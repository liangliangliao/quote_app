package com.example.virtualincense

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.virtualincense.ui.theme.Amber
import com.example.virtualincense.ui.theme.AmberStrong
import com.example.virtualincense.ui.theme.BackgroundBottom
import com.example.virtualincense.ui.theme.BackgroundTop
import com.example.virtualincense.ui.theme.CardStroke
import com.example.virtualincense.ui.theme.CardSurface
import com.example.virtualincense.ui.theme.SoftText
import com.example.virtualincense.ui.theme.VirtualIncenseTheme
import com.example.virtualincense.ui.theme.WarmText
import kotlinx.coroutines.delay
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VirtualIncenseTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VirtualIncenseApp()
                }
            }
        }
    }
}

data class Preset(
    val id: String,
    val title: String,
    val text: String,
    val icon: ImageVector,
)

@Composable
fun VirtualIncenseApp() {
    val presets = remember {
        listOf(
            Preset("peace", "平安", "愿心安定，烦扰渐散。", Icons.Rounded.Favorite),
            Preset("luck", "转运", "把晦气放下，把好运请进来。", Icons.Rounded.AutoAwesome),
            Preset("clean", "清净", "杂念止息，空间与心绪一起清明。", Icons.Rounded.SelfImprovement),
            Preset("rest", "安睡", "今夜安稳，梦里无惊。", Icons.Rounded.Bedtime),
        )
    }

    var selectedId by rememberSaveable { mutableStateOf("luck") }
    var wish by rememberSaveable { mutableStateOf("愿烦心事散去，接下来一切顺一点。") }
    var durationSeconds by rememberSaveable { mutableIntStateOf(90) }
    var running by rememberSaveable { mutableStateOf(false) }
    var progress by rememberSaveable { mutableFloatStateOf(0f) }
    var completedCount by rememberSaveable { mutableIntStateOf(0) }
    var soundOn by rememberSaveable { mutableStateOf(false) }

    val currentPreset = presets.first { it.id == selectedId }

    LaunchedEffect(running, durationSeconds) {
        if (!running) return@LaunchedEffect
        progress = 0f
        val totalTicks = durationSeconds * 10
        repeat(totalTicks) { tick ->
            delay(100)
            progress = ((tick + 1f) / totalTicks.toFloat()).coerceIn(0f, 1f)
        }
        running = false
        completedCount += 1
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(BackgroundTop, BackgroundBottom)
                )
            )
            .padding(horizontal = 16.dp, vertical = 20.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { HeaderCard() }
            item { IncenseVisualCard(progress = progress, running = running) }
            item {
                RitualCard(
                    presets = presets,
                    selectedId = selectedId,
                    onSelectPreset = { preset ->
                        selectedId = preset.id
                        wish = preset.text
                    },
                    wish = wish,
                    onWishChange = { wish = it },
                    durationSeconds = durationSeconds,
                    onDurationChange = { durationSeconds = it },
                    running = running,
                    onStart = { running = true },
                    onReset = {
                        running = false
                        progress = 0f
                    }
                )
            }
            item {
                NotesCard(
                    currentTitle = currentPreset.title,
                    completedCount = completedCount,
                    soundOn = soundOn,
                    onToggleSound = { soundOn = !soundOn }
                )
            }
        }
    }
}

@Composable
private fun HeaderCard() {
    GlassCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "电子上香",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = WarmText,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "把这款 App 当成一个安定情绪的小仪式：写下烦心事，点一炷模拟香，让自己慢下来。",
                    color = SoftText,
                    lineHeight = 22.sp,
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            PillBadge()
        }
    }
}

@Composable
private fun PillBadge() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(Color(0x33F2B46D), RoundedCornerShape(100))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Icon(
            imageVector = Icons.Rounded.LocalFireDepartment,
            contentDescription = null,
            tint = Amber,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text("模拟祈愿", color = Amber, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun IncenseVisualCard(progress: Float, running: Boolean) {
    GlassCard {
        Text(
            text = when {
                running -> "香正在燃烧中"
                progress >= 1f -> "本次祈愿已完成"
                else -> "尚未开始"
            },
            color = WarmText,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
                .background(Color(0x12000000), RoundedCornerShape(28.dp))
                .border(1.dp, CardStroke, RoundedCornerShape(28.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            IncenseCanvas(progress = progress, running = running)
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "进度", color = SoftText)
            Text(text = "${(progress * 100).toInt()}%", color = SoftText)
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp),
            color = Amber,
            trackColor = Color.White.copy(alpha = 0.08f),
        )
    }
}

@Composable
private fun IncenseCanvas(progress: Float, running: Boolean) {
    val transition = rememberInfiniteTransition(label = "smoke")
    val drift by transition.animateFloat(
        initialValue = -14f,
        targetValue = 14f,
        animationSpec = infiniteRepeatable(
            animation = tween(3400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "drift"
    )
    val glow by transition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "glow"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val centerX = width / 2f
        val burnerTop = height * 0.76f

        drawRoundRect(
            color = Color(0xFF2E241D),
            topLeft = Offset(centerX - 120f, burnerTop),
            size = Size(240f, 44f),
            cornerRadius = CornerRadius(32f, 32f)
        )
        drawRoundRect(
            color = Color(0x99362821),
            topLeft = Offset(centerX - 70f, burnerTop - 12f),
            size = Size(140f, 18f),
            cornerRadius = CornerRadius(18f, 18f)
        )

        val stickHeight = 170f
        val spacing = 40f
        val burnAmount = min(progress, 1f) * stickHeight
        val stickXs = listOf(centerX - spacing, centerX, centerX + spacing)

        stickXs.forEachIndexed { index, x ->
            val bottomY = burnerTop
            val topY = bottomY - stickHeight

            drawRoundRect(
                color = Color(0xFFAE6B2E),
                topLeft = Offset(x - 5f, topY),
                size = Size(10f, stickHeight),
                cornerRadius = CornerRadius(8f, 8f)
            )
            drawRoundRect(
                color = Color(0xFF1B1715),
                topLeft = Offset(x - 5f, topY),
                size = Size(10f, burnAmount),
                cornerRadius = CornerRadius(8f, 8f)
            )

            val emberY = topY + burnAmount.coerceIn(6f, stickHeight)
            drawCircle(
                color = AmberStrong.copy(alpha = 0.35f * glow),
                radius = 18f,
                center = Offset(x, emberY)
            )
            drawCircle(
                color = lerp(AmberStrong, Color(0xFFFFCC8A), glow),
                radius = 6f,
                center = Offset(x, emberY)
            )

            if (running) {
                val path = Path().apply {
                    moveTo(x, emberY - 12f)
                    cubicTo(
                        x + drift * (index + 1) * 0.4f,
                        emberY - 70f,
                        x - drift * (index + 1) * 0.3f,
                        emberY - 140f,
                        x + drift * 0.5f,
                        emberY - 220f
                    )
                }
                drawPath(
                    path = path,
                    color = Color.White.copy(alpha = 0.18f),
                    style = Stroke(width = 18f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = path,
                    color = Color.White.copy(alpha = 0.10f),
                    style = Stroke(width = 32f, cap = StrokeCap.Round)
                )
            }
        }
    }
}

@Composable
private fun RitualCard(
    presets: List<Preset>,
    selectedId: String,
    onSelectPreset: (Preset) -> Unit,
    wish: String,
    onWishChange: (String) -> Unit,
    durationSeconds: Int,
    onDurationChange: (Int) -> Unit,
    running: Boolean,
    onStart: () -> Unit,
    onReset: () -> Unit,
) {
    GlassCard {
        Text(
            text = "祈愿",
            style = MaterialTheme.typography.titleLarge,
            color = WarmText,
            fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(text = "快速主题", color = SoftText)
        Spacer(modifier = Modifier.height(10.dp))

        presets.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { preset ->
                    PresetChip(
                        preset = preset,
                        selected = preset.id == selectedId,
                        onClick = { onSelectPreset(preset) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        Text(text = "写下此刻想放下的事 / 想求的愿", color = SoftText)
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = wish,
            onValueChange = onWishChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("例如：希望这阵子的晦气过去，事情顺一点") },
            minLines = 3,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.04f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                focusedTextColor = WarmText,
                unfocusedTextColor = WarmText,
                focusedIndicatorColor = Amber,
                unfocusedIndicatorColor = Color.White.copy(alpha = 0.08f),
                cursorColor = Amber,
                focusedPlaceholderColor = SoftText,
                unfocusedPlaceholderColor = SoftText,
            ),
            shape = RoundedCornerShape(20.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "燃香时长", color = SoftText)
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            listOf(60, 90, 180).forEach { value ->
                val selected = durationSeconds == value
                TextButton(
                    onClick = { onDurationChange(value) },
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (selected) Color(0x22F2B46D) else Color.White.copy(alpha = 0.05f),
                                RoundedCornerShape(18.dp)
                            )
                            .border(
                                1.dp,
                                if (selected) Amber.copy(alpha = 0.4f) else CardStroke,
                                RoundedCornerShape(18.dp)
                            )
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${value}s", color = if (selected) Amber else WarmText)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = onStart,
                enabled = !running,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
            ) {
                Icon(Icons.Rounded.LocalFireDepartment, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (running) "燃烧中" else "开始上香")
            }
            OutlinedButton(
                onClick = onReset,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("重置")
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.14f), RoundedCornerShape(20.dp))
                .border(1.dp, CardStroke, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Text(
                text = wish,
                color = WarmText,
                lineHeight = 24.sp,
            )
        }
    }
}

@Composable
private fun PresetChip(
    preset: Preset,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) Color(0x22F2B46D) else Color.White.copy(alpha = 0.05f)
        ),
        border = BorderStroke(1.dp, if (selected) Amber.copy(alpha = 0.5f) else CardStroke),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White.copy(alpha = 0.08f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(preset.icon, contentDescription = null, tint = Amber)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(preset.title, color = WarmText, fontWeight = FontWeight.SemiBold)
                Text(preset.text, color = SoftText, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun NotesCard(
    currentTitle: String,
    completedCount: Int,
    soundOn: Boolean,
    onToggleSound: () -> Unit,
) {
    GlassCard {
        Text(
            text = "安定",
            style = MaterialTheme.typography.titleLarge,
            color = WarmText,
            fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(14.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x112EDC82), RoundedCornerShape(20.dp))
                .border(1.dp, Color(0x222EDC82), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Text(
                text = "先深呼吸 4 次，再检查让你不舒服的事情有没有现实原因：门窗、噪音、电器、灯光、睡眠不足或压力过大。",
                color = WarmText,
                lineHeight = 24.sp,
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            StatCard(title = "完成次数", value = completedCount.toString(), modifier = Modifier.weight(1f))
            StatCard(title = "当前主题", value = currentTitle, modifier = Modifier.weight(1f))
        }
        Spacer(modifier = Modifier.height(12.dp))
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
            border = BorderStroke(1.dp, CardStroke),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("声音陪伴", color = WarmText, fontWeight = FontWeight.SemiBold)
                    Text("当前版本仅做 UI 开关，方便你后续接入音频。", color = SoftText, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedButton(onClick = onToggleSound, shape = RoundedCornerShape(18.dp)) {
                    Icon(
                        imageVector = if (soundOn) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (soundOn) "已开启" else "点击开启")
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Divider(color = Color.White.copy(alpha = 0.07f))
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "说明：这个 App 适合做一个短暂的心理缓冲仪式，不承诺任何超自然效果。若你持续强烈恐惧、失眠，或家里有真实安全风险，优先联系家人朋友并检查环境。",
            color = SoftText,
            lineHeight = 22.sp,
            textAlign = TextAlign.Start,
        )
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
        border = BorderStroke(1.dp, CardStroke),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = SoftText, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, color = WarmText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        border = BorderStroke(1.dp, CardStroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            content = content
        )
    }
}
