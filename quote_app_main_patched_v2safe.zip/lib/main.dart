// v2-safe Flutter entrypoint.
// No manual GeneratedPluginRegistrant calls; initialization is in native V2 embedding.
import 'package:flutter/material.dart';

import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/settings_page.dart';
import 'pages/logs_page.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'data/db.dart';

Future<void> main() async {
  // Required when using async initialization before runApp.
  WidgetsFlutterBinding.ensureInitialized();

  // App-level initializations.
  await AppDatabase.instance();
  await NotificationService.init();
  await SchedulerService.init();
  await SchedulerService.scheduleNextForAll();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quote App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const RootShell(),
    );
  }
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _idx = 0;

  late final List<Widget> _pages = <Widget>[
    const HomePage(),
    const HistoryPage(),
    const LogsPage(),
    const SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (int i) => setState(() => _idx = i),
      ),
    );
  }
}
