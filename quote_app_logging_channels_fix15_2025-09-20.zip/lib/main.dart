
import 'dart:io';
import 'package:flutter/material.dart';

import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';

import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'data/db.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // 先启动 UI，避免首帧卡顿；初始化在首帧后异步进行
  runApp(const MyApp());
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    await AppDatabase.instance();
    try { await NotificationService.init(); } catch (_) {}
    try { await SchedulerService.init(); } catch (_) {}
    // Android 13+ 主动申请一次通知权限（前台）
    if (Platform.isAndroid) { try { await NotificationService.requestAndroidPermissionSafely(); } catch (_) {} }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
      home: const _Root(),
    );
  }
}

class _Root extends StatefulWidget {
  const _Root({super.key});
  @override
  State<_Root> createState() => _RootState();
}

class _RootState extends State<_Root> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) => setState(() => _idx = i),
      ),
    );
  }
}
