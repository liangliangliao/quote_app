
import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  final String endpoint; // e.g., https://api.openai.com/v1/responses or /chat/completions
  final String apiKey;
  final String model;

  OpenAIService({required this.endpoint, required this.apiKey, required this.model});

  Future<String> generateQuote(String prompt) async {
    final uri = Uri.parse(endpoint);
    final headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json'
    };

    Map<String, dynamic> payload;
    final path = uri.path.toLowerCase();
    if (path.contains('/chat/completions')) {
      // OpenAI Chat Completions style
      payload = {
        'model': model,
        'messages': [
          {'role': 'user', 'content': prompt}
        ]
      };
    } else {
      // Responses / Completions style（兼容）
      payload = {
        'model': model,
        'input': prompt,
      };
    }

    final resp = await http.post(uri, headers: headers, body: json.encode(payload));

    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      // 明确把非 2xx 当作失败抛出，外层会记录日志
      throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
    }

    final data = json.decode(resp.body);

    // Chat Completions API
    if (data is Map && data['choices'] is List && data['choices'].isNotEmpty) {
      final first = data['choices'][0];
      if (first is Map && first['message'] is Map) {
        final msg = first['message'];
        final content = (msg['content'] ?? '').toString();
        if (content.trim().isNotEmpty) return content.trim();
      }
      // text completion 退路
      final text = first['text'];
      if (text != null && text.toString().trim().isNotEmpty) {
        return text.toString().trim();
      }
    }

    // Responses API (可能是 content 字段)
    if (data is Map && data['content'] != null) {
      final content = data['content'].toString().trim();
      if (content.isNotEmpty) return content;
    }

    throw Exception('未知返回结构或内容为空');
  }
}
