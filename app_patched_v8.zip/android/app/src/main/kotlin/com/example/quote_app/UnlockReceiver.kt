package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver listens for the USER_PRESENT broadcast which fires
 * when the user unlocks the device. When triggered, it checks for
 * any enabled screen‑unlock vision triggers and, if present, sends a
 * gentle reminder notification encouraging the user to recall their
 * vision goal.
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Use goAsync() to extend the lifetime of this receiver so that
        // database access and notification posting can run off the main
        // thread without risking ANR. Without this, some OEM ROMs may
        // terminate the receiver prematurely when the app is in the
        // background or killed from recents, causing the unlock event to
        // effectively be lost. The pendingResult must be finished when work
        // completes.
        val pendingResult = goAsync()
        // Offload the heavy work to a background thread.
        Thread {
            try {
                // Log the received broadcast action for debugging and analytics
                try {
                    // Prepend a timestamp to the log entry so the logs page can display
                    // when the event occurred. Without a timestamp, the UI may not
                    // extract a time for display.
                    val ts = try {
                        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                        fmt.format(java.util.Date())
                    } catch (_: Throwable) { "" }
                    DbRepo.log(context, null, "[" + ts + "] [UnlockReceiver] onReceive action=" + (intent?.action ?: "null"))
                } catch (_: Throwable) {}

                // Attempt to load the DB contract; if unavailable we still
                // proceed to send a reminder as a conservative default.
                val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
                var hasTrigger = false
                if (contract == null || contract.dbPath == null) {
                    // If contract or db path is unavailable, assume triggers may exist
                    try {
                        val ts2 = try {
                            val fmt2 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                            fmt2.format(java.util.Date())
                        } catch (_: Throwable) { "" }
                        DbRepo.log(context, null, "[" + ts2 + "] [UnlockReceiver] contract or dbPath unavailable, fallback to send reminder")
                    } catch (_: Throwable) {}
                    hasTrigger = true
                } else {
                    // Query for enabled screen_unlock triggers
                    try {
                        val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
                        val cursor = db.rawQuery(
                            "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                            null
                        )
                        hasTrigger = cursor.moveToFirst()
                        try {
                            val ts3 = try {
                                val fmt3 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                                fmt3.format(java.util.Date())
                            } catch (_: Throwable) { "" }
                            DbRepo.log(context, null, "[" + ts3 + "] [UnlockReceiver] hasTrigger=" + hasTrigger)
                        } catch (_: Throwable) {}
                        cursor.close()
                        db.close()
                    } catch (_: Throwable) {
                        // If any DB error occurs, assume we should send a reminder
                        hasTrigger = true
                        try {
                        val ts4 = try {
                            val fmt4 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                            fmt4.format(java.util.Date())
                        } catch (_: Throwable) { "" }
                        DbRepo.log(context, null, "[" + ts4 + "] [UnlockReceiver] DB query failed; treating as hasTrigger=true")
                        } catch (_: Throwable) {}
                    }
                }
                if (hasTrigger) {
                    // Record the timestamp of this unlock event so the app can detect
                    // recent unlocks when it starts. This value will be consumed
                    // by App.maybeSendUnlockReminderOnAppStart to avoid sending
                    // reminders when the app is opened long after unlocking.
                    try {
                        val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                        prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                        try {
                            val ts5 = try {
                                val fmt5 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                                fmt5.format(java.util.Date())
                            } catch (_: Throwable) { "" }
                            DbRepo.log(context, null, "[" + ts5 + "] [UnlockReceiver] recorded last_unlock_time")
                        } catch (_: Throwable) {}
                    } catch (_: Throwable) { /* ignore errors */ }
                    sendReminder(context)
                }
            } catch (_: Throwable) {
                // On any error, fallback to sending reminder. Record the unlock time
                try {
                    val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                    try {
                        val ts6 = try {
                            val fmt6 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                            fmt6.format(java.util.Date())
                        } catch (_: Throwable) { "" }
                        DbRepo.log(context, null, "[" + ts6 + "] [UnlockReceiver] exception occurred, fallback to send reminder")
                    } catch (_: Throwable) {}
                } catch (_: Throwable) { /* ignore */ }
                sendReminder(context)
            } finally {
                // Always finish the pending result to allow the broadcast to
                // return to the system. Without calling finish(), the
                // broadcast may be considered to be running forever and
                // eventually terminated, especially on newer Android versions.
                try {
                    pendingResult.finish()
                } catch (_: Throwable) {
                    // ignore
                }
            }
        }.start()
    }

    /**
     * Sends a notification reminding the user about their vision goal.
     */
    private fun sendReminder(context: Context) {
        // 记录最近一次通过解锁事件发送提醒的时间，方便 App 在启动时
        // 避免立刻再补发一条重复通知。
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_unlock_reminder_time", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
            // ignore
        }

        // Use a deterministic ID to avoid flooding the notification drawer
        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        // Pass notifType so that tapping the notification opens the vision focus page
        try {
            val ts = try {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                fmt.format(java.util.Date())
            } catch (_: Throwable) { "" }
            DbRepo.log(context, null, "[" + ts + "] [UnlockReceiver] sending reminder notification")
        } catch (_: Throwable) {}
        NotifyHelper.send(context, id, title, body, null, "vision_focus", null)
    }
}