package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

object Channels {
  private const val CH = "native.scheduler"

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
                "scheduleNextForUid" -> { val uid = call.argument<String>("uid"); if (uid!=null) { NativeSchedulerK.scheduleNextForUid(appCtx, uid); result.success(true) } else result.error("bad_args","missing uid", null) }
                "cancelByIdCard" -> { val idc = call.argument<String>("idCard"); if (idc!=null) { NativeSchedulerK.cancelByIdCard(appCtx, idc); result.success(true) } else result.error("bad_args","missing idCard", null) }
                "isNativeWM" -> result.success(true)
                "isNativeAM" -> result.success(true)
          "canScheduleExact" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))
          "scheduleExactAt" -> {
            val id = call.argument<Int>("id") ?: 0
            val epochMs = call.argument<Long>("epochMs") ?: 0L
            val payload = call.argument<String>("payload")
            val ok = NativeSchedulerK.scheduleExactAt(appCtx, id, epochMs, payload)
            result.success(ok)
          }
          "cancel" -> {
            val id = call.argument<Int>("id") ?: 0
            NativeSchedulerK.cancel(appCtx, id)
            result.success(null)
          }
          "cancelAll" -> { NativeSchedulerK.cancelAll(appCtx); result.success(null) }
          
          "dbInfo" -> {
            try {
              val arg = call.arguments as? Map<*, *>
              val path = arg?.get("dbPath") as? String
              val ver = (arg?.get("version") as? Int) ?: 1
              if (!path.isNullOrEmpty()) {
                android.util.Log.i("Channels", "dbInfo received path=" + path + " ver=" + ver + " schema=" + ( (arg?.get("schema") as? Map<*,*>)?.size ?: 0))
                // save minimal contract into prefs so DbInspector can pick it up
                val o = org.json.JSONObject()
                o.put("dbPath", path)
                o.put("version", ver)
                o.put("logsSource", "logs");
                o.put("tasksSource", "tasks");
                o.put("quotesSource", "quotes");
                val logMap = org.json.JSONObject();
                logMap.put("uid", "task_uid");
                logMap.put("detail", "detail");
                o.put("logColMap", logMap);
                val taskMap = org.json.JSONObject();
                taskMap.put("uid", "task_uid");
                taskMap.put("title", "name");
                taskMap.put("content", "prompt");
                taskMap.put("avatar", "avatar_path");
                taskMap.put("enabled", "status");
                taskMap.put("trigger_at", "start_time");
                taskMap.put("next_time", "next_time");
                o.put("taskColMap", taskMap);
                val quoteMap = org.json.JSONObject();
                quoteMap.put("uid", "task_uid");
                quoteMap.put("content", "content");
                o.put("quoteColMap", quoteMap)
                // optional: persist full schema if provided by Dart
                val schemaArg = arg?.get("schema")
                if (schemaArg is Map<*, *>) {
                    val schemaJson = org.json.JSONObject(schemaArg)
                    o.put("schema", schemaJson)
                }
                val sp = android.preference.PreferenceManager.getDefaultSharedPreferences(appCtx)
                sp.edit().putString("db.contract", o.toString()).apply()
                result.success(true)
              } else result.error("bad_args","missing path", null)
            } catch (t: Throwable) { result.error("ERR", t.message, null) }
          }
    
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
        // System/perm support channel used by Dart (PermHelper & NativeGuard)
    MethodChannel(engine.dartExecutor.binaryMessenger, "com.example.quote_app/sys").setMethodCallHandler { call, result ->
      try {
        when (call.method) {
                "scheduleNextForUid" -> { val uid = call.argument<String>("uid"); if (uid!=null) { NativeSchedulerK.scheduleNextForUid(appCtx, uid); result.success(true) } else result.error("bad_args","missing uid", null) }
                "cancelByIdCard" -> { val idc = call.argument<String>("idCard"); if (idc!=null) { NativeSchedulerK.cancelByIdCard(appCtx, idc); result.success(true) } else result.error("bad_args","missing idCard", null) }
          "isNativeWmEnabled" -> result.success(true)
          "isNativeAmEnabled" -> result.success(true)
          "hasExactAlarmPermission" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactAlarmPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))
          
          "dbInfo" -> {
            try {
              val arg = call.arguments as? Map<*, *>
              val path = arg?.get("dbPath") as? String
              val ver = (arg?.get("version") as? Int) ?: 1
              if (!path.isNullOrEmpty()) {
                android.util.Log.i("Channels", "dbInfo received path=" + path + " ver=" + ver + " schema=" + ( (arg?.get("schema") as? Map<*,*>)?.size ?: 0))
                // save minimal contract into prefs so DbInspector can pick it up
                val o = org.json.JSONObject()
                o.put("dbPath", path)
                o.put("version", ver)
                o.put("logsSource", "logs");
                o.put("tasksSource", "tasks");
                o.put("quotesSource", "quotes");
                val logMap = org.json.JSONObject();
                logMap.put("uid", "task_uid");
                logMap.put("detail", "detail");
                o.put("logColMap", logMap);
                val taskMap = org.json.JSONObject();
                taskMap.put("uid", "task_uid");
                taskMap.put("title", "name");
                taskMap.put("content", "prompt");
                taskMap.put("avatar", "avatar_path");
                taskMap.put("enabled", "status");
                taskMap.put("trigger_at", "start_time");
                taskMap.put("next_time", "next_time");
                o.put("taskColMap", taskMap);
                val quoteMap = org.json.JSONObject();
                quoteMap.put("uid", "task_uid");
                quoteMap.put("content", "content");
                o.put("quoteColMap", quoteMap)
                // optional: persist full schema if provided by Dart
                val schemaArg = arg?.get("schema")
                if (schemaArg is Map<*, *>) {
                    val schemaJson = org.json.JSONObject(schemaArg)
                    o.put("schema", schemaJson)
                }
                val sp = android.preference.PreferenceManager.getDefaultSharedPreferences(appCtx)
                sp.edit().putString("db.contract", o.toString()).apply()
                result.success(true)
              } else result.error("bad_args","missing path", null)
            } catch (t: Throwable) { result.error("ERR", t.message, null) }
          }
    
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
    
}
  }
}
