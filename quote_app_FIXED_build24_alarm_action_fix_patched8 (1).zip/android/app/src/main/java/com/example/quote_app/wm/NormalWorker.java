package com.example.quote_app.wm;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

public final class NormalWorker extends Worker {

    public NormalWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override public ListenableWorker.Result doWork() {
        Context ctx = getApplicationContext();
        Data in = getInputData();
        String uid = in.getString("uid");
        String runKey = in.getString("runKey");
        String chan = in.getString("chan");
        int attempt = in.getInt("attempt", 1);

        try {
            DbRepository.log(ctx, uid, "【原生】WM 正常通道触发 uid="+uid+" run="+runKey+" attempt="+attempt);
            boolean ok = Biz.run(ctx, uid);
            if (ok) {
                DbRepository.markLatestSuccess(ctx, uid);
                // 成功：取消兜底，安排下一次
                WmScheduler.cancelFallback(ctx, uid, runKey);
                long next = NextTriggerCalculator.compute(ctx, uid);
                if (next > 0) {
                    WmScheduler.schedulePair(ctx, next, uid, "ts_" + next);
                }
                return Result.success();
            } else {
                DbRepository.log(ctx, uid, "【原生】WM 正常通道发送失败 uid="+uid+" run="+runKey);
                // 失败：不取消兜底，仅安排下一次（让兜底还有机会）
                long next = NextTriggerCalculator.compute(ctx, uid);
                if (next > 0) {
                    WmScheduler.schedulePair(ctx, next, uid, "ts_" + next);
                }
                return Result.retry(); // 交由系统策略，也不影响兜底
            }
        } catch (Throwable t) {
            DbRepository.log(ctx, uid, "WM正常通道异常: " + t.getMessage());
            return Result.retry();
        }
    }
}
