import 'package:flutter/material.dart';

import 'pages/belief_forge_home_page.dart';
import 'pages/belief_lab_page.dart';
import 'pages/belief_map_page.dart';
import 'pages/permission_space_page.dart';
import 'pages/will_gym_page.dart';
import 'pages/belief_review_page.dart';
import 'belief_game_service.dart';

/// BeliefForge (信念工坊) module root.
///
/// This is intentionally implemented as a standalone feature (own navigation
/// shell) so it can be plugged into the existing Quotes app via a single entry
/// point on the Home page.
class BeliefForgeShellPage extends StatefulWidget {
  const BeliefForgeShellPage({super.key});

  @override
  State<BeliefForgeShellPage> createState() => _BeliefForgeShellPageState();
}

class _BeliefForgeShellPageState extends State<BeliefForgeShellPage> {
  int _idx = 0;

  @override
  void initState() {
    super.initState();
    // Warm up schema + profile so all pages can read level/quests immediately.
    BeliefGameService.instance.init();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const BeliefForgeHomePage(),
      const BeliefLabPage(),
      const BeliefMapPage(),
      const WillGymPage(),
      const PermissionSpacePage(),
      const BeliefReviewPage(),
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('信念工坊'),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: IndexedStack(index: _idx, children: pages),
      bottomNavigationBar: SafeArea(
        top: false,
        child: NavigationBar(
          elevation: 0,
          surfaceTintColor: Colors.transparent,
          shadowColor: Colors.transparent,
          selectedIndex: _idx,
          onDestinationSelected: (i) => setState(() => _idx = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: '概览'),
            NavigationDestination(icon: Icon(Icons.school_outlined), label: '实验室'),
            NavigationDestination(icon: Icon(Icons.map_outlined), label: '图谱'),
            NavigationDestination(icon: Icon(Icons.fitness_center_outlined), label: '意志'),
            NavigationDestination(icon: Icon(Icons.self_improvement_outlined), label: '允许区'),
            NavigationDestination(icon: Icon(Icons.insights_outlined), label: '复盘'),
          ],
        ),
      ),
    );
  }
}
