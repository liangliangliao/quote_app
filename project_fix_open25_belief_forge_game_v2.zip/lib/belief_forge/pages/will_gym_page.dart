import 'dart:async';

import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../widgets/game_feedback.dart';

/// Will Gym: based on William James' “fiat” (a decisive act of will)
/// and the training of voluntary attention.
class WillGymPage extends StatelessWidget {
  const WillGymPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
      children: const [
        Text('意志训练', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        SizedBox(height: 8),
        Text(
          '意志不是“靠感觉”。\n'
          'William James 强调两件事：\n'
          '① fiat：在犹豫中做一个明确的“现在就做”的决定；\n'
          '② 自愿注意：把注意力一次次从分心拉回目标。\n\n'
          '下面两个训练都很短，但非常“见效”：你会亲自体验“我可以选择”。',
          style: TextStyle(fontSize: 13, color: Colors.black54, height: 1.3),
        ),
        SizedBox(height: 12),
        _FiatTrainer(),
        SizedBox(height: 12),
        _AttentionTrainer(),
      ],
    );
  }
}

class _FiatTrainer extends StatefulWidget {
  const _FiatTrainer();

  @override
  State<_FiatTrainer> createState() => _FiatTrainerState();
}

class _FiatTrainerState extends State<_FiatTrainer> {
  final _dao = BeliefForgeDao();
  final _goal = TextEditingController();
  Timer? _timer;
  int _left = 0;
  bool _running = false;

  @override
  void dispose() {
    _timer?.cancel();
    _goal.dispose();
    super.dispose();
  }

  void _start() {
    final g = _goal.text.trim();
    if (g.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('先写一个你正在犹豫的行动')));
      return;
    }
    setState(() {
      _left = 120;
      _running = true;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_left <= 1) {
        t.cancel();
        setState(() {
          _left = 0;
          _running = false;
        });
        _dao.addRun(
          conceptId: 'will_fiat',
          conceptTitle: 'Fiat 决断（120 秒）',
          runType: 'will',
          durationSec: 120,
          note: g,
        );
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('训练完成：已记录 fiat 决断')));
        // Gamification: XP + badge
        Future(() async {
          final award = await BeliefGameService.instance.awardXp(xp: 12, reason: '意志训练');
          await BeliefGameService.instance.unlockBadge(
            key: 'badge_first_will',
            extra: {'title': '第一次意志训练', 'desc': '你完成了第一次意志训练。'},
          );
          if (context.mounted) {
            await showXpFeedback(context, award: award);
          }
        });
        return;
      }
      setState(() => _left--);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('1) fiat 决断：120 秒把犹豫变成行动', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text(
              'fiat 的意思是：在犹豫时，做一个明确的“就现在”。\n'
              '不是等动力，而是给大脑一个命令：我选择开始。',
              style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.25),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _goal,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: '写一个你正在犹豫的动作（例：打开简历改 1 行）',
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _running ? null : _start,
                    icon: const Icon(Icons.play_arrow),
                    label: Text(_running ? '进行中：${_left}s' : '开始 120 秒'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              '完成后请立刻做一个最小动作（30 秒也算）。你会体验到：意志=可以开始。',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class _AttentionTrainer extends StatefulWidget {
  const _AttentionTrainer();

  @override
  State<_AttentionTrainer> createState() => _AttentionTrainerState();
}

class _AttentionTrainerState extends State<_AttentionTrainer> {
  final _dao = BeliefForgeDao();
  final _target = TextEditingController(text: '写第一句');
  int _pullBacks = 0;
  bool _started = false;
  Timer? _timer;
  int _left = 45;

  @override
  void dispose() {
    _timer?.cancel();
    _target.dispose();
    super.dispose();
  }

  void _start() {
    setState(() {
      _pullBacks = 0;
      _started = true;
      _left = 45;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_left <= 1) {
        t.cancel();
        setState(() {
          _started = false;
          _left = 0;
        });
        _dao.addRun(
          conceptId: 'will_attention',
          conceptTitle: '自愿注意拉回（45 秒）',
          runType: 'will',
          durationSec: 45,
          score: _pullBacks.toDouble(),
          note: _target.text.trim(),
        );
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('训练完成：拉回 $_pullBacks 次（已记录）')));
        Future(() async {
          final award = await BeliefGameService.instance.awardXp(xp: 10, reason: '注意力拉回');
          await BeliefGameService.instance.unlockBadge(
            key: 'badge_first_will',
            extra: {'title': '第一次意志训练', 'desc': '你完成了第一次意志训练。'},
          );
          if (context.mounted) {
            await showXpFeedback(context, award: award);
          }
        });
        return;
      }
      setState(() => _left--);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('2) 自愿注意：把注意力一次次拉回目标', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text(
              'James 认为：意志的核心训练就是“注意力的训练”。\n'
              '你不需要永不分心，你只需要：发现分心 → 拉回。',
              style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.25),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _target,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: '你的目标注意点',
                helperText: '例：写第一句 / 背 1 个单词 / 走 2 分钟',
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _started ? null : _start,
                    icon: const Icon(Icons.play_arrow),
                    label: Text(_started ? '进行中：${_left}s' : '开始 45 秒'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('目标：${_target.text.trim().isEmpty ? '（未填写）' : _target.text.trim()}'),
                  const SizedBox(height: 6),
                  Text('拉回次数：$_pullBacks', style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: _started
                  ? () => setState(() => _pullBacks++)
                  : null,
              icon: const Icon(Icons.undo),
              label: const Text('我分心了，我把注意力拉回来'),
            ),
            const SizedBox(height: 8),
            const Text(
              '提示：分心不可避免；“拉回一次”就是一次意志训练。',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
