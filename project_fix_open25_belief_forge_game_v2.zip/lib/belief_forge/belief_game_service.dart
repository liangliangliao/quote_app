import 'dart:async';
import 'dart:math';

import 'belief_game_dao.dart';
import 'model/belief_game.dart';

/// In-memory game state + database backing.
///
/// This is intentionally tiny (no provider dependency): UI can listen via
/// [profileListenable].
class BeliefGameService {
  BeliefGameService._();

  static final BeliefGameService instance = BeliefGameService._();

  final BeliefGameDao _dao = BeliefGameDao();
  final ValueNotifier<BeliefProfile> profileListenable = ValueNotifier<BeliefProfile>(BeliefProfile.defaultProfile());

  bool _inited = false;
  Future<void>? _initFuture;

  Future<void> init() {
    if (_inited) return Future.value();
    if (_initFuture != null) return _initFuture!;
    _initFuture = _load().then((_) => _inited = true);
    return _initFuture!;
  }

  Future<void> _load() async {
    await _dao.ensureSchema();
    final p = await _dao.getOrCreateProfile();
    profileListenable.value = p;
  }

  Future<BeliefProfile> refreshProfile() async {
    await _dao.ensureSchema();
    final p = await _dao.getOrCreateProfile();
    profileListenable.value = p;
    return p;
  }

  Future<XpAward> awardXp({required int xp, int coins = 0, String? reason}) async {
    await init();
    final award = await _dao.addXp(xp: xp, coins: coins, reason: reason);
    await refreshProfile();
    return award;
  }

  Future<bool> unlockBadge(String key, {Map<String, dynamic>? extra}) async {
    await init();
    final inserted = await _dao.unlockBadge(key, extra: extra);
    return inserted;
  }

  Future<List<Map<String, dynamic>>> listBadges({int limit = 50}) async {
    await init();
    return _dao.listAchievements(limit: limit);
  }

  String todayYmd() => ymd(DateTime.now());

  int todayStartMs() {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    return start.millisecondsSinceEpoch;
  }

  Future<Map<String, int>> getTodayCounts() async {
    await init();
    final startMs = todayStartMs();
    final actionCards = await _dao.countRunsSince(startMs, runType: 'lab', extraTypeContains: 'action_card');
    final will = await _dao.countRunsSince(startMs, runType: 'will');
    final space = await _dao.countRunsSince(startMs, runType: 'space');
    final mapTouched = await _dao.countRunsSince(startMs, runType: 'map');
    final mapTouchedFallback = await _dao.countBeliefsTouchedSince(startMs);
    // Journals are also stored; keep as backup for older data.
    final journals = await _dao.countJournalsSince(startMs);
    return {
      'action_card': actionCards,
      'will': will,
      'space': max(space, journals),
      'map': max(mapTouched, mapTouchedFallback),
    };
  }

  Future<bool> isQuestClaimed(String questId) async {
    await init();
    return _dao.isQuestClaimed(day: todayYmd(), questId: questId);
  }

  Future<XpAward?> claimQuestIfEligible({required DailyQuestDef quest, required int progress}) async {
    await init();
    final before = profileListenable.value;
    final day = todayYmd();
    final claimed = await _dao.isQuestClaimed(day: day, questId: quest.id);
    if (claimed) return null;
    if (progress < quest.target) return null;
    await _dao.claimQuest(day: day, quest: quest);
    final after = await refreshProfile();
    return XpAward(xpGained: quest.xp, coinsGained: quest.coins, oldLevel: before.level, newLevel: after.level);
  }

  Future<bool> isChestClaimed() async {
    await init();
    return _dao.isChestClaimed(day: todayYmd());
  }

  Future<void> claimChest({int coins = 5}) async {
    await init();
    await _dao.claimChest(day: todayYmd(), coins: coins);
    await refreshProfile();
  }
}
