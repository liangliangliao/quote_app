import 'dart:convert';
import 'dart:math';

import '../data/db.dart';
import 'model/belief_game.dart';
import 'package:sqflite/sqflite.dart';

/// SQLite DAO for BeliefForge gamification.
class BeliefGameDao {
  static const int _profileId = 1;

  Future<void> ensureSchema() async {
    await AppDatabase.instance();
    // Tables are created idempotently in AppDatabase.instance() open hook.
  }

  Future<BeliefProfile> getOrCreateProfile() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('belief_forge_profile', where: 'id=?', whereArgs: const [_profileId], limit: 1);
    if (rows.isNotEmpty) {
      return BeliefProfile.fromRow(Map<String, dynamic>.from(rows.first));
    }
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert('belief_forge_profile', {
      'id': _profileId,
      'xp': 0,
      'coins': 0,
      'streak': 0,
      'last_active_day': null,
      'last_chest_claim_day': null,
      'created_at_ms': now,
      'updated_at_ms': now,
    });
    final rows2 = await db.query('belief_forge_profile', where: 'id=?', whereArgs: const [_profileId], limit: 1);
    if (rows2.isNotEmpty) {
      return BeliefProfile.fromRow(Map<String, dynamic>.from(rows2.first));
    }
    return BeliefProfile.defaultProfile();
  }

  Future<XpAward> addXp({
    required int xp,
    int coins = 0,
    String? reason,
  }) async {
    await ensureSchema();
    final db = await AppDatabase.instance();
    final before = await getOrCreateProfile();
    final now = DateTime.now();
    final today = ymd(now);
    final yesterday = ymdYesterday(now);

    int newStreak = before.streak;
    if (before.lastActiveDay.isEmpty) {
      newStreak = 1;
    } else if (before.lastActiveDay == today) {
      // keep
    } else if (before.lastActiveDay == yesterday) {
      newStreak = max(1, before.streak + 1);
    } else {
      newStreak = 1;
    }

    final oldLevel = before.level;
    final newXp = max(0, before.xp + xp);
    final newCoins = max(0, before.coins + coins);
    final updatedAt = now.millisecondsSinceEpoch;

    await db.update(
      'belief_forge_profile',
      {
        'xp': newXp,
        'coins': newCoins,
        'streak': newStreak,
        'last_active_day': today,
        'updated_at_ms': updatedAt,
      },
      where: 'id=?',
      whereArgs: const [_profileId],
    );

    final afterRows = await db.query('belief_forge_profile', where: 'id=?', whereArgs: const [_profileId], limit: 1);
    final after = afterRows.isEmpty ? before.copyWith(xp: newXp, coins: newCoins, streak: newStreak, lastActiveDay: today) : BeliefProfile.fromRow(Map<String, dynamic>.from(afterRows.first));

    return XpAward(
      xpGained: xp,
      coinsGained: coins,
      oldLevel: oldLevel,
      newLevel: after.level,
    );
  }

  Future<bool> hasBadge(String key) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('belief_forge_achievements', where: 'key=?', whereArgs: [key], limit: 1);
    return rows.isNotEmpty;
  }

  Future<bool> unlockBadge(String key, {Map<String, dynamic>? extra}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    final res = await db.insert(
      'belief_forge_achievements',
      {
        'key': key,
        'unlocked_at_ms': now,
        'extra_json': extra == null ? null : jsonEncode(extra),
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    // sqflite returns 0 on ignore.
    return res > 0;
  }

  Future<List<Map<String, dynamic>>> listAchievements({int limit = 50}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('belief_forge_achievements', orderBy: 'unlocked_at_ms DESC', limit: limit);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<bool> isQuestClaimed({required String day, required String questId}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query(
      'belief_forge_daily_quest_claims',
      where: 'day=? AND quest_id=?',
      whereArgs: [day, questId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<void> claimQuest({
    required String day,
    required DailyQuestDef quest,
  }) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert(
      'belief_forge_daily_quest_claims',
      {
        'day': day,
        'quest_id': quest.id,
        'claimed_at_ms': now,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    await addXp(xp: quest.xp, coins: quest.coins, reason: 'quest:${quest.id}');
  }

  Future<bool> isChestClaimed({required String day}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('belief_forge_daily_chest_claims', where: 'day=?', whereArgs: [day], limit: 1);
    return rows.isNotEmpty;
  }

  Future<void> claimChest({required String day, int coins = 5}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert(
      'belief_forge_daily_chest_claims',
      {
        'day': day,
        'claimed_at_ms': now,
        'coins': coins,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    await addXp(xp: 0, coins: coins, reason: 'daily_chest');
  }

  Future<int> countRunsSince(int startMs, {String? runType, String? extraTypeContains}) async {
    final db = await AppDatabase.instance();
    final where = <String>['ts_ms >= ?'];
    final args = <Object>[startMs];
    if (runType != null && runType.isNotEmpty) {
      where.add('run_type = ?');
      args.add(runType);
    }
    if (extraTypeContains != null && extraTypeContains.isNotEmpty) {
      where.add("extra_json LIKE ?");
      args.add('%"type":"$extraTypeContains"%');
    }
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM belief_forge_runs WHERE ${where.join(' AND ')}', args);
    if (rows.isEmpty) return 0;
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  Future<int> countJournalsSince(int startMs) async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM belief_forge_journals WHERE ts_ms >= ?', [startMs]);
    if (rows.isEmpty) return 0;
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  Future<int> countBeliefsTouchedSince(int startMs) async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM belief_forge_beliefs WHERE created_at_ms >= ? OR updated_at_ms >= ?',
      [startMs, startMs],
    );
    if (rows.isEmpty) return 0;
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }
}
