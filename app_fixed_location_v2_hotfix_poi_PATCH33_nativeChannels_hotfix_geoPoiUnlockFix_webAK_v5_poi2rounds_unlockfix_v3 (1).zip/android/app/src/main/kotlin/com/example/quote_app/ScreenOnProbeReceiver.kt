package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 仅用于兜底：监听 SCREEN_ON，延迟检查是否已解锁（无锁屏/智能解锁等）。
 * 只有确认“已解锁”时，才触发 UnlockWorker；否则不做任何业务。
 * 同时做 3 秒去重，避免与 USER_PRESENT 双触发。
 */
class ScreenOnProbeReceiver : BroadcastReceiver() {
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[" + now + "] " + msg)
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  override fun onReceive(context: Context, intent: Intent?) {
    if (intent?.action != Intent.ACTION_SCREEN_ON) return
    try { logWithTime(context, "【解锁后台-探测】收到 SCREEN_ON，开始延迟检查是否已解锁（回包：PROBE）") } catch (_: Throwable) {}

    val app = context.applicationContext
    val km = app.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

    Handler(Looper.getMainLooper()).postDelayed({
      val isLocked = try { km.isKeyguardLocked } catch (_: Throwable) { true }
      if (!isLocked) {
        // 去重：3 秒窗口内若已触发过解锁提醒，则跳过
        val now = System.currentTimeMillis()
        val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        val lastTrig = sp.getLong("last_unlock_trigger_ts", 0L)
        if (lastTrig > 0 && (now - lastTrig) < 3000L) {
          try { logWithTime(app, "【解锁后台-探测】3秒内已触发过解锁提醒，屏蔽本次重复（回包：SKIP_DUP）") } catch (_: Throwable) {}
          return@postDelayed
        }
        sp.edit().putLong("last_unlock_trigger_ts", now)
          .putLong("last_user_present_ts", now)  // 也记录最近“解锁时间”
          .apply()

        try { logWithTime(app, "【解锁后台-探测】检测到未上锁，判定为已解锁并触发 UnlockWorker（回包：OK）") } catch (_: Throwable) {}
        try { Toast.makeText(app, "已捕获解锁事件（探测），后台正在准备解锁提醒", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
        
        // ---- 解锁后通过透明 Activity 统一调度“地点规则提醒 + 解锁轻提醒” ----
        try { logWithTime(app, "【解锁后台-探测】即将启动透明 Activity 承载地点规则与解锁轻提醒逻辑") } catch (_: Throwable) {}
        try {
          val act = Intent(app, FgKickActivity::class.java)
          act.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          app.startActivity(act)
        } catch (t: Throwable) {
          try { logWithTime(app, "【解锁后台-探测】启动透明 Activity 失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
        }
    
      } else {
        try { logWithTime(app, "【解锁后台-探测】SCREEN_ON 后仍处于上锁状态，等待系统 USER_PRESENT 广播（回包：WAIT）") } catch (_: Throwable) {}
      }
    }, 600)
  }
}
