package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.os.SystemClock

/**
 * Fires on device unlock to display a Toast immediately even if app is in background.
 * 支持 USER_PRESENT / USER_UNLOCKED / SCREEN_ON 三种广播，并做 3 秒去抖。
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        if (action == Intent.ACTION_USER_PRESENT ||
            action == Intent.ACTION_USER_UNLOCKED ||
            action == Intent.ACTION_SCREEN_ON) {

            // 简单去抖（同 3s 内仅处理一次）
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            val now = SystemClock.elapsedRealtime()
            val last = prefs.getLong("last_unlock_broadcast_rt", 0L)
            if (last > 0 && (now - last) < 3000L) return
            prefs.edit().putLong("last_unlock_broadcast_rt", now)
                .putLong("last_unlock_time", System.currentTimeMillis())
                .apply()

            // 通过透明 Activity 统一调度“地点规则提醒 + 解锁轻提醒”逻辑
            try {
                val appCtx = context.applicationContext
                val act = Intent(appCtx, FgKickActivity::class.java)
                act.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                appCtx.startActivity(act)
            } catch (_: Throwable) {}

            // 立刻给出 Toast 反馈（无论前台/后台）
            try {
                Toast.makeText(context.applicationContext, "已解锁：轻提醒已就绪", Toast.LENGTH_SHORT).show()
            } catch (_: Throwable) {}

            // 记录日志（忽略任何异常）
            try {
                com.example.quote_app.data.DbRepo.log(context, null, "【解锁广播】$action 收到并处理")
            } catch (_: Throwable) {}
        }
    }
}