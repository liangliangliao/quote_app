package com.example.quote_app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import com.example.quote_app.data.DbRepo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * 透明 Activity：在解锁后统一调度
 * 1）地点规则提醒前台服务（GeoForegroundService）
 * 2）解锁轻提醒（UnlockWorker）
 *
 * 所有业务逻辑都在后台线程中执行；无论中间是否成功或失败，
 * finally 中都会写入详细日志并销毁自身，避免占用资源。
 */
class FgKickActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    val appCtx = applicationContext

    thread(name = "unlock-fg-activity") {
      try {
        logWithTime(appCtx, "【解锁前台Activity】已启动，准备执行地点规则提醒与解锁轻提醒逻辑")

        // 1) 启动地点规则前台服务（内部已处理地点规则开关 / 定位 / 距离100m判断等逻辑）
        try {
          val svc = Intent(appCtx, GeoForegroundService::class.java)
          if (Build.VERSION.SDK_INT >= 26) {
            appCtx.startForegroundService(svc)
          } else {
            appCtx.startService(svc)
          }
          logWithTime(appCtx, "【解锁前台Activity】已请求启动 GeoForegroundService（地点规则提醒）")
        } catch (t: Throwable) {
          logWithTime(appCtx, "【解锁前台Activity】启动 GeoForegroundService 异常：" + (t.message ?: "unknown"))
        }

        // 2) 触发解锁轻提醒（内部已处理开关 / 冷却时间 / 通知内容等逻辑）
        try {
          UnlockWorker.trigger(appCtx)
          logWithTime(appCtx, "【解锁前台Activity】已请求触发 UnlockWorker（解锁轻提醒）")
        } catch (t: Throwable) {
          logWithTime(appCtx, "【解锁前台Activity】触发 UnlockWorker 异常：" + (t.message ?: "unknown"))
        }
      } finally {
        try {
          logWithTime(appCtx, "【解锁前台Activity】所有解锁相关逻辑已调度完成，准备销毁透明 Activity（无论成功或失败）")
        } catch (_: Throwable) {
          // ignore
        }

        runOnUiThread {
          try {
            finish()
          } catch (_: Throwable) {
            // ignore
          }
        }
      }
    }
  }

  companion object {
    private fun logWithTime(ctx: Context, msg: String) {
      try {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
        val now = sdf.format(Date())
        DbRepo.log(ctx, null, "[$now] $msg")
      } catch (_: Throwable) {
        // 忽略日志异常，避免影响主流程
      }
    }
  }
}
