package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONObject
import com.example.quote_app.data.DbRepository
import com.example.quote_app.NativeSchedulerK
import com.example.quote_app.schedule.NextTriggerCalculator
import com.example.quote_app.biz.Biz
import com.example.quote_app.biz.Biz
import com.example.quote_app.schedule.NextTriggerCalculator

class NotifyWorker(appContext: Context, params: WorkerParameters)
  : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val id = inputData.getInt("id", 0)
    val payload = inputData.getString("payload") ?: "{}"
    val o = JSONObject(payload)
    val uid  = o.optString("uid", "")
val run  = o.optString("runKey", "")
var title = o.optString("title", "提醒")
var body  = o.optString("body",  "到点了")

            // 如果 payload 含 uid，则走完整 Java 业务
    if (uid.isNotEmpty()) {
      try {
        val enter = DbRepository.runGuardBegin(applicationContext, uid, runKey ?: "", "wm")
        if (!enter) return Result.success()
        val handled = try { Biz.run(applicationContext, uid) } finally { DbRepository.runGuardEnd(applicationContext, uid, runKey ?: "", "wm") }
        if (handled) {
                try { DbRepository.markLatestSuccess(applicationContext, uid) } catch (_: Throwable) {}
          // 续排（完全原生）
          val next = NextTriggerCalculator.compute(applicationContext, uid)
          if (next > System.currentTimeMillis()) {
            val payloadNext = org.json.JSONObject().apply { put("uid", uid); put("chan","am") }.toString()
            NativeSchedulerK.scheduleExactWmCompat(applicationContext, uid.hashCode(), next, payloadNext)
          }
          return Result.success()
        }
      } catch (t: Throwable) {
        return Result.retry()
      }
    }
    // 否则按原先兜底通知
    val ok = NotifyHelper.send(applicationContext, id, title, body, null)
    return if (ok) Result.success() else Result.failure()
}
}
