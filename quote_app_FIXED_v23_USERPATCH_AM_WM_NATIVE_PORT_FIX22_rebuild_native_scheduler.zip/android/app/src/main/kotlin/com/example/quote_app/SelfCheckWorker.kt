package com.example.quote_app

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.quote_app.data.DbRepository
import com.example.quote_app.NativeSchedulerK
import org.json.JSONObject

class SelfCheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            val fails = DbRepository.failsOfToday(applicationContext)
            val now = System.currentTimeMillis()
            for (uid in fails) {
                val runKey = java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US).format(java.util.Date(now))
                val id = (uid.hashCode() xor runKey.hashCode()) and 0x7fffffff
                val payload = JSONObject().apply {
                    put("uid", uid); put("runKey", runKey); put("chan", "normal"); put("attempt", 1)
                }.toString()
                NativeSchedulerK.scheduleWmFallback(applicationContext, id, now, payload)
                try { DbRepository.log(applicationContext, uid, "自检补发：已注册 WM 正常 uid="+uid+" run="+runKey) } catch (_: Throwable) {}
            }
            Result.success()
        } catch (t: Throwable) {
            // 记录失败日志，但返回成功以避免风暴
            try { 
                if (t.message != null) {
                    DbRepository.log(applicationContext, "", "自检执行失败: "+t.message) 
                }
            } catch (_: Throwable) {}
            Result.success()
        }
    }
}