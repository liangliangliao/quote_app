import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  /// 距离当前位置的估计距离，单位：米。允许为 null。
  final double? distance;

  const PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

/// 定位与附近地点相关的服务封装。
class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// Baidu 插件是否可用；如果发现 MissingPluginException，则标记为 false，
  /// 后续不再调用 Baidu 通道，避免重复报错。
  static bool _baiduPluginAvailable = true;

  /// 获取位置时希望的最大精度（半径）阈值，单位：米。
  static const double _desiredAccuracyMeters = 30.0;

  /// 最近一次成功定位所采用的提供者名称（'baidu' / 'system' / 'last_known'）。
  static String? lastProvider;

  /// Baidu SDK 优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 1. 先尝试 Baidu SDK。
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try {
          await DLog.i(
            'LocationService',
            '【定位】Baidu SDK 成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      } else if (bd != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，回退系统定位',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e');
      } catch (_) {}
    }

    // 2. 再尝试系统高精度。
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try {
          await DLog.i(
            'LocationService',
            '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      } else if (sys != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】系统定位异常（兜底分支）：$e');
      } catch (_) {}
    }

    // 3. 最后使用最近一次已知位置兜底。
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】Baidu / 系统 / lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

  /// 系统定位优先 -> Baidu 兜底 -> lastKnown 最终兜底。
  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1. 系统高精度。
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try {
          await DLog.i(
            'LocationService',
            '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      } else if (sys != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)，尝试 Baidu 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位异常（优先分支）：$e',
        );
      } catch (_) {}
    }

    // 2. Baidu 兜底（如果插件可用）。
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try {
          await DLog.i(
            'LocationService',
            '【定位】Baidu SDK 兜底成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      } else if (bd != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu SDK 兜底但精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】Baidu SDK 兜底异常：$e');
      } catch (_) {}
    }

    // 3. 最后使用最近一次已知位置兜底。
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】系统 / Baidu / lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

  /// 使用 geolocator 进行一次高精度系统定位，并做 15 秒超时控制。
  static Future<Position?> _getCurrentPositionHighAccuracy() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      try {
        await DLog.w('LocationService', '【定位】系统定位服务未开启');
      } catch (_) {}
      return null;
    }

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      try {
        await DLog.w('LocationService', '【定位】未授予定位权限');
      } catch (_) {}
      return null;
    }

    try {
      // 第一次：高精度 + 15s。
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      ).timeout(
        const Duration(seconds: 15),
        onTimeout: () => throw TimeoutException('getCurrentPosition timeout'),
      );
      return pos;
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统 getCurrentPosition 超时：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统 getCurrentPosition 异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

  /// 最近一次已知位置（geolocator 提供的兜底接口）。
  static Future<Position?> _getLastKnownPosition() async {
    try {
      final pos = await Geolocator.getLastKnownPosition();
      if (pos == null) {
        try {
          await DLog.w('LocationService', '【定位】lastKnown 位置为空');
        } catch (_) {}
        return null;
      }
      try {
        await DLog.i(
          'LocationService',
          '【定位】lastKnown 成功 acc=${pos.accuracy}m, lat=${pos.latitude}, lon=${pos.longitude}',
        );
      } catch (_) {}
      return pos;
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】lastKnown 调用异常：$e');
      } catch (_) {}
      return null;
    }
  }

  /// 通过原生 SysChannel + Baidu SDK 拉取一次性高精度位置。
  static Future<Position?> _baiduSdkLocationOnce() async {
    if (!_baiduPluginAvailable) return null;

    try {
      // 对应 SysChannel.kt 中的 "getBaiduLocationOnce"。
      final raw =
          await _sysCh.invokeMethod<Map<dynamic, dynamic>>('getBaiduLocationOnce');
      if (raw == null) {
        try {
          await DLog.w('LocationService', '【定位】Baidu SDK 返回为空');
        } catch (_) {}
        return null;
      }

      double? _toDouble(dynamic v) {
        if (v == null) return null;
        if (v is double) return v;
        if (v is int) return v.toDouble();
        return double.tryParse(v.toString());
      }

      final lat = _toDouble(raw['lat']);
      final lon = _toDouble(raw['lng']);
      if (lat == null || lon == null) {
        try {
          await DLog.w('LocationService', '【定位】Baidu SDK 返回缺少经纬度');
        } catch (_) {}
        return null;
      }

      final accuracy = _toDouble(raw['acc']) ?? 0;
      final speed = _toDouble(raw['speed']) ?? 0;
      final bearing = _toDouble(raw['bearing']) ?? 0;
      final timeMs = int.tryParse('${raw['time'] ?? ''}') ??
          DateTime.now().millisecondsSinceEpoch;
      final ts = DateTime.fromMillisecondsSinceEpoch(timeMs);

      final pos = Position(
        longitude: lon,
        latitude: lat,
        timestamp: ts,
        accuracy: accuracy,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: bearing,
        headingAccuracy: 0,
        speed: speed,
        speedAccuracy: 0,
        floor: null,
        isMocked: false,
      );

      try {
        await DLog.i(
          'LocationService',
          '【定位】Baidu SDK 原始位置 lat=${pos.latitude}, lon=${pos.longitude}, acc=${pos.accuracy}m',
        );
      } catch (_) {}

      return pos;
    } on MissingPluginException catch (e) {
      _baiduPluginAvailable = false;
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu 插件不可用，降级为系统定位：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】Baidu SDK 调用异常：$e');
      } catch (_) {}
      return null;
    }
  }

  /// 尝试做一次逆地理解析，仅用于写日志（附近地标）。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      final placemarks =
          await placemarkFromCoordinates(pos.latitude, pos.longitude);
      if (placemarks.isEmpty) {
        try {
          await DLog.w('LocationService', '【定位】逆地理结果为空');
        } catch (_) {}
        return;
      }
      final p = placemarks.first;
      final parts = <String>[
        p.country ?? '',
        p.administrativeArea ?? '',
        p.subAdministrativeArea ?? '',
        p.locality ?? '',
        p.subLocality ?? '',
        p.street ?? '',
        p.name ?? '',
      ].where((e) => e.trim().isNotEmpty).toList();
      final addr = parts.join('');
      try {
        await DLog.i(
          'LocationService',
          '【定位】附近地标：$addr (lat=${pos.latitude}, lon=${pos.longitude}, acc=${pos.accuracy}m)',
        );
      } catch (_) {}
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】逆地理获取附近地标失败：$e');
      } catch (_) {}
    }
  }

  /// 通过 geolocator 的位置流（getPositionStream）获取一次位置，配合超时和可选的强制 LocationManager。
  static Future<Position?> _getPositionByStreamOnce({
    required LocationAccuracy accuracy,
    Duration timeout = const Duration(seconds: 15),
    bool forceLocationManager = false,
  }) async {
    try {
      LocationSettings settings;
      if (Platform.isAndroid) {
        settings = AndroidSettings(
          accuracy: accuracy,
          forceLocationManager: forceLocationManager,
        );
      } else {
        settings = LocationSettings(accuracy: accuracy);
      }
      final stream = Geolocator.getPositionStream(locationSettings: settings);
      final pos = await stream.first.timeout(timeout);
      return pos;
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取超时：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

  /// 使用 Baidu 逆地理 API 获取附近 POI 列表。
  ///
  /// - [radiusMeters] 控制搜索半径；
  /// - [keyword] 当前实现没有直接用于过滤 Baidu 返回结果，但保留参数以便后续扩展；
  /// - [page] / [pageSize] 做简单的内存切片实现分页。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 0,
    int pageSize = 10,
  }) async {
    final ak = await ConfigDao().getBaiduAk();
    final uri = Uri.https(
      'api.map.baidu.com',
      '/reverse_geocoding/v3',
      <String, String>{
        'ak': ak,
        'output': 'json',
        'coordtype': 'wgs84ll',
        'location': '$latitude,$longitude',
        'radius': '$radiusMeters',
        // 返回周边 POI。
        'extensions_poi': '1',
      },
    );

    try {
      final resp = await http
          .get(uri)
          .timeout(const Duration(seconds: 10));
      if (resp.statusCode != 200) {
        try {
          await DLog.w(
            'LocationService',
            '【POI】Baidu 逆地理 HTTP 状态异常：${resp.statusCode}',
          );
        } catch (_) {}
        return <PoiItem>[];
      }

      final jsonMap = json.decode(resp.body) as Map<String, dynamic>;
      if (jsonMap['status'] != 0) {
        try {
          await DLog.w(
            'LocationService',
            '【POI】Baidu 逆地理返回错误状态：${jsonMap['status']}',
          );
        } catch (_) {}
        return <PoiItem>[];
      }

      final result = jsonMap['result'] as Map<String, dynamic>? ?? {};
      final pois = (result['pois'] as List<dynamic>? ?? <dynamic>[]);

      final items = <PoiItem>[];
      for (final raw in pois) {
        if (raw is! Map) continue;
        final name = (raw['name'] ?? '').toString();
        if (name.isEmpty) continue;
        final addr = (raw['addr'] ?? '').toString();
        final point = raw['point'] as Map<dynamic, dynamic>? ?? {};
        final lat = double.tryParse('${point['y'] ?? ''}');
        final lon = double.tryParse('${point['x'] ?? ''}');
        final dist = double.tryParse('${raw['distance'] ?? ''}');
        if (lat == null || lon == null) continue;

        items.add(
          PoiItem(
            name: name,
            address: addr.isEmpty ? null : addr,
            latitude: lat,
            longitude: lon,
            distance: dist,
          ),
        );
      }

      // 简单分页：按 page / pageSize 切片。
      final start = page * pageSize;
      if (start >= items.length) return <PoiItem>[];
      final end = (start + pageSize).clamp(0, items.length);
      return items.sublist(start, end);
    } catch (e) {
      try {
        await DLog.w('LocationService', '【POI】Baidu 逆地理调用异常：$e');
      } catch (_) {}
      return <PoiItem>[];
    }
  }

  /// 使用系统 geocoding 做一个“当前位置”的粗略 POI，作为兜底。
  static Future<List<PoiItem>> fetchNearbyPoisSystem({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 0,
    int pageSize = 10,
  }) async {
    try {
      final placemarks =
          await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isEmpty) {
        return <PoiItem>[];
      }
      final p = placemarks.first;
      final parts = <String>[
        p.country ?? '',
        p.administrativeArea ?? '',
        p.subAdministrativeArea ?? '',
        p.locality ?? '',
        p.subLocality ?? '',
        p.street ?? '',
        p.name ?? '',
      ].where((e) => e.trim().isNotEmpty).toList();
      final addr = parts.join('');

      final name =
          keyword.isNotEmpty ? '$keyword附近' : (p.name ?? '当前位置');

      final item = PoiItem(
        name: name,
        address: addr.isEmpty ? null : addr,
        latitude: latitude,
        longitude: longitude,
        distance: 0,
      );
      return <PoiItem>[item];
    } catch (e) {
      try {
        await DLog.w('LocationService', '【POI】系统逆地理获取失败：$e');
      } catch (_) {}
      return <PoiItem>[];
    }
  }
}
