import 'dart:ui';

class AppGlobals {
  static RootIsolateToken? rootIsolateToken;
}
