
import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  final String endpoint; // e.g., https://api.openai.com/v1/chat/completions
  final String apiKey;
  final String model;

  OpenAIService({required this.endpoint, required this.apiKey, required this.model});

  Future<String> generateQuote(String prompt) async {
    // Basic chat completions payload for text-only
    final uri = Uri.parse(endpoint);
    final headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({
      'model': model,
      'messages': [
        {'role': 'system', 'content': '你是一个返回名人名言的助手，只返回一句完整的名人名言，不要加其它解释。'},
        {'role': 'user', 'content': prompt}
      ],
      'temperature': 0.7,
      'max_tokens': 200
    });
    final resp = await http.post(uri, headers: headers, body: body);
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      final data = jsonDecode(resp.body);
      // try parse OpenAI format
      final choices = data['choices'];
      if (choices is List && choices.isNotEmpty) {
        final msg = choices.first['message'];
        final content = (msg is Map) ? (msg['content'] ?? '') : '';
        return content.toString().trim();
      }
      // fallback to anthropic-like 'content'
      if (data['content'] != null) return data['content'].toString().trim();
      throw Exception('未知返回结构');
    } else {
      throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
    }
  }
}
