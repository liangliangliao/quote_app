import 'dart:convert';
import 'package:flutter/services.dart';

class NativeScheduler {
  static const _ch = MethodChannel('quote/native_scheduler');

  static Future<void> ensureChannel() async {
    await _ch.invokeMethod('ensureChannel');
  }

  static Future<bool> hasExactAlarmPermission() async {
    return await _ch.invokeMethod('hasExactAlarmPermission') as bool;
  }

  static Future<void> requestExactAlarmPermission() async {
    await _ch.invokeMethod('requestExactAlarmPermission');
  }

  static Future<bool> scheduleAfter({
    required int id,
    required int epochMs,
    required Map<String, dynamic> payload,
  }) async {
    final ok = await _ch.invokeMethod('scheduleAfter', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload),
    });
    return ok == true;
  }

  static Future<bool> scheduleFallback({
    required String unique,
    required int delayMs,
    required Map<String, dynamic> payload,
  }) async {
    final ok = await _ch.invokeMethod('scheduleFallback', {
      'unique': unique,
      'delayMs': delayMs,
      'payload': jsonEncode(payload),
    });
    return ok == true;
  }

  static Future<void> cancelFallback(String unique) async {
    await _ch.invokeMethod('cancelFallback', {'unique': unique});
  }
}


  static Future<bool> scheduleExactAt({
    required int id,
    required int epochMs,
    required Map<String, dynamic> payload,
  }) async {
    // Backward-compatible alias to 'scheduleAfter'
    final ok = await _ch.invokeMethod('scheduleExactAt', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload),
    });
    return ok == true;
  }

  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
  }
