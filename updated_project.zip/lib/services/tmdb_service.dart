import 'dart:convert';
import 'package:http/http.dart' as http;

/// A small helper service to fetch movie data from The Movie Database (TMDb).
///
/// The service requires a read‑access token which should be provided by
/// the caller. Each request sets the `Authorization` header to
/// `Bearer <token>` as recommended by TMDb. All requests include
/// `language=zh-CN` so that the returned title and overview fields are
/// localized to Simplified Chinese when available.
///
/// If a request fails with a non‑200 status code an [Exception] is thrown
/// containing the status code and response body. Callers should catch
/// exceptions and surface error messages appropriately in the UI.
class TMDbService {
  /// The v4 read access token obtained from the TMDb developer console.
  final String token;

  TMDbService({required this.token});

  static const String _baseUrl = 'https://api.themoviedb.org/3';
  static const String _imageBase = 'https://image.tmdb.org/t/p/';

  /// Performs an HTTP GET request to the given [path] with [params].
  /// Returns the decoded JSON as a `Map<String, dynamic>`.
  Future<Map<String, dynamic>> _get(String path, Map<String, String> params) async {
    final uri = Uri.parse('$_baseUrl$path').replace(queryParameters: params);
    final headers = {
      'Authorization': 'Bearer $token',
      'Accept': 'application/json',
    };
    final response = await http.get(uri, headers: headers);
    if (response.statusCode != 200) {
      throw Exception('TMDb API error: ${response.statusCode}, ${response.body}');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  /// Fetches the discovery endpoint sorted by vote average descending. A
  /// [voteCount] threshold filters out movies with too few votes. See
  /// https://developer.themoviedb.org/reference/discover-movie for details.
  Future<Map<String, dynamic>> discoverMovies({required int page, int voteCount = 5000}) async {
    return _get('/discover/movie', {
      'sort_by': 'vote_average.desc',
      'vote_count.gte': voteCount.toString(),
      'language': 'zh-CN',
      'page': page.toString(),
    });
  }

  /// Fetches the official Top Rated movies list. See
  /// https://developer.themoviedb.org/reference/movie-top-rated-list.
  Future<Map<String, dynamic>> topRatedMovies({required int page}) async {
    return _get('/movie/top_rated', {
      'language': 'zh-CN',
      'page': page.toString(),
    });
  }

  /// Fetches the popular movies list. See
  /// https://developer.themoviedb.org/reference/movie-popular-list.
  Future<Map<String, dynamic>> popularMovies({required int page}) async {
    return _get('/movie/popular', {
      'language': 'zh-CN',
      'page': page.toString(),
    });
  }

  /// Fetches the now playing movies list. See
  /// https://developer.themoviedb.org/reference/movie-now-playing-list.
  Future<Map<String, dynamic>> nowPlayingMovies({required int page}) async {
    return _get('/movie/now_playing', {
      'language': 'zh-CN',
      'page': page.toString(),
    });
  }

  /// Fetches the upcoming movies list. See
  /// https://developer.themoviedb.org/reference/movie-upcoming-list.
  Future<Map<String, dynamic>> upcomingMovies({required int page}) async {
    return _get('/movie/upcoming', {
      'language': 'zh-CN',
      'page': page.toString(),
    });
  }

  /// Builds a full poster URL using the secure TMDb image base and the
  /// provided [path]. If [path] is null or empty this returns null.
  static String? buildPosterUrl(String? path, {String size = 'w342'}) {
    if (path == null || path.isEmpty) return null;
    return '$_imageBase$size$path';
  }
}