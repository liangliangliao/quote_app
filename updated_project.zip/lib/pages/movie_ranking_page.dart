import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import '../services/tmdb_service.dart';
import '../data/dao.dart';
import '../data/movie_favorite_dao.dart';
import 'movie_favorites_page.dart';

/// A page displaying multiple movie lists from TMDb as tabs. Each tab
/// corresponds to a different endpoint: high‑score (discover with vote
/// threshold), Top Rated, Popular, Now Playing and Upcoming. Lists are
/// loaded lazily and support infinite scrolling. Users can favourite
/// movies locally; favourites are indicated with a filled heart icon.
class MovieRankingPage extends StatefulWidget {
  const MovieRankingPage({super.key});

  @override
  State<MovieRankingPage> createState() => _MovieRankingPageState();
}

class _MovieRankingPageState extends State<MovieRankingPage> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('电影榜单', style: TextStyle(color: Colors.black87)),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: Colors.black87,
          indicatorColor: Colors.black87,
          tabs: const [
            Tab(text: '高分榜'),
            Tab(text: 'Top Rated'),
            Tab(text: '热门'),
            Tab(text: '上映中'),
            Tab(text: '即将上映'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite_outline),
            onPressed: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (_) => const MovieFavoritesPage(),
                ),
              );
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _MovieListTab(category: _MovieCategory.highScore),
          _MovieListTab(category: _MovieCategory.topRated),
          _MovieListTab(category: _MovieCategory.popular),
          _MovieListTab(category: _MovieCategory.nowPlaying),
          _MovieListTab(category: _MovieCategory.upcoming),
        ],
      ),
    );
  }
}

/// Enum describing the different movie list categories.
enum _MovieCategory { highScore, topRated, popular, nowPlaying, upcoming }

/// A list widget that loads and displays movies for a specific
/// [_MovieCategory]. The first tab uses a vote count threshold of 5000 to
/// approximate a high‑score ranking; other tabs call TMDb endpoints
/// directly. Movies are fetched page by page; when the user scrolls to
/// the bottom of the list the next page is loaded.
class _MovieListTab extends StatefulWidget {
  final _MovieCategory category;
  const _MovieListTab({required this.category});

  @override
  State<_MovieListTab> createState() => _MovieListTabState();
}

class _MovieListTabState extends State<_MovieListTab> {
  final List<Map<String, dynamic>> _movies = [];
  final ScrollController _scrollController = ScrollController();
  int _currentPage = 1;
  int _totalPages = 1;
  bool _loading = false;
  bool _initialised = false;
  late MovieFavoriteDao _favDao;
  Set<int> _favIds = {};
  String _token = '';

  @override
  void initState() {
    super.initState();
    _favDao = MovieFavoriteDao();
    _scrollController.addListener(_onScroll);
    _init();
  }

  Future<void> _init() async {
    // Load the TMDb token and initial favourite ids once.
    final cfgDao = ConfigDao();
    try {
      final token = await cfgDao.getMovieToken();
      _token = token;
    } catch (_) {
      _token = '';
    }
    try {
      _favIds = await _favDao.allFavoriteIds();
    } catch (_) {
      _favIds = {};
    }
    // Load the first page of movies.
    await _loadMore();
    _initialised = true;
  }

  void _onScroll() {
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 200) {
      if (!_loading && _currentPage < _totalPages) {
        _loadMore();
      }
    }
  }

  Future<void> _loadMore() async {
    if (_loading) return;
    setState(() {
      _loading = true;
    });
    try {
      final service = TMDbService(token: _token);
      Map<String, dynamic> data;
      switch (widget.category) {
        case _MovieCategory.highScore:
          data = await service.discoverMovies(page: _currentPage, voteCount: 5000);
          break;
        case _MovieCategory.topRated:
          data = await service.topRatedMovies(page: _currentPage);
          break;
        case _MovieCategory.popular:
          data = await service.popularMovies(page: _currentPage);
          break;
        case _MovieCategory.nowPlaying:
          data = await service.nowPlayingMovies(page: _currentPage);
          break;
        case _MovieCategory.upcoming:
          data = await service.upcomingMovies(page: _currentPage);
          break;
      }
      final results = data['results'];
      if (results is List) {
        setState(() {
          _movies.addAll(results.cast<Map<String, dynamic>>());
          _currentPage = (data['page'] as int?) ?? _currentPage;
          _totalPages = (data['total_pages'] as int?) ?? _totalPages;
        });
        _currentPage += 1;
      }
    } catch (e) {
      // ignore or show error
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  Future<void> _toggleFavorite(Map<String, dynamic> movie) async {
    final id = movie['id'];
    if (id is! int) return;
    final isFav = _favIds.contains(id);
    if (isFav) {
      await _favDao.deleteByTmdbId(id);
      setState(() {
        _favIds.remove(id);
      });
    } else {
      // Build map for insertion
      final data = {
        'tmdb_id': id,
        'title': (movie['title'] ?? movie['name'] ?? '').toString(),
        'overview': (movie['overview'] ?? '').toString(),
        'poster_path': movie['poster_path'],
        'backdrop_path': movie['backdrop_path'],
        'vote_average': movie['vote_average'],
        'vote_count': movie['vote_count'],
        'release_date': (movie['release_date'] ?? movie['first_air_date'] ?? '').toString(),
        'raw_json': jsonEncode(movie),
      };
      await _favDao.insert(data);
      setState(() {
        _favIds.add(id);
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialised) {
      return const Center(child: CircularProgressIndicator());
    }
    return RefreshIndicator(
      onRefresh: () async {
        // Reset pagination and reload
        setState(() {
          _movies.clear();
          _currentPage = 1;
          _totalPages = 1;
        });
        await _init();
      },
      child: ListView.builder(
        controller: _scrollController,
        itemCount: _movies.length + (_loading && _currentPage <= _totalPages ? 1 : 0),
        itemBuilder: (context, index) {
          if (index >= _movies.length) {
            // loading indicator at bottom
            return const Padding(
              padding: EdgeInsets.all(16.0),
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final movie = _movies[index];
          final id = movie['id'] as int?;
          final fav = id != null && _favIds.contains(id);
          final title = (movie['title'] ?? movie['name'] ?? '').toString();
          final overview = (movie['overview'] ?? '').toString();
          final releaseDate = (movie['release_date'] ?? movie['first_air_date'] ?? '').toString();
          final voteAverage = movie['vote_average'];
          final voteCount = movie['vote_count'];
          final posterUrl = TMDbService.buildPosterUrl(movie['poster_path'], size: 'w342');
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            child: InkWell(
              onTap: () {},
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Poster image
                    if (posterUrl != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: Image.network(
                          posterUrl,
                          width: 80,
                          height: 120,
                          fit: BoxFit.cover,
                        ),
                      )
                    else
                      Container(
                        width: 80,
                        height: 120,
                        color: Colors.grey.shade300,
                        alignment: Alignment.center,
                        child: const Icon(Icons.movie, size: 40, color: Colors.grey),
                      ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            overview,
                            style: const TextStyle(fontSize: 13, color: Colors.black54),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              if (releaseDate.isNotEmpty) ...[
                                const Icon(Icons.calendar_today, size: 14, color: Colors.black45),
                                const SizedBox(width: 4),
                                Text(releaseDate, style: const TextStyle(fontSize: 12, color: Colors.black45)),
                                const SizedBox(width: 12),
                              ],
                              const Icon(Icons.star, size: 14, color: Colors.amber),
                              const SizedBox(width: 4),
                              Text(
                                (voteAverage != null ? (voteAverage as num).toStringAsFixed(1) : '-') +
                                    ' (${voteCount ?? '-'})',
                                style: const TextStyle(fontSize: 12, color: Colors.black45),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(fav ? Icons.favorite : Icons.favorite_border, color: fav ? Colors.red : Colors.grey),
                      onPressed: () => _toggleFavorite(movie),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}