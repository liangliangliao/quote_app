package com.example.quote_app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*

object NativeSchedulerK {

  // ------------ helpers ------------
  private const val CHANNEL_ID = "am_exact_channel"
  private const val UNIQUE_WORK_PREFIX = "wm_once_"

  private fun ensureChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = ctx.getSystemService(NotificationManager::class.java)
      if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        val ch = NotificationChannel(CHANNEL_ID, "Exact Alarm", NotificationManager.IMPORTANCE_HIGH)
        nm.createNotificationChannel(ch)
      }
    }
  }

  private fun pendingIntent(ctx: Context, id: Int, payload: String?): PendingIntent {
    val intent = Intent(ctx, AlarmReceiver::class.java).apply {
      action = "ALARM_FIRE"
      putExtra("id", id)
      if (payload != null) putExtra("payload", payload)
    }
    return PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE)
  }

  private fun uidFromPayloadForLog(payload: String?): String? {
    if (payload == null) return null
    return try {
      val key = ""uid":""
      val i = payload.indexOf(key)
      if (i < 0) null else {
        val s = i + key.length
        val e = payload.indexOf('"', s)
        if (e > s) payload.substring(s, e) else null
      }
    } catch (_: Throwable) { null }
  }
