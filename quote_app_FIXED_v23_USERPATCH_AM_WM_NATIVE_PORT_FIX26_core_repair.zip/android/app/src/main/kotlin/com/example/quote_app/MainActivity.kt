package com.example.quote_app

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
  private val CHANNEL = "native.scheduler"

  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
          "requestExactPermission" -> {
            val ok = NativeSchedulerK.requestExactPermission(this)
            result.success(ok)
          }
          "scheduleExactAt" -> {
            val id = (call.argument<Int>("id") ?: 0)
            val epochMs = (call.argument<Long>("epochMs") ?: 0L)
            val payload = call.argument<String>("payload")
            val ok = NativeSchedulerK.scheduleExactAt(this, id, epochMs, payload)
            result.success(ok)
          }
          "scheduleWmFallback" -> {
            val id = (call.argument<Int>("id") ?: 0)
            val epochMs = (call.argument<Long>("epochMs") ?: 0L)
            val payload = call.argument<String>("payload") ?: "{}"
            NativeSchedulerK.scheduleWmFallback(this, id, epochMs, payload)
            result.success(true)
          }
          "cancel" -> {
            val id = (call.argument<Int>("id") ?: 0)
            NativeSchedulerK.cancel(this, id)
            result.success(null)
          }
          "cancelAll" -> {
            NativeSchedulerK.cancelAll(this)
            result.success(null)
          }
          "scheduleSelfCheck" -> {
            val minutes = call.argument<Int>("minutes") ?: 15
            val ok = NativeSchedulerK.scheduleSelfCheck(this, minutes)
            result.success(ok)
          }
          "request_notification_permission" -> {
            result.success(true)
          }
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
  }
}
