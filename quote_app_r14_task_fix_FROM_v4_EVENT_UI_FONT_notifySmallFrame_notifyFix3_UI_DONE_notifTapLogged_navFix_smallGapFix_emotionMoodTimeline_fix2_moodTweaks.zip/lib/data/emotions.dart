import 'dart:math';
import 'package:sqflite/sqflite.dart';

import 'db.dart';

/// 单个情绪表情定义
class EmojiItem {
  final String char;
  final String name;
  final List<String> tags;
  const EmojiItem({
    required this.char,
    required this.name,
    required this.tags,
  });
}

/// 18 个情绪表情条目
const List<EmojiItem> unicornEmotions = [
  EmojiItem(
    char: "😄",
    name: "开心",
    tags: ["开心", "高兴", "快乐", "喜悦"],
  ),
  EmojiItem(
    char: "😣",
    name: "痛苦",
    tags: ["痛苦", "折磨", "难熬"],
  ),
  EmojiItem(
    char: "😩",
    name: "累",
    tags: ["疲惫", "累", "困", "疲劳"],
  ),
  EmojiItem(
    char: "😕",
    name: "迷茫",
    tags: ["迷茫", "困惑", "疑惑", "懵"],
  ),
  EmojiItem(
    char: "😎",
    name: "自信",
    tags: ["自信", "酷", "稳", "从容"],
  ),
  EmojiItem(
    char: "😔",
    name: "自卑",
    tags: ["自卑", "沮丧", "低落"],
  ),
  EmojiItem(
    char: "😰",
    name: "焦虑",
    tags: ["焦虑", "紧张", "担心", "不安"],
  ),
  EmojiItem(
    char: "😢",
    name: "难过",
    tags: ["难过", "伤心", "悲伤", "委屈"],
  ),
  EmojiItem(
    char: "😡",
    name: "愤怒",
    tags: ["愤怒", "生气", "怒火", "暴躁"],
  ),
  EmojiItem(
    char: "😐",
    name: "一般",
    tags: ["一般", "平淡", "还好", "普通"],
  ),
  EmojiItem(
    char: "😒",
    name: "无聊",
    tags: ["无聊", "烦躁", "厌倦"],
  ),
  EmojiItem(
    char: "❤️",
    name: "爱",
    tags: ["爱", "喜欢", "热爱", "心动"],
  ),
  EmojiItem(
    char: "💢",
    name: "恨",
    tags: ["恨", "憎恨", "怨", "怒"],
  ),
  EmojiItem(
    char: "😲",
    name: "惊讶",
    tags: ["惊讶", "吃惊", "震惊", "意外"],
  ),
  EmojiItem(
    char: "🤢",
    name: "厌恶",
    tags: ["厌恶", "恶心", "反感"],
  ),
  EmojiItem(
    char: "🤔",
    name: "好奇",
    tags: ["好奇", "思考", "疑问", "想法"],
  ),
  EmojiItem(
    char: "😳",
    name: "羞愧",
    tags: ["羞愧", "脸红", "害羞", "尴尬"],
  ),
  EmojiItem(
    char: "😱",
    name: "恐惧",
    tags: ["恐惧", "害怕", "惊恐", "恐慌"],
  ),
];

String _two(int v) => v.toString().padLeft(2, '0');

String _nowString() {
  final now = DateTime.now();
  return "${now.year}-${_two(now.month)}-${_two(now.day)} "
         "${_two(now.hour)}:${_two(now.minute)}:${_two(now.second)}";
}

String _uid() {
  final rand = Random();
  final ts = DateTime.now().microsecondsSinceEpoch;
  final r = rand.nextInt(0xFFFFFF);
  return "emo_${ts.toRadixString(16)}_${r.toRadixString(16)}";
}

/// 情绪记录 DAO：负责 emotions 表的增删查
class EmotionDao {
  Future<int> insert({
    required String emojiChar,
    required String emojiName,
    required List<String> emojiTags,
    required String behavior,
    required String triggerEvent,
    required String thought,
  }) async {
    final db = await AppDatabase.instance();
    final tagsStr = emojiTags.join(',');
    final nowStr = _nowString();
    final uid = _uid();
    return db.insert('emotions', {
      'emotion_uid': uid,
      'emoji_char': emojiChar,
      'emoji_name': emojiName,
      'emoji_tags': tagsStr,
      'behavior': behavior,
      'trigger_event': triggerEvent,
      'thought': thought,
      'inserted_at': nowStr,
    });
  }

  /// 获取当天最近一条情绪记录（按 inserted_at 倒序）
  Future<Map<String, dynamic>?> latestToday() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final today = "${now.year}-${_two(now.month)}-${_two(now.day)}";
    final rows = await db.query(
      'emotions',
      where: "substr(inserted_at,1,10)=?",
      whereArgs: [today],
      orderBy: "inserted_at DESC",
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// 获取当天所有情绪记录，按时间先后顺序排列
  Future<List<Map<String, dynamic>>> listTodayOrdered() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final today = "${now.year}-${_two(now.month)}-${_two(now.day)}";
    final rows = await db.query(
      'emotions',
      where: "substr(inserted_at,1,10)=?",
      whereArgs: [today],
      orderBy: "inserted_at ASC",
    );
    return rows;
  }
}
