package com.example.quote_app;

import android.app.Application;

public class App extends Application { }