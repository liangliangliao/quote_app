package com.example.quote_app.data

import android.content.Context

// Lightweight wrapper to make Kotlin compile even if Java source ordering prevents symbol resolution.
// Delegates to the Java DbRepository at runtime; failures are swallowed to keep app functional.
object DbRepo {
  @JvmStatic fun log(ctx: Context, uid: String, detail: String) {
    try { DbRepository.log(ctx, uid, detail) } catch (_: Throwable) {}
  }
  @JvmStatic fun runGuardBegin(ctx: Context, uid: String, runKey: String, src: String): Boolean {
    return try { DbRepository.runGuardBegin(ctx, uid, runKey, src) } catch (_: Throwable) { true }
  }
  @JvmStatic fun runGuardEnd(ctx: Context, uid: String, runKey: String, src: String) {
    try { DbRepository.runGuardEnd(ctx, uid, runKey, src) } catch (_: Throwable) {}
  }
  @JvmStatic fun markLatestSuccess(ctx: Context, uid: String) {
    try { DbRepository.markLatestSuccess(ctx, uid) } catch (_: Throwable) {}
  }
}
