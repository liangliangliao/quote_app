import 'package:flutter/material.dart';
import '../data/dao.dart';
import 'package:intl/intl.dart';
import '../utils/debug_logger.dart';
import '../services/native_guard.dart';

class LogsPage extends StatefulWidget {
  const LogsPage({super.key});
  @override
  State<LogsPage> createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> {
  final _dao = LogDao();
  final _scroll = ScrollController();
  final List<Map<String, dynamic>> _items = [];
  int _offset = 0;
  bool _done = false;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    // 注册日志刷新事件监听
    SimpleBus.logsTick.addListener(_onBus);
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 &&
          !_loading &&
          !_done) {
        _loadMore();
      }
    });
  }

  /// 当接收到日志页刷新通知时，清空现有列表并重新加载最新数据
  void _onBus() {
    if (!mounted) return;
    setState(() {
      _items.clear();
      _offset = 0;
      _done = false;
    });
    _loadMore();
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 50, offset: _offset);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState(() {});
    if (rows.length < 50) _done = true;
  }

  String _fmt(String? s) {
    if (s == null || s.isEmpty) return '';
    try {
      // 提取形如 “yyyy-MM-dd HH:mm[:ss]” 的子串
      final match =
          RegExp(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}(?::\d{2})?').firstMatch(s);
      if (match == null) return s;
      final raw = match.group(0)!;
      final srcPattern =
          raw.length == 19 ? 'yyyy-MM-dd HH:mm:ss' : 'yyyy-MM-dd HH:mm';
      final dt = DateFormat(srcPattern).parseLoose(raw);
      return DateFormat('yyyy-MM-dd HH:mm').format(dt);
    } catch (e, sTrace) {
      DLog.e('pages/logs_page.dart', 'catch: ' + e.toString());
      return s ?? '';
    }
  }

  Future<void> _confirmClearLogs() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('清空日志'),
          content: const Text('确定要删除所有日志吗？'),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('取消')),
            TextButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: const Text('确认')),
          ],
        );
      },
    );
    if (ok == true) {
      await _dao.clearAll();
      if (!mounted) return;
      setState(() {
        _items.clear();
        _offset = 0;
        _done = false;
      });
      await _loadMore();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ListView.builder(
          controller: _scroll,
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + kToolbarHeight),
          itemCount: _items.length,
          itemBuilder: (_, i) {
            final e = _items[i];
            final detail = (e['detail'] ?? '') as String;
            final isErr = detail.contains('错误');
            final isOk = detail.contains('成功');
            final style = TextStyle(
              color: isErr
                  ? Colors.red
                  : isOk
                      ? Colors.green
                      : null,
              fontWeight: (isErr || isOk) ? FontWeight.bold : null,
            );
            return ListTile(
              leading: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    (e['task_name'] ?? '') as String,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(_fmt(e['task_start_time'] as String?)),
                ],
              ),
              title: Text(detail, style: style),
            );
          },
        ),
        Positioned(left:0,right:0,top:0, child: Container(height: MediaQuery.of(context).padding.top + kToolbarHeight, color: Colors.white)),
        Positioned(right:12, top: MediaQuery.of(context).padding.top + 8, child: IconButton(onPressed: _confirmClearLogs, icon: const Icon(Icons.delete))),
        
      ],
    );
  }

  @override
  void dispose() {
    // 移除日志刷新监听并释放 ScrollController
    SimpleBus.logsTick.removeListener(_onBus);
    _scroll.dispose();
    super.dispose();
  }
}