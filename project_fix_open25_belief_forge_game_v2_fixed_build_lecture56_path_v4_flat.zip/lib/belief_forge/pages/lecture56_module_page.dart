import 'dart:convert';

import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../model/lecture56_modules.dart';
import '../model/lecture56_playgrounds.dart';
import '../model/lecture56_quiz.dart';
import '../widgets/concept_playground_wizard.dart';
import '../widgets/game_feedback.dart';

/// A single module page in the Lecture 5–6 belief path.
class Lecture56ModulePage extends StatefulWidget {
  final String moduleId;
  const Lecture56ModulePage({super.key, required this.moduleId});

  @override
  State<Lecture56ModulePage> createState() => _Lecture56ModulePageState();
}

class _Lecture56ModulePageState extends State<Lecture56ModulePage> {
  final _dao = BeliefForgeDao();

  bool _loading = true;
  int _stars = 0; // 0..3
  bool _hasActionCard = false;
  bool _hasQuizPassed = false;
  bool _hasCommit = false;
  bool _rewardClaimed = false;
  bool _advancedOn = false;

  // quiz
  int? _quizPick;
  bool? _quizLastCorrect;

  // commit
  String _commitWhen = 'today';
  String _commitSlot = 'morning';
  String _commitMethod = 'solo';
  final TextEditingController _commitNoteCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _dao.ensureSchema();
    _loadProgress();
  }

  @override
  void dispose() {
    _commitNoteCtrl.dispose();
    super.dispose();
  }

  Map<String, dynamic>? _decodeExtra(String raw) {
    if (raw.isEmpty) return null;
    try {
      final v = jsonDecode(raw);
      if (v is Map) {
        return Map<String, dynamic>.from(v as Map);
      }
    } catch (_) {}
    return null;
  }

  Future<void> _loadProgress() async {
    setState(() => _loading = true);
    await _dao.ensureSchema();
    final rows = await _dao.listRunsForConcept(widget.moduleId, runType: 'module', limit: 600);

    bool hasAction = false;
    bool hasQuiz = false;
    bool hasCommit = false;
    bool rewardClaimed = false;

    for (final r in rows) {
      final extraRaw = (r['extra_json'] ?? '').toString();
      final extra = _decodeExtra(extraRaw);
      final t = (extra?['type'] ?? '').toString();
      if (t == 'action_card') hasAction = true;
      if (t == 'module_quiz') hasQuiz = true;
      if (t == 'module_commit') hasCommit = true;
      if (t == 'module_complete') rewardClaimed = true;
      if ((r['note'] ?? '').toString() == 'module_complete') rewardClaimed = true;
    }

    // Backward compatibility: older builds marked completion without the new
    // 3★ checkpoints. If a user has already claimed the module completion,
    // we treat the module as 3★ finished.
    if (rewardClaimed) {
      hasAction = true;
      hasQuiz = true;
      hasCommit = true;
    }

    final stars = (hasAction ? 1 : 0) + (hasQuiz ? 1 : 0) + (hasCommit ? 1 : 0);
    if (!mounted) return;
    setState(() {
      _stars = stars;
      _hasActionCard = hasAction;
      _hasQuizPassed = hasQuiz;
      _hasCommit = hasCommit;
      _rewardClaimed = rewardClaimed;
      if (stars < 3) _advancedOn = false;
      _loading = false;
    });
  }

  Future<void> _submitQuiz(Lecture56Module m, Lecture56QuizItem quiz) async {
    if (_quizPick == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('先选一个答案')));
      return;
    }
    final correct = _quizPick == quiz.correctIndex;
    setState(() => _quizLastCorrect = correct);
    if (!correct) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('再想想：${quiz.explanation}')));
      return;
    }
    if (_hasQuizPassed) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('你已经通过本关小测验 ✅')));
      return;
    }

    await _dao.addRun(
      conceptId: m.id,
      conceptTitle: '第${m.index}关·${m.title}',
      runType: 'module',
      score: 1,
      note: 'quiz_pass',
      extra: {
        'type': 'module_quiz',
        'module_id': m.id,
        'module_index': m.index,
        'picked': _quizPick,
        'correct': true,
      },
    );
    final award = await BeliefGameService.instance.awardXp(xp: 8, reason: 'module_quiz');
    await BeliefGameService.instance.unlockBadge(
      'badge_first_quiz',
      extra: const {
        'title': '第一次通过小测验',
        'desc': '你用一次选择题把概念从“看过”变成“理解”。',
      },
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('小测验通过 ✅（+8 XP）')));
    await showXpFeedback(context, award: award);
    await _loadProgress();
  }

  Future<void> _submitCommit(Lecture56Module m) async {
    if (_hasCommit) {
      // allow re-commit (keep history), but提醒用户这是覆盖式升级
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('你已提交过承诺：再次提交会生成一条新的承诺记录')));
    }
    await _dao.addRun(
      conceptId: m.id,
      conceptTitle: '第${m.index}关·${m.title}',
      runType: 'module',
      note: 'commit',
      extra: {
        'type': 'module_commit',
        'module_id': m.id,
        'module_index': m.index,
        'when': _commitWhen,
        'slot': _commitSlot,
        'method': _commitMethod,
        'note': _commitNoteCtrl.text.trim(),
      },
    );
    final award = await BeliefGameService.instance.awardXp(xp: 8, reason: 'module_commit');
    await BeliefGameService.instance.unlockBadge(
      'badge_first_commit',
      extra: const {
        'title': '第一次提交承诺',
        'desc': '你把“想做”变成了具体的时间与方式。',
      },
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('承诺已提交 ✅（+8 XP）')));
    await showXpFeedback(context, award: award);
    await _loadProgress();
  }

  Future<void> _claimReward(Lecture56Module m) async {
    if (_rewardClaimed) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('本关奖励已领取 ✅')));
      return;
    }
    if (_stars < 3) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('需要先完成 3★：行动卡 + 小测验 + 承诺')));
      return;
    }
    await _dao.addRun(
      conceptId: m.id,
      conceptTitle: '第${m.index}关·${m.title}',
      runType: 'module',
      note: 'module_complete',
      extra: {
        'type': 'module_complete',
        'module_id': m.id,
        'module_index': m.index,
        'stars': 3,
      },
    );
    final award = await BeliefGameService.instance.awardXp(xp: 10, reason: 'module_complete');
    await BeliefGameService.instance.unlockBadge(
      'badge_path_lecture56_${m.index}',
      extra: {
        'title': '通关：${m.title}',
        'desc': '你完成了 Lecture 5–6 路径的第${m.index}关（3★）。',
      },
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('通关奖励已领取 ✅（+10 XP）')));
    await showXpFeedback(context, award: award);
    await _loadProgress();
  }

  @override
  Widget build(BuildContext context) {
    final m = findLecture56Module(widget.moduleId);
    if (m == null) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text('课程关卡'),
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
        ),
        body: const Center(child: Text('找不到该关卡（moduleId 不存在）')),
      );
    }

    if (_loading) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text('${m.index.toString().padLeft(2, '0')} · ${m.title}'),
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final unlockedAdvanced = _stars >= 3;
    final cfg = getLecture56PlaygroundConfig(m.id, advanced: unlockedAdvanced && _advancedOn);
    final quiz = getLecture56Quiz(m.id);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('${m.index.toString().padLeft(2, '0')} · ${m.title}'),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
        children: [
          Text(m.lecture, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 10),

          _ProgressCard(
            stars: _stars,
            hasActionCard: _hasActionCard,
            hasQuiz: _hasQuizPassed,
            hasCommit: _hasCommit,
            rewardClaimed: _rewardClaimed,
            unlockedAdvanced: unlockedAdvanced,
            advancedOn: _advancedOn,
            onToggleAdvanced: (v) => setState(() => _advancedOn = v),
          ),

          const SizedBox(height: 12),
          _InfoCard(title: '原课钩子（原文/原例）', body: '${m.hookQuote}\n\n${m.hookCase}'),
          const SizedBox(height: 12),
          _InfoCard(title: '你刚刚经历了什么（解释）', body: m.explanation),
          const SizedBox(height: 12),
          _InfoCard(title: '为什么会这样（机制）', body: m.why),
          const SizedBox(height: 12),
          _ChecklistCard(title: '你可以怎么做（步骤）', items: m.howTo),
          const SizedBox(height: 12),
          _InfoCard(title: '日常案例（照着做）', body: m.caseStudy),

          const SizedBox(height: 12),
          if (cfg != null)
            _InteractionCard(
              title: '★ 1/3 行动卡：做选择，生成你的行动卡',
              subtitle: cfg.intro,
              child: ConceptPlaygroundWizard(
                conceptId: m.id,
                conceptTitle: '第${m.index}关·${m.title}',
                config: cfg,
                dao: _dao,
                runType: 'module',
                onActionCardSaved: _loadProgress,
              ),
            )
          else
            _InfoCard(title: '互动', body: '（该关尚未配置互动向导）'),

          const SizedBox(height: 12),
          if (quiz != null)
            _QuizCard(
              quiz: quiz,
              passed: _hasQuizPassed,
              pick: _quizPick,
              lastCorrect: _quizLastCorrect,
              onPick: (idx) => setState(() {
                _quizPick = idx;
                _quizLastCorrect = null;
              }),
              onSubmit: () => _submitQuiz(m, quiz),
            ),

          const SizedBox(height: 12),
          _CommitCard(
            hasCommit: _hasCommit,
            whenVal: _commitWhen,
            slotVal: _commitSlot,
            methodVal: _commitMethod,
            noteController: _commitNoteCtrl,
            onWhen: (v) => setState(() => _commitWhen = v),
            onSlot: (v) => setState(() => _commitSlot = v),
            onMethod: (v) => setState(() => _commitMethod = v),
            onSubmit: () => _submitCommit(m),
          ),

          const SizedBox(height: 14),
          if (_stars >= 3)
            FilledButton.icon(
              onPressed: _rewardClaimed ? null : () => _claimReward(m),
              icon: const Icon(Icons.emoji_events_outlined),
              label: Text(_rewardClaimed ? '本关奖励已领取' : '领取通关奖励（+10 XP）'),
            )
          else
            _InfoCard(
              title: '通关条件（3★）',
              body: '要拿到本关奖励，你需要完成：\n'
                  '1) 保存一张行动卡；\n'
                  '2) 通过 1 道小测验；\n'
                  '3) 提交一次执行承诺（时间+方式）。',
            ),
        ],
      ),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final int stars;
  final bool hasActionCard;
  final bool hasQuiz;
  final bool hasCommit;
  final bool rewardClaimed;
  final bool unlockedAdvanced;
  final bool advancedOn;
  final ValueChanged<bool> onToggleAdvanced;

  const _ProgressCard({
    required this.stars,
    required this.hasActionCard,
    required this.hasQuiz,
    required this.hasCommit,
    required this.rewardClaimed,
    required this.unlockedAdvanced,
    required this.advancedOn,
    required this.onToggleAdvanced,
  });

  @override
  Widget build(BuildContext context) {
    final items = <_StarTaskItem>[
      _StarTaskItem(label: '行动卡', done: hasActionCard, hint: '做选择→保存行动卡'),
      _StarTaskItem(label: '小测验', done: hasQuiz, hint: '用 1 题把概念锁住'),
      _StarTaskItem(label: '承诺', done: hasCommit, hint: '选时间+方式→提交'),
    ];

    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('三星闯关（理解→行动）', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                ),
                _StarsRow(stars: stars),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '当前：$stars/3 ★ ${rewardClaimed ? '· 奖励已领取' : ''}',
              style: const TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 12),
            ...items.map((it) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    children: [
                      Icon(it.done ? Icons.check_circle : Icons.radio_button_unchecked, size: 18, color: it.done ? Colors.green : Colors.black54),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text('${it.label}：${it.hint}', style: const TextStyle(height: 1.2)),
                      ),
                    ],
                  ),
                )),
            const SizedBox(height: 6),
            if (unlockedAdvanced)
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: advancedOn,
                onChanged: onToggleAdvanced,
                title: const Text('进阶模式（解锁更多选项）', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('当你已经完成 3★ 后，可打开进阶分支：在“时间少/压力大/刚失败”等真实条件下也能行动。'),
              )
            else
              const Text(
                '进阶模式将在你完成本关 3★ 后解锁：会在行动卡里增加一个“更难真实条件”的选择分支。',
                style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.25),
              ),
          ],
        ),
      ),
    );
  }
}

class _StarTaskItem {
  final String label;
  final bool done;
  final String hint;
  const _StarTaskItem({required this.label, required this.done, required this.hint});
}

class _StarsRow extends StatelessWidget {
  final int stars;
  const _StarsRow({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(3, (i) {
        final filled = stars >= i + 1;
        return Padding(
          padding: const EdgeInsets.only(left: 2),
          child: Icon(
            filled ? Icons.star : Icons.star_border,
            size: 18,
            color: filled ? Colors.amber : Colors.black54,
          ),
        );
      }),
    );
  }
}

class _QuizCard extends StatelessWidget {
  final Lecture56QuizItem quiz;
  final bool passed;
  final int? pick;
  final bool? lastCorrect;
  final ValueChanged<int> onPick;
  final VoidCallback onSubmit;

  const _QuizCard({
    required this.quiz,
    required this.passed,
    required this.pick,
    required this.lastCorrect,
    required this.onPick,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('★ 2/3 小测验：用 1 题锁住概念', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                ),
                if (passed) const Icon(Icons.check_circle, color: Colors.green),
              ],
            ),
            const SizedBox(height: 10),
            Text(quiz.question, style: const TextStyle(fontWeight: FontWeight.w700, height: 1.25)),
            const SizedBox(height: 8),
            ...List.generate(quiz.options.length, (idx) {
              return RadioListTile<int>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: idx,
                groupValue: pick,
                onChanged: passed ? null : (v) => onPick(v ?? idx),
                title: Text(quiz.options[idx]),
              );
            }),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: passed ? null : (pick == null ? null : onSubmit),
                    icon: const Icon(Icons.fact_check_outlined),
                    label: Text(passed ? '已通过 ✅' : '提交答案'),
                  ),
                ),
              ],
            ),
            if (lastCorrect == false) ...[
              const SizedBox(height: 8),
              Text('提示：${quiz.explanation}', style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
            ],
            if (passed) ...[
              const SizedBox(height: 8),
              Text('解释：${quiz.explanation}', style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
            ],
          ],
        ),
      ),
    );
  }
}

class _CommitCard extends StatelessWidget {
  final bool hasCommit;
  final String whenVal;
  final String slotVal;
  final String methodVal;
  final TextEditingController noteController;
  final ValueChanged<String> onWhen;
  final ValueChanged<String> onSlot;
  final ValueChanged<String> onMethod;
  final VoidCallback onSubmit;

  const _CommitCard({
    required this.hasCommit,
    required this.whenVal,
    required this.slotVal,
    required this.methodVal,
    required this.noteController,
    required this.onWhen,
    required this.onSlot,
    required this.onMethod,
    required this.onSubmit,
  });

  String _labelWhen(String id) {
    switch (id) {
      case 'today':
        return '今天';
      case 'tomorrow':
        return '明天';
      case 'week':
        return '本周';
      default:
        return id;
    }
  }

  String _labelSlot(String id) {
    switch (id) {
      case 'morning':
        return '早上';
      case 'noon':
        return '中午';
      case 'afternoon':
        return '下午';
      case 'evening':
        return '晚上';
      case 'before_bed':
        return '睡前';
      default:
        return id;
    }
  }

  String _labelMethod(String id) {
    switch (id) {
      case 'solo':
        return '自己做';
      case 'buddy':
        return '找同伴';
      case 'reward':
        return '带奖励';
      case 'public':
        return '公开打卡';
      default:
        return id;
    }
  }

  Widget _chips({required List<MapEntry<String, String>> options, required String value, required ValueChanged<String> on}) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: options.map((e) {
        final selected = value == e.key;
        return ChoiceChip(
          label: Text(e.value),
          selected: selected,
          onSelected: (_) => on(e.key),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('★ 3/3 承诺：把行动放进时间与方式', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                ),
                if (hasCommit) const Icon(Icons.check_circle, color: Colors.green),
              ],
            ),
            const SizedBox(height: 10),
            const Text('你打算什么时候做', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            _chips(
              options: const [
                MapEntry('today', '今天'),
                MapEntry('tomorrow', '明天'),
                MapEntry('week', '本周'),
              ],
              value: whenVal,
              on: onWhen,
            ),
            const SizedBox(height: 12),
            const Text('你更可能在哪个时间段完成', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            _chips(
              options: const [
                MapEntry('morning', '早上'),
                MapEntry('noon', '中午'),
                MapEntry('afternoon', '下午'),
                MapEntry('evening', '晚上'),
                MapEntry('before_bed', '睡前'),
              ],
              value: slotVal,
              on: onSlot,
            ),
            const SizedBox(height: 12),
            const Text('你用什么方式让它更容易发生', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            _chips(
              options: const [
                MapEntry('solo', '自己做'),
                MapEntry('buddy', '找同伴'),
                MapEntry('reward', '带奖励'),
                MapEntry('public', '公开打卡'),
              ],
              value: methodVal,
              on: onMethod,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteController,
              minLines: 1,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: '给未来的自己一句提醒（可选）',
                hintText: '例如：只做 2 分钟也算 / 先发那一句消息',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '你的承诺：${_labelWhen(whenVal)} · ${_labelSlot(slotVal)} · ${_labelMethod(methodVal)}',
              style: const TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onSubmit,
                    icon: const Icon(Icons.done_all),
                    label: Text(hasCommit ? '更新承诺' : '提交承诺（+8 XP）'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _InteractionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  const _InteractionCard({required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String body;
  const _InfoCard({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Text(body, style: const TextStyle(height: 1.4)),
          ],
        ),
      ),
    );
  }
}

class _ChecklistCard extends StatelessWidget {
  final String title;
  final List<String> items;
  const _ChecklistCard({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            ...items.map(
              (it) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.check_circle_outline, size: 18),
                    const SizedBox(width: 8),
                    Expanded(child: Text(it, style: const TextStyle(height: 1.35))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
