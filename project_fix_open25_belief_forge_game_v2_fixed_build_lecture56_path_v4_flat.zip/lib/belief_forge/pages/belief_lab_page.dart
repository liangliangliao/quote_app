import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../model/belief_concepts.dart';
import '../model/belief_game.dart';
import '../model/concept_playgrounds.dart';
import '../widgets/concept_playground_wizard.dart';
import '../widgets/game_feedback.dart';
import 'lecture56_path_page.dart';

/// Belief Lab: all key concepts as “interactive lessons”.
class BeliefLabPage extends StatefulWidget {
  final String? initialConceptId;
  const BeliefLabPage({super.key, this.initialConceptId});

  @override
  State<BeliefLabPage> createState() => _BeliefLabPageState();
}

class _BeliefLabPageState extends State<BeliefLabPage> {
  bool _openedInitial = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_openedInitial) return;
    final id = widget.initialConceptId;
    if (id == null) return;
    _openedInitial = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final concept = kBeliefForgeConcepts.where((c) => c.id == id).toList();
      if (concept.isEmpty) return;
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => BeliefConceptLessonPage(concept: concept.first)),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<BeliefProfile>(
      valueListenable: BeliefGameService.instance.profileListenable,
      builder: (context, p, _) {
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
          children: [
            const Text('信念实验室', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              '你的等级：Lv ${p.level}（做每日任务可快速升级）\n'
              '每个概念都包含：体验 → 解释 → 为什么 → 怎么做 → 案例。\n'
              '建议每天只做 1 个，做完立刻落到一个 1% 行动。',
              style: const TextStyle(fontSize: 13, color: Colors.black54, height: 1.3),
            ),
            const SizedBox(height: 12),
            Card(
              elevation: 0,
              color: const Color(0xFFF7F7F7),
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                leading: const CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(Icons.route_outlined, color: Colors.black87),
                ),
                title: const Text('Lecture 5–6 信念路径（15关）', style: TextStyle(fontWeight: FontWeight.w800)),
                subtitle: const Text('按原课逻辑串起来：原文钩子 → 互动选择 → 行动卡 → 生活落地'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const Lecture56PathPage()),
                ),
              ),
            ),
            const SizedBox(height: 12),
            ...kBeliefForgeConcepts.map((c) {
              final req = kConceptRequiredLevel[c.id] ?? 1;
              final locked = p.level < req;
              return _ConceptTile(concept: c, locked: locked, requiredLevel: req, playerLevel: p.level);
            }),
          ],
        );
      },
    );
  }
}

class _ConceptTile extends StatelessWidget {
  final BeliefConcept concept;
  final bool locked;
  final int requiredLevel;
  final int playerLevel;
  const _ConceptTile({required this.concept, required this.locked, required this.requiredLevel, required this.playerLevel});

  @override
  Widget build(BuildContext context) {
    final subtitle = locked ? '${concept.subtitle}\nLv $requiredLevel 解锁（当前 Lv $playerLevel）' : concept.subtitle;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        tileColor: const Color(0xFFF7F7F7),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: CircleAvatar(
          backgroundColor: Colors.white,
          child: Icon(concept.icon, color: Colors.black87),
        ),
        title: Text(concept.title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: locked ? const Icon(Icons.lock_outline) : const Icon(Icons.chevron_right),
        onTap: locked
            ? () {
                showModalBottomSheet<void>(
                  context: context,
                  showDragHandle: true,
                  builder: (_) {
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('未解锁：${concept.title}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 6),
                          Text('达到 Lv $requiredLevel 即可解锁。你当前 Lv $playerLevel。', style: const TextStyle(color: Colors.black54)),
                          const SizedBox(height: 12),
                          const Text('最快升级方式（像闯关一样）', style: TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 6),
                          const Text('• 做 1 次意志训练（fiat 或 注意力拉回）\n• 在任意概念里生成并保存 1 张行动卡\n• 写 1 次允许区三句话', style: TextStyle(color: Colors.black54, height: 1.25)),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: FilledButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('提示：切到下方“概览”→做/领取今日任务即可升级解锁。')),
                                    );
                                  },
                                  child: const Text('去做每日任务'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                );
              }
            : () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BeliefConceptLessonPage(concept: concept)),
                ),
      ),
    );
  }
}

/// Generic lesson page.
///
/// It contains:
/// 1) Micro-interaction (different by concept)
/// 2) Explanation
/// 3) Why
/// 4) How-to checklist
/// 5) Daily-life case
class BeliefConceptLessonPage extends StatefulWidget {
  final BeliefConcept concept;
  const BeliefConceptLessonPage({super.key, required this.concept});

  @override
  State<BeliefConceptLessonPage> createState() => _BeliefConceptLessonPageState();
}

class _BeliefConceptLessonPageState extends State<BeliefConceptLessonPage> {
  final _dao = BeliefForgeDao();

  // Shared interaction state
  int _tapCount = 0;
  bool _running = false;
  int _secondsLeft = 0;
  Timer? _timer;

  // Text inputs used by some lessons
  final _text1 = TextEditingController();
  final _text2 = TextEditingController();
  final _text3 = TextEditingController();

  double _sliderBefore = 5;
  double _sliderAfter = 5;
  bool _didAfter = false;

  String _primeChoice = '成就';

  @override
  void dispose() {
    _timer?.cancel();
    _text1.dispose();
    _text2.dispose();
    _text3.dispose();
    super.dispose();
  }

  void _startTapChallenge({required int seconds}) {
    if (_running) return;
    setState(() {
      _tapCount = 0;
      _running = true;
      _secondsLeft = seconds;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        t.cancel();
        setState(() {
          _running = false;
          _secondsLeft = 0;
        });
        _dao.addRun(
          conceptId: widget.concept.id,
          conceptTitle: widget.concept.title,
          runType: 'lab',
          durationSec: seconds,
          score: _tapCount.toDouble(),
          extra: {
            'type': 'tap_challenge',
            'prime': _primeChoice,
          },
        );
        return;
      }
      setState(() => _secondsLeft--);
    });
  }

  Widget _buildInteraction() {
    final cfg = getPlaygroundConfig(widget.concept.id);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (cfg != null)
          _InteractionCard(
            title: '互动：做选择，生成你的行动卡',
            subtitle: cfg.intro,
            child: ConceptPlaygroundWizard(
              conceptId: widget.concept.id,
              conceptTitle: widget.concept.title,
              config: cfg,
              dao: _dao,
            ),
          ),
        const SizedBox(height: 12),
        _buildDeepenExperience(),
      ],
    );
  }

  Widget _buildDeepenExperience() {
    switch (widget.concept.id) {
      case 'priming':
        return _InteractionCard(
          title: '加深体验（可选）：启动词点按挑战',
          subtitle: '多选一些启动主题，看看你的“开始感”会不会变化。',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final o in const ['成就', '平静', '勇气', '专注', '温柔', '随意'])
                    ChoiceChip(
                      label: Text(o),
                      selected: _primeChoice == o,
                      onSelected: (_) => setState(() => _primeChoice = o),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  _primeChoice == '成就'
                      ? '坚持 · 推进 · 完成 · 我能开始'
                      : _primeChoice == '平静'
                          ? '呼吸 · 放松 · 允许 · 我先稳定'
                          : _primeChoice == '勇气'
                              ? '开口 · 尝试 · 不必完美 · 我敢一步'
                              : _primeChoice == '专注'
                                  ? '只做这一件 · 先 2 分钟 · 继续'
                                  : _primeChoice == '温柔'
                                      ? '慢一点也可以 · 我照顾自己 · 我能继续'
                                      : '无所谓 · 随便 · 之后再说 · 等一等',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 12),
              _TapChallenge(
                running: _running,
                secondsLeft: _secondsLeft,
                tapCount: _tapCount,
                onStart: () => _startTapChallenge(seconds: 20),
                onTap: () => setState(() => _tapCount++),
              ),
              const SizedBox(height: 10),
              const Text(
                '提示：分数高低不重要，重点是体验“启动线索”如何影响你的投入与开始感。',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        );

      case 'belief_gears':
        return _InteractionCard(
          title: '加深体验（可选）：自洽雷达',
          subtitle: widget.concept.interactionHint,
          child: _BeliefConsistencyMini(),
        );

      case 'growth_mindset':
        return _InteractionCard(
          title: '加深体验（可选）：夸奖翻译器',
          subtitle: widget.concept.interactionHint,
          child: _MindsetTranslator(),
        );

      case 'permission_human':
        return _InteractionCard(
          title: '加深体验（可选）：允许区（三句话）',
          subtitle: widget.concept.interactionHint,
          child: _ThreeLineJournal(
            dao: _dao,
            concept: widget.concept,
            t1: _text1,
            t2: _text2,
            t3: _text3,
          ),
        );

      case 'placebo':
        return _InteractionCard(
          title: '加深体验（可选）：放松前后打分（安全版）',
          subtitle: widget.concept.interactionHint,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('现在你的紧张/不适程度（0-10）'),
              Slider(
                value: _sliderBefore,
                min: 0,
                max: 10,
                divisions: 10,
                label: _sliderBefore.toStringAsFixed(0),
                onChanged: (v) => setState(() => _sliderBefore = v),
              ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () {
                  setState(() {
                    _didAfter = true;
                    _sliderAfter = _sliderBefore;
                  });
                  showDialog<void>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('60 秒放松'),
                      content: const Text(
                        '吸气 4 秒 → 呼气 6 秒，重复 6 次。\n\n'
                        '把注意力放到“呼气变慢”，让身体先稳下来。',
                      ),
                      actions: [
                        FilledButton(onPressed: () => Navigator.pop(_), child: const Text('完成')),
                      ],
                    ),
                  );
                },
                icon: const Icon(Icons.timer_outlined),
                label: const Text('开始 60 秒放松'),
              ),
              if (_didAfter) ...[
                const SizedBox(height: 10),
                const Text('放松后再评一次（0-10）'),
                Slider(
                  value: _sliderAfter,
                  min: 0,
                  max: 10,
                  divisions: 10,
                  label: _sliderAfter.toStringAsFixed(0),
                  onChanged: (v) => setState(() => _sliderAfter = v),
                ),
                Text('变化：${(_sliderAfter - _sliderBefore).toStringAsFixed(0)}', style: const TextStyle(color: Colors.black54)),
              ]
            ],
          ),
        );

      default:
        return _InteractionCard(
          title: '加深体验（可选）：写下你的 1% 行动',
          subtitle: '把“理解”连到“行动证据”——越小越容易开始。',
          child: _DefaultMicroPractice(concept: widget.concept, dao: _dao),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.concept;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(c.title),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
        children: [
          Text(c.subtitle, style: const TextStyle(fontSize: 13, color: Colors.black54)),
          const SizedBox(height: 12),
          _buildInteraction(),
          const SizedBox(height: 12),
          _TextSection(title: '你刚刚经历了什么（解释）', body: c.explanation),
          const SizedBox(height: 12),
          _TextSection(title: '为什么会这样（机制）', body: c.why),
          const SizedBox(height: 12),
          _ChecklistSection(title: '你可以怎么做（步骤）', items: c.howTo),
          const SizedBox(height: 12),
          _TextSection(title: '日常案例（照着做）', body: c.caseStudy),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () async {
              await _dao.addRun(
                conceptId: c.id,
                conceptTitle: c.title,
                runType: 'lab',
                note: 'completed',
              );
              final award = await BeliefGameService.instance.awardXp(xp: 10, reason: 'lesson_complete');
              await BeliefGameService.instance.unlockBadge(
                'badge_first_lesson',
                extra: const {
                  'title': '第一次通关',
                  'desc': '你完成了一个概念的“体验→解释→怎么做”。',
                },
              );
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已记录：本次学习完成')));
              await showXpFeedback(context, award: award);
            },
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('把这次学习记下来'),
          ),
        ],
      ),
    );
  }
}

class _InteractionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  const _InteractionCard({required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _TapChallenge extends StatelessWidget {
  final bool running;
  final int secondsLeft;
  final int tapCount;
  final VoidCallback onStart;
  final VoidCallback onTap;

  const _TapChallenge({
    required this.running,
    required this.secondsLeft,
    required this.tapCount,
    required this.onStart,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: FilledButton(
            onPressed: running ? null : onStart,
            child: Text(running ? '进行中：${secondsLeft}s' : '开始 20 秒挑战'),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: InkWell(
            onTap: running ? onTap : null,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                running ? '点我 +1（$tapCount）' : '得分：$tapCount',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _TextSection extends StatelessWidget {
  final String title;
  final String body;
  const _TextSection({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Text(body, style: const TextStyle(height: 1.4)),
          ],
        ),
      ),
    );
  }
}

class _ChecklistSection extends StatelessWidget {
  final String title;
  final List<String> items;
  const _ChecklistSection({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            ...items.map(
              (it) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.check_circle_outline, size: 18),
                    const SizedBox(width: 8),
                    Expanded(child: Text(it, style: const TextStyle(height: 1.35))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DefaultMicroPractice extends StatefulWidget {
  final BeliefConcept concept;
  final BeliefForgeDao dao;
  const _DefaultMicroPractice({required this.concept, required this.dao});

  @override
  State<_DefaultMicroPractice> createState() => _DefaultMicroPracticeState();
}

class _DefaultMicroPracticeState extends State<_DefaultMicroPractice> {
  String _selected = '';
  final _note = TextEditingController();

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final options = const ['我愿意试一次', '我还不确定', '我先不做'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options
              .map(
                (o) => ChoiceChip(
                  label: Text(o),
                  selected: _selected == o,
                  onSelected: (_) => setState(() => _selected = o),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _note,
          maxLines: 2,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: '写下你打算做的“最小动作”（例：先做 2 分钟）',
          ),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: _selected.isEmpty
              ? null
              : () async {
                  await widget.dao.addRun(
                    conceptId: widget.concept.id,
                    conceptTitle: widget.concept.title,
                    runType: 'lab',
                    note: _note.text.trim(),
                    extra: {'choice': _selected},
                  );
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存：你的最小动作')));
                },
          icon: const Icon(Icons.save_outlined),
          label: const Text('保存这个最小动作'),
        ),
      ],
    );
  }
}

class _BeliefConsistencyMini extends StatefulWidget {
  @override
  State<_BeliefConsistencyMini> createState() => _BeliefConsistencyMiniState();
}

class _BeliefConsistencyMiniState extends State<_BeliefConsistencyMini> {
  final _belief = TextEditingController();
  String _behavior = '';

  @override
  void dispose() {
    _belief.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final behaviors = const ['很一致', '一般', '不一致'];
    final score = _behavior == '很一致'
        ? 85
        : _behavior == '一般'
            ? 55
            : _behavior == '不一致'
                ? 25
                : 0;
    final suggest = score >= 70
        ? '保持：今天再做一个 1% 动作巩固证据。'
        : score >= 40
            ? '调整：挑一个你做得到的 1% 动作，让信念有证据。'
            : score == 0
                ? '先输入信念并选择昨天行为。'
                : '先别苛责：从“最小动作”开始，先制造证据。';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _belief,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: '输入一句信念（例：我重视健康 / 我能学会）',
          ),
        ),
        const SizedBox(height: 10),
        const Text('昨天的行为更接近哪一种？'),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: behaviors
              .map(
                (b) => ChoiceChip(
                  label: Text(b),
                  selected: _behavior == b,
                  onSelected: (_) => setState(() => _behavior = b),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('自洽分数：$score', style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text(suggest, style: const TextStyle(color: Colors.black54, height: 1.3)),
                  ],
                ),
              ),
            ),
          ],
        )
      ],
    );
  }
}

class _MindsetTranslator extends StatefulWidget {
  @override
  State<_MindsetTranslator> createState() => _MindsetTranslatorState();
}

class _MindsetTranslatorState extends State<_MindsetTranslator> {
  final _input = TextEditingController();
  String _output = '';

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  String _translate(String s) {
    final t = s.trim();
    if (t.isEmpty) return '';
    if (t.contains('笨') || t.contains('不行') || t.contains('没天赋')) {
      return '我还没掌握这个策略，但我可以练出来。下一步：先练 2 分钟/2 次。';
    }
    if (t.contains('必须') || t.contains('一定') || t.contains('一次就')) {
      return '我把今天当练习：先收集 1 个改进点，再做下一次尝试。';
    }
    if (t.contains('聪明') || t.contains('天才')) {
      return '我用了___策略并坚持了___分钟。这是我能控制的部分。';
    }
    return '把它改成“可控变量”语言：我可以用___策略，先做___分钟/___次。';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _input,
          maxLines: 2,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: '输入一句你常说的台词（例：我太笨了 / 我必须一次成功）',
          ),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: () => setState(() => _output = _translate(_input.text)),
          icon: const Icon(Icons.translate),
          label: const Text('翻译成成长心态'),
        ),
        if (_output.isNotEmpty) ...[
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
            child: Text(_output, style: const TextStyle(height: 1.35)),
          ),
        ]
      ],
    );
  }
}

class _ThreeLineJournal extends StatelessWidget {
  final BeliefForgeDao dao;
  final BeliefConcept concept;
  final TextEditingController t1;
  final TextEditingController t2;
  final TextEditingController t3;
  const _ThreeLineJournal({required this.dao, required this.concept, required this.t1, required this.t2, required this.t3});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: t1,
          decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '第 1 句：我正在感到___'),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: t2,
          decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '第 2 句：这很正常，它告诉我___'),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: t3,
          decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '第 3 句：我愿意先照顾自己：___（一个最小动作）'),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: () async {
            if (t1.text.trim().isEmpty || t2.text.trim().isEmpty || t3.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先写满三句话')));
              return;
            }
            await dao.addJournal(
              mood0to10: null,
              emotion: null,
              line1: t1.text.trim(),
              line2: t2.text.trim(),
              line3: t3.text.trim(),
              reframe: null,
            );
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存到允许区')));
          },
          icon: const Icon(Icons.save_outlined),
          label: const Text('保存三句话'),
        ),
      ],
    );
  }
}

// ---- helpers ----

extension _RandomPick on List<String> {
  String pick(Random r) => this[r.nextInt(length)];
}
