import 'dart:convert';

import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../model/lecture56_modules.dart';
import 'lecture56_module_page.dart';

/// An ordered path that follows Harvard Positive Psychology Lecture 5 + Lecture 6.
///
/// This path is designed to preserve the original logic flow:
/// situation/positive loop (L5) → belief-to-reality mechanisms (L6).
class Lecture56PathPage extends StatefulWidget {
  const Lecture56PathPage({super.key});

  @override
  State<Lecture56PathPage> createState() => _Lecture56PathPageState();
}

class _Lecture56PathPageState extends State<Lecture56PathPage> {
  final _dao = BeliefForgeDao();
  bool _loading = true;
  final Map<String, int> _stars = <String, int>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await _dao.ensureSchema();
    final rows = await _dao.listRunsByRunType('module', limit: 2000);
    final flags = <String, Set<String>>{}; // moduleId -> {'action','quiz','commit'}

    for (final r in rows) {
      final cid = (r['concept_id'] ?? '').toString();
      if (cid.isEmpty) continue;
      final extraRaw = (r['extra_json'] ?? '').toString();
      if (extraRaw.isEmpty) continue;
      try {
        final decoded = jsonDecode(extraRaw);
        if (decoded is! Map) continue;
        final extra = Map<String, dynamic>.from(decoded as Map);
        final mid = (extra['module_id'] ?? '').toString();
        final moduleId = mid.isEmpty ? cid : mid;
        final t = (extra['type'] ?? '').toString();

        final set = flags.putIfAbsent(moduleId, () => <String>{});
        if (t == 'action_card') set.add('action');
        if (t == 'module_quiz') set.add('quiz');
        if (t == 'module_commit') set.add('commit');
        if (t == 'module_complete') {
          // Backward compatibility for older builds where completion
          // did not have 3★ checkpoints.
          set.add('action');
          set.add('quiz');
          set.add('commit');
        }
      } catch (_) {
        // ignore
      }
    }

    final starMap = <String, int>{};
    for (final m in kLecture56Modules) {
      final set = flags[m.id] ?? const <String>{};
      starMap[m.id] = set.length.clamp(0, 3);
    }

    if (!mounted) return;
    setState(() {
      _stars
        ..clear()
        ..addAll(starMap);
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    final totalStars = _stars.values.fold<int>(0, (a, b) => a + b);
    final completedCount = kLecture56Modules.where((m) => (_stars[m.id] ?? 0) >= 3).length;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Lecture 5–6 信念路径（15关）'),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
          children: [
            Card(
              elevation: 0,
              color: const Color(0xFFF7F7F7),
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('按原课逻辑串起来', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text(
                      '进度：$completedCount/15 关（3★通关）。\n'
                      '星数：$totalStars/45 ★（每关 3★：行动卡 + 小测验 + 承诺）。\n'
                      '每一关都是：原文钩子 → 解释/为什么 → 互动选择 → 行动卡 → 生活落地。',
                      style: const TextStyle(color: Colors.black54, height: 1.25),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () async {
                              final next = kLecture56Modules.firstWhere(
                                (m) => (_stars[m.id] ?? 0) < 3,
                                orElse: () => kLecture56Modules.last,
                              );
                              await Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => Lecture56ModulePage(moduleId: next.id)),
                              );
                              await _load();
                            },
                            icon: const Icon(Icons.play_arrow),
                            label: const Text('继续下一关'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            ...kLecture56Modules.map((m) {
              final s = _stars[m.id] ?? 0;
              final done = s >= 3;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  tileColor: const Color(0xFFF7F7F7),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  leading: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: Text(
                      m.index.toString().padLeft(2, '0'),
                      style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.black87),
                    ),
                  ),
                  title: Text(m.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${m.lecture} · $s/3★${done ? ' · 已通关' : ''}'),
                  trailing: _StarsMini(stars: s),
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => Lecture56ModulePage(moduleId: m.id)),
                    );
                    await _load();
                  },
                ),
              );
            }),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: () async {
                final award = await BeliefGameService.instance.awardXp(xp: 5, reason: 'path_checkin');
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已记录：今天来过路径（+5 XP）')));
                // keep the path page lightweight: no modal feedback
              },
              icon: const Icon(Icons.auto_awesome),
              label: const Text('今日来过（小奖励）'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StarsMini extends StatelessWidget {
  final int stars;
  const _StarsMini({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final filled = stars >= i + 1;
        return Padding(
          padding: const EdgeInsets.only(left: 2),
          child: Icon(
            filled ? Icons.star : Icons.star_border,
            size: 16,
            color: filled ? Colors.amber : Colors.black54,
          ),
        );
      }),
    );
  }
}
