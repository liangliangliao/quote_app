import 'dart:math';

/// BeliefForge Concept Playground
///
/// Each concept is represented as a preset interactive wizard:
/// - Users make choices *within a curated option space*.
/// - The app deterministically composes an Action Card:
///   plan title + summary + steps + short mechanism + a concrete case example.
///
/// This file contains:
/// - Data structures for option groups
/// - Preset configs for every concept in BeliefForge
///
/// No free-form AI generation is used here (so the scope is controlled,
/// predictable, and testable).

enum SelectionMode { single, multi }

class PlaygroundOption {
  final String id;
  final String label;
  final String? hint;
  const PlaygroundOption({required this.id, required this.label, this.hint});
}

class PlaygroundGroup {
  final String key;
  final String title;
  final String? description;
  final SelectionMode mode;
  final int maxSelect; // only used for multi
  final List<PlaygroundOption> options;

  const PlaygroundGroup({
    required this.key,
    required this.title,
    this.description,
    required this.mode,
    this.maxSelect = 3,
    required this.options,
  });
}

class ActionCard {
  final String title;
  final String summary;
  final String whyShort;
  final List<String> steps;
  final String example;

  const ActionCard({
    required this.title,
    required this.summary,
    required this.whyShort,
    required this.steps,
    required this.example,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'summary': summary,
        'why_short': whyShort,
        'steps': steps,
        'example': example,
      };
}

typedef ActionCardGenerator = ActionCard Function(Map<String, List<PlaygroundOption>> picks);

class ConceptPlaygroundConfig {
  final String conceptId;
  final String intro;
  final List<PlaygroundGroup> groups;
  final ActionCardGenerator generator;

  const ConceptPlaygroundConfig({
    required this.conceptId,
    required this.intro,
    required this.groups,
    required this.generator,
  });
}

// ---------- helpers ----------

PlaygroundOption _one(Map<String, List<PlaygroundOption>> picks, String key, PlaygroundOption fallback) {
  final list = picks[key];
  if (list == null || list.isEmpty) return fallback;
  return list.first;
}

List<PlaygroundOption> _many(Map<String, List<PlaygroundOption>> picks, String key) {
  return List<PlaygroundOption>.from(picks[key] ?? const []);
}

String _joinLabels(List<PlaygroundOption> opts, {String empty = '（未选择）'}) {
  if (opts.isEmpty) return empty;
  return opts.map((e) => e.label).join('、');
}

String _hintOrLabel(PlaygroundOption o) => o.hint == null ? o.label : '${o.label}（${o.hint}）';

// ---------- configs ----------

final Map<String, ConceptPlaygroundConfig> kConceptPlaygrounds = {
  // 1) Broaden & Build
  'broaden_build': ConceptPlaygroundConfig(
    conceptId: 'broaden_build',
    intro: '选择你此刻的状态与可用时间，我们会为你生成一个“拓展动作”，帮助你把带宽加宽一点点。',
    groups: const [
      PlaygroundGroup(
        key: 'mood',
        title: '你现在的情绪天气',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'storm', label: '暴风雨', hint: '很烦/很乱/撑不住'),
          PlaygroundOption(id: 'cloudy', label: '阴天', hint: '低落/没劲'),
          PlaygroundOption(id: 'windy', label: '大风', hint: '焦虑/紧张'),
          PlaygroundOption(id: 'fog', label: '大雾', hint: '迷茫/脑雾'),
          PlaygroundOption(id: 'clear', label: '晴天', hint: '还不错'),
          PlaygroundOption(id: 'sunny', label: '大晴', hint: '轻松/有能量'),
        ],
      ),
      PlaygroundGroup(
        key: 'goal',
        title: '你想拓展到什么方向',
        description: '拓展不是“强迫开心”，而是给大脑更多选项。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'connect', label: '连接', hint: '找回支持感'),
          PlaygroundOption(id: 'explore', label: '探索', hint: '走出去/换视角'),
          PlaygroundOption(id: 'learn', label: '学习', hint: '获得新策略'),
          PlaygroundOption(id: 'move', label: '运动', hint: '让身体带动心情'),
          PlaygroundOption(id: 'gratitude', label: '感恩', hint: '看见已有的'),
          PlaygroundOption(id: 'create', label: '创造', hint: '做点小作品'),
        ],
      ),
      PlaygroundGroup(
        key: 'time',
        title: '你现在有多少时间',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '30s', label: '30 秒'),
          PlaygroundOption(id: '2m', label: '2 分钟'),
          PlaygroundOption(id: '5m', label: '5 分钟'),
          PlaygroundOption(id: '10m', label: '10 分钟'),
          PlaygroundOption(id: '15m', label: '15 分钟'),
        ],
      ),
      PlaygroundGroup(
        key: 'action',
        title: '选择一个“拓展动作”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'msg', label: '发一句连接消息', hint: '“我想聊聊/你在吗”'),
          PlaygroundOption(id: 'walk', label: '走 5 分钟看 3 个细节', hint: '换场景'),
          PlaygroundOption(id: 'breath', label: '呼吸 6 轮 + 扫描身体', hint: '把带宽拉回'),
          PlaygroundOption(id: 'grat', label: '写 3 个小感恩', hint: '越具体越好'),
          PlaygroundOption(id: 'learn1', label: '学 1 个小技巧', hint: '看 1 段教程/1 页书'),
          PlaygroundOption(id: 'create1', label: '做 1 个小创作', hint: '写 4 句/画 1 个图标'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackMood = PlaygroundOption(id: 'cloudy', label: '阴天');
      const fallbackGoal = PlaygroundOption(id: 'connect', label: '连接');
      const fallbackTime = PlaygroundOption(id: '2m', label: '2 分钟');
      const fallbackAction = PlaygroundOption(id: 'msg', label: '发一句连接消息');

      final mood = _one(picks, 'mood', fallbackMood);
      final goal = _one(picks, 'goal', fallbackGoal);
      final time = _one(picks, 'time', fallbackTime);
      final action = _one(picks, 'action', fallbackAction);

      final title = '拓展动作：${action.label}';
      final summary = '''你现在是「${mood.label}」→ 目标是「${goal.label}」。
用 ${time.label} 做一个小小的拓展动作：${_hintOrLabel(action)}。''';

      final steps = <String>[
        '先说一句：我现在是「${mood.label}」，这很正常（不评判）。',
        '计时 ${time.label}，只做一件事：${_hintOrLabel(action)}。',
        '做完写一句：我看到的新可能是___；我下一步愿意试___。',
      ];

      final why = '积极情绪/积极体验会“加宽带宽”，让你更容易看到选项；拓展动作是最小成本的带宽恢复。';

      final example = '''例子：你处在「${mood.label}」时容易反刍。
你不强迫自己开心，只做 ${time.label} 的「${action.label}」。
当你完成一次小连接/小移动，你会更容易从“钻牛角尖”切回“可行动”。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 2) Priming
  'priming': ConceptPlaygroundConfig(
    conceptId: 'priming',
    intro: '选择你想进入的状态、启动通道、要移除的反线索，并生成一张“启动行动卡”。',
    groups: const [
      PlaygroundGroup(
        key: 'state',
        title: '你想进入的状态',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'focus', label: '专注'),
          PlaygroundOption(id: 'start', label: '开始'),
          PlaygroundOption(id: 'calm', label: '平静'),
          PlaygroundOption(id: 'confidence', label: '自信'),
          PlaygroundOption(id: 'persistence', label: '坚持'),
          PlaygroundOption(id: 'creative', label: '创造力'),
        ],
      ),
      PlaygroundGroup(
        key: 'channel',
        title: '你的启动通道',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'words', label: '词语启动', hint: '10 秒读启动词'),
          PlaygroundOption(id: 'music', label: '音乐启动', hint: '一首固定开工曲'),
          PlaygroundOption(id: 'image', label: '图片启动', hint: '锁屏/壁纸'),
          PlaygroundOption(id: 'object', label: '物品启动', hint: '工具放第一视线'),
          PlaygroundOption(id: 'ritual', label: '仪式启动', hint: '同一动作=开工'),
          PlaygroundOption(id: 'buddy', label: '同伴启动', hint: '一句话互相提醒'),
        ],
      ),
      PlaygroundGroup(
        key: 'remove',
        title: '移除反线索（最多选 3 个）',
        description: '你不是“靠意志扛”，而是减少竞争线索。',
        mode: SelectionMode.multi,
        maxSelect: 3,
        options: [
          PlaygroundOption(id: 'phone_far', label: '手机放远', hint: '至少 2 米'),
          PlaygroundOption(id: 'one_window', label: '只开 1 个窗口', hint: '关掉其它'),
          PlaygroundOption(id: 'notify_off', label: '关通知 30 分钟'),
          PlaygroundOption(id: 'clean_desk', label: '桌面只留任务物'),
          PlaygroundOption(id: 'timer', label: '番茄计时', hint: '先 10 分钟'),
          PlaygroundOption(id: 'block_app', label: '加一层阻力', hint: '短视频延迟'),
          PlaygroundOption(id: 'water', label: '水杯就位', hint: '减少中断'),
        ],
      ),
      PlaygroundGroup(
        key: 'first',
        title: '第一步做什么（越小越好）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'write1', label: '写第一句/第一行'),
          PlaygroundOption(id: 'open_file', label: '打开文件并命名'),
          PlaygroundOption(id: 'outline3', label: '写 3 个要点'),
          PlaygroundOption(id: 'reply1', label: '回 1 条消息推进'),
          PlaygroundOption(id: 'read1', label: '读 1 页/看 1 段'),
          PlaygroundOption(id: 'start_timer', label: '启动 2 分钟计时'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackState = PlaygroundOption(id: 'focus', label: '专注');
      const fallbackChannel = PlaygroundOption(id: 'words', label: '词语启动');
      const fallbackFirst = PlaygroundOption(id: 'write1', label: '写第一句/第一行');

      final state = _one(picks, 'state', fallbackState);
      final channel = _one(picks, 'channel', fallbackChannel);
      final remove = _many(picks, 'remove');
      final first = _one(picks, 'first', fallbackFirst);

      final title = '启动：${state.label} → ${first.label}';
      final summary = '''目标状态：${state.label}。
我用「${channel.label}」作为启动线索，移除「${_joinLabels(remove, empty: '先移除 1 个干扰')}」，然后立刻做：${first.label}。''';

      final steps = <String>[
        '准备启动线索：${_hintOrLabel(channel)}。',
        '移除反线索：${_joinLabels(remove, empty: '先做一个：手机放远/只开一个窗口')}。',
        '启动 10 秒：对自己说/看见「${state.label}」相关提示。',
        '立刻开始：${first.label}（先计时 2 分钟）。',
        '结束后记录 1 条证据：我完成了___；这说明我可以___。',
      ];

      final why = '启动效应会让“被激活的线索”更容易占据注意力，从而提高开始与坚持的概率；移除反线索能减少竞争。';

      final example = '''例子：你想进入「${state.label}」来处理一个重要任务。
你选择「${channel.label}」作为开工信号，并移除「${_joinLabels(remove, empty: '一个干扰')}」。
然后只做最小第一步「${first.label}」。通常“开始”的阻力会明显下降。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 3) Situation power
  'situation_power': ConceptPlaygroundConfig(
    conceptId: 'situation_power',
    intro: '选择一个你想扮演的角色，并把环境改成“帮你做对事”的样子。',
    groups: const [
      PlaygroundGroup(
        key: 'role',
        title: '你今天想扮演的角色',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'executor', label: '执行者', hint: '只推进下一步'),
          PlaygroundOption(id: 'learner', label: '学习者', hint: '把困难当信息'),
          PlaygroundOption(id: 'speaker', label: '清晰表达者', hint: '先说重点'),
          PlaygroundOption(id: 'calm', label: '稳定者', hint: '先稳再做'),
          PlaygroundOption(id: 'coach', label: '教练', hint: '对自己友善而坚定'),
          PlaygroundOption(id: 'builder', label: '系统搭建者', hint: '先搭场景'),
        ],
      ),
      PlaygroundGroup(
        key: 'scene',
        title: '你要在哪个场景做这件事',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'desk', label: '书桌/工位'),
          PlaygroundOption(id: 'meeting', label: '会议/沟通'),
          PlaygroundOption(id: 'home', label: '家里'),
          PlaygroundOption(id: 'commute', label: '通勤路上'),
          PlaygroundOption(id: 'gym', label: '运动/户外'),
          PlaygroundOption(id: 'phone', label: '手机场景', hint: '随时会被打断'),
        ],
      ),
      PlaygroundGroup(
        key: 'setup',
        title: '环境设置（最多选 3 个）',
        mode: SelectionMode.multi,
        maxSelect: 3,
        options: [
          PlaygroundOption(id: 'one_task', label: '只留一个任务'),
          PlaygroundOption(id: 'timer10', label: '先计时 10 分钟'),
          PlaygroundOption(id: 'tools_ready', label: '工具/资料就位'),
          PlaygroundOption(id: 'phone_out', label: '手机离开视线'),
          PlaygroundOption(id: 'cue_card', label: '放一张提示卡', hint: '“只做下一步”'),
          PlaygroundOption(id: 'music', label: '固定背景音乐'),
          PlaygroundOption(id: 'clean', label: '清理桌面 1 分钟'),
        ],
      ),
      PlaygroundGroup(
        key: 'micro',
        title: '角色的第一个微行动',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'next_step', label: '写下“下一步”并做 2 分钟'),
          PlaygroundOption(id: '3points', label: '列 3 个要点'),
          PlaygroundOption(id: 'send_msg', label: '发一条推进消息'),
          PlaygroundOption(id: 'open', label: '打开文件并开始编辑'),
          PlaygroundOption(id: 'practice', label: '练 1 次开场白'),
          PlaygroundOption(id: 'prep', label: '准备材料 3 分钟'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackRole = PlaygroundOption(id: 'executor', label: '执行者');
      const fallbackScene = PlaygroundOption(id: 'desk', label: '书桌/工位');
      const fallbackMicro = PlaygroundOption(id: 'next_step', label: '写下“下一步”并做 2 分钟');

      final role = _one(picks, 'role', fallbackRole);
      final scene = _one(picks, 'scene', fallbackScene);
      final setup = _many(picks, 'setup');
      final micro = _one(picks, 'micro', fallbackMicro);

      final title = '情境脚本：${role.label}';
      final summary = '场景：${scene.label}。我扮演「${role.label}」，先做环境设置：${_joinLabels(setup, empty: '任选一个设置')}，然后立刻做：${micro.label}。';

      final steps = <String>[
        '进入场景：${scene.label}。',
        '做环境设置：${_joinLabels(setup, empty: '只做一个：计时10分钟/手机离开视线')}。',
        '用角色语气对自己说：今天我就是「${role.label}」。',
        '立刻执行微行动：${micro.label}。',
        '复盘一句：这个情境让我更容易做对什么？下次我要保留哪一项设置？',
      ];

      final why = '情境会提供“脚本”并改变默认预期。先搭好情境，意志成本会明显下降。';

      final example = '''例子：你在「${scene.label}」里容易拖延。
你决定扮演「${role.label}」，先做设置「${_joinLabels(setup, empty: '计时10分钟')}」。
然后只做「${micro.label}」。你会发现，不需要等动力来，情境本身会推动你开始。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 4) Pygmalion
  'pygmalion': ConceptPlaygroundConfig(
    conceptId: 'pygmalion',
    intro: '选择一个对象，并把“期待”翻译成“高期待=高支持”的具体动作。',
    groups: const [
      PlaygroundGroup(
        key: 'person',
        title: '你要把期待用在哪个对象上',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'self', label: '我自己'),
          PlaygroundOption(id: 'child', label: '孩子/学生'),
          PlaygroundOption(id: 'partner', label: '伴侣'),
          PlaygroundOption(id: 'coworker', label: '同事/下属'),
          PlaygroundOption(id: 'friend', label: '朋友'),
          PlaygroundOption(id: 'team', label: '团队'),
        ],
      ),
      PlaygroundGroup(
        key: 'expect',
        title: '你想传递的期待',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'can_learn', label: '你能学会'),
          PlaygroundOption(id: 'can_finish', label: '你能完成'),
          PlaygroundOption(id: 'can_grow', label: '你能变得更好'),
          PlaygroundOption(id: 'can_try', label: '你能再试一次'),
          PlaygroundOption(id: 'can_lead', label: '你能担起来'),
          PlaygroundOption(id: 'can_recover', label: '你能恢复'),
        ],
      ),
      PlaygroundGroup(
        key: 'support',
        title: '把期待翻译成支持（最多选 3 个）',
        description: '期待不是口号，而是：标准 + 机会 + 反馈。',
        mode: SelectionMode.multi,
        maxSelect: 3,
        options: [
          PlaygroundOption(id: 'clear_standard', label: '给清晰标准', hint: '什么算完成'),
          PlaygroundOption(id: 'small_step', label: '拆成小步练习', hint: '一次只做一小段'),
          PlaygroundOption(id: 'give_chance', label: '给一次机会', hint: '小但关键任务'),
          PlaygroundOption(id: 'process_feedback', label: '给过程反馈', hint: '策略/努力'),
          PlaygroundOption(id: 'patience', label: '多一点耐心', hint: '慢一点也行'),
          PlaygroundOption(id: 'remove_shame', label: '减少羞辱式语言', hint: '不贴标签'),
          PlaygroundOption(id: 'review', label: '每周一次复盘', hint: '看看进步证据'),
        ],
      ),
      PlaygroundGroup(
        key: 'script',
        title: '你要用哪种反馈语言',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'process', label: '过程语言', hint: '你用了什么策略'),
          PlaygroundOption(id: 'effort', label: '努力语言', hint: '你坚持了多久'),
          PlaygroundOption(id: 'next', label: '下一步语言', hint: '下次试什么'),
          PlaygroundOption(id: 'evidence', label: '证据语言', hint: '你已经做到过'),
          PlaygroundOption(id: 'supportive', label: '支持性语言', hint: '我会陪你一起'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackPerson = PlaygroundOption(id: 'self', label: '我自己');
      const fallbackExpect = PlaygroundOption(id: 'can_learn', label: '你能学会');
      const fallbackScript = PlaygroundOption(id: 'process', label: '过程语言');

      final person = _one(picks, 'person', fallbackPerson);
      final expect = _one(picks, 'expect', fallbackExpect);
      final support = _many(picks, 'support');
      final script = _one(picks, 'script', fallbackScript);

      final title = '高期待=高支持：${person.label}';
      final summary = '''对象：${person.label}。
我传递的期待是「${expect.label}」。
我会用支持动作：${_joinLabels(support, empty: '至少选 1 个支持动作')}。
我的反馈语言是：${script.label}。''';

      final steps = <String>[
        '先说一句期待：${expect.label}。',
        '立刻给支持：${_joinLabels(support, empty: '给清晰标准/拆小步/给一次机会')}。',
        '用${script.label}给出一句具体反馈（避免“你真聪明/你不行”这种标签）。',
        '约定一次复盘：本周我们看一条证据（做到过什么）。',
      ];

      final why = '期待会改变你给予的机会与反馈质量；把期待落到支持动作，才会形成正向自证预言。';

      final example = '''例子：你想支持${person.label}。
你不只说“加油”，而是说“${expect.label}，我们先把标准说清楚，然后做一次小练习”。
再用${script.label}反馈“你刚才用了___策略/坚持了___分钟”。
这样更容易让对方进入“我能做到”的证据循环。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 5) Belief gears
  'belief_gears': ConceptPlaygroundConfig(
    conceptId: 'belief_gears',
    intro: '用“动机×自洽”把一句信念变成今天就能做的 1% 证据动作。',
    groups: const [
      PlaygroundGroup(
        key: 'domain',
        title: '你的信念属于哪个领域',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'health', label: '健康'),
          PlaygroundOption(id: 'work', label: '工作/学习'),
          PlaygroundOption(id: 'relationship', label: '关系'),
          PlaygroundOption(id: 'emotion', label: '情绪/心理'),
          PlaygroundOption(id: 'money', label: '金钱/规划'),
          PlaygroundOption(id: 'self', label: '自我成长'),
        ],
      ),
      PlaygroundGroup(
        key: 'belief',
        title: '选择一句目标信念模板',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'i_can', label: '我能做到___'),
          PlaygroundOption(id: 'i_value', label: '我重视___，所以我会___'),
          PlaygroundOption(id: 'i_learn', label: '我正在学习___'),
          PlaygroundOption(id: 'i_practice', label: '我可以通过练习变得更___'),
          PlaygroundOption(id: 'i_handle', label: '我能处理___的困难'),
        ],
      ),
      PlaygroundGroup(
        key: 'friction',
        title: '你最常卡在什么阻力',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'no_time', label: '没时间/太忙'),
          PlaygroundOption(id: 'low_energy', label: '没精力'),
          PlaygroundOption(id: 'fear', label: '害怕失败/尴尬'),
          PlaygroundOption(id: 'overthink', label: '想太多才开始'),
          PlaygroundOption(id: 'perfection', label: '完美主义'),
          PlaygroundOption(id: 'forget', label: '容易忘'),
        ],
      ),
      PlaygroundGroup(
        key: 'evidence',
        title: '今天的 1% 证据动作',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '30s', label: '30 秒行动', hint: '只做启动'),
          PlaygroundOption(id: '2m', label: '2 分钟行动', hint: '只做第一步'),
          PlaygroundOption(id: '5m', label: '5 分钟行动', hint: '小块推进'),
          PlaygroundOption(id: 'ask', label: '问一个问题', hint: '获得支持'),
          PlaygroundOption(id: 'prepare', label: '准备材料', hint: '降低下次阻力'),
          PlaygroundOption(id: 'track', label: '记录一次', hint: '把证据写下来'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackDomain = PlaygroundOption(id: 'work', label: '工作/学习');
      const fallbackBelief = PlaygroundOption(id: 'i_can', label: '我能做到___');
      const fallbackFriction = PlaygroundOption(id: 'overthink', label: '想太多才开始');
      const fallbackEvidence = PlaygroundOption(id: '2m', label: '2 分钟行动');

      final domain = _one(picks, 'domain', fallbackDomain);
      final belief = _one(picks, 'belief', fallbackBelief);
      final friction = _one(picks, 'friction', fallbackFriction);
      final evidence = _one(picks, 'evidence', fallbackEvidence);

      final title = '1% 证据：${domain.label}';
      final summary = '''领域：${domain.label}。
目标信念模板：${belief.label}
你的主要阻力：${friction.label}。
今天只做一个证据动作：${_hintOrLabel(evidence)}。''';

      final steps = <String>[
        '把信念写成一句“可验证”的话（用模板即可）。',
        '识别阻力：${friction.label}（不评判，只当作环境变量）。',
        '执行证据动作：${_hintOrLabel(evidence)}。',
        '写下证据句：我刚才做了___，这说明我可以___。',
      ];

      final why = '信念会通过动机与自洽影响行为。最小证据动作能让你“像那种人”，从而重写信念。';

      final example = '''例子：你在${domain.label}上怀疑自己。
你不追求一次改变人生，而是做一个「${evidence.label}」。
当你有了“我做到了”的证据，自洽会推动你更愿意继续。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 6) Placebo / mind-body
  'placebo': ConceptPlaygroundConfig(
    conceptId: 'placebo',
    intro: '在安全范围内体验“期待→体验”的回路：先稳住身体，再给出可相信的解释，然后做一小步。',
    groups: const [
      PlaygroundGroup(
        key: 'scene',
        title: '你现在更像哪种场景',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'before_talk', label: '要开口/上台前'),
          PlaygroundOption(id: 'before_sleep', label: '睡前'),
          PlaygroundOption(id: 'after_news', label: '看完信息很焦虑'),
          PlaygroundOption(id: 'overwhelmed', label: '事情太多压住了'),
          PlaygroundOption(id: 'body_unwell', label: '身体不舒服但非紧急'),
          PlaygroundOption(id: 'panic', label: '突然紧张/心跳快'),
        ],
      ),
      PlaygroundGroup(
        key: 'signal',
        title: '你感到的身体信号',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'tight_chest', label: '胸口紧'),
          PlaygroundOption(id: 'stomach', label: '胃不舒服'),
          PlaygroundOption(id: 'heart', label: '心跳快'),
          PlaygroundOption(id: 'shoulder', label: '肩颈紧'),
          PlaygroundOption(id: 'head', label: '头紧/头痛'),
          PlaygroundOption(id: 'breath', label: '呼吸浅'),
        ],
      ),
      PlaygroundGroup(
        key: 'reframe',
        title: '给自己一句“可相信的解释”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'prepare', label: '这表示身体在准备应对'),
          PlaygroundOption(id: 'safe', label: '我现在是安全的，我先稳下来'),
          PlaygroundOption(id: 'signal', label: '这是一条信号，不是判决'),
          PlaygroundOption(id: 'allow', label: '我允许紧张存在 90 秒'),
          PlaygroundOption(id: 'learn', label: '我在学习面对它'),
          PlaygroundOption(id: 'pass', label: '它会过去的，我只需先呼气'),
        ],
      ),
      PlaygroundGroup(
        key: 'calm',
        title: '选择一个稳定身体的动作',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'breath_4_6', label: '呼吸 4-6', hint: '吸4呼6×6轮'),
          PlaygroundOption(id: 'ground', label: '脚底扎根', hint: '感受脚掌'),
          PlaygroundOption(id: 'scan', label: '身体扫描', hint: '从头到脚'),
          PlaygroundOption(id: 'sip', label: '喝一口水'),
          PlaygroundOption(id: 'stretch', label: '拉伸 60 秒'),
          PlaygroundOption(id: 'cold', label: '冷刺激 10 秒', hint: '洗手/冷敷'),
        ],
      ),
      PlaygroundGroup(
        key: 'micro',
        title: '稳定后，你要做的最小行动',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'one_sentence', label: '说/写第一句'),
          PlaygroundOption(id: 'send', label: '发一条消息'),
          PlaygroundOption(id: 'step', label: '走 2 分钟'),
          PlaygroundOption(id: 'list', label: '写下 1 个下一步'),
          PlaygroundOption(id: 'reduce', label: '删掉 1 个任务'),
          PlaygroundOption(id: 'ask', label: '向人求助 1 次'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackScene = PlaygroundOption(id: 'panic', label: '突然紧张/心跳快');
      const fallbackSignal = PlaygroundOption(id: 'heart', label: '心跳快');
      const fallbackReframe = PlaygroundOption(id: 'prepare', label: '这表示身体在准备应对');
      const fallbackCalm = PlaygroundOption(id: 'breath_4_6', label: '呼吸 4-6');
      const fallbackMicro = PlaygroundOption(id: 'list', label: '写下 1 个下一步');

      final scene = _one(picks, 'scene', fallbackScene);
      final signal = _one(picks, 'signal', fallbackSignal);
      final reframe = _one(picks, 'reframe', fallbackReframe);
      final calm = _one(picks, 'calm', fallbackCalm);
      final micro = _one(picks, 'micro', fallbackMicro);

      final title = '身心回路：先稳再做';
      final summary = '''场景：${scene.label}；信号：${signal.label}。
我先做「${_hintOrLabel(calm)}」稳定身体，再对自己说「${reframe.label}」，然后做最小行动「${micro.label}」。''';

      final steps = <String>[
        '命名：我现在感到 ${signal.label}（不评判）。',
        '稳定：${_hintOrLabel(calm)}。',
        '解释：${reframe.label}。',
        '行动：${micro.label}（只做最小一步）。',
        '记录：稳定后我的体验变化是___（0-10）。',
      ];

      final why = '期待/解释会影响注意力与紧张度，从而影响体验。先稳住身体，再给出可相信解释，会让行动更容易发生。';

      final example = '''例子：你在「${scene.label}」前出现「${signal.label}」。
你不把它当成失败预告，而是先做「${calm.label}」，再说「${reframe.label}」。
当身体降噪后，你就能做出「${micro.label}」这一步。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 7) Growth mindset
  'growth_mindset': ConceptPlaygroundConfig(
    conceptId: 'growth_mindset',
    intro: '选择一句常见“固定心态台词”，再选择翻译策略与下一步练习，让信念落到可控变量。',
    groups: const [
      PlaygroundGroup(
        key: 'fixed',
        title: '你最近更像哪句固定心态台词',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'not_good', label: '我不行'),
          PlaygroundOption(id: 'stupid', label: '我太笨了'),
          PlaygroundOption(id: 'perfect', label: '我必须完美'),
          PlaygroundOption(id: 'talent', label: '我没天赋'),
          PlaygroundOption(id: 'compare', label: '别人都比我强'),
          PlaygroundOption(id: 'fail_once', label: '失败一次就说明没戏'),
        ],
      ),
      PlaygroundGroup(
        key: 'translate',
        title: '你想用哪种“翻译方式”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'yet', label: '加上“还没”', hint: '我还没学会'),
          PlaygroundOption(id: 'strategy', label: '换成策略', hint: '我需要换方法'),
          PlaygroundOption(id: 'practice', label: '换成练习', hint: '我需要练几次'),
          PlaygroundOption(id: 'info', label: '换成信息', hint: '失败=信息'),
          PlaygroundOption(id: 'process', label: '换成过程', hint: '今天只练一步'),
        ],
      ),
      PlaygroundGroup(
        key: 'next',
        title: '下一步要练什么（越具体越好）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'repeat', label: '重复练 2 次'),
          PlaygroundOption(id: 'ask', label: '问一个人/找一个示范'),
          PlaygroundOption(id: 'break', label: '拆成更小步骤'),
          PlaygroundOption(id: 'timer', label: '计时 5 分钟练习'),
          PlaygroundOption(id: 'feedback', label: '收集 1 条反馈'),
          PlaygroundOption(id: 'record', label: '记录 1 个改进点'),
        ],
      ),
      PlaygroundGroup(
        key: 'praise',
        title: '你要用哪种“过程语言”鼓励自己',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'effort', label: '我很努力', hint: '我坚持了___分钟'),
          PlaygroundOption(id: 'strategy', label: '我用了策略', hint: '我试了___方法'),
          PlaygroundOption(id: 'progress', label: '我有进步', hint: '比昨天更___'),
          PlaygroundOption(id: 'courage', label: '我很勇敢', hint: '我敢尝试'),
          PlaygroundOption(id: 'learning', label: '我在学习', hint: '我学到了___'),
        ],
      ),
    ],
    generator: (picks) {
      const fixedFb = PlaygroundOption(id: 'not_good', label: '我不行');
      const transFb = PlaygroundOption(id: 'yet', label: '加上“还没”');
      const nextFb = PlaygroundOption(id: 'break', label: '拆成更小步骤');
      const praiseFb = PlaygroundOption(id: 'learning', label: '我在学习');

      final fixed = _one(picks, 'fixed', fixedFb);
      final trans = _one(picks, 'translate', transFb);
      final next = _one(picks, 'next', nextFb);
      final praise = _one(picks, 'praise', praiseFb);

      String translated;
      switch (trans.id) {
        case 'yet':
          translated = '${fixed.label} → 我还没学会，但我能通过练习变好。';
          break;
        case 'strategy':
          translated = '${fixed.label} → 我需要换一个策略/方法。';
          break;
        case 'practice':
          translated = '${fixed.label} → 我需要练几次，把它练出来。';
          break;
        case 'info':
          translated = '${fixed.label} → 这次失败给了我信息：下一次可以改___。';
          break;
        default:
          translated = '${fixed.label} → 今天我只练一步（不审判自己）。';
      }

      final title = '成长心态翻译卡';
      final summary = '''固定台词：${fixed.label}
翻译方式：${trans.label}
翻译结果：$translated
下一步练习：${next.label}；过程鼓励：${praise.label}。''';

      final steps = <String>[
        '把固定台词写下来：${fixed.label}。',
        '做翻译：$translated',
        '立刻做一次练习：${next.label}（先 5 分钟）。',
        '用过程语言鼓励自己：${praise.label}（写一句具体的）。',
      ];

      final why = '当你把价值绑在“天赋/结果”，困难会威胁自我概念；把注意力转到“策略/练习”，你更敢继续并更容易坚持。';

      final example = '''例子：你学口语时冒出「${fixed.label}」。
你用「${trans.label}」把它翻译成可练习版本，并立刻做「${next.label}」。
你不是在证明自己，而是在收集进步证据。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 8) Relationship cultivate
  'relationship_cultivate': ConceptPlaygroundConfig(
    conceptId: 'relationship_cultivate',
    intro: '把冲突从“找错人/不被爱”改写成“我们要练一个技能”，并生成可复制的对话脚本。',
    groups: const [
      PlaygroundGroup(
        key: 'conflict',
        title: '最近更像哪类矛盾',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'forget', label: '忘事/没回应'),
          PlaygroundOption(id: 'late', label: '迟到/爽约'),
          PlaygroundOption(id: 'cold', label: '冷战/回避'),
          PlaygroundOption(id: 'chores', label: '家务分工'),
          PlaygroundOption(id: 'money', label: '金钱观/花钱'),
          PlaygroundOption(id: 'parents', label: '父母/育儿'),
          PlaygroundOption(id: 'work', label: '工作占用'),
        ],
      ),
      PlaygroundGroup(
        key: 'need',
        title: '你更在意的需求是什么',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'respect', label: '被尊重'),
          PlaygroundOption(id: 'security', label: '安全感'),
          PlaygroundOption(id: 'care', label: '被在意'),
          PlaygroundOption(id: 'fair', label: '公平'),
          PlaygroundOption(id: 'closeness', label: '亲近感'),
          PlaygroundOption(id: 'trust', label: '信任'),
        ],
      ),
      PlaygroundGroup(
        key: 'skill',
        title: '这次要练哪个技能',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'express', label: '表达需求', hint: '不指责'),
          PlaygroundOption(id: 'repair', label: '修复对话', hint: '先连接'),
          PlaygroundOption(id: 'boundary', label: '边界与规则', hint: '提前约定'),
          PlaygroundOption(id: 'listen', label: '倾听与复述', hint: '确认理解'),
          PlaygroundOption(id: 'plan', label: '共同计划', hint: '建立机制'),
        ],
      ),
      PlaygroundGroup(
        key: 'micro',
        title: '今天最小的经营动作',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '3sent', label: '发 3 句话脚本', hint: '我感受/我在意/我希望'),
          PlaygroundOption(id: '10min', label: '约 10 分钟谈一次'),
          PlaygroundOption(id: 'apology', label: '先说一句修复', hint: '我想好好聊'),
          PlaygroundOption(id: 'rule', label: '写一个规则', hint: '提醒/分工表'),
          PlaygroundOption(id: 'praise', label: '说一句具体感谢'),
          PlaygroundOption(id: 'date', label: '安排一个小约会'),
        ],
      ),
    ],
    generator: (picks) {
      const conflictFb = PlaygroundOption(id: 'forget', label: '忘事/没回应');
      const needFb = PlaygroundOption(id: 'care', label: '被在意');
      const skillFb = PlaygroundOption(id: 'express', label: '表达需求');
      const microFb = PlaygroundOption(id: '3sent', label: '发 3 句话脚本');

      final conflict = _one(picks, 'conflict', conflictFb);
      final need = _one(picks, 'need', needFb);
      final skill = _one(picks, 'skill', skillFb);
      final micro = _one(picks, 'micro', microFb);

      final title = '关系经营卡：练${skill.label}';
      final script = '① 我感到___（比如：难过/失望）\n② 我在意的是「${need.label}」\n③ 我希望我们能试___（一个具体可行的请求）';

      final summary = '''矛盾类型：${conflict.label}。
核心需求：${need.label}。
本次练习技能：${skill.label}。
今天最小动作：${micro.label}。
可复制脚本：\n$script''';

      final steps = <String>[
        '先把“解释”从人身攻击改成需求：我在意的是「${need.label}」。',
        '选择技能：${skill.label}。',
        '使用三段式脚本（复制即可）：\n$script',
        '完成最小动作：${micro.label}。',
        '复盘：我们做对了什么？下次想把哪一步做得更温和？',
      ];

      final why = '把关系看成“经营与练习”，冲突就从“找错人”变成“练技能”。解释改变，行为与结果也会改变。';

      final example = '''例子：因为「${conflict.label}」你很生气。
你不直接定性“你不在乎”，而是用脚本表达「${need.label}」。
当你把沟通变得更具体、更可执行，关系更容易进入修复与成长。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 9) Permission to be human
  'permission_human': ConceptPlaygroundConfig(
    conceptId: 'permission_human',
    intro: '把“情绪”从敌人变成信息：先允许 90 秒，再做一件最小照顾动作，最后回到行动。',
    groups: const [
      PlaygroundGroup(
        key: 'emotion',
        title: '你现在更像哪种情绪',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'sad', label: '难过'),
          PlaygroundOption(id: 'angry', label: '愤怒'),
          PlaygroundOption(id: 'anxious', label: '焦虑'),
          PlaygroundOption(id: 'guilty', label: '内疚'),
          PlaygroundOption(id: 'jealous', label: '嫉妒'),
          PlaygroundOption(id: 'numb', label: '麻木/空'),
          PlaygroundOption(id: 'shame', label: '羞耻'),
        ],
      ),
      PlaygroundGroup(
        key: 'need',
        title: '它可能在提醒你什么需求',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'rest', label: '需要休息'),
          PlaygroundOption(id: 'support', label: '需要支持'),
          PlaygroundOption(id: 'boundary', label: '需要边界'),
          PlaygroundOption(id: 'fair', label: '需要公平'),
          PlaygroundOption(id: 'meaning', label: '需要意义/方向'),
          PlaygroundOption(id: 'care', label: '需要被在意'),
        ],
      ),
      PlaygroundGroup(
        key: 'allow',
        title: '允许句（对自己说）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'normal', label: '这很正常，我允许它存在 90 秒'),
          PlaygroundOption(id: 'human', label: '我只是个人，我不需要完美'),
          PlaygroundOption(id: 'safe', label: '我现在是安全的'),
          PlaygroundOption(id: 'signal', label: '这是信息，不是判决'),
          PlaygroundOption(id: 'pass', label: '它会过去的，我先呼气'),
        ],
      ),
      PlaygroundGroup(
        key: 'care',
        title: '最小照顾动作',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'water', label: '喝一口水'),
          PlaygroundOption(id: 'walk', label: '走 2 分钟'),
          PlaygroundOption(id: 'stretch', label: '拉伸 60 秒'),
          PlaygroundOption(id: 'text', label: '发一句“我需要你”'),
          PlaygroundOption(id: 'desk', label: '整理桌面 1 分钟'),
          PlaygroundOption(id: 'shower', label: '洗把脸/洗手'),
        ],
      ),
      PlaygroundGroup(
        key: 'return',
        title: '回到行动：下一步最小是什么',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'one_step', label: '做下一步 2 分钟'),
          PlaygroundOption(id: 'one_msg', label: '发一条推进消息'),
          PlaygroundOption(id: 'write1', label: '写第一句'),
          PlaygroundOption(id: 'reduce', label: '删掉 1 个任务'),
          PlaygroundOption(id: 'ask', label: '求助 1 次'),
        ],
      ),
    ],
    generator: (picks) {
      const emoFb = PlaygroundOption(id: 'anxious', label: '焦虑');
      const needFb = PlaygroundOption(id: 'rest', label: '需要休息');
      const allowFb = PlaygroundOption(id: 'normal', label: '这很正常，我允许它存在 90 秒');
      const careFb = PlaygroundOption(id: 'water', label: '喝一口水');
      const retFb = PlaygroundOption(id: 'one_step', label: '做下一步 2 分钟');

      final emo = _one(picks, 'emotion', emoFb);
      final need = _one(picks, 'need', needFb);
      final allow = _one(picks, 'allow', allowFb);
      final care = _one(picks, 'care', careFb);
      final ret = _one(picks, 'return', retFb);

      final title = '允许区行动卡';
      final summary = '''情绪：${emo.label}；需求：${need.label}。
我先说「${allow.label}」，做一个照顾动作「${care.label}」，然后回到最小行动「${ret.label}」。''';

      final steps = <String>[
        '命名：我正在感到「${emo.label}」。',
        '允许：${allow.label}（计时 90 秒，只呼气）。',
        '照顾：${care.label}。',
        '回归：${ret.label}。',
        '记录：我照顾了自己，这说明___。',
      ];

      final why = '允许并不等于放任。先容纳情绪能降低内耗，再回到最小行动，才更可持续。';

      final example = '''例子：你因为某事感到「${emo.label}」。
你不压抑，也不被它带走，而是先允许 90 秒，再做「${care.label}」。
当你回到「${ret.label}」，你就在训练“痛苦后仍能行动”的能力。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 10) Active agent
  'active_agent': ConceptPlaygroundConfig(
    conceptId: 'active_agent',
    intro: '选择一个卡点，把痛苦放进时间盒，然后做一个最小主动行为，生成证据。',
    groups: const [
      PlaygroundGroup(
        key: 'stuck',
        title: '你现在卡在哪类情境',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'rejected', label: '被拒绝/被否定'),
          PlaygroundOption(id: 'failed', label: '失败/没达标'),
          PlaygroundOption(id: 'criticized', label: '被批评'),
          PlaygroundOption(id: 'lonely', label: '孤独/没人懂'),
          PlaygroundOption(id: 'overwhelmed', label: '事情太多'),
          PlaygroundOption(id: 'stuck_start', label: '就是启动不了'),
        ],
      ),
      PlaygroundGroup(
        key: 'timebox',
        title: '给痛苦的时间盒',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '3m', label: '3 分钟'),
          PlaygroundOption(id: '5m', label: '5 分钟'),
          PlaygroundOption(id: '10m', label: '10 分钟'),
          PlaygroundOption(id: '15m', label: '15 分钟'),
        ],
      ),
      PlaygroundGroup(
        key: 'micro',
        title: '最小主动行为',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'apply', label: '投/约下一次机会'),
          PlaygroundOption(id: 'edit1', label: '改 1 行/补 1 句'),
          PlaygroundOption(id: 'ask_help', label: '求助 1 次'),
          PlaygroundOption(id: 'practice', label: '练 1 次'),
          PlaygroundOption(id: 'clean', label: '清理 1 分钟'),
          PlaygroundOption(id: 'plan1', label: '写 1 个下一步'),
        ],
      ),
      PlaygroundGroup(
        key: 'evidence',
        title: '证据句（完成后写）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'i_did', label: '我做到了___'),
          PlaygroundOption(id: 'i_can', label: '我可以___'),
          PlaygroundOption(id: 'i_stepped', label: '我迈出了___'),
          PlaygroundOption(id: 'i_handled', label: '我能处理___'),
          PlaygroundOption(id: 'i_learned', label: '我学到了___'),
        ],
      ),
    ],
    generator: (picks) {
      const stuckFb = PlaygroundOption(id: 'stuck_start', label: '就是启动不了');
      const tbFb = PlaygroundOption(id: '5m', label: '5 分钟');
      const microFb = PlaygroundOption(id: 'plan1', label: '写 1 个下一步');
      const evFb = PlaygroundOption(id: 'i_stepped', label: '我迈出了___');

      final stuck = _one(picks, 'stuck', stuckFb);
      final tb = _one(picks, 'timebox', tbFb);
      final micro = _one(picks, 'micro', microFb);
      final ev = _one(picks, 'evidence', evFb);

      final title = '主动者行动卡';
      final summary = '''卡点：${stuck.label}。
我允许自己难受 ${tb.label}，然后做最小主动行为「${micro.label}」。
完成后写证据句：${ev.label}。''';

      final steps = <String>[
        '时间盒：允许情绪存在 ${tb.label}（不压抑）。',
        '按下“开始”只做一个动作：${micro.label}。',
        '完成后写证据：${ev.label}（越具体越好）。',
        '下一步再小一点：明天我只需要___。',
      ];

      final why = '主动者不是不痛苦，而是痛苦后仍选择行动。行动会产出证据与掌控感，证据会反过来增强希望。';

      final example = '''例子：你因为「${stuck.label}」想放弃。
你先给自己 ${tb.label} 的空间，然后只做「${micro.label}」。
哪怕很小，它也会成为“我可以继续”的证据。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 11) Correct expectations
  'correct_expectations': ConceptPlaygroundConfig(
    conceptId: 'correct_expectations',
    intro: '把“外部事件=幸福承诺”拆开：你真正想要的是一种感受。我们为你生成一个“内在等价动作”。',
    groups: const [
      PlaygroundGroup(
        key: 'external',
        title: '你以为哪个外部事件会让我幸福',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'promotion', label: '升职/被认可'),
          PlaygroundOption(id: 'money', label: '赚更多钱'),
          PlaygroundOption(id: 'relationship', label: '脱单/关系更好'),
          PlaygroundOption(id: 'move', label: '搬家/换城市'),
          PlaygroundOption(id: 'buy', label: '买到某个东西'),
          PlaygroundOption(id: 'free_time', label: '有更多时间'),
          PlaygroundOption(id: 'body', label: '身材更好'),
        ],
      ),
      PlaygroundGroup(
        key: 'feeling',
        title: '你期待它带来的感受',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'freedom', label: '自由'),
          PlaygroundOption(id: 'security', label: '安全感'),
          PlaygroundOption(id: 'love', label: '被爱/被在意'),
          PlaygroundOption(id: 'pride', label: '自豪/价值感'),
          PlaygroundOption(id: 'peace', label: '平静'),
          PlaygroundOption(id: 'belong', label: '归属感'),
        ],
      ),
      PlaygroundGroup(
        key: 'equiv',
        title: '今天就能做的“内在等价动作”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'block_time', label: '给自己 30 分钟无打扰时间', hint: '自由'),
          PlaygroundOption(id: 'plan', label: '写一个可控计划', hint: '安全感'),
          PlaygroundOption(id: 'express', label: '表达一次真实需求', hint: '被爱'),
          PlaygroundOption(id: 'finish', label: '完成一个小任务并庆祝', hint: '自豪'),
          PlaygroundOption(id: 'breath', label: '做 5 分钟放松呼吸', hint: '平静'),
          PlaygroundOption(id: 'connect', label: '主动联系一个人', hint: '归属'),
        ],
      ),
      PlaygroundGroup(
        key: 'today',
        title: '你今天愿意立刻做哪一步',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'do_now', label: '现在就做 2 分钟'),
          PlaygroundOption(id: 'schedule', label: '今天安排到日程'),
          PlaygroundOption(id: 'prepare', label: '准备工具/环境'),
          PlaygroundOption(id: 'tell', label: '告诉一个人监督'),
          PlaygroundOption(id: 'track', label: '记录一次完成'),
        ],
      ),
    ],
    generator: (picks) {
      const exFb = PlaygroundOption(id: 'promotion', label: '升职/被认可');
      const feelFb = PlaygroundOption(id: 'pride', label: '自豪/价值感');
      const eqFb = PlaygroundOption(id: 'finish', label: '完成一个小任务并庆祝');
      const todayFb = PlaygroundOption(id: 'do_now', label: '现在就做 2 分钟');

      final external = _one(picks, 'external', exFb);
      final feeling = _one(picks, 'feeling', feelFb);
      final equiv = _one(picks, 'equiv', eqFb);
      final today = _one(picks, 'today', todayFb);

      final title = '正确期待：先得到${feeling.label}';
      final summary = '''外部期待：${external.label}。
你真正想要的感受：${feeling.label}。
今天的内在等价动作：${_hintOrLabel(equiv)}。
落地方式：${today.label}。''';

      final steps = <String>[
        '把幸福承诺拆开：我想要的是「${feeling.label}」。',
        '做内在等价动作：${_hintOrLabel(equiv)}。',
        '用${today.label}把它落地（不要只停留在想象）。',
        '复盘：今天我获得了多少${feeling.label}（0-10）？',
      ];

      final why = '外部变化常带来短期波动；长期体验更依赖注意力、解释与习惯。先用内在等价动作获得状态，幸福更可控。';

      final example = '''例子：你以为「${external.label}」会让你幸福。
你发现自己真正想要的是「${feeling.label}」。
于是你今天先做「${equiv.label}」，并用「${today.label}」落地。
你把幸福从“等未来发生”变成“今天可经营”。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 12) Emotion -> Motion
  'emotion_to_motion': ConceptPlaygroundConfig(
    conceptId: 'emotion_to_motion',
    intro: '把目标从口号变成“能看见、能感觉到的画面”，用画面唤起情绪，从而推动行动。',
    groups: const [
      PlaygroundGroup(
        key: 'goal',
        title: '你想推动的目标领域',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'health', label: '健康/运动'),
          PlaygroundOption(id: 'study', label: '学习/考试'),
          PlaygroundOption(id: 'work', label: '工作/项目'),
          PlaygroundOption(id: 'relationship', label: '关系/沟通'),
          PlaygroundOption(id: 'emotion', label: '情绪/心态'),
          PlaygroundOption(id: 'habit', label: '习惯/自律'),
        ],
      ),
      PlaygroundGroup(
        key: 'scene',
        title: '你想把自己放进哪种画面',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'desk', label: '坐在书桌前开始'),
          PlaygroundOption(id: 'outdoor', label: '户外走动/跑步'),
          PlaygroundOption(id: 'meeting', label: '清晰表达的会议'),
          PlaygroundOption(id: 'home', label: '整洁的家与稳定节奏'),
          PlaygroundOption(id: 'phone', label: '放下手机的夜晚'),
          PlaygroundOption(id: 'studio', label: '安静创作的小角落'),
        ],
      ),
      PlaygroundGroup(
        key: 'sense',
        title: '你想用哪个感官线索增强画面',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'see', label: '我看见…', hint: '具体物体/动作'),
          PlaygroundOption(id: 'hear', label: '我听见…', hint: '声音/话语'),
          PlaygroundOption(id: 'feel', label: '我身体感觉…', hint: '呼吸/肩膀'),
          PlaygroundOption(id: 'smell', label: '我闻到…', hint: '咖啡/空气'),
          PlaygroundOption(id: 'touch', label: '我触摸到…', hint: '键盘/鞋带'),
        ],
      ),
      PlaygroundGroup(
        key: 'tone',
        title: '你希望自己处在什么情绪色调',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'calm', label: '平静'),
          PlaygroundOption(id: 'energized', label: '有能量'),
          PlaygroundOption(id: 'curious', label: '好奇'),
          PlaygroundOption(id: 'brave', label: '勇敢'),
          PlaygroundOption(id: 'warm', label: '温暖'),
          PlaygroundOption(id: 'steady', label: '稳定'),
        ],
      ),
      PlaygroundGroup(
        key: 'first',
        title: '让画面落地的第一步',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'two_min', label: '先做 2 分钟'),
          PlaygroundOption(id: 'prep', label: '先准备工具/环境'),
          PlaygroundOption(id: 'start', label: '写/说第一句'),
          PlaygroundOption(id: 'timer', label: '启动计时器'),
          PlaygroundOption(id: 'message', label: '发一条推进消息'),
          PlaygroundOption(id: 'step_out', label: '出门走 2 分钟'),
        ],
      ),
    ],
    generator: (picks) {
      const goalFb = PlaygroundOption(id: 'work', label: '工作/项目');
      const sceneFb = PlaygroundOption(id: 'desk', label: '坐在书桌前开始');
      const senseFb = PlaygroundOption(id: 'see', label: '我看见…');
      const toneFb = PlaygroundOption(id: 'steady', label: '稳定');
      const firstFb = PlaygroundOption(id: 'two_min', label: '先做 2 分钟');

      final goal = _one(picks, 'goal', goalFb);
      final scene = _one(picks, 'scene', sceneFb);
      final sense = _one(picks, 'sense', senseFb);
      final tone = _one(picks, 'tone', toneFb);
      final first = _one(picks, 'first', firstFb);

      final title = '画面驱动：${tone.label}地开始';
      final summary = '''目标领域：${goal.label}。
画面：${scene.label}。
感官线索：${sense.label}；情绪色调：${tone.label}。
第一步：${first.label}。''';

      final steps = <String>[
        '闭眼 10 秒，把画面放大：${scene.label}。',
        '用一句话写出感官线索：${sense.label}（越具体越好）。',
        '命名色调：我想以「${tone.label}」开始。',
        '立刻落地：${first.label}。',
        '复盘：画面是否让行动更容易？下次我想换哪个线索？',
      ];

      final why = '情绪会驱动动作（emotion → motion）。具体画面更容易激活情绪与动机，从而让行动启动更顺。';

      final example = '''例子：你在${goal.label}上很难开始。
你不再说“我要自律”，而是把自己放进画面「${scene.label}」，并用「${tone.label}」的感觉启动。
当你做出「${first.label}」，你是在把抽象目标变成可执行的下一步。''';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),
};

// ---------- meta "make it real" groups (applied to ALL concepts) ----------

const PlaygroundGroup _metaSceneGroup = PlaygroundGroup(
  key: 'meta_scene',
  title: '落地场景：你希望把这张卡用在',
  description: '同一个动作，放在不同场景里“阻力”会完全不同。先选场景再落地。',
  mode: SelectionMode.single,
  options: [
    PlaygroundOption(id: 'default', label: '随便/不限定'),
    PlaygroundOption(id: 'work', label: '工作/职场'),
    PlaygroundOption(id: 'study', label: '学习/考试'),
    PlaygroundOption(id: 'relationship', label: '关系/沟通'),
    PlaygroundOption(id: 'health', label: '健康/体能'),
    PlaygroundOption(id: 'home', label: '家务/家庭'),
    PlaygroundOption(id: 'money', label: '金钱/消费'),
  ],
);

const PlaygroundGroup _metaObstacleGroup = PlaygroundGroup(
  key: 'meta_obstacle',
  title: '主要阻力：此刻最拦你的是',
  description: '阻力不是“你不够好”，而是系统里有一个环节缺支撑。',
  mode: SelectionMode.single,
  options: [
    PlaygroundOption(id: 'default', label: '不确定'),
    PlaygroundOption(id: 'start', label: '很难开始'),
    PlaygroundOption(id: 'focus', label: '注意力容易跑'),
    PlaygroundOption(id: 'emotion', label: '情绪太强'),
    PlaygroundOption(id: 'friction', label: '环境阻力/太麻烦'),
    PlaygroundOption(id: 'people', label: '他人影响/社交压力'),
    PlaygroundOption(id: 'confidence', label: '不相信自己能做到'),
  ],
);

const PlaygroundGroup _metaBoostersGroup = PlaygroundGroup(
  key: 'meta_boosters',
  title: '加成道具（最多选 3 个）',
  description: '像游戏一样：给行动加 buff（更容易开始/更容易坚持）。',
  mode: SelectionMode.multi,
  maxSelect: 3,
  options: [
    PlaygroundOption(id: 'countdown', label: '10 秒倒计时', hint: '倒计时到 0 就做第一步'),
    PlaygroundOption(id: 'timer', label: '只做 10 分钟', hint: '降低开始门槛'),
    PlaygroundOption(id: 'buddy', label: '找一个同伴提醒', hint: '一句话打卡'),
    PlaygroundOption(id: 'remove', label: '先移除一个干扰', hint: '手机远离/关通知'),
    PlaygroundOption(id: 'prepare', label: '把材料放到第一视线', hint: '打开文档/摆好器材'),
    PlaygroundOption(id: 'ifthen', label: '如果-那么计划', hint: '如果分心→那么拉回'),
    PlaygroundOption(id: 'reward', label: '小奖励', hint: '完成后给自己一点甜头'),
    PlaygroundOption(id: 'public', label: '公开承诺', hint: '对一个人说“我会做”'),
  ],
);

const PlaygroundGroup _metaRewardGroup = PlaygroundGroup(
  key: 'meta_reward',
  title: '完成后的小奖励',
  description: '奖励不是“贿赂”，而是让大脑把“行动”与“正反馈”绑定。',
  mode: SelectionMode.single,
  options: [
    PlaygroundOption(id: 'none', label: '不需要奖励'),
    PlaygroundOption(id: 'tea', label: '一杯喜欢的饮品'),
    PlaygroundOption(id: 'walk', label: '走 3 分钟/伸展'),
    PlaygroundOption(id: 'music', label: '听一首歌'),
    PlaygroundOption(id: 'mark', label: '在日历打 ✅'),
    PlaygroundOption(id: 'share', label: '发给同伴一个“我做到了”'),
  ],
);

const List<PlaygroundGroup> _metaGroups = [_metaSceneGroup, _metaObstacleGroup, _metaBoostersGroup, _metaRewardGroup];

ConceptPlaygroundConfig _wrapWithMeta(ConceptPlaygroundConfig base) {
  return ConceptPlaygroundConfig(
    conceptId: base.conceptId,
    intro: '${base.intro}\n\n最后一步：选择“落地场景/阻力/加成”，让行动卡更像你自己的。',
    groups: [...base.groups, ..._metaGroups],
    generator: (picks) {
      final card = base.generator(picks);
      const sceneFb = PlaygroundOption(id: 'default', label: '随便/不限定');
      const obsFb = PlaygroundOption(id: 'default', label: '不确定');
      const rewFb = PlaygroundOption(id: 'none', label: '不需要奖励');

      final scene = _one(picks, 'meta_scene', sceneFb);
      final obstacle = _one(picks, 'meta_obstacle', obsFb);
      final boosters = _many(picks, 'meta_boosters');
      final reward = _one(picks, 'meta_reward', rewFb);

      final boosterText = boosters.isEmpty ? '无' : _joinLabels(boosters, empty: '无');
      final rewardText = reward.id == 'none' ? '无' : reward.label;

      final summary = '${card.summary}\n\n落地设置：场景=${scene.label}；主要阻力=${obstacle.label}；加成=${boosterText}；奖励=${rewardText}。';

      final steps = <String>[
        '场景锁定：把这张卡用在「${scene.label}」这个场景。',
        if (obstacle.id != 'default') '识别阻力：当前最大阻力是「${obstacle.label}」。先解决它，而不是怪自己。',
        if (boosters.isNotEmpty) '加成道具：${boosterText}（把它们提前准备好）。',
        ...card.steps,
        if (reward.id != 'none') '完成后立刻奖励自己：${reward.label}（让大脑把行动=正反馈）。',
      ];

      final why = '${card.whyShort} 另外，把行动放进具体场景，并用“阻力诊断 + 加成道具 + 小奖励”，会显著提高执行概率。';

      final example = '${card.example}\n\n把它放进你的场景：${scene.label}。当你卡住时，先问：阻力是「${obstacle.label}」还是“没加 buff”？然后加一个最小加成（例如倒计时/只做 10 分钟）。';

      return ActionCard(title: card.title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  );
}

ConceptPlaygroundConfig? getPlaygroundConfig(String conceptId) {
  final base = kConceptPlaygrounds[conceptId];
  if (base == null) return null;
  return _wrapWithMeta(base);
}

/// Public helper for other lesson modules.
///
/// It appends the same “落地设置：场景/阻力/加成/奖励” meta groups used by
/// the Belief Lab concepts, so course/path pages can reuse the wizard UX.
ConceptPlaygroundConfig wrapWithMeta(ConceptPlaygroundConfig base) => _wrapWithMeta(base);

/// Generate a random (but valid) selection set for a concept.
///
/// Used by UI “随机推荐一组” button.
Map<String, List<PlaygroundOption>> randomPicksFor(String conceptId, {int seed = 0}) {
  final cfg = getPlaygroundConfig(conceptId);
  if (cfg == null) return {};
  final rnd = Random(seed == 0 ? DateTime.now().microsecondsSinceEpoch : seed);
  final picks = <String, List<PlaygroundOption>>{};
  for (final g in cfg.groups) {
    if (g.options.isEmpty) continue;
    if (g.mode == SelectionMode.single) {
      picks[g.key] = [g.options[rnd.nextInt(g.options.length)]];
    } else {
      final maxSel = max(1, min(g.maxSelect, g.options.length));
      final k = 1 + rnd.nextInt(maxSel); // at least 1
      final shuffled = [...g.options]..shuffle(rnd);
      picks[g.key] = shuffled.take(k).toList();
    }
  }
  return picks;
}
