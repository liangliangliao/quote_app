/// Lightweight quiz (1 question per module) for Lecture 5–6 path.
///
/// Goal: immediate feedback to deepen understanding (not exam-level).
class Lecture56QuizItem {
  final String moduleId;
  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const Lecture56QuizItem({
    required this.moduleId,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });
}

final Map<String, Lecture56QuizItem> kLecture56Quiz = {
  'm01_contagious': Lecture56QuizItem(
    moduleId: 'm01_contagious',
    question: '课程里说“happiness is contagious”，最贴近的含义是什么？',
    options: [
      '你越幸福，别人就会越不幸福（零和）',
      '你的情绪会通过互动质量影响他人，形成“传染链”（正和）',
      '幸福完全取决于运气，无法练习',
      '幸福等于成功或财富',
    ],
    correctIndex: 1,
    explanation: '课上强调幸福是“正和游戏”，会通过微行为与互动质量扩散。重点不是口号，而是做出具体微行为。',
  ),
  'm02_broaden_build': Lecture56QuizItem(
    moduleId: 'm02_broaden_build',
    question: 'Broaden-and-Build 讲的是正向情绪的哪种作用？',
    options: [
      '让注意力变窄，更专注于威胁',
      '让你忘掉现实问题，不再行动',
      '拓展思维/行动选项，并在时间里建出资源（韧性/连接/创造力）',
      '让你永远保持兴奋，不能低落',
    ],
    correctIndex: 2,
    explanation: '正向情绪的关键不是“强迫开心”，而是加宽带宽，看到更多选项，并积累长期资源。',
  ),
  'm03_appreciation': Lecture56QuizItem(
    moduleId: 'm03_appreciation',
    question: '“when we appreciate the good, the good appreciates”更像在说什么？',
    options: [
      '欣赏就是客套话，没什么用',
      '欣赏会让对方立刻完美，不再犯错',
      '注意力会强化你指出的行为，让“做得对的部分”更容易被重复',
      '只要欣赏就不用提出问题',
    ],
    correctIndex: 2,
    explanation: '欣赏的重点在“具体可复制”。你关注/强化什么，系统就更可能进入上升螺旋。',
  ),
  'm04_modeling': Lecture56QuizItem(
    moduleId: 'm04_modeling',
    question: '以身作则这关想让你记住哪句话？',
    options: [
      'People mostly do what you do, rather than what you say.',
      '只要讲道理就能改变别人',
      '别人不会被环境影响',
      '改变从控制别人开始',
    ],
    correctIndex: 0,
    explanation: '示范会改变默认值与规范：先做出证据，再谈建议，影响力更稳。',
  ),
  'm05_situation': Lecture56QuizItem(
    moduleId: 'm05_situation',
    question: '“情境的力量”这关最核心的行动建议是什么？',
    options: [
      '靠意志硬扛，环境无所谓',
      '先把环境设计成队友，再谈努力',
      '先责怪自己，再考虑方法',
      '只要换个心情，一切自动解决',
    ],
    correctIndex: 1,
    explanation: '情境会把坏习惯设成默认选项。降低好习惯摩擦、增加坏习惯摩擦，比“更努力”更有效。',
  ),
  'm06_priming': Lecture56QuizItem(
    moduleId: 'm06_priming',
    question: 'Priming（启动效应）最贴近的比喻是？',
    options: ['给自己打鸡血', '在心里“种种子”（词/图/仪式会引导默认行为）', '完全靠运气', '压抑情绪'],
    correctIndex: 1,
    explanation: '启动效应强调线索：你反复看到/听到的东西会激活联想网络，改变你“更容易做什么”。',
  ),
  'm07_placebo': Lecture56QuizItem(
    moduleId: 'm07_placebo',
    question: 'Placebo（安慰剂）案例主要想说明什么？',
    options: [
      '外部世界不存在，只有想法',
      '信念不一定万能，但会参与体验与结果',
      '身体反应完全不受心智影响',
      '只要相信就不需要行动',
    ],
    correctIndex: 1,
    explanation: '正确的理解是：期待会影响注意力与解释方式，从而改变体验强度；但这不等于否认现实与行动。',
  ),
  'm08_motivation': Lecture56QuizItem(
    moduleId: 'm08_motivation',
    question: '信念如何变现实的“机制一”是什么？',
    options: ['动机：相信能通过练习变好，就更愿意投入与坚持', '神秘能量', '天赋决定论', '靠别人推着走'],
    correctIndex: 0,
    explanation: '信念先改变“愿不愿意投入”，投入量与坚持时间往往决定长期结果。',
  ),
  'm09_schema': Lecture56QuizItem(
    moduleId: 'm09_schema',
    question: '图式（schema）与“自洽”在这节课里是什么意思？',
    options: [
      '大脑喜欢不一致，越矛盾越舒服',
      '一旦有了默认信念，大脑会选择性注意/解释，让现实更像它',
      '图式是不可改变的天性',
      '图式只存在于童年，成年人没有',
    ],
    correctIndex: 1,
    explanation: '课上强调 mind likes consistency：不一致会带来不适，于是你会更新/忽略/找证据/创造现实来恢复一致。',
  ),
  'm10_alignment': Lecture56QuizItem(
    moduleId: 'm10_alignment',
    question: '当现实与信念冲突时，课程总结了哪“四种拉齐策略”？',
    options: [
      '逃避/否认/幻想/抱怨',
      '更新图式/忽略信息/寻找确认性证据/创造新现实',
      '吃药/祈祷/许愿/躺平',
      '只看运气/只看天赋/只看背景/只看关系',
    ],
    correctIndex: 1,
    explanation: '关键不是否认这个机制，而是用更好的问题与行动去创造新证据（questions create reality）。',
  ),
  'm11_reality': Lecture56QuizItem(
    moduleId: 'm11_reality',
    question: '课程为什么批评 The Secret 的“只靠想”版本？',
    options: [
      '因为信念完全没用',
      '因为它会过度承诺并引发内疚/受害者归因，忽略行动与现实限制',
      '因为它鼓励努力与纪律',
      '因为它强调三圈控制',
    ],
    correctIndex: 1,
    explanation: '课上说它“draws on a truth but blows it out of proportion”，会导致羞耻与错误归因；正确做法是回到可控行动。',
  ),
  'm12_stockdale': Lecture56QuizItem(
    moduleId: 'm12_stockdale',
    question: 'Stockdale 悖论的关键是把哪两件事同时抓住？',
    options: [
      '只要乐观，不要事实',
      '只看事实，不要希望',
      '终会胜利的信念 + 直面残酷事实的纪律',
      '完全随缘',
    ],
    correctIndex: 2,
    explanation: '成熟积极=不自欺：信念给你方向，事实给你策略与纪律。',
  ),
  'm13_selfeff': Lecture56QuizItem(
    moduleId: 'm13_selfeff',
    question: '自我效能的“最可靠来源”在课程里被强调是什么？',
    options: ['自我鼓励的口号', '别人夸我', '行动与小成功的证据（做过→能）', '运气'],
    correctIndex: 2,
    explanation: '自我效能不是鸡汤，而是“我做过”的证据感。最小可承担风险的行动，是最快的建构方式。',
  ),
  'm14_simulator': Lecture56QuizItem(
    moduleId: 'm14_simulator',
    question: '“内部模拟器（预演）”在课程里的正确位置是？',
    options: ['预演可以替代行动', '预演是行动的前奏：短预演后立刻真做一个小动作', '只预演失败，不做准备', '越想越好，不需要行动'],
    correctIndex: 1,
    explanation: '预演能激活线索与策略，但必须接上现实动作，才能变成证据并更新信念。',
  ),
  'm15_failure': Lecture56QuizItem(
    moduleId: 'm15_failure',
    question: '“failure is underrated / learn to fail”在这关想你怎么对待失败？',
    options: ['把失败当羞耻证据', '把失败当训练数据：事实化→可行动解释→最小改进', '永远避免失败', '失败说明一切结束'],
    correctIndex: 1,
    explanation: '失败像心理免疫系统：只要你能复盘成下一步，它就是增长材料。',
  ),
};

Lecture56QuizItem? getLecture56Quiz(String moduleId) => kLecture56Quiz[moduleId];
