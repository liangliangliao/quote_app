
import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../platform/perm_helper.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:characters/characters.dart';
import 'package:quote_app/widgets/poster_pure_flutter.dart';
import 'package:quote_app/widgets/wood_frame_card.dart';
import 'package:quote_app/services/notification_service.dart';
import '../data/dao.dart';
import '../data/emotions.dart';
import '../utils/debug_logger.dart';
import 'package:quote_app/services/native_guard.dart';



/// Local scroll behavior to hide glow/scrollbar and use clamping physics,
/// mirroring the helpers used in other widgets.
class _NoIndicatorScroll extends ScrollBehavior {
  @override
  Widget buildViewportChrome(BuildContext context, Widget child, AxisDirection axisDirection) => child;

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const ClampingScrollPhysics();
}


String _buildAuthorLine(String authorName, String source) {
  authorName = (authorName).trim();
  source = (source).trim();
  if (authorName.isEmpty && source.isEmpty) return '';
  final s = StringBuffer('——');
  if (authorName.isNotEmpty) {
    s.write(authorName);
    if (source.isNotEmpty) s.write('《' + source + '》');
  } else if (source.isNotEmpty) {
    s.write('《' + source + '》');
  }
  return s.toString();
}


  bool isShortTopic(String s) {
    try { return s.runes.length < 15; } catch (_) { return s.length < 15; }
  }
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  // Truncate huge strings for logging to avoid performance issues on phone.
  String _truncateForLog(String? s, {int maxLen = 140}) {
    if (s == null) return '';
    final str = s;
    if (str.length <= maxLen) return str;
    return str.substring(0, maxLen) + '...(truncated)';
  }

  Future<void> _logInject(String source, Map<String, dynamic> data) async {
    try {
      final _lp = Map<String, dynamic>.from(data);
      _lp['avatarUrl'] = _truncateForLog((_lp['avatarUrl'] ?? _lp['avatar'])?.toString());
      if (_lp.containsKey('bgUrl')) _lp['bgUrl'] = _truncateForLog((_lp['bgUrl'] ?? '').toString());
      if (_lp.containsKey('bgDataUrl')) _lp['bgDataUrl'] = _truncateForLog((_lp['bgDataUrl'] ?? '').toString());
      await LogDao().add(taskUid: 'home_inject', detail: json.encode({'source': source, 'payload': _lp}));
    } catch (_) {}
  }

  bool _sessionPrompted = false;

  Map<String, dynamic>? _todayData;
  Map<String, dynamic>? _latestRow;
  bool _firstLoaded = false;
  bool _fav = false;

  bool _liked = false;

  // 心情卡片相关状态
  bool _moodCardVisible = false;
  bool _moodCardMounted = false;
  late final AnimationController _moodCardController;
  final TextEditingController _behaviorController = TextEditingController();
  final TextEditingController _triggerController = TextEditingController();
  final TextEditingController _thoughtController = TextEditingController();
  EmojiItem? _selectedEmotion;
  bool _showEmojiPicker = false;
  bool _notifAsked = false;
  String? _firstBg; // first-frame bg data URI cache

  // Pinned (fixed) quotes state.  These lists store the loaded fixed quotes for
  // the bottom grey area.  `_pinnedQuotes` holds the current batch of
  // records, `_pinnedHasMore` indicates whether more can be loaded from the
  // database, and `_loadingPinned` prevents concurrent loads.  A dedicated
  // scroll controller listens for horizontal scrolls to trigger loading
  // additional pages.  `_pinnedActive` tracks whether the currently
  // displayed large quote is pinned.
  List<Map<String, dynamic>> _pinnedQuotes = [];
  bool _pinnedHasMore = false;
  bool _loadingPinned = false;
  final ScrollController _pinnedController = ScrollController();
  bool _pinnedActive = false;

  // 将背景图读取为 data URI（base64）。如果加载失败，返回 file uri 路径。
  Future<String> _getBgDataUrl() async {
    try {
      final data = await rootBundle.load('assets/bg-wood-upload.jpg');
      final bytes = data.buffer.asUint8List();
      final b64 = base64Encode(bytes);
      return 'data:image/jpeg;base64,$b64';
    } catch (_) {
      // fallback to file uri
      return 'file:///android_asset/flutter_assets/assets/bg-wood-upload.jpg';
    }
  }

  Future<void> _primeFirstBg() async {
    try {
      final s = await _getBgDataUrl();
      if (!mounted) return;
      setState(() { _firstBg = s; });
    } catch (_){ }
  }



  void _openLeftDrawer() {
    try {
      final scaffold = Scaffold.maybeOf(context);
      scaffold?.openDrawer();
    } catch (_) {}
  }

  void _handleTopBarMenu(String value) async {
    switch (value) {
      case 'share':
        // 沿用原来的分享行为：复制当前名言到剪贴板并提示
        await _copyLatest();
        break;
      case 'favorite':
        setState(() {
          _fav = !_fav;
        });
        break;
      case 'like':
        setState(() {
          _liked = !_liked;
        });
        try {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(_liked ? '已标记为喜欢' : '已取消喜欢'),
              duration: const Duration(milliseconds: 800),
            ),
          );
        } catch (_) {}
        break;
    }
  }

  // --- 心情卡片逻辑 ---

  static bool _moodCardShownThisSession = false;

  void _ensureShowMoodCardOncePerSession() {
    if (_moodCardShownThisSession) return;
    _moodCardShownThisSession = true;
    // 首帧之后再弹出，避免和首页其他动画冲突
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _showMoodCard();
    });
  }

  void _showMoodCard() {
    if (_moodCardVisible || !_moodCardMounted) {
      // 如果尚未挂载，先挂载再启动动画
      if (!_moodCardMounted) {
        setState(() {
          _moodCardMounted = true;
        });
      }
      // 延迟一个frame确保Overlay已经构建
      WidgetsBinding.instance.addPostFrameCallback((_) {
        try {
          _moodCardController.forward(from: 0);
          setState(() {
            _moodCardVisible = true;
          });
        } catch (_) {}
      });
    } else {
      try {
        _moodCardController.forward(from: 0);
      } catch (_) {}
      setState(() {
        _moodCardVisible = true;
      });
    }
  }

  Future<void> _hideMoodCard() async {
    try {
      await _moodCardController.reverse();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _moodCardVisible = false;
      _showEmojiPicker = false;
    });
  }

  Future<void> _onShareMood() async {
    final emoji = _selectedEmotion;
    if (emoji == null) {
      try {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请选择情绪状态')),
        );
      } catch (_) {}
      return;
    }
    String limit500(String s) => s.length > 500 ? s.substring(0, 500) : s;
    final behavior = limit500(_behaviorController.text.trim());
    final trigger = limit500(_triggerController.text.trim());
    final thought = limit500(_thoughtController.text.trim());
    try {
      await EmotionDao().insert(
        emojiChar: emoji.char,
        emojiName: emoji.name,
        emojiTags: emoji.tags,
        behavior: behavior,
        triggerEvent: trigger,
        thought: thought,
      );
    } catch (_) {}
    await _hideMoodCard();
    // 清理输入，方便下次使用
    _behaviorController.clear();
    _triggerController.clear();
    _thoughtController.clear();
    setState(() {
      _selectedEmotion = null;
    });
  }

  Widget _buildMoodCardOverlay() {
    if (!_moodCardMounted) return const SizedBox.shrink();
    return Positioned.fill(
      child: IgnorePointer(
        ignoring: !_moodCardVisible,
        child: AnimatedBuilder(
          animation: _moodCardController,
          builder: (context, child) {
            // 使用 SlideTransition 让卡片从屏幕上方缓慢弹出 / 收起
            final slide = Tween<Offset>(
              begin: const Offset(0, -1),
              end: Offset.zero,
            ).animate(
              CurvedAnimation(
                parent: _moodCardController,
                curve: Curves.easeOutCubic,
                reverseCurve: Curves.easeInCubic,
              ),
            );
            return Stack(
              children: [
                // 点击卡片外任意位置关闭
                GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: _hideMoodCard,
                  child: Container(color: Colors.transparent),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: SlideTransition(
                    position: slide,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 40, left: 16, right: 16),
                      child: _buildMoodCard(),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildMoodCard() {
    final emoji = _selectedEmotion;
    final String emojiSummary = emoji == null
        ? ''
        : '${emoji.char}  ${emoji.name}  ${emoji.tags.join(' ')}';
    return Material(
      elevation: 12,
      borderRadius: BorderRadius.circular(16),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            if (_showEmojiPicker) {
              setState(() {
                _showEmojiPicker = false;
              });
            }
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
            // 标题行
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '分享此时此刻的心情',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  tooltip: '关闭',
                  onPressed: _hideMoodCard,
                ),
              ],
            ),
            const SizedBox(height: 8),
            // 第一行：情绪状态 + 下划线 + 选择的表情
            Center(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _showEmojiPicker = true;
                  });
                },
                child: Column(
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('情绪'),
                        const SizedBox(width: 12),
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 260),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(color: Colors.black54, width: 1),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Text(
                                    emojiSummary,
                                    style: const TextStyle(fontSize: 14),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(width: 4),
                                const Icon(Icons.expand_more, size: 18),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (_showEmojiPicker) _buildEmojiPicker(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            // 第二行：行为
            _buildTextRow(label: '行为', controller: _behaviorController),
            const SizedBox(height: 8),
            // 第三行：事件
            _buildTextRow(label: '事件', controller: _triggerController),
            const SizedBox(height: 8),
            // 第四行：认知
            _buildTextRow(label: '认知', controller: _thoughtController),
            const SizedBox(height: 16),
            // 底部操作按钮
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: _hideMoodCard,
                  child: const Text('取消'),
                ),
                ElevatedButton(
                  onPressed: _onShareMood,
                  child: const Text('分享'),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
  }

  Widget _buildTextRow({required String label, required TextEditingController controller}) {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label),
          const SizedBox(width: 12),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 260),
            child: TextField(
              controller: controller,
              maxLines: null,
              maxLength: 500,
              decoration: const InputDecoration(
                isDense: true,
                counterText: '',
                border: UnderlineInputBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmojiPicker() {
    return Container(
      margin: const EdgeInsets.only(top: 4),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: SizedBox(
        height: 230,
        child: GridView.count(
          padding: const EdgeInsets.fromLTRB(4, 15, 4, 0),
          crossAxisCount: 6,
          mainAxisSpacing: 0,
          crossAxisSpacing: 0,
          childAspectRatio: 0.9,
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            for (final item in unicornEmotions)
              InkWell(
                onTap: () {
                  setState(() {
                    _selectedEmotion = item;
                    _showEmojiPicker = false;
                  });
                },
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(item.char, style: const TextStyle(fontSize: 20)),
                    const SizedBox(height: 4),
                    Text(
                      item.name,
                      style: const TextStyle(fontSize: 11),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
  @override
  void initState() {
    super.initState();
    _moodCardController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
    WidgetsBinding.instance.addObserver(this);
    SimpleBus.homeTick.addListener(_onBus);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      NotificationService.markHomeVisible();
      _checkNotificationPermission();
    });
    _primeFirstBg();
    _load();
    // Load pinned quotes immediately on first build
    _loadPinned(reset: true);

    // 每次从冷启动进入首页时，尝试弹出心情卡片
    _ensureShowMoodCardOncePerSession();
  }

  void _onBus() { _load(); }


  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SimpleBus.homeTick.removeListener(_onBus);
    // Dispose controllers for mood card
    try {
      _moodCardController.dispose();
    } catch (_) {}
    _behaviorController.dispose();
    _triggerController.dispose();
    _thoughtController.dispose();
    // Dispose the pinned scroll controller to free resources
    _pinnedController.dispose();
    super.dispose();
  }

  // removed redundant lifecycle reload to avoid non-first re-render

  Future<String> _avatarToDataUrl(String raw) async {
    final s = (raw).toString().trim();
    if (s.isEmpty) return '';
    if (s.startsWith('data:') || s.startsWith('http://') || s.startsWith('https://')) return s;
    try {
      final f = File(s);
      if (await f.exists()) {
        final bytes = await f.readAsBytes();
        String mime = 'image/png';
        final lower = s.toLowerCase();
        if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) mime = 'image/jpeg';
        else if (lower.endsWith('.webp')) mime = 'image/webp';
        else if (lower.endsWith('.gif')) mime = 'image/gif';
        final b64 = base64Encode(bytes);
        return 'data:$mime;base64,$b64';
      }
    } catch (_) {}
    return '';
  }


  void _requestNotifAfterFirstFrame() {
    if (_notifAsked) return;
    _notifAsked = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
            NotificationService.markHomeVisible();
try {
        bool enabled = true;
        try {
          enabled = await NotificationService.areNotificationsEnabled();
        } catch (_) { enabled = false; }
        if (enabled != true) {
          try { await NotificationService.request(); } catch (_) {}
          await _maybeAskExactAfterNotif();
        }
      } catch (_) {}
    });
  }

Future<bool> _isFirstOpenAndMarkLocal() async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, '.first_open_done'));
    if (await file.exists()) return false;
    await file.writeAsString(DateTime.now().toIso8601String());
    return true;
  } catch (_) { return false; }
}

Future<void> _maybeAskExactAfterNotif() async {
  bool enabled = true;
  try { enabled = await NotificationService.areNotificationsEnabled(); } catch (_){ enabled = false; }
  if (enabled != true) return;
  final first = await _isFirstOpenAndMarkLocal();
  if (!first) return;
  try {
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact && mounted) {
      final allow = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          content: const Text('为确保定时提醒准确，请在系统设置中允许“精确闹钟”。是否前往设置？'),
          actions: [
            TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('稍后')),
            FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('允许')),
          ],
        ),
      );
      if (allow == true) {
        try { await PermHelper.requestExactAlarmPermission(); } catch (_){}
      }
    }
  } catch (_){}
}
  Future<void> _load() async {
    // 仅在首次加载时将数据设为空以显示兜底，后续刷新保持原有数据避免闪屏
    if (!_firstLoaded) {
      setState(() { _todayData = null; _firstLoaded = true; });
    }
    try {
      final dao = QuoteDao();
      final latest = await dao.latestNotifiedToday();
      if (!mounted) return;
      _latestRow = latest;
      if (latest == null) {
        // 当查询不到今日数据时，注入固定的兜底内容而非 null。
        // 兜底内容与模板原始文案保持一致，这样即便无数据，也能通过 setDynamicData 渲染完整页面。
        await DLog.i('HOME', '今日未检索到已通知记录：注入兜底内容');
        final fallbackBg = await _getBgDataUrl();
        // 从资产 JSON 读取兜底内容
        final fbStr = await rootBundle.loadString('assets/fallback/camus_fallback.json');
        final Map<String, dynamic> fallback = json.decode(fbStr);
        fallback['bgUrl'] = fallbackBg; // 运行时覆盖背景
        await _logInject('json', fallback);
        if (mounted) setState(() { _todayData = fallback; });
        // Update pinned state after injecting fallback content
        await _checkPinnedState();
        _requestNotifAfterFirstFrame();
        } else {
        final avatarUrl = await _avatarToDataUrl((latest['avatar'] ?? '').toString());
        // 根据署名和出处组装 author 字段。若存在署名或出处则前缀“——”，否则为空
        final String authorName = (latest['author_name'] ?? latest['author'] ?? '').toString().trim();
        final String source = (latest['source_from'] ?? latest['source'] ?? '').toString().trim();
        String authorLine = '';
        if (authorName.isNotEmpty || source.isNotEmpty) {
          // 如果署名不为空，使用“——署名 出处”，否则仅加前缀
          authorLine = '——';
          if (authorName.isNotEmpty) {
            authorLine += authorName; if (source.isNotEmpty) { authorLine += '《' + source + '》'; }
          } else { authorLine += (source.isNotEmpty ? ('《' + source + '》') : ''); }
        }
        // 读取背景图为 data URI，使背景在各平台上稳定显示
        final bgUrl = await _getBgDataUrl();
        final payload = <String, dynamic>{
          'topic': (latest['theme'] ?? latest['topic'] ?? '').toString(),
          'quote': (latest['content'] ?? latest['quote'] ?? '').toString(),
          // 将 author 字段设置为包含署名和出处的组合文本
          'author': authorLine,
          'source': source,
          'note': (latest['explanation'] ?? latest['note'] ?? '').toString(),
          'avatarUrl': avatarUrl,
          // 将背景图片路径作为 data uri 传入，供 HTML 页通过 setBackground 使用。
          'bgUrl': bgUrl,
        };
        await DLog.i('HOME', '已检索到今日最新已通知记录：准备注入');
        await _logInject('db', payload);
        if (mounted) setState(() { _todayData = payload; });
      // Update pinned state after injecting DB content
      await _checkPinnedState();
      _requestNotifAfterFirstFrame();
      }
    } catch (e) {
      await DLog.e('HOME', '查询异常：注入兜底内容；err=$e');
      // 当查询发生异常时，注入兜底内容以保证页面不为空白
      final fallbackBg = await _getBgDataUrl();
        // 从资产 JSON 读取兜底内容
        final fbStr = await rootBundle.loadString('assets/fallback/camus_fallback.json');
        final Map<String, dynamic> fallback = json.decode(fbStr);
        fallback['bgUrl'] = fallbackBg; // 运行时覆盖背景
        await _logInject('json', fallback);
        if (mounted) setState(() { _todayData = fallback; });
        // Update pinned state after error fallback
        await _checkPinnedState();
        _requestNotifAfterFirstFrame();
        }
  }

  Future<void> _copyLatest() async {
    final text = (_latestRow?['content'] ?? '').toString();
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'), behavior: SnackBarBehavior.floating));
  }

  /// Load fixed quotes from the database.  When [reset] is true, clear the
  /// existing list and start from offset 0.  Otherwise, append the next
  /// page of results.  Each page fetches up to 20 records.  Updates
  /// [_pinnedQuotes], [_pinnedHasMore] and [_loadingPinned] accordingly.
  Future<void> _loadPinned({bool reset = false}) async {
    if (_loadingPinned) return;
    _loadingPinned = true;
    final dao = QuoteFixedDao();
    final offset = reset ? 0 : _pinnedQuotes.length;
    final rows = await dao.all(limit: 20, offset: offset);
    if (!mounted) return;
    setState(() {
      if (reset) {
        _pinnedQuotes = rows;
      } else {
        _pinnedQuotes.addAll(rows);
      }
      _pinnedHasMore = rows.length == 20;
      _loadingPinned = false;
    });
  }

  /// Build a single fixed quote card.  The card uses the home_small_frame
  /// image as the background and overlays the quote content scaled to fit.
  Widget 
_buildFixedCard(Map<String, dynamic> row) {

ImageProvider _imageFrom(String? any) {
  final String s = (any ?? '').toString().trim();
  if (s.isEmpty || s.toLowerCase() == 'null') {
    return const AssetImage('assets/bg-wood-upload.jpg');
  }
  if (s.startsWith('data:')) {
    final b64 = s.substring(s.indexOf(',') + 1);
    return MemoryImage(base64.decode(b64));
  }
  if (s.startsWith('http')) return NetworkImage(s);
  if (s.startsWith('file://')) {
    try { return FileImage(File(Uri.parse(s).toFilePath())); } catch (_) { return const AssetImage('assets/bg-wood-upload.jpg'); }
  }
  if (s.startsWith('/')) {
    try { return FileImage(File(s)); } catch (_) { return const AssetImage('assets/bg-wood-upload.jpg'); }
  }
  if (s.startsWith('assets/')) return AssetImage(s);
  return const AssetImage('assets/bg-wood-upload.jpg');
}

    return GestureDetector(
      onTap: () => _switchToPinned(row),
      child: SizedBox(
        width: 200,
        child: AspectRatio(
          aspectRatio: 0.87,
          child: LayoutBuilder(
            builder: (context, cons) {
              final short = (cons.maxWidth < cons.maxHeight) ? cons.maxWidth : cons.maxHeight;
              // Font sizes scale with the background image size, tuned to roughly
              // match the ratios used in the large poster.
              final tTitle = (short * 0.095).clamp(8.5, 14.0) + 1.0;
              final tQuote = (short * 0.155).clamp(8.5, 16.0);
              final tAuth  = (short * 0.075).clamp(7.0, 11.0);
              final tNote  = (short * 0.065).clamp(7.0, 9.5);
              final avatarSize = (short * 0.28 * 0.85).clamp(36.0, 56.0);
              final innerPadH = ((short * 0.10).clamp(8.0, 14.0));
              final innerPadV = (short * 0.12).clamp(8.0, 16.0);

              final topic = (row['theme'] ?? row['topic'] ?? '') as String;
              final quote = (row['content'] ?? row['quote'] ?? '') as String;
              final authorName = (row['author_name'] ?? row['author'] ?? '') as String;
              final sourceFrom = (row['source_from'] ?? row['source'] ?? '') as String;
              final note = (row['explanation'] ?? row['note'] ?? '') as String;
              final avatar = (row['avatar'] ?? row['avatarUrl'] ?? '') as String;
              final authorLine = _buildAuthorLine(authorName, sourceFrom);
              final hasAvatar = avatar.trim().isNotEmpty && avatar.trim().toLowerCase() != 'null';
              final bool shortTopic = topic.length < 15;

              return Stack(
                fit: StackFit.expand,
                children: [
                  // 背景相框
                  Positioned.fill(
                    child: Image.asset('assets/home_small_frame.png', fit: BoxFit.fill),
                  ),
                  // 画布内容
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(innerPadH + 15, innerPadV + 10, innerPadH + 10, innerPadV - 4), // bottom padding reduced by 4dp to shrink white margin and avoid bottom gap
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        clipBehavior: Clip.hardEdge,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // 主题 + 头像（固定在顶部）
                            hasAvatar
                                ? Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Padding(
                                          padding: EdgeInsets.only(left: 12),
                                          child: Text(
                                            topic,
                                            maxLines: null,
                                            overflow: TextOverflow.visible,
                                            style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: (tTitle - 1),
                                              height: 1.25,
                                              fontWeight: FontWeight.w400,
                                      letterSpacing: 0.6, ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: innerPadH * 0.6),
                                      ClipOval(
                                        child: SizedBox(
                                          width: avatarSize,
                                          height: avatarSize,
                                          child: hasAvatar
                                              ? Image(
                                                  image: _imageFrom(avatar),
                                                  fit: BoxFit.contain,
                                                  gaplessPlayback: true,
                                                )
                                              : const SizedBox.shrink(),
                                        ),
                                      ),
                                    ],
                                  )
                                : Center(
                                    child: Text(
                                      topic,
                                      textAlign: TextAlign.center,
                                      softWrap: true,
                                      maxLines: null,
                                      overflow: TextOverflow.visible,
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: (tTitle - 1),
                                        height: 1.25,
                                        fontWeight: FontWeight.w400,
                                      letterSpacing: 0.6, ),
                                    ),
                                  ),
                            SizedBox(height: innerPadV * 0.6),
                            // 可滚动正文+署名+注解
                            Expanded(
                              child: ScrollConfiguration(
                                behavior: _NoIndicatorScroll(),
                                child: SingleChildScrollView(
                                  physics: const ClampingScrollPhysics(),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                      quote,
                                      textScaleFactor: 1.0,
                                      style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 21,
                                        height: 1.5,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 2.1,
                                        fontFamily: 'QuoteSong',
                                        fontFamilyFallback: ['NotoSerifSC','Source Han Serif SC','SimSun','serif'],
                                      ),
                                      ),SizedBox(height: innerPadV * 0.5),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          _buildAuthorLine(authorName, sourceFrom),
                                          textAlign: TextAlign.right,
                                          softWrap: true,
                                          overflow: TextOverflow.visible,
                                          style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: tAuth - 1,
                                            height: 1.35,
                                            fontStyle: FontStyle.italic,
                                            fontWeight: FontWeight.w600,
                                      letterSpacing: 0, ),
                                        ),
                                      ),
                                      if (note.trim().isNotEmpty) ...[
                                        SizedBox(height: innerPadV * 0.5),
                                        Text(
                                          note,
                                          style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: tNote + 1,
                                            height: 1.35,
                                            fontWeight: FontWeight.w200,
                                      letterSpacing: 0,
                                          ),
                                        ),
                                      ]
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }


  /// Layout inner contents of a fixed quote card.  Dynamically scales font
  /// sizes relative to the card width to ensure readability on small cards.
  Widget _buildFixedCardContent(Map<String, dynamic> row) {
    final String theme = (row['theme'] ?? '').toString();
    final String quote = (row['content'] ?? '').toString();
    final String authorName = (row['author_name'] ?? '').toString();
    final String sourceFrom = (row['source_from'] ?? '').toString();
    final String explanation = (row['explanation'] ?? '').toString();
    String authorLine = '';
    if (authorName.isNotEmpty || sourceFrom.isNotEmpty) {
      authorLine = '——';
      if (authorName.isNotEmpty) {
        authorLine += authorName;
        if (sourceFrom.isNotEmpty) {
          authorLine += '《' + sourceFrom + '》';
        }
      } else {
        authorLine += (sourceFrom.isNotEmpty ? ('《' + sourceFrom + '》') : '');
      }
    }
    return LayoutBuilder(
      builder: (context, cons) {
        final w = cons.maxWidth;
        final topicSize = (w * 0.10).clamp(10.0, 16.0);
        final quoteSize = (w * 0.15).clamp(12.0, 20.0);
        final authorSize = (w * 0.08).clamp(8.0, 14.0);
        final noteSize = (w * 0.07).clamp(7.0, 12.0);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 64),
              child: SingleChildScrollView(
                child: Text(
                  theme,
                  textAlign: (theme.characters.length < 20) ? TextAlign.center : TextAlign.left,
                  softWrap: true,
                  style: TextStyle(
                color: Colors.black87,
                fontSize: topicSize - 1,
                fontWeight: FontWeight.w400,
                                      letterSpacing: 0.6,
                height: 1.2,
              )
                ),
              ),
            ),
            SizedBox(height: w * 0.05),
            Expanded(
              child: Text(
                                      quote,
                                      textScaleFactor: 1.0,
                                      style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 21,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 2.1,
                                        height: 1.35,
                                        fontFamily: 'QuoteSong',
                                        fontFamilyFallback: ['NotoSerifSC','Source Han Serif SC','SimSun','serif'],
                                      ),
                                      maxLines: 3,
                                      overflow: TextOverflow.visible,
                                    ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                authorLine,
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: authorSize,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.w800,
                                      letterSpacing: 0,
                  height: 1.3,
                ),
                maxLines: 1,
                overflow: TextOverflow.visible,
              ),
            ),
            SizedBox(height: w * 0.02),
            Text(
              explanation,
              style: TextStyle(
                color: Colors.black87,
                fontSize: noteSize,
                fontWeight: FontWeight.w300,
                                      letterSpacing: 0,
                height: 1.3,
              ),
              maxLines: null,
              overflow: TextOverflow.visible,
            ),
          ],
        );
      },
    );
  }

  /// Build the grey area widget that displays pinned quotes.  When the list is
  /// empty, returns an empty widget.  When there is one item, centers it.
  /// Otherwise, lays out cards horizontally with lazy loading and a trailing
  /// message when all data has loaded.
  Widget _buildPinnedContent() {
    if (_pinnedQuotes.isEmpty) {
      return const SizedBox.shrink();
    }
    // Single pinned quote: center the card
    if (_pinnedQuotes.length == 1) {
      final row = _pinnedQuotes[0];
      return Container(
        height: 240,
        width: double.infinity,
        color: const Color(0xFFF5F5F5),
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: _buildFixedCard(row),
      );
    }
    return Container(
      height: 240,
      width: double.infinity,
      color: const Color(0xFFF5F5F5),
      padding: const EdgeInsets.fromLTRB(20, 30, 20, 0),
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification is ScrollEndNotification) {
            final max = _pinnedController.position.maxScrollExtent;
            final offset = _pinnedController.offset;
            if (max - offset < 50 && !_loadingPinned && _pinnedHasMore) {
              _loadPinned(reset: false);
            }
          }
          return false;
        },
        child: ListView.builder(
          controller: _pinnedController,
          scrollDirection: Axis.horizontal,
          itemCount: _pinnedQuotes.length + (_pinnedHasMore ? 0 : 1),
          itemBuilder: (context, idx) {
            if (idx < _pinnedQuotes.length) {
              return Row(
                children: [
                  _buildFixedCard(_pinnedQuotes[idx]),
                  const SizedBox(width: 20),
                ],
              );
            }
            // Last message when all data loaded
            return Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Text(
                  '已经到底了',
                  style: TextStyle(color: Colors.grey[600], fontSize: 14),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  /// Check whether the currently displayed quote is already pinned.  Updates
  /// the [_pinnedActive] flag accordingly.  Invoked whenever [_todayData]
  /// changes.
  Future<void> _checkPinnedState() async {
    final content = (_todayData?['quote'] ?? '').toString();
    final theme = (_todayData?['topic'] ?? '').toString();
    if (content.trim().isEmpty) {
      if (mounted) setState(() { _pinnedActive = false; });
      return;
    }
    final dao = QuoteFixedDao();
    final row = await dao.findByContentAndTheme(content, theme);
    if (!mounted) return;
    setState(() { _pinnedActive = row != null; });
  }

  /// Toggle the pin state for the current large quote.  If the quote is
  /// already pinned, this will remove it; otherwise, it attempts to insert
  /// it into the fixed table.  Displays feedback via SnackBar.
  Future<void> _togglePin() async {
    final content = (_todayData?['quote'] ?? '').toString();
    final theme = (_todayData?['topic'] ?? '').toString();
    if (content.trim().isEmpty) return;
    final fixedDao = QuoteFixedDao();
    final existing = await fixedDao.findByContentAndTheme(content, theme);
    if (existing != null) {
      // Unpin
      await fixedDao.deleteByContentAndTheme(content, theme);
      if (mounted) {
        setState(() { _pinnedActive = false; });
      }
      await _loadPinned(reset: true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('已取消固定名言'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      return;
    }
    // Not pinned; search in quotes table
    final quoteDao = QuoteDao();
    final row = await quoteDao.findByContentAndTheme(content, theme);
    if (row == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('此名言不存在，固定名言失败'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      return;
    }
    final int? quoteId = row['id'] is int ? row['id'] as int : null;
    await fixedDao.insert(
      content: content,
      theme: theme,
      authorName: (row['author_name'] ?? row['author'] ?? '').toString(),
      sourceFrom: (row['source_from'] ?? row['source'] ?? '').toString(),
      explanation: (row['explanation'] ?? row['note'] ?? '').toString(),
      avatar: (row['avatar'] ?? row['avatarUrl'] ?? '').toString(),
      quoteId: quoteId,
    );
    if (mounted) {
      setState(() { _pinnedActive = true; });
    }
    await _loadPinned(reset: true);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('名言已固定在底部'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  /// Switch the large poster to display a pinned quote.  Builds the
  /// corresponding payload and updates [_todayData], then refreshes the
  /// pinned state.
  Future<void> _switchToPinned(Map<String, dynamic> row) async {
    final avatarUrl = await _avatarToDataUrl((row['avatar'] ?? '').toString());
    final String theme = (row['theme'] ?? '').toString();
    final String quote = (row['content'] ?? '').toString();
    final String authorName = (row['author_name'] ?? '').toString().trim();
    final String source = (row['source_from'] ?? '').toString().trim();
    final String note = (row['explanation'] ?? '').toString();
    String authorLine = '';
    if (authorName.isNotEmpty || source.isNotEmpty) {
      authorLine = '——';
      if (authorName.isNotEmpty) {
        authorLine += authorName;
        if (source.isNotEmpty) {
          authorLine += '《' + source + '》';
        }
      } else {
        authorLine += (source.isNotEmpty ? ('《' + source + '》') : '');
      }
    }
    final bgUrl = await _getBgDataUrl();
    final payload = <String, dynamic>{
      'topic': theme,
      'quote': quote,
      'author': authorLine,
      'source': source,
      'note': note,
      'avatarUrl': avatarUrl,
      'bgUrl': bgUrl,
    };
    if (!mounted) return;
    setState(() {
      _todayData = payload;
    });
    // After switching, update pinned state
    await _checkPinnedState();
  }

  @override
  Widget build(BuildContext context) {
    final assetPath = 'assets/html/poster-wall-only-frame-v23-1.html';
    final content = (!_firstLoaded)
        ? (_firstBg == null ? const {'__blank__': true} : {'bgUrl': _firstBg})
        : _todayData;
    final topPad = MediaQuery.of(context).padding.top;
    final contentPad = topPad; // 再向上靠近约 10dp，使大相框更接近顶栏按钮

    return Scaffold(
      // 直接使用父级背景色，相框单独悬浮
      backgroundColor: Colors.white,
      body: Stack(
        clipBehavior: Clip.none,
        children: [
          // 内容区
          Positioned.fill(
            child: Padding(
              padding: EdgeInsets.only(top: contentPad, bottom: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                  // 大相框（纯木纹 + 画布），使用原始宽度
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: AnimatedSlide(
                      duration: const Duration(milliseconds: 320),
                      curve: Curves.easeOutCubic,
                      offset: (_pinnedQuotes.isEmpty ? const Offset(0, 0.12) : Offset.zero),
                      child: Transform.scale(
                        scale: 0.736,
                        child: PosterPureFlutter(
                        topic: '${content?['topic'] ?? ''}',
                        quote: '${content?['quote'] ?? ''}',
                        author: '${content?['author'] ?? ''}',
                        note: '${content?['note'] ?? ''}',
                        avatar: '${content?['avatar'] ?? content?['avatarUrl'] ?? ''}',
                        woodBgAsset: 'assets/bg-wood-upload.jpg',
                      ),),
                    ),
                  ),
                  const SizedBox(height: 0),
                  Transform.translate(
                    offset: const Offset(0, -80),
                    // Display dynamic pinned quotes area.  When there are no
                    // fixed quotes, this returns an empty widget and the grey
                    // area is effectively hidden.
                    child: AnimatedSwitcher(
  duration: const Duration(milliseconds: 420),
  switchInCurve: Curves.easeOutCubic,
  switchOutCurve: Curves.easeInCubic,
  transitionBuilder: (Widget child, Animation<double> anim) {
    // 'Curtain' effect: slide up when hiding, slide up-from-bottom when showing.
    final slide = Tween<Offset>(begin: const Offset(0, 0.25), end: Offset.zero)
        .chain(CurveTween(curve: Curves.easeOutCubic))
        .animate(anim);
    return ClipRect(
      child: SlideTransition(
        position: slide,
        child: FadeTransition(opacity: anim, child: child),
      ),
    );
  },
  child: (_pinnedQuotes.isNotEmpty)
      ? _buildPinnedContent()
      : const SizedBox.shrink(),
),
                  ),
                  const SizedBox(height: 0),                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
// 顶栏区域（悬浮白底按钮）
          Positioned(
            top: topPad,
            left: 0,
            right: 0,
            height: kToolbarHeight,
            child: IgnorePointer(
              ignoring: false,
              child: Row(

                children: [
                  const SizedBox(width: 8),
                  // 左侧按钮：打开左侧抽屉卡片
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '打开卡片',
                        icon: const Icon(Icons.menu, color: Colors.black87),
                        onPressed: _openLeftDrawer,
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  // pin/unpin button for fixing quotes to the bottom grey area（固定按钮保持不变）
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: _pinnedActive ? '取消固定' : '固定名言',
                        icon: Icon(
                          _pinnedActive ? Icons.push_pin : Icons.push_pin_outlined,
                          color: Colors.black87,
                        ),
                        onPressed: _togglePin,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
// 更多操作下拉按钮：分享 / 收藏 / 喜欢
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: PopupMenuButton<String>(
                        tooltip: '更多操作',
                        icon: const Icon(Icons.more_vert, color: Colors.black87),
                        onSelected: _handleTopBarMenu,
                        itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                          PopupMenuItem<String>(
                            value: 'share',
                            child: Row(
                              children: const [
                                Icon(Icons.share),
                                SizedBox(width: 8),
                                Text('分享'),
                              ],
                            ),
                          ),
                          PopupMenuItem<String>(
                            value: 'favorite',
                            child: Row(
                              children: const [
                                Icon(Icons.favorite_border),
                                SizedBox(width: 8),
                                Text('收藏'),
                              ],
                            ),
                          ),
                          PopupMenuItem<String>(
                            value: 'like',
                            child: Row(
                              children: const [
                                Icon(Icons.thumb_up_alt_outlined),
                                SizedBox(width: 8),
                                Text('喜欢'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),

                  
                ],
              ),
            ),
          ),

          // 顶部心情分享卡片（从屏幕上方缓慢弹出）
          _buildMoodCardOverlay(),
                  ],
      ),
    );
  }

  /// 每次进入首页（首开/重启/被杀后重启/从后台恢复）仅检查一次；未开仅触发系统默认通知权限弹窗。
  Future<void> _checkNotificationPermission() async {
    if (_sessionPrompted) return;
    _sessionPrompted = true;
    bool enabled = true;
    try { enabled = await NotificationService.areNotificationsEnabled(); } catch (_){ enabled = false; }
    if (enabled != true) {
      try { await NotificationService.request(); } catch (_){}
    }
    try { await _maybeAskExactAfterNotif(); } catch (_){}
  }
}