
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  Future<void> _injectIfNeeded() async {    if (!_ready) return;
    final d = widget.data;
    if (d == null || d.isEmpty) return;
    String _normalizeAvatar(dynamic v){
      if (v == null) return '';
      final s = v.toString();
      if (s.startsWith('http://') || s.startsWith('https://')) return s;
      return 'img/avatars/' + s;
    }
    // Build fields according to canonical IDs
    final _topic  = (d['topic'] ?? d['topic_text'] ?? d['theme'] ?? '').toString();
    final _quote  = (d['content'] ?? d['quote'] ?? d['quote_text'] ?? '').toString();
    final _authorRaw  = (d['author'] ?? d['author_name'] ?? d['signature'] ?? d['署名']);
    final _sourceRaw  = (d['source'] ?? d['source_from'] ?? d['出处']);
    final _author = (() {
      final a = _authorRaw == null ? '' : _authorRaw.toString();
      final s = _sourceRaw == null ? '' : _sourceRaw.toString();
      if (a.isEmpty && s.isEmpty) return '';
      if (a.isNotEmpty && s.isNotEmpty) return '——' + a + '《' + s + '》';
      if (a.isNotEmpty) return '——' + a;
      return '——《' + s + '》';
    })();
    final _note   = (d['explain'] ?? d['explanation'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? '').toString();
    final _avatar = _normalizeAvatar(
      d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
    );
    final payload = jsonEncode({
      'topic': _topic,
      'quote': _quote,
      'author': _author,
      'note': _note,
      'avatarUrl': _avatar,
    });
    try {
      final exists = await _controller.runJavaScriptReturningResult(
        "(() => { try { return typeof window.setDynamicData; } catch(e){ return 'EX:'+e.toString(); } })()"
      );
      if (exists == "'function'") {
        await _controller.runJavaScript('try{ window.setDynamicData(' + payload + '); }catch(e){ console.error("inject-error:"+e); }');
      } else {
        final js = r"""
          (function(){
            try{
              window.__applyDynamic = function(p){
                try{
                  var o = (typeof p === 'string') ? JSON.parse(p) : p;
                  var T = document.getElementById('topic-text');
                  var Q = document.getElementById('quote-text');
                  var A = document.getElementById('author-text');
                  var N = document.getElementById('note-text');
                  var IMG = document.getElementById('avatar-img');
                  if (o.topic && T)  T.innerText  = o.topic;
                  if (o.quote && Q)  Q.innerText  = o.quote;
                  if (o.author && A) A.innerText  = o.author;
                  if (o.note && N)   N.innerText  = o.note;
                  if (o.avatarUrl && IMG) IMG.setAttribute('src', o.avatarUrl);
                }catch(e){ console.error('fallback-apply-error:'+e); }
              };
              return 'ok';
            }catch(e){ return 'err:'+e; }
          })();
        """;
        await _controller.runJavaScript(js);
        await _controller.runJavaScript('try{ window.__applyDynamic(' + payload + '); }catch(e){ console.error("fallback-call-error:"+e); }');
      }
    } catch (e) {
      try { await _controller.runJavaScript("console.error('inject-outer-error:'+"+jsonEncode(e.toString())+")"); } catch(_) {}
    }
}
    final payload = jsonEncode({
      'topic': (d['topic'] ?? d['topic_text'] ?? d['theme'] ?? ''),
      'quote': (d['content'] ?? d['quote'] ?? d['quote_text'] ?? ''),
      'author': (() {
        final a = (d['author'] ?? d['author_name'] ?? d['signature'] ?? d['署名']);
        final s = (d['source'] ?? d['source_from'] ?? d['出处']);
        if (a != null && a.toString().isNotEmpty) {
          return '---' + a.toString() + (s != null && s.toString().isNotEmpty ? '《' + s.toString() + '》' : '');
        }
        return '';
      })(),
      'note': (d['explain'] ?? d['explanation'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? ''),
      'avatarUrl': _normalizeAvatar(
        d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
      ),
      if (d.containsKey('focalX')) 'focalX': d['focalX'],
      if (d.containsKey('focalY')) 'focalY': d['focalY'],
    });
    try {
      final exists = await _controller.runJavaScriptReturningResult(
        "(() => { try { return typeof window.setDynamicData; } catch(e){ return 'EX:'+e.toString(); } })()"
      );
      if (exists == "'function'") {
        await _controller.runJavaScript('try{ window.setDynamicData(' + payload + '); }catch(e){ console.error("inject-error:"+e); }');
      } else {
        // Define a minimal fallback updater if setDynamicData is missing
        final js = r"""
          (function(){
            try{
              window.__applyDynamic = function(p){
                try{
                  var o = (typeof p === 'string') ? JSON.parse(p) : p;
                  if (o.topic && document.getElementById('topic')) document.getElementById('topic').innerText = o.topic;
                  if (o.quote && document.getElementById('quote')) document.getElementById('quote').innerText = o.quote;
                  if (o.author && document.getElementById('author')) document.getElementById('author').innerText = o.author;
                  if (o.note && document.getElementById('note')) document.getElementById('note').innerText = o.note;
                  if (o.avatarUrl && document.getElementById('avatar')) document.getElementById('avatar').setAttribute('src', o.avatarUrl);
                }catch(e){ console.error('fallback-apply-error:'+e); }
              };
              return 'ok';
            }catch(e){ return 'err:'+e; }
          })();
        """;
        await _controller.runJavaScript(js);
        await _controller.runJavaScript('try{ window.__applyDynamic(' + payload + '); }catch(e){ console.error("fallback-call-error:"+e); }');
      }
    } catch (e) {
      // Swallow but leave a console trace inside the WebView
      try { await _controller.runJavaScript("console.error('inject-outer-error:'+"+jsonEncode(e.toString())+")"); } catch(_) {}
    }
}
      // Otherwise map to img/avatars/<name> relative to html; fallback to remote images if placed there
      final onlyName = v;
      return 'img/avatars/$onlyName';
    }
    final payload = jsonEncode({
      // Use multiple fallbacks for each field to support different DB schemas
      'topic': (d['topic'] ?? d['topic_text'] ?? d['theme'] ?? ''),
      'quote': (d['content'] ?? d['quote'] ?? d['quote_text'] ?? ''),
      // For author, prefer author / author_name / signature / 署名 then build with source/source_from/出处
      'author': (() {
        final a = (d['author'] ?? d['author_name'] ?? d['signature'] ?? d['署名']);
        final s = (d['source'] ?? d['source_from'] ?? d['出处']);
        if (a != null && a.toString().isNotEmpty) {
          return '---' + a.toString() + (s != null && s.toString().isNotEmpty ? '《' + s.toString() + '》' : '');
        }
        return (d['authorText'] ?? d['author_text'] ?? '');
      })(),
      // For note/explanation use multiple fallbacks
      'note': (d['explain'] ?? d['explanation'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? ''),
      // For avatar use various fallback keys
      'avatarUrl': _normalizeAvatar(
        d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
      ),
      if (d.containsKey('focalX')) 'focalX': d['focalX'],
      if (d.containsKey('focalY')) 'focalY': d['focalY'],
    });
    try { await _controller.runJavaScript('window.setDynamicData($payload);'); } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
