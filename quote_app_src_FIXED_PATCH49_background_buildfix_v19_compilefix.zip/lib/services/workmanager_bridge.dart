import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import 'bg_init.dart';
import '../data/db.dart';
import '../data/dao.dart';
import 'scheduler_service.dart';

const String kQuotesTask = 'quotes_job';

class WorkManagerBridge {
  static Future<void> init() async {
    try {
      await Workmanager().initialize(wmCallbackDispatcher, isInDebugMode: false);
    } catch (_) {}
  }

  static Future<void> scheduleOneOff(DateTime when, {int? nid, String? fallback}) async {
    final delay = when.difference(DateTime.now());
    await Workmanager().registerOneOffTask(
      'quote_${when.millisecondsSinceEpoch}',
      kQuotesTask,
      initialDelay: delay.isNegative ? Duration.zero : delay,
      inputData: {
        'nid': nid ?? 2001,
        'fallback': fallback ?? '到点啦～',
      },
      constraints: Constraints(
        networkType: NetworkType.notRequired,
      ),
    );
  }
}

@pragma('vm:entry-point')
void wmCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    await BackgroundBootstrap.initForBackground();
    try {
      await SchedulerService.callback();
    } catch (e) {
      try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: 'wm回调异常: ' + e.toString()); } catch (_) {}
    }
    return Future.value(true);
  });
}
