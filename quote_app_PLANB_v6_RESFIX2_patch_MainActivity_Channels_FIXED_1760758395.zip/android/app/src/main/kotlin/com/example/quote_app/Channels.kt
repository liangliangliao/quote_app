package com.example.quote_app

object Channels {
    const val SYS_PERMS = "com.example.quote_app/sysperms"
    const val BACK_CLOSE = "com.example.quote_app/backclose"
}
