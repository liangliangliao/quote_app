package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 仅用于兜底：监听 SCREEN_ON，延迟检查是否已解锁（无锁屏/智能解锁等）。
 * 只有确认“已解锁”时，才注册闹钟立刻执行（业务逻辑在闹钟中执行）；否则不做任何业务。
 * 同时做 3 秒去重，避免与 USER_PRESENT 双触发。
 */
class ScreenOnProbeReceiver : BroadcastReceiver() {
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[" + now + "] " + msg)
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  override fun onReceive(context: Context, intent: Intent?) {
    if (intent?.action != Intent.ACTION_SCREEN_ON) return
    val app = context.applicationContext
    // 无锁屏/智能解锁等场景下，系统可能不会发送 USER_PRESENT；此处做“零延迟”兜底：
    val km = app.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    val isLocked = try { km.isKeyguardLocked } catch (_: Throwable) { true }
    if (!isLocked) {
      // 3 秒去重，避免与 USER_PRESENT 双触发
      try {
        val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = sp.getLong("last_unlock_probe_ts", 0L)
        if (last > 0L && (now - last) < 3000L) {
          try { logWithTime(app, "【解锁后台-探测】SCREEN_ON 已确认无锁，但 3s 去重命中，跳过（回包：DEDUP）") } catch (_: Throwable) {}
          return
        }
        sp.edit().putLong("last_unlock_probe_ts", now).apply()
      } catch (_: Throwable) {}

      try { logWithTime(app, "【解锁后台-探测】SCREEN_ON 确认当前无锁，注册闹钟立刻执行（业务逻辑在闹钟中执行）（回包：FIRE）") } catch (_: Throwable) {}
      try { UnlockReceiver.scheduleImmediate(app, "SCREEN_ON") } catch (_: Throwable) {}
    } else {
      try { logWithTime(app, "【解锁后台-探测】SCREEN_ON 后仍上锁，等待解锁（上锁状态不注册闹钟）（回包：WAIT）") } catch (_: Throwable) {}
    }
  }
}
