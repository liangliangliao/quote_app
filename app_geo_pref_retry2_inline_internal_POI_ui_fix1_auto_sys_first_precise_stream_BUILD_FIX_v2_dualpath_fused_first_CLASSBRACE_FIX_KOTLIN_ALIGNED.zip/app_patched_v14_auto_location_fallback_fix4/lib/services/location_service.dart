import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:geolocator/geolocator.dart';
import 'package:geolocator_android/geolocator_android.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// Top-level POI model for nearby place selection.
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  const PoiItem({
    required this.name,
    required this.latitude,
    required this.longitude,
    this.address,
    this.distance,
  });
}

/// A helper service to obtain the current device location in a robust manner.
///
/// This service first attempts to use the Geolocator plugin to obtain the
/// current position with high accuracy. If that fails (for example on
/// devices without Google Play services in Mainland China), it falls back
/// to Baidu's IP‑based geolocation API. The Baidu API key is read from
/// the notify_config table (key = 'baidu_ak'). If no key is configured,
/// the fallback will be skipped and null is returned.
class LocationService {
  // Latitude and longitude bounding box for mainland China. These constants
  // are used to determine whether a device's current coordinates fall
  // within the approximate borders of mainland China. If both latitude and
  // longitude lie within these ranges, we consider the device to be in
  // China for the purpose of choosing a location provider.
  static const double _chinaMinLat = 3.86;
  static const double _chinaMaxLat = 53.55;
  static const double _chinaMinLon = 73.66;
  static const double _chinaMaxLon = 135.05;
  /// Attempts to obtain the current position. Returns a [Position] if
  /// successful, otherwise returns null.
  static Future<Position?> 

getCurrentPositionSmart() async {
    // 预检查：位置服务、权限、精确定位状态
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        try { DLog.i('LocationService', '【定位】系统定位服务未开启'); } catch (_) {}
        return null;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        try { DLog.i('LocationService', '【定位】没有定位权限（denied/deniedForever）'); } catch (_) {}
        return null;
      }
      try {
        final accStatus = await Geolocator.getLocationAccuracy();
        if (accStatus.toString().contains('reduced')) {
          DLog.i('LocationService', '【定位】系统仅“近似位置”，建议开启“精确位置”提高准确度');
        }
      } catch (_) {}
    } catch (_) {}

    // A) 高精度(流) - bestForNavigation, 50s, >=3次，<=25m
    try {
      final streamBest = await _getAccurateFixFromStream(
        timeWindow: const Duration(seconds: 40),
        targetMeters: 25.0,
        minUpdates: 3,
        androidUseLocationManager: false,
        androidAccuracyHigh: false,
      );
      if (streamBest != null) {
        try { DLog.i('LocationService', '【定位】高精度(流@bestForNav)成功 acc=${streamBest.accuracy.toStringAsFixed(1)}m, lat=${streamBest.latitude}, lon=${streamBest.longitude}'); } catch (_) {}
        return streamBest;
      }
    } catch (_) {}

    // B) 高精度(单次) - bestForNavigation, 60s
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation,
        timeLimit: const Duration(seconds: 50),
      );
      try { DLog.i('LocationService', '【定位】高精度(单次@bestForNav)成功 acc=${pos.accuracy.toStringAsFixed(1)}m, lat=${pos.latitude}, lon=${pos.longitude}'); } catch (_) {}
      return pos;
    } catch (_) { try { DLog.i('LocationService', '【定位】高精度(单次@bestForNav)失败，尝试High'); } catch (_) {} }

    // C) 高精度(流) - HIGH, 40s
    try {
      final streamHigh = await _getAccurateFixFromStream(
        timeWindow: const Duration(seconds: 40),
        targetMeters: 35.0,
        minUpdates: 3,
        androidUseLocationManager: true,
        androidAccuracyHigh: true,
      );
      if (streamHigh != null) {
        try { DLog.i('LocationService', '【定位】高精度(流@HIGH)成功 acc=${streamHigh.accuracy.toStringAsFixed(1)}m, lat=${streamHigh.latitude}, lon=${streamHigh.longitude}'); } catch (_) {}
        return streamHigh;
      }
    } catch (_) {}

    // D) 高精度(单次) - HIGH, 45s
    try {
      final pos2 = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 45),
      );
      try { DLog.i('LocationService', '【定位】高精度(单次@HIGH)成功 acc=${pos2.accuracy.toStringAsFixed(1)}m, lat=${pos2.latitude}, lon=${pos2.longitude}'); } catch (_) {}
      return pos2;
    } catch (_) { try { DLog.i('LocationService', '【定位】高精度(单次@HIGH)失败，评估lastKnown'); } catch (_) {} }

    // E) 最近一次已知位置（仅接受<=5分钟内的点）
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        final age = DateTime.now().difference(last.timestamp ?? DateTime.fromMillisecondsSinceEpoch(0));
        if (age.inMinutes <= 5) {
          try { DLog.i('LocationService', '【定位】使用最近一次已知位置(<=5min)：lat=${last.latitude}, lon=${last.longitude}'); } catch (_) {}
          return last;
        } else {
          try { DLog.i('LocationService', '【定位】丢弃过期的最近一次已知位置(约${age.inMinutes}分钟)'); } catch (_) {}
        }
      }
    } catch (_) {}

    // F) 低精度快速获取（给个兜底的较粗糙点）
    try {
      final low = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 25),
      );
      try { DLog.i('LocationService', '【定位】使用低精度位置：lat=${low.latitude}, lon=${low.longitude}'); } catch (_) {}
      return low;
    } catch (_) {}

    // G) 系统彻底失败
    return null;
  }



  /// Attempts to obtain the current position with a bias toward using the
  /// Baidu IP geolocation service when it is configured. This helper first
  /// checks whether a Baidu API key exists in the notify_config table. If a
  /// non‑empty key is found, it will immediately attempt to query Baidu's
  /// `location/ip` endpoint to obtain a coordinate. Should this request
  /// succeed, the resulting position is returned and no further calls are
  /// attempted. If the Baidu lookup fails or no key is configured, this
  /// method falls back to [getCurrentPositionSmart] which uses Geolocator
  /// and then Baidu as a final option. All key steps are logged via DLog so
  /// that the logs table clearly shows which provider was used.
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 统一2分钟超时（自动/手动一致）
    return _getCurrentPositionPreferBaiduInternal().timeout(
      const Duration(minutes: 2),
      onTimeout: () {
        try {
          DLog.i('LocationService', '定位服务在2分钟内未能返回结果，将视为获取当前位置失败');
        } catch (_) {}
        return null;
      },
    );
  }

  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
      if (effectiveAk.isEmpty) return;
      final lat = pos.latitude;
      final lon = pos.longitude;
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?ak=${Uri.encodeComponent(effectiveAk)}&output=json&coordtype=wgs84ll&extensions_poi=1&radius=600&location=$lat,$lon'
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        try {
          final data = jsonDecode(res.body);
          if (data is Map && (data['status'] == 0 || data['status'] == '0')) {
            final result = data['result'];
            if (result is Map) {
              final pois = result['pois'];
              if (pois is List && pois.isNotEmpty) {
                final first = pois.first;
                String? name; int? distance;
                if (first is Map) {
                  final n = first['name']; final d = first['distance'];
                  if (n is String) name = n; if (d is int) distance = d;
                }
                if (name != null) {
                  final suffix = distance != null ? '（约${distance}米）' : '';
                  try { await DLog.i('LocationService', '附近地标：' + name + suffix); } catch (_) {}
                }
              }
            }
          }
        } catch (_) {}
      }
    } catch (_) {}
  }


  static Future<Position?> _getCurrentPositionPreferBaiduInternal() async {
    // 1) 优先系统定位（内部已包含两次高精度重试 + 最近一次已知位置，或至少一次高精度 + lastKnown）
    try {
      final systemPos = await getCurrentPositionSmart();
      if (systemPos != null) {
        try { await _logNearbyLandmarkIfPossible(systemPos); } catch (_) {}
        return systemPos;
      }
    } catch (_) {}

    // 2) 系统失败 -> 兜底百度 IP（粗略），仅当配置/内置AK可用
    String ak = '';
    try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
    final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
    if (effectiveAk.isEmpty) return null;

    int? httpStatus;
    int? baiduStatus;
    String? baiduMessage;
    try {
      final url = Uri.parse(
        'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(effectiveAk)}&coor=gcj02'
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      httpStatus = res.statusCode;
      if (res.statusCode == 200) {
        try {
          final data = jsonDecode(res.body);
          if (data is Map) {
            final rawStatus = data['status'];
            if (rawStatus is int) { baiduStatus = rawStatus; }
            else if (rawStatus is String) { baiduStatus = int.tryParse(rawStatus); }
            final rawMsg = data['message'];
            if (rawMsg is String) { baiduMessage = rawMsg; }
            if (data['status'] == 0) {
              final content = data['content'];
              if (content is Map) {
                final point = content['point'];
                if (point is Map) {
                  final latStr = point['y']?.toString() ?? '';
                  final lngStr = point['x']?.toString() ?? '';
                  final lat = double.tryParse(latStr);
                  final lng = double.tryParse(lngStr);
                  if (lat != null && lng != null) {
                    try { DLog.i('LocationService', '【定位】使用 Baidu IP 兜底定位获取位置：lat=$lat, lon=$lng'); } catch (_) {}
                    return Position(
                      latitude: lat, longitude: lng, timestamp: DateTime.now(),
                      accuracy: 0, altitude: 0, heading: 0, speed: 0,
                      speedAccuracy: 0, altitudeAccuracy: 0, headingAccuracy: 0,
                    );
                  }
                }
              }
            }
          }
        } catch (_) {}
      }
      try {
        await DLog.i(
          'LocationService',
          '调用百度定位服务出现异常(http=${httpStatus ?? -1}, status=${baiduStatus ?? -1}, msg=${baiduMessage ?? ''})，将返回null',
        );
      } catch (_) {}
      return null;
    } catch (_) {
      try {
        await DLog.i(
          'LocationService',
          '调用百度定位服务出现异常(http=${httpStatus ?? -1}, status=${baiduStatus ?? -1}, msg=${baiduMessage ?? ''})，将返回null',
        );
      } catch (_) {}
      return null;
    }
  }

  // --- Nearby POI model & fetcher (non-breaking additions) ---
  /// Fetch nearby POIs (within [radiusMeters]) around [latitude],[longitude].
  /// Client-side filtering by [keyword] and simple paging by [page]/[pageSize].
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    int radiusMeters = 200,
    String keyword = '',
    int page = 1,
    int pageSize = 5,
  }) async {
    String ak = '';
    try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
    final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
    if (effectiveAk.isEmpty) return [];

    final url = Uri.parse(
      'https://api.map.baidu.com/reverse_geocoding/v3/'
      '?ak=${Uri.encodeComponent(effectiveAk)}'
      '&output=json'
      '&coordtype=wgs84ll'
      '&extensions_poi=1'
      '&radius=$radiusMeters'
      '&location=$latitude,$longitude'
    );
    try {
      final res = await http.get(url).timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return [];
      final data = jsonDecode(res.body);
      if (data is! Map || (data['status'] != 0 && data['status'] != '0')) return [];
      final result = data['result'];
      if (result is! Map) return [];
      final pois = result['pois'];
      if (pois is! List) return [];

      final List<String> preferWords = [
        '超市','便利店','商超','商场','购物','广场','市场','公寓','小区','大厦','花园','写字楼','门店','购物中心'
      ];
      List<PoiItem> all = <PoiItem>[];
      for (final item in pois) {
        if (item is! Map) continue;
        final n = item['name']?.toString() ?? '';
        if (n.isEmpty) continue;
        final hasPrefer = preferWords.any((w) => n.contains(w));
        if (!hasPrefer && keyword.isEmpty) continue;
        if (keyword.isNotEmpty && !n.contains(keyword)) continue;

        double? lat, lng;
        final p = item['point'];
        if (p is Map) {
          lat = double.tryParse(p['y']?.toString() ?? '');
          lng = double.tryParse(p['x']?.toString() ?? '');
        } else {
          final loc = item['location'];
          if (loc is Map) {
            lat = double.tryParse(loc['lat']?.toString() ?? '');
            lng = double.tryParse(loc['lng']?.toString() ?? '');
          }
        }
        final dist = int.tryParse(item['distance']?.toString() ?? '');
        if (lat != null && lng != null) {
          all.add(PoiItem(
            name: n,
            address: item['addr']?.toString(),
            latitude: lat,
            longitude: lng,
            distance: dist,
          ));
        }
      }
      all.sort((PoiItem a, PoiItem b) => (a.distance ?? (1 << 30)).compareTo(b.distance ?? (1 << 30)));
      final start = (page - 1) * pageSize;
      if (start >= all.length) return [];
      final end = (start + pageSize).clamp(0, all.length);
      return all.sublist(start, end);
    } catch (_) {
      return [];
    }
  }
  /// 收敛一段时间内的多次GNSS更新，选择accuracy最优，尽量拿到≤25m的高精度点。
  


  static Future<Position?> _getAccurateFixFromStream({
    Duration timeWindow = const Duration(seconds: 45),
    double targetMeters = 25.0,
    int minUpdates = 3,
    bool androidUseLocationManager = false,
    bool androidAccuracyHigh = false,
  }) async {
    StreamSubscription<Position>? sub;
    final completer = Completer<Position?>();
    Position? best;
    int count = 0;
    try {
      final locationSettings = Platform.isAndroid
          ? (androidUseLocationManager
              ? AndroidSettings(
                  accuracy: androidAccuracyHigh ? LocationAccuracy.high : LocationAccuracy.bestForNavigation,
                  distanceFilter: 0,
                  forceLocationManager: true,
                  intervalDuration: const Duration(seconds: 1),
                )
              : const LocationSettings(
                  accuracy: LocationAccuracy.bestForNavigation,
                  distanceFilter: 0,
                ))
          : const LocationSettings(
              accuracy: LocationAccuracy.bestForNavigation,
              distanceFilter: 0,
            );
      final stream = Geolocator.getPositionStream(locationSettings: locationSettings);
      sub = stream.listen((pos) {
        count += 1;
        if (best == null || pos.accuracy < (best!.accuracy)) {
          best = pos;
          try { DLog.i('LocationService', '【定位】流式更新：acc=${pos.accuracy.toStringAsFixed(1)}m, lat=${pos.latitude}, lon=${pos.longitude}'); } catch (_) {}
        }
        if (best != null && best!.accuracy <= targetMeters && count >= minUpdates) {
          sub?.cancel();
          if (!completer.isCompleted) completer.complete(best);
        }
      });
      Future.delayed(timeWindow, () {
        sub?.cancel();
        if (!completer.isCompleted) completer.complete(best);
      });
      return await completer.future;
    } catch (_) {
      try { await sub?.cancel(); } catch (_) {}
      return best;
    }
  }
