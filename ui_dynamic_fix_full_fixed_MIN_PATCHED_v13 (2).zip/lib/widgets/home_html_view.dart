import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView 容器：统一处理“空白→兜底/动态”的展示与 JS 注入
class HomeHtmlView extends StatefulWidget {
  final String assetPath;                 // 兜底/模板 HTML
  final Map<String, dynamic>? data;       // null 表示兜底（无/异常）

  const HomeHtmlView({super.key, required this.assetPath, required this.data});

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _revealed = false; // 是否已经把内容展示给用户

  // 隐藏首页 HTML 所有可见元素。通过修改元素的不透明度隐藏，确保内容不可见且不发生布局重排
  Future<void> _hideHtml() async {
    const jsHide = '''
      (function(){
        try {
          var root = document.documentElement || document.body;
          if (root) {
            // Use opacity instead of visibility to avoid reflow and flicker.
            root.style.opacity = '0';
          }
          return true;
        } catch(e) { return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(jsHide);
    } catch (_) {
      // 在页面未准备好时可能会失败，稍后再次尝试
      await Future.delayed(const Duration(milliseconds: 50));
      try { await _controller.runJavaScriptReturningResult(jsHide); } catch(__) {}
    }
  }

  // 显示之前隐藏的 HTML 元素，将不透明度恢复为正常。使用 opacity 可以避免闪屏
  Future<void> _showHtml() async {
    const jsShow = '''
      (function(){
        try {
          var root = document.documentElement || document.body;
          if (root) {
            root.style.opacity = '1';
          }
          return true;
        } catch(e) { return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(jsShow);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 50));
      try { await _controller.runJavaScriptReturningResult(jsShow); } catch(__) {}
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) async {
            // 页面加载完成后：判断是否有动态数据（忽略 __blank__ 标记）
            final hasDynamicData = widget.data != null && !(widget.data is Map && (widget.data as Map).containsKey('__blank__'));
            // 若有数据则注入，无数据则直接展示默认内容
            if (hasDynamicData) {
              await _injectDynamic(widget.data!);
            }
            // 展示页面（html 初始已隐藏）
            await _showHtml();
            _revealIfNeeded();
          },
        ),
      );
    _loadBlankThenDecide();
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 当 data 发生变化时重新决定是否注入数据并显隐内容
    if (widget.data != oldWidget.data) {
      // 使用微任务确保在 build 完成后执行 JS
      Future.microtask(() async {
        final hasDynamicData = widget.data != null && !(widget.data is Map && (widget.data as Map).containsKey('__blank__'));
        // 如果尚未展示过内容，则按首次加载逻辑：注入（如有）并展示
        if (!_revealed) {
          if (hasDynamicData) {
            await _injectDynamic(widget.data!);
          }
          await _showHtml();
          _revealIfNeeded();
        } else {
          // 已经展示过页面：仅在有动态数据时更新，不再隐藏/显示，避免闪屏
          if (hasDynamicData) {
            await _injectDynamic(widget.data!);
          }
        }
      });
    }
  }

  void _revealIfNeeded() {
    if (!_revealed && mounted) setState(() => _revealed = true);
  }

  Future<void> _loadBlankThenDecide() async {
    // 先加载透明空白，避免兜底闪屏
    await _controller.loadHtmlString(
      '<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>'
      '<body style="background:transparent;margin:0;padding:0;"></body></html>'
    );

    // 再加载模板（有/无数据都先加载模板，注入数据与否由 onPageFinished 决定）
    final html = await rootBundle.loadString(widget.assetPath);
    await _controller.loadHtmlString(html);
  }

  Future<void> _injectDynamic(Map<String, dynamic> data) async {
    final payloadJson = jsonEncode(data);
    final js = '''
      (function(){
        try{
          var payload = $payloadJson;
          if (window.setDynamicData && typeof window.setDynamicData === 'function') {
            window.setDynamicData(payload);
          } else {
            window.PAYLOAD = payload;
            try{ if (window.onPayloadArrived) window.onPayloadArrived(payload); }catch(e){}
          }
          return true;
        }catch(e){ return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(js);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 60));
      try { await _controller.runJavaScriptReturningResult(js); } catch(__) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    // 使用零时长过渡，避免动画造成的闪屏。通过 _revealed 标志控制完全隐藏/显示。
    return AnimatedOpacity(
      opacity: _revealed ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 0),
      child: IgnorePointer(
        ignoring: !_revealed,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}