import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'dart:async';
import 'dart:io';

import 'package:quote_app/services/native_am.dart';
import 'package:quote_app/services/native_wm.dart';
import 'package:quote_app/services/native_guard.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';
import '../data/dao.dart';
import '../utils/debug_logger.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _endpointCtrl = TextEditingController();

  bool _editingConfig = false;
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  
  Future<void> _reloadTasksAfterSave() async {
    _tasks = await _taskDao.all();
      if (mounted) setState(() {});
    
  }
void showToast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  /// Compute the next run time for the given task map.
  /// This replicates the logic of SchedulerService._computeNextRun so that we
  /// always cancel alarms based on the latest future trigger, rather than a
  /// possibly stale next_time stored in the database. If next_time is valid
  /// and in the future, it is used directly. Otherwise we derive the next
  /// run from start_time, freq_type, freq_weekday and freq_day_of_month.
  DateTime? _computeNextRunFor(Map<String, dynamic> t) {
    final now = DateTime.now();
    // Prefer next_time if it exists and is in the future.
    try {
      final raw = (t['next_time'] ?? '').toString();
      if (raw.isNotEmpty) {
        final dt = DateTime.tryParse(raw);
        if (dt != null && dt.isAfter(now.subtract(const Duration(seconds: 10)))) {
          return dt;
        }
      }
    } catch (_) {}
    // Parse start_time which may be HH:mm or absolute date time string
    String start = (t['start_time'] ?? '09:00').toString().trim();
    if (start.isEmpty) start = '09:00';
    DateTime? absDt;
    int hh = 9, mm = 0;
    // absolute date-time, e.g., 2025-10-25 10:05 or 2025-10-25 10:05:00
    final reAbs = RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?\$');
    if (reAbs.hasMatch(start)) {
      try {
        // replace space with 'T' to parse ISO-like string
        final s = start.replaceFirst(' ', 'T');
        absDt = DateTime.parse(s);
        hh = absDt.hour;
        mm = absDt.minute;
      } catch (_) {
        absDt = null;
      }
    } else {
      final m = RegExp(r'\b(\d{1,2}):(\d{2})\b').firstMatch(start);
      if (m != null) {
        hh = int.tryParse(m.group(1) ?? '') ?? 9;
        mm = int.tryParse(m.group(2) ?? '') ?? 0;
      }
    }
    // Determine frequency type; treat manual/empty/null as daily
    String freqType = (t['freq_type'] ?? 'daily').toString();
    if (freqType.isEmpty || freqType == 'null' || freqType == 'manual') {
      freqType = 'daily';
    }
    final int? weekDay = t['freq_weekday'] is int ? t['freq_weekday'] as int : null;
    final int? dayOfMonth = t['freq_day_of_month'] is int ? t['freq_day_of_month'] as int : null;
    // If start_time is an absolute future date-time, use it
    if (absDt != null && absDt.isAfter(now)) {
      return absDt;
    }
    // Weekly frequency
    if (freqType == 'weekly' && weekDay != null) {
      final wd = weekDay;
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isBefore(now)) {
        return cand;
      }
      return cand.add(const Duration(days: 7));
    }
    // Monthly frequency
    if (freqType == 'monthly' && dayOfMonth != null) {
      final d = dayOfMonth.clamp(1, 31);
      int y = now.year;
      int mth = now.month;
      int end = DateTime(y, mth + 1, 0).day;
      var cand = DateTime(y, mth, d.clamp(1, end), hh, mm);
      if (!cand.isBefore(now)) {
        return cand;
      }
      mth += 1;
      end = DateTime(y, mth + 1, 0).day;
      return DateTime(y, mth, d.clamp(1, end), hh, mm);
    }
    // Default daily frequency
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    if (!today.isBefore(now)) {
      return today;
    }
    return today.add(const Duration(days: 1));
  }

  /// Read the next run time (milliseconds) directly from the database for the given task uid.
  /// Returns null if next_time is not present or cannot be parsed.  This helper is used
  /// when cancelling alarms to ensure we always use the latest persisted next_time rather
  /// than recomputing it or using a stale in-memory value.
  Future<int?> _readNextMillisFromDbOrNull(String uid) async {
    try {
      final t = await _taskDao.getByUid(uid);
      final raw = (t?['next_time'] ?? '') as String?;
      if (raw != null && raw.isNotEmpty) {
        try {
          final dt = DateTime.parse(raw);
          return dt.millisecondsSinceEpoch;
        } catch (_) {
          return null;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? '') as String;

    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _saveConfig() async {
    await _configDao.save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
      setState(()=> _editingConfig = false);
      showToast('配置已保存');
    
  }

  
Future<String?> _saveAvatarTemp(File file) async {
  // 保留原始扩展名与尺寸，不裁剪
  final docs = await getApplicationDocumentsDirectory();
  final ext = p.extension(file.path);
  final base = p.basename(file.path);
  final safeName = 'avatar_${DateTime.now().millisecondsSinceEpoch}${ext.isNotEmpty ? ext : p.extension(base)}';
  final dst = File(p.join(docs.path, safeName));
  await dst.writeAsBytes(await file.readAsBytes());
  return dst.path;
}


  Future<void> _openTaskDialog({Map<String, dynamic>? task}) async {
    final isEdit = task != null;

    String name = isEdit ? (task['name'] ?? '') as String : '';
    String type = isEdit ? (task['type'] ?? 'manual') as String : 'manual'; // manual / auto / carousel / 批量导入任务
    String status = isEdit ? (task['status'] ?? 'on') as String : 'on';     // on / off
    String prompt = isEdit ? (task['prompt'] ?? '') as String : '';
    String manualQuote = '';
    String theme = '';
    String authorName = '';
    String sourceFrom = '';
    String explanation = '';
    
    // Prepare avatarPath early; it may be overwritten for bulk-import tasks based on quote avatar
    String avatarPath = isEdit ? (task['avatar_path'] ?? '') as String : '';
    // 回显手动任务或批量导入任务的名言及其他字段
    if (isEdit && (task?['task_uid'] != null)) {
      final taskUid = task!['task_uid'] as String;
      if (type == 'manual') {
        final mq = await QuoteDao().latestForTask(taskUid);
        manualQuote = (mq?['content'] ?? '') as String;
        theme = (mq?['theme'] ?? '') as String;
        authorName = (mq?['author_name'] ?? '') as String;
        sourceFrom = (mq?['source_from'] ?? '') as String;
        explanation = (mq?['explanation'] ?? '') as String;
      } else if (type == '批量导入任务') {
        // Use cursor to select which quote to show.  Default to 0 if missing.
        final cursorVal = (task['cursor'] is int) ? task['cursor'] as int : int.tryParse((task['cursor'] ?? '0').toString()) ?? 0;
        final mq = await QuoteDao().findByTaskOffsetDesc(taskUid, cursorVal);
        if (mq != null) {
          manualQuote = (mq['content'] ?? '') as String;
          theme = (mq['theme'] ?? '') as String;
          authorName = (mq['author_name'] ?? '') as String;
          sourceFrom = (mq['source_from'] ?? '') as String;
          explanation = (mq['explanation'] ?? '') as String;
          // For bulk import tasks, use the quote's avatar for preview
          avatarPath = (mq['avatar'] ?? '') as String;
        }
      }
    }

    // freq
    String freqType = isEdit ? (task['freq_type'] ?? 'daily') as String : 'daily'; // daily/weekly/monthly/custom
    int? selectedWeekday = (task?['freq_weekday'] as int?);
    int? selectedMonthDay = (task?['freq_day_of_month'] as int?);
    TimeOfDay time = _parseTimeOfDay((task?['start_time'] ?? '') as String) ?? const TimeOfDay(hour: 9, minute: 0);
    final formKey = GlobalKey<FormState>();

    // Auto-refresh "next trigger" preview
    Timer? ticker;
    void ensureTicker(StateSetter setStateDialog, BuildContext ctx) {
      ticker ??= Timer.periodic(const Duration(seconds: 30), (_){
        if (Navigator.of(ctx).mounted) setStateDialog((){});
      });
    }

    String two(int n)=> n.toString().padLeft(2,'0');
    String weekdayText(int w){
      const names = ['一','二','三','四','五','六','日'];
      return (w>=1 && w<=7)? names[w-1] : '一';
    }
    DateTime computeNext(DateTime now){
      if (freqType == 'weekly'){
        final wd = (selectedWeekday ?? 1);
        int delta = (wd - now.weekday) % 7;
        var cand = DateTime(now.year, now.month, now.day, time.hour, time.minute).add(Duration(days: delta));
        if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
        return cand;
      } else if (freqType == 'monthly'){
        final d = (selectedMonthDay ?? 1);
        int y = now.year, m = now.month;
        int end = DateTime(y, m + 1, 0).day;
        var cand = DateTime(y, m, d.clamp(1, end), time.hour, time.minute);
        if (!cand.isAfter(now)) {
          m += 1;
          end = DateTime(y, m + 1, 0).day;
          cand = DateTime(y, m, d.clamp(1, end), time.hour, time.minute);
        }
        return cand;
      } else {
        final today = DateTime(now.year, now.month, now.day, time.hour, time.minute);
        if (today.isAfter(now)) return today;
        return today.add(const Duration(days: 1));
      }
    }

    String _fmt(DateTime dt){ String two(int n)=> n.toString().padLeft(2,'0'); return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}'; }
    await showDialog(context: context, builder: (dialogCtx) {
      return StatefulBuilder(
        builder: (ctx, setStateDialog) {
          ensureTicker(setStateDialog, ctx);
          final next = computeNext(DateTime.now());
          final nextStr = '${next.year}-${two(next.month)}-${two(next.day)} ${two(next.hour)}:${two(next.minute)}';

          return AlertDialog(
            title: Text(isEdit ? '编辑任务' : '新增任务'),
            content: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('任务标题'),
                    TextFormField(
                      initialValue: name,
                      onChanged: (v)=> name = v,
                      validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务标题' : null,
                    ),
                    const SizedBox(height: 8),
                    const Text('任务类型'),
                    DropdownButton<String>(
                      value: type,
                      onChanged: (v){ setStateDialog(()=> type = v ?? 'manual'); },
                      items: const [
                        DropdownMenuItem(value: 'manual', child: Text('手动')),
                        DropdownMenuItem(value: 'auto', child: Text('自动')),
                        DropdownMenuItem(value: 'carousel', child: Text('轮播')),
                        DropdownMenuItem(value: '批量导入任务', child: Text('批量导入任务')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (type == 'auto') ...[
                      const Text('提示词'),
                      TextFormField(
                        initialValue: prompt,
                        onChanged: (v)=> prompt = v,
                        validator: (v)=> (type=='auto' && (v==null || v.trim().isEmpty)) ? '请输入提示词' : null,
                      ),
                    ],
                    if (type == 'manual' || type == '批量导入任务') ...[
                      const Text('名人名言'),
                      
TextFormField(
            initialValue: manualQuote,
                        onChanged: (v)=> manualQuote = v,
                        validator: (v)=> (type=='manual' && (v==null || v.trim().isEmpty)) ? '请输入名人名言' : null,
                        minLines: 3,
                        maxLines: null,
                        keyboardType: TextInputType.multiline,
                        textInputAction: TextInputAction.newline,
                      ),

  const SizedBox(height: 8),
  const Text('主题'),
  TextFormField(
    initialValue: theme,
    onChanged: (v) => theme = v,
  ),
  const SizedBox(height: 8),
  const Text('署名'),
  TextFormField(
    initialValue: authorName,
    onChanged: (v) => authorName = v,
  ),
  const SizedBox(height: 8),
  const Text('出处'),
  TextFormField(
    initialValue: sourceFrom,
    onChanged: (v) => sourceFrom = v,
  ),
  const SizedBox(height: 8),
  const Text('简明解释'),
  TextFormField(
    initialValue: explanation,
    onChanged: (v) => explanation = v,
    minLines: 3,
    maxLines: null,
    keyboardType: TextInputType.multiline,
    textInputAction: TextInputAction.newline,
  ),
],
const SizedBox(height: 8),
const Text('头像（用于通知图标）'),
                    Row(
                      children: [
                        // 显示文件名；若未选择则显示提示文字；不展示图片
                        Flexible(
                          child: Text(
                            avatarPath.isNotEmpty ? p.basename(avatarPath) : '未选择',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        OutlinedButton.icon(
                          onPressed: () async {
                            final picker = ImagePicker();
                            final x = await picker.pickImage(source: ImageSource.gallery);
                            if (x != null) {
                              final p = await _saveAvatarTemp(File(x.path));
                              setStateDialog(()=> avatarPath = p ?? '');
                            }
                          },
                          icon: const Icon(Icons.photo),
                          label: const Text('选择图片'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('状态'),
                    DropdownButton<String>(
                      value: status,
                      onChanged: (v){ setStateDialog(()=> status = v ?? 'on'); },
                      items: const [
                        DropdownMenuItem(value: 'on', child: Text('开启')),
                        DropdownMenuItem(value: 'off', child: Text('关闭')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('时间：'),
                    // frequency row
                    Row(
                      children: [
                        DropdownButton<String>(
                          value: freqType,
                          onChanged: (v){ setStateDialog(()=> freqType = v ?? 'daily'); },
                          items: const [
                            DropdownMenuItem(value: 'daily', child: Text('每天')),
                            DropdownMenuItem(value: 'weekly', child: Text('每周')),
                            DropdownMenuItem(value: 'monthly', child: Text('每月')),
                          ],
                        ),
                        const SizedBox(width: 12),
                        if (freqType=='weekly')
                          DropdownButton<int>(
                            value: selectedWeekday ?? 1,
                            onChanged: (v){ setStateDialog(()=> selectedWeekday = v ?? 1); },
                            items: const [
                              DropdownMenuItem(value: 1, child: Text('周一')),
                              DropdownMenuItem(value: 2, child: Text('周二')),
                              DropdownMenuItem(value: 3, child: Text('周三')),
                              DropdownMenuItem(value: 4, child: Text('周四')),
                              DropdownMenuItem(value: 5, child: Text('周五')),
                              DropdownMenuItem(value: 6, child: Text('周六')),
                              DropdownMenuItem(value: 7, child: Text('周日')),
                            ],
                          ),
                        if (freqType=='monthly')
                          DropdownButton<int>(
                            value: (selectedMonthDay ?? 1).clamp(1, 28),
                            onChanged: (v){ setStateDialog(()=> selectedMonthDay = (v ?? 1).clamp(1, 28)); },
                            items: [
                              for (int d=1; d<=28; d++)
                                DropdownMenuItem(value: d, child: Text('$d日')),
                            ],
                          ),
                        const Spacer(),
                        IconButton(
                          onPressed: () async {
                            final t = await showTimePicker(context: ctx, initialTime: time);
                            if (t != null) setStateDialog(()=> time = t);
                          },
                          icon: const Icon(Icons.access_time),
                        ),
                        Text('${two(time.hour)}:${two(time.minute)}'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      () {
                        final hhmm = '${two(time.hour)}:${two(time.minute)}';
                        if (freqType=='weekly') {
                          final w = selectedWeekday ?? 1;
                          return '每周${weekdayText(w)} $hhmm （下一次：$nextStr）';
                        } else if (freqType=='monthly') {
                          final d = selectedMonthDay ?? 1;
                          return '每月${d}日 $hhmm （下一次：$nextStr）';
                        } else {
                          return '每天 $hhmm （下一次：$nextStr）';
                        }
                      }(),
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              if (isEdit)
                TextButton(
                  onPressed: () async {
                    final uid = task!['task_uid'] as String;
                    // Cancel AM/WM using the latest persisted next_time from DB rather than computing a value.
                    try {
                      final nextMillis = await _readNextMillisFromDbOrNull(uid);
                      if (await NativeGuard.isNativeWM()) {
                        await NativeWm.cancelWmByUidBoth(uid);
                      }
                      if (await NativeGuard.isNativeAM()) {
                        if (nextMillis != null) {
                          await NativeAm.cancelExactByNext(uid, nextMillis);
                        } else {
                          final _t = await _taskDao.getByUid(uid);
                          final rk = (_t?['scheduled_run_key'] ?? '') as String?;
                          await NativeAm.cancelExactById(uid, rk);
                        }
                      }
                    } catch (_) {}
                    await SchedulerService.cancelNextForTask(uid);
                    await _taskDao.delete(uid);
                    showToast('已删除任务');
                    await _load();
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('删除'),
                ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: () async {
                  if (formKey.currentState?.validate() != true) return;

                  String? uidToSchedule;

                  // Compose freq_custom for potential future use (not required now)
                  final freqCustomJson = '';

                  if (isEdit) {
                    final patch = <String, dynamic>{
                      'name': name.trim(),
                      'type': type,
                      'prompt': type=='auto' ? prompt.trim() : '',
                      'avatar_path': avatarPath,
                      'status': status,
                      'freq_type': freqType,
                      'freq_weekday': selectedWeekday,
                      'freq_day_of_month': selectedMonthDay,
                      'start_time': _fmt(computeNext(DateTime.now())),
                      'freq_custom': freqCustomJson,
                    };
                    await _taskDao.update(task!['task_uid'] as String, patch);
                    // Cancel existing alarms using the latest persisted next_time from DB rather than computing a value
                    try {
                      final uid = task['task_uid'] as String;
                      final nextMillis = await _readNextMillisFromDbOrNull(uid);
                      if (await NativeGuard.isNativeWM()) {
                        await NativeWm.cancelWmByUidBoth(uid);
                      }
                      if (await NativeGuard.isNativeAM()) {
                        if (nextMillis != null) {
                          await NativeAm.cancelExactByNext(uid, nextMillis);
                        } else {
                          final _t2 = await _taskDao.getByUid(uid);
                          final rk = (_t2?['scheduled_run_key'] ?? '') as String?;
                          await NativeAm.cancelExactById(uid, rk);
                        }
                      }
                    } catch (_) {}
                    await SchedulerService.cancelNextForTask(task['task_uid'] as String);
                    uidToSchedule = task['task_uid'] as String;
                    await _reloadTasksAfterSave();

                                          
                    if (type == 'manual') {
                      final content = manualQuote.trim();
                      if (content.isNotEmpty) {
                        final ok = await QuoteDao().updateLatestForTaskDetailed(
                          taskUid: task['task_uid'] as String,
                          content: content,
                          theme: theme,
                          authorName: authorName,
                          sourceFrom: sourceFrom,
                          explanation: explanation,
                          avatarPath: avatarPath,
                        );
                        if (!ok) {
                          // 按你的要求：编辑手动任务时不新增，只更新
                          showToast('未找到该任务的现有名言（未新增）');
                        }
                      }
                    }
                  } else {
                    final newUid = await _taskDao.create(
                      name: name.trim(),
                      type: type,
                      startTime: _fmt(computeNext(DateTime.now())),
                      prompt: type=='auto' ? prompt.trim() : '',
                      avatarPath: avatarPath,
                      status: status,
                      freqType: freqType,
                      freqWeekday: selectedWeekday,
                      freqDayOfMonth: selectedMonthDay,
                      freqCustom: freqCustomJson,
                    );
                    uidToSchedule = newUid;
                    await _reloadTasksAfterSave();

                    if (type == 'manual') {
                      final content = manualQuote.trim();
                      if (content.isNotEmpty) {
                        final dup = await QuoteDao().existsSimilar(content);
                        if (dup) {
                          showToast('数据重复!请重新输入名人名言');
                          return;
                        }
                        final now = DateTime.now(); String two(int n)=> n<10? '0$n':'$n'; final nowStr='${now.year}-${two(now.month)}-${two(now.day)} ${now.hour}:${two(now.minute)}:${two(now.second)}';
                        await QuoteDao().insertIfUniqueDetailed(taskUid: newUid, content: content, theme: theme, authorName: authorName, sourceFrom: sourceFrom, explanation: explanation, avatarPath: avatarPath, taskName: name, taskType: type, insertedAt: nowStr);
                      }
                    }
                  }

                                    await _load();
                  if (uidToSchedule != null) {
                    await SchedulerService.scheduleNextForTask(uidToSchedule!);
                  }
                  showToast('已保存');
                  if (context.mounted) Navigator.pop(context);
                }
                  ,
                child: const Text('保存'),
              ),
            ],
          );
        },
      );
    });
    ticker?.cancel();
  }

  
  TimeOfDay? _parseTimeOfDay(String startTime){
    // supports 'HH:mm' or 'yyyy-MM-dd HH:mm'
    startTime = (startTime ?? '').trim();
    if (startTime.isEmpty) return null;
    String? hhmm;
    if (RegExp(r'^\d{2}:\d{2}$').hasMatch(startTime)) {
      hhmm = startTime;
    } else {
      final m = RegExp(r'\b(\d{2}:\d{2})\b').firstMatch(startTime);
      hhmm = m?.group(1);
    }
    if (hhmm == null) return null;
    final hm = hhmm.split(':');
    final h = int.tryParse(hm[0]); final m2 = int.tryParse(hm[1]);
    if (h == null || m2 == null) return null;
    return TimeOfDay(hour: h, minute: m2);
  }
  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('API key', style: TextStyle(fontWeight: FontWeight.bold)),
        // Remove underline border for API key input
        TextField(
          controller: _apiKeyCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
        const SizedBox(height: 8),
        const Text('模型名称', style: TextStyle(fontWeight: FontWeight.bold)),
        // Remove underline border for model input
        TextField(
          controller: _modelCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
        const SizedBox(height: 8),
        const Text('接口地址', style: TextStyle(fontWeight: FontWeight.bold)),
        // Remove underline border for endpoint input
        TextField(
          controller: _endpointCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
      ],
    );

    return Scaffold(backgroundColor: Colors.white,
      appBar: AppBar(
        title: const SizedBox.shrink(),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        // Remove the default bottom divider by specifying a zero-height bottom
        bottom: const PreferredSize(preferredSize: Size.fromHeight(0), child: SizedBox()),
        leading: Padding(
          padding: const EdgeInsets.all(10),
          child: Material(
            color: Colors.white,
            elevation: 6,
            shape: const CircleBorder(),
            child: IconButton(
              icon: Icon(_editingConfig ? Icons.save : Icons.edit, color: Colors.black87),
              onPressed: () async {
                if (_editingConfig) {
                  // 如果处于编辑状态，保存配置并退出编辑模式（保存函数内部已处理 _editingConfig=false）
                  await _saveConfig();
                } else {
                  // 当前非编辑状态，进入编辑模式
                  setState(() => _editingConfig = true);
                }
              },
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Material(
              color: Colors.white,
              elevation: 6,
              shape: const CircleBorder(),
              child: IconButton(onPressed: ()=> _openTaskDialog(), icon: const Icon(Icons.add, color: Colors.black87)),
            ),
          ),
        ],
      ),
      body: Padding(
        // Remove top and bottom padding; keep horizontal padding only
        padding: const EdgeInsets.only(left: 12.0, right: 12.0),
        child: ListView(
          children: [
            cfgFields,
            const SizedBox(height: 16),
            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final t in _tasks)
              ListTile(
                title: InkWell(
                  onTap: () => _openTaskDialog(task: t),
                  child: Text((t['name'] ?? '') as String, style: const TextStyle(decoration: TextDecoration.underline)),
                ),
                subtitle: Text('时间: ${(t['start_time'] ?? '') as String}   下一次: ${((t['next_time'] ?? '') as String).toString().replaceFirst('T', ' ').split('.').first}   频率: ${(t['freq_type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}'),
              ),
          ],
        ),
      ),

    );
  }
}

class _SelfCheckConfigWidget extends StatefulWidget {
  const _SelfCheckConfigWidget({super.key});
  @override
  State<_SelfCheckConfigWidget> createState() => _SelfCheckConfigWidgetState();
}
class _SelfCheckConfigWidgetState extends State<_SelfCheckConfigWidget> {
  final _ctrl = TextEditingController();
  bool _loading = true;
  @override
  void initState() {
    super.initState();
    _load();
  }
  Future<void> _load() async {
    final minutes = await NotifyConfigDao().getSelfCheckMinutes();
    setState(() { _ctrl.text = minutes.toString(); _loading=false; });
  }
  Future<void> _save() async {
    final m = int.tryParse(_ctrl.text) ?? 15;
    await NotifyConfigDao().setSelfCheckMinutes(m);
    await SchedulerService.scheduleSelfCheck();
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存自检频率并注册自检任务')));
  }
  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('自检频率（分钟）', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: _ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: '>=15')),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: _save, child: const Text('保存并生效')),
          ],
        ),
      ),
    );
  }
}