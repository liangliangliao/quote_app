package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Single place for native <-> Dart method channel.
 * Channel name must match Dart:  "com.example.quote_app/sys"
 */
object Channels {
    private lateinit var appContext: Context

    fun register(engine: FlutterEngine, context: Context) {
        appContext = context.applicationContext
        MethodChannel(engine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "areNotificationsEnabled" -> {
                        result.success(areNotificationsEnabled())
                    }
                    "shouldAskExactAlarm" -> {
                        // First-run gate: only ask exact-alarm if notifications are enabled AND we don't already have it.
                        val first = (call.argument<Boolean>("firstLaunch") ?: false)
                        result.success(shouldAskExactAlarm(first))
                    }
                    "hasExactAlarmPermission" -> {
                        result.success(hasExactAlarmPermission())
                    }
                    "requestExactAlarmPermission" -> {
                        requestExactAlarmPermission(context)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    fun areNotificationsEnabled(): Boolean {
        return try {
            NotificationManagerCompat.from(appContext).areNotificationsEnabled()
        } catch (_: Throwable) {
            true
        }
    }

    fun shouldAskExactAlarm(firstLaunch: Boolean): Boolean {
        if (!firstLaunch) return false
        if (!areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return !hasExactAlarmPermission()
    }

    fun hasExactAlarmPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    fun requestExactAlarmPermission(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        try {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${appContext.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                // Back key should close and not leave Settings in recents.
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
            // Fallback: open app details settings
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", appContext.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            }
            context.startActivity(intent)
        }
    }
}
