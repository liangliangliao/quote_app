package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {