package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.provider.Settings
import android.app.NotificationManager
import androidx.core.app.AlarmManagerCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : FlutterActivity() {

    private val sysChannel = "com.example.quote_app/sys"
    private val schChannel = "native.scheduler"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // Ensure custom MethodChannels are registered
        Channels.register(flutterEngine, applicationContext)
MethodChannel(flutterEngine.dartExecutor.binaryMessenger, sysChannel).setMethodCallHandler { call, result ->
            when (call.method) {
                "areNotificationsEnabled" -> {
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    result.success(nm.areNotificationsEnabled())
                }
                "openNotificationSettings" -> {
                    val intent = Intent()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        intent.action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                        intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    } else {
                        intent.action = "android.settings.APP_NOTIFICATION_SETTINGS"
                        intent.putExtra("app_package", packageName)
                        intent.putExtra("app_uid", applicationInfo.uid)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    result.success(null)
                }
                "hasExactAlarmPermission" -> {
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        am.canScheduleExactAlarms()
                    } else true
                    result.success(ok)
                }
                "requestExactAlarmPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, schChannel).setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleExactAt" -> {
                    val id = call.argument<Int>("id") ?: 0
                    val epochMs = call.argument<Long>("epochMs") ?: 0L
                    val payload = call.argument<String>("payload") ?: "{}"
                    val intent = Intent(this, com.example.quote_app.am.AlarmReceiver::class.java).apply {
                        action = "com.example.quote_app.ALARM"
                        putExtra("payload", payload)
                        putExtra("task_uid", call.argument<String>("task_uid"))
                        putExtra("run_key", call.argument<String>("run_key"))
                        // pass uid explicitly to AlarmReceiver (extracted from payload if present)
                        try {
                            val j = org.json.JSONObject(payload)
                            val uidFromPayload = j.optString("uid", j.optString("task_uid", null))
                            if (!uidFromPayload.isNullOrEmpty()) {
                                intent.putExtra("uid", uidFromPayload)
                            }
                        } catch (_: Throwable) {}
                    }
                    val pi = PendingIntent.getBroadcast(this, id, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        AlarmManagerCompat.setExactAndAllowWhileIdle(am, AlarmManager.RTC_WAKEUP, epochMs, pi)
                    } else {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
                    }
                    // If exact alarms are not allowed on S+, add a WM fallback to the same time
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        if (!(getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()) {
                            val delay = kotlin.math.max(0L, epochMs - System.currentTimeMillis())
                            val data = workDataOf(
                                "task_uid" to call.argument<String>("task_uid"),
                                "run_key" to call.argument<String>("run_key"),
                                "payload" to payload
                            )
                            val req = OneTimeWorkRequestBuilder<com.example.quote_app.am.NotifyWorker>()
                                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                                .setInputData(Data.Builder().putAll(data).build())
                                .addTag("wm_fb_" + id)
                                .build()
                            WorkManager.getInstance(this).enqueueUniqueWork("wm_fb_" + id, ExistingWorkPolicy.REPLACE, req)
                        }
                    }
                    result.success(true)
                }
                "cancel" -> {
                    val id = call.argument<Int>("id") ?: 0
                    val intent = Intent(this, com.example.quote_app.am.AlarmReceiver::class.java).apply {
                        action = "com.example.quote_app.ALARM"
                    }
                    val pi = PendingIntent.getBroadcast(this, id, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    am.cancel(pi)
                    // Also cancel Java AM receiver PendingIntent for compatibility
                    run {
                        val jIntent = Intent(this, com.example.quote_app.am.AlarmReceiver::class.java).apply {
                            action = "com.example.quote_app.ALARM"
                        }
                        val jPi = PendingIntent.getBroadcast(this, id, jIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        am.cancel(jPi)
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}