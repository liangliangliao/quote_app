package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.example.quote_app.data.DbRepo

/**
 * 兜底：监听 SCREEN_ON，延迟检查是否已解锁（无锁屏/智能解锁等）。
 * 只有确认“已解锁”时，才触发：
 * 1) 解锁轻提醒（直接执行，避免 WorkManager 延迟）
 * 2) 方案B地点规则（快路径 -> 必要时前台兜底）
 * 同时做 3 秒去重，避免与 USER_PRESENT 双触发。
 */
class ScreenOnProbeReceiver : BroadcastReceiver() {

  override fun onReceive(context: Context, intent: Intent?) {
    if (intent?.action != Intent.ACTION_SCREEN_ON) return

    val app = context.applicationContext
    val pending = goAsync()

    try { logWithTime(app, "【解锁后台-探测】收到 SCREEN_ON，600ms 后检查是否已解锁（回包：PROBE）") } catch (_: Throwable) {}

    val km = app.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

    Handler(Looper.getMainLooper()).postDelayed({
      try {
        val isLocked = try { km.isKeyguardLocked } catch (_: Throwable) { true }
        if (isLocked) {
          try { logWithTime(app, "【解锁后台-探测】SCREEN_ON 后仍处于上锁状态，等待 USER_PRESENT（回包：WAIT）") } catch (_: Throwable) {}
          try { pending.finish() } catch (_: Throwable) {}
          return@postDelayed
        }

        // 去重：3 秒窗口内若已触发过解锁链路，则跳过
        val now = System.currentTimeMillis()
        val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        val last = sp.getLong("last_unlock_trigger_ts", 0L)
        if (last > 0 && (now - last) < 3000L) {
          try { logWithTime(app, "【解锁后台-探测】3 秒内已触发过解锁链路，跳过重复（回包：SKIP_DUP）") } catch (_: Throwable) {}
          try { pending.finish() } catch (_: Throwable) {}
          return@postDelayed
        }

        sp.edit()
          .putLong("last_unlock_trigger_ts", now)
          .putLong("last_user_present_ts", now)
          .apply()

        try { logWithTime(app, "【解锁后台-探测】检测到未上锁，判定为已解锁，执行高优先级解锁链路（回包：OK）") } catch (_: Throwable) {}

        // 重要：不要在主线程执行数据库/定位等耗时逻辑，避免卡顿与丢回调
        kotlin.concurrent.thread(name = "screen-on-probe") {
          try {
            UnlockEventHandler.withHighPriority(app, "screen_on_probe") {
              try { UnlockEventHandler.handleUnlockLightReminder(app, source = "screen_on_probe") } catch (t: Throwable) {
                try { logWithTime(app, "【解锁后台-探测】轻提醒处理失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
              }
              try { GeoUnlockOrchestrator.run(app, "screen_on_probe") } catch (t: Throwable) {
                try { logWithTime(app, "【解锁后台-探测】触发 GeoUnlockOrchestrator 失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
              }
            }
          } catch (t: Throwable) {
            try { logWithTime(app, "【解锁后台-探测】后台线程异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
          } finally {
            try { pending.finish() } catch (_: Throwable) {}
          }
        }
      } catch (t: Throwable) {
        try { logWithTime(app, "【解锁后台-探测】异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
        try { pending.finish() } catch (_: Throwable) {}
      }
    }, 600)
  }

  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
