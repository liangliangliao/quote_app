# Virtual Incense Android

这是一个可在 Android Studio 中打开的 Kotlin + Jetpack Compose 示例工程。

## 已修复
- 移除了与 Kotlin 1.9.24 不匹配的 `org.jetbrains.kotlin.plugin.compose` 插件
- 改为经典 Compose 配置：`buildFeatures.compose = true` + `composeOptions.kotlinCompilerExtensionVersion = "1.5.14"`
- 将 `compileSdk` / `targetSdk` 调整为 34，兼容性更稳
- 调整了 `LinearProgressIndicator` 的写法，避免 Material3 版本差异导致的编译问题

## 打开方式
1. 用 Android Studio 打开 `virtual-incense-android` 文件夹
2. 等待 Gradle Sync 完成
3. 运行 `app`

## 环境建议
- Android Studio Jellyfish / Koala 或更新版本
- JDK 17
- Android SDK 34

## 说明
这是一个“模拟上香 / 情绪安定”类 UI 示例，不承诺任何超自然效果。
