import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../main.dart';
import 'package:quote_app/widgets/home_html_view.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver, AutomaticKeepAliveClientMixin<HomePage> {
  bool _tabSubAdded = false;
  bool _firstLoaded = false;
  bool _fav = false;
  Map<String,dynamic>? _latest;
  /* removed periodic Timer for power saving */

  Future<void> _shareLatest() async {
    // 为避免新增依赖，这里用复制到剪贴板作为“分享”的简化实现
    final text = (_latest?['content'] ?? '') as String?;
    if (text == null || text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制，可去任何应用粘贴分享')));
    }
  }


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (!_tabSubAdded) { tabIndexNotifier.addListener(_onTabChange); _tabSubAdded = true; }
    _load();
    
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _load(); // refresh on foreground
    }
  }

  @override
  bool get wantKeepAlive => true;
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (_tabSubAdded) { tabIndexNotifier.removeListener(_onTabChange); _tabSubAdded = false; }
    super.dispose();
  }

  void _onTabChange(){
    try { if (tabIndexNotifier.value == 0) { _load(); } } catch(_){ }
  }

  Future<void> _load() async {
  final dao = QuoteDao();
  // 优先获取“今日已通知”的最新一条记录
  final latestNotified = await dao.latestNotifiedToday();
  try {
    if (latestNotified == null) {
      await DLog.i('HOME', '今日未检索到已通知记录：保持显示原始静态兜底HTML');
    } else {
      final q = (latestNotified['quote_uid'] ?? latestNotified['id'] ?? '').toString();
      final t = (latestNotified['last_notified_at'] ?? latestNotified['last_notify_time'] ?? '').toString();
      await DLog.i('HOME', '已检索到今日最新已通知记录：quote=' + q + ' at=' + t + '，将注入动态数据');
    }
  } catch (_) {}
  setState((){ _latest = latestNotified; _firstLoaded = true; });
}


  @override
  Widget build(BuildContext context) {
    super.build(context);
    final topH = MediaQuery.of(context).padding.top + kToolbarHeight;
    Widget content;
    content = HomeHtmlView(assetPath: 'assets/html/poster-wall-only-frame-v23-1.html', data: _latest);
    return Stack(
      children: [
        // 内容区整体下移并在剩余空间垂直居中，避免进入状态栏/顶栏区域且保持上下留白对称
        Padding(
          padding: EdgeInsets.only(top: topH),
          child: Center(child: content),
        ),
        // 顶部白条
        Positioned(
          left: 0, right: 0, top: 0,
          child: Container(height: topH, color: Colors.white),
        ),
        // 顶栏按钮（左侧三个）
        Positioned(
          left: 8, top: MediaQuery.of(context).padding.top + 8,
          child: Row(
            children: [
              IconButton(onPressed: _shareLatest, icon: const Icon(Icons.share)),
              IconButton(onPressed: () async {
                final text = (_latest?['content'] ?? '') as String?;
                if (text == null || text.isEmpty) return;
                await Clipboard.setData(ClipboardData(text: text));
                if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'))); }
              }, icon: const Icon(Icons.copy)),
              IconButton(onPressed: (){ setState(()=> _fav = !_fav); }, icon: Icon(_fav ? Icons.favorite : Icons.favorite_border)),
            ],
          ),
        ),
      ],
    );
  }
}