package com.example.quote_app

import android.app.Application

/**
 * V2 Embedding Application.
 *
 * We no longer extend FlutterApplication (which belongs to the
 * deprecated v1 Android embedding). Extending the base Application
 * avoids triggering the “deleted Android v1 embedding” build error
 * while preserving any future application‑level initialisation.
 * This class currently acts as a placeholder and does not override
 * any Flutter‑specific lifecycle.  WorkManager initialisation is
 * handled by App.kt.
 */
class MyApp : Application()
