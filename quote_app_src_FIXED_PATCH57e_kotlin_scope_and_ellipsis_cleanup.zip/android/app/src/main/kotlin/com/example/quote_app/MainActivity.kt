package com.example.quote_app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import androidx.work.*
import com.example.quote_app.NotificationUtils
import java.time.*
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {

    companion object {
        private const val REQ_POST_NOTIFICATIONS = 1001
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
        channel.setMethodCallHandler { call, result ->
            when (call.method) {

                "scheduleBackupWork" -> {
                    try {
                        val whenMs = (call.argument<Long>("whenMs") ?: 0L)
                        val title = call.argument<String>("title") ?: "提醒"
                        val body = call.argument<String>("body") ?: "到点啦"
                        val nid = (call.argument<Int>("nid") ?: 1003)
                        val tag = call.argument<String>("tag") ?: ("notif_" + nid)

                        val delayMs = kotlin.math.max(0L, whenMs - java.lang.System.currentTimeMillis())
                        val workData = com.example.quote_app.NotifyWorker.Companion.input(title, body, nid)
                        val req = androidx.work.OneTimeWorkRequestBuilder<com.example.quote_app.NotifyWorker>()
                            .setInputData(workData)
                            .addTag(tag)
                            .setInitialDelay(java.time.Duration.ofMillis(delayMs))
                            .build()
                        androidx.work.WorkManager.getInstance(this).enqueue(req)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("WM_SCHEDULE_FAIL", e.message, null)
                    }
                }
                "cancelBackupWorkByTag" -> {
                    try {
                        val tag = call.argument<String>("tag") ?: return@let result.error("WM_CANCEL_FAIL", "no tag", null)
                        androidx.work.WorkManager.getInstance(this).cancelAllWorkByTag(tag)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("WM_CANCEL_FAIL", e.message, null)
                    }
                }

                "requestExactAlarm" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            val intent = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                            intent.data = Uri.parse("package:$packageName")
                            startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            result.error("OPEN_SETTINGS_FAIL", e.message, null)
                        }
                    } else {
                        result.success(true)
                    }
                }
                "hasExactAlarmPermission" -> {
                    val can = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        am.canScheduleExactAlarms()
                    } else { true }
                    result.success(can)
                }
                
                "scheduleNativeNotification" -> {
                    val useAlarmClock = call.argument<Boolean>("useAlarmClock") ?: false

                    // schedule fallback native notification

                    try {
                        val whenMs = (call.argument<Long>("whenMs") ?: 0L)
                        val title = call.argument<String>("title") ?: ""
                        val body = call.argument<String>("body") ?: ""
                        val nid = (call.argument<Int>("nid") ?: 1002)
                        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                        val pi = android.app.PendingIntent.getBroadcast(
                            this,
                            nid,
                            Intent(this, NativeNotifyReceiver::class.java).apply {
                                putExtra("title", title)
                                putExtra("body", body)
                                putExtra("nid", nid)
                            },
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            if (useAlarmClock) {
                        val showIntent = android.app.PendingIntent.getActivity(
                            this,
                            nid,
                            android.content.Intent(this, MainActivity::class.java).apply { 
                                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                putExtra("from_alarm", true)
                                putExtra("nid", nid)
                            },
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        val info = android.app.AlarmManager.AlarmClockInfo(whenMs, showIntent)
                        am.setAlarmClock(info, pi)
                    } else {
                        am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, whenMs, pi)
                        } else {
                            am.setExact(android.app.AlarmManager.RTC_WAKEUP, whenMs, pi)
                        }
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("NATIVE_SCHEDULE_FAIL", e.message, null)
                    }
                }
                "cancelNativeNotification" -> {
                    try {
                        val nid = (call.argument<Int>("nid") ?: 1002)
                        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                        val pi = android.app.PendingIntent.getBroadcast(
                            this,
                            nid,
                            Intent(this, NativeNotifyReceiver::class.java),
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        am.cancel(pi)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("NATIVE_CANCEL_FAIL", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ensure default notification channel exists
        NotificationUtils.ensureDefaultChannel(this)

        // Android 13+ notification runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationUtils.areNotificationsEnabled(this)) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQ_POST_NOTIFICATIONS
                )
            }
        }

        // NOTE: Per product decision, DO NOT auto-navigate to exact-alarm settings.
        // Users can open system Settings manually to enable Alarms & reminders for this app.

                // One-off diagnostic exact alarm in ~60s (only if permission already granted)
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val can = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
            if (can) {
                val prefs = getSharedPreferences("diag_prefs", Context.MODE_PRIVATE)
                if (!prefs.getBoolean("diag_alarm_scheduled", false)) {
                    val t = System.currentTimeMillis() + 60_000L
                    ExactAlarmTestReceiver.scheduleOnce(this, t)
                    prefs.edit().putBoolean("diag_alarm_scheduled", true).apply()
                }
            }
        } catch (_: Exception) {}
    }
}
