import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import '../data/db.dart';

class DLog {
  static Future<void> i(String tag, String msg) async {
    final now = DateTime.now().toIso8601String();
    final line = "【信息】[$now][$tag] $msg";
    // ignore: avoid_print
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    } catch (_) {}
  }

  static Future<void> w(String tag, String msg) async {
    final now = DateTime.now().toIso8601String();
    final line = "【警告】[$now][$tag] $msg";
    // ignore: avoid_print
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    } catch (_) {}
  }

  static Future<void> e(String tag, String msg) async {
    final now = DateTime.now().toIso8601String();
    final line = "【错误】[$now][$tag] $msg";
    // ignore: avoid_print
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    } catch (_) {}
  }
}
