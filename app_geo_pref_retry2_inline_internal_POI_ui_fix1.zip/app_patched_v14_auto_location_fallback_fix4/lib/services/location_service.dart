import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// Top-level POI model for nearby place selection.
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  const PoiItem({
    required this.name,
    required this.latitude,
    required this.longitude,
    this.address,
    this.distance,
  });
}

/// A helper service to obtain the current device location in a robust manner.
///
/// This service first attempts to use the Geolocator plugin to obtain the
/// current position with high accuracy. If that fails (for example on
/// devices without Google Play services in Mainland China), it falls back
/// to Baidu's IP‑based geolocation API. The Baidu API key is read from
/// the notify_config table (key = 'baidu_ak'). If no key is configured,
/// the fallback will be skipped and null is returned.
class LocationService {
  // Latitude and longitude bounding box for mainland China. These constants
  // are used to determine whether a device's current coordinates fall
  // within the approximate borders of mainland China. If both latitude and
  // longitude lie within these ranges, we consider the device to be in
  // China for the purpose of choosing a location provider.
  static const double _chinaMinLat = 3.86;
  static const double _chinaMaxLat = 53.55;
  static const double _chinaMinLon = 73.66;
  static const double _chinaMaxLon = 135.05;
  /// Attempts to obtain the current position. Returns a [Position] if
  /// successful, otherwise returns null.
  static Future<Position?> getCurrentPositionSmart() async {
    // Try using Geolocator first
    try {
      // Attempt to obtain a fresh location fix with a time limit.  In some indoor
      // environments or on devices without Google Play services, this call may
      // throw or time out.  We wrap it in a try/catch to gracefully handle
      // failures.
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 4),
      );
      // Record a log entry indicating that the standard Geolocator API was used
      // to obtain the location. This helps differentiate overseas provider
      // usage from the Baidu fallback in the logs table.
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator 获取位置：'
            'lat=${pos.latitude}, lon=${pos.longitude}');
      } catch (_) {}
      return pos;
    } catch (_) {
      // ignore and try last known position or Baidu fallback
    }
    // If a current position could not be obtained, attempt to retrieve the last
    // known position from the system.  This is useful when GPS is disabled or
    // no recent fix is available.  If null, fall through to Baidu.
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        try {
          DLog.i('LocationService', '【定位】使用 Geolocator 最近一次已知位置：'
              'lat=${last.latitude}, lon=${last.longitude}');
        } catch (_) {}
        return last;
      }
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // If there is no last known position, attempt to obtain a low-accuracy
    // location via the network/GPS provider. This provides a coarse location
    // quickly before falling back to Baidu IP. This call may still throw
    // exceptions which are caught and ignored.
    try {
      final low = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 4),
      );
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator (低精度) 获取位置：'
            'lat=${low.latitude}, lon=${low.longitude}');
      } catch (_) {}
      return low;
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // Fallback to Baidu IP location if configured
    try {
      final ak = await NotifyConfigDao().getBaiduAk();
      if (ak.trim().isEmpty) {
        return null;
      }
      final url = Uri.parse(
        'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(ak.trim())}&coor=gcj02',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && data['status'] == 0) {
          final content = data['content'];
          if (content is Map) {
            final point = content['point'];
            if (point is Map) {
              final latStr = point['y']?.toString() ?? '';
              final lngStr = point['x']?.toString() ?? '';
              final lat = double.tryParse(latStr);
              final lng = double.tryParse(lngStr);
              if (lat != null && lng != null) {
                // Construct a Position with minimal fields; other fields left at zero
                // Log that Baidu IP location fallback is being used so the logs can
                // differentiate between location providers. Include the coordinates.
                try {
                  DLog.i('LocationService', '【定位】使用 Baidu IP 定位获取位置：'
                      'lat=$lat, lon=$lng');
                } catch (_) {}
                return Position(
                  latitude: lat,
                  longitude: lng,
                  timestamp: DateTime.now(),
                  accuracy: 0,
                  altitude: 0,
                  heading: 0,
                  speed: 0,
                  speedAccuracy: 0,
                  altitudeAccuracy: 0,
                  headingAccuracy: 0,
                );
              }
            }
          }
        }
      }
    } catch (_) {
      // ignore network or JSON errors
    }
    return null;
  }

  /// Attempts to obtain the current position with a bias toward using the
  /// Baidu IP geolocation service when it is configured. This helper first
  /// checks whether a Baidu API key exists in the notify_config table. If a
  /// non‑empty key is found, it will immediately attempt to query Baidu's
  /// `location/ip` endpoint to obtain a coordinate. Should this request
  /// succeed, the resulting position is returned and no further calls are
  /// attempted. If the Baidu lookup fails or no key is configured, this
  /// method falls back to [getCurrentPositionSmart] which uses Geolocator
  /// and then Baidu as a final option. All key steps are logged via DLog so
  /// that the logs table clearly shows which provider was used.
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 统一2分钟超时（自动/手动一致）
    return _getCurrentPositionPreferBaiduInternal().timeout(
      const Duration(minutes: 2),
      onTimeout: () {
        try {
          DLog.i('LocationService', '定位服务在2分钟内未能返回结果，将视为获取当前位置失败');
        } catch (_) {}
        return null;
      },
    );
  }

  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
      if (effectiveAk.isEmpty) return;
      final lat = pos.latitude;
      final lon = pos.longitude;
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?ak=${Uri.encodeComponent(effectiveAk)}&output=json&coordtype=wgs84ll&extensions_poi=1&radius=600&location=$lat,$lon'
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        try {
          final data = jsonDecode(res.body);
          if (data is Map && (data['status'] == 0 || data['status'] == '0')) {
            final result = data['result'];
            if (result is Map) {
              final pois = result['pois'];
              if (pois is List && pois.isNotEmpty) {
                final first = pois.first;
                String? name; int? distance;
                if (first is Map) {
                  final n = first['name']; final d = first['distance'];
                  if (n is String) name = n; if (d is int) distance = d;
                }
                if (name != null) {
                  final suffix = distance != null ? '（约${distance}米）' : '';
                  try { await DLog.i('LocationService', '附近地标：' + name + suffix); } catch (_) {}
                }
              }
            }
          }
        } catch (_) {}
      }
    } catch (_) {}
  }


  static Future<Position?> _getCurrentPositionPreferBaiduInternal() async {
    // 1) 优先系统定位（内部已包含两次高精度重试 + 最近一次已知位置，或至少一次高精度 + lastKnown）
    try {
      final systemPos = await getCurrentPositionSmart();
      if (systemPos != null) {
        try { await _logNearbyLandmarkIfPossible(systemPos); } catch (_) {}
        return systemPos;
      }
    } catch (_) {}

    // 2) 系统失败 -> 兜底百度 IP（粗略），仅当配置/内置AK可用
    String ak = '';
    try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
    final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
    if (effectiveAk.isEmpty) return null;

    int? httpStatus;
    int? baiduStatus;
    String? baiduMessage;
    try {
      final url = Uri.parse(
        'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(effectiveAk)}&coor=gcj02'
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      httpStatus = res.statusCode;
      if (res.statusCode == 200) {
        try {
          final data = jsonDecode(res.body);
          if (data is Map) {
            final rawStatus = data['status'];
            if (rawStatus is int) { baiduStatus = rawStatus; }
            else if (rawStatus is String) { baiduStatus = int.tryParse(rawStatus); }
            final rawMsg = data['message'];
            if (rawMsg is String) { baiduMessage = rawMsg; }
            if (data['status'] == 0) {
              final content = data['content'];
              if (content is Map) {
                final point = content['point'];
                if (point is Map) {
                  final latStr = point['y']?.toString() ?? '';
                  final lngStr = point['x']?.toString() ?? '';
                  final lat = double.tryParse(latStr);
                  final lng = double.tryParse(lngStr);
                  if (lat != null && lng != null) {
                    try { DLog.i('LocationService', '【定位】使用 Baidu IP 兜底定位获取位置：lat=$lat, lon=$lng'); } catch (_) {}
                    return Position(
                      latitude: lat, longitude: lng, timestamp: DateTime.now(),
                      accuracy: 0, altitude: 0, heading: 0, speed: 0,
                      speedAccuracy: 0, altitudeAccuracy: 0, headingAccuracy: 0,
                    );
                  }
                }
              }
            }
          }
        } catch (_) {}
      }
      try {
        await DLog.i(
          'LocationService',
          '调用百度定位服务出现异常(http=${httpStatus ?? -1}, status=${baiduStatus ?? -1}, msg=${baiduMessage ?? ''})，将返回null',
        );
      } catch (_) {}
      return null;
    } catch (_) {
      try {
        await DLog.i(
          'LocationService',
          '调用百度定位服务出现异常(http=${httpStatus ?? -1}, status=${baiduStatus ?? -1}, msg=${baiduMessage ?? ''})，将返回null',
        );
      } catch (_) {}
      return null;
    }
  }

  // --- Nearby POI model & fetcher (non-breaking additions) ---
  /// Fetch nearby POIs (within [radiusMeters]) around [latitude],[longitude].
  /// Client-side filtering by [keyword] and simple paging by [page]/[pageSize].
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    int radiusMeters = 200,
    String keyword = '',
    int page = 1,
    int pageSize = 5,
  }) async {
    String ak = '';
    try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
    final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
    if (effectiveAk.isEmpty) return [];

    final url = Uri.parse(
      'https://api.map.baidu.com/reverse_geocoding/v3/'
      '?ak=${Uri.encodeComponent(effectiveAk)}'
      '&output=json'
      '&coordtype=wgs84ll'
      '&extensions_poi=1'
      '&radius=$radiusMeters'
      '&location=$latitude,$longitude'
    );
    try {
      final res = await http.get(url).timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return [];
      final data = jsonDecode(res.body);
      if (data is! Map || (data['status'] != 0 && data['status'] != '0')) return [];
      final result = data['result'];
      if (result is! Map) return [];
      final pois = result['pois'];
      if (pois is! List) return [];

      final List<String> preferWords = [
        '超市','便利店','商超','商场','购物','广场','市场','公寓','小区','大厦','花园','写字楼','门店','购物中心'
      ];
      List<PoiItem> all = <PoiItem>[];
      for (final item in pois) {
        if (item is! Map) continue;
        final n = item['name']?.toString() ?? '';
        if (n.isEmpty) continue;
        final hasPrefer = preferWords.any((w) => n.contains(w));
        if (!hasPrefer && keyword.isEmpty) continue;
        if (keyword.isNotEmpty && !n.contains(keyword)) continue;

        double? lat, lng;
        final p = item['point'];
        if (p is Map) {
          lat = double.tryParse(p['y']?.toString() ?? '');
          lng = double.tryParse(p['x']?.toString() ?? '');
        } else {
          final loc = item['location'];
          if (loc is Map) {
            lat = double.tryParse(loc['lat']?.toString() ?? '');
            lng = double.tryParse(loc['lng']?.toString() ?? '');
          }
        }
        final dist = int.tryParse(item['distance']?.toString() ?? '');
        if (lat != null && lng != null) {
          all.add(PoiItem(
            name: n,
            address: item['addr']?.toString(),
            latitude: lat,
            longitude: lng,
            distance: dist,
          ));
        }
      }
      all.sort((PoiItem a, PoiItem b) => (a.distance ?? (1 << 30)).compareTo(b.distance ?? (1 << 30)));
      final start = (page - 1) * pageSize;
      if (start >= all.length) return [];
      final end = (start + pageSize).clamp(0, all.length);
      return all.sublist(start, end);
    } catch (_) {
      return [];
    }
  }
}