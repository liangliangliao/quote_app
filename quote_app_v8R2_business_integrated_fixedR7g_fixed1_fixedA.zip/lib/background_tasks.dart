import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:workmanager/workmanager.dart';

import 'utils/debug_logger.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'platform/perm_helper.dart';

class BackgroundTasks {
  static const int _SELF_CHECK_ALARM_ID = 910001; // unique & stable

  /// 注册一个“2分钟一次”的自检任务：
  /// - 若有精确闹钟权限，采用 AlarmManager 精确 oneShotAt + 自我续订；
  /// - 否则，注册 WorkManager one-off (2~3分钟后)，并在执行时自我续订。
  static Future<void> registerSelfCheck() async {
    final hasExact = await PermHelper.hasExactAlarmPermission();
    final now = DateTime.now();
    final next = now.add(const Duration(minutes: 2));

    if (hasExact) {
      await DLog.i('BG', 'register self-check via AlarmManager @ ' + next.toIso8601String());
      await AndroidAlarmManager.oneShotAt(
        next,
        _SELF_CHECK_ALARM_ID,
        BackgroundTasks.selfCheckAlarmCallback,
        exact: true,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
    } else {
      await DLog.i('BG', 'register self-check via WorkManager (~2m)');
      await Workmanager().registerOneOffTask(
        'bg_selfcheck_${now.millisecondsSinceEpoch}',
        'bg_selfcheck',
        initialDelay: const Duration(minutes: 2),
        existingWorkPolicy: ExistingWorkPolicy.keep,
      );
    }
  }

  @pragma('vm:entry-point')
  static Future<void> selfCheckAlarmCallback() async {
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    await DLog.i('BG', 'selfCheckAlarmCallback fired');

    // 做一次“到期任务扫描”+“再排程”
    await SchedulerService.catchupIfMissed();
    await SchedulerService.callback();
    await SchedulerService.scheduleNextForAll();

    // 自我续订下一次自检
    await registerSelfCheck();
  }
}

/// WorkManager 路由：当 job == 'bg_selfcheck' 时触发与 Alarm 相同逻辑
@pragma('vm:entry-point')
void routeBackgroundJobs() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();

    if (task == 'bg_selfcheck') {
      await DLog.i('BG', 'wm selfcheck fired');
      await SchedulerService.catchupIfMissed();
      await SchedulerService.callback();
      await SchedulerService.scheduleNextForAll();
      await BackgroundTasks.registerSelfCheck();
      return Future.value(true);
    }
    return Future.value(false);
  });
}
