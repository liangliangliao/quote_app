package com.example.quote_app.demo_unlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.quote_app.MainActivity

/**
 * 独立 Demo：监听解锁广播并发送一条固定测试通知。
 *
 * - 不依赖项目内的其它业务类（DbRepo / NotifyHelper 等），完全独立；
 * - 只有当显式 startService/stopService 时才会运行；
 * - 不会修改或者影响现有的 ScreenGatekeeperService / UnlockReceiver 等逻辑；
 * - 方便你随时删除：只需移除此文件以及 Manifest 中对应 <service> 配置。
 */
class UnlockDemoService : Service() {

    private val channelId = "unlock_demo_service_channel"

    private var unlockReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()

        // 注册解锁相关广播（用户真正解锁进入桌面）
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                addAction(Intent.ACTION_USER_UNLOCKED)
            }
        }

        unlockReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val act = intent?.action ?: "null"
                // 收到解锁广播时，发送一条简单通知用于测试。
                sendUnlockTestNotification(act)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(unlockReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(unlockReceiver, filter)
            }
        } catch (_: Throwable) {
            // 只是 Demo，不抛异常以免影响其它逻辑
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 将自己提升为前台服务，保证在系统中有更高存活率
        startForeground(9000, buildServiceNotification())
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (unlockReceiver != null) {
                unregisterReceiver(unlockReceiver)
            }
        } catch (_: Throwable) {
        }
        unlockReceiver = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * 用于前台服务本身的常驻通知。
     */
    private fun buildServiceNotification(): Notification {
        createChannelIfNeeded()

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            @Suppress("DEPRECATION")
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pi = PendingIntent.getActivity(
            this,
            1001,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )

        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("解锁通知测试服务运行中")
            .setContentText("用于演示：解锁屏幕后发送测试通知，不影响原有逻辑。")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    /**
     * 真正的“屏幕解锁触发测试通知”逻辑。
     */
    private fun sendUnlockTestNotification(action: String) {
        createChannelIfNeeded()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            @Suppress("DEPRECATION")
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pi = PendingIntent.getActivity(
            this,
            1002,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("from_notification", true)
                .putExtra("notif_type", "unlock_demo")
                .putExtra("payload", action),
            flags
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("屏幕解锁触发通知测试")
            .setContentText("当前广播 Action: $action")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        // 使用一个固定 ID，避免产生大量通知
        nm.notify(9001, notification)
    }

    /**
     * 为 Demo 单独创建一个最低优先级的通知渠道。
     */
    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(channelId) == null) {
                val ch = NotificationChannel(
                    channelId,
                    "解锁通知测试 Demo",
                    NotificationManager.IMPORTANCE_LOW
                )
                ch.description = "用于演示屏幕解锁时发送通知的独立 Demo 渠道。"
                ch.setShowBadge(false)
                nm.createNotificationChannel(ch)
            }
        }
    }
}
