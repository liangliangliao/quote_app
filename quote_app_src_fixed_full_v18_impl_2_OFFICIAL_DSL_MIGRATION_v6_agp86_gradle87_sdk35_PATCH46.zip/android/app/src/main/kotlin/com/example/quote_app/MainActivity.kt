package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hasExactAlarmPermission" -> {
                        result.success(ExactAlarmHelper.hasExactAlarmPermission(this))
                    }
                    "requestExactAlarmPermission" -> {
                        ExactAlarmHelper.requestExactAlarmPermission(this)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

}
