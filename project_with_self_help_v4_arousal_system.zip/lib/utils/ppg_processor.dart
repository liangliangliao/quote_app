import 'dart:math' as math;

/// A lightweight, on-device camera PPG processor.
///
/// Goals:
/// - More stable HR than naive peak counting.
/// - Provide a signal quality score and reject poor samples.
/// - Compute HRV RMSSD from RR intervals (estimated from peaks).
///
/// Note: Camera PPG is sensitive to motion/pressure/lighting. We therefore
/// compute a basic signal quality index (SQI) and require a minimum number of
/// peaks and plausible RR ranges.
class PpgProcessor {
  /// Bandpass filter settings (Hz) for finger PPG.
  /// Typical HR is roughly 0.8–3.0 Hz (48–180 bpm). We'll use a slightly wider
  /// band so the filter still works for both lower and higher HR cases.
  ///
  /// Many mobile PPG implementations use an approximate heart-related band
  /// around 0.5–4 Hz.
  final double hpHz;
  final double lpHz;

  PpgProcessor({this.hpHz = 0.5, this.lpHz = 4.0});

  /// Hyperbolic tangent helper.
  ///
  /// Dart's `dart:math` does not expose `tanh` on all SDK versions,
  /// so we provide a small stable implementation here.
  double _tanh(double x) {
    // Clamp to avoid overflow in exp for large |x|.
    final double xx = x.clamp(-10.0, 10.0);
    final double ePos = math.exp(xx);
    final double eNeg = math.exp(-xx);
    return (ePos - eNeg) / (ePos + eNeg);
  }

  /// Runs bandpass filter (1st order HP + 1st order LP).
  List<double> bandpass(List<double> x, double fs) {
    if (x.length < 4) return x;
    final dt = 1.0 / fs;

    // High-pass (single pole)
    final rcHp = 1.0 / (2.0 * math.pi * hpHz);
    final aHp = rcHp / (rcHp + dt);
    final hp = List<double>.filled(x.length, 0.0);
    hp[0] = 0.0;
    for (int i = 1; i < x.length; i++) {
      hp[i] = aHp * (hp[i - 1] + x[i] - x[i - 1]);
    }

    // Low-pass (single pole)
    final rcLp = 1.0 / (2.0 * math.pi * lpHz);
    final aLp = dt / (rcLp + dt);
    final bp = List<double>.filled(x.length, 0.0);
    bp[0] = hp[0];
    for (int i = 1; i < x.length; i++) {
      bp[i] = bp[i - 1] + aLp * (hp[i] - bp[i - 1]);
    }
    return bp;
  }

  /// Simple moving average smoothing.
  List<double> movingAverage(List<double> x, int win) {
    if (win <= 1 || x.isEmpty) return x;
    final w = math.max(2, win);
    final out = List<double>.filled(x.length, 0.0);
    double sum = 0;
    for (int i = 0; i < x.length; i++) {
      sum += x[i];
      if (i >= w) sum -= x[i - w];
      final denom = (i + 1 < w) ? (i + 1) : w;
      out[i] = sum / denom;
    }
    return out;
  }

  /// Peak detection on a quasi-periodic waveform.
  ///
  /// - threshold = mean + k*std
  /// - enforce a minimum distance between peaks (in samples)
  List<int> findPeaks(List<double> x, {required double fs, double k = 0.6}) {
    if (x.length < 5) return [];
    final mean = x.reduce((a, b) => a + b) / x.length;
    double varianceSum = 0;
    for (final v in x) {
      final d = v - mean;
      varianceSum += d * d;
    }
    final std = math.sqrt(varianceSum / math.max(1, x.length - 1));
    final thr = mean + k * std;

    // Minimum distance between peaks ~ 0.3s (200 bpm max ~ 0.3s period)
    final minDist = math.max(1, (0.30 * fs).round());

    // Additional prominence requirement (reduces false peaks when signal is noisy).
    final prom = 0.25 * std;

    final peaks = <int>[];
    int lastPeak = -minDist;
    for (int i = 1; i < x.length - 1; i++) {
      if (i - lastPeak < minDist) continue;
      final isPeak = x[i] > thr && x[i] > x[i - 1] && x[i] >= x[i + 1];
      if (!isPeak) continue;

      // crude prominence check: peak higher than immediate neighbors by `prom`.
      if ((x[i] - x[i - 1]) < prom || (x[i] - x[i + 1]) < prom) continue;

      peaks.add(i);
      lastPeak = i;
    }
    return peaks;
  }

  /// Compute BPM and RMSSD from peak indices.
  ///
  /// We use a robust median-based approach (BPM from median RR) and reject
  /// large outliers using MAD. This is usually more stable on phone PPG.
  Map<String, double?> computeHrAndHrv({required List<int> peaks, required double fs}) {
    if (peaks.length < 4) {
      return {'bpm': null, 'rmssd': null};
    }

    // RR intervals in milliseconds (from peak-to-peak).
    final rr = <double>[]; // ms
    for (int i = 1; i < peaks.length; i++) {
      final dt = (peaks[i] - peaks[i - 1]) / fs;
      final ms = dt * 1000.0;
      // plausible RR (30–200 bpm)
      if (ms >= 300 && ms <= 2000) rr.add(ms);
    }
    if (rr.length < 3) {
      return {'bpm': null, 'rmssd': null};
    }

    double median(List<double> a) {
      if (a.isEmpty) return double.nan;
      final b = List<double>.from(a)..sort();
      final mid = b.length ~/ 2;
      if (b.length.isOdd) return b[mid];
      return 0.5 * (b[mid - 1] + b[mid]);
    }

    final med0 = median(rr);
    final absDev = rr.map((v) => (v - med0).abs()).toList();
    final mad = median(absDev);

    List<double> cleaned = rr;
    if (mad.isFinite && mad > 1e-9) {
      // 1.4826 * MAD approximates std for normal distributions.
      final thr = 3.0 * 1.4826 * mad;
      cleaned = rr.where((v) => (v - med0).abs() <= thr).toList(growable: false);
      if (cleaned.length < 3) cleaned = rr;
    }

    final medRr = median(cleaned);
    final bpm = 60000.0 / medRr;

    // RMSSD (time-domain HRV) from successive RR differences.
    if (cleaned.length < 3) {
      return {'bpm': bpm, 'rmssd': null};
    }
    final diffs2 = <double>[];
    for (int i = 1; i < cleaned.length; i++) {
      final d = cleaned[i] - cleaned[i - 1];
      diffs2.add(d * d);
    }
    final meanDiff2 = diffs2.reduce((a, b) => a + b) / diffs2.length;
    final rmssd = math.sqrt(meanDiff2);

    return {'bpm': bpm, 'rmssd': rmssd};
  }

  /// Basic signal quality index (SQI) based on peak regularity and amplitude.
  /// Returns 0..1.
  double signalQuality({required List<double> filtered, required List<int> peaks, required double fs}) {
    if (filtered.isEmpty || peaks.length < 4) return 0.0;

    // amplitude proxy
    final maxV = filtered.reduce(math.max);
    final minV = filtered.reduce(math.min);
    final amp = (maxV - minV).abs();
    if (amp < 1e-6) return 0.0;

    // RR regularity
    final rr = <double>[];
    for (int i = 1; i < peaks.length; i++) {
      rr.add((peaks[i] - peaks[i - 1]) / fs);
    }
    if (rr.length < 3) return 0.0;
    final mean = rr.reduce((a, b) => a + b) / rr.length;
    double varianceSum = 0;
    for (final v in rr) {
      final d = v - mean;
      varianceSum += d * d;
    }
    final std = math.sqrt(varianceSum / math.max(1, rr.length - 1));

    // normalize: lower std => higher quality
    final reg = (1.0 - math.min(1.0, std / (0.15 * mean))).clamp(0.0, 1.0);

    // amplitude normalized loosely (avoid device dependence): map amp to 0..1 with tanh
    final ampScore = _tanh(amp / 0.05).clamp(0.0, 1.0);

    return (0.6 * reg + 0.4 * ampScore).clamp(0.0, 1.0);
  }
}
