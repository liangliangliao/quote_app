package com.example.quote_app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.util.Log

object BaiduLocator {
    private const val TAG = "BaiduLocator"

    data class Simple(val latitude: Double, val longitude: Double, val accuracy: Float, val provider: String?)

    @SuppressLint("MissingPermission")
    fun getOnce(ctx: Context, callback: (Simple?) -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            // Try lastKnown from both GPS and Network
            val candidates = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            var best: Location? = null
            for (p in candidates) {
                try {
                    val l = lm.getLastKnownLocation(p)
                    if (l != null && (best == null || l.accuracy < best!!.accuracy)) {
                        best = l
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "getLastKnownLocation($p) failed: ${e.message}")
                }
            }
            if (best != null) {
                callback(Simple(best!!.latitude, best!!.longitude, best!!.accuracy, best!!.provider))
                return
            }
        } catch (e: Exception) {
            Log.w(TAG, "lastKnown failed: ${e.message}")
        }

        // Request single fresh update
        try {
            val criteria = Criteria().apply {
                accuracy = Criteria.ACCURACY_FINE
                isAltitudeRequired = false
                isBearingRequired = false
                isSpeedRequired = false
                powerRequirement = Criteria.POWER_MEDIUM
            }
            val provider = lm.getBestProvider(criteria, true) ?: LocationManager.NETWORK_PROVIDER
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { lm.removeUpdates(this) } catch (_: Exception) {}
                    callback(Simple(location.latitude, location.longitude, location.accuracy, location.provider))
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {}
                override fun onProviderEnabled(p0: String) {}
                override fun onProviderDisabled(p0: String) {}
            }
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            // Fallback timeout in case no callback in time
            android.os.Handler(Looper.getMainLooper()).postDelayed({
                try { lm.removeUpdates(listener) } catch (_: Exception) {}
                callback(null)
            }, 10000)
        } catch (e: Exception) {
            Log.e(TAG, "requestSingleUpdate failed: ${e.message}")
            callback(null)
        }
    }
}
