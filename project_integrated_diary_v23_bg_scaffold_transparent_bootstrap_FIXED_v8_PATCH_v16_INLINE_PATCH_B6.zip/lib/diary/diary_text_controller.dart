import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A TextEditingController that hides attachment marker lines in the raw text like:
///   [图片] /path/to/file
///   [语音] /path/to/file
///
/// Storage remains fully compatible (raw text is unchanged), while the editor/reader
/// UI can render inline previews without exposing file paths.
class DiaryContentController extends TextEditingController {
  DiaryContentController({String? text}) : super(text: text);

  /// Enable inline image preview rendering inside the EditableText (TextField).
  /// Audio is still rendered by the existing preview widgets (to keep playback logic unchanged).
  static const bool kInlineImageInText = true;

  static bool _isMarkerLine(String line) {
    final l = line.trimLeft();
    return l.startsWith('[图片]') || l.startsWith('[语音]');
  }

  static String? _tryParseImagePath(String line) {
    final l = line.trimLeft();
    if (!l.startsWith('[图片]')) return null;
    final idx = l.indexOf(']');
    if (idx < 0) return null;
    final rest = l.substring(idx + 1).trimLeft();
    if (rest.isEmpty) return null;
    return rest;
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final baseStyle = style ?? DefaultTextStyle.of(context).style;

    // Keep marker line text length unchanged but visually hidden.
    // Using tiny font/height avoids affecting layout; the inline WidgetSpan provides the visible preview height.
    final hiddenStyle = baseStyle.copyWith(
      color: Colors.transparent,
      fontSize: 0.01,
      height: 0.001,
      letterSpacing: -1.0,
    );

    final full = value.text;
    final composing = value.composing;
    final composingValid =
        withComposing && composing.isValid && !composing.isCollapsed;

    final lines = full.split('\n');
    final spans = <InlineSpan>[];
    int offset = 0;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i];
      final lineHasNewline = i != lines.length - 1;
      final lineText = lineHasNewline ? '$line\n' : line;
      final segStart = offset;
      final segEnd = offset + lineText.length;

      // If this is an image marker line, render a visible inline preview widget before the hidden raw text.
      final String? imgPath = kInlineImageInText ? _tryParseImagePath(line) : null;
      if (imgPath != null) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: _InlineDiaryImage(path: imgPath),
        ));
      }

      final segStyle = _isMarkerLine(line) ? hiddenStyle : baseStyle;

      void addSpan(String text, TextStyle s) {
        if (text.isEmpty) return;
        spans.add(TextSpan(text: text, style: s));
      }

      // Preserve composing underline behaviour for IME on non-marker lines.
      if (composingValid &&
          composing.start < segEnd &&
          composing.end > segStart &&
          !_isMarkerLine(line)) {
        final a = (composing.start - segStart).clamp(0, lineText.length);
        final b = (composing.end - segStart).clamp(0, lineText.length);
        addSpan(lineText.substring(0, a), segStyle);
        addSpan(
          lineText.substring(a, b),
          segStyle.copyWith(decoration: TextDecoration.underline),
        );
        addSpan(lineText.substring(b), segStyle);
      } else {
        addSpan(lineText, segStyle);
      }

      offset = segEnd;
    }

    return TextSpan(style: baseStyle, children: spans);
  }
}

class _InlineDiaryImage extends StatelessWidget {
  final String path;
  const _InlineDiaryImage({required this.path});

  @override
  Widget build(BuildContext context) {
    final f = File(path);
    if (!f.existsSync()) {
      return const SizedBox.shrink();
    }

    final double w = math.min(MediaQuery.of(context).size.width - 32, 560).toDouble();
    final double h = math.min(MediaQuery.of(context).size.height * 0.35, 320).toDouble();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: SizedBox(
        width: w,
        height: h,
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 4,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(
              f,
              width: w,
              height: h,
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}
