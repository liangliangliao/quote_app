package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

object ExactAlarmHelper {

    @JvmStatic
    fun hasExactAlarmPermission(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * 仅在 Android 12+ 触发授权页；其余版本直接返回 true
     * 返回 true 表示“已尝试拉起或无需授权”，并不代表用户已授予
     */
    @JvmStatic
    fun requestExactAlarmPermission(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${ctx.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                BackCloser.finishOnResume = true
                ctx.startActivity(intent)
                true
            } catch (_: Throwable) {
                false
            }
        } else {
            true
        }
    }
}
