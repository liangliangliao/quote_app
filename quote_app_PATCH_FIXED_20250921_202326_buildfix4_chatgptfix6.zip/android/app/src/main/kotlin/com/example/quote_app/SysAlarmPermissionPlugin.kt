package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.annotation.Keep
import androidx.annotation.NonNull
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler

/**
 * Exposes `hasExactAlarmPermission` & `requestExactAlarmPermission`
 * to Dart via the "com.example.quote_app/sys" channel.
 *
 * Marked with @Keep so it can be discovered by Flutter's reflection‑based
 * plugin auto‑registration for headless isolates.
 */
@Keep
class SysAlarmPermissionPlugin : FlutterPlugin, MethodCallHandler {

    companion object {
        const val CHANNEL = "com.example.quote_app/sys"
        
    }

    private lateinit var channel: MethodChannel
    private lateinit var context: Context

    override fun onAttachedToEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, CHANNEL)
        channel.setMethodCallHandler(this)
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "hasExactAlarmPermission" -> {
                val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        am.canScheduleExactAlarms()
                    } catch (_: Exception) { false }
                } else true
                result.success(ok)
            }
            "requestExactAlarmPermission" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        val intent = android.content.Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:${context.packageName}")
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (_: Exception) { /* ignore */ }
                }
                result.success(null)
            }
            else -> result.notImplemented()
        }
    }
}