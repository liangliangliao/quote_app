package com.example.quote_app

import io.flutter.app.FlutterApplication

/**
 * Minimal Application. We no longer manually register plugins here; Flutter's
 * auto-generated registrant covers the UI engine, while background isolates
 * fall back to cached permission status via PermHelper's try‑catch.
 */
class MyApp : FlutterApplication()
