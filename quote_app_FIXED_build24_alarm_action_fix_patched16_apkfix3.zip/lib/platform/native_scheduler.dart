import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:quote_app/utils/debug_logger.dart';

class NativeScheduler {
  static const MethodChannel _ch = MethodChannel('native.scheduler');

  static int _alarmIdFrom(String uid, String runKey) {
    final v = uid.hashCode ^ runKey.hashCode;
    return (v & 0x7fffffff);
  }

  /// （旧）按 int id 注册精准闹钟（兼容保留）
  static Future<bool> scheduleExactAt({required int id, required int epochMs, Map<String, dynamic>? payload}) async {
    await DLog.i('SCH', '【Dart→原生】AM 注册请求(id='+id.toString()+', epochMs='+epochMs.toString()+')');
    final ok = await _ch.invokeMethod<bool>('scheduleExactAt', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload ?? {}),
    });
    return ok ?? false;
  }

  /// （旧）按 int id 取消精准闹钟（兼容保留）
  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
    await DLog.i('SCH', '【Dart】AM 调用原生取消完成 id='+id.toString());
  }

  /// （身份证）AM 注册
  static Future<bool> scheduleExactAtByIdCard({required String idCard, required int epochMs, Map<String, dynamic>? payload}) async {
    final ok = await _ch.invokeMethod<bool>('scheduleExactAtByIdCard', {
      'id_card': idCard,
      'epochMs': epochMs,
      'payload': jsonEncode(payload ?? {}),
    });
    return ok ?? false;
  }

  /// （身份证）WM 主注册
  static Future<bool> scheduleWmMainByIdCard({required String idCard, required int epochMs, Map<String, dynamic>? payload}) async {
    final ok = await _ch.invokeMethod<bool>('scheduleWmMainByIdCard', {
      'id_card': idCard,
      'epochMs': epochMs,
      'payload': jsonEncode(payload ?? {}),
    });
    return ok ?? false;
  }

  /// （身份证）WM 兜底注册
  static Future<bool> scheduleWmFallbackByIdCard({required String idCard, required int epochMs, Map<String, dynamic>? payload}) async {
    final ok = await _ch.invokeMethod<bool>('scheduleWmFallbackByIdCard', {
      'id_card': idCard,
      'epochMs': epochMs,
      'payload': jsonEncode(payload ?? {}),
    });
    return ok ?? false;
  }

  /// （身份证）取消（AM 或 WM）
  static Future<bool> cancelByIdCard(String idCard) async {
    final ok = await _ch.invokeMethod<bool>('cancelByIdCard', {'id_card': idCard});
    return ok ?? false;
  }
}
