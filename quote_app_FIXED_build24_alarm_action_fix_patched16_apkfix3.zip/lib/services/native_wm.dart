import 'package:flutter/services.dart';
import 'package:quote_app/utils/debug_logger.dart';

class NativeWm {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> cancelByUid(String uid) async {
    try {
      final ret = await _ch.invokeMethod('cancelWmByUid', {'uid': uid});
      return ret == true;
    } catch (_) { return false; }
  }

  /// 统一身份证取消（首选，转发到 native.scheduler）
  static Future<bool> cancelByIdCard(String idCard) async {
    try {
      await DLog.i('SCH', '【Dart→原生】WM 取消请求(身份证)='+idCard);
      const ch2 = MethodChannel('native.scheduler');
      final ret = await ch2.invokeMethod('cancelByIdCard', {'id_card': idCard});
      return ret == true;
    } catch (_) { return false; }
  }
}
