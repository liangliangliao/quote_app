import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');
  // Baidu 插件是否可用；如果发现 MissingPluginException，则标记为 false，后续不再调用 Baidu 通道。
  static bool _baiduPluginAvailable = true;

  /// 获取位置时希望的最大精度（半径）阈值，单位：米。
  /// 当精度大于此阈值时，将视为不满足高精度要求而继续回退到下一方案。
  static const double _desiredAccuracyMeters = 30.0;

  /// 最近一次成功定位所采用的提供者名称（baidu 或 system）。
  /// 如果定位失败或尚未调用，则为 null。
  static String? lastProvider;

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 优先尝试百度定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        // 检查精度：仅当满足阈值时才认为成功
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i('LocationService', '【定位】Baidu SDK成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w('LocationService', '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，回退系统定位');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_) {}
    }
    // 回退系统定位
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i('LocationService', '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w('LocationService', '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_) {}
    }
    // 再尝试使用系统最近一次已知位置作为兜底。
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}
    // 都失败
    lastProvider = null;
    try { await DLog.w('LocationService', '【定位】无法获取符合精度要求的位置'); } catch (_) {}
    return null;
  }

  
  /// 系统定位优先 -> Baidu 兜底 -> lastKnown 最终兜底。

  /// 使用 Baidu 逆地理 API 获取附近 POI 列表。
  /// 若调用失败或状态码非 0，则返回空列表并写入日志。
  /// 使用 Baidu 逆地理 API 获取附近 POI 列表。
  /// 若调用失败或状态码非 0，则返回空列表并写入日志。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 0,
    int pageSize = 10,
  }) async {
    try {
      final ak = await ConfigDao().getBaiduAk();
      final params = <String, String>{
        'ak': ak,
        'output': 'json',
        'coordtype': 'wgs84ll',
        'location': '\$latitude,\$longitude',
        // extensions_poi=1 会返回周边 POI 列表。
        'extensions_poi': '1',
        // 半径 0–1000 米，超过按 1000 处理。
        'radius': radiusMeters.clamp(0, 1000).toString(),
      };

      final uri = Uri.https('api.map.baidu.com', '/reverse_geocoding/v3/', params);
      final resp = await http.get(uri).timeout(const Duration(seconds: 8));
      if (resp.statusCode != 200) {
        try {
          await DLog.w('LocationService', '【POI】Baidu 逆地理请求失败 status=${resp.statusCode}');
        } catch (_) {}
        return <PoiItem>[];
      }

      final data = json.decode(resp.body) as Map<String, dynamic>;
      if (data['status'] != 0) {
        try {
          await DLog.w('LocationService', '【POI】Baidu 逆地理返回错误：${data['status']} ${data['message']}');
        } catch (_) {}
        return <PoiItem>[];
      }

      final result = data['result'] as Map<String, dynamic>?;
      if (result == null) return <PoiItem>[];
      final pois = (result['pois'] as List<dynamic>? ?? const []) as List<dynamic>;

      // Baidu 逆地理自带距离排序；这里简单切片到 page/pageSize。
      final start = (page * pageSize).clamp(0, pois.length);
      final end = (start + pageSize).clamp(0, pois.length);
      final sub = pois.sublist(start, end);

      return sub.map((raw) {
        final m = raw as Map<String, dynamic>;
        final name = (m['name'] ?? '').toString();
        final addr = (m['addr'] ?? '').toString();
        final distRaw = m['distance'];
        double? distance;
        if (distRaw is num) {
          distance = distRaw.toDouble();
        } else if (distRaw != null) {
          distance = double.tryParse(distRaw.toString());
        }

        final point = m['point'] as Map<String, dynamic>? ?? const {};
        final double? lng = (point['x'] as num?)?.toDouble();
        final double? lat = (point['y'] as num?)?.toDouble();

        return PoiItem(
          name: name.isEmpty ? '未知地点' : name,
          address: addr.isEmpty ? null : addr,
          latitude: lat ?? latitude,
          longitude: lng ?? longitude,
          distance: distance,
        );
      }).toList(growable: false);
    } catch (e) {
      try {
        await DLog.w('LocationService', '【POI】Baidu 逆地理解析异常：$e');
      } catch (_) {}
      return <PoiItem>[];
    }
  }

  /// 使用系统逆地理（geocoding 插件）返回一个粗略的附近地点。
  static Future<List<PoiItem>> fetchNearbyPoisSystem({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 0,
    int pageSize = 10,
  }) async {
    try {
      final placemarks = await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isEmpty) return <PoiItem>[];

      final p = placemarks.first;
      final parts = <String>[
        p.country ?? '',
        p.administrativeArea ?? '',
        p.subAdministrativeArea ?? '',
        p.locality ?? '',
        p.subLocality ?? '',
        p.street ?? '',
        p.name ?? '',
      ].where((e) => e.trim().isNotEmpty).toList();

      final addr = parts.join('');
      final name = keyword.isNotEmpty ? '\${keyword}附近' : (p.name ?? '当前位置');

      final item = PoiItem(
        name: name,
        address: addr.isEmpty ? null : addr,
        latitude: latitude,
        longitude: longitude,
        distance: 0,
      );
      return <PoiItem>[item];
    } catch (e) {
      try {
        await DLog.w('LocationService', '【POI】系统逆地理获取失败：$e');
      } catch (_) {}
      return <PoiItem>[];
    }
  }

  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1. 系统高精度
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try {
          await DLog.i(
            'LocationService',
            '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      } else if (sys != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)，尝试 Baidu 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位异常（优先分支）：$e',
        );
      } catch (_) {}
    }

    // 2. Baidu 兜底（如果插件可用）
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try {
          await DLog.i(
            'LocationService',
            '【定位】Baidu SDK 兜底成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      } else if (bd != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu SDK 兜底精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，尝试 lastKnown 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu SDK 兜底异常：$e',
        );
      } catch (_) {}
    }

    // 3. 最后使用最近一次已知位置兜底
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】系统/Baidu/lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }


  /// 使用 Geolocator 的高精度一次性定位。
  static Future<Position?> _getCurrentPositionHighAccuracy() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      try {
        await DLog.w('LocationService', '【定位】系统定位服务未开启');
      } catch (_) {}
      return null;
    }

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      try {
        await DLog.w('LocationService', '【定位】未授予定位权限');
      } catch (_) {}
      return null;
    }

    try {
      // 高精度一次性定位，使用 locationSettings 以适配 geolocator 14.x
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      ).timeout(
        const Duration(seconds: 15),
        onTimeout: () => throw TimeoutException('getCurrentPosition timeout'),
      );
    } on TimeoutException catch (e) {
      try {
        await DLog.w('LocationService', '【定位】系统高精度定位超时：$e');
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】系统高精度定位异常：$e');
      } catch (_) {}
      return null;
    }
  }

  /// 读取系统的 lastKnown 位置；失败返回 null。
  static Future<Position?> _getLastKnownPosition() async {
    try {
      final pos = await Geolocator.getLastKnownPosition();
      if (pos == null) {
        try {
          await DLog.w('LocationService', '【定位】lastKnown 位置为空');
        } catch (_) {}
        return null;
      }
      try {
        await DLog.i(
          'LocationService',
          '【定位】lastKnown 成功 acc=${pos.accuracy}m, lat=${pos.latitude}, lon=${pos.longitude}',
        );
      } catch (_) {}
      return pos;
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】lastKnown 调用异常：$e');
      } catch (_) {}
      return null;
    }
  }

  /// 调用 Baidu SDK 获取一次位置；失败时自动降级并打点日志。
  /// 这里通过 MethodChannel 调用原生实现，如果插件不可用会降级为 null。
  static Future<Position?> _baiduSdkLocationOnce() async {
    if (!_baiduPluginAvailable) return null;

    try {
      final raw = await _sysCh.invokeMethod<Map<dynamic, dynamic>>('baiduLocateOnce');
      if (raw == null) {
        try {
          await DLog.w('LocationService', '【定位】Baidu SDK 返回为空');
        } catch (_) {}
        return null;
      }

      double? _toDouble(dynamic v) {
        if (v == null) return null;
        if (v is double) return v;
        if (v is int) return v.toDouble();
        return double.tryParse(v.toString());
      }

      final lat = _toDouble(raw['latitude']);
      final lon = _toDouble(raw['longitude']);
      if (lat == null || lon == null) {
        try {
          await DLog.w('LocationService', '【定位】Baidu SDK 返回缺少经纬度：$raw');
        } catch (_) {}
        return null;
      }

      final accuracy = _toDouble(raw['accuracy']) ?? 0;
      final altitude = _toDouble(raw['altitude']) ?? 0;
      final heading = _toDouble(raw['heading']) ?? 0;
      final speed = _toDouble(raw['speed']) ?? 0;
      final speedAccuracy = _toDouble(raw['speedAccuracy']) ?? 0;
      final altitudeAccuracy = _toDouble(raw['altitudeAccuracy']) ?? 0;
      final headingAccuracy = _toDouble(raw['headingAccuracy']) ?? 0;

      DateTime ts;
      final tsRaw = raw['timestamp'];
      if (tsRaw is DateTime) {
        ts = tsRaw;
      } else if (tsRaw != null) {
        ts = DateTime.tryParse(tsRaw.toString()) ?? DateTime.now();
      } else {
        ts = DateTime.now();
      }

      final pos = Position(
        longitude: lon,
        latitude: lat,
        timestamp: ts,
        accuracy: accuracy,
        altitude: altitude,
        altitudeAccuracy: altitudeAccuracy,
        heading: heading,
        headingAccuracy: headingAccuracy,
        speed: speed,
        speedAccuracy: speedAccuracy,
        floor: null,
        isMocked: false,
      );

      try {
        await DLog.i(
          'LocationService',
          '【定位】Baidu SDK 原始位置 lat=${pos.latitude}, lon=${pos.longitude}, acc=${pos.accuracy}m',
        );
      } catch (_) {}

      return pos;
    } on MissingPluginException catch (e) {
      // 标记为不可用，后续不再尝试 Baidu 通道。
      _baiduPluginAvailable = false;
      try {
        await DLog.w('LocationService', '【定位】Baidu 插件不可用，降级为系统定位：$e');
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】Baidu SDK 调用异常：$e');
      } catch (_) {}
      return null;
    }
  }

  /// 尝试做一次逆地理解析并写入日志（不会抛出异常）。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        pos.latitude,
        pos.longitude,
      );
      if (placemarks.isEmpty) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】逆地理为空 lat=${pos.latitude}, lon=${pos.longitude}',
          );
        } catch (_) {}
        return;
      }

      final p = placemarks.first;
      final parts = <String>[
        p.country ?? '',
        p.administrativeArea ?? '',
        p.subAdministrativeArea ?? '',
        p.locality ?? '',
        p.subLocality ?? '',
        p.street ?? '',
        p.name ?? '',
      ].where((e) => e.trim().isNotEmpty).toList();

      final addr = parts.join('');
      try {
        await DLog.i(
          'LocationService',
          '【定位】附近地标：$addr (lat=${pos.latitude}, lon=${pos.longitude}, acc=${pos.accuracy}m)',
        );
      } catch (_) {}
    } catch (e) {
      try {
        await DLog.w('LocationService', '【定位】逆地理获取附近地标失败：$e');
      } catch (_) {}
    }
  }

  /// 监听位置流，获取首个位置点；失败或超时返回 null。
  static Future<Position?> _getPositionByStreamOnce({
    LocationAccuracy accuracy = LocationAccuracy.low,
    Duration timeout = const Duration(seconds: 15),
    bool forceLocationManager = false,
  }) async {
    try {
      LocationSettings settings;
      if (Platform.isAndroid) {
        settings = AndroidSettings(
          accuracy: accuracy,
          distanceFilter: 0,
          forceLocationManager: forceLocationManager,
        );
      } else {
        settings = const LocationSettings(
          accuracy: LocationAccuracy.low,
          distanceFilter: 0,
        );
      }
      final stream = Geolocator.getPositionStream(locationSettings: settings);
      final pos = await stream.first.timeout(timeout);
      return pos;
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取超时：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

}