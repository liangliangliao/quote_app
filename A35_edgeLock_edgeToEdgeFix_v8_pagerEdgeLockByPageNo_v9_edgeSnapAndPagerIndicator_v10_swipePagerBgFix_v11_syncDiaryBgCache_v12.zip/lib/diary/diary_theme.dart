import 'package:flutter/foundation.dart';

import '../data/db.dart';

/// Simple in-memory cache for diary background configuration.
/// Diary-related pages can synchronously obtain the latest
/// background image and opacity from here, instead of querying
/// the database on first build (which can cause visible flicker).
class DiaryBgConfig {
  final String? imagePath;
  final double opacity;

  const DiaryBgConfig({this.imagePath, required this.opacity});

  bool get hasImage => imagePath != null && imagePath!.isNotEmpty;
}

class DiaryTheme {
  // Global background configuration for diary pages.
  static final ValueNotifier<DiaryBgConfig> bgConfig =
      ValueNotifier<DiaryBgConfig>(const DiaryBgConfig(imagePath: null, opacity: 0.25));

  static DiaryBgConfig get current => bgConfig.value;

  /// Load the latest configuration from the database into memory.
  /// This should be called once during app start (or diary tab unlock)
  /// so that diary pages can read [current] synchronously.
  static Future<void> reloadFromDatabase() async {
    try {
      await AppDatabase.ensureDiaryColumns();
    } catch (_) {
      // ignore
    }
    try {
      final db = await AppDatabase.instance();
      final rows = await db.rawQuery(
        "SELECT diary_bg_image, diary_bg_opacity FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1",
      );
      String? path;
      double opacity = bgConfig.value.opacity;
      if (rows.isNotEmpty) {
        final img = rows.first['diary_bg_image'];
        final imgStr = img?.toString() ?? '';
        path = imgStr.isEmpty ? null : imgStr;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) {
          opacity = double.tryParse(op.toString()) ?? opacity;
        }
      } else {
        path = null;
      }
      bgConfig.value = DiaryBgConfig(imagePath: path, opacity: opacity);
    } catch (_) {
      // ignore
    }
  }

  /// Update the in-memory configuration immediately when the user
  /// changes diary settings. Persistence to the database is handled
  /// separately by the settings page.
  static void updateInMemory({String? imagePath, required double opacity}) {
    bgConfig.value = DiaryBgConfig(imagePath: imagePath, opacity: opacity);
  }
}
