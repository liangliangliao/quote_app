package com.example.quote_app

import io.flutter.app.FlutterApplication
import io.flutter.plugin.common.PluginRegistry
import io.flutter.plugins.GeneratedPluginRegistrant
import dev.fluttercommunity.plus.androidalarmmanager.AndroidAlarmManagerPlugin

class MyApp : FlutterApplication(), PluginRegistry.PluginRegistrantCallback {

    override fun onCreate() {
        super.onCreate()
        // Register the callback that will be used by the AlarmManager background isolate.
        AndroidAlarmManagerPlugin.setPluginRegistrant(this)
    }

    override fun registerWith(registry: PluginRegistry) {
        GeneratedPluginRegistrant.registerWith(registry)
    }
}