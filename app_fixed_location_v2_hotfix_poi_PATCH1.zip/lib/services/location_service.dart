import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');
  // Baidu 插件是否可用；如果发现 MissingPluginException，则标记为 false，后续不再调用 Baidu 通道。
  static bool _baiduPluginAvailable = true;

  /// 获取位置时希望的最大精度（半径）阈值，单位：米。
  /// 当精度大于此阈值时，将视为不满足高精度要求而继续回退到下一方案。
  static const double _desiredAccuracyMeters = 30.0;

  /// 最近一次成功定位所采用的提供者名称（baidu 或 system）。
  /// 如果定位失败或尚未调用，则为 null。
  static String? lastProvider;

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 优先尝试百度定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        // 检查精度：仅当满足阈值时才认为成功
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i('LocationService', '【定位】Baidu SDK成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w('LocationService', '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，回退系统定位');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_) {}
    }
    // 回退系统定位
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i('LocationService', '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w('LocationService', '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_) {}
    }
    // 再尝试使用系统最近一次已知位置作为兜底。
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}
    // 都失败
    lastProvider = null;
    try { await DLog.w('LocationService', '【定位】无法获取符合精度要求的位置'); } catch (_) {}
    return null;
  }

  
  /// 系统定位优先 -> Baidu 兜底 -> lastKnown 最终兜底。
  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1. 系统高精度
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try {
          await DLog.i(
            'LocationService',
            '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      } else if (sys != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)，尝试 Baidu 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位异常（优先分支）：$e',
        );
      } catch (_) {}
    }

    // 2. Baidu 兜底（如果插件可用）
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try {
          await DLog.i(
            'LocationService',
            '【定位】Baidu SDK 兜底成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      } else if (bd != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu SDK 兜底精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，尝试 lastKnown 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu SDK 兜底异常：$e',
        );
      } catch (_) {}
    }

    // 3. 最后使用最近一次已知位置兜底
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】系统/Baidu/lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

static Future<Position?> _getCurrentPositionHighAccuracy() async {
  final enabled = await Geolocator.isLocationServiceEnabled();
  if (!enabled) {
    try { await DLog.w('LocationService', '【定位】系统定位服务未开启'); } catch (_) {}
    return null;
  }
  LocationPermission perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    try { await DLog.w('LocationService', '【定位】未授予定位权限'); } catch (_) {}
    return null;
  }
  try {
    // 第一次：高精度 + 15s
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.best,
      timeLimit: const Duration(seconds: 15),
    );
  } on TimeoutException catch (e) {
    try { await DLog.w('LocationService','【定位】高精度定位超时，尝试中等精度：$e'); } catch (_){}
    try {
      // 第二次：中精度 + 20s
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 20),
      );
    } on TimeoutException catch (e2) {
      try { await DLog.w('LocationService','【定位】中等精度定位仍然超时：$e2'); } catch (_){}
      // 第三次：位置流拿第一条（低精度）+ 15s；Android 强制使用 LocationManager
      final low = await _getPositionByStreamOnce(
        accuracy: LocationAccuracy.low,
        timeout: const Duration(seconds: 15),
        forceLocationManager: true,
      );
      return low;
    } catch (e2) {
      try { await DLog.w('LocationService','【定位】中等精度定位异常：$e2'); } catch (_){}
      return null;
    }
  } catch (e) {
    try { await DLog.w('LocationService','【定位】系统定位异常：$e'); } catch (_){}
    return null;
  }

  /// 监听位置流，获取首个位置点；失败或超时返回 null。
  static Future<Position?> _getPositionByStreamOnce({
    LocationAccuracy accuracy = LocationAccuracy.low,
    Duration timeout = const Duration(seconds: 15),
    bool forceLocationManager = false,
  }) async {
    try {
      LocationSettings settings;
      if (Platform.isAndroid) {
        settings = AndroidSettings(
          accuracy: accuracy,
          distanceFilter: 0,
          forceLocationManager: forceLocationManager,
        );
      } else {
        settings = LocationSettings(
          accuracy: accuracy,
          distanceFilter: 0,
        );
      }
      final stream = Geolocator.getPositionStream(locationSettings: settings);
      final pos = await stream.first.timeout(timeout);
      return pos;
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取超时：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }


  /// 公共方法：使用百度 Web 逆地理接口获取附近 POI 列表，并在内存中做分页。
  /// - 不论当前位置是通过系统定位还是百度 SDK 定位，只要有经纬度就可以复用这一套逻辑；
  /// - radiusMeters 建议控制在 0–3000 米之间，这里会做简单的安全裁剪；
  /// - page 从 1 开始计数，pageSize 控制每页多少条记录。
  static Future<List<PoiItem>> _fetchNearbyPoisFromBaiduApi({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 1,
    int pageSize = 10,
  }) async {
    final safePage = page < 1 ? 1 : page;
    final safeSize = pageSize <= 0 ? 10 : pageSize;
    final radius = radiusMeters <= 0
        ? 50
        : (radiusMeters > 3000 ? 3000 : radiusMeters);

    try {
      final cfgDao = ConfigDao();
      final ak = await cfgDao.getBaiduAk();

      // 构造请求 URL：使用全球逆地理编码 v3 接口，并开启 POI 返回，按距离排序。
      final sb = StringBuffer(
        'https://api.map.baidu.com/reverse_geocoding/v3/'
        '?ak=$ak'
        '&output=json'
        '&coordtype=wgs84ll'
        '&location=$latitude,$longitude'
        '&extensions_poi=1'
        '&entire_poi=1'
        '&sort_strategy=distance'
        '&radius=$radius',
      );

      final uri = Uri.parse(sb.toString());
      final resp = await http
          .get(uri)
          .timeout(const Duration(seconds: 10));

      if (resp.statusCode != 200) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】百度逆地理请求失败：HTTP ${resp.statusCode}',
          );
        } catch (_) {}
        return [];
      }

      Map<String, dynamic> data;
      try {
        data = jsonDecode(resp.body) as Map<String, dynamic>;
      } catch (e) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】百度逆地理解析失败：$e',
          );
        } catch (_) {}
        return [];
      }

      final status = data['status'];
      if (status != 0) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】百度逆地理返回错误状态：$status',
          );
        } catch (_) {}
        return [];
      }

      final result = (data['result'] as Map<String, dynamic>?) ?? const {};
      final poisRaw = (result['pois'] as List?) ?? const [];

      // 先全部解析成 PoiItem 列表，再在内存里按关键字过滤、分页。
      final all = <PoiItem>[];
      final kw = keyword.trim();

      for (final item in poisRaw) {
        if (item is! Map) continue;
        final map = item.cast<String, dynamic>();

        final rawName = (map['name'] ?? '').toString().trim();
        final rawAddr = (map['address'] ?? '').toString().trim();

        if (kw.isNotEmpty) {
          final text = (rawName + ' ' + rawAddr);
          if (!text.contains(kw)) {
            // 不匹配关键字则跳过。
            continue;
          }
        }

        // Baidu POI 里坐标可能在 point.x/point.y 或 location.lng/location.lat 字段。
        double? lat;
        double? lng;
        final point = map['point'];
        final loc = map['location'];

        if (point is Map) {
          final x = point['x'];
          final y = point['y'];
          if (x is num) lng = x.toDouble();
          if (y is num) lat = y.toDouble();
        }
        if ((lat == null || lng == null) && loc is Map) {
          final lx = loc['lng'];
          final ly = loc['lat'];
          if (lx is num) lng = lx.toDouble();
          if (ly is num) lat = ly.toDouble();
        }

        lat ??= latitude;
        lng ??= longitude;

        final distNum = map['distance'];
        final dist = distNum is num ? distNum.round() : null;

        all.add(PoiItem(
          name: rawName.isEmpty ? '未知地点' : rawName,
          address: rawAddr.isEmpty ? null : rawAddr,
          latitude: lat,
          longitude: lng,
          distance: dist,
        ));
      }

      if (all.isEmpty) return [];

      final start = (safePage - 1) * safeSize;
      if (start >= all.length) return [];

      var end = start + safeSize;
      if (end > all.length) end = all.length;

      return all.sublist(start, end);
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】百度逆地理调用异常：$e',
        );
      } catch (_) {}
      return [];
    }
  }

  /// 使用百度 SDK / Web 服务获取附近 POI（默认路径）。
  /// 实际上 POI 数据统一来自百度逆地理接口，区别仅在于前面获取坐标的方式。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 1,
    int pageSize = 10,
  }) {
    return _fetchNearbyPoisFromBaiduApi(
      latitude: latitude,
      longitude: longitude,
      radiusMeters: radiusMeters,
      keyword: keyword,
      page: page,
      pageSize: pageSize,
    );
  }

  /// 使用「系统定位」获取到的坐标，再去做一次 POI 查询。
  /// 这里同样复用百度逆地理服务，以保证系统逆地理与百度逆地理在表现上的一致性，
  /// 同时也满足“查询附近 50 米内所有标志物并分页返回”的需求。
  static Future<List<PoiItem>> fetchNearbyPoisSystem({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 1,
    int pageSize = 10,
  }) {
    return _fetchNearbyPoisFromBaiduApi(
      latitude: latitude,
      longitude: longitude,
      radiusMeters: radiusMeters,
      keyword: keyword,
      page: page,
      pageSize: pageSize,
    );
  }


}
