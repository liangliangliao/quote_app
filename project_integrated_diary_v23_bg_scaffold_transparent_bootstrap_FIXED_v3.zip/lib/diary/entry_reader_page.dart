import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:audioplayers/audioplayers.dart';
import 'diary_dao.dart';
import 'weather.dart';
import '../data/db.dart';

class EntryReaderPage extends StatefulWidget {
  final int notebookId;
  final int initialEntryId;
  const EntryReaderPage({super.key, required this.notebookId, required this.initialEntryId});

  @override
  State<EntryReaderPage> createState() => _EntryReaderPageState();
}

class _EntryReaderPageState extends State<EntryReaderPage> {
  int _totalCount = 0; int _globalIndex = 0;
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy年MM月dd日 HH:mm');
  final _controller = PageController(initialPage: 1);
  final List<DiaryEntry> _pages = [];
  final Map<String, AudioPlayer> _players = {};
  int _index = 0;

  String? _bgPath;
  double _bgOpacity = 0.25;

  @override
  void dispose() {
    for (final p in _players.values) { try { p.dispose(); } catch (_) {} }
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        _bgPath = (rows.first['diary_bg_image'] ?? '') as String?;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
    } catch (_) {}
    final e = await _dao.getEntry(widget.initialEntryId);
    final total = await _dao.countEntries(widget.notebookId);
    final pos = await _dao.positionOfEntry(widget.notebookId, widget.initialEntryId) ?? 0;
    if (e != null) setState(() { _pages.add(e); _totalCount = total; _globalIndex = pos; });
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(fit: StackFit.expand, children: [
      Opacity(opacity: (1.0 - _bgOpacity).clamp(0.0,1.0), child: Image.file(f, fit: BoxFit.cover)),
      child,
    ]);
  }

  
  Future<bool?> _ensureNewer() async {
    if (_pages.isEmpty) return false;
    final first = _pages.first;
    final next = await _dao.neighbor(notebookId: widget.notebookId, cur: first, newer: true);
    if (next == null) {
      return false;
    }
    setState(() { _pages.insert(0, next); });
    return true;
  }
Future<bool?> _ensureOlder(int targetIndex) async {
    if (targetIndex < _pages.length) return true;
    final last = _pages.last;
    final next = await _dao.neighbor(notebookId: widget.notebookId, cur: last, newer: false);
    if (next == null) {
      
      
      if (mounted) _controller.jumpToPage(_index);
      return false;
    }
    setState(() => _pages.add(next));
    return true;
  }

  
Widget _buildContent(BuildContext context, String content) {
  final lines = content.split(RegExp(r'\r?\n'));
  final widgets = <Widget>[];
  final imgReg = RegExp(r'^\[图片\]\s*(.+)$');
  final audioReg = RegExp(r'^\[语音\]\s*(.+)$');

  for (final raw in lines) {
    final line = raw.trimRight();
    if (line.isEmpty) {
      widgets.add(const SizedBox(height: 8));
      continue;
    }

    final m1 = imgReg.firstMatch(line);
    final m2 = audioReg.firstMatch(line);

    if (m1 != null) {
      final path = m1.group(1)!;
      final f = File(path);
      if (f.existsSync()) {
        widgets.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Image.file(f),
        ));
      } else {
        widgets.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text('[图片不可用] ' + path, style: Theme.of(context).textTheme.bodyLarge),
        ));
      }
    } else if (m2 != null) {
      final path = m2.group(1)!;
      widgets.add(
        StatefulBuilder(builder: (context, setSt) {
          final p = _players.putIfAbsent(path, () => AudioPlayer());
          bool playing = false;
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: IconButton(icon: Icon(playing ? Icons.pause : Icons.play_arrow), onPressed: () async {
              if (playing) {
                await p.pause();
              } else {
                await p.play(DeviceFileSource(path));
              }
              setSt(() { playing = !playing; });
            }),
            title: const Text('语音'),
            subtitle: Text(path),
          );
        }),
      );
    } else {
      widgets.add(Text(line, style: Theme.of(context).textTheme.bodyLarge));
    }
  }

  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets);
}

@override
  Widget build(BuildContext context) {
    return _bgWrap(Scaffold(backgroundColor: ((_bgPath==null||_bgPath!.isEmpty) || (_bgOpacity>=0.999)) ? Colors.white : Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: const Text('日记'), backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0),
      body: SafeArea(child: PageView.builder(physics: EdgeLockPagePhysics(lockToStart: _globalIndex<=0, lockToEnd: _globalIndex>=_totalCount-1), 
        controller: _controller,
        itemCount: _pages.length + 2,
        onPageChanged: (i) async {
          // left swipe -> older
          if (i == _pages.length + 1) {
            final ok = await _ensureOlder(i);
            if (ok == true) {
              setState(() { _index = _pages.length; _globalIndex = (_globalIndex + 1).clamp(0, _totalCount-1); });
            } else {
              
              
              if (mounted) _controller.jumpToPage(_pages.length);
            }
            return;
          }
          // right swipe -> newer
          if (i == 0) {
            final ok = await _ensureNewer();
            if (ok == true) {
              setState(() { _index = 1; _globalIndex = (_globalIndex - 1).clamp(0, _totalCount-1); });
              if (mounted) _controller.jumpToPage(1);
            } else {
              
              
              if (mounted) _controller.jumpToPage(1);
            }
            return;
          }
          final prev = _index; setState(() { _index = i; _globalIndex = (_globalIndex + (i - prev)).clamp(0, _totalCount-1); });
        },
        itemBuilder: (context, i) {
          // Map PageView index (with 2 sentinels) to _pages index
          if (_pages.isEmpty) return const SizedBox.shrink();
          if (i == 0 || i == _pages.length + 1) return const SizedBox.shrink();
          final real = (i - 1).clamp(0, _pages.length - 1);
          final e = _pages[real];
          final w = weatherByCode(e.weatherCode);
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Stack(children:[
              Card(color: Colors.transparent, elevation: 0, 
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(_fmt.format(DateTime.fromMillisecondsSinceEpoch(e.entryTime)), style: Theme.of(context).textTheme.titleMedium)),
                    if (e.weatherCode != null) ...[ Icon(w.icon,size:18), const SizedBox(width:4), Text(w.name) ],
                    const SizedBox(width: 8),
                    if (e.moodIcon != null) Text(e.moodIcon!, style: const TextStyle(fontSize: 18)),
                    if (e.moodName != null) ...[ const SizedBox(width:4), Text(e.moodName!) ],
                  ]),
                  const SizedBox(height: 12),
                  Expanded(child: SingleChildScrollView(child: _buildContent(context, e.content))),
                  const SizedBox(height: 6),
                  Align(alignment: Alignment.centerRight, child: Text('${_globalIndex+1}/$_totalCount')),
                ]),
              ),
            ),
              Positioned(bottom: 8, right: 12, child: DecoratedBox(
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
                child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), child: Text('\${_globalIndex+1}/\$_totalCount', style: const TextStyle(color: Colors.white))),
              )),
          );
        },
      )),
    ));
  }
}


class EdgeLockPagePhysics extends ScrollPhysics {
  final bool lockToStart;
  final bool lockToEnd;
  const EdgeLockPagePhysics({this.lockToStart=false, this.lockToEnd=false, ScrollPhysics? parent}) : super(parent: parent);

  @override
  EdgeLockPagePhysics applyTo(ScrollPhysics? ancestor) {
    return EdgeLockPagePhysics(lockToStart: lockToStart, lockToEnd: lockToEnd, parent: buildParent(ancestor));
  }

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) {
    if (lockToStart && offset > 0) return 0.0;
    if (lockToEnd && offset < 0) return 0.0;
    return super.applyPhysicsToUserOffset(position, offset);
  }

  @override
  double applyBoundaryConditions(ScrollMetrics position, double value) {
    final delta = value - position.pixels;
    if (lockToStart && delta > 0) return delta;
    if (lockToEnd && delta < 0) return delta;
    return super.applyBoundaryConditions(position, value);
  }
}
