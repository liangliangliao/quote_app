import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  final String endpoint; // e.g. https://api.openai.com/v1/responses or /v1/chat/completions
  final String apiKey;
  final String model;

  OpenAIService({required this.endpoint, required this.apiKey, required this.model});

  String _modelOrDefault(String? m) => (m == null || m.trim().isEmpty) ? 'gpt-5' : m.trim();

  Future<String> generateQuote(String prompt) async {
    final uri = Uri.parse(endpoint);
    final headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
    };

    Map<String, dynamic> body;
    if (endpoint.contains('/chat/completions')) {
      body = {
        'model': _modelOrDefault(model),
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      };
    } else {
      // Treat all other endpoints as Responses API for robustness
      body = {
        'model': _modelOrDefault(model),
        'input': prompt,
      };
    }

    final resp = await http.post(uri, headers: headers, body: jsonEncode(body));
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('OpenAI API error ${resp.statusCode}: ${resp.body}');
    }
    final data = jsonDecode(resp.body);

    // Try friendly extraction paths (Responses API)
    try {
      if (data is Map && data['output_text'] != null) {
        return data['output_text'].toString().trim();
      }
      if (data is Map && data['content'] != null) {
        // Responses API sometimes returns content array
        final c = data['content'];
        if (c is List && c.isNotEmpty) {
          final first = c.first;
          if (first is Map && first['text'] != null) {
            final t = first['text'];
            if (t is Map && t['value'] != null) {
              return t['value'].toString().trim();
            }
          }
        }
      }
    } catch (_) {}

    // Chat Completions path
    if (data is Map && data['choices'] is List && (data['choices'] as List).isNotEmpty) {
      final choice0 = (data['choices'] as List).first;
      if (choice0 is Map) {
        if (choice0['message'] is Map) {
          final msg = choice0['message'] as Map;
          final content = msg['content'];
          if (content is String) return content.trim();
          if (content is List && content.isNotEmpty) {
            final first = content.first;
            if (first is Map && first['text'] is Map && first['text']['value'] != null) {
              return first['text']['value'].toString().trim();
            }
          }
        }
        if (choice0['text'] != null) return choice0['text'].toString().trim();
      }
    }

    // Fallback for any 'content' at top-level
    if (data is Map && data['content'] != null) {
      return data['content'].toString().trim();
    }

    throw Exception('无法从响应中解析文本');
  }

  // Compute cosine similarities of candidate vs. corpus using embeddings
  Future<List<double>> cosineSimilarities(String candidate, List<String> corpus) async {
    // Derive base from endpoint
    Uri baseUri;
    try {
      final u = Uri.parse(endpoint);
      if (u.hasScheme && u.host.isNotEmpty) {
        baseUri = Uri(scheme: u.scheme, host: u.host, port: u.hasPort ? u.port : null);
      } else {
        baseUri = Uri.parse('https://api.openai.com');
      }
    } catch (_) {
      baseUri = Uri.parse('https://api.openai.com');
    }
    final embUri = endpoint.contains('/embeddings')
        ? Uri.parse(endpoint)
        : baseUri.replace(path: '/v1/embeddings');

    final headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
    };
    final inputs = [candidate, ...corpus];
    final body = jsonEncode({
      'model': (model.isNotEmpty ? model : 'text-embedding-3-small'),
      'input': inputs
    });
    final resp = await http.post(embUri, headers: headers, body: body);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('embeddings api error: ${resp.statusCode} ${resp.body}');
    }
    final data = jsonDecode(resp.body);
    final vecs = (data['data'] as List)
        .map((e) => (e['embedding'] as List).map((n) => (n as num).toDouble()).toList())
        .toList();

    final ref = vecs.first;
    double dot(List<double> a, List<double> b) {
      double s = 0;
      for (int i = 0; i < a.length; i++) { s += a[i] * b[i]; }
      return s;
    }
    double sqrt(double x) { if (x <= 0) return 0.0; double g = x/2.0; for (int i=0;i<10;i++) { g = 0.5*(g + x/g); } return g; }
    double norm2(List<double> a) { double s = 0; for (final x in a) { s += x*x; } return sqrt(s); }

    final nr = norm2(ref);
    final List<double> sims = [];
    for (int i = 1; i < vecs.length; i++) {
      final v = vecs[i];
      final nv = norm2(v);
      final sim = (nr == 0 || nv == 0) ? 0.0 : dot(ref, v) / (nr * nv);
      sims.add(sim);
    }
    return sims;
  }
}
