import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import '../utils/text_utils.dart';
import 'openai_service.dart';
import '../data/dao_helpers.dart';
import 'notification_service.dart';
import '../platform/perm_helper.dart';

/// 统一调度服务：使用原生 AlarmManager / iOS UNUserNotificationCenter 进行到点触发，
/// 不再依赖 flutter_alarm_manager 或 workmanager。
class SchedulerService {
  static const MethodChannel _schedCh = MethodChannel('com.example.quote_app/sched');
  static bool _inited = false;

  /// 初始化：通知与数据库初始化 + 权限提示 + 重新对所有开启的任务安排闹钟
  static Future<void> init() async {
    if (_inited) return;
    _inited = true;
    WidgetsFlutterBinding.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    // 提示精确闹钟权限
    if (Platform.isAndroid && !(await PermHelper.hasExactAlarmPermission())) {
      // 可以在设置页引导；此处仅记录日志
      try { await LogDao().add(taskUid: 'sys', detail: '缺少精确闹钟权限'); } catch (_) {}
    }
    await rescheduleAllActiveTasks();
  }

  /// 由原生在重启/闹钟触发时调用（通过 bgMain entrypoint）
  static Future<void> onAlarmFired(String taskUid) async {
    WidgetsFlutterBinding.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    final t = await TaskDao().getByUid(taskUid);
    if (t == null) return;
    final status = (t['status'] ?? '').toString();
    if (status != 'on') return;

    await _sendForTask(t);
    // 安排下一次
    await scheduleNextForTask(t);
  }

  /// 重新为所有开启任务安排一次最近的到点闹钟
  static Future<void> rescheduleAllActiveTasks() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      if ((t['status'] ?? '') != 'on') continue;
      await scheduleNextForTask(t);
    }
  }

  /// 安排某任务最近一次的触发点
  static Future<void> scheduleNextForTask(Map<String,dynamic> task) async {
    final when = _nextPlannedDateTime(task);
    if (when == null) return;
    final uid = (task['task_uid'] ?? '').toString();
    final ms = when.millisecondsSinceEpoch;
    try {
      await _schedCh.invokeMethod('scheduleExact', {'taskUid': uid, 'when': ms});
    } catch (_) {}
  }

  static DateTime? _parseTimeOrToday(String hhmm) {
    final now = DateTime.now();
    try {
      final dt = DateFormat('HH:mm').parseStrict(hhmm);
      return DateTime(now.year, now.month, now.day, dt.hour, dt.minute);
    } catch (_) { return null; }
  }

  static DateTime? _nextPlannedDateTime(Map<String,dynamic> task) {
    final startStr = (task['start_time'] ?? '').toString();
    final base = _parseTimeOrToday(startStr);
    if (base == null) return null;
    // 简化：统一按每天固定时间触发（freq 逻辑保持字段占位，不改变业务）
    var when = DateTime.now().isAfter(base) ? base.add(const Duration(days:1)) : base;
    return when;
  }

  /// 业务派发（自动/手动/轮播）
  static Future<void> _sendForTask(Map<String,dynamic> t) async {
    final type = (t['type'] ?? 'manual').toString();
    final uid = (t['task_uid'] ?? '').toString();

    if (type == 'auto') {
      await _handleAutoTask(t);
    } else if (type == 'carousel') {
      await _handleCarouselTask(t);
    } else {
      await _handleManualTask(t);
    }
  }

  static Future<void> _handleManualTask(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    // 取联表名言内容
    final q = await QuoteDao().latestForTask(uid);
    if (q == null) {
      await LogDao().add(taskUid: uid, detail: '手动任务：未找到名言内容');
      return;
    }
    final title = (t['name'] ?? '').toString();
    final body = (q['content'] ?? '').toString();
    final avatar = (t['avatar_path'] ?? '').toString();
    await NotificationService.show(title: title, body: accepted, payload: uid, avatarPath: avatar.isEmpty ? null : avatar);
    await QuoteDao().markNotified(q['quote_uid'].toString());
  }

  static Future<void> _handleCarouselTask(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    final row = await QuoteDao().carouselNextSequential(uid);
    if (row == null) {
      await LogDao().add(taskUid: uid, detail: '轮播任务：没有名言可发送');
      return;
    }
    final title = (t['name'] ?? '').toString();
    final body = (row['content'] ?? '').toString();
    final avatar = (t['avatar_path'] ?? '').toString();
    await NotificationService.show(title: title, body: accepted, payload: uid, avatarPath: avatar.isEmpty ? null : avatar);
    await QuoteDao().markNotified(row['quote_uid'].toString());
  }

  static Future<void> _handleAutoTask(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    final prompt = (t['prompt'] ?? '').toString();

    final cfg = await ConfigDao().getOne();
    final model = (cfg['model'] ?? 'gpt-5').toString().isEmpty ? 'gpt-5' : (cfg['model'] ?? 'gpt-5').toString();
    final key = (cfg['api_key'] ?? '').toString();
    final endpoint = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses').toString();

    if (key.isEmpty) {
      await LogDao().add(taskUid: uid, detail: '调用openai api发生错误或失败!(缺少api key)');
      return;
    }

    // 最多重试去重 10 次
    int tries = 0;
    String? accepted;
    while (tries < 10 && accepted == null) {
      tries++;
      try {
        final api = OpenAIService(endpoint: endpoint, apiKey: key, model: model);
        final content = (await api.generateQuote(prompt)).trim();
        if (content.isEmpty) throw Exception('空返回');

        final ok = await _dedupCheck(uid, content, key); // 语义>0.9 判定
        if (ok) {
          accepted = content;
          break;
        } else {
          await LogDao().add(taskUid: uid, detail: '去重未通过，重试第$tries次');
        }
      } catch (e) {
        await LogDao().add(taskUid: uid, detail: '调用openai api发生错误或失败!');
        return;
      }
    }

    if (accepted == null) {
      await LogDao().add(taskUid: uid, detail: '错误!连续调用api10次去重检验未通过！');
      return;
    }

    // 插入名言并记录日志
    final qUid = await QuoteDao().insert(taskUid: uid, taskName: (t['name'] ?? '').toString(), avatar: (t['avatar_path'] ?? '').toString(), content: accepted!, taskType: (t['type'] ?? '').toString()).toString(), taskType: (t['type'] ?? '').toString(), avatarPath: (t['avatar_path'] ?? '').toString());
    await LogDao().add(taskUid: uid, detail: '成功!');

    // 发送通知
    final title = (t['name'] ?? '').toString();
    final avatar = (t['avatar_path'] ?? '').toString();
    await NotificationService.show(title: title, body: accepted, payload: uid, avatarPath: avatar.isEmpty ? null : avatar);
    await QuoteDao().markNotified(qUid);
  }

  /// 语义去重：如有 embeddings 配置则调用，否则回退到 Jaro-Winkler 文本相似度
  static Future<bool> _dedupCheck(String taskUid, String candidate, String apiKey) async {
    final rows = await QuoteDao().allContentsForTask(taskUid);
    if (rows.isEmpty) return true;

    // 优先 embeddings
    try {
      final sims = await OpenAIService(endpoint: 'https://api.openai.com/v1/embeddings', apiKey: apiKey, model: 'text-embedding-3-small').cosineSimilarities(candidate, rows.map((e)=> e['content'].toString()).toList());
      final maxSim = sims.isEmpty ? 0.0 : sims.reduce((a,b)=> a>b?a:b);
      return maxSim < 0.9;
    } catch (_) {
      // fallback: Jaro-Winkler on normalized text
      final cand = normalizeText(candidate);
      double mx = 0.0;
      for (final r in rows) {
        final s = normalizeText(r['content'].toString());
        mx = mx > jaroWinkler(cand, s) ? mx : jaroWinkler(cand, s);
        if (mx >= 0.9) break;
      }
      return mx < 0.9;
    }
  }

  static String _fmt(DateTime dt) {
    String two(int n)=> n.toString().padLeft(2,'0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}';
  }
}
