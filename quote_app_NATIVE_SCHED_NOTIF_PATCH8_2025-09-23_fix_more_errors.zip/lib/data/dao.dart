import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  return '${prefix}-${ts}-${r.nextInt(1<<32)}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    // initialize default row
    final id = await db.insert('configs', {
      'api_key': '',
      'model': 'gpt-5',
      'endpoint': 'https://api.openai.com/v1/responses',
    });
    final one = await db.query('configs', limit: 1);
    return one.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint}) async {
    final db = await AppDatabase.instance();
    final has = await db.query('configs', limit: 1);
    if (has.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint});
    } else {
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint});
    }
  }
}

class TaskDao {
  Future<List<Map<String,dynamic>>> all() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', orderBy: 'id DESC');
    return rows;
  }

  Future<Map<String,dynamic>?> getByUid(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<String> create({
    required String name,
    required String type,
    required DateTime startTime,
    String prompt='',
    String avatarPath='',
    String status='on',
    String freqType='daily',
    int? freqWeekday,
    int? freqDayOfMonth,
    String freqCustom='',
  }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'start_time': _fmt(startTime),
      'prompt': prompt,
      'avatar_path': avatarPath,
      'status': status,
      'freq_type': freqType,
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': freqCustom,
    });
    return uid;
  }

  Future<void> update(String uid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [uid]);
  }

  Future<void> delete(String uid) async {
    final db = await AppDatabase.instance();
    // Fill snapshots in logs before deleting the task (so历史保留)
    final t = await getByUid(uid);
    if (t != null) {
      await db.rawUpdate(
        "UPDATE logs SET task_name_snapshot = COALESCE(task_name_snapshot, ?), task_start_time_snapshot = COALESCE(task_start_time_snapshot, ?) WHERE task_uid = ?",
        [ (t['name'] ?? '') as String, (t['start_time'] ?? '') as String, uid ]
      );
    }
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [uid]);
  }
}

class QuoteDao {
  // 顺序轮播（不看notified与类型）：按id升序，每次取下一条；游标保存在meta表
  Future<Map<String,dynamic>?> carouselNextSequential(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC');
    if (rows.isEmpty) return null;
    final key = 'carousel_index_' + taskUid;
    final metaRows = await db.query('meta', where: 'k=?', whereArgs: [key], limit: 1);
    int idx = -1;
    if (metaRows.isNotEmpty) {
      final v = metaRows.first['v']?.toString() ?? '-1';
      idx = int.tryParse(v) ?? -1;
    }
    final nextIdx = (idx + 1) % rows.length;
    final row = rows[nextIdx];
    // 更新游标
    if (metaRows.isEmpty) {
      await db.insert('meta', {'k': key, 'v': nextIdx.toString()});
    } else {
      await db.update('meta', {'v': nextIdx.toString()}, where: 'k=?', whereArgs: [key]);
    }
    return row;
  }


  // 最近一条名言（含任务名）
  Future<Map<String,dynamic>?> latestOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
      'SELECT q.*, t.name AS task_name FROM quotes q LEFT JOIN tasks t ON t.task_uid = q.task_uid ORDER BY q.id DESC LIMIT 1');
    return rows.isNotEmpty ? rows.first : null;
  }

  // 名言历史分页（可搜索）
  Future<List<Map<String,dynamic>>> latest({int limit=100, int offset=0, String? q}) async {
    final db = await AppDatabase.instance();
    if (q == null || q.isEmpty) {
      return await db.rawQuery(
        'SELECT q.*, t.name AS task_name FROM quotes q LEFT JOIN tasks t ON t.task_uid = q.task_uid ORDER BY q.id DESC LIMIT ? OFFSET ?',
        [limit, offset],
      );
    } else {
      final like = '%' + q.replaceAll('\\', '\\\\').replaceAll('%','\\%').replaceAll('_','\\_') + '%';
      return await db.rawQuery(
        'SELECT q.*, t.name AS task_name FROM quotes q LEFT JOIN tasks t ON t.task_uid = q.task_uid '
        "WHERE q.content LIKE ? ESCAPE '\\' OR t.name LIKE ? ESCAPE '\\' "
        'ORDER BY q.id DESC LIMIT ? OFFSET ?',
        [like, like, limit, offset],
      );
    }
  }


  Future<Map<String,dynamic>?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final q = await latestForTask(taskUid);
    if (q == null) return false;
    await db.update('quotes', {'content': content}, where: 'id=?', whereArgs: [q['id']]);
    return true;
  }

  Future<bool> existsSimilar(String content, {double threshold = 0.9}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content']);
    final source = normalizeText(content);
    for (final r in rows) {
      final s = normalizeText((r['content'] ?? '') as String);
      if (s == source) return true;
      if (jaroWinkler(s, source) >= threshold) return true;
    }
    return false;
  }

  Future<String> insertIfUnique({
    required String taskUid,
    required String type,
    required String taskName,
    required String avatarPath,
    required String content,
  }) async {
    final db = await AppDatabase.instance();
    // dedup is expected to be done before calling this in auto-mode; still protect here
    final exists = await existsSimilar(content, threshold: 0.9);
    if (exists) return '';
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'content': content,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    // Write a log with snapshot
    await LogDao().add(taskUid: taskUid, detail: '成功! 已插入名言');
    return uid;
  }

  // For carousel: get next quote for task (oldest not yet notified)
  Future<Map<String,dynamic>?> nextForCarousel(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes',
        where: 'task_uid=? AND (notified IS NULL OR notified=0)', whereArgs: [taskUid],
        orderBy: 'id ASC', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    // If all notified, reset and return oldest
    await db.update('quotes', {'notified': 0}, where: 'task_uid=?', whereArgs: [taskUid]);
    final reset = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC', limit: 1);
    return reset.isNotEmpty ? reset.first : null;
  }

  Future<void> markNotified(int id) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'id=?', whereArgs: [id]);
  }


  /// 插入一条名人名言
  Future<String> insert({required String taskUid, required String taskName, required String avatar, required String content, required String taskType}) async {
    final db = await AppDatabase.instance();
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'task_name': taskName,
      'task_avatar': avatar,
      'task_type': taskType,
      'content': content,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    return uid;
  }
}

class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    String? name;
    String? startTime;
    // snapshot
    final trows = await db.query('tasks', where: 'task_uid=?', whereArgs: [taskUid], limit: 1);
    if (trows.isNotEmpty) {
      name = (trows.first['name'] ?? '') as String;
      startTime = (trows.first['start_time'] ?? '') as String;
    }
    await db.insert('logs', {
      'log_uid': _uid('log'),
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'task_name_snapshot': name,
      'task_start_time_snapshot': startTime,
    });
  }

  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0}) async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
      'SELECT logs.*, '
      'COALESCE(logs.task_name_snapshot, tasks.name, "") AS task_name, '
      'COALESCE(logs.task_start_time_snapshot, tasks.start_time, "") AS task_start_time '
      'FROM logs LEFT JOIN tasks ON tasks.task_uid = logs.task_uid '
      'ORDER BY logs.id DESC LIMIT ? OFFSET ?', [limit, offset]);
    return rows;
  }
}

String _fmt(DateTime dt) {
  String two(int n)=> n.toString().padLeft(2,'0');
  return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}';
}
