import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/dao.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _fav = false;
  Map<String,dynamic>? _latest;
  Timer? _timer;

  Future<void> _shareLatest() async {
    // 为避免新增依赖，这里用复制到剪贴板作为“分享”的简化实现
    final text = (_latest?['content'] ?? '') as String?;
    if (text == null || text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制，可去任何应用粘贴分享')));
    }
  }


  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 5), (_)=> _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final dao = QuoteDao();
    final rows = await dao.all(limit: 1, offset: 0);
    setState(()=> _latest = rows.isNotEmpty ? rows.first : null);
  }

  @override
  Widget build(BuildContext context) {
    final topH = MediaQuery.of(context).padding.top + kToolbarHeight;
    Widget content;
    if (_latest == null) {
      content = const Center(child: Text('暂无数据！'));
    } else {
      content = Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Text(
            (_latest!['content'] ?? '') as String,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      );
    }
    return Stack(
      children: [
        // 内容区整体下移，避免进入状态栏/顶栏区域
        Padding(
          padding: EdgeInsets.only(top: topH),
          child: content,
        ),
        // 顶部白条
        Positioned(
          left: 0, right: 0, top: 0,
          child: Container(height: topH, color: Colors.white),
        ),
        // 顶栏按钮（左侧三个）
        Positioned(
          left: 8, top: MediaQuery.of(context).padding.top + 8,
          child: Row(
            children: [
              IconButton(onPressed: _shareLatest, icon: const Icon(Icons.share)),
              IconButton(onPressed: () async {
                final text = (_latest?['content'] ?? '') as String?;
                if (text == null || text.isEmpty) return;
                await Clipboard.setData(ClipboardData(text: text));
                if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'))); }
              }, icon: const Icon(Icons.copy)),
              IconButton(onPressed: (){ setState(()=> _fav = !_fav); }, icon: Icon(_fav ? Icons.favorite : Icons.favorite_border)),
            ],
          ),
        ),
      ],
    );
  }
