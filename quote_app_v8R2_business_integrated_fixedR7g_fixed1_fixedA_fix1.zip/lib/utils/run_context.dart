class RunContext {
  static bool isBackground = false;
}
