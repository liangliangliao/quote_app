import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  final String endpoint; // e.g., https://api.openai.com/v1/responses or /chat/completions
  final String apiKey;
  final String model;

  OpenAIService({required this.endpoint, required this.apiKey, required this.model});

  Future<String> generateQuote(String prompt) async {
    final uri = Uri.parse(endpoint);
    final headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json'
    };

    Map<String, dynamic> payload;
    if (endpoint.contains('/responses')) {
      payload = {
        'model': model,
        'input': '给我一句简洁的中文名人名言，并附作者或来源。主题：$prompt'
      };
    } else {
      payload = {
        'model': model,
        'messages': [
          {'role': 'system', 'content': '你是一位擅长中文名人名言的助手，只返回一句完整的名人名言并附上作者或来源。'},
          {'role': 'user', 'content': '主题：$prompt'}
        ]
      };
    }

    final resp = await http.post(uri, headers: headers, body: jsonEncode(payload));
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
    }

    final data = jsonDecode(utf8.decode(resp.bodyBytes));

    // Responses API
    if (data is Map && data['output'] != null) {
      final out = data['output'];
      if (out is List && out.isNotEmpty) {
        final first = out.first;
        if (first is Map && first['content'] is List && first['content'].isNotEmpty) {
          final txt = first['content'][0]['text']?['value'] ?? '';
          return txt.toString().trim();
        }
      }
    }

    // Chat Completions API
    if (data is Map && data['choices'] is List && data['choices'].isNotEmpty) {
      final msg = data['choices'][0]['message'];
      final content = (msg is Map) ? (msg['content'] ?? '') : '';
      return content.toString().trim();
    }

    if (data is Map && data['content'] != null) {
      return data['content'].toString().trim();
    }
    throw Exception('未知返回结构');
  }
}