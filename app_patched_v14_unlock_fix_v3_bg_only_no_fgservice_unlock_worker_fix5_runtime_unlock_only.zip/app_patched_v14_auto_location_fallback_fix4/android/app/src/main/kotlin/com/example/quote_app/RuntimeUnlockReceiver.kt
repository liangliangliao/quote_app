package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 运行时注册的“解锁事件”接收器（轻活）：
 * - 仅监听 ACTION_USER_PRESENT（用户已解锁）
 * - 收到后仅做：中文日志 + Toast 提示 + 触发 UnlockWorker（后台完成全部业务）
 * - 不做数据库/冷却/通知等重活，避免阻塞广播线程
 */
class RuntimeUnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val act = intent?.action ?: "null"
    try {
      DbRepo.log(context, null, "【解锁后台】RuntimeUnlockReceiver 触发，action="+act+"（仅做轻活：日志+Toast+触发后台）")
    } catch (_: Throwable) {}

    // 立刻 Toast 告知
    try {
      Handler(Looper.getMainLooper()).post {
        Toast.makeText(context.applicationContext, "已解锁：后台正在处理轻提醒…", Toast.LENGTH_SHORT).show()
      }
    } catch (_: Throwable) {}

    // 触发后台 UnlockWorker（唯一工作名 + REPLACE，具备刷新一次的语义）
    try {
      UnlockWorker.trigger(context.applicationContext)
    } catch (_: Throwable) {}
  }
}
