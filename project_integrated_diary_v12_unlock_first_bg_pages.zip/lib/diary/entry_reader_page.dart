import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'diary_dao.dart';
import 'weather.dart';
import '../data/db.dart';

class EntryReaderPage extends StatefulWidget {
  final int notebookId;
  final int initialEntryId;
  const EntryReaderPage({super.key, required this.notebookId, required this.initialEntryId});

  @override
  State<EntryReaderPage> createState() => _EntryReaderPageState();
}

class _EntryReaderPageState extends State<EntryReaderPage> {
  int _totalCount = 0; int _globalIndex = 0;
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy年MM月dd日 HH:mm');
  final _controller = PageController();
  final List<DiaryEntry> _pages = [];
  int _index = 0;

  String? _bgPath;
  double _bgOpacity = 0.25;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        _bgPath = (rows.first['diary_bg_image'] ?? '') as String?;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
    } catch (_) {}
    final e = await _dao.getEntry(widget.initialEntryId);
    final total = await _dao.countEntries(widget.notebookId);
    final pos = await _dao.positionOfEntry(widget.notebookId, widget.initialEntryId) ?? 0;
    if (e != null) setState(() { _pages.add(e); _totalCount = total; _globalIndex = pos; });
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(fit: StackFit.expand, children: [
      Opacity(opacity: _bgOpacity.clamp(0.0,1.0), child: Image.file(f, fit: BoxFit.cover)),
      child,
    ]);
  }

  
  Future<bool?> _ensureNewer() async {
    if (_pages.isEmpty) return false;
    final first = _pages.first;
    final next = await _dao.neighbor(notebookId: widget.notebookId, cur: first, newer: true);
    if (next == null) {
      return false;
    }
    setState(() { _pages.insert(0, next); });
    return true;
  }
Future<bool?> _ensureOlder(int targetIndex) async {
    if (targetIndex < _pages.length) return true;
    final last = _pages.last;
    final next = await _dao.neighbor(notebookId: widget.notebookId, cur: last, newer: false);
    if (next == null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已经是最早一篇')));
      await Future.delayed(const Duration(milliseconds: 300));
      if (mounted) _controller.jumpToPage(_index);
      return false;
    }
    setState(() => _pages.add(next));
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: const Text('日记')),
      body: _bgWrap(PageView.builder(
        controller: _controller,
        itemCount: _pages.length + 2,
        onPageChanged: (i) async {
          // left swipe -> older
          if (i == _pages.length + 1) {
            final ok = await _ensureOlder(i);
            if (ok == true) {
              setState(() { _index = _pages.length; _globalIndex = (_globalIndex + 1).clamp(0, _totalCount-1); });
            } else {
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已经是最早一篇')));
              await Future.delayed(const Duration(milliseconds: 200));
              if (mounted) _controller.jumpToPage(_pages.length);
            }
            return false;
          }
          // right swipe -> newer
          if (i == 0) {
            final ok = await _ensureNewer();
            if (ok == true) {
              setState(() { _index = 1; _globalIndex = (_globalIndex - 1).clamp(0, _totalCount-1); });
              if (mounted) _controller.jumpToPage(1);
            } else {
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已经是最新一篇')));
              await Future.delayed(const Duration(milliseconds: 200));
              if (mounted) _controller.jumpToPage(1);
            }
            return false;
          }
          setState(() { _index = i; });
        },
        itemBuilder: (context, i) {
          if (i >= _pages.length) return const SizedBox.shrink();
          final e = _pages[i];
          final w = weatherByCode(e.weatherCode);
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(_fmt.format(DateTime.fromMillisecondsSinceEpoch(e.entryTime)), style: Theme.of(context).textTheme.titleMedium)),
                    if (e.weatherCode != null) ...[ Icon(w.icon,size:18), const SizedBox(width:4), Text(w.name) ],
                    const SizedBox(width: 8),
                    if (e.moodIcon != null) Text(e.moodIcon!, style: const TextStyle(fontSize: 18)),
                    if (e.moodName != null) ...[ const SizedBox(width:4), Text(e.moodName!) ],
                  ]),
                  const SizedBox(height: 12),
                  Expanded(child: SingleChildScrollView(child: Text(e.content, style: Theme.of(context).textTheme.bodyLarge))),
                  const SizedBox(height: 6),
                  Align(alignment: Alignment.centerRight, child: Text('${i+1}/${_pages.length}')),
                ]),
              ),
            ),
          );
        },
      )),
    );
  }
}
