
package com.example.quote_app

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.IBinder
import android.content.IntentFilter
import android.content.Context

class UnlockWatchdogService : Service() {
    private val receiver = UnlockReceiver()
    override fun onCreate() {
        super.onCreate()
        // 注册广播
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_USER_UNLOCKED)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(receiver, f)
        // 前台
        startForeground(1607, buildTiny())
    }

    private fun buildTiny(): Notification {
        val chanId = "unlock_watchdog"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(chanId, "Unlock Watchdog", NotificationManager.IMPORTANCE_MIN)
            chan.setShowBadge(false)
            chan.lockscreenVisibility = Notification.VISIBILITY_SECRET
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(chan)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, chanId)
        } else {
            Notification.Builder(this)
        }
        return builder.setContentTitle("Unlock Watchdog")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(false)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // stop shortly after to keep lightweight
        stopForeground(true)
        stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch(_:Throwable){}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
