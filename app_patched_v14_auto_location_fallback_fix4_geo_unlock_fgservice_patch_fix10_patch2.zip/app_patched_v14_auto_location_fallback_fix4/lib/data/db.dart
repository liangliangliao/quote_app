import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// 全局数据库封装：与原生/旧模块统一使用同一物理库文件：/databases/app.db
class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dbDir = await getDatabasesPath(); // /data/user/0/<pkg>/databases
    final path = p.join(dbDir, 'app.db');   // 统一为 app.db，避免多个库分裂
    _db = await openDatabase(
      path,
      version: 13,
      onCreate: (db, v) async => _createAll(db),
      onUpgrade: (db, from, to) async => _createAll(db), // 仅补齐（IF NOT EXISTS / ALTER ADD）
    );
    return _db!;
  }

  static Future<void> _createAll(Database db) async {
    // 1) 关键业务表（IF NOT EXISTS，避免破坏已存在数据结构）
    await db.execute('''CREATE TABLE IF NOT EXISTS logs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at INTEGER,
      task_uid TEXT,
      log_uid TEXT,
      detail TEXT,
      task_name_snapshot TEXT,
      task_start_time_snapshot TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS configs(
      id INTEGER PRIMARY KEY CHECK (id=1),
      api_key TEXT,
      model TEXT,
      endpoint TEXT,
      recent_hours INTEGER,
      overview_threshold INTEGER,
      auto_report_enabled INTEGER,
      ema_enabled INTEGER,
      esteem_scale INTEGER,
      sses_index INTEGER,
      start_time INTEGER,
      bg_image TEXT,
      unlock_switch_enabled INTEGER,
      unlock_cooldown_minutes INTEGER,
      location_rules_enabled INTEGER,
      baidu_ak TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS notify_config(
      key TEXT PRIMARY KEY,
      value TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS app_kv(
      key TEXT PRIMARY KEY,
      value TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS meta(
      key TEXT PRIMARY KEY,
      value TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS tasks(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_uid TEXT,
      task_name TEXT,
      type TEXT,
      status INTEGER,
      start_time INTEGER,
      end_time INTEGER,
      freq TEXT,
      freq_custom TEXT,
      carousel_order INTEGER,
      scheduled_run_key TEXT,
      extra_json TEXT,
      avatar_path TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS quotes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_uid TEXT,
      task_name TEXT,
      task_type TEXT,
      content TEXT,
      author_name TEXT,
      avatar TEXT,
      theme TEXT,
      source_from TEXT,
      extra_json TEXT,
      created_at INTEGER
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS quotes_fixed(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content TEXT,
      author_name TEXT,
      theme TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS notify_failures(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_uid TEXT,
      date_str TEXT,
      channel TEXT,
      status INTEGER,
      unique_id TEXT,
      created_at INTEGER
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS notify_guard(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_uid TEXT,
      run_key TEXT,
      attempt INTEGER,
      chan TEXT,
      created_at INTEGER
    )''');

    // 2) 迁移：为缺失的列做补齐（避免 'no such column' ）
    Future<void> ensureColumn(String table, String name, String type) async {
      final info = await db.rawQuery("PRAGMA table_info($table)");
      final cols = info.map((e) => (e['name'] as String?) ?? '').toList();
      if (!cols.contains(name)) {
        await db.execute("ALTER TABLE $table ADD COLUMN $name $type");
      }
    }

    // configs 补列
    await ensureColumn('configs','unlock_switch_enabled','INTEGER');
    await ensureColumn('configs','unlock_cooldown_minutes','INTEGER');
    await ensureColumn('configs','location_rules_enabled','INTEGER');
    await ensureColumn('configs','baidu_ak','TEXT');

    // logs 补列
    await ensureColumn('logs','log_uid','TEXT');
    await ensureColumn('logs','task_name_snapshot','TEXT');
    await ensureColumn('logs','task_start_time_snapshot','TEXT');

    // tasks 补列
    await ensureColumn('tasks','scheduled_run_key','TEXT');
    await ensureColumn('tasks','avatar_path','TEXT');
    await ensureColumn('tasks','freq_custom','TEXT');
    await ensureColumn('tasks','carousel_order','INTEGER');

    // quotes 补列
    await ensureColumn('quotes','theme','TEXT');
    await ensureColumn('quotes','source_from','TEXT');
    await ensureColumn('quotes','extra_json','TEXT');
    await ensureColumn('quotes','author_name','TEXT');
    await ensureColumn('quotes','avatar','TEXT');

    // 3) 保证 configs 至少有一行（id=1）
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {
        'id': 1,
        'model': 'gpt-5',
        'endpoint': 'https://api.openai.com/v1/responses',
        'recent_hours': 2,
        'overview_threshold': 500,
        'auto_report_enabled': 0,
        'ema_enabled': 0,
        'location_rules_enabled': 0
      });
    }
  }
}
