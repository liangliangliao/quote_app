package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object SysChannel {
    private const val TAG = "SysChannel"
    private const val CHANNEL = "com.example.quote_app/sys"

    fun register(engine: FlutterEngine, appContext: Context) {
        val channel = MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
        channel.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            when (call.method) {
                "getBaiduLocationOnce" -> {
                    try {
                        BaiduLocator.requestSingle(appContext, result)
                    } catch (t: Throwable) {
                        Log.w(TAG, "Baidu SDK exception: ${t.message}", t)
                        result.error("BAIDU_SDK_ERROR", t.message, null)
                    }
                }
                "getSystemLocationOnce" -> {
                    try {
                        val loc = getSystemSingleLocation(appContext)
                        if (loc != null) {
                            val map = hashMapOf(
                                "lat" to loc.latitude,
                                "lon" to loc.longitude,
                                "acc" to loc.accuracy
                            )
                            result.success(map)
                        } else {
                            result.error("NO_LOCATION", "System lastKnown is null", null)
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "System location exception: ${t.message}", t)
                        result.error("SYS_LOC_ERROR", t.message, null)
                    }
                }
                "baiduReverseGeocode" -> {
                    try {
                        val ak = call.argument<String>("ak") ?: ""
                        val lat = call.argument<Double>("lat") ?: 0.0
                        val lon = call.argument<Double>("lon") ?: 0.0
                        val radius = call.argument<Int>("radius") ?: 50
                        val json = reverseGeocodeBaidu(ak, lat, lon, radius)
                        result.success(json)
                    } catch (t: Throwable) {
                        Log.w(TAG, "Baidu reverse geocode failed: ${t.message}", t)
                        result.error("BAIDU_HTTP_ERROR", t.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun getSystemSingleLocation(ctx: Context): Location? {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        var best: Location? = null
        for (p in providers) {
            try {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.accuracy < best!!.accuracy) best = l
            } catch (_: SecurityException) {
                // permission handled on Dart side
            } catch (_: Throwable) {
            }
        }
        return best
    }

    private fun reverseGeocodeBaidu(ak: String, lat: Double, lon: Double, radius: Int): String {
        // Build URL
        val url = ("https://api.map.baidu.com/reverse_geocoding/v3/?ak=" + ak +
                "&output=json&coordtype=wgs84ll&location=" + lat + "," + lon +
                "&extensions_poi=1&radius=" + radius + "&ret_coordtype=wgs84ll&page_size=50&page_num=0")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.requestMethod = "GET"
        conn.doInput = true
        val code = conn.responseCode
        val reader = BufferedReader(InputStreamReader(if (code in 200..299) conn.inputStream else conn.errorStream))
        val sb = StringBuilder()
        reader.useLines { lines -> lines.forEach { sb.append(it) } }
        // Wrap minimal payload + http status so Dart can log
        val wrapper = JSONObject()
        wrapper.put("httpCode", code)
        wrapper.put("body", sb.toString())
        return wrapper.toString()
    }
}
