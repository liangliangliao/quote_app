package com.example.quote_app

import android.content.Context
import com.baidu.location.LocationClient
import com.baidu.location.LocationClientOption
import com.baidu.location.BDAbstractLocationListener
import com.baidu.location.BDLocation
import io.flutter.plugin.common.MethodChannel

object BaiduLocator {
    fun requestSingle(context: Context, result: MethodChannel.Result) {
        val client = LocationClient(context.applicationContext)
        val option = LocationClientOption()
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy)
        option.setIsNeedAddress(true)
        option.setOpenGnss(true)
        option.setScanSpan(0) // one-shot
        client.locOption = option
        client.registerLocationListener(object : BDAbstractLocationListener() {
            override fun onReceiveLocation(location: BDLocation?) {
                if (location != null && (location.locType == BDLocation.TypeGpsLocation ||
                            location.locType == BDLocation.TypeNetWorkLocation ||
                            location.locType == BDLocation.TypeOffLineLocation ||
                            location.locType == BDLocation.TypeGnssLocation ||
                            location.locType == 61 || location.locType == 161)) {
                    val map = hashMapOf(
                        "lat" to location.latitude,
                        "lon" to location.longitude,
                        "acc" to location.radius
                    )
                    result.success(map)
                } else {
                    result.error("NO_LOCATION", "Baidu location failed, type=${location?.locType}", null)
                }
                try { client.stop() } catch (_: Throwable) {}
            }
        })
        try {
            client.start()
        } catch (t: Throwable) {
            result.error("BAIDU_START_FAILED", t.message, null)
        }
    }
}
