package com.example.quote_app

import android.content.Context
import android.os.Build
import android.text.Layout
import android.util.TypedValue
import android.widget.RemoteViews
import android.widget.TextView

/**
 * 无 DecoratedCustomViewStyle、无 Material3 依赖的版本：
 * - 系统头：由通知本身提供（smallIcon/title/when），不需要 DecoratedCustomViewStyle 也会显示；
 * - 正文：一个 TextView，折叠 maxLines=5；展开 maxLines=12；字号 = 系统正文基准 + deltaSp；
 * - 仅用 framework TextAppearance，避免引 Material3。
 */
object NotifFrameworkOnly {

    private fun resolveSystemBodySp(ctx: Context): Float {
        val tv = TextView(ctx)
        // framework 的正文外观
        tv.setTextAppearance(ctx, android.R.style.TextAppearance_Material_Body1)
        val scaledDensity = ctx.resources.displayMetrics.scaledDensity
        return tv.textSize / scaledDensity // px->sp
    }

    private fun common(ctx: Context, body: CharSequence, maxLines: Int, deltaSp: Float): RemoteViews {
        val baseSp = resolveSystemBodySp(ctx)
        return RemoteViews(ctx.packageName, R.layout.notif_body_framework_only).apply {
            setTextViewText(R.id.body_text, body)
            setInt(R.id.body_text, "setMaxLines", maxLines)
            setTextViewTextSize(R.id.body_text, TypedValue.COMPLEX_UNIT_SP, baseSp + deltaSp)
            if (Build.VERSION.SDK_INT >= 23) {
                setInt(R.id.body_text, "setBreakStrategy", Layout.BREAK_STRATEGY_HIGH_QUALITY)
                setInt(R.id.body_text, "setHyphenationFrequency", Layout.HYPHENATION_FREQUENCY_NORMAL)
            }
        }
    }

    fun collapsed(ctx: Context, body: CharSequence, deltaSp: Float = 1f) =
        common(ctx, body, 5, deltaSp)

    fun expanded(ctx: Context, body: CharSequence, deltaSp: Float = 1f) =
        common(ctx, body, 12, deltaSp)
}
