import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Downloads an image from [url] and saves it to an app-owned folder.
///
/// Notes:
/// - To avoid adding extra permissions/dependencies, this saves into an
///   app-accessible directory (external app dir on Android when available,
///   documents dir otherwise).
/// - Returns the saved file path.
class ImageDownloader {
  static Future<String> saveImage(String url) async {
    final uri = Uri.parse(url);
    final res = await http.get(uri);
    if (res.statusCode != 200) {
      throw Exception('下载失败: ${res.statusCode}');
    }

    Directory baseDir;
    if (Platform.isAndroid) {
      baseDir = (await getExternalStorageDirectory()) ?? await getApplicationDocumentsDirectory();
    } else {
      baseDir = await getApplicationDocumentsDirectory();
    }

    final saveDir = Directory(p.join(baseDir.path, 'downloads', 'images'));
    if (!await saveDir.exists()) {
      await saveDir.create(recursive: true);
    }

    final ext = _extFromUrl(url);
    final fileName = 'img_${DateTime.now().millisecondsSinceEpoch}$ext';
    final filePath = p.join(saveDir.path, fileName);
    final file = File(filePath);
    await file.writeAsBytes(res.bodyBytes, flush: true);
    return filePath;
  }

  static String _extFromUrl(String url) {
    try {
      final path = Uri.parse(url).path;
      final ext = p.extension(path);
      if (ext.isNotEmpty && ext.length <= 5) return ext;
    } catch (_) {}
    return '.jpg';
  }
}
