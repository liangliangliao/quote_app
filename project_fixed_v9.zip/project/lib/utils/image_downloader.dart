import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

/// Downloads an image from [url] and saves it to an app-owned folder.
///
/// Notes:
/// - To avoid adding extra permissions/dependencies, this saves into an
///   app-accessible directory (external app dir on Android when available,
///   documents dir otherwise).
/// - Returns the saved file path.
class ImageDownloader {
  static Future<String> saveImage(String url) async {
    final uri = Uri.parse(url);
    final res = await http.get(uri);
    if (res.statusCode != 200) {
      throw Exception('下载失败: ${res.statusCode}');
    }

    Directory baseDir;
    if (Platform.isAndroid) {
      baseDir = (await getExternalStorageDirectory()) ?? await getApplicationDocumentsDirectory();
    } else {
      baseDir = await getApplicationDocumentsDirectory();
    }

    final saveDir = Directory(p.join(baseDir.path, 'downloads', 'images'));
    if (!await saveDir.exists()) {
      await saveDir.create(recursive: true);
    }

    final ext = _extFromUrl(url);
    final fileName = 'img_${DateTime.now().millisecondsSinceEpoch}$ext';
    final filePath = p.join(saveDir.path, fileName);
    final file = File(filePath);
    await file.writeAsBytes(res.bodyBytes, flush: true);
    return filePath;
  }

  /// Downloads an image from [url] and saves it to the system gallery.
  ///
  /// Returns a best-effort string describing the saved location/identifier.
  ///
  /// Notes:
  /// - On modern Android (scoped storage), MediaStore saving generally works
  ///   without extra permissions.
  /// - On older Android versions, we request storage permission when possible.
  static Future<String> saveImageToGallery(String url) async {
    final uri = Uri.parse(url);
    final res = await http.get(uri);
    if (res.statusCode != 200) {
      throw Exception('下载失败: ${res.statusCode}');
    }

    // Best-effort permissions: do NOT hard-fail on denial because many devices
    // (Android 10+) can still save via MediaStore without explicit permission.
    if (Platform.isAndroid) {
      try {
        await Permission.storage.request();
        await Permission.photos.request();
      } catch (_) {
        // ignore permission request issues
      }
    } else if (Platform.isIOS) {
      try {
        await Permission.photosAddOnly.request();
      } catch (_) {}
    }

    final ext = _extFromUrl(url);
    final name = 'img_${DateTime.now().millisecondsSinceEpoch}${ext.replaceAll('.', '_')}';
    final Uint8List bytes = res.bodyBytes;
    final result = await ImageGallerySaver.saveImage(
      bytes,
      quality: 100,
      name: name,
    );

    // image_gallery_saver returns a Map-like result across platforms.
    if (result is Map) {
      final isSuccess = (result['isSuccess'] ?? result['success'] ?? false) == true;
      if (!isSuccess) {
        throw Exception('保存到相册失败');
      }
      final filePath = (result['filePath'] ?? result['path'] ?? '').toString();
      return filePath.isEmpty ? '相册' : filePath;
    }
    // If plugin returns a non-map value, treat it as success and return it.
    return result?.toString() ?? '相册';
  }

  static String _extFromUrl(String url) {
    try {
      final path = Uri.parse(url).path;
      final ext = p.extension(path);
      if (ext.isNotEmpty && ext.length <= 5) return ext;
    } catch (_) {}
    return '.jpg';
  }
}
