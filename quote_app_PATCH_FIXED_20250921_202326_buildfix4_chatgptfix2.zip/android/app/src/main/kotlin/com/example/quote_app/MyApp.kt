package com.example.quote_app

import android.app.Application
import io.flutter.app.FlutterApplication
import io.flutter.plugin.common.PluginRegistry
import io.flutter.plugins.GeneratedPluginRegistrant
import dev.fluttercommunity.plus.androidalarmmanager.AndroidAlarmManagerPlugin
import be.tramckrijte.workmanager.WorkmanagerPlugin

/** Custom Application to ensure plugins are registered for background isolates. */
class MyApp : FlutterApplication(), PluginRegistry.PluginRegistrantCallback {

    override fun onCreate() {
        super.onCreate()
        // Register callbacks so android_alarm_manager_plus / workmanager use this class.
        AndroidAlarmManagerPlugin.setPluginRegistrant(this)
        // Workmanager 0.5+ API
        WorkmanagerPlugin.setPluginRegistrantCallback(this)
    }

    /** Called whenever a new FlutterEngine is spun up (background or foreground). */
    override fun registerWith(registry: PluginRegistry) {
        GeneratedPluginRegistrant.registerWith(registry)
        // Register our custom plugin so headless engines can call the method channel.
        SysAlarmPermissionPlugin.registerWith(
            registry.registrarFor(SysAlarmPermissionPlugin.CHANNEL)
        )
    }
}
