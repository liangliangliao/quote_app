
package com.example.quote_app.biz;

import android.text.TextUtils;

import com.example.quote_app.data.DbRepository;
import com.example.quote_app.data.DbRepository.Config;
import com.example.quote_app.data.DbRepository.Task;
import com.example.quote_app.NotifyHelper;

import java.util.List;

/** Implements business logic for AUTO / MANUAL / CAROUSEL types. */
import android.content.Context;

public final class Biz {
    private Biz() {}

    public static boolean run(Context ctx, String uid) {
        com.example.quote_app.data.DbRepository.log(ctx, uid, "【Biz】进入业务分发");
        Task t = DbRepository.getTaskFull(ctx, uid);
        if (t == null) { com.example.quote_app.data.DbRepository.log(ctx, uid, "【Biz】未找到任务，回退兜底"); return false; }
        if (!t.enabled) { com.example.quote_app.data.DbRepository.log(ctx, uid, "【Biz】任务已关闭，直接退出"); return true; }
        String tp = t.type != null ? t.type.toUpperCase() : "MANUAL";
        switch (tp) {
            case "AUTO":
                com.example.quote_app.data.DbRepository.log(ctx, uid, "【Biz】自动任务分支");
                return autoTask(ctx, t);
            case "CAROUSEL":
                com.example.quote_app.data.DbRepository.log(ctx, uid, "【Biz】轮播任务分支");
                return carouselTask(ctx, t);
            case "MANUAL":
                com.example.quote_app.data.DbRepository.log(ctx, uid, "【Biz】手动任务分支");
            default:
                return manualTask(ctx, t);
        }
    }

    public static boolean manualTask(Context ctx, Task t) {
        com.example.quote_app.data.DbRepository.log(ctx, t.uid, "【Manual】准备发送手动任务通知");
        String content = DbRepository.getManualQuote(ctx, t.uid);
        if (TextUtils.isEmpty(content)) content = t.content;
        String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
        int id = t.uid != null ? t.uid.hashCode() : 10002;
        com.example.quote_app.NotifyHelper.INSTANCE.send(ctx.getApplicationContext(), id, title, content, t.avatarPath);
        // mark notified best-effort is omitted (unknown id); log success
        DbRepository.log(ctx, t.uid, "成功!");
        return true;
    }

    public static boolean carouselTask(Context ctx, Task t) {
        com.example.quote_app.data.DbRepository.log(ctx, t.uid, "【Carousel】准备发送轮播任务通知");
        String content = DbRepository.getCarouselNextQuote(ctx, t.uid);
        if (TextUtils.isEmpty(content)) content = t.content;
        String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
        int id = t.uid != null ? t.uid.hashCode() : 10003;
        com.example.quote_app.NotifyHelper.INSTANCE.send(ctx.getApplicationContext(), id, title, content, t.avatarPath);
        DbRepository.log(ctx, t.uid, "成功!");
        return true;
    }

    public static boolean autoTask(Context ctx, Task t) {
        com.example.quote_app.data.DbRepository.log(ctx, t.uid, "【Auto】开始调用OpenAI");
        Config cfg = DbRepository.loadConfig(ctx);
        try {
            String prompt = !TextUtils.isEmpty(t.prompt) ? t.prompt : (t.title != null ? t.title : "给我一句励志名言");
            String text = OpenAiClient.chatComplete(cfg != null ? cfg.endpoint : "https://api.openai.com/v1",
                    cfg != null ? cfg.apiKey : null,
                    cfg != null ? cfg.model : "gpt-5",
                    prompt);
            if (TextUtils.isEmpty(text)) {
                DbRepository.log(ctx, t.uid, "调用openai api发生错误或失败!");
                return false;
            }
            // dedupe up to 10 tries
            List<String> existing = DbRepository.listQuoteTextsForTask(ctx, t.uid, 200);
            int tries = 0;
            while (DedupeUtil.isDuplicate(existing, text, 0.90) && tries < 10) {
                tries++;
                text = OpenAiClient.chatComplete(cfg != null ? cfg.endpoint : "https://api.openai.com/v1",
                        cfg != null ? cfg.apiKey : null,
                        cfg != null ? cfg.model : "gpt-5",
                        prompt);
                if (TextUtils.isEmpty(text)) {
                    DbRepository.log(ctx, t.uid, "调用openai api发生错误或失败!");
                    return false;
                }
            }
            if (tries >= 10 && DedupeUtil.isDuplicate(existing, text, 0.90)) {
                DbRepository.log(ctx, t.uid, "错误!连续调用api10次去重检验未通过!");
                return false;
            }
            long qid = DbRepository.insertQuote(ctx, t.uid, text, null);
            String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
            int id = t.uid != null ? t.uid.hashCode() : 10004;
            com.example.quote_app.NotifyHelper.INSTANCE.send(ctx.getApplicationContext(), id, title, text, t.avatarPath);
            if (qid > 0) DbRepository.markQuoteNotified(ctx, qid);
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "调用openai api发生错误或失败!");
            return false;
        }
    }
}