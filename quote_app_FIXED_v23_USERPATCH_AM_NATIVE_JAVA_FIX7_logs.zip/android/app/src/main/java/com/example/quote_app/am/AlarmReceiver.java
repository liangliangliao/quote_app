
package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.biz.Biz;

import org.json.JSONObject;

/**
 * Java receiver that handles AlarmManager intents and posts notifications natively,
 * without launching Flutter. Uses DbRepository to fetch business data from SQLite
 * written by Dart/sqflite. Falls back to payload JSON.
 */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try { com.example.quote_app.data.DbRepository.log(context, intent != null ? intent.getStringExtra("uid") : null, "【Receiver】收到闹钟广播"); } catch (Throwable ignore) {}
        String payload = intent.getStringExtra("payload");
        String uid = null;
        String title = null;
        String body = null;

        if (!TextUtils.isEmpty(payload)) {
            try {
                JSONObject obj = new JSONObject(payload);
                uid = obj.optString("uid", null);
                title = obj.optString("title", null);
                body = obj.optString("body", null);
            } catch (Exception ignored) {}
        }

        // First, try full business logic path (AUTO/MANUAL/CAROUSEL)
        try {
            try {
                com.example.quote_app.data.DbRepository.log(context, uid, "【Receiver】开始执行业务分支");
                if (uid != null && Biz.run(context, uid)) {
                    com.example.quote_app.data.DbRepository.log(context, uid, "【Receiver】业务分支执行完成");
                    return;
                }
            } catch (Throwable ignored) { try { com.example.quote_app.data.DbRepository.log(context, uid, "【Receiver】执行业务分支异常"); } catch (Throwable ignore) {} }
        } catch (Throwable ignored) {}

        // Prefer DB data if uid present
        if (uid != null) {
            DbRepository.Task task = DbRepository.findTaskByUid(context, uid);
            if (task != null) {
                if (TextUtils.isEmpty(title)) title = task.title;
                if (TextUtils.isEmpty(body)) body = task.content;
            }
        }

        if (TextUtils.isEmpty(title)) title = "提醒";
        if (TextUtils.isEmpty(body)) body = "该做正事啦";

        String quote = DbRepository.pickRandomQuote(context);
        if (!TextUtils.isEmpty(quote)) {
            body = body + "\n" + quote;
        }

        // Use Kotlin object from Java
        try {
            // id: use uid hash if present; otherwise a stable default
            int id = (uid != null ? uid.hashCode() : 10001);
            NotifyHelper.INSTANCE.send(context.getApplicationContext(), id, title, body, null);
        } catch (Throwable ignored) {}
    }
}