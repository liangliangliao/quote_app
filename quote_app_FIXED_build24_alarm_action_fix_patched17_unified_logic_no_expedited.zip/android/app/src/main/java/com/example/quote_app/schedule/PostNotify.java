package com.example.quote_app.schedule;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.ListenableWorker;

import com.example.quote_app.am.AmCancel;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.wm.WmNames;
import com.example.quote_app.wm.WmScheduler;
import com.example.quote_app.schedule.AutoRescheduler;

import java.util.concurrent.TimeUnit;

/**
 * Unifies the business logic after a notification attempt (AM / WM).
 * Implements the spec:
 *  a) Success:
 *     a.1 source = am|main-wm -> cancel fallback-wm, cancel current, schedule next
 *     a.2 source = fallback-wm -> cancel current fallback only
 *     a.3 source = selfck-wm -> cancel current self-check only
 *  b) Failure:
 *     b.1 source = am|main-wm -> cancel current, schedule next
 *     b.2 source = fallback-wm -> cancel current fallback; if attempts>2 stop retry, else enqueue zero-delay fallback
 *     b.3 source = selfck-wm -> cancel current self-check only
 *
 *  "身份证" format examples (WM): src=main-wm_runkey=..._uid=..., src=fallback-wm_runkey=..._uid=...
 *  For AM we pass explicit source="am".
 */
public final class PostNotify {
    private PostNotify() {}

    private static String parseSourceFromUnique(String uniqueOrSource) {
        if (uniqueOrSource == null) return "";
        if (uniqueOrSource.startsWith("src=")) {
            int end = uniqueOrSource.indexOf('_');
            if (end > 4) {
                return uniqueOrSource.substring(4, end);
            } else {
                return uniqueOrSource.substring(4);
            }
        }
        return uniqueOrSource; // already a source literal like "am", "main-wm", etc.
    }

    /** Cancel self-check work by tag. */
    private static void cancelSelfCheck(Context ctx) {
        try {
            WorkManager.getInstance(ctx.getApplicationContext()).cancelAllWorkByTag("selfck-wm");
            DbRepository.log(ctx, null, "【原生】WM 取消自检(selfck-wm tag)");
        } catch (Throwable ignore) {}
    }

    public static ListenableWorker.Result onWmResult(Context ctx, String sourceOrUnique, String uid, String runKey, boolean success, int attempt) {
        final String src = parseSourceFromUnique(sourceOrUnique);
        try { DbRepository.log(ctx, uid, "【统一】WM后置处理 src="+src+" uid="+uid+" run="+runKey+" ok="+success+" attempt="+attempt); } catch (Throwable ignore) {}

        if (success) {
            try { DbRepository.markLatestSuccess(ctx, uid); } catch (Throwable ignore) {}
            if ("main-wm".equals(src) || "am".equals(src)) {
                // a.1: cancel fallback, cancel current, schedule next
                try { WmScheduler.cancelFallback(ctx, WmNames.fbUnique(uid, runKey)); } catch (Throwable ignore) {}
                try { WmScheduler.cancelByUnique(ctx, WmNames.normUnique(uid, runKey)); } catch (Throwable ignore) {}
                try { AutoRescheduler.scheduleNext(ctx, uid); } catch (Throwable ignore) {}
                return ListenableWorker.Result.success();
            } else if ("fallback-wm".equals(src)) {
                // a.2
                try { WmScheduler.cancelFallback(ctx, WmNames.fbUnique(uid, runKey)); } catch (Throwable ignore) {}
                return ListenableWorker.Result.success();
            } else if ("selfck-wm".equals(src)) {
                // a.3
                cancelSelfCheck(ctx);
                return ListenableWorker.Result.success();
            } else {
                return ListenableWorker.Result.success();
            }
        } else {
            if ("main-wm".equals(src) || "am".equals(src)) {
                // b.1: cancel current and schedule next
                try { WmScheduler.cancelByUnique(ctx, WmNames.normUnique(uid, runKey)); } catch (Throwable ignore) {}
                try { AutoRescheduler.scheduleNext(ctx, uid); } catch (Throwable ignore) {}
                return ListenableWorker.Result.success();
            } else if ("fallback-wm".equals(src)) {
                // b.2: cancel current fallback; retry up to 2 times (attempt<=2 => allow retry)
                try { WmScheduler.cancelFallback(ctx, WmNames.fbUnique(uid, runKey)); } catch (Throwable ignore) {}
                if (attempt > 2) {
                    try { DbRepository.log(ctx, uid, "【统一】fallback 重试次数>2 停止重试"); } catch (Throwable ignore) {}
                    return ListenableWorker.Result.failure();
                } else {
                    // re-enqueue zero-delay fallback (attempt+1)
                    try {
                        Data in2 = new Data.Builder()
                                .putString("uid", uid)
                                .putString("runKey", runKey)
                                .putString("task_uid", uid)
                                .putString("run_key", runKey)
                                .putString("chan", "fallback-wm")
                                .putInt("attempt", attempt + 1)
                                .build();
                        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(com.example.quote_app.wm.FallbackWorker.class)
                                .setInitialDelay(0, TimeUnit.MILLISECONDS)
                                .addTag("fallback-wm-retry")
                                .setInputData(in2)
                                .build();
                        String unique = WmNames.fbUnique(uid, runKey);
                        WorkManager.getInstance(ctx.getApplicationContext())
                                .enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req);
                        try { DbRepository.log(ctx, uid, "【统一】fallback 立刻重试 attempt="+(attempt+1)); } catch (Throwable ignore) {}
                    } catch (Throwable ignore) {}
                    return ListenableWorker.Result.success();
                }
            } else if ("selfck-wm".equals(src)) {
                // b.3
                cancelSelfCheck(ctx);
                return ListenableWorker.Result.success();
            } else {
                return ListenableWorker.Result.success();
            }
        }
    }

    public static void onAmResult(Context ctx, String uid, String runKey, boolean success) {
        final String src = "am";
        try { DbRepository.log(ctx, uid, "【统一】AM后置处理 uid="+uid+" run="+runKey+" ok="+success); } catch (Throwable ignore) {}
        if (success) {
            // a.1 for am
            try { WmScheduler.cancelFallback(ctx, WmNames.fbUnique(uid, runKey)); } catch (Throwable ignore) {}
            try { AmCancel.cancelExactById(ctx, uid, runKey); } catch (Throwable ignore) {}
            try { AutoRescheduler.scheduleNext(ctx, uid); } catch (Throwable ignore) {}
        } else {
            // b.1 for am
            try { AmCancel.cancelExactById(ctx, uid, runKey); } catch (Throwable ignore) {}
            try { AutoRescheduler.scheduleNext(ctx, uid); } catch (Throwable ignore) {}
        }
    }
}
