package com.example.quote_app.wm;

import android.content.Context;
import com.example.quote_app.schedule.PostNotify;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.AutoRescheduler;
import com.example.quote_app.wm.WmNames;

public final class NormalWorker extends Worker {

    public NormalWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override public ListenableWorker.Result doWork() {
        Context ctx = getApplicationContext();
        Data in = getInputData();
        // Extract uid/runKey from either legacy or new keys. Dart side may provide
        // 'task_uid' and 'run_key' whereas native side uses 'uid' and 'runKey'.
        String uid = in.getString("uid");
        if (uid == null || uid.isEmpty()) uid = in.getString("task_uid");
        String runKey = in.getString("runKey");
        if (runKey == null || runKey.isEmpty()) runKey = in.getString("run_key");
        String chan = in.getString("chan");
        int attempt = in.getInt("attempt", 1);

        try {
            // 记录触发日志
            DbRepository.log(ctx, uid, "【原生】WM 正常通道触发 uid="+uid+" run="+runKey+" attempt="+attempt);
            boolean ok = Biz.run(ctx, uid);
            return com.example.quote_app.schedule.PostNotify.onWmResult(ctx, "main-wm", uid, runKey, ok, attempt);
        } catch (Throwable t) {
            DbRepository.log(ctx, uid, "WM正常通道异常: " + (t.getMessage()==null?"未知错误":t.getMessage()));
            // 异常情况下尝试安排下一次任务，避免任务丢失
            try { AutoRescheduler.scheduleNext(ctx, uid); } catch (Throwable ignore) {}
            return Result.retry();
        }
    }
}