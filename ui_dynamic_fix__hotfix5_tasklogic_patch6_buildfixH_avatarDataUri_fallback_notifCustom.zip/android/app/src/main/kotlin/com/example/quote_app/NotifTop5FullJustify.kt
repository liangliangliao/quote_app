package com.example.quote_app

import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.widget.RemoteViews

/**
 * Top 5 lines fixed; last line of the top block is fully justified to the right edge.
 * Strategy:
 *  - Use StaticLayout to split by line.
 *  - For lines 0..3 draw normally.
 *  - For line 4, compute extra gap = (targetWidth - measureWidth). If there are spaces, distribute gap across spaces;
 *    otherwise distribute across characters (CJK-friendly). Draw word-by-word / char-by-char with translated x.
 */
object NotifTop5FullJustify {

    private fun dp(ctx: Context, v: Float) = v * ctx.resources.displayMetrics.density
    private fun sp(ctx: Context, v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, ctx.resources.displayMetrics)

    private fun addSoftHyphens(body: String): String {
        val re = Regex("\\b[A-Za-z]{8,}\\b")
        return re.replace(body) { m -> m.value.chunked(6).joinToString("\\u00AD") }
    }

    private fun measure(p: TextPaint, s: String): Float = p.measureText(s)

    private fun drawJustifiedLine(c: Canvas, p: TextPaint, text: String, y: Float, target: Float) {
        val clean = text.trimEnd('\n', ' ')
        if (clean.isEmpty()) return
        val baseWidth = measure(p, clean)
        if (baseWidth >= target || clean.length <= 1) {
            c.drawText(clean, 0f, y, p); return
        }
        val parts = clean.split(' ')
        if (parts.size >= 2) {
            // word-wise distribution
            val wordsWidth = parts.sumOf { measure(p, it).toDouble() }.toFloat()
            val gaps = parts.size - 1
            val extra = (target - wordsWidth) / gaps
            var x = 0f
            for ((i, w) in parts.withIndex()) {
                c.drawText(w, x, y, p)
                x += measure(p, w)
                if (i < parts.lastIndex) x += extra
            }
        } else {
            // char-wise distribution (CJK or no spaces)
            val chars = clean.toCharArray()
            val textWidth = measure(p, clean)
            val gaps = chars.size - 1
            val extra = if (gaps > 0) (target - textWidth) / gaps else 0f
            var x = 0f
            for ((i, ch) in chars.withIndex()) {
                val s = ch.toString()
                c.drawText(s, x, y, p)
                x += measure(p, s)
                if (i < chars.lastIndex) x += extra
            }
        }
    }

    private fun renderTopBitmap(ctx: Context, text: String, avail: Int, lines: Int): Bitmap {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#344054")
            textSize = sp(ctx, 14f)
        }
        val spacing = dp(ctx, 2f)
        val layout = if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, avail)
                .setIncludePad(false)
                .setLineSpacing(spacing, 1f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_FULL)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, avail, Layout.Alignment.ALIGN_NORMAL, 1f, spacing, false)
        }
        val take = kotlin.math.min(lines, layout.lineCount)
        val fm = paint.fontMetrics
        val lineHeight = (fm.descent - fm.ascent + spacing)
        val bmp = Bitmap.createBitmap(avail, kotlin.math.ceil(lineHeight * take).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        var baseline = -fm.ascent
        for (i in 0 until take) {
            val start = layout.getLineStart(i)
            val end = layout.getLineEnd(i)
            val line = text.substring(start, end)
            if (i == take - 1) {
                drawJustifiedLine(c, paint, line, baseline, avail.toFloat())
            } else {
                c.drawText(line.trimEnd('\n', ' '), 0f, baseline, paint)
            }
            baseline += lineHeight
        }
        return bmp
    }

    fun buildRemoteViews(ctx: Context, layoutRes: Int, title: String, body: String, collapsed: Boolean): RemoteViews {
        val total = if (collapsed) 5 else 12
        val topLines = 5

        val padding = dp(ctx, 16f)
        val marginEnd = 0f
        val hero = dp(ctx, 56f)
        val screen = ctx.resources.displayMetrics.widthPixels.toFloat()
        val avail = (screen - padding * 2 - hero - marginEnd).toInt().coerceAtLeast(100)

        val bodyProcessed = addSoftHyphens(body)

        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = sp(ctx, 14f) }
        val layout = if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(bodyProcessed, 0, bodyProcessed.length, p, avail)
                .setIncludePad(false).setLineSpacing(dp(ctx, 2f), 1f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_FULL).build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(bodyProcessed, p, avail, Layout.Alignment.ALIGN_NORMAL, 1f, dp(ctx, 2f), false)
        }

        val cut = layout.getLineEnd((topLines - 1).coerceAtMost(layout.lineCount - 1)).coerceAtMost(bodyProcessed.length)
        val topText = bodyProcessed.substring(0, cut)
        val bottomText = bodyProcessed.substring(cut).trimStart()
        val bottomCap = (total - topLines).coerceAtLeast(0)

        val bmp = renderTopBitmap(ctx, topText, avail, topLines)

        return RemoteViews(ctx.packageName, layoutRes).apply {
            setTextViewText(R.id.title, title)
            setImageViewBitmap(R.id.body_top_bitmap, bmp)
            if (bottomCap > 0) {
                setTextViewText(R.id.body_bottom, bottomText)
                setInt(R.id.body_bottom, "setMaxLines", bottomCap)
            } else {
                setTextViewText(R.id.body_bottom, "")
            }
        }
    }
}
