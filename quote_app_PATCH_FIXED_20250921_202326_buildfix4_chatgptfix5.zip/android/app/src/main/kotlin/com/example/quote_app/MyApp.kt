package com.example.quote_app

import io.flutter.app.FlutterApplication
import io.flutter.plugin.common.PluginRegistry
import dev.fluttercommunity.plus.androidalarmmanager.AndroidAlarmManagerPlugin
import be.tramckrijte.workmanager.WorkmanagerPlugin

/**
 * Application class that registers custom plugins for background isolates.
 */
class MyApp : FlutterApplication(), PluginRegistry.PluginRegistrantCallback {

    override fun onCreate() {
        super.onCreate()
        // Ensure our callback is used when headless Flutter engines are spawned.
        AndroidAlarmManagerPlugin.setPluginRegistrantCallback(this)
        WorkmanagerPlugin.setPluginRegistrantCallback(this)
    }

    /** Called by AndroidAlarmManager / Workmanager to register plugins. */
    override fun registerWith(registry: PluginRegistry) {
        // Only register the plugins that background code needs.
        SysAlarmPermissionPlugin.registerWith(
            registry.registrarFor("com.example.quote_app/sys")
        )
    }
}
