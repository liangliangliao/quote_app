package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Fires on device unlock to display a Toast immediately even if app is in background.
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_USER_PRESENT) {
            // Use application context for Toast in background
            Toast.makeText(context.applicationContext, "已解锁：轻提醒已就绪", Toast.LENGTH_SHORT).show()
        }
    }
}