import '../platform/perm_helper.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../utils/debug_logger.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  // 单一通知通道（统一用于所有任务类型）
  static const String chGeneralId = 'quote_general';
  static const String chGeneralName = '默认通知';
  static const String chGeneralDesc = '统一的应用通知通道';
  static const AndroidNotificationChannel _channelGeneral = AndroidNotificationChannel(
    chGeneralId, chGeneralName,
    description: chGeneralDesc,
    importance: Importance.high,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );

  static Future<void> init({bool allowRequestPermission = false}) async {
    if (_inited) return;

    const androidInit = AndroidInitializationSettings('mipmap/ic_launcher');
    final darwinInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    final settings = InitializationSettings(android: androidInit, iOS: darwinInit);
    await _plugin.initialize(settings);

    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (allowRequestPermission) { try { await android?.requestNotificationsPermission(); } catch (e, s) { DLog.i('services/notification_service.dart', 'requestPermission skipped in bg: ' + e.toString()); } }
      try {
        await android?.createNotificationChannel(_channelGeneral);
      } catch (e, s) { DLog.e('services/notification_service.dart', 'catch: ' + e.toString()); }
      // 可选：确保悬浮窗权限（若你的产品需要悬浮提示），这里不强制
    }

    _inited = true;
  }

  // 统一展示入口：可前台/后台调用
  static Future<void> show({
    required int id,
    Object? largeIcon,
    String? largeIconPath,
    required String title,
    required String body,
    String? payload,
    BigPictureStyleInformation? style,
  }) async {
    await init();

    // Android 通知详情（使用单一通道）
    final androidDetails = AndroidNotificationDetails(
      chGeneralId,
      chGeneralName,
      channelDescription: chGeneralDesc,
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: style,
      icon: 'mipmap/ic_launcher',
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : (largeIcon == null
              ? const DrawableResourceAndroidBitmap('mipmap/ic_launcher')
              : largeIcon as dynamic),
      enableVibration: true,
      playSound: true,
      ticker: 'quote_ticker',
    );

    final darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(android: androidDetails, iOS: darwinDetails);
    await DLog.i('NOTI', 'show id=$id "$title"');
    // 发送前确认系统通知权限（Android 13+ 为运行时权限），便于将失败原因写入日志
    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      try {
        final enabled = await android?.areNotificationsEnabled() ?? true;
        if (!enabled) {
          await DLog.e('NOTI', '系统已禁止通知：请授予通知权限或在系统设置中打开');
          return;
        }
      } catch (e, s) {
        await DLog.e('NOTI', 'areNotificationsEnabled() 调用异常: ' + e.toString());
      }
    }
    await _plugin.show(id, title, body, details, payload: payload);
    await DLog.i('NOTI', '发送通知成功');
  }
}