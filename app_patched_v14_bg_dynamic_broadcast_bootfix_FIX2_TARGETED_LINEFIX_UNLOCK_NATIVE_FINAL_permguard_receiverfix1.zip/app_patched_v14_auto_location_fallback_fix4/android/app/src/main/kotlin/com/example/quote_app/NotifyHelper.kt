package com.example.quote_app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val GEO_CHANNEL_ID = "quote_geo_high"
  private const val GEO_CHANNEL_NAME = "地点提醒（高优先级）"

  private fun ensureChannels(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (nm.getNotificationChannel(DEFAULT_CHANNEL_ID) == null) {
        val ch = NotificationChannel(DEFAULT_CHANNEL_ID, "默认提醒", NotificationManager.IMPORTANCE_DEFAULT)
        nm.createNotificationChannel(ch)
      }
      if (nm.getNotificationChannel(GEO_CHANNEL_ID) == null) {
        val geo = NotificationChannel(GEO_CHANNEL_ID, GEO_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
        geo.enableVibration(true)
        geo.vibrationPattern = longArrayOf(0L, 250L, 150L, 350L)
        try {
          val uri: Uri = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
          geo.setSound(uri, android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build())
        } catch (_: Throwable) {}
        nm.createNotificationChannel(geo)
      }
    }
  }

  @JvmStatic
  fun hasPostNotifPerm(ctx: Context): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    avatarPath: String?,
    notifType: String?,
    payload: String?
  ) {
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[NotifyHelper] POST_NOTIFICATIONS not granted; skip notify id="+id) } catch (_: Throwable) {}
        return
      }
    }

    ensureChannels(ctx)
    val isGeo = (notifType == "vision_geo")
    val channelId = if (isGeo) GEO_CHANNEL_ID else DEFAULT_CHANNEL_ID

    val builder = NotificationCompat.Builder(ctx, channelId)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      .setPriority(if (isGeo) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
      .setDefaults(if (isGeo) NotificationCompat.DEFAULT_ALL else 0)

    // Tap intent -> launch main activity with extras
    try {
      val launchIntent = Intent(ctx, MainActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        putExtra("from_notification", true)
        if (notifType != null) putExtra("notif_type", notifType)
        if (payload != null) putExtra("payload", payload)
      }
      val pi = PendingIntent.getActivity(
        ctx, 1001, launchIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
      )
      builder.setContentIntent(pi)
    } catch (_: Throwable) { }

    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) { }
    }

    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.notify(id, builder.build())
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "[NotifyHelper] sent id="+id+" chan="+channelId) } catch (_: Throwable) { }
  }

  // Overload kept for Java callers
  @JvmStatic
  fun hasPostNotifPerm(ctx: Context): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    avatarPath: String?
  ) {
    send(ctx, id, title, body, avatarPath, null, null)
  }
}
