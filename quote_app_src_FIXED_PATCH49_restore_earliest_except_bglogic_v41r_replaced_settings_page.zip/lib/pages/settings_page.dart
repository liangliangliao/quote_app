
import 'package:quote_app/util/kv_store.dart';
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _endpointCtrl = TextEditingController();

  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  bool _editingConfig = false;
  bool _simulateDartFail = false;
  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  void showToast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;

    final kv = await KVStore.instance();
    final sflag = kv.getInt('simulate_dart_fail') ?? 0;

    final list = await _taskDao.all();

    if (!mounted) return;
    setState(() {
      _simulateDartFail = sflag == 1;
      _tasks = list;
    });
  }

  Future<void> _saveConfig() async {
    await _configDao.save(
      apiKey: _apiKeyCtrl.text.trim(),
      model: _modelCtrl.text.trim().isEmpty ? 'gpt-5' : _modelCtrl.text.trim(),
      endpoint: _endpointCtrl.text.trim().isEmpty ? 'https://api.openai.com/v1/responses' : _endpointCtrl.text.trim(),
    );
    showToast('已保存');
    setState(() { _editingConfig = false; });
  }

  void _setEditing(bool v) {
    setState(() { _editingConfig = v; });
  }

  Future<void> _openTaskDialog({Map<String,dynamic>? task}) async {
    // 还原到最早版本前的最小可用：提供查看占位对话框，避免构建错误。
    await showDialog(context: context, builder: (dialogCtx) {
      return AlertDialog(
        title: Text(task==null ? '新增任务' : '编辑任务'),
        content: Text(task==null ? '（占位对话框）稍后按你的旧版 UI 完整恢复。' : (task['name'] ?? '').toString()),
        actions: [
          TextButton(onPressed: ()=> Navigator.of(dialogCtx).pop(), child: const Text('关闭')),
        ],
      );
    });
    // 重新拉取任务列表
    final list = await _taskDao.all();
    if (mounted) setState(() { _tasks = list; });
  }

  Widget _header() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text('设置', style: Theme.of(context).textTheme.titleLarge)),
            if (!_editingConfig)
              IconButton(onPressed: ()=>_setEditing(true), icon: const Icon(Icons.edit))
            else
              IconButton(onPressed: ()=>_saveConfig(), icon: const Icon(Icons.save)),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _apiKeyCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(labelText: 'API key'),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _modelCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(labelText: '模型（默认 gpt-5）'),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _endpointCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(labelText: '接口地址（默认 /v1/responses）'),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          title: const Text('原生兜底测试开关（仅测试用）'),
          value: _simulateDartFail,
          onChanged: (v) async {
            final kv = await KVStore.instance();
            await kv.setInt('simulate_dart_fail', v ? 1 : 0);
            if (!mounted) return;
            setState(() { _simulateDartFail = v; });
            showToast(v ? '已开启测试兜底（将模拟Dart失败）' : '已关闭测试兜底');
          },
        ),
        const Divider(height: 20),
        Row(
          children: [
            Text('任务列表', style: Theme.of(context).textTheme.titleMedium),
            const Spacer(),
            TextButton.icon(
              onPressed: ()=> _openTaskDialog(),
              icon: const Icon(Icons.add),
              label: const Text('新增任务'),
            )
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: _header(),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (_, idx){
                  final t = _tasks[idx];
                  final name = (t['name'] ?? '') as String;
                  final type = (t['type'] ?? 'manual') as String;
                  final subtitle = '类型：$type';
                  return ListTile(
                    title: Text(name),
                    subtitle: Text(subtitle),
                    onTap: () => _openTaskDialog(task: t),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
