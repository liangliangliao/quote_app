
import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../platform/perm_helper.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:quote_app/widgets/home_html_view.dart';
import 'package:quote_app/services/notification_service.dart';
import '../data/dao.dart';
import '../utils/debug_logger.dart';
import 'package:quote_app/services/native_guard.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  Map<String, dynamic>? _todayData;
  Map<String, dynamic>? _latestRow;
  bool _firstLoaded = false;
  bool _fav = false;
  bool _notifAsked = false;
  DateTime? _lastNotifCheckAt;
  bool _notifRequesting = false;

  // 将背景图读取为 data URI（base64）。如果加载失败，返回 file uri 路径。
  Future<String> _getBgDataUrl() async {
    try {
      final data = await rootBundle.load('assets/bg-wood-upload.jpg');
      final bytes = data.buffer.asUint8List();
      final b64 = base64Encode(bytes);
      return 'data:image/jpeg;base64,$b64';
    } catch (_) {
      // fallback to file uri
      return 'file:///android_asset/flutter_assets/assets/bg-wood-upload.jpg';
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SimpleBus.homeTick.addListener(_onBus);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      NotificationService.markHomeVisible();
      await _checkNotificationPermission();
    });
    _load();
  }

  void _onBus() { _load(); }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SimpleBus.homeTick.removeListener(_onBus);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      NotificationService.markHomeVisible();
      _checkNotificationPermission();
      _load();
    }
  }

  Future<String> _avatarToDataUrl(String raw) async {
    final s = (raw).toString().trim();
    if (s.isEmpty) return '';
    if (s.startsWith('data:') || s.startsWith('http://') || s.startsWith('https://')) return s;
    try {
      final f = File(s);
      if (await f.exists()) {
        final bytes = await f.readAsBytes();
        String mime = 'image/png';
        final lower = s.toLowerCase();
        if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) mime = 'image/jpeg';
        else if (lower.endsWith('.webp')) mime = 'image/webp';
        else if (lower.endsWith('.gif')) mime = 'image/gif';
        final b64 = base64Encode(bytes);
        return 'data:$mime;base64,$b64';
      }
    } catch (_) {}
    return '';
  }


  void _requestNotifAfterFirstFrame() {
    if (_notifAsked) return;
    _notifAsked = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      NotificationService.markHomeVisible();
      try {
        await _requestSystemNotifIfNeeded();
        await _maybeAskExactAfterNotif();
      } catch (_){}
    });
  });
  }

Future<bool> _isFirstOpenAndMarkLocal() async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, '.first_open_done'));
    if (await file.exists()) return false;
    await file.writeAsString(DateTime.now().toIso8601String());
    return true;
  } catch (_) { return false; }
}

Future<void> _maybeAskExactAfterNotif() async {
  bool enabled = true;
  try { enabled = await NotificationService.areNotificationsEnabled(); } catch (_){ enabled = false; }
  if (enabled != true) return;
  final first = await _isFirstOpenAndMarkLocal();
  if (!first) return;
  try {
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact && mounted) {
      final allow = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          content: const Text('为确保定时提醒准确，请在系统设置中允许“精确闹钟”。是否前往设置？'),
          actions: [
            TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('稍后')),
            FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('允许')),
          ],
        ),
      );
      if (allow == true) {
        try { await PermHelper.requestExactAlarmPermission(); } catch (_){}
      }
    }
  } catch (_){}
}
  Future<void> _load() async {
    // 仅在首次加载时将数据设为空以显示兜底，后续刷新保持原有数据避免闪屏
    if (!_firstLoaded) {
      setState(() { _todayData = null; _firstLoaded = true; });
    }
    try {
      final dao = QuoteDao();
      final latest = await dao.latestNotifiedToday();
      if (!mounted) return;
      _latestRow = latest;
      if (latest == null) {
        // 当查询不到今日数据时，注入固定的兜底内容而非 null。
        // 兜底内容与模板原始文案保持一致，这样即便无数据，也能通过 setDynamicData 渲染完整页面。
        await DLog.i('HOME', '今日未检索到已通知记录：注入兜底内容');
        final fallbackBg = await _getBgDataUrl();
        final fallback = <String, dynamic>{
          'topic': '不可战胜的夏天',
          'quote': '在隆冬之中，我终于在自己内心发现了一个不可战胜的夏天。',
          'author': '— Albert Camus, “Return to Tipasa” (from “Summer”)',
          'note': '这句出自随笔《重返提帕萨》（收于《夏天》）。加缪在战后重返阿尔及利亚的光、海与石之间，意识到即便身处“隆冬”——荒谬、失落与历史的沉重之中——人的内心仍可保存一簇不被世界熄灭的热与明。它指向加缪伦理中的“清醒的反抗”：不自欺也不绝望。所谓“不可战胜的夏天”，并非盲目乐观，而是承认世界的荒谬之后仍选择热爱、行动与承担的能力。',
          // 提供默认头像，以匹配兜底内容所引用的作者（阿尔贝·加缪）。
          'avatarUrl': 'https://upload.wikimedia.org/wikipedia/commons/c/c3/Albert_Camus_1945_%28cropped%29.jpg',
          // 使用 data URI 作为背景图，确保加载
          'bgUrl': fallbackBg,
        };
        if (mounted) setState(() { _todayData = fallback; });
      _requestNotifAfterFirstFrame();
      
      } else {
        final avatarUrl = await _avatarToDataUrl((latest['avatar'] ?? '').toString());
        // 根据署名和出处组装 author 字段。若存在署名或出处则前缀“——”，否则为空
        final String authorName = (latest['author_name'] ?? latest['author'] ?? '').toString().trim();
        final String source = (latest['source_from'] ?? latest['source'] ?? '').toString().trim();
        String authorLine = '';
        if (authorName.isNotEmpty || source.isNotEmpty) {
          // 如果署名不为空，使用“——署名 出处”，否则仅加前缀
          authorLine = '——';
          if (authorName.isNotEmpty) {
            authorLine += authorName;
            if (source.isNotEmpty) authorLine += ' $source';
          } else {
            authorLine += source;
          }
        }
        // 读取背景图为 data URI，使背景在各平台上稳定显示
        final bgUrl = await _getBgDataUrl();
        final payload = <String, dynamic>{
          'topic': (latest['theme'] ?? latest['topic'] ?? '').toString(),
          'quote': (latest['content'] ?? latest['quote'] ?? '').toString(),
          // 将 author 字段设置为包含署名和出处的组合文本
          'author': authorLine,
          'source': source,
          'note': (latest['explanation'] ?? latest['note'] ?? '').toString(),
          'avatarUrl': avatarUrl,
          // 将背景图片路径作为 data uri 传入，供 HTML 页通过 setBackground 使用。
          'bgUrl': bgUrl,
        };
        await DLog.i('HOME', '已检索到今日最新已通知记录：准备注入');
        if (mounted) setState(() { _todayData = payload; });
      _requestNotifAfterFirstFrame();
      }
    } catch (e) {
      await DLog.e('HOME', '查询异常：注入兜底内容；err=$e');
      // 当查询发生异常时，注入兜底内容以保证页面不为空白
      final fallbackBg = await _getBgDataUrl();
      final fallback = <String, dynamic>{
        'topic': '不可战胜的夏天',
        'quote': '在隆冬之中，我终于在自己内心发现了一个不可战胜的夏天。',
        'author': '— Albert Camus, “Return to Tipasa” (from “Summer”)',
        'note': '这句出自随笔《重返提帕萨》（收于《夏天》）。加缪在战后重返阿尔及利亚的光、海与石之间，意识到即便身处“隆冬”——荒谬、失落与历史的沉重之中——人的内心仍可保存一簇不被世界熄灭的热与明。它指向加缪伦理中的“清醒的反抗”：不自欺也不绝望。所谓“不可战胜的夏天”，并非盲目乐观，而是承认世界的荒谬之后仍选择热爱、行动与承担的能力。',
        'avatarUrl': 'https://upload.wikimedia.org/wikipedia/commons/c/c3/Albert_Camus_1945_%28cropped%29.jpg',
        'bgUrl': fallbackBg,
      };
      if (mounted) setState(() { _todayData = fallback; });
      _requestNotifAfterFirstFrame();
      }
  }

  Future<void> _copyLatest() async {
    final text = (_latestRow?['content'] ?? '').toString();
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final assetPath = 'assets/html/poster-wall-only-frame-v23-1.html';
    final content = (!_firstLoaded) ? const {'__blank__': true} : _todayData;
    final topPad = MediaQuery.of(context).padding.top;

    return Scaffold(
      // 恢复纯白背景，避免绿色或其他底色
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // 内容区
          Positioned.fill(
            child: Padding(
              padding: EdgeInsets.only(top: topPad),
              child: Center(child: HomeHtmlView(assetPath: assetPath, data: content)),
            ),
          ),
          // 顶栏区域（悬浮白底按钮）
          Positioned(
            top: topPad,
            left: 0,
            right: 0,
            height: kToolbarHeight,
            child: IgnorePointer(
              ignoring: false,
              child: Row(
                children: [
                  const SizedBox(width: 8),
                  const Expanded(child: SizedBox()),
                  // share
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '分享',
                        icon: const Icon(Icons.share, color: Colors.black87),
                        onPressed: () async {
                          // 简化版分享：复制到剪贴板并提示
                          await _copyLatest();
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // copy
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '复制',
                        icon: const Icon(Icons.copy, color: Colors.black87),
                        onPressed: _copyLatest,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // favorite
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: _fav ? '取消收藏' : '收藏',
                        icon: Icon(_fav ? Icons.favorite : Icons.favorite_border, color: Colors.black87),
                        onPressed: () => setState(() => _fav = !_fav),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 统一的通知权限请求入口：带 2 秒去抖与并发保护，避免重复弹两次。
  Future<void> _requestSystemNotifIfNeeded() async {
    final now = DateTime.now();
    if (_notifRequesting) return;
    if (_lastNotifCheckAt != null && now.difference(_lastNotifCheckAt!) < const Duration(seconds: 2)) return;
    _lastNotifCheckAt = now;
    _notifRequesting = true;
    try {
      bool enabled = true;
      try { enabled = await NotificationService.areNotificationsEnabled(); } catch (_){ enabled = false; }
      if (enabled != true) {
        try { await NotificationService.request(); } catch (_){}
      }
    } finally {
      _notifRequesting = false;
    }
  }

  /// 每次进入首页（首开/重启/被杀后重启/从后台恢复）都即时检查通知权限；未开启则仅触发系统默认授权弹框。
  Future<void> _checkNotificationPermission() async {
    try {
      await _requestSystemNotifIfNeeded();
      await _maybeAskExactAfterNotif();
    } catch (_){}
  }
}