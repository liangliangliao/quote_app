import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:quote_app/services/native_guard.dart';

class NotificationService {
  static bool _homeVisible = false;
  static bool _requestedThisSession = false;

  static void markHomeVisible() {
    _homeVisible = true;
    _requestedThisSession = false;
  }

  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const AndroidInitializationSettings androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosInit = DarwinInitializationSettings();
    const InitializationSettings initSettings = InitializationSettings(android: androidInit, iOS: iosInit);

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        try { SimpleBus.navHome(); SimpleBus.pokeHome(); } catch (_) {}
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'quote_high', '定时提醒',
      description: 'Quote 定时提醒',
      importance: Importance.high,
    );
    try {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await android?.createNotificationChannel(channel);
    } catch (_) {}
  }

  @pragma('vm:entry-point')
  static void notificationTapBackground(NotificationResponse response) {
    try { SimpleBus.navHome(); SimpleBus.pokeHome(); } catch (_) {}
  }

  static Future<bool> areNotificationsEnabled() async {
    try {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android != null) {
        final enabled = await android.areNotificationsEnabled();
        return enabled ?? true;
      }
    } catch (_) {}
    return true;
  }

  static Future<void> request() async {
    try {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return;
      try { await android.requestNotificationsPermission(); return; } catch (_) {}
      try { await (android as dynamic).requestPermission(); } catch (_) {}
    } catch (_) {}
  }

  static Future<void> showSimple(String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails('quote_high', '定时提醒', importance: Importance.high, priority: Priority.high),
      iOS: DarwinNotificationDetails(),
    );
    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    await _plugin.show(id, title, body, details);
  }

  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'quote_high', '定时提醒',
      channelDescription: 'Quote 定时提醒',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? BigPictureStyleInformation(
              FilePathAndroidBitmap(largeIconPath),
              largeIcon: FilePathAndroidBitmap(largeIconPath),
              contentTitle: title,
              summaryText: body,
            )
          : const DefaultStyleInformation(true, true),
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails, iOS: const DarwinNotificationDetails());
    await _plugin.show(id ?? DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body, details);
  }
}
