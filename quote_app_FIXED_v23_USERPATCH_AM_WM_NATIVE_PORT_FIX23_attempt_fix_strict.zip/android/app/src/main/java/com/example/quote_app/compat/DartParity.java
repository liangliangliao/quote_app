package com.example.quote_app.compat;

import android.content.Context;
import android.text.TextUtils;

import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

import org.json.JSONObject;

/** 
 * 提供与 Dart 侧函数等价的 Java 包装（名称与语义尽可能一致），
 * 以满足“函数名/调用关系一致”的迁移对照需求。
 * 内部委托给已有原生实现，避免重复代码。
 */
public final class DartParity {
    private DartParity() {}

    /** 对齐 Dart: _alarmId(uid, runKey) */
    public static int alarmId(String uid, String runKey) {
        String rk = runKey == null ? "" : runKey;
        int h = (uid != null ? uid.hashCode() : 0) ^ rk.hashCode();
        return h & 0x7fffffff;
    }

    /** 对齐 Dart: scheduleExactAt + 注册2分钟兜底WM + setScheduledRunKey */
    public static boolean scheduleExactAt(Context ctx, long epochMs, String uid, String runKey, String payloadJson) {
        if (TextUtils.isEmpty(uid)) return false;
        int id = alarmId(uid, runKey);
        boolean ok = NativeSchedulerK.INSTANCE.scheduleExactAt(ctx, id, epochMs, payloadJson);
        // 兜底WM：2分钟后
        long fallbackAt = System.currentTimeMillis() + 2L*60L*1000L;
        try { NativeSchedulerK.INSTANCE.scheduleWmFallback(ctx, id, fallbackAt, payloadJson); } catch (Throwable ignored) {}
        // 记录 scheduled_run_key（缺列自动补列）
        try { DbRepository.setScheduledRunKey(ctx, uid, runKey != null ? runKey : String.valueOf(epochMs)); } catch (Throwable ignored) {}
        return ok;
    }

    /** 对齐 Dart: cancel(uid, runKey) */
    public static void cancel(Context ctx, String uid, String runKey) {
        int id = alarmId(uid, runKey);
        try { NativeSchedulerK.INSTANCE.cancel(ctx, id); } catch (Throwable ignored) {}
    }

    /** 对齐 Dart: scheduleSelfCheck() -> 使用 NativeSchedulerK 周期注册 */
    public static boolean scheduleSelfCheck(Context ctx, int minutes) {
        try { NativeSchedulerK.INSTANCE.scheduleSelfCheck(ctx, minutes); return true; } catch (Throwable t) { return false; }
    }

    /** 对齐 Dart: selfCheckTodayFailures() */
    public static void selfCheckTodayFailures(Context ctx) {
        java.util.List<String> uids = DbRepository.failsOfToday(ctx);
        long now = System.currentTimeMillis();
        for (String uid : uids) {
            try {
                String runKey = new java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US).format(new java.util.Date(now));
                int id = alarmId(uid, runKey);
                JSONObject payload = new JSONObject()
                        .put("uid", uid).put("runKey", runKey).put("chan", "normal").put("attempt", 1);
                NativeSchedulerK.INSTANCE.scheduleWmFallback(ctx, id, now, payload.toString());
                DbRepository.log(ctx, uid, "自检补发：已注册 WM 正常 uid="+uid+" run="+runKey);
            } catch (Throwable ignored) {}
        }
    }

    /** 对齐 Dart: wmRunTask(uid, runKey, chan, attempt) —— 委托 NotifyWorker/AlarmReceiver 的同等逻辑 */
    public static boolean wmRunTask(Context ctx, String uid, String runKey, String chan, int attempt) {
        if (TextUtils.isEmpty(uid)) return false;
        if (TextUtils.isEmpty(chan)) chan = "normal";
        if (attempt < 1) attempt = 1;
        int id = alarmId(uid, runKey);

        // 幂等
        try {
            if (!TextUtils.isEmpty(runKey) && DbRepository.alreadySent(ctx, uid, runKey, chan, attempt)) {
                try { NativeSchedulerK.INSTANCE.cancel(ctx, id); } catch (Throwable ignored) {}
                DbRepository.log(ctx, uid, "幂等拦截：已发送过 uid="+uid+" run="+runKey);
                return true;
            }
        } catch (Throwable e) { throw new RuntimeException(e); }

        try {
            boolean handled = Biz.run(ctx, uid);
            if (handled) {
                if (!TextUtils.isEmpty(runKey)) {
                    try { DbRepository.markSent(ctx, uid, runKey, chan, attempt); } catch (Throwable ignored) {}
                }
                try { NativeSchedulerK.INSTANCE.cancel(ctx, id); } catch (Throwable ignored) {}
                // 续排
                long next = NextTriggerCalculator.compute(ctx, uid);
                if (next > System.currentTimeMillis()) {
                    String nextPayload = new JSONObject().put("uid", uid).put("runKey", String.valueOf(next)).put("chan","am").put("attempt",1).toString();
                    NativeSchedulerK.INSTANCE.scheduleExactWmCompat(ctx, alarmId(uid, String.valueOf(next)), next, nextPayload);
                }
                try { DbRepository.markLatestSuccess(ctx, uid); } catch (Throwable ignored) {}
                return true;
            } else {
                DbRepository.log(ctx, uid, "发送失败：业务未处理 uid="+uid);
                try {
                    String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
                    DbRepository.insertFail(ctx, uid, chan, String.valueOf(id), today);
                } catch (Throwable ignored) {}
                // 兜底两次
                if (attempt <= 1) {
                    long nextEpoch = System.currentTimeMillis() + 2L*60L*1000L;
                    String retryPayload = new JSONObject().put("uid", uid).put("runKey", runKey).put("chan","wm_fallback").put("attempt", attempt+1).toString();
                    NativeSchedulerK.INSTANCE.scheduleWmFallback(ctx, id, nextEpoch, retryPayload);
                    return true;
                }
                return false;
            }
        } catch (Throwable t) {
            DbRepository.log(ctx, uid, "发送失败：异常 "+t.getMessage());
            try {
                String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
                DbRepository.insertFail(ctx, uid, chan, String.valueOf(id), today);
            } catch (Throwable ignored) {}
            if (attempt <= 1) {
                long nextEpoch = System.currentTimeMillis() + 2L*60L*1000L;
                String retryPayload = new JSONObject().put("uid", uid).put("runKey", runKey).put("chan","wm_fallback").put("attempt", attempt+1).toString();
                NativeSchedulerK.INSTANCE.scheduleWmFallback(ctx, id, nextEpoch, retryPayload);
                return true;
            }
            throw new RuntimeException(t);
        }
    }
}