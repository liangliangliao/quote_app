import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';

import '../data/db.dart';

class DiarySettingsPage extends StatefulWidget {
  const DiarySettingsPage({super.key});

  @override
  State<DiarySettingsPage> createState() => _DiarySettingsPageState();
}

class _DiarySettingsPageState extends State<DiarySettingsPage> {
  String? _bgPath;
  double _opacity = 0.25;
  final TextEditingController _pinCtrl = TextEditingController();
  bool _loaded = false;

  int? _targetConfigId; // which configs row we should update

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _pinCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = await AppDatabase.instance();

    try {
      // Prefer the latest row that already contains diary settings.
      final rows = await db.rawQuery('''
        SELECT id, diary_bg_image, diary_bg_opacity, diary_pin
        FROM configs
        WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '')
           OR diary_bg_opacity IS NOT NULL
           OR (diary_pin IS NOT NULL AND diary_pin != '')
        ORDER BY id DESC
        LIMIT 1
      ''');

      if (rows.isNotEmpty) {
        final r = rows.first;
        _targetConfigId = r['id'] as int?;
        _bgPath = (r['diary_bg_image'] ?? '').toString();
        final op = r['diary_bg_opacity'];
        if (op != null) {
          _opacity = double.tryParse(op.toString()) ?? _opacity;
        }
        _pinCtrl.text = (r['diary_pin'] ?? '').toString();
      } else {
        // Fallback: use latest row id if exists (so we update instead of inserting new rows)
        final latest = await db.query('configs', columns: ['id'], orderBy: 'id DESC', limit: 1);
        if (latest.isNotEmpty) {
          _targetConfigId = latest.first['id'] as int?;
        }
      }
    } catch (_) {
      // ignore and still render page
    }

    if (!mounted) return;
    setState(() => _loaded = true);
  }

  Future<String> _persistBgImage(String sourcePath) async {
    final src = File(sourcePath);
    if (!src.existsSync()) return sourcePath;

    final dir = await getApplicationDocumentsDirectory();
    final targetDir = Directory(path.join(dir.path, 'diary_bg'));
    if (!targetDir.existsSync()) targetDir.createSync(recursive: true);

    final ext = path.extension(sourcePath).isNotEmpty ? path.extension(sourcePath) : '.jpg';
    final filename = 'bg_${DateTime.now().millisecondsSinceEpoch}$ext';
    final destPath = path.join(targetDir.path, filename);

    await src.copy(destPath);
    return destPath;
  }

  Future<void> _pickBg() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final p = res.files.single.path;
    if (p == null || p.isEmpty) return;

    final persisted = await _persistBgImage(p);
    if (!mounted) return;
    setState(() => _bgPath = persisted);
  }

  Future<void> _save() async {
    final db = await AppDatabase.instance();

    final data = <String, Object?>{
      'diary_bg_image': (_bgPath ?? ''),
      'diary_bg_opacity': _opacity,
      'diary_pin': _pinCtrl.text.trim(),
    };

    try {
      if (_targetConfigId != null) {
        await db.update('configs', data, where: 'id=?', whereArgs: [_targetConfigId]);
      } else {
        // No row exists at all - insert.
        await db.insert('configs', data);
        // refresh target id
        final latest = await db.query('configs', columns: ['id'], orderBy: 'id DESC', limit: 1);
        if (latest.isNotEmpty) _targetConfigId = latest.first['id'] as int?;
      }
    } catch (_) {
      // If update fails for any reason, fallback to insert (last resort).
      try {
        await db.insert('configs', data);
      } catch (_) {}
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final exists = _bgPath != null && _bgPath!.isNotEmpty && File(_bgPath!).existsSync();

    return Scaffold(
      appBar: AppBar(title: const Text('日记设置')),
      body: ListView(
        children: [
          const ListTile(title: Text('背景设置')),
          ListTile(
            title: const Text('选择背景图'),
            subtitle: Text(exists ? _bgPath! : '未设置'),
            onTap: _pickBg,
          ),
          if (exists)
            ListTile(
              title: const Text('清除背景图'),
              onTap: () => setState(() => _bgPath = null),
            ),
          ListTile(
            title: const Text('背景透明度'),
            subtitle: Text('${(_opacity * 100).round()}%'),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Slider(
              value: _opacity.clamp(0.0, 1.0),
              onChanged: (v) => setState(() => _opacity = v),
            ),
          ),
          const Divider(),
          const ListTile(title: Text('PIN 锁（进入日记模块时验证）')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _pinCtrl,
              decoration: const InputDecoration(
                labelText: '4位数字（留空表示不开启）',
                border: OutlineInputBorder(),
              ),
              maxLength: 4,
              keyboardType: TextInputType.number,
              obscureText: true,
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: FilledButton(
              onPressed: _save,
              child: const Text('保存设置'),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
