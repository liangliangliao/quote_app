
// ignore_for_file: depend_on_referenced_packages
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  NotificationService._internal();
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _inited = false;

  Future<void> init() async {
    if (_inited) return;
    const AndroidInitializationSettings androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);
    _inited = true;
  }

  Future<void> show(String title, String body, {String? androidSmallIcon}) async {
    await init();
    final android = AndroidNotificationDetails(
      'quote_app_channel',
      'Quote App',
      channelDescription: 'General notifications for Quote App',
      importance: Importance.high,
      priority: Priority.high,
      icon: androidSmallIcon, // fallbacks to default if null
    );
    final details = NotificationDetails(android: android);
    await _plugin.show(DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body, details);
  }
}
