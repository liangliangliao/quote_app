
import 'dart:ui';
import 'package:workmanager/workmanager.dart';
import 'package:quote_app/utils/run_context.dart';
import 'scheduler_service.dart';

void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    RunContext.isFromWM = true;
    final data = inputData ?? {};
    final job = (data['job'] ?? '').toString();
    final uid = (data['task_uid'] ?? '').toString();
    final runKey = (data['run_key'] ?? '').toString();
    try {
      switch (job) {
        case 'wm_after_am':
          await SchedulerService.wmAfterAmTask(uid, runKey);
          break;
        case 'wm_run':
          await SchedulerService.wmRunTask(uid, runKey);
          break;
        case 'wm_catchup':
          await SchedulerService.catchupIfMissed();
          break;
        default:
          // unknown job, ignore
          break;
      }
      return true;
    } catch (_) {
      return false;
    } finally {
      RunContext.isFromWM = false;
    }
  });
}
