
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';

class OctagonClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final w = size.width;
    final h = size.height;
    final c = 0.18; // corner factor
    final Path p = Path();
    p.moveTo(c*w, 0);
    p.lineTo(w-c*w, 0);
    p.lineTo(w, c*h);
    p.lineTo(w, h-c*h);
    p.lineTo(w-c*w, h);
    p.lineTo(c*w, h);
    p.lineTo(0, h-c*h);
    p.lineTo(0, c*h);
    p.close();
    return p;
  }
  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

ImageProvider _imageFromAny(String? urlOrData, {String? assetFallback}) {
  if (urlOrData == null || urlOrData.isEmpty) {
    if (assetFallback != null) return AssetImage(assetFallback);
    return const AssetImage('assets/bg-wood-upload.jpg'); // harmless default
  }
  if (urlOrData.startsWith('data:')) {
    final base64Part = urlOrData.substring(urlOrData.indexOf(',')+1);
    final bytes = base64.decode(base64Part);
    return MemoryImage(bytes);
  }
  if (urlOrData.startsWith('http')) {
    return NetworkImage(urlOrData);
  }
  if (urlOrData.startsWith('assets/')) {
    return AssetImage(urlOrData);
  }
  return AssetImage(assetFallback ?? 'assets/bg-wood-upload.jpg');
}

/// 纯 Flutter 版的海报，按照你的原型图实现：
/// - 木纹相框背景（使用同一张 assets/bg-wood-upload.jpg）
/// - 内部白色画布 + 阴影
/// - 左上角标题、右上角头像（八边形裁剪）
/// - 中部中文大段引文
/// - 英文作者署名（斜体、带长破折号）
/// - 下方中文注解段落
class PosterPureFlutter extends StatelessWidget {
  final String topic;     // 左上标题
  final String quote;     // 主引文（中文）
  final String author;    // 英文署名（可含长破折号）
  final String note;      // 注释段落（中文）
  final String avatar;    // 头像 url/base64/asset
  final String woodBgAsset; // 木纹背景（相框）
  const PosterPureFlutter({
    super.key,
    required this.topic,
    required this.quote,
    required this.author,
    required this.note,
    required this.avatar,
    this.woodBgAsset = 'assets/bg-wood-upload.jpg',
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cons) {
        final maxW = cons.maxWidth;
        final maxH = cons.maxHeight;
        final short = maxW < maxH ? maxW : maxH;

        // 基于原图比例粗略调整字号
        final t1 = (short * 0.050).clamp(16.0, 26.0); // 标题
        final tQuote = (short * 0.085).clamp(22.0, 40.0); // 主引文
        final tAuthor = (short * 0.044).clamp(14.0, 22.0); // 署名
        final tNote = (short * 0.040).clamp(12.0, 18.0); // 注解
        final framePad = (short * 0.035).clamp(14.0, 24.0); // 木纹边宽
        final canvasPad = (short * 0.040).clamp(18.0, 28.0); // 白画布内边距
        final avatarSize = (short * 0.17).clamp(60.0, 110.0);

        return Container(
          color: Colors.white,
          alignment: Alignment.topCenter,
          padding: EdgeInsets.only(top: (short * 0.10).clamp(30.0, 60.0)),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(woodBgAsset),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 18,
                    spreadRadius: 2,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Padding(
                padding: EdgeInsets.all(framePad),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(canvasPad),
                    child: Stack(
                      children: [
                        // 顶部布局：左标题 + 右头像
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Text(
                                    topic,
                                    style: TextStyle(
                                      color: Colors.black87,
                                      fontSize: t1,
                                      height: 1.35,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                                SizedBox(width: framePad),
                                ClipPath(
                                  clipper: OctagonClipper(),
                                  child: Container(
                                    width: avatarSize,
                                    height: avatarSize,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: _imageFromAny(avatar, assetFallback: 'assets/bg-wood-upload.jpg'),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: canvasPad * 0.6),
                            // 主引文
                            Text(
                              quote,
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: tQuote,
                                height: 1.4,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: canvasPad * 0.5),
                            // 英文作者署名（斜体 + 长破折号起始）
                            Text(
                              author,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: tAuthor,
                                height: 1.35,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: canvasPad * 0.5),
                            // 注解段落
                            Text(
                              note,
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: tNote,
                                height: 1.55,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
