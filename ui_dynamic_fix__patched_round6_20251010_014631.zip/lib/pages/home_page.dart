import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/dao.dart';
import 'package:quote_app/widgets/home_html_view.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _fav = false;
  Map<String,dynamic>? _latest;
  Timer? _timer;

  Future<void> _shareLatest() async {
    // 为避免新增依赖，这里用复制到剪贴板作为“分享”的简化实现
    final text = (_latest?['content'] ?? '') as String?;
    if (text == null || text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制，可去任何应用粘贴分享')));
    }
  }


  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 5), (_)=> _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final dao = QuoteDao();
    // First try to load the most recently notified quote (notify_status=1 and latest last_notified_at)
    final latestNotified = await dao.latestNotified();
    // 如果没有任何通知成功，_latest 设为 null，让首页显示兜底静态页
    setState(() => _latest = latestNotified);
  }

  @override
  Widget build(BuildContext context) {
    final topH = MediaQuery.of(context).padding.top + kToolbarHeight;
    Widget content;
    content = HomeHtmlView(assetPath: 'assets/html/poster-wall-only-frame-v23-1.html', data: _latest);
    return Stack(
      children: [
        // 内容区整体下移并在剩余空间垂直居中，避免进入状态栏/顶栏区域且保持上下留白对称
        Padding(
          padding: EdgeInsets.only(top: topH),
          child: Center(child: content),
        ),
        // 顶部白条
        Positioned(
          left: 0, right: 0, top: 0,
          child: Container(height: topH, color: Colors.white),
        ),
        // 顶栏按钮（左侧三个）
        Positioned(
          left: 8, top: MediaQuery.of(context).padding.top + 8,
          child: Row(
            children: [
              IconButton(onPressed: _shareLatest, icon: const Icon(Icons.share)),
              IconButton(onPressed: () async {
                final text = (_latest?['content'] ?? '') as String?;
                if (text == null || text.isEmpty) return;
                await Clipboard.setData(ClipboardData(text: text));
                if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'))); }
              }, icon: const Icon(Icons.copy)),
              IconButton(onPressed: (){ setState(()=> _fav = !_fav); }, icon: Icon(_fav ? Icons.favorite : Icons.favorite_border)),
            ],
          ),
        ),
      ],
    );
  }
}