import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';

/// Belief Map: turn abstract beliefs into editable cards.
class BeliefMapPage extends StatefulWidget {
  const BeliefMapPage({super.key});

  @override
  State<BeliefMapPage> createState() => _BeliefMapPageState();
}

class _BeliefMapPageState extends State<BeliefMapPage> {
  final _dao = BeliefForgeDao();
  bool _loading = true;
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await _dao.ensureSchema();
    final rows = await _dao.listBeliefs();
    if (!mounted) return;
    setState(() {
      _items = rows;
      _loading = false;
    });
  }

  Future<void> _openEditor({Map<String, dynamic>? existing}) async {
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => _BeliefEditorSheet(existing: existing, dao: _dao),
    );
    if (ok == true) await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('信念图谱', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            ),
            FilledButton.icon(
              onPressed: () => _openEditor(),
              icon: const Icon(Icons.add),
              label: const Text('新增'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Text(
          '把“限制信念”写出来，再写一个“替代信念”。\n'
          '关键不是“逼自己相信”，而是用最小动作制造证据，让替代信念变可信。',
          style: TextStyle(fontSize: 13, color: Colors.black54, height: 1.3),
        ),
        const SizedBox(height: 12),
        if (_items.isEmpty)
          Card(
            elevation: 0,
            color: const Color(0xFFF7F7F7),
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: const Padding(
              padding: EdgeInsets.all(16),
              child: Text('还没有信念卡片。点击右上角“新增”开始。'),
            ),
          )
        else
          ..._items.map((it) => _BeliefCard(it: it, onEdit: () => _openEditor(existing: it), onDelete: () async {
                final id = (it['id'] as num?)?.toInt();
                if (id == null) return;
                await _dao.deleteBelief(id);
                await _load();
              })),
      ],
    );
  }
}

class _BeliefCard extends StatelessWidget {
  final Map<String, dynamic> it;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _BeliefCard({required this.it, required this.onEdit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final domain = (it['domain'] ?? '').toString();
    final bt = (it['belief_type'] ?? '').toString();
    final lim = (it['limiting_belief'] ?? '').toString();
    final tgt = (it['target_belief'] ?? '').toString();
    final strength = (it['strength_1_10'] as num?)?.toInt() ?? 5;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Card(
        elevation: 0,
        color: const Color(0xFFF7F7F7),
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${domain.isEmpty ? '未分类' : domain} · ${bt.isEmpty ? '信念' : bt}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                  IconButton(onPressed: onEdit, icon: const Icon(Icons.edit_outlined)),
                  IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline)),
                ],
              ),
              const SizedBox(height: 10),
              Text('限制信念：$lim', style: const TextStyle(height: 1.35)),
              const SizedBox(height: 6),
              Text('替代信念：$tgt', style: const TextStyle(height: 1.35, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('可信度', style: TextStyle(color: Colors.black54)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: LinearProgressIndicator(
                      value: strength / 10.0,
                      minHeight: 8,
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text('$strength/10', style: const TextStyle(color: Colors.black54)),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                '下一步建议：为“替代信念”做一个 1% 行动，让它变得更可信。\n'
                '例：替代信念=“我能开始” → 行动=“打开文档写第一句”。',
                style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.25),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BeliefEditorSheet extends StatefulWidget {
  final Map<String, dynamic>? existing;
  final BeliefForgeDao dao;
  const _BeliefEditorSheet({required this.dao, this.existing});

  @override
  State<_BeliefEditorSheet> createState() => _BeliefEditorSheetState();
}

class _BeliefEditorSheetState extends State<_BeliefEditorSheet> {
  late final TextEditingController _domain;
  String _type = 'self';
  late final TextEditingController _lim;
  late final TextEditingController _tgt;
  double _strength = 5;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _domain = TextEditingController(text: (e?['domain'] ?? '').toString());
    _type = (e?['belief_type'] ?? 'self').toString().isEmpty ? 'self' : (e?['belief_type'] ?? 'self').toString();
    _lim = TextEditingController(text: (e?['limiting_belief'] ?? '').toString());
    _tgt = TextEditingController(text: (e?['target_belief'] ?? '').toString());
    _strength = ((e?['strength_1_10'] as num?)?.toDouble() ?? 5).clamp(1, 10);
  }

  @override
  void dispose() {
    _domain.dispose();
    _lim.dispose();
    _tgt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, bottom: 16 + bottom, top: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.existing == null ? '新增信念卡' : '编辑信念卡', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          TextField(
            controller: _domain,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '领域（例：工作 / 关系 / 健康）'),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _type,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '类型'),
            items: const [
              DropdownMenuItem(value: 'self', child: Text('关于我自己')), 
              DropdownMenuItem(value: 'other', child: Text('关于他人')), 
              DropdownMenuItem(value: 'world', child: Text('关于世界')), 
              DropdownMenuItem(value: 'future', child: Text('关于未来')), 
              DropdownMenuItem(value: 'body', child: Text('关于身体/健康')),
            ],
            onChanged: (v) => setState(() => _type = v ?? 'self'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _lim,
            maxLines: 2,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '限制信念（例：我不够好）'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _tgt,
            maxLines: 2,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '替代信念（更可相信、可执行）'),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Text('当前可信度'),
              const SizedBox(width: 10),
              Expanded(
                child: Slider(
                  value: _strength,
                  min: 1,
                  max: 10,
                  divisions: 9,
                  label: _strength.toStringAsFixed(0),
                  onChanged: (v) => setState(() => _strength = v),
                ),
              ),
              Text('${_strength.toStringAsFixed(0)}/10'),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () async {
                    if (_lim.text.trim().isEmpty || _tgt.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请填写限制信念与替代信念')));
                      return;
                    }
                    final existing = widget.existing;
                    if (existing == null) {
                      await widget.dao.addBelief(
                        domain: _domain.text.trim(),
                        beliefType: _type,
                        limitingBelief: _lim.text.trim(),
                        targetBelief: _tgt.text.trim(),
                        strength1to10: _strength.round(),
                      );
                    } else {
                      final id = (existing['id'] as num?)?.toInt();
                      if (id != null) {
                        await widget.dao.updateBelief(
                          id: id,
                          domain: _domain.text.trim(),
                          beliefType: _type,
                          limitingBelief: _lim.text.trim(),
                          targetBelief: _tgt.text.trim(),
                          strength1to10: _strength.round(),
                        );
                      }
                    }
                    if (!context.mounted) return;
                    Navigator.pop(context, true);
                  },
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('保存'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
