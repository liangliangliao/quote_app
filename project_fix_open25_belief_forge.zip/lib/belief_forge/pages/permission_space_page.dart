import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';

/// Permission Space: a safe container for emotions.
class PermissionSpacePage extends StatefulWidget {
  const PermissionSpacePage({super.key});

  @override
  State<PermissionSpacePage> createState() => _PermissionSpacePageState();
}

class _PermissionSpacePageState extends State<PermissionSpacePage> {
  final _dao = BeliefForgeDao();
  double _mood = 5;
  final _emo = TextEditingController();
  final _l1 = TextEditingController();
  final _l2 = TextEditingController();
  final _l3 = TextEditingController();
  final _reframe = TextEditingController();

  @override
  void dispose() {
    _emo.dispose();
    _l1.dispose();
    _l2.dispose();
    _l3.dispose();
    _reframe.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_l1.text.trim().isEmpty || _l2.text.trim().isEmpty || _l3.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请至少写满三句话')));
      return;
    }
    await _dao.addJournal(
      mood0to10: _mood,
      emotion: _emo.text.trim().isEmpty ? null : _emo.text.trim(),
      line1: _l1.text.trim(),
      line2: _l2.text.trim(),
      line3: _l3.text.trim(),
      reframe: _reframe.text.trim().isEmpty ? null : _reframe.text.trim(),
    );
    if (!mounted) return;
    _l1.clear();
    _l2.clear();
    _l3.clear();
    _reframe.clear();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存到允许区')));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
      children: [
        const Text('允许区', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        const Text(
          '这里不是让你“变积极”，而是让你“先允许”，再回到行动。\n'
          '流程：感受 → 信息 → 照顾 →（可选）重构。',
          style: TextStyle(fontSize: 13, color: Colors.black54, height: 1.3),
        ),
        const SizedBox(height: 12),
        Card(
          elevation: 0,
          color: const Color(0xFFF7F7F7),
          surfaceTintColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('1) 情绪天气', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Text('心情(0-10)：', style: TextStyle(color: Colors.black54)),
                    const SizedBox(width: 8),
                    Text(_mood.toStringAsFixed(0), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ],
                ),
                Slider(
                  value: _mood,
                  min: 0,
                  max: 10,
                  divisions: 10,
                  label: _mood.toStringAsFixed(0),
                  onChanged: (v) => setState(() => _mood = v),
                ),
                TextField(
                  controller: _emo,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '主要情绪（可选）',
                    hintText: '例：焦虑 / 生气 / 难过 / 羞耻',
                  ),
                ),
                const SizedBox(height: 12),
                const Text('2) 三句话练习', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                TextField(
                  controller: _l1,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '第 1 句：我正在感到___'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _l2,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '第 2 句：这很正常，它告诉我___'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _l3,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '第 3 句：我愿意先照顾自己：___（最小动作）'),
                ),
                const SizedBox(height: 12),
                const Text('3) 可选：重构一句话', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                TextField(
                  controller: _reframe,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: '例：紧张=我在准备；难过=我在乎。',
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _save,
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('保存'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  '提示：允许不是放任。允许是“先停止二次伤害”，再做一个最小照顾动作。',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
