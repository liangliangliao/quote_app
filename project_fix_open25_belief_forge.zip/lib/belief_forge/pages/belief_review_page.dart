import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../belief_forge_dao.dart';

/// Review / insights based on the user's recent practice runs.
class BeliefReviewPage extends StatefulWidget {
  const BeliefReviewPage({super.key});

  @override
  State<BeliefReviewPage> createState() => _BeliefReviewPageState();
}

class _BeliefReviewPageState extends State<BeliefReviewPage> {
  final _dao = BeliefForgeDao();
  bool _loading = true;
  List<Map<String, dynamic>> _runs = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await _dao.ensureSchema();
    final rows = await _dao.listRuns();
    if (!mounted) return;
    setState(() {
      _runs = rows;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    final df = DateFormat('MM-dd HH:mm');
    final now = DateTime.now();
    final last7 = _runs.where((r) {
      final ts = (r['ts_ms'] as num?)?.toInt();
      if (ts == null) return false;
      final t = DateTime.fromMillisecondsSinceEpoch(ts);
      return now.difference(t).inDays <= 7;
    }).toList();

    int countLab = 0;
    int countWill = 0;
    int countSpace = 0;
    for (final r in last7) {
      final type = (r['run_type'] ?? '').toString();
      if (type == 'lab') countLab++;
      if (type == 'will') countWill++;
      if (type == 'space') countSpace++;
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('复盘', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              ),
              TextButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('刷新')),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            '复盘的目的不是评判，而是把“我做过”变成“我能”。\n'
            '你会在这里看到：过去 7 天做了什么、哪里容易坚持、下一步怎么更简单。',
            style: TextStyle(fontSize: 13, color: Colors.black54, height: 1.3),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            color: const Color(0xFFF7F7F7),
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('过去 7 天', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  _StatRow(label: '实验室（概念）', value: countLab.toString()),
                  _StatRow(label: '意志训练', value: countWill.toString()),
                  _StatRow(label: '允许区记录', value: countSpace.toString()),
                  const SizedBox(height: 10),
                  const Text(
                    '建议：如果你想让信念真正改变生活，\n'
                    '请把“学习”连到“行动证据”——每天 1 个 1% 动作。',
                    style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.25),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('最近记录', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          if (_runs.isEmpty)
            Card(
              elevation: 0,
              color: const Color(0xFFF7F7F7),
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: const Padding(
                padding: EdgeInsets.all(16),
                child: Text('暂无记录。去“实验室/意志/允许区”完成一次练习吧。'),
              ),
            )
          else
            ..._runs.take(30).map(
              (r) {
                final ts = (r['ts_ms'] as num?)?.toInt();
                final t = ts == null ? null : DateTime.fromMillisecondsSinceEpoch(ts);
                final title = (r['concept_title'] ?? '').toString();
                final type = (r['run_type'] ?? '').toString();
                final note = (r['note'] ?? '').toString();
                final score = (r['score'] as num?)?.toDouble();
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Card(
                    elevation: 0,
                    color: const Color(0xFFF7F7F7),
                    surfaceTintColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(title.isEmpty ? '练习' : title, style: const TextStyle(fontWeight: FontWeight.w700)),
                              ),
                              Text(type, style: const TextStyle(color: Colors.black54)),
                            ],
                          ),
                          const SizedBox(height: 6),
                          if (t != null) Text(df.format(t), style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          if (score != null) Text('得分：${score.toStringAsFixed(0)}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          if (note.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text(note, style: const TextStyle(height: 1.25)),
                          ]
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  const _StatRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.black54))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
