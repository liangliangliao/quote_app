import 'package:flutter/material.dart';

import '../model/belief_concepts.dart';
import 'belief_lab_page.dart';
import 'belief_map_page.dart';
import 'permission_space_page.dart';
import 'will_gym_page.dart';
import 'belief_review_page.dart';

class BeliefForgeHomePage extends StatelessWidget {
  const BeliefForgeHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
      children: [
        _HeroCard(),
        const SizedBox(height: 12),
        const Text(
          '今日推荐：选 1 个概念，先做“体验”，再读解释，然后把它落到一个 1% 行动。',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        _ConceptQuickPick(),
        const SizedBox(height: 16),
        const Text('你可以从这里开始', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        _EntryGrid(),
        const SizedBox(height: 16),
        const Text('为什么它能改变生活', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        const _WhyItWorks(),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('信念工坊 BeliefForge', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Text(
              '把“信念”从抽象观点变成可执行的日常系统：\n'
              '信念 → 注意力/意志 → 行动 → 反馈 → 信念更新。',
              style: TextStyle(fontSize: 13, color: Colors.black87, height: 1.35),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConceptQuickPick extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final picks = kBeliefForgeConcepts.take(3).toList();
    return Column(
      children: picks
          .map(
            (c) => ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              tileColor: const Color(0xFFF7F7F7),
              leading: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(c.icon, color: Colors.black87),
              ),
              title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(c.subtitle),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => BeliefLabPage(initialConceptId: c.id)),
              ),
            ),
          )
          .toList(),
    );
  }
}

class _EntryGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = <_EntryItem>[
      _EntryItem('信念实验室', '概念关卡 + 体验 + 解释', Icons.school_outlined),
      _EntryItem('信念图谱', '记录你的限制信念与替代信念', Icons.map_outlined),
      _EntryItem('意志训练', 'fiat 决断 + 注意力拉回', Icons.fitness_center_outlined),
      _EntryItem('允许区', '情绪容纳 + 三句日记', Icons.self_improvement_outlined),
      _EntryItem('复盘', '洞察与下一步', Icons.insights_outlined),
    ];

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: items
          .map(
            (it) => SizedBox(
              width: (MediaQuery.of(context).size.width - 16 * 2 - 12) / 2,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () {
                  final Widget body;
                  if (it.title.contains('实验室')) {
                    body = const BeliefLabPage();
                  } else if (it.title.contains('图谱')) {
                    body = const BeliefMapPage();
                  } else if (it.title.contains('意志')) {
                    body = const WillGymPage();
                  } else if (it.title.contains('允许')) {
                    body = const PermissionSpacePage();
                  } else {
                    body = const BeliefReviewPage();
                  }
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => Scaffold(
                        appBar: AppBar(
                          title: Text(it.title),
                          backgroundColor: Colors.white,
                          surfaceTintColor: Colors.transparent,
                        ),
                        backgroundColor: Colors.white,
                        body: body,
                      ),
                    ),
                  );
                },
                child: Card(
                  elevation: 0,
                  color: const Color(0xFFF7F7F7),
                  surfaceTintColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(it.icon, color: Colors.black87),
                        const SizedBox(height: 10),
                        Text(it.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        Text(it.subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.2)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}

class _EntryItem {
  final String title;
  final String subtitle;
  final IconData icon;
  _EntryItem(this.title, this.subtitle, this.icon);
}

class _WhyItWorks extends StatelessWidget {
  const _WhyItWorks();

  @override
  Widget build(BuildContext context) {
    const bullets = [
      '用“微实验”让你亲自体验：环境/期待/情绪如何影响行为。',
      '每个概念都给“解释 + 为什么 + 怎么做 + 案例”，让你知其然且知其所以然。',
      '用 1% 行动制造证据：证据会反过来改写信念，让改变可持续。',
    ];
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: bullets
              .map(
                (b) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('• ', style: TextStyle(fontSize: 16, height: 1.3)),
                      Expanded(child: Text(b, style: const TextStyle(height: 1.3))),
                    ],
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
