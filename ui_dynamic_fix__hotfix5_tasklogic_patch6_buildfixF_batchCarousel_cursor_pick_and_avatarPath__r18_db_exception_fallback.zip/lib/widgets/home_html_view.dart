// GENERATED FIX: robust data injection + avatar base64 scaling
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';
import 'package:image/image.dart' as img;
import '../utils/debug_logger.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ;
    _loadFirstFrame();
}

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  // -- Helpers -----------------------------------------------------------------
String _coalesce(Map d, List keys) {
  for (final k in keys) {
    if (d.containsKey(k) && d[k] != null) {
      final v = d[k];
      if (v is String && v.trim().isNotEmpty) return v.trim();
      return v.toString();
    }
  }
  return '';
}


  static bool _looksLikeUrl(String s) => s.startsWith('http://') || s.startsWith('https://');
  static bool _looksLikeData(String s) => s.startsWith('data:image/');

  static String _extToMime(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    if (p.endsWith('.gif')) return 'image/gif';
    return 'image/jpeg';
  }

  /// Read an avatar source and return a **small** data URL (<= ~60KB) to avoid
  /// evaluateJavascript length limits on Android WebView.
  Future<String> _normalizeAvatar(dynamic raw) async {
    if (raw == null) return '';
    final s = raw.toString();
    if (s.isEmpty) return '';
    if (_looksLikeUrl(s) || _looksLikeData(s)) return s;

    // Try file path (absolute or file://)
    var path = s;
    if (path.startsWith('file://')) path = path.substring(7);
    final f = File(path);
    if (!(await f.exists())) return '';

    // Decode -> downscale -> JPEG(85)
    try {
      final bytes = await f.readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return '';
      final maxSide = 256;
      final resized = img.copyResize(decoded, width: decoded.width > decoded.height ? maxSide : null, height: decoded.height >= decoded.width ? maxSide : null, interpolation: img.Interpolation.average);
      final out = img.encodeJpg(resized, quality: 85);
      final b64 = base64Encode(out);
      return 'data:image/jpeg;base64,' + b64;
    } catch (e) {
      try { await DLog.e('HTML','avatar normalize failed: ' + e.toString()); } catch(_){}
      return '';
    }
  }

  
  Future<void> _loadFirstFrame() async {
    final isBlank = (widget.data is Map) && ((widget.data as Map)['__blank__'] == true);
    // Blank-first strategy
// If we already have data, compose final HTML and load once to avoid flicker.
    try {
      final d = widget.data;
      if (isBlank) { await _controller.loadHtmlString('<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head><body style="background:transparent;margin:0;padding:0;"></body></html>'); _ready = true; return; }
if (d != null) {
        final payloadMap = <String, dynamic>{
          'topic': _coalesce(d, ['topic','title','headline','subject','theme','主题','标题']),
          'quote': _coalesce(d, ['quote','content','body','正文']),
          'author': _coalesce(d, ['author','author_name','speaker','signature','署名','签名','credit']),
          'source': _coalesce(d, ['source','origin','source_from','出处','来源','from']),
          'note': _coalesce(d, ['explain','explanation','note','comment','memo','备注']),
        };
        final rawAvatar = d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url'];
        payloadMap['avatarUrl'] = await _normalizeAvatar(rawAvatar);
        if (d.containsKey('focalX')) payloadMap['focalX'] = d['focalX'];
        if (d.containsKey('focalY')) payloadMap['focalY'] = d['focalY'];

        final tpl = await rootBundle.loadString(widget.assetPath);
        final payloadJson = jsonEncode(payloadMap);
        // Hide body until data applied, then reveal, to avoid static->dynamic flash.
        final injector = '''
<style>
#topic-text,#quote-text,#author-text,#note-text,
#avatar-img,[id*="avatar"],[class*="avatar"],img[alt*="avatar"]{visibility:hidden}
</style>
<script>
(function(){
  function reveal(){
    try{
      ['topic-text','quote-text','author-text','note-text'].forEach(function(id){
        var el = document.getElementById(id); if (el) el.style.visibility='visible';
      });
      Array.from(document.querySelectorAll('[id*="avatar"],[class*="avatar"],img[alt*="avatar"],#avatar-img')).forEach(function(el){
        el.style.visibility='visible';
      });
      if (document && document.body) document.body.style.visibility='visible';
    }catch(e){}
  }
  function apply(){
    try{
      var payload = PAYLOAD;
      if (window.setDynamicData) {
        try { window.setDynamicData(payload); } catch(e) {}
        reveal();
        return;
      }
      // fallback: write minimal fields directly
      if (payload){
        var t = document.getElementById('topic-text'); if (t && payload.theme) t.textContent = payload.theme;
        var q = document.getElementById('quote-text'); if (q && payload.quote) q.textContent = payload.quote;
        var a = document.getElementById('author-text'); if (a && payload.authorText) a.textContent = payload.authorText;
        var n = document.getElementById('note-text'); if (n && payload.note) n.textContent = payload.note;
        var av = document.querySelector('#avatar-img,[id*="avatar"],[class*="avatar"],img[alt*="avatar"]');
        if (av && payload.avatarUrl) av.setAttribute('src', payload.avatarUrl);
      }
      reveal();
    }catch(e){ reveal(); }
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(apply, 0);
  } else {
    document.addEventListener('DOMContentLoaded', apply);
  }
})();
</script>'''.replaceAll("PAYLOAD", payloadJson);
        String html = tpl;
        if (!html.contains('<body')) {
          // fallback: just load template
          await _controller.loadFlutterAsset(widget.assetPath);
          return;
        }
        // ensure hidden before injecting
        if (!RegExp(r'visibility\s*:\s*hidden').hasMatch(html)) {
          html = html.replaceFirst('<body', '<body style="visibility:hidden"');
        }
        html = html.replaceFirst('</body>', injector + '\n</body>');
        await _controller.loadHtmlString(html);
        _ready = true; // avoid double-injection in onPageFinished
        return;
      }
    } catch (_) {
      // fallback to asset
    }
    await _controller.loadFlutterAsset(widget.assetPath);
  }

Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
if (d == null) return;
    final payloadMap = <String, dynamic>{
  'topic': _coalesce(d, ['topic','title','headline','subject','theme','主题','标题']),
  'quote': _coalesce(d, ['quote','content','body','正文']),
  'author': _coalesce(d, ['author','author_name','speaker','signature','署名','签名','credit']),
  'source': _coalesce(d, ['source','origin','source_from','出处','来源','from']),
  'note': _coalesce(d, ['explain','explanation','note','comment','memo','备注']),
  'avatarUrl': await _normalizeAvatar(
    d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
  ),
  if (d.containsKey('focalX')) 'focalX': d['focalX'],
  if (d.containsKey('focalY')) 'focalY': d['focalY'],
};
    // avatar
    final rawAvatar = d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url'];
    payloadMap['avatarUrl'] = await _normalizeAvatar(rawAvatar);
    if (d.containsKey('focalX')) payloadMap['focalX'] = d['focalX'];
    if (d.containsKey('focalY')) payloadMap['focalY'] = d['focalY'];

    final payloadJson = jsonEncode(payloadMap);

    try { await DLog.i('HTML', '注入数据: ' + (payloadJson.length > 256 ? (payloadJson.substring(0,256)+'...('+payloadJson.length.toString()+' bytes)') : payloadJson)); } catch(_){}

    // Some WebViews have trouble with very long evaluateJavascript strings.
    // Keep it small by compressing avatar above. Additionally, guard with try..catch in JS.
    final script = "try { window.setDynamicData(PAYLOAD); } catch(e) { console && console.error && console.error('inject failed', e); }".replaceFirst("PAYLOAD", payloadJson);
    await _controller.runJavaScript(script);
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
