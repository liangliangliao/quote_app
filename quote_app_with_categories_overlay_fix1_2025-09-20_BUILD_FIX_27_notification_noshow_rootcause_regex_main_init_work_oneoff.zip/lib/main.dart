import 'platform/perm_helper.dart';

import 'package:flutter/material.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/settings_page.dart';
import 'pages/logs_page.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'data/db.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Start app immediately to avoid long splash hang; init async after first frame.
  try { await AndroidAlarmManager.initialize(); } catch (_) {}
  runApp(const MyApp());
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try { await AndroidAlarmManager.initialize(); } catch (_) {}
    await AppDatabase.instance();
    await PermHelper.ensureExactAlarmPermission();
    // 某些机型需要直接主动请求一次以唤起授权页
    await PermHelper.requestExactAlarmPermission();
    await PermHelper.ensureBatteryOptExemption();
    await NotificationService.init();
    await SchedulerService.init();
    await SchedulerService.scheduleNextForAll();
  });
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];
  // Titles removed per UI requirement
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        body: _pages[_idx],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _idx,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home), label: '首页'),
            NavigationDestination(icon: Icon(Icons.history), label: '历史'),
            NavigationDestination(icon: Icon(Icons.list), label: '日志'),
            NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
          ],
          onDestinationSelected: (i)=> setState(()=> _idx = i),
        ),
      ),
    );
  }
}
