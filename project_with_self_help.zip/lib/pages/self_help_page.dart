import 'dart:async';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../data/self_help_dao.dart';

/// 心理自助：主观唤醒（简化 STAI-S6） + 摄像头PPG心率/HRV + 舒适区/学习区/恐慌区判定
class SelfHelpPage extends StatefulWidget {
  const SelfHelpPage({super.key});

  @override
  State<SelfHelpPage> createState() => _SelfHelpPageState();
}

class _StaiItem {
  final String id;
  final String text;
  final bool reverse;
  const _StaiItem(this.id, this.text, {this.reverse = false});
}

class _SelfHelpPageState extends State<SelfHelpPage> {
  final _dao = SelfHelpDao();

  // --- 主观：简化 STAI-S6（每题 1~4）---
  static const List<_StaiItem> _items = [
    _StaiItem('calm', '我感到平静', reverse: true),
    _StaiItem('tense', '我感到紧张'),
    _StaiItem('upset', '我感到烦躁'),
    _StaiItem('relaxed', '我感到放松', reverse: true),
    _StaiItem('content', '我感到满足', reverse: true),
    _StaiItem('worried', '我感到担忧'),
  ];
  final Map<String, int> _answers = {}; // 1..4

  // --- 客观：摄像头PPG ---
  CameraController? _cam;
  bool _camReady = false;
  bool _measuring = false;
  double _progress = 0.0;
  Timer? _ticker;
  final List<double> _ppg = [];
  final List<int> _ts = [];
  int _startMs = 0;
  int _lastFrameMs = 0;

  // 结果
  double? _bpm;
  double? _rmssd;
  String? _zone;
  String? _advice;
  String? _error;

  @override
  void dispose() {
    _ticker?.cancel();
    _stopStreamSafely();
    _cam?.dispose();
    super.dispose();
  }

  double? _subjectiveScore0to10() {
    if (_answers.length != _items.length) return null;
    int total = 0;
    for (final it in _items) {
      final a = _answers[it.id]!;
      final s = it.reverse ? (5 - a) : a;
      total += s;
    }
    // total range: 6..24 -> 0..10
    final v = (total - 6) / (24 - 6) * 10.0;
    return double.parse(v.clamp(0.0, 10.0).toStringAsFixed(1));
  }

  Future<void> _ensureCamera() async {
    if (_camReady) return;

    final status = await Permission.camera.status;
    if (!status.isGranted) {
      final req = await Permission.camera.request();
      if (!req.isGranted) {
        throw Exception('未获得相机权限');
      }
    }

    final cams = await availableCameras();
    final back = cams.where((c) => c.lensDirection == CameraLensDirection.back).toList();
    final camDesc = (back.isNotEmpty ? back.first : cams.first);

    final controller = CameraController(
      camDesc,
      ResolutionPreset.low,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.yuv420,
    );
    await controller.initialize();

    // 尝试打开 torch（部分设备可能不支持）
    try {
      await controller.setFlashMode(FlashMode.torch);
    } catch (_) {
      // ignore
    }

    _cam = controller;
    _camReady = true;
    if (mounted) setState(() {});
  }

  Future<void> _startMeasure() async {
    final subj = _subjectiveScore0to10();
    if (subj == null) {
      setState(() {
        _error = '请先完成 6 题自评（每题选择 1~4）。';
      });
      return;
    }

    setState(() {
      _error = null;
      _bpm = null;
      _rmssd = null;
      _zone = null;
      _advice = null;
    });

    try {
      await _ensureCamera();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '相机初始化失败：$e';
      });
      return;
    }

    // reset buffers
    _ppg.clear();
    _ts.clear();
    _startMs = DateTime.now().millisecondsSinceEpoch;
    _lastFrameMs = 0;

    setState(() {
      _measuring = true;
      _progress = 0.0;
    });

    // 20 秒测量
    const duration = Duration(seconds: 20);

    // 进度刷新
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(milliseconds: 100), (_) {
      final now = DateTime.now().millisecondsSinceEpoch;
      final elapsed = now - _startMs;
      final p = elapsed / duration.inMilliseconds;
      if (mounted) {
        setState(() => _progress = p.clamp(0.0, 1.0));
      }
    });

    // 开始流
    await _cam!.startImageStream(_onFrame);

    // 到点停止
    Timer(duration, () async {
      if (!mounted) return;
      await _finishMeasure();
    });
  }

  Future<void> _finishMeasure() async {
    if (!_measuring) return;
    _ticker?.cancel();

    await _stopStreamSafely();

    final subj = _subjectiveScore0to10()!;
    if (_ppg.length < 30) {
      setState(() {
        _measuring = false;
        _error = '采样数据太少。请用指腹轻盖住后置摄像头与闪光灯，保持稳定，重新测量。';
      });
      return;
    }

    final result = _computeBpmAndRmssd(_ppg, _ts);
    if (result == null) {
      setState(() {
        _measuring = false;
        _error = '未能识别稳定脉搏信号。请调整手指覆盖力度/位置，重新测量。';
      });
      return;
    }

    final bpm = result.$1;
    final rmssd = result.$2;

    final zone = _classifyZone(subjective: subj, bpm: bpm, rmssd: rmssd);
    final advice = _zoneAdvice(zone);

    // 保存
    try {
      await _dao.insert(
        subjectiveScore: subj,
        heartRateBpm: bpm,
        hrvRmssdMs: rmssd,
        zone: zone,
      );
    } catch (_) {
      // ignore save errors
    }

    if (!mounted) return;
    setState(() {
      _measuring = false;
      _bpm = bpm;
      _rmssd = rmssd;
      _zone = zone;
      _advice = advice;
    });
  }

  Future<void> _stopStreamSafely() async {
    try {
      final c = _cam;
      if (c != null && c.value.isStreamingImages) {
        await c.stopImageStream();
      }
    } catch (_) {
      // ignore
    }
  }

  void _onFrame(CameraImage image) {
    if (!_measuring) return;

    final now = DateTime.now().millisecondsSinceEpoch;
    // 节流：~20fps，减轻CPU
    if (_lastFrameMs != 0 && (now - _lastFrameMs) < 50) return;
    _lastFrameMs = now;

    // 使用Y平面（亮度）做PPG近似，能反映指尖随脉搏的亮度变化
    final bytes = image.planes.first.bytes;
    if (bytes.isEmpty) return;

    // 采样步长：每 12 个字节取 1 个，速度更快
    const step = 12;
    int sum = 0;
    int count = 0;
    for (int i = 0; i < bytes.length; i += step) {
      sum += bytes[i];
      count++;
    }
    final mean = sum / count;

    _ppg.add(mean.toDouble());
    _ts.add(now);
  }

  /// 计算 BPM 与 RMSSD（ms）。返回 (bpm, rmssd)；失败返回 null。
  (double, double)? _computeBpmAndRmssd(List<double> raw, List<int> tsMs) {
    if (raw.length != tsMs.length || raw.length < 20) return null;

    // 以时间戳计算采样时长
    final totalMs = (tsMs.last - tsMs.first).clamp(1, 1 << 30);
    final fs = raw.length / (totalMs / 1000.0); // Hz

    // 去均值 + 简单平滑（移动平均）
    final mean = raw.reduce((a, b) => a + b) / raw.length;
    final detrended = raw.map((v) => v - mean).toList();

    final smoothed = _movingAverage(detrended, window: 5);

    // 标准差
    final m = smoothed.reduce((a, b) => a + b) / smoothed.length;
    double varSum = 0;
    for (final v in smoothed) {
      final d = v - m;
      varSum += d * d;
    }
    final std = math.sqrt(varSum / smoothed.length);
    if (std <= 0) return null;

    final threshold = 0.5 * std;

    // 峰值检测（局部最大 + 阈值 + 最小间隔）
    final minIntervalMs = 300; // 200bpm 时 RR≈300ms
    final peaks = <int>[];
    int lastPeakT = -1 << 30;

    for (int i = 1; i < smoothed.length - 1; i++) {
      final v = smoothed[i];
      if (v < threshold) continue;
      if (v > smoothed[i - 1] && v > smoothed[i + 1]) {
        final t = tsMs[i];
        if (t - lastPeakT >= minIntervalMs) {
          peaks.add(t);
          lastPeakT = t;
        }
      }
    }

    if (peaks.length < 3) return null;

    // RR intervals
    final rr = <double>[];
    for (int i = 1; i < peaks.length; i++) {
      rr.add((peaks[i] - peaks[i - 1]).toDouble());
    }
    final rrMean = rr.reduce((a, b) => a + b) / rr.length;
    if (rrMean <= 0) return null;

    final bpm = 60000.0 / rrMean;

    // RMSSD
    if (rr.length < 2) return null;
    double diffSqSum = 0;
    for (int i = 1; i < rr.length; i++) {
      final d = rr[i] - rr[i - 1];
      diffSqSum += d * d;
    }
    final rmssd = math.sqrt(diffSqSum / (rr.length - 1));

    // 基本范围 sanity
    if (bpm.isNaN || bpm < 40 || bpm > 200) return null;
    return (double.parse(bpm.toStringAsFixed(1)), double.parse(rmssd.toStringAsFixed(1)));
  }

  List<double> _movingAverage(List<double> x, {required int window}) {
    if (window <= 1 || x.length <= 2) return x;
    final w = window.clamp(2, 15);
    final out = List<double>.filled(x.length, 0);
    double sum = 0;
    int q = 0;
    for (int i = 0; i < x.length; i++) {
      sum += x[i];
      q++;
      if (q > w) {
        sum -= x[i - w];
        q--;
      }
      out[i] = sum / q;
    }
    return out;
  }

  String _classifyZone({required double subjective, required double bpm, required double rmssd}) {
    // 经验阈值：可后续按用户个体基线/历史数据自适应
    final highArousal = subjective >= 7.0;
    final lowArousal = subjective <= 3.0;

    final hrHigh = bpm >= 105.0;
    final hrLow = bpm <= 85.0;

    final hrvLow = rmssd <= 25.0;
    final hrvHigh = rmssd >= 40.0;

    if (lowArousal && hrLow && hrvHigh) return '舒适区';
    if (highArousal && (hrHigh || hrvLow)) return '恐慌区';
    return '学习区';
  }

  String _zoneAdvice(String zone) {
    switch (zone) {
      case '舒适区':
        return '你现在比较放松，处于舒适区。可以尝试设定一个很小的“改变”行动（例如 5 分钟整理/一条消息/一次短散步），把挑战控制在可承受范围内。';
      case '学习区':
        return '你处于学习区：有压力但仍可应对。这通常是成长效率最高的区间。建议：把目标拆小（下一步是什么？），并设定一个 10~20 分钟可完成的行动。';
      case '恐慌区':
        return '你可能接近恐慌区：唤醒水平很高。优先做“降唤醒”：4-6 呼吸（吸 4 秒、呼 6 秒）× 3 轮；然后把任务缩小到“最小下一步”。必要时暂停并寻求支持。';
      default:
        return '';
    }
  }

  Widget _buildScale() {
    const labels = ['几乎没有', '有一点', '较明显', '非常明显'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '主观自评（简化 STAI-S6）',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        const Text(
          '请根据“此刻”的感受作答（1~4）。完成后再开始心率测量。',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        for (final it in _items) ...[
          Text(it.text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: List.generate(4, (idx) {
              final v = idx + 1;
              final selected = _answers[it.id] == v;
              return ChoiceChip(
                label: Text('${v}. ${labels[idx]}'),
                selected: selected,
                onSelected: (_) {
                  setState(() {
                    _answers[it.id] = v;
                    _error = null;
                  });
                },
              );
            }),
          ),
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 12),
        ],
        Row(
          children: [
            const Text('综合唤醒/压力分：', style: TextStyle(fontWeight: FontWeight.w600)),
            Text(
              _subjectiveScore0to10()?.toString() ?? '未完成',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 6),
            const Text('（0~10）', style: TextStyle(color: Colors.black54)),
          ],
        ),
      ],
    );
  }

  Widget _buildMeasureCard() {
    final subj = _subjectiveScore0to10();
    final canStart = !_measuring && subj != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '客观测量（摄像头PPG）',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        const Text(
          '用指腹轻盖住后置摄像头与闪光灯，保持稳定约 20 秒。',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        if (_camReady && _cam != null)
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: _cam!.value.aspectRatio,
              child: CameraPreview(_cam!),
            ),
          )
        else
          Container(
            height: 160,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0xFFF2F2F2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text('相机预览将在开始测量时初始化', style: TextStyle(color: Colors.black54)),
          ),
        const SizedBox(height: 12),
        if (_measuring) ...[
          LinearProgressIndicator(value: _progress),
          const SizedBox(height: 8),
          const Text('测量中…请保持手指稳定', style: TextStyle(color: Colors.black54)),
        ],
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: canStart ? _startMeasure : null,
                icon: const Icon(Icons.favorite_border),
                label: const Text('开始测量'),
              ),
            ),
            const SizedBox(width: 10),
            OutlinedButton(
              onPressed: _measuring ? _finishMeasure : null,
              child: const Text('提前结束'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildResultCard() {
    if (_error != null) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3F3),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.error_outline, color: Colors.redAccent),
            const SizedBox(width: 8),
            Expanded(child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
          ],
        ),
      );
    }
    if (_zone == null || _bpm == null || _rmssd == null) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7F7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('结果', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 12,
            runSpacing: 8,
            children: [
              Chip(label: Text('区间：$_zone')),
              Chip(label: Text('心率：${_bpm!.toStringAsFixed(1)} bpm')),
              Chip(label: Text('HRV：${_rmssd!.toStringAsFixed(1)} ms')),
              Chip(label: Text('主观：${_subjectiveScore0to10()!.toStringAsFixed(1)}/10')),
            ],
          ),
          const SizedBox(height: 10),
          Text(_advice ?? ''),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('返回发现之旅'),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('改变 · 心理自助'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _buildScale(),
          const SizedBox(height: 12),
          _buildMeasureCard(),
          const SizedBox(height: 12),
          _buildResultCard(),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F7F7),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              '免责声明：本功能用于情绪/压力自助与习惯养成参考，不用于医疗诊断。如出现持续强烈不适，请及时寻求专业帮助。',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ),
        ],
      ),
    );
  }
}
