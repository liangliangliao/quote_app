import 'db.dart';

/// DAO for 心理自助模块：保存每次测量结果（主观唤醒/压力 + 摄像头PPG心率/HRV + 舒适/学习/恐慌区判定）。
class SelfHelpDao {
  /// 插入一条测量记录。
  Future<int> insert({
    required double subjectiveScore,
    required double heartRateBpm,
    required double hrvRmssdMs,
    required String zone,
    int? timestampMs,
  }) async {
    final db = await AppDatabase.instance();
    final ts = timestampMs ?? DateTime.now().millisecondsSinceEpoch;
    return await db.insert('self_help_records', {
      'timestamp_ms': ts,
      'subjective_score': subjectiveScore,
      'heart_rate_bpm': heartRateBpm,
      'hrv_rmssd_ms': hrvRmssdMs,
      'zone': zone,
    });
  }

  /// 获取最近一条记录（如果没有则返回 null）。
  Future<Map<String, dynamic>?> latest() async {
    final db = await AppDatabase.instance();
    final rows = await db.query(
      'self_help_records',
      orderBy: 'timestamp_ms DESC, id DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// 获取最近 N 条记录（默认 20）。
  Future<List<Map<String, dynamic>>> latestN({int limit = 20}) async {
    final db = await AppDatabase.instance();
    final n = limit <= 0 ? 20 : limit;
    return await db.query(
      'self_help_records',
      orderBy: 'timestamp_ms DESC, id DESC',
      limit: n,
    );
  }
}
