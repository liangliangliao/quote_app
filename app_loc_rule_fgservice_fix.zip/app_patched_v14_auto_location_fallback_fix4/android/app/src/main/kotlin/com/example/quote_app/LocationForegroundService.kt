
package com.example.quote_app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import org.json.JSONObject
import android.database.sqlite.SQLiteDatabase
import kotlin.concurrent.thread

/**
 * 前台定位服务：只在“地点规则开关=开启”且捕获到解锁事件时按需启动。
 * 负责：快速获取当前位置 -> 比对数据库中的地点规则 -> 触发“愿景提醒”通知 -> 立刻自我停止。
 * 关键步骤写入日志表，便于排查。
 */
class LocationForegroundService : Service() {

  private val CHANNEL_ID = "geo_fg_v1"
  private val NOTIF_ID = 1999

  override fun onCreate() {
    super.onCreate()
    try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】onCreate：启动前台定位服务") } catch (_: Throwable) {}
    createChannel()
    val notif = NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setContentTitle("定位中…")
      .setContentText("正在获取当前位置以判断是否触发愿景提醒")
      .setOngoing(true)
      .build()
    startForeground(NOTIF_ID, notif)
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    thread(name = "geo-foreground") {
      runLogic()
    }
    return START_NOT_STICKY
  }

  private fun hasLocationPermission(): Boolean {
    val okFine = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val okCoarse = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    return okFine || okCoarse
  }

  private fun getCurrentLocationQuick(): Location? {
    if (!hasLocationPermission()) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】无定位权限，直接放弃") } catch (_: Throwable) {}
      return null
    }
    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager

    // A) Android 30+ 使用 getCurrentLocation 尝试一次性高精度
    if (Build.VERSION.SDK_INT >= 30) {
      try {
        var result: Location? = null
        val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
        val latch = java.util.concurrent.CountDownLatch(1)
        lm.getCurrentLocation(provider, null, mainExecutor) { loc ->
          result = loc
          latch.countDown()
        }
        latch.await(java.time.Duration.ofSeconds(15))
        if (result != null) {
          try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】getCurrentLocation 成功 acc=" + (result!!.accuracy)) } catch (_: Throwable) {}
          return result
        } else {
          try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】getCurrentLocation 超时/失败") } catch (_: Throwable) {}
        }
      } catch (_: Throwable) { }
    }

    // B) 单次请求（旧设备）
    try {
      var out: Location? = null
      val latch = java.util.concurrent.CountDownLatch(1)
      val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
      val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
          out = location
          latch.countDown()
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
      }
      @Suppress("DEPRECATION")
      val crit = Criteria().apply { accuracy = Criteria.ACCURACY_FINE; isSpeedRequired = false }
      @Suppress("DEPRECATION")
      lm.requestSingleUpdate(crit, listener, null)
      latch.await(15, java.util.concurrent.TimeUnit.SECONDS)
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      if (out != null) {
        try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】requestSingleUpdate 成功 acc=" + (out!!.accuracy)) } catch (_: Throwable) {}
        return out
      }
    } catch (_: Throwable) {}

    // C) 最近已知位置（兜底）
    try {
      val gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
      val net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
      val best = when {
        gps != null && net != null -> if ((gps.accuracy) <= (net.accuracy)) gps else net
        gps != null -> gps
        else -> net
      }
      if (best != null) {
        try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】采用最近已知位置 acc=" + best.accuracy) } catch (_: Throwable) {}
        return best
      }
    } catch (_: Throwable) {}

    return null
  }

  private fun runLogic() {
    try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】开始执行业务逻辑：读取地点规则并比对") } catch (_: Throwable) {}

    // 1) 取定位
    val loc = getCurrentLocationQuick()
    if (loc == null) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】定位失败，无法比对地点规则，直接结束") } catch (_: Throwable) {}
      stopSelfSafely()
      return
    }

    // 2) 读取 DB 的地点规则（vision_triggers 表，type='geo' 且 enabled=1）
    var db: SQLiteDatabase? = null
    var matched = false
    try {
      val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(this)
      if (contract == null || contract.dbPath == null) {
        try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】无法定位数据库文件") } catch (_: Throwable) {}
      } else {
        db = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
        val c = db!!.rawQuery("SELECT id, config, then_text FROM vision_triggers WHERE enabled=1 AND type='geo'", null)
        while (c.moveToNext()) {
          val id = c.getString(0) ?: ""
          val cfgStr = c.getString(1) ?: ""
          val thenText = c.getString(2) ?: "别忘了你的一件事！"
          try {
            val js = JSONObject(cfgStr)
            val lat = js.optDouble("lat", java.lang.Double.NaN)
            val lng = js.optDouble("lng", java.lang.Double.NaN)
            if (!lat.isNaN() && !lng.isNaN()) {
              val dist = FloatArray(1)
              android.location.Location.distanceBetween(loc.latitude, loc.longitude, lat, lng, dist)
              val meters = dist[0]
              try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】比对规则 id=" + id + "，距离=" + meters + "m") } catch (_: Throwable) {}
              if (meters <= 100.0f) {
                matched = true
                // 触发通知（标题统一“愿景提醒”）
                try {
                  NotifyHelper.send(this, /*id*/2000, "愿景提醒", thenText, null, "vision_focus", null)
                  com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】命中地点规则（≤100m），已发送提醒")
                } catch (_: Throwable) {}
                break
              }
            }
          } catch (_: Throwable) {}
        }
        c.close()
      }
    } catch (_: Throwable) {
    } finally {
      try { db?.close() } catch (_: Throwable) {}
    }

    if (!matched) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】未命中任何地点规则（>100m 或未配置），不发送通知") } catch (_: Throwable) {}
    }

    stopSelfSafely()
  }

  private fun stopSelfSafely() {
    try { stopForeground(true) } catch (_: Throwable) {}
    try { stopSelf() } catch (_: Throwable) {}
    try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】业务完成，服务已停止") } catch (_: Throwable) {}
  }

  private fun createChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val ch = NotificationChannel(CHANNEL_ID, "地点定位执行", NotificationManager.IMPORTANCE_LOW)
      nm.createNotificationChannel(ch)
    }
  }

  override fun onDestroy() {
    try { com.example.quote_app.data.DbRepo.log(this, null, "【前台定位】onDestroy") } catch (_: Throwable) {}
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null
}
