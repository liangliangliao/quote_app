package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver：仅作为轻量入口，接收解锁广播，然后触发后台 UnlockWorker。
 * 具体业务逻辑（查库、开关、冷却时间以及发送通知）全部在 UnlockWorker 中完成。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val act = intent?.action ?: "null"
    // 只处理真正的解锁事件：USER_PRESENT / USER_UNLOCKED，其它广播直接略过，避免误触发
    if (act != Intent.ACTION_USER_PRESENT && act != Intent.ACTION_USER_UNLOCKED) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 收到非解锁广播 action=" + act + "，本次忽略（回包：SKIP_NOT_USER_PRESENT）")
      } catch (_: Throwable) {}
      return
    }

    // 记录收到解锁事件
    try {
      DbRepo.log(context, null, "【解锁后台】UnlockReceiver 收到解锁广播 action=" + act + "，准备触发后台 UnlockWorker（回包：OK）")
    } catch (_: Throwable) {}

    // 记录一次“最近解锁时间”，并做 3 秒去重
    try {
      val sp = context.applicationContext.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
      val now = System.currentTimeMillis()
      val lastTrig = sp.getLong("last_unlock_trigger_ts", 0L)
      if (lastTrig > 0 && (now - lastTrig) < 3000L) {
        try { DbRepo.log(context, null, "【解锁后台】3秒内已触发过解锁提醒，屏蔽本次重复（回包：SKIP_DUP）") } catch (_: Throwable) {}
        return
      }
      sp.edit().putLong("last_unlock_trigger_ts", now).putLong("last_user_present_ts", now).apply()
    } catch (_: Throwable) {}

    // 轻量 Toast 提示（仅在进程仍存活时可见）
    try {
      Toast.makeText(context.applicationContext, "已捕获解锁事件，后台正在准备解锁提醒", Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) {}

    
    // 读取配置：地点规则是否开启（configs.location_rule_enabled）——优先于其它开关检查
    var geoEnabled = false
    try {
      val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
      val path = contract?.dbPath
      if (path != null) {
        val db = android.database.sqlite.SQLiteDatabase.openDatabase(path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
        val c = db.rawQuery("SELECT location_rule_enabled FROM configs LIMIT 1", null)
        if (c.moveToFirst()) {
          val v = try { c.getInt(0) } catch (_: Throwable) { 0 }
          geoEnabled = (v == 1)
        }
        c.close()
        db.close()
      }
    } catch (_: Throwable) {}

    if (!geoEnabled) {
      try { DbRepo.log(context, null, "【解锁入口】地点规则开关关闭，直接返回（不进入后台/服务）") } catch (_: Throwable) {}
      return
    }

    // 启动前台定位服务以快速判定是否命中地点规则；其内部会自行发送通知并停止
    try {
      val svc = Intent(context.applicationContext, LocationForegroundService::class.java)
      androidx.core.content.ContextCompat.startForegroundService(context.applicationContext, svc)
      DbRepo.log(context, null, "【解锁入口】已启动前台定位服务 LocationForegroundService")
    } catch (th: Throwable) {
      try { DbRepo.log(context, null, "【解锁入口】启动前台定位服务失败：" + th.message) } catch (_: Throwable) {}
    }

    // 仍保留原后台轻提示逻辑（如有），但不再负责地点规则
    try {
      UnlockWorker.trigger(context.applicationContext)
    } catch (_: Throwable) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 触发 UnlockWorker 失败（回包：FAIL）")
      } catch (_: Throwable) {}
    }

    try {
      UnlockWorker.trigger(context.applicationContext)
    } catch (_: Throwable) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 触发 UnlockWorker 失败（回包：FAIL）")
      } catch (_: Throwable) {}
    }
  }
}
