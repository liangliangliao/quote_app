package com.example.quote_app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.quote_app.data.DbRepo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 设备管理员 Receiver：
 * - 用于在系统层面监听解锁成功事件（onPasswordSucceeded），
 *   以弥补高版本 Android / 厂商 ROM 对 USER_PRESENT 等广播的限制。
 * - 需要用户在系统「设备管理员」设置中手动启用本应用。
 */
class MyDeviceAdminReceiver : DeviceAdminReceiver() {

    private fun logWithTime(ctx: Context, msg: String) {
        try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
            val now = fmt.format(Date())
            DbRepo.log(ctx.applicationContext, null, "[$now] $msg")
        } catch (_: Throwable) {
        }
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        logWithTime(context, "[DeviceAdmin] 设备管理员已启用")
        try {
            Toast.makeText(context, "已启用解锁监听（设备管理员）", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
        }
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        logWithTime(context, "[DeviceAdmin] 设备管理员已禁用")
        try {
            Toast.makeText(context, "已关闭解锁监听（设备管理员）", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
        }
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
        val appCtx = context.applicationContext
        logWithTime(appCtx, "[DeviceAdmin] 检测到解锁成功事件，准备触发解锁业务链路")

        // 这里复用 UnlockReceiver 里同样的“解锁提示 + 透明 Activity 入口”逻辑：
        // 1. 立刻给出一个简短 Toast 反馈
        try {
            Toast.makeText(appCtx, "已解锁（设备管理员）：轻提醒已就绪", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
        }

        // 2. 启动透明 Activity，在其中统一执行“地点规则提醒 + 解锁轻提醒”
        try {
            val act = Intent(appCtx, FgKickActivity::class.java)
            act.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appCtx.startActivity(act)
            logWithTime(appCtx, "[DeviceAdmin] 已通过透明 Activity 触发解锁业务链路")
        } catch (t: Throwable) {
            logWithTime(appCtx, "[DeviceAdmin] 启动透明 Activity 异常：" + (t.message ?: "unknown"))
        }
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        logWithTime(context.applicationContext, "[DeviceAdmin] 检测到一次解锁密码失败尝试")
    }
}
