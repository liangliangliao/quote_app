import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 默认：Baidu SDK（高精度）→ 失败再系统定位（高精度）
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 1) Baidu SDK
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      }
    } catch (_) {}
    // 2) 系统定位（高精度）
    try {
      final sys = await getCurrentPositionSmart();
      if (sys != null) {
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      }
    } catch (_) {}
    return null;
  }

  /// 系统定位（尽量高精度）。
  static Future<Position?> getCurrentPositionSmart() async {
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        await DLog.w('LocationService', '【定位】系统定位服务未开启');
        return null;
      }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        await DLog.w('LocationService', '【定位】未授予定位权限');
        return null;
      }
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
      return pos;
    } catch (e) {
      await DLog.e('LocationService', '【定位】系统定位异常：$e');
      return null;
    }
  }

  /// 通过原生（Baidu SDK）获取一次位置（可能为 null）。
  static Future<Position?> _baiduSdkLocationOnce() async {
    try {
      final ret = await _sysCh.invokeMethod('getBaiduLocationOnce');
      if (ret is Map) {
        final lat = (ret['lat'] as num?)?.toDouble();
        final lng = (ret['lng'] as num?)?.toDouble();
        final acc = (ret['acc'] as num?)?.toDouble() ?? 0.0;
        if (lat != null && lng != null) {
          return Position(
            latitude: lat, longitude: lng, timestamp: DateTime.now(),
            accuracy: acc, altitude: 0, heading: 0, speed: 0,
            speedAccuracy: 0, altitudeAccuracy: 0, headingAccuracy: 0,
          );
        }
      }
    } catch (e) {
      await DLog.w('LocationService', '【定位】Baidu SDK 失败：$e');
    }
    return null;
  }

  /// 百度逆地理：记录附近地标（不影响主流程）。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2';
      if (effectiveAk.isEmpty) return;

      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?ak=${Uri.encodeComponent(effectiveAk)}&coordtype=wgs84ll&extensions_poi=1&radius=600&location=${pos.latitude},${pos.longitude}'
      );
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && (data['status'] == 0 || data['status'] == '0')) {
          final result = data['result'];
          if (result is Map) {
            final pois = result['pois'];
            if (pois is List && pois.isNotEmpty) {
              final first = pois.first;
              String? name; int? distance;
              if (first is Map) {
                final n = first['name']; final d = first['distance'];
                if (n is String) name = n; if (d is int) distance = d;
              }
              if (name != null) {
                final suffix = distance != null ? '（约${distance}米）' : '';
                await DLog.i('LocationService', '附近地标：' + name + suffix);
              }
            }
          }
        }
      }
    } catch (_) {}
  }
}
