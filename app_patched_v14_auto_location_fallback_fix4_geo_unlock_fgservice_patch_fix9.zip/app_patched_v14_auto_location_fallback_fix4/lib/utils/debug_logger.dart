import 'package:sqflite/sqflite.dart';
import '../data/db.dart';

/// 统一的中文日志写入工具（最小实现，保持兼容已有调用）。
class DLog {
  static Future<void> i(String tag, String msg) async {
    await _write('信息', tag, msg);
  }
  static Future<void> w(String tag, String msg) async {
    await _write('警告', tag, msg);
  }
  static Future<void> e(String tag, String msg) async {
    await _write('错误', tag, msg);
  }

  static Future<void> _write(String level, String tag, String msg) async {
    final line = '【$level】[${DateTime.now().toIso8601String()}][$tag] $msg';
    // ignore: avoid_print
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    } catch (_) {}
  }
}
