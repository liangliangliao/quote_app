class NotifyPrefs {
  // 是否启用原生兜底（AlarmClock+FGS）。默认关闭，先把“正常路径（Dart）”跑通。
  static const bool enableNativeFallback = false;
  // 是否启用 WorkManager 分钟级兜底。默认关闭，先确保正常链路稳定。
  static const bool enableWorkBackup = false;
}
