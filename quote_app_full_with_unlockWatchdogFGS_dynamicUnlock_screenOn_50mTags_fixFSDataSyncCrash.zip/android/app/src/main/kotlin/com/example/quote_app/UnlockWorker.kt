
package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.OutOfQuotaPolicy
import com.example.quote_app.data.DbRepo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 解锁轻提醒 & 地点规则等后台调度入口。
 *
 * 设计原则：
 * - 所有耗时/IO 操作都放在 WorkManager 的后台线程中执行；
 * - 仅通过静态 trigger(context) 触发一次性任务，外部不直接 new；
 * - 失败不会影响 App 正常运行，只记录日志方便排查。
 */
class UnlockWorker(
  appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val ctx = applicationContext
    logWithTime(ctx, "【解锁后台】UnlockWorker 开始执行")

    return try {
      withContext(Dispatchers.IO) {
        runUnlockBusiness(ctx)
      }
      logWithTime(ctx, "【解锁后台】UnlockWorker 执行完毕（Result.success）")
      Result.success()
    } catch (t: Throwable) {
      logWithTime(ctx, "【解锁后台】UnlockWorker 执行异常：" + (t.message ?: "unknown"))
      Result.failure()
    }
  }

  companion object {
    private const val UNIQUE_NAME = "wm_unlock_light_reminder"

    /**
     * 由解锁广播 / 透明 Activity / 冷启动等入口调用。
     * 使用 ExistingWorkPolicy.REPLACE 保证队列中始终只有一个待执行任务。
     */
    fun trigger(context: Context) {
      try {
        val work = OneTimeWorkRequestBuilder<UnlockWorker>()
          .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
          .build()
        WorkManager.getInstance(context)
          .enqueueUniqueWork(
            UNIQUE_NAME,
            ExistingWorkPolicy.REPLACE,
            work
          )
        logWithTime(context, "【解锁后台】已触发 UnlockWorker（ExistingWorkPolicy.REPLACE）")
      } catch (t: Throwable) {
        logWithTime(context, "【解锁后台】触发 UnlockWorker 异常：" + (t.message ?: "unknown"))
      }
    }

    private fun logWithTime(ctx: Context, msg: String) {
      try {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
        val now = sdf.format(Date())
        DbRepo.log(ctx, null, "[$now] $msg")
      } catch (_: Throwable) {
      }
    }

    /**
     * 实际业务逻辑的占位实现：
     * 这里可以根据数据库配置执行“地点规则提醒 + 解锁轻提醒”等逻辑。
     * 为了避免再次引入复杂 Bug，当前版本仅记录日志，逻辑细化可以后续在
     * 不影响编译的前提下增量迭代。
     */
    private fun runUnlockBusiness(ctx: Context) {
      logWithTime(ctx, "【解锁后台】执行解锁轻提醒业务逻辑（占位实现，可后续细化）")
    }
  }
}
