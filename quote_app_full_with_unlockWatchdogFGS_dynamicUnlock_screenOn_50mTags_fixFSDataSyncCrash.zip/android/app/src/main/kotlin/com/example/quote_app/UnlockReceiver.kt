package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.Toast
import android.app.KeyguardManager
import android.os.Build
import com.example.quote_app.data.DbRepo

/**
 * 监听解锁广播，在解锁瞬间：
 * 1. 立刻弹出 Toast，提示“屏幕解锁事件已被监听，轻提醒已就绪”；
 * 2. 启动透明 Activity（FgKickActivity），在其中统一调度“地点规则提醒 + 解锁轻提醒”业务逻辑；
 * 3. 做 3 秒去抖，避免重复触发。
 */
class UnlockReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        val appCtx = context.applicationContext

        // 只处理与“用户已可见/已解锁”相关的广播：
        // - USER_PRESENT / USER_UNLOCKED：标准解锁路径
        // - SCREEN_ON：某些机型在“自动锁定有延迟”或“无锁屏”的情况下，只会收到 SCREEN_ON，
        //              此时需要结合 KeyguardManager 判断当前是否已经解锁
        val isUnlockEvent = when (action) {
            Intent.ACTION_USER_PRESENT,
            Intent.ACTION_USER_UNLOCKED -> true
            Intent.ACTION_SCREEN_ON -> {
                try {
                    val km = appCtx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                    if (km != null) {
                        val locked = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            km.isDeviceLocked
                        } else {
                            km.inKeyguardRestrictedInputMode()
                        }
                        // 屏幕亮起且当前未处于锁屏限制状态，可以视为“用户已可见”
                        !locked
                    } else {
                        false
                    }
                } catch (_: Throwable) {
                    false
                }
            }
            else -> false
        }

        if (!isUnlockEvent) {
            return
        }

        // 走到这里，说明已经判定为一次“有效的解锁事件”

        // 简单去抖：3 秒内只处理一次
        val prefs = appCtx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
        val nowRt = SystemClock.elapsedRealtime()
        val lastRt = prefs.getLong("last_unlock_broadcast_rt", 0L)
        if (lastRt > 0L && (nowRt - lastRt) < 3000L) {
            return
        }
        prefs.edit()
            .putLong("last_unlock_broadcast_rt", nowRt)
            .putLong("last_unlock_time_rt", nowRt)
            .putLong("last_unlock_time", System.currentTimeMillis())
            .apply()

        // 立刻给出 Toast 反馈（无论后续逻辑是否成功，都先提示给用户）
        try {
            Toast.makeText(appCtx, "已解锁：屏幕事件已被监听，轻提醒已就绪", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
        }

        // 启动透明 Activity，在其中统一执行“地点规则提醒 + 解锁轻提醒”
        try {
            val act = Intent(appCtx, FgKickActivity::class.java)
            act.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appCtx.startActivity(act)
        } catch (t: Throwable) {
            try {
                DbRepo.log(appCtx, null, "【解锁广播】启动透明 Activity 异常：" + (t.message ?: "unknown"))
            } catch (_: Throwable) {
            }
        }

        // 记录一条总日志，方便在日志表中查看解锁事件是否被捕获
        try {
            DbRepo.log(appCtx, null, "【解锁广播】$action 收到并处理：已弹出 Toast 并启动透明 Activity")
        } catch (_: Throwable) {
        }
    }
}
