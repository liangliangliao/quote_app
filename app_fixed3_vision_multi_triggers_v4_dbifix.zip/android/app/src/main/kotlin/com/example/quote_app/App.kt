package com.example.quote_app

import android.app.Application
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * Application (Flutter V2 embedding).
 * 这里增加了一些轻量级的原生初始化逻辑：
 * 1）启动时调度 GeoWorker，保证 geo 触发规则生效；
 * 2）在 App 启动时做一次 screen_unlock 规则检查，必要时推送一条温和提醒。
 */
class App : Application() {
  override fun onCreate() {
    super.onCreate()

    // 1. 启动应用时就调度一次 GeoWorker（之前只在开机/升级时调度，不够及时）
    try {
      DbRepo.log(this, null, "[App] onCreate: schedule GeoWorker")
      GeoWorker.schedule(this)
    } catch (_: Throwable) {
      // 忽略调度失败，避免影响启动
    }

    // 2. 启动时做一次 screen_unlock 规则检查
    try {
      maybeSendUnlockReminderOnAppStart()
    } catch (_: Throwable) {
      // 忽略异常
    }
  }

  /**
   * 在 App 启动（包括点击图标从前台/后台切回）时，如果存在启用的
   * screen_unlock 规则，则发送一条温和的愿景提醒。
   */
  private fun maybeSendUnlockReminderOnAppStart() {
    try {
      val contract = DbInspector.loadOrLightScan(this)
      if (contract == null) {
        DbRepo.log(this, null, "[App] unlock-check: no contract")
        return
      }
      val path = contract.dbPath
      if (path == null) {
        DbRepo.log(this, null, "[App] unlock-check: no dbPath")
        return
      }

      val db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY)
      val c = db.rawQuery(
        "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
        null
      )
      val hasTrigger = c.moveToFirst()
      c.close()
      db.close()

      DbRepo.log(this, null, "[App] unlock-check: hasTrigger=$hasTrigger")
      if (hasTrigger) {
        NotifyHelper.send(this, 2000, "愿景提醒", "别忘了你的一件事！", null)
      }
    } catch (t: Throwable) {
      DbRepo.log(this, null, "[App] unlock-check error: ${t.javaClass.simpleName}")
    }
  }
}

