import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';

import '../data/db.dart';
import 'diary_dao.dart';
import 'tag_picker_page.dart';
import 'weather.dart';

class EntryEditorPage extends StatefulWidget {
  final int notebookId;
  final int? entryId;
  const EntryEditorPage({super.key, required this.notebookId, this.entryId});

  @override
  State<EntryEditorPage> createState() => _EntryEditorPageState();
}

class _EntryEditorPageState extends State<EntryEditorPage> {
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy年MM月dd日 HH:mm');
  final _textCtrl = TextEditingController();

  int _entryId = 0;
  DateTime _time = DateTime.now();
  int? _weatherCode;
  String? _moodName;
  String? _moodIcon;
  bool _starred = false;

  bool _dirty = false;

  String? _bgPath;
  double _bgOpacity = 0.25;

  final List<int> _tagIds = [];
  final Map<int, String> _tagNameById = {};

  @override
  void initState() {
    super.initState();
    _bootstrap();
    _textCtrl.addListener(() {
      if (!_dirty) setState(() => _dirty = true);
    });
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    super.dispose();
  }

  Future<void> _bootstrap() async {
    // config: diary bg image & opacity
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        final img = rows.first['diary_bg_image'];
        _bgPath = img == null ? null : img.toString();
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
    } catch (_) {}

    // recent mood from emotions
    try {
      final rows = await db.query('emotions', orderBy: 'inserted_at DESC', limit: 1);
      if (rows.isNotEmpty) {
        _moodName = (rows.first['emoji_name'] ?? '').toString();
        _moodIcon = (rows.first['emoji_char'] ?? '').toString();
      }
    } catch (_) {}

    await _dao.ensureSchema();

    if (widget.entryId != null) {
      final e = await _dao.getEntry(widget.entryId!);
      if (e != null) {
        _entryId = e.id;
        _time = DateTime.fromMillisecondsSinceEpoch(e.entryTime);
        _weatherCode = e.weatherCode;
        _moodName = e.moodName ?? _moodName;
        _moodIcon = e.moodIcon ?? _moodIcon;
        _textCtrl.text = e.content;
        _starred = (e.starred == 1);

        final tags = await _dao.tagsForEntry(e.id);
        _tagIds
          ..clear()
          ..addAll(tags.map((t) => t.id));
        for (final t in tags) {
          _tagNameById[t.id] = t.name;
        }
      }
    }

    // If no entryId, keep defaults but build tag name map for future display
    await _refreshTagNameMap();

    if (mounted) setState(() {});
  }

  Future<void> _refreshTagNameMap() async {
    try {
      final all = await _dao.listTags();
      for (final t in all) {
        _tagNameById[t.id] = t.name;
      }
    } catch (_) {}
  }

  String _preview(String content) {
    final t = content.trim();
    if (t.isEmpty) return '（空白日记）';
    final first = t.split(RegExp(r'\r?\n')).first.trim();
    if (first.isNotEmpty) return first.length > 50 ? first.substring(0, 50) : first;
    return t.length > 50 ? t.substring(0, 50) : t;
  }

  Future<void> _save() async {
    if (!_dirty) return;

    final w = weatherByCode(_weatherCode);
    final e = DiaryEntry(
      id: _entryId,
      notebookId: widget.notebookId,
      entryTime: _time.millisecondsSinceEpoch,
      weatherCode: _weatherCode,
      weatherName: _weatherCode == null ? null : w.name,
      moodName: _moodName,
      moodIcon: _moodIcon,
      content: _textCtrl.text,
      preview: _preview(_textCtrl.text),
      starred: _starred ? 1 : 0,
    );
    final id = await _dao.upsertEntry(e);
    await _dao.touchNotebook(widget.notebookId);
    await _dao.setTagsForEntry(id, _tagIds);

    if (!mounted) return;
    Navigator.pop(context, id);
  }

  Future<void> _cancel() async {
    if (!_dirty) {
      Navigator.pop(context);
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('放弃未保存内容？'),
        content: const Text('你有修改尚未保存，确定要退出吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('继续编辑')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('放弃')),
        ],
      ),
    );
    if (ok == true && mounted) Navigator.pop(context);
  }

  Future<void> _pickTime() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _time,
      firstDate: DateTime(2000, 1, 1),
      lastDate: DateTime(DateTime.now().year + 1),
    );
    if (d == null) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_time));
    if (t == null) return;
    setState(() {
      _time = DateTime(d.year, d.month, d.day, t.hour, t.minute);
      _dirty = true;
    });
  }

  Future<void> _pickTags() async {
    final res = await Navigator.push<List<int>?>(
      context,
      MaterialPageRoute(builder: (_) => TagPickerPage(dao: _dao, initialSelected: _tagIds)),
    );
    if (res == null) return;
    setState(() {
      _tagIds
        ..clear()
        ..addAll(res);
      _dirty = true;
    });
    await _refreshTagNameMap();
    if (mounted) setState(() {});
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(
      fit: StackFit.expand,
      children: [
        Opacity(opacity: _bgOpacity.clamp(0.0, 1.0), child: Image.file(f, fit: BoxFit.cover)),
        child,
      ],
    );
  }

  @override
  
  Future<void> _insertImage() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;
    final sel = _textCtrl.selection;
    final insertText = "\n[图片] " + path + "\n";
    final base = _textCtrl.text;
    final start = sel.start < 0 ? base.length : sel.start;
    final end = sel.end < 0 ? start : sel.end;
    final newText = base.replaceRange(start, end, insertText);
    setState(() { _textCtrl.text = newText; _textCtrl.selection = TextSelection.collapsed(offset: start + insertText.length); _dirty = true; });
  }

  Future<void> _insertAudio() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;
    final sel = _textCtrl.selection;
    final insertText = "\n[语音] " + path + "\n";
    final base = _textCtrl.text;
    final start = sel.start < 0 ? base.length : sel.start;
    final end = sel.end < 0 ? start : sel.end;
    final newText = base.replaceRange(start, end, insertText);
    setState(() { _textCtrl.text = newText; _textCtrl.selection = TextSelection.collapsed(offset: start + insertText.length); _dirty = true; });
  }
Widget build(BuildContext context) {
    final w = weatherByCode(_weatherCode);

    return _bgWrap(Scaffold(extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0,
        title: const Text('写日记'),
        actions: [
          IconButton(onPressed: _dirty ? _cancel : null, icon: const Icon(Icons.close)),
          IconButton(onPressed: _dirty ? _save : null, icon: const Icon(Icons.check)),
        ],
      ),
      body: SafeArea(child:
        Column(
          children: [
            Material(
              elevation: 1,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                child: Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: _pickTime,
                        child: Row(
                          children: [
                            const Icon(Icons.schedule, size: 18),
                            const SizedBox(width: 6),
                            Text(_fmt.format(_time)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    DropdownButton<int>(
                      value: _weatherCode,
                      hint: const Text('天气'),
                      items: weatherOptions
                          .map(
                            (o) => DropdownMenuItem(
                              value: o.code,
                              child: Row(
                                children: [
                                  Icon(o.icon, size: 18),
                                  const SizedBox(width: 6),
                                  Text(o.name),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setState(() {
                        _weatherCode = v;
                        _dirty = true;
                      }),
                    ),
                    const SizedBox(width: 12),
                    if (_moodIcon != null && _moodIcon!.isNotEmpty) Text(_moodIcon!, style: const TextStyle(fontSize: 18)),
                    if (_moodName != null && _moodName!.isNotEmpty) ...[
                      const SizedBox(width: 4),
                      Text(_moodName!),
                    ],
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: () => setState(() {
                        _starred = !_starred;
                        _dirty = true;
                      }),
                      icon: Icon(_starred ? Icons.star : Icons.star_border),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  controller: _textCtrl,
                  maxLines: null,
                  expands: true,
                  autofocus: true,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration.collapsed(hintText: '写点什么……'),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: _tagIds
                          .map((id) => Chip(
                                label: Text(_tagNameById[id] ?? '标签#$id'),
                              ))
                          .toList(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(tooltip:'插入语音', onPressed: _insertAudio, icon: const Icon(Icons.mic_none)),
                  IconButton(tooltip:'插入图片', onPressed: _insertImage, icon: const Icon(Icons.image_outlined)),
                  OutlinedButton.icon(
                    onPressed: _pickTags,
                    icon: const Icon(Icons.label_outline),
                    label: const Text('标签'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
