import 'package:flutter/material.dart';

/// Movie overview widget:
///
/// By default it shows a box that is about 3 lines tall. If the text is
/// longer than the box, users can scroll inside the box to read the rest.
///
/// This avoids truncation (ellipsis) while also preventing very long
/// overviews from taking over the whole list item.
class MovieOverviewBox extends StatelessWidget {
  final String text;
  final int maxLines;
  final TextStyle style;

  const MovieOverviewBox({
    super.key,
    required this.text,
    this.maxLines = 3,
    this.style = const TextStyle(fontSize: 13, color: Colors.black54, height: 1.35),
  });

  @override
  Widget build(BuildContext context) {
    final double lineHeight = (style.fontSize ?? 13) * (style.height ?? 1.35);
    final double boxHeight = lineHeight * maxLines;

    final String content = text.trim().isEmpty ? '暂无简介' : text;
    return SizedBox(
      height: boxHeight,
      child: ClipRect(
        child: Scrollbar(
          // Let the thumb appear while scrolling, but don't force it always on.
          child: SingleChildScrollView(
            physics: const ClampingScrollPhysics(),
            child: Text(content, style: style),
          ),
        ),
      ),
    );
  }
}
