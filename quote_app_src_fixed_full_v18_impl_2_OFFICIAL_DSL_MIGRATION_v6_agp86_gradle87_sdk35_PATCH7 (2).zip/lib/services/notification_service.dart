
import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/material.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  static Future<void> init() async {
    if (_inited) return;
    const android = AndroidInitializationSettings('@android:drawable/sym_def_app_icon');
    const ios = DarwinInitializationSettings();
    const settings = InitializationSettings(android: android, iOS: ios);
    await _plugin.initialize(settings);
    // Android 13+ runtime permission
    await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
    _inited = true;
    // Android 13+ runtime permission
    try {
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestPermission();
    } catch (_) {}
    
  }

  static Future<void> show({
    required int id,
    required String title,
    required String body,
    String? largeIconPath,
  }) async {
    await init();
    final androidDetails = AndroidNotificationDetails(
      'quotes_channel',
      '名言通知',
      channelDescription: '任务触发时展示名言',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: const BigTextStyleInformation(''),
      largeIcon: (largeIconPath!=null && largeIconPath.isNotEmpty && File(largeIconPath).existsSync())
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails, iOS: const DarwinNotificationDetails());
    await _plugin.show(id, title, body, details);
  }
}
