
import 'dart:io';
import 'package:flutter/services.dart';
import '../utils/debug_logger.dart';

class PermHelper {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');
  static bool? _lastHasExact;
  static DateTime? _lastExactCheckedAt;

  /// 是否拥有“精确闹钟”权限（带缓存与容错，避免偶发抖动）
  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod('hasExactAlarmPermission');
      return ok == true;
    } catch (e) {
      // Fallback to the scheduler channel used widely in the app
      try {
        const MethodChannel ch2 = MethodChannel('native.scheduler');
        final ok2 = await ch2.invokeMethod('canScheduleExact');
        return ok2 == true;
      } catch (_) {
        DLog.w('platform/perm_helper.dart', 'both /sys and native.scheduler unavailable, treat as no exact perm');
        return false;
      }
    }
  }
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      _lastExactCheckedAt = DateTime.now();
      _lastHasExact = ok ?? false;
      return _lastHasExact!;
    } catch (e) {
      // 如果后台 isolate 缺少此 MethodChannel，实现可能会抛 MissingPluginException。
      // 在这种情况下按无精准权限处理，并记录警告日志。
      final msg = e.toString();
      if (msg.contains('MissingPluginException')) {
        await DLog.w('platform/perm_helper.dart', 'catch: MissingPluginException: '+msg+'，视为无精准权限');
      } else {
        await DLog.e('platform/perm_helper.dart', 'catch: ' + msg);
      }
      return false;
    }
  }

  /// 跳转系统界面申请“精确闹钟”权限（Android 12+）
  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } catch (e) {
      try {
        const MethodChannel ch2 = MethodChannel('native.scheduler');
        await ch2.invokeMethod('requestExactPermission');
      } catch (_) {
        DLog.w('platform/perm_helper.dart', 'both /sys and native.scheduler unavailable when requesting exact alarm perm');
      }
    }
  } catch (e) {
      DLog.e('platform/perm_helper.dart', 'requestExactAlarmPermission catch: ' + e.toString());
    }
  }
}
