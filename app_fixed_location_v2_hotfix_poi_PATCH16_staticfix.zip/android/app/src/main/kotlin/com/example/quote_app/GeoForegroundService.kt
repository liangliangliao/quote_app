package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.quote_app.data.DbRepo
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread
import kotlin.math.*

class GeoForegroundService : Service() {

  private val CHANNEL_ID = "geo_fg_channel"
  private val NOTIF_ID = 7771001

  override fun onBind(intent: Intent?) = null

  override fun onCreate() {
    super.onCreate()
    try { logWithTime(this, "【前台服务-地点规则】onCreate") } catch (_: Throwable) {}
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // 第一时间启动前台
    
        // 弹出 toast 提示用户正在进行地点提醒
        try {
            Handler(Looper.getMainLooper()).post {
                try { android.widget.Toast.makeText(this@GeoForegroundService, "正在执行地点提醒...", android.widget.Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    startForeground(NOTIF_ID, buildOngoingNotification("正在获取位置..."))
    // 记录启动前台服务的日志
    try { logWithTime(this, "【前台服务-地点规则】已调用 startForeground，开始在前台运行") } catch (_: Throwable) {}
    thread(name = "geo-fg-exec") {
      try {
        executeCore()
      } catch (t: Throwable) {
        try { logWithTime(this, "【前台服务-地点规则】执行失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      } finally {
        try {
          @Suppress("DEPRECATION")
          stopForeground(true)
          stopSelf()
          // 记录销毁前台服务的日志
          try { logWithTime(this, "【前台服务-地点规则】前台服务已停止并销毁") } catch (_: Throwable) {}
        } catch (_: Throwable) {}
      }
    }
    return START_NOT_STICKY
  }

  private fun buildOngoingNotification(text: String): Notification {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val ch = NotificationChannel(CHANNEL_ID, "地点前台服务", NotificationManager.IMPORTANCE_LOW)
      nm.createNotificationChannel(ch)
    }
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("愿景提醒")
      .setContentText(text)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setOngoing(true)
      .build()
  }

  private fun executeCore() {
    val ctx = this

    // 1) 配置开关
    if (!isLocationRulesEnabled(ctx)) {
      try { logWithTime(ctx, "【前台服务-地点规则】开关=关闭，直接返回") } catch (_: Throwable) {}
      return
    }

    // 2) 读取启用的最近一条地点规则
    val target = queryFirstGeoTarget(ctx)
    if (target == null) {
      try { logWithTime(ctx, "【前台服务-地点规则】未找到启用的地点规则，返回") } catch (_: Throwable) {}
      return
    }
    val (tLat, tLng) = target

    // 3) 获取当前位置（系统高精度≤30m）
    var loc: Location? = runCatching { obtainHighAccuracyLocation(ctx, 30.0, 10_000L) }.getOrNull()
    if (loc != null) {
      try { logWithTime(ctx, "【前台服务-地点规则】系统定位成功 acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
    }

    // 4) 失败则百度定位
    if (loc == null) {
      val ak = getBaiduAk(ctx)
      loc = runCatching { obtainBaiduLocation(ctx, ak, 30.0, 10_000L) }.getOrNull()
      if (loc != null) {
        try { logWithTime(ctx, "【前台服务-地点规则】百度定位成功 acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
      } else {
        try { logWithTime(ctx, "【前台服务-地点规则】百度定位失败或不可用") } catch (_: Throwable) {}
      }
    }

    // 5) 再失败则最近已知位置
    if (loc == null) {
      try {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull {
          try { lm.getLastKnownLocation(it) } catch (_: Throwable) { null }
        }.maxByOrNull { it.time }
        loc = last
        if (loc != null) try { logWithTime(ctx, "【前台服务-地点规则】使用最近已知位置 acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
      } catch (_: Throwable) {}
    }

    if (loc == null) {
      try { logWithTime(ctx, "【前台服务-地点规则】无法获取位置，返回") } catch (_: Throwable) {}
      return
    }

    // 6) 比对距离并通知
    val d = distanceMeters(loc.latitude, loc.longitude, tLat, tLng)
    try { logWithTime(ctx, "【前台服务-地点规则】当前位置(${ '$' }{loc.latitude},${ '$' }{loc.longitude}) 到目标(${ '$' }tLat,${ '$' }tLng) 距离=${ '$' }d m") } catch (_: Throwable) {}
    if (d <= 100.0) {
      try {
        NotifyHelper.sendUnlockReminder(ctx, 901001, "愿景提醒", "你已到达目标地点，别忘了今天的一件事。")
        logWithTime(ctx, "【前台服务-地点规则】命中≤100m，已发送愿景提醒通知")
      } catch (_: Throwable) {}
    } else {
      try { logWithTime(ctx, "【前台服务-地点规则】未命中>100m，不发送") } catch (_: Throwable) {}
    }
  }

  /**
   * 写入包含时间戳的日志。所有地点规则前台服务的日志都通过此方法统一前缀当前时间，
   * 便于调试和排查问题。
   */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      // fallback to original log without timestamp
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return false
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
          if (c.moveToFirst()) (c.getInt(0) == 1) else false
        }
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { false }
  }

  private fun getBaiduAk(ctx: Context): String {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT baidu_ak FROM configs LIMIT 1", null).use { c ->
          if (c.moveToFirst()) (c.getString(0) ?: "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2") else "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
        }
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" }
  }

  private fun queryFirstGeoTarget(ctx: Context): Pair<Double, Double>? {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return null
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT config FROM vision_triggers WHERE enabled=1 AND type='geo' ORDER BY updated_at DESC LIMIT 1", null).use { c ->
          if (!c.moveToFirst()) return null
          val cfg = c.getString(0) ?: return null
          val jo = JSONObject(cfg)
          val lat = jo.optDouble("lat", Double.NaN)
          val lng = jo.optDouble("lng", Double.NaN)
          if (lat.isNaN() || lng.isNaN()) null else Pair(lat, lng)
        }
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { null }
  }

  private fun obtainHighAccuracyLocation(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    try {
      val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val latch = CountDownLatch(1)
      var best: Location? = null
      val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
          if (best == null || loc.accuracy < best!!.accuracy) best = loc
          if (best != null && best!!.accuracy <= targetAccMeters) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
        }
        @Deprecated("deprecated")
        override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
      }
      try {
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
          lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
          lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
      } catch (_: Throwable) {}
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      return best
    } catch (_: Throwable) { return null }
  }

  // 通过反射调用百度定位（若依赖不可用将直接返回 null）
  private fun obtainBaiduLocation(ctx: Context, ak: String, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val clientClazz = Class.forName("com.baidu.location.LocationClient")
      val optionsClazz = Class.forName("com.baidu.location.LocationClientOption")
      val listenerIfc = Class.forName("com.baidu.location.BDAbstractLocationListener")
      val bdLocClazz = Class.forName("com.baidu.location.BDLocation")

      val client = clientClazz.getConstructor(Context::class.java).newInstance(ctx)
      val opts = optionsClazz.getDeclaredConstructor().newInstance()

      optionsClazz.getMethod("setOpenGps", Boolean::class.java).invoke(opts, true)
      try { optionsClazz.getMethod("setScanSpan", Int::class.java).invoke(opts, 0) } catch (_: Throwable) {}
      try { optionsClazz.getMethod("setIsNeedAddress", Boolean::class.java).invoke(opts, false) } catch (_: Throwable) {}

      clientClazz.getMethod("setLocOption", optionsClazz).invoke(client, opts)

      val holder = arrayOfNulls<Any>(1)
      val handler = java.lang.reflect.Proxy.newProxyInstance(
        listenerIfc.classLoader, arrayOf(listenerIfc)
      ) { _, method, args ->
        if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
          holder[0] = args[0]
        }
        null
      }
      clientClazz.getMethod("registerLocationListener", listenerIfc).invoke(client, handler)
      clientClazz.getMethod("start").invoke(client)

      val start = System.currentTimeMillis()
      while (System.currentTimeMillis() - start < timeoutMs) {
        val cur = holder[0]
        if (cur != null) {
          val acc = (bdLocClazz.getMethod("getRadius").invoke(cur) as? Float) ?: 9999f
          val lat = bdLocClazz.getMethod("getLatitude").invoke(cur) as? Double
          val lng = bdLocClazz.getMethod("getLongitude").invoke(cur) as? Double
          if (lat != null && lng != null && acc <= targetAccMeters) {
            val l = Location("baidu")
            l.latitude = lat
            l.longitude = lng
            l.accuracy = acc
            try { clientClazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
            return l
          }
        }
        Thread.sleep(300)
      }
      try { clientClazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
      null
    } catch (_: Throwable) {
      null
    }
  }

  private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371000.0
    val dLat = Math.toRadians(lat2-lat1)
    val dLon = Math.toRadians(lon2-lon1)
    val a = sin(dLat/2)*sin(dLat/2) + cos(Math.toRadians(lat1))*cos(Math.toRadians(lat2))*sin(dLon/2)*sin(dLon/2)
    val c = 2*atan2(sqrt(a), sqrt(1-a))
    return R*c
  }
}
