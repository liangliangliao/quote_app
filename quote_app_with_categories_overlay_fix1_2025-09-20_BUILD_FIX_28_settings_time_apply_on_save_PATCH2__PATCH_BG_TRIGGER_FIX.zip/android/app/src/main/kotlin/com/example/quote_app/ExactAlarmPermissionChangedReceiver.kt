package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.app.AlarmManager
import android.content.pm.PackageManager

/**
 * When user toggles the Exact Alarm permission in system settings (Android 14+),
 * bring the app to foreground once so Flutter can reschedule exact alarms.
 * This avoids having to wait for the next periodic WorkManager run.
 */
class ExactAlarmPermissionChangedReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val action = intent?.action ?: return
            if (action != "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED") return
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (am.canScheduleExactAlarms()) {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    // Mark the intent so Flutter side could decide to instantly reschedule if needed.
                    launchIntent.putExtra("reschedule_on_launch", true)
                    context.startActivity(launchIntent)
                }
            }
        }
    }
}
