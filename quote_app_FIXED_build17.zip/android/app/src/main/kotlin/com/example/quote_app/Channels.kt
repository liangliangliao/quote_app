package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

object Channels {
  private const val CH = "native.scheduler"

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
                "isNativeWM" -> result.success(true)
                "isNativeAM" -> result.success(true)
          "canScheduleExact" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))
          "scheduleExactAt" -> {
            val id = call.argument<Int>("id") ?: 0
            val epochMs = call.argument<Long>("epochMs") ?: 0L
            val payload = call.argument<String>("payload")
            val ok = NativeSchedulerK.scheduleExactAt(appCtx, id, epochMs, payload)
            result.success(ok)
          }
          "cancel" -> {
            val id = call.argument<Int>("id") ?: 0
            NativeSchedulerK.cancel(appCtx, id)
            result.success(null)
          }
          "cancelAll" -> { NativeSchedulerK.cancelAll(appCtx); result.success(null) }
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
        // System/perm support channel used by Dart (PermHelper & NativeGuard)
    MethodChannel(engine.dartExecutor.binaryMessenger, "com.example.quote_app/sys").setMethodCallHandler { call, result ->
      try {
        when (call.method) {
          "isNativeWmEnabled" -> result.success(true)
          "isNativeAmEnabled" -> result.success(true)
          "hasExactAlarmPermission" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactAlarmPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
    
}
  }
}
