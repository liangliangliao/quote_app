import 'package:quote_app/services/native_guard.dart';
import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';


@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) async {
  // Record a tap; actual navigation to home will run on app start.
  try {
    await NotificationService.markLaunchedFromNotification();
  } catch (_) {}
}
class NotificationService {
  static bool _launchFromNotif = false;
  static Future<void> markLaunchedFromNotification() async { _launchFromNotif = true; }
  static bool consumeLaunchFromNotificationFlag() { final v = _launchFromNotif; _launchFromNotif = false; return v; }
  static bool _homeVisible = false;
  static bool _requestedThisSession = false;

  static void markHomeVisible() {
    _homeVisible = true;
    _requestedThisSession = false;
  }

  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  /// Initialize plugin and create Android notification channel.
  /// NOTE: Do NOT request runtime POST_NOTIFICATIONS permission here.
  static Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(
      initSettings,
      onDidReceiveBackgroundNotificationResponse: (NotificationResponse response) async { try { SimpleBus.navHome(); } catch (_) {} },
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        try { SimpleBus.navHome(); } catch (_) {}
        return;
      },
    );

    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android != null) {
        const AndroidNotificationChannel channel = AndroidNotificationChannel(
          'quote_high', '定时提醒',
          description: 'Quote 定时提醒',
          importance: Importance.high,
          playSound: true,
        );
        await android.createNotificationChannel(channel);
      }
    }
  }

  /// Check whether notifications are enabled at system level.
  static Future<bool> areNotificationsEnabled() async {
    try {
      if (!Platform.isAndroid) return true;
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return true;
      final enabled = await android.areNotificationsEnabled();
      return enabled ?? true;
    } catch (_) {
      return true;
    }
  }

  /// Show a simple notification.
  static Future<void> showSimple(String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'quote_high', '定时提醒',
        importance: Importance.high, priority: Priority.high,
      ),
    );
    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    await _plugin.show(id, title, body, details);
  }

  /// Show a rich notification (optional large icon / big picture).
  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'quote_high', '定时提醒',
      channelDescription: 'Quote 定时提醒',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? BigPictureStyleInformation(
              FilePathAndroidBitmap(largeIconPath),
              largeIcon: FilePathAndroidBitmap(largeIconPath),
              contentTitle: title,
              summaryText: body,
            )
          : const DefaultStyleInformation(true, true),
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails);
    final nid = id ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000);
    await _plugin.show(nid, title, body, details);
  }

  /// Request POST_NOTIFICATIONS on Android 13+ after Home is visible, once per process.
  static Future<void> request() async {
    if (!_homeVisible || _requestedThisSession) {
      return;
    }
    _requestedThisSession = true;
    try {
      if (!Platform.isAndroid) return;
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return;
      // Prefer the new API first:
      try {
        await android.requestNotificationsPermission();
        return;
      } catch (_) {}
      // Fallback for older plugin versions exposing requestPermission():
      try {
        await (android as dynamic).requestPermission();
      } catch (_) {}
    } catch (_) {}
  }
}
