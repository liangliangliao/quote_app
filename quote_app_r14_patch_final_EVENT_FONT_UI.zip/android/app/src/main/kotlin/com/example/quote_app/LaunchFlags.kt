package com.example.quote_app

/**
 * 记录应用是否是通过点击原生通知启动/唤醒的。
 * 使用一个简单的内存标志即可，避免引入持久化。
 */
object LaunchFlags {
  @Volatile
  private var tappedNotification: Boolean = false

  fun markNotificationTapped() {
    tappedNotification = true
  }

  fun consumeNotificationTappedFlag(): Boolean {
    val v = tappedNotification
    tappedNotification = false
    return v
  }
}
