package com.example.quote_app

import android.os.Bundle
import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 注册已有通道 + 系统通道（用于通知点击桥接）
        Channels.register(flutterEngine, applicationContext)
        SysChannels.register(flutterEngine, applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent?.let { maybeHandleNotificationIntent(it) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        maybeHandleNotificationIntent(intent)
    }

    private fun maybeHandleNotificationIntent(intent: Intent) {
        if (intent.getBooleanExtra("from_notification", false)) {
            // 记录这次启动由通知触发
            LaunchFlags.markNotificationTapped()
            // 如果 Flutter 已经在内存中，直接发事件给 Dart
            SysChannels.emitNotificationTap()
        }
    }
}
