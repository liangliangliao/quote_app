package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * 系统级通道：原生 → Dart 的通知点击事件桥接。
 * 为了兼容性，只负责 invokeMethod，不设置 handler。
 */
object SysChannels {
  @Volatile
  private var channel: MethodChannel? = null

  private const val SYS_CH = "com.example.quote_app/sys"

  fun register(engine: FlutterEngine, appCtx: Context) {
    channel = MethodChannel(engine.dartExecutor.binaryMessenger, SYS_CH)
  }

  fun emitNotificationTap() {
    try {
      channel?.invokeMethod("onNativeNotificationTap", null)
    } catch (_: Throwable) {
      // Flutter 端可能尚未就绪，冷启动场景由 LaunchFlags 兜底
    }
  }
}
