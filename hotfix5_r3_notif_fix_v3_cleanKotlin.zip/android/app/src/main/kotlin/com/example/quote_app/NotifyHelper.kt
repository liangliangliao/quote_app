package com.example.quote_app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val DEFAULT_CHANNEL_NAME = "Quotes"

  @JvmStatic
  fun send(ctx: Context, id: Int, title: String, body: String, avatarPath: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Android 13+ 运行时权限
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        return
      }
    }

    // 创建默认通知渠道
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = nm.getNotificationChannel(DEFAULT_CHANNEL_ID)
      if (ch == null) {
        val c = NotificationChannel(DEFAULT_CHANNEL_ID, DEFAULT_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT)
        nm.createNotificationChannel(c)
      }
    }

    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)

    // 自定义正文：折叠 5 行 / 展开 12 行；系统风格，字号略放大（+1sp）
    try {
      val collapsedRv = NotifFrameworkCompat.collapsed(ctx, body, 1.0f)
      val expandedRv  = NotifFrameworkCompat.expanded(ctx,  body, 1.0f)
      builder.setCustomContentView(collapsedRv)
      builder.setCustomBigContentView(expandedRv)
    } catch (_: Throwable) {
      // 某些 ROM 不支持 RemoteViews 自定义时，直接回退系统默认文案
    }

    // 大图标（可选）
    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) { }
    }

    nm.notify(id, builder.build())
  }
}
