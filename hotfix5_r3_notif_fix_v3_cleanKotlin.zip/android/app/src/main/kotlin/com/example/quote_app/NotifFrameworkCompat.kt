package com.example.quote_app

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.text.Layout
import android.util.TypedValue
import android.widget.RemoteViews
import android.widget.TextView
import com.example.quote_app.R

/**
 * 兼容增强版（无 Material3 依赖）：
 * - 根据 ROM / API 自动选择外观：优先 DeviceDefault.Body1，失败则回退 Material.Body1，再不行回退 android.R.attr.textAppearance；
 * - 折叠 5 行 / 展开 12 行，统一 TextView；
 * - 字号 = 系统正文基准 + deltaSp，且对极端无障碍字体缩放做上限控制（例如最大放大 1.4x，再叠加 deltaSp）；
 * - 处理 RTL：textDirection/layoutDirection 设为 locale；
 * - 暗色：文本颜色走 ?android:attr/textColorPrimary（交由系统适配）。
 */
object NotifFrameworkCompat {

    private fun resolveBodySpAndApplyAppearance(ctx: Context, tv: TextView): Float {
        // 依次尝试三套外观，避免定制 ROM 缺失样式导致崩溃
        val tried = intArrayOf(
            android.R.style.TextAppearance_Material_Body1,
            android.R.attr.textAppearance
        )
        val out = TypedValue()
        for (attr in tried) {
            try {
                if (attr == android.R.attr.textAppearance) {
                    if (ctx.theme.resolveAttribute(attr, out, true) && out.resourceId != 0) {
                        tv.setTextAppearance(ctx, out.resourceId)
                        break
                    }
                } else {
                    tv.setTextAppearance(ctx, attr)
                    break
                }
            } catch (_: Throwable) {}
        }
        val scaledDensity = ctx.resources.displayMetrics.scaledDensity
        return tv.textSize / scaledDensity // px->sp
    }

    private fun capByFontScale(ctx: Context, baseSp: Float, deltaSp: Float): Float {
        val conf: Configuration = ctx.resources.configuration
        val scale = conf.fontScale.coerceIn(0.85f, 1.40f) // 给一个保守上限，避免 2.0x 导致行数突变
        return baseSp * scale + deltaSp
    }

    private fun common(ctx: Context, body: CharSequence, maxLines: Int, deltaSp: Float): RemoteViews {
        val probe = TextView(ctx)
        val baseSp = resolveBodySpAndApplyAppearance(ctx, probe)
        val targetSp = capByFontScale(ctx, baseSp, deltaSp)

        return RemoteViews(ctx.packageName, R.layout.notif_body_device_default).apply {
            setTextViewText(R.id.body_text, body)
            setInt(R.id.body_text, "setMaxLines", maxLines)
            setTextViewTextSize(R.id.body_text, TypedValue.COMPLEX_UNIT_SP, targetSp)
            // RTL/断行质量
            if (Build.VERSION.SDK_INT >= 17) {
                setInt(R.id.body_text, "setTextDirection", android.view.View.TEXT_DIRECTION_LOCALE)
                setInt(R.id.body_text, "setLayoutDirection", android.view.View.LAYOUT_DIRECTION_LOCALE)
            }
            if (Build.VERSION.SDK_INT >= 23) {
                setInt(R.id.body_text, "setBreakStrategy", Layout.BREAK_STRATEGY_HIGH_QUALITY)
                setInt(R.id.body_text, "setHyphenationFrequency", Layout.HYPHENATION_FREQUENCY_NORMAL)
            }
        }
    }

    fun collapsed(ctx: Context, body: CharSequence, deltaSp: Float = 1f) =
        common(ctx, body, 5, deltaSp)

    fun expanded(ctx: Context, body: CharSequence, deltaSp: Float = 1f) =
        common(ctx, body, 12, deltaSp)
}
