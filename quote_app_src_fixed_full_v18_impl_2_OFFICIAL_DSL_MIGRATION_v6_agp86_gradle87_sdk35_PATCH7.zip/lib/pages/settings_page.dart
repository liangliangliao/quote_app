import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');

  bool _editingConfig = false;
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    setState(() {
      _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
      _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
      _endpointCtrl.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;
    });
    final tasks = await _taskDao.all();
    setState(() {
      _tasks = tasks;
    });
  }

  Future<void> _saveConfig() async {
    await _configDao.save(
      apiKey: _apiKeyCtrl.text.trim(),
      model: _modelCtrl.text.trim().isEmpty ? 'gpt-5' : _modelCtrl.text.trim(),
      endpoint: _endpointCtrl.text.trim(),
    );
    setState(() { _editingConfig = false; });
    await _load();
  }

  Future<void> _openTaskDialog({Map<String, dynamic>? task}) async {
    final isEdit = task != null;

    // fields
    final formKey = GlobalKey<FormState>();
    String name = isEdit ? (task!['name'] ?? '') as String : '';
    String type = isEdit ? (task!['type'] ?? 'auto') as String : 'auto';
    String status = isEdit ? (task!['status'] ?? 'open') as String : 'open';
    String avatarPath = isEdit ? (task!['avatar_path'] ?? '') as String : '';
    String prompt = isEdit ? (task!['prompt'] ?? '') as String : '';
    String freqType = isEdit ? (task!['freq_type'] ?? 'daily') as String : 'daily';
    int? selectedWeekday = isEdit ? task!['freq_weekday'] as int? : 1;
    int? selectedMonthDay = isEdit ? task!['freq_day_of_month'] as int? : 1;

    // base time
    DateTime start;
    if (isEdit) {
      final s = (task!['start_time'] as String);
      try { start = DateTime.parse(s.replaceFirst(' ', 'T')); }
      catch (_) { start = DateTime.now(); }
    } else {
      start = DateTime.now().add(const Duration(minutes: 1));
    }

    final nameCtrl = TextEditingController(text: name);
    final promptCtrl = TextEditingController(text: prompt);
    final manualQuoteCtrl = TextEditingController();

    // manual task: preload latest
    if (isEdit && type == 'manual') {
      final latest = await QuoteDao().latestForTask(task!['task_uid'] as String);
      manualQuoteCtrl.text = latest ?? '';
    }

    await showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: Text(isEdit ? '编辑任务' : '新增任务'),
        content: StatefulBuilder(builder: (ctx, setStateDialog) {
          Future<void> pickAvatar() async {
            final picker = ImagePicker();
            final x = await picker.pickImage(source: ImageSource.gallery);
            if (x == null) return;
            final bytes = await x.readAsBytes();
            final decoded = img.decodeImage(bytes);
            if (decoded != null) {
              final resized = img.copyResize(decoded, width: 72, height: 72);
              final dir = await getApplicationDocumentsDirectory();
              final file = File('${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png');
              await file.writeAsBytes(img.encodePng(resized));
              avatarPath = file.path;
              setStateDialog((){});
            }
          }

          Widget timePickerRow() {
            return Row(
              children: [
                const Text('时间：'),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: freqType,
                  items: const [
                    DropdownMenuItem(value: 'daily', child: Text('每天')),
                    DropdownMenuItem(value: 'weekly', child: Text('每周')),
                    DropdownMenuItem(value: 'monthly', child: Text('每月')),
                    DropdownMenuItem(value: 'custom', child: Text('自定义')),
                  ],
                  onChanged: (v){ if (v!=null) setStateDialog(()=> freqType = v); },
                ),
                const Spacer(),
                Text('${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}'),
                IconButton(
                  icon: const Icon(Icons.access_time),
                  onPressed: () async {
                    final t = await showTimePicker(context: ctx, initialTime: TimeOfDay(hour: start.hour, minute: start.minute));
                    if (t!=null) setStateDialog(()=> start = DateTime(start.year, start.month, start.day, t.hour, t.minute));
                  },
                ),
              ],
            );
          }

          Widget freqDetail() {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (freqType=='weekly') Row(
                  children: [
                    const Text('星期：'),
                    const SizedBox(width: 8),
                    DropdownButton<int>(
                      value: (selectedWeekday ?? 1),
                      items: const [
                        DropdownMenuItem(value: 1, child: Text('一')),
                        DropdownMenuItem(value: 2, child: Text('二')),
                        DropdownMenuItem(value: 3, child: Text('三')),
                        DropdownMenuItem(value: 4, child: Text('四')),
                        DropdownMenuItem(value: 5, child: Text('五')),
                        DropdownMenuItem(value: 6, child: Text('六')),
                        DropdownMenuItem(value: 7, child: Text('日')),
                      ],
                      onChanged: (v){ setStateDialog(()=> selectedWeekday = v); },
                    ),
                  ],
                ),
                if (freqType=='monthly') Row(
                  children: [
                    const Text('日：'),
                    const SizedBox(width: 8),
                    DropdownButton<int>(
                      value: (selectedMonthDay ?? 1),
                      items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
                      onChanged: (v){ setStateDialog(()=> selectedMonthDay = v); },
                    ),
                  ],
                ),
              ],
            );
          }

          return SizedBox(
            width: 380,
            child: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('头像'),
                        const SizedBox(width: 12),
                        CircleAvatar(
                          radius: 24,
                          backgroundImage: (avatarPath.isNotEmpty) ? FileImage(File(avatarPath)) : null,
                          child: avatarPath.isEmpty ? const Icon(Icons.person) : null,
                        ),
                        const SizedBox(width: 12),
                        OutlinedButton.icon(icon: const Icon(Icons.photo), label: const Text('选择头像'), onPressed: pickAvatar),
                      ],
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: nameCtrl,
                      decoration: const InputDecoration(labelText: '任务名称'),
                      validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务名称' : null,
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: type,
                      items: const [
                        DropdownMenuItem(value: 'auto', child: Text('自动任务')),
                        DropdownMenuItem(value: 'manual', child: Text('手动任务')),
                        DropdownMenuItem(value: 'carousel', child: Text('轮播任务')),
                      ],
                      onChanged: (v){ setStateDialog(()=> type = v ?? 'auto'); },
                      decoration: const InputDecoration(labelText: '任务类型'),
                    ),
                    const SizedBox(height: 8),
                    timePickerRow(),
                    const SizedBox(height: 8),
                    freqDetail(),
                    const SizedBox(height: 8),
                    if (type=='manual') TextFormField(
                      controller: manualQuoteCtrl,
                      maxLines: 3,
                      decoration: const InputDecoration(labelText: '名人名言内容'),
                    ),
                    if (type!='manual') TextFormField(
                      controller: promptCtrl,
                      minLines: 1,
                      maxLines: 3,
                      decoration: const InputDecoration(labelText: '提示词（自动任务用）'),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Text('状态：'),
                        const SizedBox(width: 8),
                        FilterChip(
                          label: Text(status=='open'?'开启(open)':'关闭(closed)'),
                          selected: status=='open',
                          onSelected: (_){ setStateDialog(()=> status = (status=='open'?'closed':'open')); },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
        actions: [
          TextButton(onPressed: (){ Navigator.pop(context); }, child: const Text('取消')),
          FilledButton(onPressed: () async {
            if (!formKey.currentState!.validate()) return;
            if (isEdit) {
              await _taskDao.update(
                taskUid: task!['task_uid'] as String,
                name: nameCtrl.text.trim(),
                type: type,
                startTime: start,
                prompt: promptCtrl.text.trim(),
                avatarPath: avatarPath.isEmpty ? null : avatarPath,
                status: status,
                freqType: freqType,
                freqWeekday: selectedWeekday,
                freqDayOfMonth: selectedMonthDay,
              );
              if (type=='manual' && manualQuoteCtrl.text.trim().isNotEmpty) {
                await QuoteDao().updateLatestForTask(task!['task_uid'] as String, manualQuoteCtrl.text.trim());
              }
            } else {
              final uid = await _taskDao.create(
                name: nameCtrl.text.trim(),
                type: type,
                startTime: start,
                prompt: promptCtrl.text.trim(),
                avatarPath: avatarPath,
                status: status,
                freqType: freqType,
                freqWeekday: selectedWeekday,
                freqDayOfMonth: selectedMonthDay,
              );
              if (type=='manual' && manualQuoteCtrl.text.trim().isNotEmpty) {
                await QuoteDao().insertIfUnique(taskUid: uid, type: 'manual', taskName: nameCtrl.text.trim(), avatarPath: avatarPath, content: manualQuoteCtrl.text.trim());
              }
            }
            await SchedulerService.scheduleNextForAll();
            await _load();
            if (context.mounted) Navigator.pop(context);
          }, child: const Text('保存')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(''),
        actions: [
          IconButton(onPressed: (){
            setState(()=> _editingConfig = true);
          }, icon: const Icon(Icons.edit)),
          IconButton(onPressed: _saveConfig, icon: const Icon(Icons.save)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            // 配置区
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('配置', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _apiKeyCtrl,
                  readOnly: !_editingConfig,
                  decoration: const InputDecoration(labelText: 'API Key'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _modelCtrl,
                  readOnly: !_editingConfig,
                  decoration: const InputDecoration(labelText: '模型名称（默认 gpt-5）'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _endpointCtrl,
                  readOnly: !_editingConfig,
                  decoration: const InputDecoration(labelText: '接口地址（默认 /v1/responses）'),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ..._tasks.map((t) => ListTile(
              title: InkWell(
                onTap: () => _openTaskDialog(task: t),
                child: Text((t['name'] ?? '') as String, style: const TextStyle(decoration: TextDecoration.underline)),
              ),
              subtitle: Text('时间: ${(t['start_time'] ?? '') as String}   类型: ${(t['type'] ?? '') as String}   状态: ${(t['status'] ?? '') as String}'),
            )),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}