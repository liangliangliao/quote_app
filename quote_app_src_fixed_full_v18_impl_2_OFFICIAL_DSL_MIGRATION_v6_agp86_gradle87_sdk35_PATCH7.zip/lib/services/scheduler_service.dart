import 'dart:isolate';
import 'dart:ui';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import '../data/dao.dart';
import '../data/db.dart';
import '../services/notification_service.dart';
import '../services/openai_service.dart';

const String _isolateName = 'task_alarm_isolate';
SendPort? _uiSendPort;

class SchedulerService {
  static Future<void> init() async {
    await AndroidAlarmManager.initialize();
  }

  /// Schedule one exact alarm per open task, based on `next_run_at`.
  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    final now = DateTime.now();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final ms = (t['next_run_at'] as int?) ?? 0;
      if (ms <= 0) continue;
      final when = DateTime.fromMillisecondsSinceEpoch(ms);
      if (!when.isAfter(now)) continue;
      final id = (t['task_uid'] as String).hashCode & 0x7fffffff;
      await AndroidAlarmManager.oneShotAt(
        when, id, callback,
        exact: true, wakeup: true, allowWhileIdle: true, rescheduleOnReboot: true
      );
    }
  }

  /// Alarm entry point: dispatch due tasks and reschedule.
  @pragma('vm:entry-point')
  static Future<void> callback() async {
    final now = DateTime.now();
    final db = await AppDatabase.instance();
    final tasks = await TaskDao().all();
    final cfg = await ConfigDao().getOne();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final nextMs = (t['next_run_at'] as int?) ?? 0;
      if (nextMs == 0) continue;
      if (now.millisecondsSinceEpoch + 500 < nextMs) continue; // not due yet

      final type = (t['type'] ?? 'auto') as String;
      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;

      if (type == 'manual') {
        final content = await QuoteDao().contentForTask(taskUid);
        if (content != null && content.trim().isNotEmpty) {
          await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
          await QuoteDao().markNewestNotifiedForTask(taskUid);
          await LogDao().add(taskUid: taskUid, detail: '成功!');
        }
      } else if (type == 'carousel') {
        final content = await QuoteDao().nextCarouselContent(taskUid);
        if (content != null) {
          await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
          await LogDao().add(taskUid: taskUid, detail: '成功!');
        }
      } else {
        // auto: call OpenAI and dedupe with up to 10 retries
        final endpoint = (cfg['endpoint'] as String?)?.isNotEmpty == true ? cfg['endpoint'] as String : 'https://api.openai.com/v1/responses';
        final model = (cfg['model'] as String?)?.isNotEmpty == true ? cfg['model'] as String : 'gpt-5';
        final apiKey = (cfg['api_key'] as String?) ?? '';
        final prompt = (t['prompt'] as String?) ?? '';
        try {
          final content = await OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model).generateQuote(prompt);
          Future<void> insertAndNotify(String text) async {
            final uid = await QuoteDao().insertIfUnique(taskUid: taskUid, type: 'auto', taskName: name, avatarPath: avatar, content: text);
            await LogDao().add(taskUid: taskUid, detail: uid==null ? '错误! 插入名言失败（可能重复）' : '成功!');
            if (uid != null) {
              await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: text, largeIconPath: avatar);
              await QuoteDao().markNotifiedByUid(uid);
            }
          }
          if (content.trim().isNotEmpty) {
            if (await QuoteDao().existsSimilar(content)) {
              int fail = 0; bool done = false;
              while (fail < 10 && !done) {
                final c2 = await OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model).generateQuote(prompt);
                if (c2.trim().isNotEmpty && !(await QuoteDao().existsSimilar(c2))) {
                  await insertAndNotify(c2); done = true; break;
                }
                fail++;
              }
              if (!done) await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
            } else {
              await insertAndNotify(content);
            }
          } else {
            await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
          }
        } catch (_) {
          await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
        }
      }

      // Recompute next_run_at and reschedule self
      final freq = (t['freq_type'] ?? 'daily') as String;
      final weekday = t['freq_weekday'] as int?;
      final dom = t['freq_day_of_month'] as int?;
      final stStr = (t['start_time'] as String);
      DateTime base;
      try { base = DateTime.parse(stStr.replaceFirst(' ', 'T')); } catch (_) { base = DateTime(now.year, now.month, now.day, now.hour, now.minute); }
      final nextMs2 = TaskDao.computeNextRunAt(DateTime.now(), base, freq, weekday, dom);
      await db.update('tasks', {'next_run_at': nextMs2}, where: 'task_uid=?', whereArgs: [taskUid]);
      final when2 = DateTime.fromMillisecondsSinceEpoch(nextMs2);
      final id2 = taskUid.hashCode & 0x7fffffff;
      await AndroidAlarmManager.oneShotAt(when2, id2, callback, exact: true, wakeup: true, allowWhileIdle: true, rescheduleOnReboot: true);
    }
  }
}