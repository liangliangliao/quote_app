import 'package:intl/intl.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../platform/native_scheduler.dart';

class SchedulerService {
  static Future<void> init() async {}

  static String _runKeyFromEpoch(int epochMs) {
    final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
    return DateFormat('yyyyMMdd_HHmmss_SSS').format(dt);
  }

  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      await registerOne(t);
    }
  }

  /// 注册精准闹钟前，预先把业务文案绑定到 payloads(task_uid, run_key)
  static Future<void> registerOne(Map<String, dynamic> task) async {
    final uid = (task['uid'] ?? task['task_uid']).toString();
    if (uid.isEmpty) return;
    final epoch = (task['trigger_at'] is int) ? task['trigger_at'] as int : DateTime.now().millisecondsSinceEpoch + 60000;
    final runKey = _runKeyFromEpoch(epoch);

    final title = (task['title'] ?? '提醒').toString();
    final content = (task['content'] ?? '该做正事啦').toString();
    await PayloadDao().upsert(taskUid: uid, runKey: runKey, title: title, content: content, avatarPath: task['avatar_path']?.toString());

    await TaskDao().upsertScheduledRunKey(uid, runKey);

    final ok = await NativeScheduler.scheduleExactAt(
      id: uid.hashCode,
      epochMs: epoch,
      taskUid: uid,
      runKey: runKey,
      payload: {'task_uid': uid, 'run_key': runKey},
    );
    await DLog.i('SCH', 'schedule exact uid=$uid run=$runKey ok=$ok');
  }

  /// ---- injected shim methods (compile-compat, keep minimal side-effects) ----
  static Future<void> selfCheckTodayFailures() async {
    await DLog.i('SCH', 'selfCheckTodayFailures noop');
  }

  static Future<void> scheduleSelfCheck() async {
    await DLog.i('SCH', 'scheduleSelfCheck noop');
  }

  static Future<void> wmRunTask(String uid, String? runKey, {String? chan, int? attempt}) async {
    await DLog.i('SCH', 'wmRunTask uid=' + uid + ' runKey=' + (runKey ?? '') + ' chan=' + (chan ?? '') + ' attempt=' + (attempt?.toString() ?? ''));
  }

  static Future<void> callback() async {
    await DLog.i('SCH', 'callback noop');
  }
static Future<void> cancelNextForTask(String uid) async {
    await NativeScheduler.cancel(uid.hashCode);
    await DLog.i('SCH','cancelNextForTask '+uid);
}
static Future<void> scheduleNextForTask(String uid) async {
    final task = await TaskDao().getByUid(uid);
    if (task == null) return;
    final epoch = (task['trigger_at'] is int) ? task['trigger_at'] as int : DateTime.now().millisecondsSinceEpoch + 60000;
    final runKey = _runKeyFromEpoch(epoch);
    final title = (task['title'] ?? '提醒').toString();
    final content = (task['content'] ?? '该做正事啦').toString();
    await PayloadDao().upsert(taskUid: uid, runKey: runKey, title: title, content: content, avatarPath: task['avatar_path']?.toString());
    await TaskDao().upsertScheduledRunKey(uid, runKey);
    final ok = await NativeScheduler.scheduleExactAt(
      id: uid.hashCode, epochMs: epoch, taskUid: uid, runKey: runKey, payload: {'task_uid': uid, 'run_key': runKey},
    );
    await DLog.i('SCH', 'schedule exact uid=$uid run=$runKey ok=$ok');
}
}
