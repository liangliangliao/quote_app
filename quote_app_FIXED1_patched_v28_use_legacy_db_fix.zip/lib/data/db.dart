import 'dart:io';
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

const _DB_NAME = 'quotes.db';





class AppDatabase {
  static Future<void> _copyDbFile(String from, String to) async {
    try {
      await Directory(p.dirname(to)).create(recursive: true);
      final src = File(from);
      if (await src.exists()) {
        await src.copy(to);
      }
    } catch (_) {}
  }

  static Database? _db;

  static Future<Database> instance() async {
  if (_db != null) return _db!;

  final dbDir = await getDatabasesPath();
  final legacyPath = p.join(dbDir, _DB_NAME);
  final docDir = await getApplicationDocumentsDirectory();
  final newPath = p.join(docDir.path, _DB_NAME);

  if (await databaseExists(legacyPath)) {
    _db = await openDatabase(
      legacyPath, version: 6,
      onCreate: (db, v) async => _migrate(db),
      onUpgrade: (db, ov, nv) async => _migrate(db),
    );
    if (await databaseExists(newPath)) {
      try { await _mergeFromExternalDb(_db!, newPath); } catch (_) {}
    }
    return _db!;
  }

  if (await databaseExists(newPath)) {
    try { await _copyDbFile(newPath, legacyPath); } catch (_) {}
  }

  _db = await openDatabase(
    legacyPath, version: 6,
    onCreate: (db, v) async => _migrate(db),
    onUpgrade: (db, ov, nv) async => _migrate(db),
  );
  return _db!;
}
catch (_) {}
    }
    return _db!;
  }

  if (await databaseExists(newPath)) {
    try { await _copyDbFile(newPath, legacyPath); } catch (_) {}
  }

  _db = await openDatabase(legacyPath, version: 6,
    onCreate: (db, v) async => _migrate(db),
    onUpgrade: (db, ov, nv) async => _migrate(db));
  return _db!;
}

  static Future<void> _migrate(Database db) async {
    // Core tables
    await db.execute('''
      CREATE TABLE IF NOT EXISTS tasks(
        uid TEXT PRIMARY KEY,
        title TEXT,
        type TEXT,
        prompt TEXT,
        avatar_path TEXT,
        status TEXT,
        start_time TEXT,
        next_time INTEGER,
        scheduled_run_key TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS quotes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT,
        title TEXT,
        content TEXT,
        created_at INTEGER DEFAULT (strftime('%s','now'))
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT,
        message TEXT,
        created_at INTEGER DEFAULT (strftime('%s','now'))
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS config(
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS payloads(
        task_uid TEXT,
        run_key TEXT,
        title TEXT,
        content TEXT,
        big_picture TEXT,
        actions_json TEXT,
        payload_json TEXT,
        PRIMARY KEY(task_uid, run_key)
      )
    ''');

    // Make sure newly added columns exist (idempotent)
    Future<void> ensureColumn(String table, String column, String ddl) async {
      final info = await db.rawQuery("PRAGMA table_info(" + table + ")");
      final cols = info.map((e) => (e['name'] as String).toLowerCase()).toSet();
      if (!cols.contains(column.toLowerCase())) {
        await db.execute(ddl);
      }
    }

    await ensureColumn('tasks','start_time',"ALTER TABLE tasks ADD COLUMN start_time TEXT");
    await ensureColumn('tasks','next_time',"ALTER TABLE tasks ADD COLUMN next_time INTEGER");
    await ensureColumn('tasks','scheduled_run_key',"ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
    await ensureColumn('tasks','prompt',"ALTER TABLE tasks ADD COLUMN prompt TEXT");
    await ensureColumn('tasks','avatar_path',"ALTER TABLE tasks ADD COLUMN avatar_path TEXT");
    await ensureColumn('tasks','type',"ALTER TABLE tasks ADD COLUMN type TEXT");
    await ensureColumn('tasks','status',"ALTER TABLE tasks ADD COLUMN status TEXT");
        await ensureColumn('tasks','task_uid',"ALTER TABLE tasks ADD COLUMN task_uid TEXT");
        await ensureColumn('tasks','name',"ALTER TABLE tasks ADD COLUMN name TEXT");
  }
}

/// Ensure extra task columns exist when app boots.
Future<void> ensureExtraTaskColumns() async {
  final db = await AppDatabase.instance();
  Future<void> ensure(String column, String ddl) async {
    final info = await db.rawQuery("PRAGMA table_info(tasks)");
    final cols = info.map((e) => (e['name'] as String).toLowerCase()).toSet();
    if (!cols.contains(column.toLowerCase())) {
      await db.execute(ddl);
    }
  }
  await ensure('start_time',"ALTER TABLE tasks ADD COLUMN start_time TEXT");
  await ensure('next_time',"ALTER TABLE tasks ADD COLUMN next_time INTEGER");
  await ensure('scheduled_run_key',"ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
  await ensure('prompt',"ALTER TABLE tasks ADD COLUMN prompt TEXT");
  await ensure('avatar_path',"ALTER TABLE tasks ADD COLUMN avatar_path TEXT");
  await ensure('type',"ALTER TABLE tasks ADD COLUMN type TEXT");
  await ensure('status',"ALTER TABLE tasks ADD COLUMN status TEXT");
}
