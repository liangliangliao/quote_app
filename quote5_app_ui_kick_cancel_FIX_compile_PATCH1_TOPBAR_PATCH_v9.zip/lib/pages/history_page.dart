import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:path/path.dart' as p;

import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
        
  Future<String?> _saveAvatarTemp(File file) async {
    final docs = await getApplicationDocumentsDirectory();
    final ext = p.extension(file.path);
    final dst = File(p.join(docs.path, 'avatar_${DateTime.now().millisecondsSinceEpoch}${ext}'));
    await dst.writeAsBytes(await file.readAsBytes());
    return dst.path;
  }

  Future<void> _reload() async {
    _items.clear();
    _offset = 0;
    _done = false;
    await _loadMore();
    if (mounted) setState((){});
  }

  final _dao = QuoteDao();
  final _scroll = ScrollController();
  String _q = '';
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && !_done) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 100, offset: _offset, q: _q.isEmpty ? null : _q);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 100) _done = true;
  }

  
  @override
  Widget build(BuildContext context) {
    final double topPad = MediaQuery.of(context).padding.top;
    return Column(
      children: [
        SizedBox(height: topPad),
        Container(
          height: kToolbarHeight,
          color: Colors.white,
          alignment: Alignment.centerRight,
          child: IconButton(
            onPressed: _pickAndImportFile,
            icon: const Icon(Icons.upload),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            children: [
              const Icon(Icons.search, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    hintText: '搜索',
                    border: InputBorder.none, // 去下划线
                  ),
                  onChanged: _onSearchChanged,
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(child: _buildList()),
      ],
    );
  }
}
