import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/dao.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _fav = false;
  Map<String,dynamic>? _latest;
  Timer? _timer;

  Future<void> _shareLatest() async {
    // 为避免新增依赖，这里用复制到剪贴板作为“分享”的简化实现
    final text = (_latest?['content'] ?? '') as String?;
    if (text == null || text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制，可去任何应用粘贴分享')));
    }
  }


  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 5), (_)=> _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final dao = QuoteDao();
    final rows = await dao.all(limit: 1, offset: 0);
    setState(()=> _latest = rows.isNotEmpty ? rows.first : null);
  }

  
  @override
  Widget build(BuildContext context) {
    final double topPad = MediaQuery.of(context).padding.top;
    final Widget topBar = Container(
      height: kToolbarHeight,
      color: Colors.white,
      padding: EdgeInsets.only(top: 0),
      child: Row(
        children: [
          const SizedBox(width: 8),
          IconButton(onPressed: _shareLatest, icon: const Icon(Icons.share)),
          IconButton(onPressed: () async {
            final text = (_latest?['content'] ?? '') as String?;
            if (text == null || text.isEmpty) return;
            await Clipboard.setData(ClipboardData(text: text));
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制')));
            }
          }, icon: const Icon(Icons.copy)),
          StatefulBuilder(builder: (context, setStateSB) {
            return IconButton(onPressed: (){ setStateSB((){}); setState(()=> _fav = !_fav); }, icon: Icon(_fav ? Icons.favorite : Icons.favorite_border));
          }),
        ],
      ),
    );

    Widget content;
    if (_latest == null) {
      content = const Center(child: Text('暂无数据！'));
    } else {
      content = Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Text(
            (_latest!['content'] ?? '') as String,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      );
    }

    return Column(
      children: [
        SizedBox(height: topPad),
        topBar,
        Expanded(child: content),
      ],
    );
  }
}
