package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Minimal receiver to satisfy manifest reference.
 * android_alarm_manager_plus already handles rescheduling via its own receiver.
 * We intentionally keep this as a no-op to avoid duplicate scheduling.
 */
class BootReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // no-op: plugin's RebootBroadcastReceiver handles reschedule
    }
}
