import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView 容器：统一处理“空白→兜底/动态”的展示与 JS 注入
class HomeHtmlView extends StatefulWidget {
  final String assetPath;                 // 兜底/模板 HTML
  final Map<String, dynamic>? data;       // null 表示兜底（无/异常）

  const HomeHtmlView({super.key, required this.assetPath, required this.data});

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  // Wait until DOM is visibly painted (avoid removing white overlay too early)
  Future<bool> _awaitDomPaint({int tries = 8}) async {
    for (var i = 0; i < tries; i++) {
      try {
        final result = await _controller.runJavaScriptReturningResult(
          "(function(){try{var b=document.body; if(!b) return false;"
          "var h=b.offsetHeight||0; var s=getComputedStyle(b).backgroundColor;"
          "return (h>0)||(s==='rgb(255, 255, 255)'||s==='#fff'||s==='#ffffff');}catch(e){return false;}})();"
        );
        if (result == true || result == 'true' || (result != null && result.toString() == 'true')) return true;
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 80));
    }
    return false;
  }

  // NAVFIX34: compute safe fallback height when initial measure is too small
  double _fallbackFromWidth(BuildContext context) {
    final w = MediaQuery.of(context).size.width * 0.92;
    return (w * (124.0 / 85.0)) + 8.0;
  }

  // NAVFIX28: dynamic height to crop extra blank space
  double _webHeight = 10; // small initial height to avoid gray flash
  bool _webReady = false;
  bool _dataApplied = false;

  Future<void> _fitToContent() async {
    try {
      final result = await _controller.runJavaScriptReturningResult(r'''
        (function() {
          var el = document.querySelector('.poster,.poster-root,.frame,.page');
          var h = 0;
          if (el) {
            var rect = el.getBoundingClientRect();
            h = Math.ceil(rect.height);
          }
          if (!h || h < 48) {
            var de = document.documentElement, db = document.body;
            h = Math.max(de.scrollHeight, db.scrollHeight, de.offsetHeight, db.offsetHeight, de.clientHeight, db.clientHeight);
          }
          return Math.ceil(h);
        })();
      ''');
      final h = double.tryParse(result.toString().replaceAll('"', '')) ?? 0.0;
      if (h > 0 && mounted) {
        setState(() { _webHeight = h; });
      }
      await _controller.runJavaScript(r'''
        (function() {
          document.documentElement.style.overflow = 'hidden';
          document.body.style.overflow = 'hidden';
          document.body.style.background = '#ffffff';
          try{ document.documentElement.style.setProperty('--bg-url','none'); }catch(_){}
          try{
            var ps=document.getElementsByClassName('poster');
            for(var i=0;i<ps.length;i++){ ps[i].style.background='#ffffff'; ps[i].style.backgroundImage='none'; }
          }catch(_){}
        })();
      ''');
    } catch (e) {
      // ignore
    }
  }


  Future<void> _fitToContentLoop({int maxTries = 8}) async {
    for (int i = 0; i < maxTries; i++) {
      await _fitToContent();
      if (_webHeight > 120) return;
      await Future.delayed(const Duration(milliseconds: 120));
    }
  }
  bool _reveal = false;
  late final WebViewController _controller;
  bool _htmlLoaded = false; // 标识模板是否已加载完成

  // 无需隐藏/显示 HTML：我们通过一次性加载模板并在数据变化时直接注入，从而避免每次出现空白页面
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) { _ensureBgWhite(); });
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      // 让 WebView 背景完全透明，以便由上层容器提供纯白背景，避免白屏闪烁
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) async { _webReady = true; if (mounted) setState((){}); _webReady = true; setState((){});
          _htmlLoaded = true;
          if (widget.data == null) { await _awaitDomPaint(); if (mounted) setState((){ _webReady = true; }); }

            // 页面初次加载完成时注入初始数据（若有）
            if (widget.data != null) {
              await _injectDynamic(widget.data!);
            }
            // NAVFIX29: fit webview to content height (and retry once after reflow)
            await _fitToContentLoop(maxTries: 10);
          },

        ),
      );
    _loadHtml();
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.data != oldWidget.data) {
      // 当模板已经加载并且数据变化时，直接注入新的数据，而不是重新加载空白模板
      if (_htmlLoaded) {
        if (widget.data != null) {
          // 在下一微任务中执行 JS，确保 build 完成
          Future.microtask(() async {
            await _injectDynamic(widget.data!);
          });
        }
      }
    }
  }

  
Future<void> _loadHtml() async {
  try {
    // 首帧白页，避免平台灰
    await _controller.loadHtmlString('<!doctype html><meta name="color-scheme" content="light"><style>html,body{margin:0;height:100%;background:#fff}</style>');
    // 资产存在性检查
    await rootBundle.loadString(widget.assetPath);
    // 用 Flutter asset 方式加载，保证相对路径可用
    await _controller.loadFlutterAsset(widget.assetPath);
  } catch (e) {
    final esc = e.toString().replaceAll("'", "\'"); 
    await _controller.loadHtmlString('<!doctype html><meta name="color-scheme" content="light"><style>html,body{margin:0;height:100%;background:#fff;font:14px/1.6 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto}</style><body><div style="padding:14px"><h3>HTML 资产未找到或加载失败</h3><div>path: <code>' + widget.assetPath + '</code></div><div>error: <code>' + esc + '</code></div></div></body>');
  }
}
</style>');
      await 
// First load a pure-white page to avoid any gray flash
_controller.loadHtmlString('<!doctype html><meta name="color-scheme" content="light"><style>html,body{margin:0;height:100%;background:#fff}</style>');

// Pre-check asset existence; show diagnostic if missing
try {
  await rootBundle.loadString(widget.assetPath);
  _controller.loadHtmlString('<!doctype html><meta name="color-scheme" content="light">''<style>html,body{margin:0;height:100%;background:#fff}</style>');
      try { await rootBundle.loadString(widget.assetPath); _controller.loadFlutterAsset(widget.assetPath); }
      catch (e) { final esc = e.toString().replaceAll("'", "\'");
        await _controller.loadHtmlString('''<!doctype html>
<meta name="color-scheme" content="light">
<style>html,body{margin:0;height:100%;background:#fff;font:14px/1.6 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto}</style>
<body><div style="padding:14px"><h3>HTML 资产未找到或加载失败</h3>
<div>path: <code>''' + widget.assetPath + '''</code></div>
<div>error: <code>''' + esc + '''</code></div></div></body>'''); }
} catch (e) {
  final esc = e.toString().replaceAll("'", "\\'");
  await _controller.loadHtmlString('''<!doctype html>
<meta name="color-scheme" content="light">
<style>html,body{margin:0;height:100%;background:#fff;font:14px/1.6 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto}</style>
<body><div style="padding:14px"><h3>HTML 资产未找到</h3><div>path: <code>''' + widget.assetPath + '''</code></div>
<div>error: <code>''' + esc + '''</code></div></div></body>''');
}
await _fitToContentLoop(maxTries: 6);
    } catch (_) {
      // 回退到内联加载（当本地加载失败时）
      final html = await rootBundle.loadString(widget.assetPath);
await _controller.setBackgroundColor(const Color(0x00000000));
              await _controller.loadHtmlString(html, baseUrl: 'file:///android_asset/flutter_assets/');
            await _fitToContentLoop(maxTries: 12);
        }
  }

  Future<void> _injectDynamic(Map<String, dynamic> data) async {
    final payloadJson = jsonEncode(data);
    final js = '''
      (function(){
        try{
          var payload = $payloadJson;
          if (window.setDynamicData && typeof window.setDynamicData === 'function') {
            window.setDynamicData(payload);
          } else {
            window.PAYLOAD = payload;
            try{ if (window.onPayloadArrived) window.onPayloadArrived(payload); }catch(e){}
          }
          return true;
        }catch(e){ return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(js);
      _dataApplied = true;
      if (await _awaitDomPaint()) { if (mounted) setState((){ _webReady = true; }); }
      _markReveal();
    } catch (_) {
      // 如果执行失败，则忽略错误；页面加载完成后注入可能仍会成功
    }
  }

  void _ensureBgWhite() async { try { await _controller.setBackgroundColor(const Color(0x00000000)); } catch (_) {} }

  void _markReveal(){ if(!_reveal){ try{ setState(()=>_reveal=true); } catch(_){}} }

  @override
  Widget build(BuildContext context) {
    // 直接渲染 WebView：不再隐藏或延时显示，避免初始白屏
    return Stack(
      children: [
        Transform.translate(
          offset: const Offset(0, -1),
          child: SizedBox(
            height: (_webHeight < 120 ? _fallbackFromWidth(context) : _webHeight), // NAVFIX29: crop WebView to content height
            child: Stack(children:[
              Container(
                clipBehavior: Clip.hardEdge,
                color: Colors.white,
                child: WebViewWidget(controller: _controller),
              ),
              AnimatedOpacity(
                opacity: _webReady ? 0.0 : 1.0,
                duration: const Duration(milliseconds: 180),
                child: const ColoredBox(color: Colors.white),
              ),
            ]),
          ),
        ),
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: IgnorePointer(
            child: SizedBox(
              height: (2.0 / MediaQuery.of(context).devicePixelRatio),
              child: const ColoredBox(color: Colors.white),
            ),
          ),
        ),
      ],
    );}
}