package com.example.quote_app.am

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

object SqliteReader {

    data class Payload(
        val title: String?, val content: String?,
        val bigPicture: String?, val actionsJson: String?, val payloadJson: String?
    )

    private fun readPayload(c: Cursor): Payload {
        fun s(name: String) = c.getColumnIndex(name).let { if (it >= 0) c.getString(it) else null }
        return Payload(s("title"), s("content"), s("big_picture"), s("actions_json"), s("payload_json"))
    }

    private fun tableExists(db: SQLiteDatabase, name: String): Boolean =
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(name))
            .use { it.moveToFirst() }

    fun queryExact(dbPath: String, taskUid: String, runKey: String): Payload? {
        val db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            // 1) payloads(task_uid, run_key)
            if (tableExists(it, "payloads")) {
                it.rawQuery(
                    "SELECT title,content,big_picture,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key=? LIMIT 1",
                    arrayOf(taskUid, runKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            // 2) tasks 直接带文案（兼容）
            if (tableExists(it, "tasks")) {
                it.rawQuery(
                    "SELECT title,content,big_picture,actions_json,payload_json FROM tasks WHERE task_uid=? AND scheduled_run_key=? LIMIT 1",
                    arrayOf(taskUid, runKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            // 3) quotes 与 tasks 关联（兼容若 tasks 引用 quote_id）
            if (tableExists(it, "quotes") && tableExists(it, "tasks")) {
                it.rawQuery(
                    "SELECT q.title as title, q.content as content, NULL as big_picture, NULL as actions_json, NULL as payload_json " +
                    "FROM quotes q JOIN tasks t ON t.quote_id=q.id WHERE t.task_uid=? AND t.scheduled_run_key=? LIMIT 1",
                    arrayOf(taskUid, runKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            return null
        }
    }

    fun queryNearest(dbPath: String, taskUid: String, fromRunKey: String, toRunKey: String): Payload? {
        val db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            if (tableExists(it, "payloads")) {
                it.rawQuery(
                    "SELECT title,content,big_picture,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key BETWEEN ? AND ? ORDER BY run_key DESC LIMIT 1",
                    arrayOf(taskUid, fromRunKey, toRunKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            if (tableExists(it, "tasks")) {
                it.rawQuery(
                    "SELECT title,content,big_picture,actions_json,payload_json FROM tasks WHERE task_uid=? AND scheduled_run_key BETWEEN ? AND ? ORDER BY scheduled_run_key DESC LIMIT 1",
                    arrayOf(taskUid, fromRunKey, toRunKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            return null
        }
    }
}
