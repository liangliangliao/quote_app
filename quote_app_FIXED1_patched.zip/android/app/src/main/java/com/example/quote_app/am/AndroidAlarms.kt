package com.example.quote_app.am

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri

object AndroidAlarms {
    fun register(context: Context, taskUid: String, runKey: String, triggerAt: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val action = "com.example.quote_app.ALARM.$" + taskUid
        val data = Uri.parse("quote://alarm/$" + taskUid + "/$" + runKey)
        val req = taskUid.hashCode() xor runKey.hashCode()

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            setAction(action); setData(data)
            putExtra("task_uid", taskUid)
            putExtra("run_key", runKey)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pi = PendingIntent.getBroadcast(context, req, intent, flags)
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
    }
}
