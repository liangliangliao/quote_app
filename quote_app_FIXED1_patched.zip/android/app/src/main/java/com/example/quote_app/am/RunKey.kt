package com.example.quote_app.am

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object RunKey {
    private val fmt = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS")
    fun windowBefore(runKey: String, minutes: Long): Pair<String,String> {
        return try {
            val t = LocalDateTime.parse(runKey, fmt)
            val from = t.minusMinutes(minutes)
            fmt.format(from) to fmt.format(t)
        } catch (e: Throwable) {
            // 如果解析失败，直接返回原值
            runKey to runKey
        }
    }
}
