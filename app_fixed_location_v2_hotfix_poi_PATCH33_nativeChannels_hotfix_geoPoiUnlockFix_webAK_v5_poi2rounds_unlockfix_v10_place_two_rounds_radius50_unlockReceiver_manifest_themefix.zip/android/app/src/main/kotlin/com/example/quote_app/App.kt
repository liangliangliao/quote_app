package com.example.quote_app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Keep lightweight; channel registration happens in MainActivity.configureFlutterEngine
    }
}
