import 'package:flutter/material.dart';
import '../belief_dao.dart';
import 'belief_case_detail_page.dart';

class BeliefReviewPage extends StatefulWidget {
  final int caseId;
  final bool forceOpen;
  const BeliefReviewPage({super.key, required this.caseId, this.forceOpen = false});

  @override
  State<BeliefReviewPage> createState() => _BeliefReviewPageState();
}

class _BeliefReviewPageState extends State<BeliefReviewPage> {
  Map<String, Object?>? _case;
  final _facts = TextEditingController();
  final _moral = TextEditingController();
  bool _falsified = false;
  String _decision = 'reinforce';
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    _case = c;
    _facts.text = (c?['review_facts']?.toString() ?? '');
    _moral.text = (c?['review_moral']?.toString() ?? '');
    _falsified = (c?['review_falsified'] as int? ?? 0) == 1;
    final d = (c?['decision']?.toString() ?? '');
    if (d == 'revise') _decision = 'revise';
    if (d == 'abandon') _decision = 'abandon';
    setState(() { _loading = false; });
  }

  @override
  void dispose() {
    _facts.dispose();
    _moral.dispose();
    super.dispose();
  }

  bool get _ready => _facts.text.trim().isNotEmpty && _moral.text.trim().isNotEmpty;

  bool get _isDue {
    final endMs = _case?['end_date_ms'] as int?;
    if (endMs == null || endMs <= 0) return true;
    final end = DateTime.fromMillisecondsSinceEpoch(endMs);
    final today = DateTime.now();
    final t = DateTime(today.year, today.month, today.day);
    final e = DateTime(end.year, end.month, end.day);
    return !t.isBefore(e);
  }

  String _decisionLabel(String v) {
    switch (v) {
      case 'reinforce':
        return '加固信念';
      case 'revise':
        return '修正信念';
      case 'abandon':
        return '放弃信念';
      default:
        return v;
    }
  }

  Future<void> _submit() async {
    if (!_ready) return;
    if (!widget.forceOpen && !_isDue) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('还未到期（你仍可在“行动进行中”页选择提前复盘）')));
      return;
    }

    setState(() { _saving = true; });
    try {
      await BeliefDao().finishReview(
        widget.caseId,
        facts: _facts.text,
        moral: _moral.text,
        falsified: _falsified,
        decision: _decision,
      );
      await BeliefDao().addLog(widget.caseId, kind: 'review', text: 'Review done: $_decision');

      if (!mounted) return;

      if (_decision == 'revise') {
        final newId = await BeliefDao().forkNewVersion(widget.caseId);
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => BeliefCaseDetailPage(caseId: newId)),
          (route) => route.isFirst,
        );
      } else {
        Navigator.of(context).pop(true);
      }
    } catch (_) {
      if (!mounted) return;
      setState(() { _saving = false; });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('保存失败，请重试')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('复盘与决断')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final c = _case;
    if (c == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('复盘与决断')),
        body: const Center(child: Text('未找到该案子')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('复盘与决断（Step 5）')),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('你的下注', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text(c['bet_text']?.toString() ?? '', style: const TextStyle(fontSize: 13, height: 1.4)),
                  const SizedBox(height: 10),
                  const Text('反证条件', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text(c['falsification']?.toString() ?? '', style: const TextStyle(fontSize: 13, height: 1.4)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _textBlock(
            title: '1) 事实发生了什么？（可核验事件）',
            hint: '只写事实：发生了什么、何时、证据是什么。',
            controller: _facts,
          ),
          const SizedBox(height: 10),
          _textBlock(
            title: '2) 对责任 / 尊严 / 关系的影响是什么？',
            hint: '把“道德后果”说清楚：你更诚实了吗？更守住边界了吗？关系更清晰了吗？',
            controller: _moral,
          ),
          const SizedBox(height: 10),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Expanded(child: Text('是否触发反证条件？', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600))),
                  Switch(value: _falsified, onChanged: (v) => setState(() { _falsified = v; })),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('决断（必选）', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  _radio('reinforce'),
                  _radio('revise'),
                  _radio('abandon'),
                  const SizedBox(height: 8),
                  const Text('提示：无论选哪一项，你都完成了一次真实的决定。', style: TextStyle(fontSize: 12, height: 1.35)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _saving ? null : (_ready ? _submit : null),
              child: _saving
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('保存复盘并决断'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _radio(String value) {
    return RadioListTile<String>(
      value: value,
      groupValue: _decision,
      onChanged: (v) {
        if (v == null) return;
        setState(() { _decision = v; });
      },
      title: Text(_decisionLabel(value)),
    );
  }

  Widget _textBlock({
    required String title,
    required String hint,
    required TextEditingController controller,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              maxLines: null,
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                hintText: hint,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
