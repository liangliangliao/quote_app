import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// 新建信念案子：写下困境 + 情绪强度
///
/// - 困境文本是后续所有步骤的上下文。
/// - 情绪强度用于风控：>=80 时强制 24h 冷却后才能下注。
class BeliefContextPage extends StatefulWidget {
  const BeliefContextPage({super.key});

  @override
  State<BeliefContextPage> createState() => _BeliefContextPageState();
}

class _BeliefContextPageState extends State<BeliefContextPage> {
  final TextEditingController _controller = TextEditingController();
  double _emotion = 50;
  bool _submitting = false;

  bool get _ready => _controller.text.trim().isNotEmpty && !_submitting;

  ({bool blocked, String? note}) _riskScan(String text) {
    final t = text.toLowerCase();
    const kws = <String>[
      '自杀',
      '想死',
      '不想活',
      '结束生命',
      '割腕',
      '跳楼',
      '服毒',
      '伤害自己',
      '杀人',
      '爆炸',
    ];
    for (final k in kws) {
      if (t.contains(k)) {
        return (blocked: true, note: '检测到高风险关键词：$k');
      }
    }
    return (blocked: false, note: null);
  }

  Future<void> _showSafetyDialog(String note) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('安全提示'),
        content: Text(
          '系统检测到可能的高风险内容（$note）。为了安全，本模块不会继续引导你做“下注/行动”类决策。\n\n'
          '如果你有立即伤害自己或他人的风险，请立刻联系当地紧急服务。\n'
          '在日本可拨打：110（警察）/119（急救消防）。\n\n'
          '如果不是紧急情况，也建议尽快联系你信任的人或专业心理支持资源。',
        ),
        actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('知道了'))],
      ),
    );
  }

  Future<void> _submit() async {
    if (!_ready) return;
    setState(() => _submitting = true);
    final txt = _controller.text.trim();
    final risk = _riskScan(txt);

    final now = DateTime.now().millisecondsSinceEpoch;
    final emo = _emotion.round();
    final cooldownUntil = emo >= 80 ? now + const Duration(hours: 24).inMilliseconds : null;

    final caseId = await BeliefDao().createDraftCase(
      contextText: txt,
      emotionIntensity: emo,
      cooldownUntilMs: cooldownUntil,
      riskBlocked: risk.blocked,
      riskNote: risk.note,
    );

    if (!mounted) return;

    if (risk.blocked) {
      await _showSafetyDialog(risk.note ?? '');
    } else if (cooldownUntil != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已记录情绪强度≥80：将强制24小时冷却后才能下注。')),
      );
    }

    Navigator.of(context).pop(caseId);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('新建信念案子')),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          const Text(
            '写下你正在纠结的困境或决定（尽量事实化）。\n'
            '下一步会判断它是否属于威廉·詹姆斯所说的“真选项”。',
            style: TextStyle(height: 1.35),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _controller,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: '困境/问题描述',
              hintText: '例：我是否要接受这个工作机会？\n现状/约束/我担心的后果分别是什么？',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 16),

          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('当前情绪强度（0-100）', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text('$_emotion', style: const TextStyle(fontSize: 12)),
                  Slider(
                    value: _emotion,
                    min: 0,
                    max: 100,
                    divisions: 100,
                    label: _emotion.round().toString(),
                    onChanged: (v) => setState(() => _emotion = v),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    '≥80：系统将强制 24h 冷却后才能下注（避免把情绪当证据）。',
                    style: TextStyle(fontSize: 12, height: 1.3),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),
          FilledButton(
            onPressed: _ready ? _submit : null,
            child: _submitting
                ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('创建案子'),
          ),
        ],
      ),
    );
  }
}
