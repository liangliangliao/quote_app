import 'package:flutter/material.dart';
import '../belief_dao.dart';
import 'belief_context_page.dart';
import 'belief_case_detail_page.dart';
import 'belief_history_page.dart';

class BeliefHomePage extends StatefulWidget {
  const BeliefHomePage({super.key});

  @override
  State<BeliefHomePage> createState() => _BeliefHomePageState();
}

class _BeliefHomePageState extends State<BeliefHomePage> {
  Map<String, dynamic>? _active;
  bool _loading = true;

  Future<void> _reload() async {
    setState(() { _loading = true; });
    try {
      await BeliefDao().ensureSchema();
      final a = await BeliefDao().getLatestActiveCase();
      if (!mounted) return;
      setState(() { _active = a; _loading = false; });
    } catch (_) {
      if (!mounted) return;
      setState(() { _active = null; _loading = false; });
    }
  }

  @override
  void initState() {
    super.initState();
    _reload();
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'draft': return '草案';
      case 'bet': return '已下注';
      case 'in_progress': return '行动中';
      case 'reinforced': return '已加固';
      case 'revised': return '已修正';
      case 'abandoned': return '已放弃';
      case 'stopped': return '已退出';
      default: return s;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('信念决策（Belief OS）'),
        actions: [
          IconButton(
            onPressed: _reload,
            icon: const Icon(Icons.refresh),
            tooltip: '刷新',
          )
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
              children: [
                _buildIntro(context),
                const SizedBox(height: 12),
                _buildActiveCard(context),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () async {
                          final id = await Navigator.of(context).push<int>(
                            MaterialPageRoute(builder: (_) => const BeliefContextPage()),
                          );
                          if (id != null) {
                            await _reload();
                            if (!context.mounted) return;
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => BeliefCaseDetailPage(caseId: id)),
                            );
                          }
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('开始一个新案子'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const BeliefHistoryPage()),
                    );
                  },
                  icon: const Icon(Icons.history),
                  label: const Text('查看全部信念历史'),
                ),
                const SizedBox(height: 16),
                _buildHowTo(context),
              ],
            ),
    );
  }

  Widget _buildIntro(BuildContext context) {
    return const Text(
      '定位：在证据不完备但必须行动的情境中，帮助你做出「可承担、可行动、可复盘」的信念下注。\n\n核心循环：信念 → 行动 → 后果 → 修正。',
      style: TextStyle(fontSize: 14, height: 1.45),
    );
  }

  Widget _buildActiveCard(BuildContext context) {
    final a = _active;
    if (a == null) {
      return Card(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: const Padding(
          padding: EdgeInsets.all(16),
          child: Text('当前没有进行中的案子。你可以开始一个新的「真选项」流程。'),
        ),
      );
    }
    final id = (a['id'] as num?)?.toInt() ?? int.tryParse(a['id']?.toString() ?? '') ?? 0;
    final status = _statusLabel(a['status']?.toString() ?? '');
    final ctx = (a['context_text']?.toString() ?? '').trim();
    final ver = (a['version'] is num) ? (a['version'] as num).toInt() : (int.tryParse(a['version']?.toString() ?? '') ?? 1);
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.psychology_alt),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '当前案子（v$ver） · $status',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              ctx.isEmpty ? '（未填写困境）' : ctx,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, height: 1.4),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => BeliefCaseDetailPage(caseId: id)),
                      ).then((_) => _reload());
                    },
                    child: const Text('继续'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => BeliefCaseDetailPage(caseId: id, openHistory: true)),
                      ).then((_) => _reload());
                    },
                    child: const Text('查看详情'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildHowTo(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: const Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          '使用规则（非常重要）：\n'
          '1) 一次只跑一个案子（并行会稀释锋利度）。\n'
          '2) 不到期不复盘（防止提前内耗）。\n'
          '3) 允许放弃（放弃 ≠ 失败，是结论）。\n'
          '4) 进行中只记录事实，不做解释；解释留到复盘。',
          style: TextStyle(fontSize: 13, height: 1.45),
        ),
      ),
    );
  }
}
