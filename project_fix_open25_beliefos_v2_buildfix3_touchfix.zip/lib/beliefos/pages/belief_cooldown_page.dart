import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// 冷却页：情绪强度过高时，强制延迟下注。
///
/// 这是 PRD 的风控机制：避免把“强情绪”当成“强证据”。
class BeliefCooldownPage extends StatefulWidget {
  final int caseId;
  const BeliefCooldownPage({super.key, required this.caseId});

  @override
  State<BeliefCooldownPage> createState() => _BeliefCooldownPageState();
}

class _BeliefCooldownPageState extends State<BeliefCooldownPage> {
  bool _loading = true;
  Map<String, Object?>? _case;

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    setState(() {
      _case = c;
      _loading = false;
    });
  }

  Duration? _left() {
    final c = _case;
    if (c == null) return null;
    final until = c['cooldown_until_ms'] as int?;
    if (until == null || until <= 0) return null;
    final left = until - DateTime.now().millisecondsSinceEpoch;
    if (left <= 0) return null;
    return Duration(milliseconds: left);
  }

  Future<void> _addFactLog() async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('记录事实（可选）'),
        content: TextField(
          controller: ctl,
          maxLines: 5,
          decoration: const InputDecoration(hintText: '只记事实，不评判。\n例：对方在会上拒绝书面确认变更。'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('保存')),
        ],
      ),
    );
    if (ok != true) return;
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    await BeliefDao().addLog(widget.caseId, kind: 'fact', text: t);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final c = _case;
    if (c == null) {
      return const Scaffold(body: Center(child: Text('案子不存在')));
    }
    final intensity = c['emotion_intensity'] as int?;
    final left = _left();
    final h = left == null ? 0 : left.inHours;
    final m = left == null ? 0 : (left.inMinutes % 60);

    return Scaffold(
      appBar: AppBar(title: const Text('冷却中')),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('情绪强度：${intensity ?? '-'} / 100', style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Text(
                    left == null
                        ? '冷却期已结束。返回案子即可继续下注。'
                        : '距离允许下注还有：${h}h ${m}m',
                    style: const TextStyle(fontSize: 14),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    '说明：当情绪很强时，大脑更容易把“紧张/兴奋/愤怒”误读成“事实证据”。\n\n这里强制延迟下注，先让情绪降温，再决定是否把信念写进现实。',
                    style: TextStyle(fontSize: 12, height: 1.35),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('返回案子'),
                ),
              ),
              const SizedBox(width: 12),
              OutlinedButton(
                onPressed: _addFactLog,
                child: const Text('记录事实'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
