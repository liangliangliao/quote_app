import 'package:flutter/material.dart';
import 'will_unblock_page.dart';
import 'will_brake_page.dart';

class WillCheckPage extends StatelessWidget {
  final int caseId;
  const WillCheckPage({super.key, required this.caseId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('意志体检')),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          const Text(
            '当信念已成立、行动也合理，但你出现“做不出来 / 停不下来”时，用这一组页面把注意力、同意与努力压缩成一个你现在就能完成的动作。',
            style: TextStyle(fontSize: 13, height: 1.4),
          ),
          const SizedBox(height: 12),
          _card(
            context,
            title: '阻塞型',
            subtitle: '我知道该做什么，但就是启动不了\n拖延、犹豫、想太多、迟迟不开始',
            icon: Icons.lock_clock,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => WillUnblockPage(caseId: caseId)),
              );
            },
          ),
          const SizedBox(height: 12),
          _card(
            context,
            title: '爆裂型',
            subtitle: '我经常一下子就做了，事后后悔\n冲动、失控、说完/做完才意识到后果',
            icon: Icons.flash_on,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => WillBrakePage(caseId: caseId)),
              );
            },
          ),
          const SizedBox(height: 20),
          const Text(
            '提示：两种都不是“性格问题”，只是不同的意志失衡。',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _card(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
