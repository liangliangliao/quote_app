import 'package:flutter/material.dart';
import '../../belief_dao.dart';
import 'will_consent_timer_page.dart';

class WillBrakePage extends StatefulWidget {
  final int caseId;
  const WillBrakePage({super.key, required this.caseId});

  @override
  State<WillBrakePage> createState() => _WillBrakePageState();
}

class _WillBrakePageState extends State<WillBrakePage> {
  int _seconds = 90;
  bool _saving = false;

  Future<Map<String, Object?>?> _load() async {
    await BeliefDao().ensureSchema();
    return BeliefDao().getCase(widget.caseId);
  }

  Future<void> _go(Map<String, Object?>? c) async {
    setState(() { _saving = true; });
    await BeliefDao().addLog(widget.caseId, kind: 'will_brake', text: 'delay=${_seconds}s');
    if (!mounted) return;
    final cost = (c?['bet_cost']?.toString() ?? '').trim();
    final fals = (c?['falsification']?.toString() ?? '').trim();
    final subtitle = '读一遍你的下注代价与反证条件：\n\n代价：${cost.isEmpty ? '(未填写)' : cost}\n\n反证条件：${fals.isEmpty ? '(未填写)' : fals}';

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => WillConsentTimerPage(
          caseId: widget.caseId,
          seconds: _seconds,
          title: '加刹车（${_seconds}s）',
          nextAction: '计时结束后，再决定是否执行当前动作。',
          subtitle: subtitle,
        ),
      ),
    );
    setState(() { _saving = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('爆裂型：加刹车稳定')),
      body: FutureBuilder<Map<String, Object?>?>(
        future: _load(),
        builder: (context, snap) {
          final c = snap.data;
          return ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
            children: [
              const Text('我们不是压抑冲动，而是让“后果”上桌：在放电前插入一个短暂延迟，让抑制联想有时间出现。', style: TextStyle(fontSize: 13, height: 1.4)),
              const SizedBox(height: 12),
              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('步骤 1｜选择延迟时间', style: TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: [
                          ChoiceChip(
                            label: const Text('30 秒'),
                            selected: _seconds == 30,
                            onSelected: (_) => setState(() { _seconds = 30; }),
                          ),
                          ChoiceChip(
                            label: const Text('90 秒'),
                            selected: _seconds == 90,
                            onSelected: (_) => setState(() { _seconds = 90; }),
                          ),
                          ChoiceChip(
                            label: const Text('2 分钟'),
                            selected: _seconds == 120,
                            onSelected: (_) => setState(() { _seconds = 120; }),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('步骤 2｜让后果上桌（重读）', style: TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Text('代价：${(c?['bet_cost']?.toString() ?? '').trim().isEmpty ? '(未填写)' : (c?['bet_cost']?.toString() ?? '').trim()}'),
                      const SizedBox(height: 8),
                      Text('反证条件：${(c?['falsification']?.toString() ?? '').trim().isEmpty ? '(未填写)' : (c?['falsification']?.toString() ?? '').trim()}'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saving ? null : () => _go(c),
                  child: _saving
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text('计时开始（${_seconds}s）'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
