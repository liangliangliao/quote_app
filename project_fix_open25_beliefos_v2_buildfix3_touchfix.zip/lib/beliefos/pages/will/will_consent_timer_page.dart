import 'dart:async';

import 'package:flutter/material.dart';
import '../../belief_dao.dart';

class WillConsentTimerPage extends StatefulWidget {
  final int caseId;
  final int seconds;
  final String title;
  final String nextAction;
  final String? subtitle;

  const WillConsentTimerPage({
    super.key,
    required this.caseId,
    required this.seconds,
    required this.title,
    required this.nextAction,
    this.subtitle,
  });

  @override
  State<WillConsentTimerPage> createState() => _WillConsentTimerPageState();
}

class _WillConsentTimerPageState extends State<WillConsentTimerPage> {
  int _remaining = 0;
  Timer? _timer;
  Map<String, Object?>? _case;

  @override
  void initState() {
    super.initState();
    _remaining = widget.seconds;
    _load();
    _start();
  }

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    setState(() {
      _case = c;
    });
  }

  void _start() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        _remaining = (_remaining - 1).clamp(0, widget.seconds);
      });
      if (_remaining <= 0) {
        t.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bet = (_case?['bet_text']?.toString() ?? '').trim();
    final betLine = bet.isEmpty ? '(尚未填写下注句)' : bet;

    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          const Text(
            '我同意在这段时间里，把注意力给到这件事。\n不需要感觉良好，只需要保持注意力。',
            style: TextStyle(fontSize: 13, height: 1.4),
          ),
          if (widget.subtitle != null) ...[
            const SizedBox(height: 10),
            Text(widget.subtitle!, style: const TextStyle(fontSize: 12, height: 1.4)),
          ],
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Text(
                      _remaining > 0 ? '$_remaining s' : '完成',
                      style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text('我的下注：', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(betLine),
                  const SizedBox(height: 12),
                  const Text('下一步动作：', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(widget.nextAction),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (_remaining <= 0) ...[
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('完成，返回上一页'),
              ),
            ),
          ] else ...[
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _start,
                child: const Text('重新开始'),
              ),
            )
          ]
        ],
      ),
    );
  }
}
