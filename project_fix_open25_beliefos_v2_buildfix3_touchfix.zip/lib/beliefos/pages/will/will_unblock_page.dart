import 'package:flutter/material.dart';
import '../../belief_dao.dart';
import 'will_consent_timer_page.dart';

class WillUnblockPage extends StatefulWidget {
  final int caseId;
  const WillUnblockPage({super.key, required this.caseId});

  @override
  State<WillUnblockPage> createState() => _WillUnblockPageState();
}

class _WillUnblockPageState extends State<WillUnblockPage> {
  String _resistance = '不知道从哪一步开始';
  final _smallStep = TextEditingController();
  bool _allowRough = false;
  bool _saving = false;

  @override
  void dispose() {
    _smallStep.dispose();
    super.dispose();
  }

  bool get _ready => _smallStep.text.trim().isNotEmpty && _allowRough;

  Future<void> _go() async {
    if (!_ready) return;
    setState(() { _saving = true; });
    await BeliefDao().addLog(widget.caseId, kind: 'will_unblock', text: 'resistance=$_resistance; step=${_smallStep.text.trim()}');
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => WillConsentTimerPage(
          caseId: widget.caseId,
          seconds: 30,
          title: '同意与注意力（30秒）',
          nextAction: _smallStep.text.trim(),
        ),
      ),
    );
    setState(() { _saving = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('阻塞型：降阻力启动')),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          const Text('不是不够努力，而是启动成本太高。我们把行动拆到“小到不需要勇气”。', style: TextStyle(fontSize: 13, height: 1.4)),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('步骤 1｜当前最大阻力是什么？', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: _resistance,
                    items: const [
                      DropdownMenuItem(value: '害怕后果', child: Text('害怕后果')),
                      DropdownMenuItem(value: '想一次做到位', child: Text('想一次做到位')),
                      DropdownMenuItem(value: '不知道从哪一步开始', child: Text('不知道从哪一步开始')),
                      DropdownMenuItem(value: '情绪抗拒', child: Text('情绪抗拒')),
                    ],
                    onChanged: (v) => setState(() { _resistance = v ?? _resistance; }),
                    decoration: const InputDecoration(border: OutlineInputBorder()),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('步骤 2｜把行动缩小到“荒谬地小”', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _smallStep,
                    maxLines: null,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: '示例：只写一句边界 / 只打开文档 / 只走出门30秒',
                    ),
                  ),
                  const SizedBox(height: 10),
                  CheckboxListTile(
                    value: _allowRough,
                    onChanged: (v) => setState(() { _allowRough = v ?? false; }),
                    title: const Text('步骤 3｜我允许这一步是粗糙的、不完整的'),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _saving ? null : (_ready ? _go : null),
              child: _saving
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('现在开始这一步'),
            ),
          ),
        ],
      ),
    );
  }
}
