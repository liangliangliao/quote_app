import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 9: 行动试点（两周最小可检验行动）
///
/// This page also embeds "Variation × Chooser" (James Ch.6) fields so that
/// the pilot is treated as an experiment design, not a vague intention.
class BeliefActionPilotPage extends StatefulWidget {
  final int caseId;
  const BeliefActionPilotPage({super.key, required this.caseId});

  @override
  State<BeliefActionPilotPage> createState() => _BeliefActionPilotPageState();
}

class _BeliefActionPilotPageState extends State<BeliefActionPilotPage> {
  bool _loading = true;
  bool _saving = false;

  String _scenario = '工作';
  DateTime _start = DateTime.now();
  DateTime _end = DateTime.now().add(const Duration(days: 14));

  final _variations = TextEditingController();
  final _chooserWho = TextEditingController();
  final _chooserConcerns = TextEditingController();
  final _plan = TextEditingController();

  @override
  void dispose() {
    _variations.dispose();
    _chooserWho.dispose();
    _chooserConcerns.dispose();
    _plan.dispose();
    super.dispose();
  }

  bool get _ready {
    return _variations.text.trim().isNotEmpty &&
        _chooserWho.text.trim().isNotEmpty &&
        _chooserConcerns.text.trim().isNotEmpty &&
        _plan.text.trim().isNotEmpty;
  }

  Future<void> _load() async {
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    if (c != null) {
      _scenario = (c['scenario']?.toString().trim().isNotEmpty ?? false)
          ? c['scenario']!.toString()
          : ((c['scenario']?.toString() ?? '').isNotEmpty ? c['scenario']!.toString() : _scenario);

      _variations.text = (c['variation_options']?.toString() ?? '').trim();
      _chooserWho.text = (c['chooser_who']?.toString() ?? '').trim();
      _chooserConcerns.text = (c['chooser_concerns']?.toString() ?? '').trim();
      _plan.text = (c['action_plan']?.toString() ?? '').trim();

      final sMs = c['start_date_ms'] as int?;
      final eMs = c['end_date_ms'] as int?;
      if (sMs != null && sMs > 0) {
        _start = DateTime.fromMillisecondsSinceEpoch(sMs);
      }
      if (eMs != null && eMs > 0) {
        _end = DateTime.fromMillisecondsSinceEpoch(eMs);
      } else {
        _end = _start.add(const Duration(days: 14));
      }

      // If the pilot isn't defined yet, seed with a reasonable default plan.
      if (_plan.text.isEmpty) {
        _plan.text = _seedPlan(c);
      }
      if (_variations.text.isEmpty) {
        _variations.text = _seedVariations(c);
      }
      if (_chooserWho.text.isEmpty) {
        _chooserWho.text = _seedChooser(c);
      }
      if (_chooserConcerns.text.isEmpty) {
        _chooserConcerns.text = _seedChooserConcerns(c);
      }
    }

    setState(() => _loading = false);
  }

  String _seedPlan(Map<String, Object?> c) {
    final bet = (c['bet_text']?.toString() ?? '').trim();
    if (bet.isEmpty) {
      return '行动目标（可检验）：\n-（写清你要验证什么）\n\n行动内容（2–3条）：\n1. \n2. \n3. \n\n复盘指标（事实）：\n- 发生次数 / 结果 / 反证条件是否触发';
    }
    return '行动目标（可检验）：\n测试“$bet”是否在两周内获得现实支持。\n\n行动内容（2–3条）：\n1. \n2. \n3. \n\n复盘指标（事实）：\n- 关键事件/次数\n- 是否触发反证条件';
  }

  String _seedVariations(Map<String, Object?> c) {
    return '我能提出的新方案（至少2个）：\n- 方案A：\n- 方案B：';
  }

  String _seedChooser(Map<String, Object?> c) {
    return '谁决定采纳/改变？（例如：我、对方、领导、系统）';
  }

  String _seedChooserConcerns(Map<String, Object?> c) {
    return '他们最在意什么？（成本/风险/面子/效率/关系/规则/结果）';
  }

  Future<void> _pickStart() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _start,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
    );
    if (picked == null) return;
    setState(() {
      _start = DateTime(picked.year, picked.month, picked.day);
      if (_end.isBefore(_start)) {
        _end = _start.add(const Duration(days: 14));
      }
    });
  }

  Future<void> _pickEnd() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _end,
      firstDate: _start,
      lastDate: _start.add(const Duration(days: 365)),
    );
    if (picked == null) return;
    setState(() {
      _end = DateTime(picked.year, picked.month, picked.day);
    });
  }

  Future<void> _save() async {
    if (!_ready) return;
    setState(() => _saving = true);
    try {
      await BeliefDao().setVariationChooser(
        widget.caseId,
        variations: _variations.text.trim(),
        chooserWho: _chooserWho.text.trim(),
        chooserConcerns: _chooserConcerns.text.trim(),
      );
      await BeliefDao().startPilot(
        widget.caseId,
        scenario: _scenario,
        planText: _plan.text.trim(),
        start: _start,
        end: _end,
      );
      await BeliefDao().addLog(widget.caseId, kind: 'pilot_start', text: 'scenario=$_scenario; start=$_start; end=$_end');
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('保存失败，请重试')));
    }
  }

  String _fmtDate(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('行动试点（Step 9）')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
              children: [
                const Text(
                  '把信念压缩为两周内可执行、可复盘的试点。\n\n原则：不是“变好”，而是“做一次现实检验”。',
                  style: TextStyle(fontSize: 13, height: 1.4),
                ),
                const SizedBox(height: 12),
                _sectionTitle('场景'),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: '工作', label: Text('工作'), icon: Icon(Icons.work_outline)),
                    ButtonSegment(value: '关系', label: Text('关系'), icon: Icon(Icons.favorite_border)),
                    ButtonSegment(value: '人生', label: Text('人生'), icon: Icon(Icons.route)),
                  ],
                  selected: {_scenario},
                  onSelectionChanged: (s) => setState(() => _scenario = s.first),
                ),
                const SizedBox(height: 16),

                _sectionTitle('变异 × 选择分析（Step 6）'),
                const Text('把“改变”当成工程：先提出变异，再看谁会采纳、在意什么。', style: TextStyle(fontSize: 12, height: 1.35)),
                const SizedBox(height: 8),
                TextField(
                  controller: _variations,
                  maxLines: null,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '变异：我能提出的新方案？'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _chooserWho,
                  maxLines: null,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '选择者：谁决定采纳/改变？'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _chooserConcerns,
                  maxLines: null,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '他们最在意什么？'),
                ),
                const SizedBox(height: 16),

                _sectionTitle('两周行动试点（核心）'),
                TextField(
                  controller: _plan,
                  maxLines: null,
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '行动草案（可编辑）'),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _pickStart,
                        child: Text('开始：${_fmtDate(_start)}'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _pickEnd,
                        child: Text('结束：${_fmtDate(_end)}'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _saving ? null : (_ready ? _save : null),
                    child: _saving
                        ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('确认并开始试点'),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
    );
  }
}
