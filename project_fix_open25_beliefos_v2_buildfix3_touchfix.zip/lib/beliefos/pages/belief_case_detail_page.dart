import 'package:flutter/material.dart';

import '../belief_dao.dart';
import 'belief_action_pilot_page.dart';
import 'belief_anti_narrative_page.dart';
import 'belief_bet_page.dart';
import 'belief_cooldown_page.dart';
import 'belief_expectation_audit_page.dart';
import 'belief_fork_map_page.dart';
import 'belief_in_progress_page.dart';
import 'belief_leverage_radar_page.dart';
import 'belief_moral_energy_page.dart';
import 'belief_rationality_check_page.dart';
import 'belief_review_page.dart';
import 'belief_stakes_page.dart';
import 'belief_true_option_page.dart';
import 'will/will_check_page.dart';

class BeliefCaseDetailPage extends StatefulWidget {
  final int caseId;
  final bool openHistory;
  const BeliefCaseDetailPage({super.key, required this.caseId, this.openHistory = false});

  @override
  State<BeliefCaseDetailPage> createState() => _BeliefCaseDetailPageState();
}

class _BeliefCaseDetailPageState extends State<BeliefCaseDetailPage> {
  bool _loading = true;
  Map<String, Object?>? _case;
  List<Map<String, Object?>> _logs = const [];

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    final logs = await BeliefDao().listLogs(widget.caseId);
    if (!mounted) return;
    setState(() {
      _case = c;
      _logs = logs;
      _loading = false;
    });
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'draft':
        return '草案';
      case 'in_progress':
        return '行动中';
      case 'reinforced':
        return '已加固';
      case 'revised':
        return '已修正';
      case 'abandoned':
        return '已放弃';
      case 'stopped':
        return '已退出';
      case 'blocked':
        return '已拦截（高风险）';
      default:
        return s;
    }
  }

  bool _isBlank(Object? v) => (v?.toString().trim().isEmpty ?? true);

  bool _hasTrueOption(Map<String, Object?> c) {
    return (c['is_live'] as int? ?? 0) == 1 &&
        (c['is_forced'] as int? ?? 0) == 1 &&
        (c['is_momentous'] as int? ?? 0) == 1;
  }

  bool _hasStakes(Map<String, Object?> c) {
    return !_isBlank(c['stake_inaction_worst']) &&
        !_isBlank(c['stake_inaction_likely']) &&
        !_isBlank(c['stake_action_cost']);
  }

  bool _hasExpectation(Map<String, Object?> c) {
    return !_isBlank(c['expectation_default']) &&
        !_isBlank(c['expectation_attention']) &&
        !_isBlank(c['expectation_behavior']) &&
        !_isBlank(c['expectation_interpretation']) &&
        !_isBlank(c['optimism_anchor']) &&
        !_isBlank(c['reality_constraint']) &&
        !_isBlank(c['effort_anchor']);
  }

  bool _hasBet(Map<String, Object?> c) {
    return !_isBlank(c['bet_text']) &&
        !_isBlank(c['bet_cost']) &&
        !_isBlank(c['falsification']);
  }

  bool _hasRationality(Map<String, Object?> c) {
    return !_isBlank(c['rationality_comfort']) &&
        !_isBlank(c['rationality_uncomfortable_questions']);
  }

  bool _hasForkMap(Map<String, Object?> c) {
    return !_isBlank(c['fork_fixed']) &&
        !_isBlank(c['fork_variable']) &&
        !_isBlank(c['fork_min_step']);
  }

  bool _hasMoralEnergy(Map<String, Object?> c) {
    return !_isBlank(c['moral_mode']) &&
        !_isBlank(c['moral_stop_bleed']) &&
        !_isBlank(c['moral_treat_root']) &&
        !_isBlank(c['moral_higher_loyalty']);
  }

  bool _hasLeverage(Map<String, Object?> c) {
    return !_isBlank(c['leverage_trunk']) &&
        !_isBlank(c['leverage_soft_layer']) &&
        !_isBlank(c['leverage_micro_actions']);
  }

  bool _hasAntiNarrative(Map<String, Object?> c) {
    return !_isBlank(c['anti_next_week_action']) &&
        !_isBlank(c['anti_no_action_cost']) &&
        !_isBlank(c['anti_flattened_conflict']);
  }

  bool _hasPilot(Map<String, Object?> c) {
    return !_isBlank(c['scenario']) &&
        !_isBlank(c['action_plan']) &&
        (c['start_date_ms'] as int? ?? 0) > 0 &&
        (c['end_date_ms'] as int? ?? 0) > 0;
  }

  bool _isCooling(Map<String, Object?> c) {
    final until = c['cooldown_until_ms'] as int?;
    if (until == null || until <= 0) return false;
    return DateTime.now().millisecondsSinceEpoch < until;
  }

  Duration? _cooldownLeft(Map<String, Object?> c) {
    final until = c['cooldown_until_ms'] as int?;
    if (until == null || until <= 0) return null;
    final left = until - DateTime.now().millisecondsSinceEpoch;
    if (left <= 0) return null;
    return Duration(milliseconds: left);
  }

  Future<void> _addQuickLog() async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('记录关键事实（可选）'),
        content: TextField(
          controller: ctl,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: '只记事实，不评判。\n例：对方在会上拒绝书面确认变更。',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('保存')),
        ],
      ),
    );
    if (ok != true) return;
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    await BeliefDao().addLog(widget.caseId, kind: 'fact', text: t);
    await _load();
  }

  Future<void> _goNext() async {
    final c = _case;
    if (c == null) return;

    final status = (c['status']?.toString() ?? 'draft');
    if (status == 'blocked') {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('高风险输入已拦截'),
          content: Text(
            ((c['risk_note']?.toString() ?? '').trim().isEmpty)
                ? '此案子包含高风险内容。为了安全，本模块不会继续引导做下注/行动。\n\n如你有立即伤害自己或他人的风险，请立刻联系当地紧急服务。'
                : "原因：${c['risk_note']}\n\n如你有立即伤害自己或他人的风险，请立刻联系当地紧急服务。",
          ),
          actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('知道了'))],
        ),
      );
      return;
    }

    if (status == 'reinforced' ||
        status == 'revised' ||
        status == 'abandoned' ||
        status == 'stopped') {
      return;
    }

    if (!_hasTrueOption(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefTrueOptionPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasStakes(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefStakesPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasExpectation(c)) {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => BeliefExpectationAuditPage(caseId: widget.caseId)),
      );
      await _load();
      return;
    }

    if (_isCooling(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefCooldownPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasBet(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefBetPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasRationality(c)) {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => BeliefRationalityCheckPage(caseId: widget.caseId)),
      );
      await _load();
      return;
    }

    if (!_hasForkMap(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefForkMapPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasMoralEnergy(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefMoralEnergyPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasLeverage(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefLeverageRadarPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasAntiNarrative(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefAntiNarrativePage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (status == 'in_progress') {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefInProgressPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    if (!_hasPilot(c)) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BeliefActionPilotPage(caseId: widget.caseId)));
      await _load();
      return;
    }

    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => BeliefInProgressPage(caseId: widget.caseId)));
    await _load();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final c = _case;
    if (c == null) {
      return const Scaffold(body: Center(child: Text('案子不存在')));
    }

    final status = _statusLabel(c['status']?.toString() ?? '');
    final createdMs = c['created_at_ms'] as int?;
    final created = (createdMs == null)
        ? '-'
        : _fmtDate(DateTime.fromMillisecondsSinceEpoch(createdMs));
    final ctxText = (c['context_text']?.toString() ?? '').trim();
    final cooling = _isCooling(c);
    final left = _cooldownLeft(c);

    final steps = <_StepItem>[
      _StepItem('Step 1  真选项判定', _hasTrueOption(c)),
      _StepItem('Step 1.5  代价澄清（不做/去做）', _hasStakes(c)),
      _StepItem('Step 2  期待审计（Tal）', _hasExpectation(c)),
      _StepItem('Step 3  信念下注', _hasBet(c), blocked: cooling),
      _StepItem('Step 4  理性之感校验', _hasRationality(c)),
      _StepItem('Step 5  可变性与分叉', _hasForkMap(c)),
      _StepItem('Step 6  道德能量调度', _hasMoralEnergy(c)),
      _StepItem('Step 7  动态窄带雷达', _hasLeverage(c)),
      _StepItem('Step 8  反宏大叙事三问', _hasAntiNarrative(c)),
      _StepItem('Step 9  两周行动试点', _hasPilot(c)),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('信念案子'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => WillCheckPage(caseId: widget.caseId)),
              );
            },
            tooltip: '意志引擎',
            icon: const Icon(Icons.timer_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('状态：$status', style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text('创建：$created', style: const TextStyle(fontSize: 12)),
                  const SizedBox(height: 10),
                  const Text('困境', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(ctxText.isEmpty ? '(无文本)' : ctxText, style: const TextStyle(height: 1.35)),
                  if (cooling && left != null) ...[
                    const SizedBox(height: 12),
                    _cooldownBanner(left),
                  ],
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton(onPressed: _goNext, child: const Text('继续下一步')),
                      ),
                      const SizedBox(width: 12),
                      OutlinedButton(onPressed: _addQuickLog, child: const Text('记事实')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('步骤进度', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          ...steps.map(_stepTile),
          const SizedBox(height: 18),
          const Text('快速入口', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton(
                onPressed: () async {
                  await Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => BeliefReviewPage(caseId: widget.caseId)));
                  await _load();
                },
                child: const Text('复盘与决断'),
              ),
              OutlinedButton(
                onPressed: () async {
                  await Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => BeliefInProgressPage(caseId: widget.caseId)));
                  await _load();
                },
                child: const Text('行动进行中'),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text('最近记录', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          if (_logs.isEmpty)
            const Text('暂无记录', style: TextStyle(fontSize: 12))
          else
            ..._logs.take(6).map(_logTile),
        ],
      ),
    );
  }

  Widget _cooldownBanner(Duration left) {
    final h = left.inHours;
    final m = (left.inMinutes % 60);
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.shade200),
      ),
      child: Text(
        '冷却中：距离允许下注还有 ${h}h ${m}m。\n'
        '（情绪强度过高时，系统强制延迟下注，避免把情绪当证据。）',
        style: const TextStyle(fontSize: 12, height: 1.35),
      ),
    );
  }

  Widget _stepTile(_StepItem s) {
    final icon = s.done
        ? Icons.check_circle
        : (s.blocked ? Icons.lock_clock : Icons.radio_button_unchecked);
    final color = s.done ? Colors.green : (s.blocked ? Colors.orange : null);
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: color),
      title: Text(s.title, style: const TextStyle(fontSize: 13)),
      subtitle: s.blocked
          ? const Text('冷却期间暂不可下注', style: TextStyle(fontSize: 11))
          : null,
    );
  }

  Widget _logTile(Map<String, Object?> l) {
    final kind = (l['kind']?.toString() ?? '').trim();
    final text = (l['text']?.toString() ?? '').trim();
    final ts = l['ts_ms'] as int?;
    final time = ts == null ? '' : _fmtDateTime(DateTime.fromMillisecondsSinceEpoch(ts));
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        title: Text(kind.isEmpty ? '记录' : kind,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        subtitle: Text('$time\n$text',
            style: const TextStyle(fontSize: 12, height: 1.35)),
      ),
    );
  }

  String _fmtDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _fmtDateTime(DateTime d) =>
      '${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

class _StepItem {
  final String title;
  final bool done;
  final bool blocked;
  _StepItem(this.title, this.done, {this.blocked = false});
}
