import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 2: 期待审计（Tal Ben‑Shahar Lecture 5/6）
///
/// 目的：让“信念”从内心态度，落到注意力/互动/解释，
/// 并用「乐观锚 + 现实锚 + 行动锚」防止假乐观。
///
/// 额外（可选）：
/// - 皮格马利翁提示卡（self-fulfilling prophecy 的可执行版本）
/// - 仪式化启动（placebo 机制：把信念绑定到可重复的启动动作）
class BeliefExpectationAuditPage extends StatefulWidget {
  final int caseId;
  const BeliefExpectationAuditPage({super.key, required this.caseId});

  @override
  State<BeliefExpectationAuditPage> createState() => _BeliefExpectationAuditPageState();
}

class _BeliefExpectationAuditPageState extends State<BeliefExpectationAuditPage> {
  final _expectDefault = TextEditingController();
  final _attn = TextEditingController();
  final _beh = TextEditingController();
  final _interp = TextEditingController();
  final _optimism = TextEditingController();
  final _reality = TextEditingController();
  final _effort = TextEditingController();

  // Optional: Pygmalion prompt card
  final _pygPotential = TextEditingController();
  final _pygLightAction = TextEditingController();
  final _pygSignalTrack = TextEditingController();

  // Optional: Ritualized start
  final _ritualExpectation = TextEditingController();
  final _ritualAction = TextEditingController();
  final _ritualFeedback = TextEditingController();

  bool _saving = false;
  bool _showOptional = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted || c == null) return;

    _expectDefault.text = (c['expectation_default']?.toString() ?? '');
    _attn.text = (c['expectation_attention']?.toString() ?? '');
    _beh.text = (c['expectation_behavior']?.toString() ?? '');
    _interp.text = (c['expectation_interpretation']?.toString() ?? '');
    _optimism.text = (c['optimism_anchor']?.toString() ?? '');
    _reality.text = (c['reality_constraint']?.toString() ?? '');
    _effort.text = (c['effort_anchor']?.toString() ?? '');

    _pygPotential.text = (c['pyg_potential']?.toString() ?? '');
    _pygLightAction.text = (c['pyg_light_action']?.toString() ?? '');
    _pygSignalTrack.text = (c['pyg_signal_track']?.toString() ?? '');

    _ritualExpectation.text = (c['ritual_expectation']?.toString() ?? '');
    _ritualAction.text = (c['ritual_action']?.toString() ?? '');
    _ritualFeedback.text = (c['ritual_feedback']?.toString() ?? '');

    final hasOptional = _pygPotential.text.trim().isNotEmpty ||
        _pygLightAction.text.trim().isNotEmpty ||
        _pygSignalTrack.text.trim().isNotEmpty ||
        _ritualExpectation.text.trim().isNotEmpty ||
        _ritualAction.text.trim().isNotEmpty ||
        _ritualFeedback.text.trim().isNotEmpty;

    setState(() {
      _showOptional = hasOptional;
    });
  }

  @override
  void dispose() {
    _expectDefault.dispose();
    _attn.dispose();
    _beh.dispose();
    _interp.dispose();
    _optimism.dispose();
    _reality.dispose();
    _effort.dispose();

    _pygPotential.dispose();
    _pygLightAction.dispose();
    _pygSignalTrack.dispose();

    _ritualExpectation.dispose();
    _ritualAction.dispose();
    _ritualFeedback.dispose();
    super.dispose();
  }

  bool get _ready {
    return _expectDefault.text.trim().isNotEmpty &&
        _attn.text.trim().isNotEmpty &&
        _beh.text.trim().isNotEmpty &&
        _interp.text.trim().isNotEmpty &&
        _optimism.text.trim().isNotEmpty &&
        _reality.text.trim().isNotEmpty &&
        _effort.text.trim().isNotEmpty;
  }

  Future<void> _submit() async {
    if (!_ready) return;
    setState(() {
      _saving = true;
    });
    try {
      await BeliefDao().setExpectationAudit(
        widget.caseId,
        defaultExpectation: _expectDefault.text,
        attention: _attn.text,
        behavior: _beh.text,
        interpretation: _interp.text,
        optimismAnchor: _optimism.text,
        realityConstraint: _reality.text,
        effortAnchor: _effort.text,
        pygPotential: _pygPotential.text.trim().isEmpty ? null : _pygPotential.text,
        pygLightAction: _pygLightAction.text.trim().isEmpty ? null : _pygLightAction.text,
        pygSignalTrack: _pygSignalTrack.text.trim().isEmpty ? null : _pygSignalTrack.text,
        ritualExpectation: _ritualExpectation.text.trim().isEmpty ? null : _ritualExpectation.text,
        ritualAction: _ritualAction.text.trim().isEmpty ? null : _ritualAction.text,
        ritualFeedback: _ritualFeedback.text.trim().isEmpty ? null : _ritualFeedback.text,
      );
      await BeliefDao().addLog(widget.caseId, kind: 'expectation_audit', text: 'Expectation audit saved');
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('保存失败，请重试')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('期待审计（Step 2）')),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          const Text(
            'Tal Ben‑Shahar（哈佛积极心理学）强调：\n'
            '我们相信什么，会改变我们看见什么、如何对待人、如何解释结果，从而把现实推向那个方向（自我实现预言）。\n\n'
            '这一页的目标不是“许愿”，而是把期待变成可被校正的假设。',
            style: TextStyle(fontSize: 14, height: 1.45),
          ),
          const SizedBox(height: 12),
          _textBlock(
            title: '1) 你的默认期待是什么？（对自己/他人/环境）',
            hint: '例如：我在关系里通常会被忽视 / 领导不会认可我 / 我不适合做这个。',
            controller: _expectDefault,
          ),
          const SizedBox(height: 10),
          _textBlock(
            title: '2) 这种期待会让你选择性注意到什么？',
            hint: '例如：只注意到不被认可的细节、忽略支持信号。',
            controller: _attn,
          ),
          const SizedBox(height: 10),
          _textBlock(
            title: '3) 它会让你采取什么微行为？（语气/投入/边界/回避）',
            hint: '例如：更冷淡、更回避、更不敢提需求。',
            controller: _beh,
          ),
          const SizedBox(height: 10),
          _textBlock(
            title: '4) 你会如何解释结果？',
            hint: '例如：把中性事件解释为“又一次失败”，从而加固旧信念。',
            controller: _interp,
          ),
          const SizedBox(height: 16),
          const Text('反假乐观护栏（必须填）', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          _textBlock(
            title: '乐观锚：我愿意相信我能做成____',
            hint: '例如：我能在两周内推动边界被尊重。',
            controller: _optimism,
          ),
          const SizedBox(height: 10),
          _textBlock(
            title: '现实锚：目前最硬的约束是____',
            hint: '例如：权力结构、时间限制、资源不足。',
            controller: _reality,
          ),
          const SizedBox(height: 10),
          _textBlock(
            title: '行动锚：我愿意投入的努力是____（时间/次数/难度）',
            hint: '例如：14 天内做 2 次边界沟通 + 1 次记录与复盘。',
            controller: _effort,
          ),

          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('展开可选增强（皮格马利翁/仪式化）', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            subtitle: const Text('不影响流程，但能把“信念”变成更可执行的暗示与启动机制', style: TextStyle(fontSize: 12)),
            value: _showOptional,
            onChanged: (v) => setState(() => _showOptional = v),
          ),

          if (_showOptional) ...[
            const SizedBox(height: 8),
            _sectionTitle('皮格马利翁提示卡（可选）'),
            _textBlock(
              title: 'A) 我看见自己/对方的潜力是____',
              hint: '例：他其实愿意合作，只是害怕失控。',
              controller: _pygPotential,
            ),
            const SizedBox(height: 10),
            _textBlock(
              title: 'B) 我会用一个“轻动作”表达这种期待：____',
              hint: '例：先确认对方最担心的点，再提出一个小请求。',
              controller: _pygLightAction,
            ),
            const SizedBox(height: 10),
            _textBlock(
              title: 'C) 我会追踪哪些信号来校正期待？____',
              hint: '例：对方是否愿意给出可检验的承诺；会议纪要是否确认。',
              controller: _pygSignalTrack,
            ),
            const SizedBox(height: 16),
            _sectionTitle('仪式化启动（可选）'),
            _textBlock(
              title: 'A) 一句话信念：我愿意相信____',
              hint: '例：我可以用小步行动把局面推向更好。',
              controller: _ritualExpectation,
            ),
            const SizedBox(height: 10),
            _textBlock(
              title: 'B) 启动仪式动作（30~90 秒）',
              hint: '例：深呼吸 3 次 + 写下今天的最小一步 + 打开计时器。',
              controller: _ritualAction,
            ),
            const SizedBox(height: 10),
            _textBlock(
              title: 'C) 即时反馈（怎么知道它有效？）',
              hint: '例：我是否更愿意行动；是否减少拖延 5 分钟。',
              controller: _ritualFeedback,
            ),
          ],

          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _saving ? null : (_ready ? _submit : null),
              child: _saving
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('保存并返回'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
    );
  }

  Widget _textBlock({
    required String title,
    required String hint,
    required TextEditingController controller,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              maxLines: null,
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                hintText: hint,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
