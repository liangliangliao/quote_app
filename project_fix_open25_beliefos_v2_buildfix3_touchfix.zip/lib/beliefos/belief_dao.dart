import 'dart:async';

import 'package:sqflite/sqflite.dart';
import '../data/db.dart';

/// Belief OS local persistence (SQLite).
///
/// Stored in the shared `quotes.db` database. All migrations are performed
/// idempotently by [ensureSchema].
class BeliefDao {
  BeliefDao._();
  static final BeliefDao _instance = BeliefDao._();
  factory BeliefDao() => _instance;

  static const _tableCases = 'belief_cases';
  static const _tableLogs = 'belief_logs';

  Future<Database> _db() => AppDatabase.instance();

  Future<void> ensureSchema() async {
    final db = await _db();

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_tableCases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        parent_id INTEGER,
        version INTEGER DEFAULT 1,
        status TEXT DEFAULT 'draft',
        created_at_ms INTEGER NOT NULL,
        updated_at_ms INTEGER NOT NULL,

        context_text TEXT,

        -- basic safety / cooldown
        emotion_intensity INTEGER,
        cooldown_until_ms INTEGER,
        risk_blocked INTEGER DEFAULT 0,
        risk_note TEXT,

        -- James: True option
        is_live INTEGER,
        is_forced INTEGER,
        is_momentous INTEGER,

        -- Stakes (inaction/action costs)
        stake_inaction_worst TEXT,
        stake_inaction_likely TEXT,
        stake_action_cost TEXT,

        -- Tal: Expectation audit + guardrails
        expectation_default TEXT,
        expectation_attention TEXT,
        expectation_behavior TEXT,
        expectation_interpretation TEXT,
        optimism_anchor TEXT,
        reality_constraint TEXT,
        effort_anchor TEXT,
        pyg_potential TEXT,
        pyg_light_action TEXT,
        pyg_signal_track TEXT,
        ritual_expectation TEXT,
        ritual_action TEXT,
        ritual_feedback TEXT,

        -- James: Bet statement
        bet_text TEXT,
        bet_cost TEXT,
        falsification TEXT,

        -- James: Rationality "feeling" check
        rationality_comfort TEXT,
        rationality_uncomfortable_questions TEXT,

        -- James: Fork / variability
        fork_fixed TEXT,
        fork_variable TEXT,
        fork_min_step TEXT,

        -- James: Moral energy
        moral_mode TEXT,
        moral_stop_bleed TEXT,
        moral_treat_root TEXT,
        moral_higher_loyalty TEXT,

        -- James: Leverage radar (trunk/soft layer)
        leverage_trunk TEXT,
        leverage_soft_layer TEXT,
        leverage_micro_actions TEXT,

        -- James: Anti-grand-narrative
        anti_flag_words TEXT,
        anti_next_week_action TEXT,
        anti_no_action_cost TEXT,
        anti_flattened_conflict TEXT,

        -- James: Variation x chooser analysis (pilot design)
        variation_options TEXT,
        chooser_who TEXT,
        chooser_concerns TEXT,

        -- Action pilot
        scenario TEXT,
        action_plan TEXT,
        start_date_ms INTEGER,
        end_date_ms INTEGER,

        -- Review
        review_facts TEXT,
        review_moral TEXT,
        review_falsified INTEGER,
        decision TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_tableLogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id INTEGER NOT NULL,
        ts_ms INTEGER NOT NULL,
        kind TEXT,
        text TEXT
      )
    ''');

    // Ensure missing columns exist for old installs.
    await _ensureColumns(db, _tableCases, {
      'parent_id': 'INTEGER',
      'version': 'INTEGER DEFAULT 1',
      'status': "TEXT DEFAULT 'draft'",
      'created_at_ms': 'INTEGER',
      'updated_at_ms': 'INTEGER',
      'context_text': 'TEXT',
      'emotion_intensity': 'INTEGER',
      'cooldown_until_ms': 'INTEGER',
      'risk_blocked': 'INTEGER DEFAULT 0',
      'risk_note': 'TEXT',
      'is_live': 'INTEGER',
      'is_forced': 'INTEGER',
      'is_momentous': 'INTEGER',
      'stake_inaction_worst': 'TEXT',
      'stake_inaction_likely': 'TEXT',
      'stake_action_cost': 'TEXT',
      'expectation_default': 'TEXT',
      'expectation_attention': 'TEXT',
      'expectation_behavior': 'TEXT',
      'expectation_interpretation': 'TEXT',
      'optimism_anchor': 'TEXT',
      'reality_constraint': 'TEXT',
      'effort_anchor': 'TEXT',
      'pyg_potential': 'TEXT',
      'pyg_light_action': 'TEXT',
      'pyg_signal_track': 'TEXT',
      'ritual_expectation': 'TEXT',
      'ritual_action': 'TEXT',
      'ritual_feedback': 'TEXT',
      'bet_text': 'TEXT',
      'bet_cost': 'TEXT',
      'falsification': 'TEXT',
      'rationality_comfort': 'TEXT',
      'rationality_uncomfortable_questions': 'TEXT',
      'fork_fixed': 'TEXT',
      'fork_variable': 'TEXT',
      'fork_min_step': 'TEXT',
      'moral_mode': 'TEXT',
      'moral_stop_bleed': 'TEXT',
      'moral_treat_root': 'TEXT',
      'moral_higher_loyalty': 'TEXT',
      'leverage_trunk': 'TEXT',
      'leverage_soft_layer': 'TEXT',
      'leverage_micro_actions': 'TEXT',
      'anti_flag_words': 'TEXT',
      'anti_next_week_action': 'TEXT',
      'anti_no_action_cost': 'TEXT',
      'anti_flattened_conflict': 'TEXT',
      'variation_options': 'TEXT',
      'chooser_who': 'TEXT',
      'chooser_concerns': 'TEXT',
      'scenario': 'TEXT',
      'action_plan': 'TEXT',
      'start_date_ms': 'INTEGER',
      'end_date_ms': 'INTEGER',
      'review_facts': 'TEXT',
      'review_moral': 'TEXT',
      'review_falsified': 'INTEGER',
      'decision': 'TEXT',
    });

    await _ensureColumns(db, _tableLogs, {
      'case_id': 'INTEGER',
      'ts_ms': 'INTEGER',
      'kind': 'TEXT',
      'text': 'TEXT',
    });

    // Indexes (safe to run repeatedly)
    try {
      await db.execute('CREATE INDEX IF NOT EXISTS idx_belief_cases_status ON $_tableCases(status)');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_belief_logs_case_ts ON $_tableLogs(case_id, ts_ms)');
    } catch (_) {
      // ignore
    }
  }

  Future<void> _ensureColumns(Database db, String table, Map<String, String> columns) async {
    try {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final existing = info.map((e) => (e['name'] ?? '').toString()).toSet();
      for (final entry in columns.entries) {
        if (existing.contains(entry.key)) continue;
        try {
          await db.execute('ALTER TABLE $table ADD COLUMN ${entry.key} ${entry.value}');
        } catch (_) {
          // ignore (may fail on some devices if column already exists)
        }
      }
    } catch (_) {
      // ignore
    }
  }

  // ---------------------------------------------------------------------------
  // CRUD

  Future<int> createDraftCase({
    required String contextText,
    int emotionIntensity = 50,
    int? cooldownUntilMs,
    bool riskBlocked = false,
    String? riskNote,
  }) async {
    await ensureSchema();
    final db = await _db();
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = await db.insert(_tableCases, {
      'parent_id': null,
      'version': 1,
      'status': riskBlocked ? 'blocked' : 'draft',
      'created_at_ms': now,
      'updated_at_ms': now,
      'context_text': contextText,
      'emotion_intensity': emotionIntensity,
      'cooldown_until_ms': cooldownUntilMs,
      'risk_blocked': riskBlocked ? 1 : 0,
      'risk_note': riskNote,
    });
    return id;
  }

  Future<Map<String, Object?>?> getCase(int id) async {
    await ensureSchema();
    final db = await _db();
    final rows = await db.query(_tableCases, where: 'id=?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, Object?>>> listCases() async {
    await ensureSchema();
    final db = await _db();
    return db.query(_tableCases, orderBy: 'created_at_ms DESC, id DESC');
  }

  /// Returns the most recent "active" case (draft/bet/in_progress), if any.
  ///
  /// Used by the Belief OS home card to resume where the user left off.
  Future<Map<String, Object?>?> getLatestActiveCase() async {
    await ensureSchema();
    final db = await _db();
    final rows = await db.query(
      _tableCases,
      where: "status IN ('draft','bet','in_progress')",
      orderBy: 'updated_at_ms DESC, id DESC',
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  /// Generic partial update helper.
  ///
  /// Keep this as a narrow helper (no business logic) so the UI can update a
  /// couple of fields without duplicating SQL everywhere.
  Future<void> updateCase(int id, Map<String, Object?> patch) async {
    await ensureSchema();
    final db = await _db();
    final data = Map<String, Object?>.from(patch);
    data['updated_at_ms'] = DateTime.now().millisecondsSinceEpoch;
    await db.update(
      _tableCases,
      data,
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> addLog(int caseId, {required String kind, required String text}) async {
    await ensureSchema();
    final db = await _db();
    await db.insert(_tableLogs, {
      'case_id': caseId,
      'ts_ms': DateTime.now().millisecondsSinceEpoch,
      'kind': kind,
      'text': text,
    });
  }

  Future<List<Map<String, Object?>>> listLogs(int caseId) async {
    await ensureSchema();
    final db = await _db();
    return db.query(
      _tableLogs,
      where: 'case_id=?',
      whereArgs: [caseId],
      orderBy: 'ts_ms DESC, id DESC',
    );
  }

  // ---------------------------------------------------------------------------
  // Step updates

  Future<void> updateContext(int id, {required String contextText, int? emotionIntensity}) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'context_text': contextText,
        if (emotionIntensity != null) 'emotion_intensity': emotionIntensity,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setCooldown(int id, int? cooldownUntilMs) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'cooldown_until_ms': cooldownUntilMs,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setTrueOption(int id, {required bool live, required bool forced, required bool momentous}) async {
    await ensureSchema();
    final db = await _db();
    final allYes = live && forced && momentous;
    await db.update(
      _tableCases,
      {
        'is_live': live ? 1 : 0,
        'is_forced': forced ? 1 : 0,
        'is_momentous': momentous ? 1 : 0,
        'status': allYes ? 'draft' : 'stopped',
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setStakes(int id, {
    required String inactionWorst,
    required String inactionLikely,
    required String actionCost,
  }) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'stake_inaction_worst': inactionWorst,
        'stake_inaction_likely': inactionLikely,
        'stake_action_cost': actionCost,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setExpectationAudit(
    int id, {
    required String defaultExpectation,
    required String attention,
    required String behavior,
    required String interpretation,
    required String optimismAnchor,
    required String realityConstraint,
    required String effortAnchor,
    String? pygPotential,
    String? pygLightAction,
    String? pygSignalTrack,
    String? ritualExpectation,
    String? ritualAction,
    String? ritualFeedback,
  }) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'expectation_default': defaultExpectation,
        'expectation_attention': attention,
        'expectation_behavior': behavior,
        'expectation_interpretation': interpretation,
        'optimism_anchor': optimismAnchor,
        'reality_constraint': realityConstraint,
        'effort_anchor': effortAnchor,
        if (pygPotential != null) 'pyg_potential': pygPotential,
        if (pygLightAction != null) 'pyg_light_action': pygLightAction,
        if (pygSignalTrack != null) 'pyg_signal_track': pygSignalTrack,
        if (ritualExpectation != null) 'ritual_expectation': ritualExpectation,
        if (ritualAction != null) 'ritual_action': ritualAction,
        if (ritualFeedback != null) 'ritual_feedback': ritualFeedback,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setBet(int id, {required String betText, required String cost, required String falsification}) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'bet_text': betText,
        'bet_cost': cost,
        'falsification': falsification,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setRationalityCheck(int id, {required String comfort, required String questions}) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'rationality_comfort': comfort,
        'rationality_uncomfortable_questions': questions,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setForkMap(int id, {required String fixed, required String variable, required String minStep}) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'fork_fixed': fixed,
        'fork_variable': variable,
        'fork_min_step': minStep,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setMoralEnergy(
    int id, {
    required String mode,
    required String stopBleed,
    required String treatRoot,
    required String higherLoyalty,
  }) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'moral_mode': mode,
        'moral_stop_bleed': stopBleed,
        'moral_treat_root': treatRoot,
        'moral_higher_loyalty': higherLoyalty,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setLeverageRadar(int id, {required String trunk, required String softLayer, required String microActions}) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'leverage_trunk': trunk,
        'leverage_soft_layer': softLayer,
        'leverage_micro_actions': microActions,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setAntiNarrative(
    int id, {
    required String flagWords,
    required String nextWeekAction,
    required String noActionCost,
    required String flattenedConflict,
  }) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'anti_flag_words': flagWords,
        'anti_next_week_action': nextWeekAction,
        'anti_no_action_cost': noActionCost,
        'anti_flattened_conflict': flattenedConflict,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> setVariationChooser(
    int id, {
    required String variations,
    required String chooserWho,
    required String chooserConcerns,
  }) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'variation_options': variations,
        'chooser_who': chooserWho,
        'chooser_concerns': chooserConcerns,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> startPilot(
    int id, {
    required String scenario,
    required String planText,
    required DateTime start,
    required DateTime end,
  }) async {
    await ensureSchema();
    final db = await _db();
    await db.update(
      _tableCases,
      {
        'scenario': scenario,
        'action_plan': planText,
        'start_date_ms': start.millisecondsSinceEpoch,
        'end_date_ms': end.millisecondsSinceEpoch,
        'status': 'in_progress',
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<void> finishReview(
    int id, {
    required String facts,
    required String moral,
    required bool falsified,
    required String decision,
  }) async {
    await ensureSchema();
    final db = await _db();
    String status;
    switch (decision) {
      case 'abandon':
        status = 'abandoned';
        break;
      case 'revise':
        status = 'revised';
        break;
      case 'reinforce':
      default:
        status = 'reinforced';
        break;
    }

    await db.update(
      _tableCases,
      {
        'review_facts': facts,
        'review_moral': moral,
        'review_falsified': falsified ? 1 : 0,
        'decision': decision,
        'status': status,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  Future<int> forkNewVersion(int id) async {
    await ensureSchema();
    final db = await _db();
    final c = await getCase(id);
    if (c == null) throw StateError('Case not found');

    final now = DateTime.now().millisecondsSinceEpoch;
    final version = (c['version'] as int? ?? 1) + 1;

    // Copy forward: context + prior reasoning artifacts (but reset pilot/review)
    final newId = await db.insert(_tableCases, {
      'parent_id': id,
      'version': version,
      'status': 'draft',
      'created_at_ms': now,
      'updated_at_ms': now,

      'context_text': c['context_text'],
      'emotion_intensity': c['emotion_intensity'],
      'cooldown_until_ms': null,
      'risk_blocked': 0,
      'risk_note': null,

      'is_live': c['is_live'],
      'is_forced': c['is_forced'],
      'is_momentous': c['is_momentous'],

      'stake_inaction_worst': c['stake_inaction_worst'],
      'stake_inaction_likely': c['stake_inaction_likely'],
      'stake_action_cost': c['stake_action_cost'],

      'expectation_default': c['expectation_default'],
      'expectation_attention': c['expectation_attention'],
      'expectation_behavior': c['expectation_behavior'],
      'expectation_interpretation': c['expectation_interpretation'],
      'optimism_anchor': c['optimism_anchor'],
      'reality_constraint': c['reality_constraint'],
      'effort_anchor': c['effort_anchor'],
      'pyg_potential': c['pyg_potential'],
      'pyg_light_action': c['pyg_light_action'],
      'pyg_signal_track': c['pyg_signal_track'],
      'ritual_expectation': c['ritual_expectation'],
      'ritual_action': c['ritual_action'],
      'ritual_feedback': c['ritual_feedback'],

      'bet_text': c['bet_text'],
      'bet_cost': c['bet_cost'],
      'falsification': c['falsification'],

      'rationality_comfort': c['rationality_comfort'],
      'rationality_uncomfortable_questions': c['rationality_uncomfortable_questions'],
      'fork_fixed': c['fork_fixed'],
      'fork_variable': c['fork_variable'],
      'fork_min_step': c['fork_min_step'],
      'moral_mode': c['moral_mode'],
      'moral_stop_bleed': c['moral_stop_bleed'],
      'moral_treat_root': c['moral_treat_root'],
      'moral_higher_loyalty': c['moral_higher_loyalty'],
      'leverage_trunk': c['leverage_trunk'],
      'leverage_soft_layer': c['leverage_soft_layer'],
      'leverage_micro_actions': c['leverage_micro_actions'],
      'anti_flag_words': c['anti_flag_words'],
      'anti_next_week_action': c['anti_next_week_action'],
      'anti_no_action_cost': c['anti_no_action_cost'],
      'anti_flattened_conflict': c['anti_flattened_conflict'],
      'variation_options': c['variation_options'],
      'chooser_who': c['chooser_who'],
      'chooser_concerns': c['chooser_concerns'],
    });

    await addLog(newId, kind: 'fork', text: 'Forked from case#$id (v${c['version']})');
    return newId;
  }
}
