import 'package:flutter/material.dart';

import '../services/tmdb_service.dart';
import 'movie_overview_box.dart';

/// A reusable movie card used by:
/// - Movie ranking list tabs
/// - Movie search results
/// - Movie favourites list
///
/// Requirements implemented here:
/// - Overview shows 4 lines by default; if it overflows, show a “查看” button.
/// - “查看” is placed in the right action column and vertically aligned with
///   the favourite button (so it never covers text).
/// - The “查看” button has no white background; it blends with the card.
class MovieCardItem extends StatefulWidget {
  final Map<String, dynamic> movie;
  final bool isFavorite;
  final VoidCallback onToggleFavorite;

  /// Whether to show the favourite button.
  final bool showFavorite;

  const MovieCardItem({
    super.key,
    required this.movie,
    required this.isFavorite,
    required this.onToggleFavorite,
    this.showFavorite = true,
  });

  @override
  State<MovieCardItem> createState() => _MovieCardItemState();
}

class _MovieCardItemState extends State<MovieCardItem> {
  bool _overviewOverflow = false;

  void _showFullOverview(String title, String overview) {
    final content = overview.trim().isEmpty ? '暂无简介' : overview.trim();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title.isEmpty ? '电影简介' : title),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Text(
              content,
              style: const TextStyle(fontSize: 14, height: 1.4),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final movie = widget.movie;
    final title = (movie['title'] ?? movie['name'] ?? '').toString();
    final overview = (movie['overview'] ?? '').toString();
    final releaseDate = (movie['release_date'] ?? movie['first_air_date'] ?? '').toString();
    final voteAverage = movie['vote_average'];
    final voteCount = movie['vote_count'];

    final posterPath = movie['poster_path'];
    final posterUrl = TMDbService.buildPosterUrl(posterPath?.toString(), size: 'w342');

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Poster image
              if (posterUrl != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: Image.network(
                    posterUrl,
                    width: 80,
                    height: 120,
                    fit: BoxFit.cover,
                  ),
                )
              else
                Container(
                  width: 80,
                  height: 120,
                  color: Colors.grey.shade300,
                  alignment: Alignment.center,
                  child: const Icon(Icons.movie, size: 40, color: Colors.grey),
                ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    MovieOverviewBox(
                      text: overview,
                      maxLines: 4,
                      onOverflowChanged: (v) {
                        if (!mounted) return;
                        if (v != _overviewOverflow) {
                          setState(() => _overviewOverflow = v);
                        }
                      },
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        if (releaseDate.isNotEmpty) ...[
                          const Icon(Icons.calendar_today, size: 14, color: Colors.black45),
                          const SizedBox(width: 4),
                          Text(releaseDate, style: const TextStyle(fontSize: 12, color: Colors.black45)),
                          const SizedBox(width: 12),
                        ],
                        const Icon(Icons.star, size: 14, color: Colors.amber),
                        const SizedBox(width: 4),
                        Text(
                          (voteAverage != null ? (voteAverage as num).toStringAsFixed(1) : '-') +
                              ' (${voteCount ?? '-'})',
                          style: const TextStyle(fontSize: 12, color: Colors.black45),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Right-side action column (favourite + 查看)
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (widget.showFavorite)
                    IconButton(
                      icon: Icon(
                        widget.isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: widget.isFavorite ? Colors.red : Colors.grey,
                      ),
                      onPressed: widget.onToggleFavorite,
                    ),
                  if (_overviewOverflow)
                    TextButton(
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
                        minimumSize: const Size(0, 28),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      onPressed: () => _showFullOverview(title, overview),
                      child: const Text(
                        '查看',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
