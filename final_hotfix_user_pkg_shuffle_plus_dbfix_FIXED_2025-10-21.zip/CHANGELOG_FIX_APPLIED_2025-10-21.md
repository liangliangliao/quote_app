# Hotfix Applied (2025-10-21)

**Base package:** `final_hotfix_user_pkg_shuffle_plus_dbfix.zip`

## Changes
1) `assets/html/poster-wall-only-frame-v23-1.html`
   - Left-align topic title:
     - `.topic-div` → `justify-content:flex-start; text-align:left;`
     - `.topic-text` → added `text-align:left !important;`
   - Note text styling:
     - Forced `line-height: 1.5;`, `font-weight: 100;` for all `.note-text` blocks (kept `margin-top:10px;`).
     - Ensured zero inner/outer spacing via `.note-text * { margin:0; padding:0; }` (already present).
   - Author text composition:
     - In `window.setDynamicData(payload)`, compute `#author-text` as `一一 + 署名 + （出处）` when fields exist; otherwise fallback to `payload.author`.

All changes are minimal and backward-compatible.