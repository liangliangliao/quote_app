import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import '../data/sport_dao.dart';
import 'sport_plan_edit_page.dart';
import 'sport_running_page.dart';
import 'sport_history_list_page.dart';

/// 运动详情页面
///
/// 展示用户的所有运动计划并提供入口进行即时运动。计划模式
/// 支持创建、编辑和删除；即时模式则一键开始运动。计划
/// 数据存储在本地数据库中，通过 [SportDao] 访问。
class SportDetailPage extends StatefulWidget {
  const SportDetailPage({super.key});

  @override
  State<SportDetailPage> createState() => _SportDetailPageState();
}

class _SportDetailPageState extends State<SportDetailPage> {
  final SportDao _dao = SportDao();
  List<Map<String, dynamic>> _plans = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPlans();
  }

  Future<void> _loadPlans() async {
    setState(() { _loading = true; });
    try {
      final plans = await _dao.getPlans();
      setState(() {
        _plans = plans;
        _loading = false;
      });
    } catch (_) {
      setState(() { _plans = []; _loading = false; });
    }
  }

  // Navigate to plan editor. If saved, refresh the plan list.
  Future<void> _onAddPlan() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const SportPlanEditPage()),
    );
    if (saved == true) {
      _loadPlans();
    }
  }

  // 查看某个计划的历史记录列表
  void _onHistoryPlan(Map<String, dynamic> plan) {
    final planId = plan['id'] as int?;
    final title = plan['title']?.toString() ?? '';
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SportHistoryListPage(planId: planId, planTitle: title),
      ),
    );
  }

  // Instant start: create a new record with minimal data and open running page.
  Future<void> _onStartInstant() async {
    // Insert a placeholder record with mode=instant
    final record = <String, dynamic>{
      'plan_id': null,
      'mode': 'instant',
      'start_time': DateTime.now().toIso8601String(),
      'status': 'in_progress',
      'target_type': 'steps',
      'target_value': 0,
      'target_unit': '步',
    };
    final recordId = await _dao.insertRecord(record);
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SportRunningPage(
          recordId: recordId,
          plan: null,
          mode: 'instant',
        ),
      ),
    );
    // When returning from running page, reload plans (in case a plan status updated)
    _loadPlans();
  }

  // Edit existing plan
  Future<void> _onEditPlan(Map<String, dynamic> plan) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => SportPlanEditPage(existingPlan: plan),
      ),
    );
    if (saved == true) {
      _loadPlans();
    }
  }

  // Delete a plan
  Future<void> _onDeletePlan(int id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除计划'),
        content: const Text('确定删除此计划吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('删除')),
        ],
      ),
    );
    if (ok == true) {
      await _dao.deletePlan(id);
      _loadPlans();
    }
  }

  // Start running for a plan: create a record based on plan and open running page
  Future<void> _onStartPlan(Map<String, dynamic> plan) async {
    final record = <String, dynamic>{
      'plan_id': plan['id'],
      'mode': 'plan',
      'start_time': DateTime.now().toIso8601String(),
      'status': 'in_progress',
      'target_type': plan['target_type'],
      'target_value': plan['target_value'],
      'target_unit': plan['target_unit'],
    };
    final recordId = await _dao.insertRecord(record);
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SportRunningPage(
          recordId: recordId,
          plan: plan,
          mode: 'plan',
        ),
      ),
    );
    _loadPlans();
  }

  // 查看全部运动历史
  void _onHistoryAll() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const SportHistoryListPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('运动'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: '历史记录',
            onPressed: _onHistoryAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (_plans.isEmpty
              ? const Center(child: Text('暂无运动计划，点击右下角按钮添加'))
              : ListView.builder(
                  itemCount: _plans.length,
                  itemBuilder: (ctx, index) {
                    final plan = _plans[index];
                    final title = (plan['title'] ?? '').toString();
                    final repeatType = (plan['repeat_type'] ?? 'daily').toString();
                    final planTimeStr = (plan['plan_time'] ?? '').toString();
                    final targetType = (plan['target_type'] ?? '').toString();
                    final targetVal = plan['target_value'];
                    final targetUnit = (plan['target_unit'] ?? '').toString();
                    String subtitle = '';
                    if (planTimeStr.isNotEmpty) {
                      subtitle = '下次：$planTimeStr';
                    }
                    final targetLine = (targetVal != null && targetUnit.isNotEmpty)
                        ? '目标：$targetVal $targetUnit'
                        : '无目标';
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        onTap: () => _onStartPlan(plan),
                        title: Text(title.isNotEmpty ? title : '未命名计划'),
                        subtitle: Text('$subtitle\n$targetLine'),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                          onSelected: (String value) {
                            if (value == 'edit') {
                              _onEditPlan(plan);
                            } else if (value == 'delete') {
                              _onDeletePlan(plan['id'] as int);
                            } else if (value == 'history') {
                              _onHistoryPlan(plan);
                            }
                          },
                          itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                            const PopupMenuItem<String>(value: 'edit', child: Text('编辑')),
                            const PopupMenuItem<String>(value: 'delete', child: Text('删除')),
                            const PopupMenuItem<String>(value: 'history', child: Text('历史')),
                          ],
                        ),
                      ),
                    );
                  },
                )),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Instant start button (left-ish)
          FloatingActionButton(
            heroTag: 'instant',
            onPressed: _onStartInstant,
            mini: true,
            backgroundColor: Colors.orange,
            child: const Icon(Icons.flash_on),
            tooltip: '立即开始非计划运动',
          ),
          const SizedBox(height: 8),
          // Add plan button
          FloatingActionButton(
            heroTag: 'add',
            onPressed: _onAddPlan,
            child: const Icon(Icons.add),
            tooltip: '新增运动计划',
          ),
        ],
      ),
    );
  }
}