import 'dart:ui';
import 'package:workmanager/workmanager.dart';
import 'package:quote_app/utils/run_context.dart';
import 'scheduler_service.dart';

void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    RunContext.isFromWM = true;
    final data = inputData ?? {};
    final job = (data['job'] ?? '').toString();
    final uid = (data['task_uid'] ?? '').toString();
    final runKey = (data['run_key'] ?? '').toString();
    try {
      switch (job) {
        case 'wm_selfcheck':
          try { await SchedulerService.catchupIfMissed(); } catch (_){}
          return Future.value(true);
        case 'wm_run':
          if (uid.isEmpty || runKey.isEmpty) return Future.value(true);
          await SchedulerService.wmRunTask(uid, runKey);
          return Future.value(true);
        case 'wm_after_am':
          final qUid = (data['q_uid'] ?? '').toString();
          if (uid.isEmpty || runKey.isEmpty) return Future.value(true);
          await SchedulerService.wmAfterAmTask(uid, runKey, qUid: qUid.isEmpty ? null : qUid);
          return Future.value(true);
        case 'wm_fallback':
          if (uid.isEmpty || runKey.isEmpty) return Future.value(true);
          await SchedulerService.wmRunTask(uid, runKey);
          return Future.value(true);
        default:
          // Unknown/obsolete job: don't retry
          return Future.value(true);
      }
    } catch (_){
      // Do not retry to avoid queue "sticking"
      return Future.value(true);
    } finally {
      RunContext.isFromWM = false;
    }
  });
}

/// Legacy entrypoint name expected by main.dart
@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  callbackDispatcher();
}
