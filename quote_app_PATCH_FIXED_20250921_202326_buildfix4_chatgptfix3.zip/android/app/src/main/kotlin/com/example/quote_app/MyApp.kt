package com.example.quote_app

import io.flutter.app.FlutterApplication
import io.flutter.plugin.common.PluginRegistry
import dev.fluttercommunity.plus.androidalarmmanager.AndroidAlarmManagerPlugin

/**
 * Custom Application to make our SysAlarmPermissionPlugin available
 * inside headless FlutterEngine instances started by AlarmManager.
 */
class MyApp : FlutterApplication(), PluginRegistry.PluginRegistrantCallback {

    override fun onCreate() {
        super.onCreate()
        // For AndroidAlarmManager (V1 embedding path) – provide a callback that will
        // register any extra plugins the background isolate needs.
        AndroidAlarmManagerPlugin.setPluginRegistrantCallback(this)
    }

    /**
     * Registers only the plugins strictly needed by background isolates.
     * We omit GeneratedPluginRegistrant to avoid API‑level mismatches and keep
     * the dependency surface minimal.
     */
    override fun registerWith(registry: PluginRegistry) {
        // Make our custom exact‑alarm permission channel available.
        SysAlarmPermissionPlugin.registerWith(
            registry.registrarFor(SysAlarmPermissionPlugin.CHANNEL)
        )
    }
}
