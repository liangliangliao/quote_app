import 'package:workmanager/workmanager.dart';
import 'services/notification_service.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'services/scheduler_service.dart';
import 'utils/debug_logger.dart';
import 'data/db.dart';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';

@pragma('vm:entry-point')
void alarmCallback() async {
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();
  await DLog.i('ALARM', 'alarmCallback fired');
  await AppDatabase.instance();
  await NotificationService.init();
  await SchedulerService.callback();
  await SchedulerService.catchupIfMissed();
  await SchedulerService.scheduleNextForAll();
}


@pragma('vm:entry-point')
void daily0830Callback() async {
  // 发送每日通知
  await NotificationService.init();
  await NotificationService.showSimple('每日提醒', '08:30 保活/巡检');
  // 回调里重约明天 08:30，确保使用 one-shot exact 且严格按点
  final now = DateTime.now().add(const Duration(days: 1));
  final next = DateTime(now.year, now.month, now.day, 8, 30).add(const Duration(seconds: 5));
  AndroidAlarmManager.oneShotAt(
    next,
    888, // 保持与注册一致的唯一 ID
    daily0830Callback,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );
}

Future<void> _scheduleDaily0830Exact() async {
  final now = DateTime.now();
  var first = DateTime(now.year, now.month, now.day, 8, 30);
  if (!first.isAfter(now)) {
    first = first.add(const Duration(days: 1));
  }
  // 避免“等于现在/过去数百毫秒”被系统丢弃，向后微调 5 秒
  first = first.add(const Duration(seconds: 5));
  await AndroidAlarmManager.oneShotAt(
    first,
    888,
    daily0830Callback,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );
}


Future<void> registerBackgroundTasks() async {
  // 兜底：每15分钟检查一次延误任务（Android 限制最小 15 分钟）
  await Workmanager().registerPeriodicTask(
    'due_recover',
    'due_recover',
    frequency: const Duration(minutes: 15),
    existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
  );

  // 自检：2分钟后触发一次，验证后台通道是否正常
  await AndroidAlarmManager.oneShot(
    const Duration(minutes: 2),
    801,
    alarmCallback,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );

  // 每日 8:30 的保活/巡检（重启后也会恢复）
  await _scheduleDaily0830Exact();
}