import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 4: 理性之感校验
///
/// 核心：识别“感觉正确”是否来自舒适/安全感，而不是证据。
/// 输出：2-3 个不舒服但必要的问题（用于后续复盘与验证）。
class BeliefRationalityCheckPage extends StatefulWidget {
  final int caseId;
  const BeliefRationalityCheckPage({super.key, required this.caseId});

  @override
  State<BeliefRationalityCheckPage> createState() => _BeliefRationalityCheckPageState();
}

class _BeliefRationalityCheckPageState extends State<BeliefRationalityCheckPage> {
  bool _loading = true;
  Map<String, Object?>? _case;

  final _comfortCtl = TextEditingController();
  final _qCtl = TextEditingController();

  final _templates = const [
    '如果我错了，最可能错在什么地方？',
    '有哪些事实（我不愿承认但必须面对）会反驳我的信念？',
    '我现在最想逃避的一个验证动作是什么？',
    '如果我把“希望”当成“证据”，我会忽略哪些相反信息？',
    '最小的、可在一周内完成的反证测试是什么？',
  ];

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    setState(() {
      _case = c;
      _comfortCtl.text = (c?['rationality_comfort']?.toString() ?? '').trim();
      _qCtl.text = (c?['rationality_uncomfortable_questions']?.toString() ?? '').trim();
      _loading = false;
    });
  }

  void _appendTemplate(String t) {
    final cur = _qCtl.text.trimRight();
    final next = cur.isEmpty ? '• $t' : '$cur\n• $t';
    setState(() => _qCtl.text = next);
  }

  Future<void> _save() async {
    final comfort = _comfortCtl.text.trim();
    final qs = _qCtl.text.trim();
    if (comfort.isEmpty || qs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请填写两项内容')));
      return;
    }

    await BeliefDao().setRationalityCheck(
      widget.caseId,
      comfortBias: comfort,
      uncomfortableQuestions: qs,
    );
    await BeliefDao().addLog(widget.caseId, kind: 'rationality', text: '完成理性校验');

    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _comfortCtl.dispose();
    _qCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final bet = (_case?['bet_text']?.toString() ?? '').trim();

    return Scaffold(
      appBar: AppBar(title: const Text('Step 4  理性之感校验')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('你的下注（回看）', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(bet.isEmpty ? '(暂无)' : bet, style: const TextStyle(height: 1.35)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('1) 这种“感觉正确”来自哪里？', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _comfortCtl,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: '例：它让我觉得安全、可控、有道德优越感、能避免冲突……',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('2) 写下 2-3 个“不舒服但必要”的问题', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _templates
                        .map(
                          (t) => ActionChip(
                            label: Text('示例：${t.length > 10 ? t.substring(0, 10) : t}…'),
                            onPressed: () => _appendTemplate(t),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _qCtl,
                    maxLines: 7,
                    decoration: const InputDecoration(
                      hintText: '建议用项目符号写，例如：\n• 如果我错了…\n• 有哪些事实会反驳…',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    '提示：这一步不是为了“自我否定”，而是为了把验证任务放在桌面上。\n下一步会把它落在“分叉图/最小一步”。',
                    style: TextStyle(fontSize: 12, height: 1.35),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: const Text('保存并继续')),
        ],
      ),
    );
  }
}
