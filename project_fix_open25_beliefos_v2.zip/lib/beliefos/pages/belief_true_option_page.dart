import 'package:flutter/material.dart';
import '../belief_dao.dart';
import 'belief_expectation_audit_page.dart';

/// Step 1: True Option Check (James - live/forced/momentous).
class BeliefTrueOptionPage extends StatefulWidget {
  final int caseId;
  const BeliefTrueOptionPage({super.key, required this.caseId});

  @override
  State<BeliefTrueOptionPage> createState() => _BeliefTrueOptionPageState();
}

class _BeliefTrueOptionPageState extends State<BeliefTrueOptionPage> {
  bool? _live;
  bool? _forced;
  bool? _momentous;
  bool _saving = false;
  Map<String, dynamic>? _case;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    setState(() {
      _case = c;
      _live = (c?['is_live'] == null) ? null : (c?['is_live'] == 1);
      _forced = (c?['is_forced'] == null) ? null : (c?['is_forced'] == 1);
      _momentous = (c?['is_momentous'] == null) ? null : (c?['is_momentous'] == 1);
    });
  }

  bool get _ready => _live != null && _forced != null && _momentous != null;

  Future<void> _submit() async {
    if (!_ready) return;
    setState(() { _saving = true; });
    try {
      await BeliefDao().setTrueOption(widget.caseId, live: _live!, forced: _forced!, momentous: _momentous!);
      final allYes = _live == true && _forced == true && _momentous == true;
      if (!mounted) return;
      if (!allYes) {
        await BeliefDao().updateCase(widget.caseId, {'status': 'stopped', 'decision': 'not_true_option'});
        await BeliefDao().addLog(widget.caseId, kind: 'true_option', text: 'Not a true option, exit.');
        if (!mounted) return;
        _showNotTrueOptionSheet();
      } else {
        await BeliefDao().addLog(widget.caseId, kind: 'true_option', text: 'True option confirmed.');
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => BeliefExpectationAuditPage(caseId: widget.caseId)),
        );
      }
    } catch (_) {
      if (!mounted) return;
      setState(() { _saving = false; });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('保存失败，请重试')));
    }
  }

  void _showNotTrueOptionSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('这不是一个「真选项」', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              const Text(
                '在詹姆斯的意义上：只有当一个选项同时是「活的 / 被迫的 / 重大的」，你才需要用意志下注。\n\n建议你先做澄清，而不是下注。',
                style: TextStyle(fontSize: 14, height: 1.45),
              ),
              const SizedBox(height: 10),
              const Text('澄清问题（任选 1–2 个）', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              const Text('• 我真正可能选择的选项到底有哪些？\n• 我拖延在避免哪种后果？\n• 如果我不选，会发生什么（最坏/最可能）？', style: TextStyle(fontSize: 13, height: 1.45)),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                    Navigator.of(context).pop();
                  },
                  child: const Text('结束（回到案子详情）'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                    Navigator.of(context).pop();
                  },
                  child: const Text('我先去修改困境描述'),
                ),
              ),
            ],
          ),
        );
      },
    ).whenComplete(() {
      if (mounted) setState(() { _saving = false; });
    });
  }

  @override
  Widget build(BuildContext context) {
    final ctxText = (_case?['context_text']?.toString() ?? '').trim();
    return Scaffold(
      appBar: AppBar(title: const Text('真选项判定（Step 1）')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '目的：阻止无限拖延，确认你是否必须下注。\n\n只有当一个选项同时是：活的 / 被迫的 / 重大的，你才进入下一步。',
            style: TextStyle(fontSize: 14, height: 1.45),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('你的困境', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text(ctxText.isEmpty ? '（未填写）' : ctxText, style: const TextStyle(fontSize: 13, height: 1.4)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _ynCard(
            title: '1) 这是一个你真的可能选择的选项吗？（活的）',
            subtitle: '不是抽象思辨，而是你现实中真的会选。',
            value: _live,
            onChanged: (v) => setState(() => _live = v),
          ),
          const SizedBox(height: 10),
          _ynCard(
            title: '2) 不选择是否也会产生后果？（被迫的）',
            subtitle: '拖延本身也在做选择，并且会付出代价。',
            value: _forced,
            onChanged: (v) => setState(() => _forced = v),
          ),
          const SizedBox(height: 10),
          _ynCard(
            title: '3) 这个决定会影响你的未来走向或重要关系吗？（重大的）',
            subtitle: '它值得你用行动去检验，而不是无限思考。',
            value: _momentous,
            onChanged: (v) => setState(() => _momentous = v),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _saving ? null : (_ready ? _submit : null),
              child: _saving
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('继续 → 期待审计'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _ynCard({
    required String title,
    required String subtitle,
    required bool? value,
    required ValueChanged<bool> onChanged,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(fontSize: 13, height: 1.35, color: Colors.black54)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: RadioListTile<bool>(
                    value: true,
                    groupValue: value,
                    onChanged: (v) { if (v != null) onChanged(v); },
                    title: const Text('Yes'),
                  ),
                ),
                Expanded(
                  child: RadioListTile<bool>(
                    value: false,
                    groupValue: value,
                    onChanged: (v) { if (v != null) onChanged(v); },
                    title: const Text('No'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
