import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 5: 可变性与分叉图
///
/// 把困境拆成：
/// - 不可变（主干/事实）
/// - 可变（分支/可试验的变量）
/// - 最小一步（把验证拉回到一小步行动）
class BeliefForkMapPage extends StatefulWidget {
  final int caseId;
  const BeliefForkMapPage({super.key, required this.caseId});

  @override
  State<BeliefForkMapPage> createState() => _BeliefForkMapPageState();
}

class _BeliefForkMapPageState extends State<BeliefForkMapPage> {
  bool _loading = true;
  final _fixedCtl = TextEditingController();
  final _varCtl = TextEditingController();
  final _minCtl = TextEditingController();

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    _fixedCtl.text = (c?['fork_fixed']?.toString() ?? '').trim();
    _varCtl.text = (c?['fork_variable']?.toString() ?? '').trim();
    _minCtl.text = (c?['fork_min_step']?.toString() ?? '').trim();
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final fixed = _fixedCtl.text.trim();
    final v = _varCtl.text.trim();
    final min = _minCtl.text.trim();
    if (fixed.isEmpty || v.isEmpty || min.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请填写三项内容')));
      return;
    }
    await BeliefDao().setForkMap(
      widget.caseId,
      fixedTrunk: fixed,
      variableBranches: v,
      minStep: min,
    );
    await BeliefDao().addLog(widget.caseId, kind: 'fork', text: '完成分叉图');
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _fixedCtl.dispose();
    _varCtl.dispose();
    _minCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Step 5  可变性与分叉')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _card(
            title: '1) 不可变主干（事实/约束）',
            hint: '例：预算已锁死、对方必须签字、时间窗口只剩 2 周…',
            ctl: _fixedCtl,
            lines: 4,
          ),
          const SizedBox(height: 12),
          _card(
            title: '2) 可变分支（变量/可试验）',
            hint: '例：沟通顺序、证据呈现方式、试点范围、替代资源…',
            ctl: _varCtl,
            lines: 5,
          ),
          const SizedBox(height: 12),
          _card(
            title: '3) 最小一步（最小可检验动作）',
            hint: '例：48 小时内发出一封确认邮件并要求书面回复；或做 30 分钟的原型验证…',
            ctl: _minCtl,
            lines: 3,
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: const Text('保存并继续')),
        ],
      ),
    );
  }

  Widget _card({required String title, required String hint, required TextEditingController ctl, required int lines}) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: ctl,
              maxLines: lines,
              decoration: InputDecoration(hintText: hint, border: const OutlineInputBorder()),
            ),
          ],
        ),
      ),
    );
  }
}
