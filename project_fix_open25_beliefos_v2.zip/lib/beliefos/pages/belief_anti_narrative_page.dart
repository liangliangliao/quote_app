import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 8: 反宏大叙事三问
///
/// 当我们把困境讲成“整体故事/必然宿命”，行动会被抽空。
/// 这里用三问把叙事压平回到：下一周、代价、具体冲突。
class BeliefAntiNarrativePage extends StatefulWidget {
  final int caseId;
  const BeliefAntiNarrativePage({super.key, required this.caseId});

  @override
  State<BeliefAntiNarrativePage> createState() => _BeliefAntiNarrativePageState();
}

class _BeliefAntiNarrativePageState extends State<BeliefAntiNarrativePage> {
  bool _loading = true;

  final _nextCtl = TextEditingController();
  final _noActionCtl = TextEditingController();
  final _conflictCtl = TextEditingController();

  final Map<String, bool> _flags = {
    '必然': false,
    '终将': false,
    '唯一正确': false,
    '整体正确': false,
    '历史规律': false,
    '不得不': false,
  };

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    _nextCtl.text = (c?['anti_next_week_action']?.toString() ?? '').trim();
    _noActionCtl.text = (c?['anti_no_action_cost']?.toString() ?? '').trim();
    _conflictCtl.text = (c?['anti_flattened_conflict']?.toString() ?? '').trim();

    final saved = (c?['anti_flag_words']?.toString() ?? '').trim();
    final parts = saved.isEmpty ? <String>[] : saved.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    for (final k in _flags.keys) {
      _flags[k] = parts.contains(k);
    }

    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final next = _nextCtl.text.trim();
    final noAction = _noActionCtl.text.trim();
    final conflict = _conflictCtl.text.trim();
    if (next.isEmpty || noAction.isEmpty || conflict.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请完成三问后再继续')));
      return;
    }
    final selected = _flags.entries.where((e) => e.value).map((e) => e.key).join(',');
    await BeliefDao().setAntiNarrative(
      widget.caseId,
      flagWords: selected,
      nextWeekAction: next,
      noActionCost: noAction,
      flattenedConflict: conflict,
    );
    await BeliefDao().addLog(widget.caseId, kind: 'anti', text: '完成反宏大叙事三问');
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nextCtl.dispose();
    _noActionCtl.dispose();
    _conflictCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Step 8  反宏大叙事三问')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('宏大叙事标记（可选）', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  const Text('当你在心里用这些词讲故事，通常意味着“叙事在吞噬行动”。', style: TextStyle(fontSize: 12, height: 1.35)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _flags.keys.map((k) {
                      final v = _flags[k] ?? false;
                      return FilterChip(
                        selected: v,
                        label: Text(k),
                        onSelected: (s) => setState(() => _flags[k] = s),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _qaCard(
            title: '1) 下一周我真正能做的“一个动作”是什么？',
            hint: '限定：一周内可完成、可验证、可记录。',
            ctl: _nextCtl,
            lines: 4,
          ),
          const SizedBox(height: 12),
          _qaCard(
            title: '2) 如果我什么都不做，代价是什么？',
            hint: '写具体代价：时间/关系/机会/健康/尊严…',
            ctl: _noActionCtl,
            lines: 4,
          ),
          const SizedBox(height: 12),
          _qaCard(
            title: '3) 我把哪些具体冲突“压平”成了一个故事？',
            hint: '列出具体冲突：谁 vs 谁、事实 vs 愿望、短期 vs 长期…',
            ctl: _conflictCtl,
            lines: 5,
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: const Text('保存并继续')),
        ],
      ),
    );
  }

  Widget _qaCard({required String title, required String hint, required TextEditingController ctl, required int lines}) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: ctl,
              maxLines: lines,
              decoration: InputDecoration(hintText: hint, border: const OutlineInputBorder()),
            ),
          ],
        ),
      ),
    );
  }
}
