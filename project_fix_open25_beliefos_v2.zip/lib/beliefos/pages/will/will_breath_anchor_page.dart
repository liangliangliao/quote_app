import 'dart:async';
import 'package:flutter/material.dart';
import '../../belief_dao.dart';

class WillBreathAnchorPage extends StatefulWidget {
  final int caseId;
  const WillBreathAnchorPage({super.key, required this.caseId});

  @override
  State<WillBreathAnchorPage> createState() => _WillBreathAnchorPageState();
}

class _WillBreathAnchorPageState extends State<WillBreathAnchorPage> {
  int _remaining = 60;
  Timer? _timer;
  bool _running = false;

  void _start() {
    _timer?.cancel();
    setState(() {
      _remaining = 60;
      _running = true;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        _remaining = (_remaining - 1).clamp(0, 60);
      });
      if (_remaining <= 0) {
        t.cancel();
        setState(() { _running = false; });
      }
    });
    BeliefDao().addLog(widget.caseId, kind: 'will_breath_anchor', text: 'start');
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('呼吸—努力锚点（60秒）')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('保持自然呼吸，只做一件事。\n\n吸气时：读一遍你的下注句。\n呼气时：做第一步动作（或准备做）。\n\n如果你在屏气，先呼气。', style: TextStyle(fontSize: 13, height: 1.4)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Center(
                child: Text(
                  _running ? '$_remaining s' : '准备',
                  style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _running ? null : _start,
              child: const Text('开始 60 秒'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('返回'),
            ),
          ),
        ],
      ),
    );
  }
}
