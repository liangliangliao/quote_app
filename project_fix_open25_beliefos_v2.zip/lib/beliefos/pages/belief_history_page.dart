import 'package:flutter/material.dart';
import '../belief_dao.dart';
import 'belief_case_detail_page.dart';

class BeliefHistoryPage extends StatefulWidget {
  final bool openHistory;
  const BeliefHistoryPage({super.key, this.openHistory = false});

  @override
  State<BeliefHistoryPage> createState() => _BeliefHistoryPageState();
}

class _BeliefHistoryPageState extends State<BeliefHistoryPage> {
  bool _loading = true;
  List<Map<String, Object?>> _items = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final l = await BeliefDao().listCases();
    if (!mounted) return;
    setState(() {
      _items = l;
      _loading = false;
    });
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'draft':
        return '草案';
      case 'in_progress':
        return '行动中';
      case 'reinforced':
        return '已加固';
      case 'revised':
        return '已修正';
      case 'abandoned':
        return '已放弃';
      case 'stopped':
        return '已退出';
      default:
        return s;
    }
  }

  String _fmtDate(int? ms) {
    if (ms == null || ms <= 0) return '-';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('信念历史'),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (_items.isEmpty
              ? const Center(child: Text('还没有任何信念案子'))
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) {
                    final c = _items[i];
                    final id = c['id'] as int;
                    final status = _statusLabel((c['status']?.toString() ?? ''));
                    final created = _fmtDate(c['created_at_ms'] as int?);
                    final ctx = (c['context_text']?.toString() ?? '').trim();
                    final subtitle = ctx.isEmpty ? '(无困境文本)' : ctx;
                    return Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: ListTile(
                        title: Text('[$status] $created'),
                        subtitle: Text(
                          subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => BeliefCaseDetailPage(caseId: id)),
                          );
                        },
                      ),
                    );
                  },
                )),
    );
  }
}
