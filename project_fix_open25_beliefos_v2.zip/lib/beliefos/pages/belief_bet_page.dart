import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 3: 信念下注
///
/// - 我相信什么（命题）
/// - 我愿意为它付出什么（成本）
/// - 什么证据会让我认输（可证伪）
class BeliefBetPage extends StatefulWidget {
  final int caseId;
  const BeliefBetPage({super.key, required this.caseId});

  @override
  State<BeliefBetPage> createState() => _BeliefBetPageState();
}

class _BeliefBetPageState extends State<BeliefBetPage> {
  final _bet = TextEditingController();
  final _cost = TextEditingController();
  final _falsify = TextEditingController();

  bool _loading = true;

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (c != null) {
      _bet.text = (c['bet_text']?.toString() ?? '').trim();
      _cost.text = (c['bet_cost']?.toString() ?? '').trim();
      _falsify.text = (c['falsification']?.toString() ?? '').trim();
    }
    if (!mounted) return;
    setState(() => _loading = false);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _bet.dispose();
    _cost.dispose();
    _falsify.dispose();
    super.dispose();
  }

  bool get _ready =>
      _bet.text.trim().isNotEmpty && _cost.text.trim().isNotEmpty && _falsify.text.trim().isNotEmpty;

  Future<void> _submit() async {
    if (!_ready) return;
    await BeliefDao().setBet(
      widget.caseId,
      betText: _bet.text.trim(),
      betCost: _cost.text.trim(),
      falsification: _falsify.text.trim(),
    );
    await BeliefDao().addLog(widget.caseId, kind: 'bet', text: '下注已记录');
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Step 3  信念下注')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '把“信念”写成可检验的赌注：\n\n'
            '1) 我相信什么（命题）\n'
            '2) 我愿意付出什么（成本）\n'
            '3) 什么证据会让我认输（可证伪）',
            style: TextStyle(height: 1.35),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: _bet,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: '命题（我相信…）',
              hintText: '尽量写成可观察/可测的陈述。\n例：我通过两周试点能把X指标提升到Y。',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: _cost,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: '成本（我愿意付出…）',
              hintText: '时间/金钱/面子/不适感/机会成本。\n例：连续14天每天投入30分钟。',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: _falsify,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: '可证伪条件（如果出现…我承认…）',
              hintText: '写出会让你改变信念的证据/事件。\n例：两周内A/B测试显示无提升且出现Z副作用。',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),

          FilledButton(
            onPressed: _ready ? _submit : null,
            child: const Text('保存并返回'),
          ),
        ],
      ),
    );
  }
}
