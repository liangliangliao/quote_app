package com.example.quote_app

import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hasExactAlarmPermission" -> {
                        try {
                            val ok = ExactAlarmHelper.hasExactAlarmPermission(this)
                            result.success(ok)
                        } catch (t: Throwable) {
                            android.util.Log.w("SysChannel", "hasExactAlarmPermission error", t)
                            result.success(Build.VERSION.SDK_INT < Build.VERSION_CODES.S)
                        }
                    }
                    "requestExactAlarmPermission" -> {
                        try {
                            ExactAlarmHelper.requestExactAlarmPermission(this)
                            result.success(true)
                        } catch (t: Throwable) {
                            android.util.Log.w("SysChannel", "requestExactAlarmPermission error", t)
                            result.error("ERR", t.message, null)
                        }
                    }
                    // 新增：告诉 Dart 侧当前是否由原生接管 AM/WM
                    "isNativeWmEnabled" -> result.success(true)
                    "isNativeAmEnabled" -> result.success(true)
                     "cancelWmByUid" -> {
                        try {
                            val uid = call.argument<String>("uid")
                            if (uid != null) com.example.quote_app.wm.WmScheduler.cancelByUid(this, uid)
                            result.success(true)
                        } catch (t: Throwable) { result.error("ERR", t.message, null) }
                    }
                     "cancelExactById" -> {
                        try {
                            val uid = call.argument<String>("uid")
                            val runKey = call.argument<String>("runKey")
                            val ok = com.example.quote_app.am.AmCancel.cancelExactById(this, uid ?: "", runKey)
                            result.success(ok)
                        } catch (t: Throwable) { result.error("ERR", t.message, null) }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
