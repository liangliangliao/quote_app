import 'package:sqflite/sqflite.dart';
import 'package:flutter/foundation.dart';
import '../data/db.dart';

class DLog {
  static Future<void> i(String tag, String msg) async {
    final line = "[$tag] $msg";
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      });
    } catch (e) { print('[ERR][DLog] db-insert failed: ' + e.toString()); }
  }

  static Future<void> e(String tag, String msg) async {
    final line = "[ERR][$tag] $msg";
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      });
    } catch (e) { print('[ERR][DLog] db-insert failed: ' + e.toString()); }
  }

  static Future<void> d(String tag, String msg) async {
    final line = "[DBG][$tag] $msg";
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      });
    } catch (e) {
      // fallback: still print error to console
      print('[ERR][DLog] db-insert failed: ' + e.toString());
    }
  }
}
