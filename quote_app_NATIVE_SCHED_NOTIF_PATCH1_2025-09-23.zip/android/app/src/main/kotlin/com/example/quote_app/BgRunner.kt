package com.example.quote_app

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.view.FlutterMain
import io.flutter.plugin.common.MethodChannel

object BgRunner {
    private var engine: FlutterEngine? = null
    private var channel: MethodChannel? = null

    @Synchronized
    fun ensureEngine(context: Context) {
        if (engine != null) return
        FlutterMain.startInitialization(context)
        FlutterMain.ensureInitializationComplete(context, null)
        val eng = FlutterEngine(context)
        eng.dartExecutor.executeDartEntrypoint(
            DartExecutor.DartEntrypoint(FlutterMain.findAppBundlePath(), "bgMain")
        )
        engine = eng
        channel = MethodChannel(eng.dartExecutor.binaryMessenger, "com.example.quote_app/bg")
    }

    fun invokeDart(context: Context, method: String, args: HashMap<String, Any?>) {
        ensureEngine(context)
        Handler(Looper.getMainLooper()).post {
            channel?.invokeMethod(method, args)
        }
        // Stop engine later to free memory
        Handler(Looper.getMainLooper()).postDelayed({
            try { engine?.destroy() } catch (_: Exception) {}
            engine = null
            channel = null
        }, 20_000) // 20s enough for one dispatch
    }
}
