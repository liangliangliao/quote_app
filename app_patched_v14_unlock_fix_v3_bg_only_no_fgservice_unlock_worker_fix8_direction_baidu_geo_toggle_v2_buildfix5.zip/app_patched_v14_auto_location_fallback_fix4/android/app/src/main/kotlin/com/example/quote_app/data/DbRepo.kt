package com.example.quote_app.data

import android.content.Context

// Bridge visible to Kotlin. Uses reflection to call Java DbRepository at runtime,
// to avoid compile-time dependency ordering issues in CI.
object DbRepo {
  private const val KLASS = "com.example.quote_app.data.DbRepository"

  private fun kls(): Class<*>? = try { Class.forName(KLASS) } catch (_: Throwable) { null }

  @JvmStatic fun log(ctx: Context, uid: String?, detail: String) {
    try {
      kls()?.getMethod("log", Context::class.java, String::class.java, String::class.java)
          ?.invoke(null, ctx, uid, detail)
    } catch (_: Throwable) {}
  }

  @JvmStatic fun runGuardBegin(ctx: Context, uid: String, runKey: String, src: String): Boolean {
    return try {
      val r = kls()?.getMethod("runGuardBegin",
          Context::class.java, String::class.java, String::class.java, String::class.java)
          ?.invoke(null, ctx, uid, runKey, src)
      (r as? Boolean) ?: true
    } catch (_: Throwable) { true }
  }

  @JvmStatic fun runGuardEnd(ctx: Context, uid: String, runKey: String, src: String) {
    try {
      kls()?.getMethod("runGuardEnd",
          Context::class.java, String::class.java, String::class.java, String::class.java)
          ?.invoke(null, ctx, uid, runKey, src)
    } catch (_: Throwable) {}
  }

  @JvmStatic fun markLatestSuccess(ctx: Context, uid: String) {
    try {
      kls()?.getMethod("markLatestSuccess", Context::class.java, String::class.java)
          ?.invoke(null, ctx, uid)
    } catch (_: Throwable) {}
  }


@JvmStatic fun getCfgInt(ctx: Context, key: String, def: Int): Int {
  val ks = kls()
  try {
    val names = arrayOf("getCfgInt","getConfigInt","readCfgInt","getIntConfig")
    for (n in names) {
      try {
        val m = ks?.getMethod(n, Context::class.java, String::class.java, Int::class.javaPrimitiveType)
        if (m != null) return m.invoke(null, ctx, key, def) as Int
      } catch (_: Throwable) {}
    }
  } catch (_: Throwable) {}
  return try { ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE).getInt(key, def) } catch (_: Throwable) { def }
}
@JvmStatic fun setCfgInt(ctx: Context, key: String, value: Int) {
  val ks = kls()
  try {
    val names = arrayOf("setCfgInt","setConfigInt","saveCfgInt","putIntConfig")
    for (n in names) {
      try {
        val m = ks?.getMethod(n, Context::class.java, String::class.java, Int::class.javaPrimitiveType)
        if (m != null) { m.invoke(null, ctx, key, value); return }
      } catch (_: Throwable) {}
    }
  } catch (_: Throwable) {}
  try { ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE).edit().putInt(key, value).apply() } catch (_: Throwable) {}
}
@JvmStatic fun getCfgString(ctx: Context, key: String, def: String): String {
  val ks = kls()
  try {
    val names = arrayOf("getCfgString","getConfigString","readCfgString","getStringConfig")
    for (n in names) {
      try {
        val m = ks?.getMethod(n, Context::class.java, String::class.java, String::class.java)
        if (m != null) return m.invoke(null, ctx, key, def) as String
      } catch (_: Throwable) {}
    }
  } catch (_: Throwable) {}
  return try { ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE).getString(key, def) ?: def } catch (_: Throwable) { def }
}

}
