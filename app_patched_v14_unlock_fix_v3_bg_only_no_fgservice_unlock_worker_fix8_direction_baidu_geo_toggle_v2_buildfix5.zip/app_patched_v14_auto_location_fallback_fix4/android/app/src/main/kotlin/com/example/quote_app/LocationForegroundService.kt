package com.example.quote_app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread
import kotlin.math.*
import java.io.File

// Baidu SDK
import com.baidu.location.*
import com.baidu.location.LocationClient
import com.baidu.location.LocationClientOption
import com.baidu.location.BDAbstractLocationListener
import com.baidu.location.BDLocation
import android.os.Looper

class LocationForegroundService : Service() {
  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    startForeground(9001, buildOngoingNotification())
    try { DbRepo.log(this, null, "【地点规则】前台服务已启动（startId=$startId）") } catch (_: Throwable) {}

    thread(start=true) {
      runCatching {
        val locSys = obtainCurrentLocation()
        var locBest: Location? = locSys
        if (locBest == null) {
          // 系统失败，尝试百度定位（高精度流，30m内）
          val ak = getBaiduAkFromDb() ?: try { DbRepo.getCfgString(this@LocationForegroundService, "baidu_ak", "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2") } catch (_: Throwable) { "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" }
          locBest = obtainBaiduLocation(ak)
        }
        if (locBest == null) {
          try { DbRepo.log(this, null, "【地点规则】无可用位置（系统/百度均失败），结束") } catch (_: Throwable) {}
          stopSelf(); return@thread
        }

        val target = readTargetLocationFromDb()
        if (target == null) {
          try { DbRepo.log(this, null, "【地点规则】未配置目标坐标，直接返回") } catch (_: Throwable) {}
          stopSelf(); return@thread
        }

        val dist = distanceMeters(locBest.latitude, locBest.longitude, target.first, target.second)
        try { DbRepo.log(this, null, "【地点规则】当前位置=(${locBest.latitude},${locBest.longitude})，目标=(${target.first},${target.second})，距离=${dist}m") } catch (_: Throwable) {}

        if (dist <= 100.0) {
          try { DbRepo.log(this, null, "【地点规则】命中（<=100m），发送通知") } catch (_: Throwable) {}
          try { NotifyHelper.send(this, 2001, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null) } catch (_: Throwable) {}
        } else {
          try { DbRepo.log(this, null, "【地点规则】未命中，不发送") } catch (_: Throwable) {}
        }
      }.onFailure {
        try { DbRepo.log(this, null, "【地点规则】异常：" + it.message) } catch (_: Throwable) {}
      }.also {
        try { if (android.os.Build.VERSION.SDK_INT >= 24) stopForeground(android.app.Service.STOP_FOREGROUND_DETACH) else stopForeground(true) } catch (_: Throwable) { stopForeground(true) }
        stopSelf()
      }
    }
    return START_NOT_STICKY
  }

  private fun buildOngoingNotification(): Notification {
    val chanId = "quote_location_fg"
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
      val chan = NotificationChannel(chanId, "地点前台服务", NotificationManager.IMPORTANCE_MIN)
      nm.createNotificationChannel(chan)
    }
    return NotificationCompat.Builder(this, chanId)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setContentTitle("正在获取位置…")
      .setContentText("用于地点规则提醒")
      .setOngoing(true)
      .build()
  }

  private fun obtainCurrentLocation(): Location? {
    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    if (Build.VERSION.SDK_INT >= 30) {
      try {
        val token = android.os.CancellationSignal()
        var result: Location? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        val exec = ContextCompat.getMainExecutor(this)
        lm.getCurrentLocation(LocationManager.GPS_PROVIDER, token, exec) { result = it; latch.countDown() }
        latch.await(1200, java.util.concurrent.TimeUnit.MILLISECONDS)
        if (result != null && (result!!.accuracy <= 30f)) {
          try { DbRepo.log(this, null, "【地点规则】系统定位 getCurrentLocation 成功，acc=${result!!.accuracy}") } catch (_: Throwable) {}
          return result
        }
      } catch (_: Throwable) {}
    }
    val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    var best: Location? = null
    for (p in providers) {
      try {
        val last = lm.getLastKnownLocation(p)
        if (last != null) if (best == null || last.accuracy < best!!.accuracy) best = last
      } catch (_: Throwable) {}
    }
    if (best != null) try { DbRepo.log(this, null, "【地点规则】系统最近已知位置 ${best!!.provider} acc=${best!!.accuracy}") } catch (_: Throwable) {}
    return best
  }

  private fun obtainBaiduLocation(ak: String): Location? {
    try {
      val client = LocationClient(applicationContext)
      // 动态设置 AK（老版本 setAK / 新版本 setApiKey），反射兼容
      try {
        val m1 = LocationClient::class.java.getMethod("setApiKey", String::class.java)
        m1.invoke(client, ak)
      } catch (_: Throwable) {
        try {
          val m2 = LocationClient::class.java.getMethod("setAK", String::class.java)
          m2.invoke(client, ak)
        } catch (_: Throwable) {}
      }

      val option = LocationClientOption()
      option.setOpenGps(true)
      option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy)
      option.setScanSpan(0) // 单次
      option.setIsNeedAddress(false)
      option.setCoorType("bd09ll") // 保持一致
      client.locOption = option

      var baiduLoc: BDLocation? = null
      val latch = java.util.concurrent.CountDownLatch(1)
      val listener = object : BDAbstractLocationListener() {
        override fun onReceiveLocation(location: BDLocation?) {
          baiduLoc = location
          latch.countDown()
        }
      }
      client.registerLocationListener(listener)
      client.start()
      latch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS)
      client.unRegisterLocationListener(listener)
      client.stop()

      if (baiduLoc != null && baiduLoc!!.radius <= 30f) {
        val l = Location("baidu")
        l.latitude = baiduLoc!!.latitude
        l.longitude = baiduLoc!!.longitude
        l.accuracy = baiduLoc!!.radius
        try { DbRepo.log(this, null, "【地点规则】百度定位成功 acc=${l.accuracy}") } catch (_: Throwable) {}
        return l
      }
      try { DbRepo.log(this, null, "【地点规则】百度定位无有效结果") } catch (_: Throwable) {}
    } catch (e: Throwable) {
      try { DbRepo.log(this, null, "【地点规则】百度定位异常：" + e.message) } catch (_: Throwable) {}
    }
    return null
  }

  private fun readTargetLocationFromDb(): Pair<Double, Double>? {
    val ks = try { Class.forName("com.example.quote_app.data.DbRepository") } catch (_: Throwable) { null }
    val ctx = this
    val cand = arrayOf("readActiveGeoTarget","getActiveGeoTarget","getGeoTarget","queryTargetLocation")
    for (m in cand) {
      try {
        val method = ks?.getMethod(m, Context::class.java)
        val obj = method?.invoke(null, ctx)
        when (obj) {
          is android.util.Pair<*,*> -> {
            val lat = (obj.first as Number).toDouble()
            val lng = (obj.second as Number).toDouble()
            return lat to lng
          }
          is Array<*> -> if (obj.size >= 2) {
            val lat = (obj[0] as Number).toDouble()
            val lng = (obj[1] as Number).toDouble()
            return lat to lng
          }
          is String -> {
            val sp = obj.split(","); if (sp.size>=2) return sp[0].toDouble() to sp[1].toDouble()
          }
        }
      } catch (_: Throwable) {}
    }
    return try {
      val sp = ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
      val lat = java.lang.Double.longBitsToDouble(sp.getLong("geo_target_lat_bits", java.lang.Double.doubleToRawLongBits(Double.NaN)))
      val lng = java.lang.Double.longBitsToDouble(sp.getLong("geo_target_lng_bits", java.lang.Double.doubleToRawLongBits(Double.NaN)))
      if (lat.isNaN() || lng.isNaN()) null else (lat to lng)
    } catch (_: Throwable) { null }
  }

  private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat/2).pow(2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon/2).pow(2.0)
    val c = 2 * atan2(sqrt(a), sqrt(1-a))
    return R * c
  }


private fun getBaiduAkFromDb(): String? {
  // Try both: Flutter path_provider (files/) and Android default (databases/)
  val cand = arrayOf(
    File(filesDir, "quotes.db").absolutePath,
    File(getDatabasePath("quotes.db").parentFile ?: filesDir, "quotes.db").absolutePath
  )
  for (p in cand) {
    try {
      val f = File(p)
      if (!f.exists()) continue
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(p, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      val c = db.query("notify_config", arrayOf("value"), "key=?", arrayOf("baidu_ak"), null, null, null)
      if (c != null) {
        if (c.moveToFirst()) {
          val v = c.getString(0)
          c.close(); db.close()
          if (!v.isNullOrEmpty()) return v
        } else { c.close(); db.close() }
      } else { db.close() }
    } catch (_: Throwable) {}
  }
  return null
}

}