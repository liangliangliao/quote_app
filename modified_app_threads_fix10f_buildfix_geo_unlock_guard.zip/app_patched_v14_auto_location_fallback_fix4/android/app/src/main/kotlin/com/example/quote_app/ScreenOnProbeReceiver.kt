
package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenOnProbeReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    logWithTime(context, "【解锁后台-探测】收到 $${intent.action}")
  }


  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      com.example.quote_app.data.DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        .getBoolean("configs.location_rules_enabled", false)
    } catch (_: Throwable) { false }
  }

}
