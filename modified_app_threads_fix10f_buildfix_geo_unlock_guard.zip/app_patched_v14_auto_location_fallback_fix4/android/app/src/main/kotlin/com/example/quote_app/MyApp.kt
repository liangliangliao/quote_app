
package com.example.quote_app

import android.app.Application
import android.content.IntentFilter
import android.content.Intent
import android.os.Build

class MyApp : Application() {
  override fun onCreate() {
    super.onCreate()
    try {
      val filter = IntentFilter().apply {
        addAction(Intent.ACTION_USER_PRESENT)
        addAction(Intent.ACTION_USER_UNLOCKED)
        addAction(Intent.ACTION_SCREEN_ON)
      }
      val rcv = UnlockReceiver()
      if (Build.VERSION.SDK_INT >= 33) {
        registerReceiver(rcv, filter, RECEIVER_EXPORTED)
      } else {
        @Suppress("DEPRECATION") registerReceiver(rcv, filter)
      }
      com.example.quote_app.data.DbRepo.log(this, null, "【App】动态注册解锁与亮屏 Receiver 完成")
    } catch (_: Throwable) {}
  }
}
