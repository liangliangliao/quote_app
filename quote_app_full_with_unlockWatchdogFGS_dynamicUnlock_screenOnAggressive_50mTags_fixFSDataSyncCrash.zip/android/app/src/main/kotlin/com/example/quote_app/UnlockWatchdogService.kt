package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder

/**
 * 解锁链路的前台保活服务：
 * - 在服务存活期间，通过动态注册 UnlockReceiver 监听 USER_PRESENT / USER_UNLOCKED；
 * - 以前台服务的形式提高进程在后台的存活率，尽量保证解锁事件可以被捕获；
 * - 不在这里直接执行业务逻辑，所有解锁后的业务仍然交给 UnlockReceiver -> FgKickActivity 完成。
 */
class UnlockWatchdogService : Service() {

    private var unlockReceiver: UnlockReceiver? = null

    override fun onCreate() {
        super.onCreate()

        try {
            com.example.quote_app.data.DbRepo.log(
                this,
                null,
                "[UnlockWatchdogService] onCreate：服务创建，准备注册解锁广播并启动前台通知"
            )
        } catch (_: Throwable) {
        }

        // 1）先注册解锁广播（动态）
        registerUnlockBroadcast()

        // 2）启动前台服务，降低被系统杀进程的概率
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            com.example.quote_app.data.DbRepo.log(
                this,
                null,
                "[UnlockWatchdogService] onStartCommand：startId=" + startId + ", flags=" + flags
            )
        } catch (_: Throwable) {
        }
        // 不自己 stopSelf，保持服务常驻；进程被系统杀死后，系统会根据 START_STICKY 尝试重建。
        return START_STICKY
    }

    private fun registerUnlockBroadcast() {
        try {
            // 避免重复注册
            unlockReceiver?.let { old ->
                try {
                    unregisterReceiver(old)
                } catch (_: Throwable) {
                }
            }

            val r = UnlockReceiver()
            val filter = IntentFilter().apply {
                // 解锁相关广播：
                // - USER_PRESENT：典型场景，锁屏解除后发送
                // - USER_UNLOCKED：用户首次解锁系统用户（仅动态接收）
                // - SCREEN_ON：某些机型/策略下，解锁后只会收到 SCREEN_ON，不会发 USER_PRESENT，
                //              需要结合 KeyguardManager 判断当前是否已解锁
                addAction(Intent.ACTION_USER_PRESENT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    addAction(Intent.ACTION_USER_UNLOCKED)
                }
                addAction(Intent.ACTION_SCREEN_ON)
            }
            registerReceiver(r, filter)
            unlockReceiver = r

            try {
                com.example.quote_app.data.DbRepo.log(
                    this,
                    null,
                    "[UnlockWatchdogService] registerUnlockBroadcast：已动态注册解锁广播（USER_PRESENT/USER_UNLOCKED）"
                )
            } catch (_: Throwable) {
            }
        } catch (t: Throwable) {
            try {
                com.example.quote_app.data.DbRepo.log(
                    this,
                    null,
                    "[UnlockWatchdogService] registerUnlockBroadcast 异常: " + (t.message ?: "unknown")
                )
            } catch (_: Throwable) {
            }
        }
    }

    private fun startAsForeground() {
        try {
            val channelId = "unlock_watchdog"
            val channelName = "解锁提醒守护"
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                var channel = nm.getNotificationChannel(channelId)
                if (channel == null) {
                    channel = NotificationChannel(
                        channelId,
                        channelName,
                        NotificationManager.IMPORTANCE_MIN
                    )
                    channel.description = "用于保持解锁提醒链路存活的前台服务通知"
                    nm.createNotificationChannel(channel)
                }
            }

            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, channelId)
            } else {
                Notification.Builder(this)
            }

            val notif = builder
                .setContentTitle("名人名言 - 解锁提醒已开启")
                .setContentText("为了保证解锁轻提醒与地点规则通知能够及时触发，本服务在后台轻量运行。")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setOngoing(true)
                .build()

            startForeground(1001, notif)

            try {
                com.example.quote_app.data.DbRepo.log(
                    this,
                    null,
                    "[UnlockWatchdogService] startAsForeground：前台服务已启动"
                )
            } catch (_: Throwable) {
            }
        } catch (t: Throwable) {
            try {
                com.example.quote_app.data.DbRepo.log(
                    this,
                    null,
                    "[UnlockWatchdogService] startAsForeground 异常: " + (t.message ?: "unknown")
                )
            } catch (_: Throwable) {
            }
        }
    }

    override fun onDestroy() {
        try {
            // 注销解锁广播，避免内存泄漏
            unlockReceiver?.let { r ->
                try {
                    unregisterReceiver(r)
                } catch (_: Throwable) {
                }
            }
            unlockReceiver = null

            com.example.quote_app.data.DbRepo.log(
                this,
                null,
                "[UnlockWatchdogService] onDestroy：服务被销毁，已注销解锁广播"
            )
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

