
import 'dart:math';
import 'dart:io';
import 'dart:convert';
import 'package:csv/csv.dart';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';
import '../utils/debug_logger.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
  final rnd = r.nextInt(1<<32).toRadixString(36);
  return '${prefix}_${ts}_${rnd}';
}

class ConfigDao {
  Future<int> getRecentHours() async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isEmpty) return 2;
      final v = rows.first['recent_hours'];
      final h = int.tryParse((v ?? '').toString()) ?? 2;
      return h < 1 ? 1 : h;
    } catch (_) {
      return 2;
    }
  }
  Future<void> setRecentHours(int hours) async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      final v = hours < 1 ? 1 : hours;
      if (rows.isEmpty) {
        await db.insert('configs', {'recent_hours': v});
      } else {
        await db.update('configs', {'recent_hours': v}, where: 'id=?', whereArgs: [rows.first['id']]);
      }
    } catch (_) {}
  }

  Future<int> getOverviewThreshold() async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isEmpty) return 500;
      final v = rows.first['overview_threshold'];
      final t = int.tryParse((v ?? '').toString()) ?? 500;
      return t < 1 ? 1 : t;
    } catch (_) {
      return 500;
    }
  }

  /// Returns whether automatic report generation for scales is enabled.
  /// A missing or non-1 value will be treated as disabled (false).
  Future<bool> getAutoReportEnabled() async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isEmpty) return false;
      final v = rows.first['auto_report_enabled'];
      // Accept truthy integer/string values as enabled
      if (v == null) return false;
      if (v is int) return v == 1;
      final s = v.toString();
      return s == '1' || s.toLowerCase() == 'true';
    } catch (_) {
      return false;
    }
  }

  /// Set whether automatic report generation for scales is enabled.
  /// Persists the flag in the configs table; inserts a config row if needed.
  Future<void> setAutoReportEnabled(bool enabled) async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      final val = enabled ? 1 : 0;
      if (rows.isEmpty) {
        await db.insert('configs', {
          'api_key': '',
          'model': 'gpt-5',
          'endpoint': 'https://api.openai.com/v1/responses',
          'recent_hours': 2,
          'overview_threshold': 500,
          'auto_report_enabled': val,
          'ema_enabled': 0,
          'esteem_scale': 100,
          'sses_index': 0,
        });
      } else {
        final id = rows.first['id'];
        await db.update('configs', {'auto_report_enabled': val}, where: 'id=?', whereArgs: [id]);
      }
    } catch (_) {}
  }

  /// 获取是否启用 EMA / SSES 自尊题问答的配置。
  /// 默认返回 false（关闭）。
  Future<bool> getEmaEnabled() async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isEmpty) return false;
      final v = rows.first['ema_enabled'];
      if (v == null) return false;
      if (v is int) return v == 1;
      final s = v.toString();
      return s == '1' || s.toLowerCase() == 'true';
    } catch (_) {
      return false;
    }
  }

  /// 设置是否启用 EMA / SSES 自尊题问答。
  Future<void> setEmaEnabled(bool enabled) async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      final val = enabled ? 1 : 0;
      if (rows.isEmpty) {
        await db.insert('configs', {
          'api_key': '',
          'model': 'gpt-5',
          'endpoint': 'https://api.openai.com/v1/responses',
          'recent_hours': 2,
          'overview_threshold': 500,
          'auto_report_enabled': 0,
          'ema_enabled': val,
          'esteem_scale': 100,
          'sses_index': 0,
        });
      } else {
        final id = rows.first['id'];
        await db.update('configs', {'ema_enabled': val}, where: 'id=?', whereArgs: [id]);
      }
    } catch (_) {}
  }

  /// 获取当前自尊评分尺度（100 或 30）。
  /// 默认返回 100。
  Future<int> getSelfEsteemScale() async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isEmpty) return 100;
      final v = rows.first['esteem_scale'];
      final n = int.tryParse((v ?? '').toString());
      if (n == null) return 100;
      return (n == 30) ? 30 : 100;
    } catch (_) {
      return 100;
    }
  }

  /// 设置自尊评分尺度（100 或 30）。其它值将被忽略并转为 100。
  Future<void> setSelfEsteemScale(int scale) async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      final v = (scale == 30) ? 30 : 100;
      if (rows.isEmpty) {
        await db.insert('configs', {
          'api_key': '',
          'model': 'gpt-5',
          'endpoint': 'https://api.openai.com/v1/responses',
          'recent_hours': 2,
          'overview_threshold': 500,
          'auto_report_enabled': 0,
          'ema_enabled': 0,
          'esteem_scale': v,
          'sses_index': 0,
        });
      } else {
        final id = rows.first['id'];
        await db.update('configs', {'esteem_scale': v}, where: 'id=?', whereArgs: [id]);
      }
    } catch (_) {}
  }

  /// 获取当前 SSES 轮换索引（0-5），如果不存在则返回 0。
  Future<int> getSsesIndex() async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isEmpty) return 0;
      final v = rows.first['sses_index'];
      final n = int.tryParse((v ?? '').toString());
      if (n == null) return 0;
      return n % 6;
    } catch (_) {
      return 0;
    }
  }

  /// 设置 SSES 轮换索引（0-5）。
  Future<void> setSsesIndex(int index) async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      final v = index % 6;
      if (rows.isEmpty) {
        await db.insert('configs', {
          'api_key': '',
          'model': 'gpt-5',
          'endpoint': 'https://api.openai.com/v1/responses',
          'recent_hours': 2,
          'overview_threshold': 500,
          'auto_report_enabled': 0,
          'ema_enabled': 0,
          'esteem_scale': 100,
          'sses_index': v,
        });
      } else {
        final id = rows.first['id'];
        await db.update('configs', {'sses_index': v}, where: 'id=?', whereArgs: [id]);
      }
    } catch (_) {}
  }

  Future<void> setOverviewThreshold(int threshold) async {
    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      final v = threshold < 1 ? 1 : threshold;
      if (rows.isEmpty) {
        await db.insert('configs', {
          'api_key': '',
          'model': 'gpt-5',
          'endpoint': 'https://api.openai.com/v1/responses',
          'recent_hours': 2,
          'overview_threshold': v,
        });
      } else {
        await db.update('configs', {'overview_threshold': v}, where: 'id=?', whereArgs: [rows.first['id']]);
      }
    } catch (_) {
      // ignore
    }
  }
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    await db.insert('configs', {'api_key':'','model':'gpt-5','endpoint':'https://api.openai.com/v1/responses'});
    final one = await db.query('configs', orderBy: 'id DESC', limit: 1);
    return one.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint});
    } else {
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint}, where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }

    Future<bool> isGeoRulesEnabled() async {
    final db = await AppDatabase.instance();
    try {
      final info = await db.rawQuery("PRAGMA table_info(configs)");
      final cols = info.map((e) => e['name'] as String).toList();
      if (!cols.contains('location_rules_enabled')) {
        // 列不存在时补齐并返回 false（默认关闭）
        await db.execute("ALTER TABLE configs ADD COLUMN location_rules_enabled INTEGER DEFAULT 0");
        return false;
      }
    } catch (_) {}
    final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return false;
    final v = (rows.first['location_rules_enabled'] ?? 0).toString();
    return v == '1';
  }
  Future<void> setGeoRulesEnabled(bool enabled) async {
    try {
      final db = await AppDatabase.instance();
      // —— 先确保列存在（兼容旧安装未触发 onUpgrade 的情况）
      try {
        final info = await db.rawQuery("PRAGMA table_info(configs)");
        final cols = info.map((e) => e['name'] as String).toList();
        if (!cols.contains('location_rules_enabled')) {
          await db.execute("ALTER TABLE configs ADD COLUMN location_rules_enabled INTEGER DEFAULT 0");
        }
      } catch (_) {}

      final val = enabled ? 1 : 0;
      // 更新最近一条 configs 记录
      final updated = await db.rawUpdate(
        'UPDATE configs SET location_rules_enabled=? WHERE id=(SELECT id FROM configs ORDER BY id DESC LIMIT 1)',
        [val],
      );
      if (updated == 0) {
        await db.insert('configs', {'id': 1, 'location_rules_enabled': val},
          conflictAlgorithm: ConflictAlgorithm.replace);
      }
    } catch (e) {
      try { await DLog.w('DB', '【ConfigDao】setGeoRulesEnabled 失败：$e'); } catch (_) {}
    }
  }
}