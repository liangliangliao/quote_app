import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 6: 道德能量调度
///
/// 目标：把“道德情绪”从泛化的羞耻/自责，转回到可执行的：
/// - 止血（立即减损）
/// - 治本（长期根因）
/// - 更高忠诚（我到底忠于什么）
class BeliefMoralEnergyPage extends StatefulWidget {
  final int caseId;
  const BeliefMoralEnergyPage({super.key, required this.caseId});

  @override
  State<BeliefMoralEnergyPage> createState() => _BeliefMoralEnergyPageState();
}

class _BeliefMoralEnergyPageState extends State<BeliefMoralEnergyPage> {
  bool _loading = true;
  String _mode = 'comfort';
  final _stopCtl = TextEditingController();
  final _rootCtl = TextEditingController();
  final _loyalCtl = TextEditingController();

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    _mode = (c?['moral_mode']?.toString().trim().isEmpty ?? true) ? 'comfort' : (c?['moral_mode']!.toString());
    _stopCtl.text = (c?['moral_stop_bleed']?.toString() ?? '').trim();
    _rootCtl.text = (c?['moral_treat_root']?.toString() ?? '').trim();
    _loyalCtl.text = (c?['moral_higher_loyalty']?.toString() ?? '').trim();
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final s = _stopCtl.text.trim();
    final r = _rootCtl.text.trim();
    final l = _loyalCtl.text.trim();
    if (s.isEmpty || r.isEmpty || l.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请填写止血/治本/更高忠诚')));
      return;
    }
    await BeliefDao().setMoralEnergy(
      widget.caseId,
      mode: _mode,
      stopBleeding: s,
      treatRoot: r,
      higherLoyalty: l,
    );
    await BeliefDao().addLog(widget.caseId, kind: 'moral', text: '完成道德能量调度');
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _stopCtl.dispose();
    _rootCtl.dispose();
    _loyalCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Step 6  道德能量调度')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('模式选择', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'comfort', label: Text('舒服型：稳住')),
                      ButtonSegment(value: 'strive', label: Text('奋勉型：拔高')),
                    ],
                    selected: {_mode},
                    onSelectionChanged: (s) => setState(() => _mode = s.first),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    '舒服型：先降低内耗、恢复行动力；奋勉型：提高标准、对齐价值。二者都可以是理性的。',
                    style: TextStyle(fontSize: 12, height: 1.35),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _card(
            title: '1) 止血：我立刻要停止的损耗是什么？',
            hint: '例：停止无休止争论/停止刷短视频到深夜/停止对外承诺…',
            ctl: _stopCtl,
            lines: 3,
          ),
          const SizedBox(height: 12),
          _card(
            title: '2) 治本：根因在哪里？',
            hint: '例：边界不清、资源分配不当、习惯系统不支持、缺少证据…',
            ctl: _rootCtl,
            lines: 4,
          ),
          const SizedBox(height: 12),
          _card(
            title: '3) 更高忠诚：我最终忠于什么？',
            hint: '例：专业伦理/长期关系/真实而非面子/可持续健康…',
            ctl: _loyalCtl,
            lines: 3,
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: const Text('保存并继续')),
        ],
      ),
    );
  }

  Widget _card({required String title, required String hint, required TextEditingController ctl, required int lines}) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: ctl,
              maxLines: lines,
              decoration: InputDecoration(hintText: hint, border: const OutlineInputBorder()),
            ),
          ],
        ),
      ),
    );
  }
}
