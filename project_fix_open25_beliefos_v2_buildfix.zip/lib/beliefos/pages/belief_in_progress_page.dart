import 'package:flutter/material.dart';
import '../belief_dao.dart';
import 'belief_review_page.dart';
import 'will/will_check_page.dart';
import 'will/will_breath_anchor_page.dart';

class BeliefInProgressPage extends StatefulWidget {
  final int caseId;
  const BeliefInProgressPage({super.key, required this.caseId});

  @override
  State<BeliefInProgressPage> createState() => _BeliefInProgressPageState();
}

class _BeliefInProgressPageState extends State<BeliefInProgressPage> {
  Map<String, Object?>? _case;
  List<Map<String, Object?>> _logs = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    final l = await BeliefDao().listLogs(widget.caseId);
    if (!mounted) return;
    setState(() {
      _case = c;
      _logs = l;
      _loading = false;
    });
  }

  Future<void> _addLog() async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('记录关键事实'),
          content: TextField(
            controller: controller,
            maxLines: 4,
            decoration: const InputDecoration(
              hintText: '只写事实，不评判。例如：今天会议中我明确提出了不可接受事项；对方同意邮件确认。',
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('取消')),
            FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('保存')),
          ],
        );
      },
    );
    if (ok != true) return;
    final text = controller.text.trim();
    if (text.isEmpty) return;
    await BeliefDao().addLog(widget.caseId, kind: 'fact', text: text);
    await _load();
  }

  void _openWillEngine() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WillCheckPage(caseId: widget.caseId)),
    );
  }

  void _openReview() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => BeliefReviewPage(caseId: widget.caseId, forceOpen: true)),
    ).then((_) => _load());
  }

  String _fmtDate(int? ms) {
    if (ms == null || ms <= 0) return '-';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('行动进行中')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final c = _case;
    if (c == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('行动进行中')),
        body: const Center(child: Text('未找到该案子')),
      );
    }

    final startMs = c['start_date_ms'] as int?;
    final endMs = c['end_date_ms'] as int?;
    final startStr = _fmtDate(startMs);
    final endStr = _fmtDate(endMs);
    final now = DateTime.now();
    final end = endMs != null && endMs > 0 ? DateTime.fromMillisecondsSinceEpoch(endMs) : null;
    final remainingDays = end == null ? null : end.difference(DateTime(now.year, now.month, now.day)).inDays;
    final dText = remainingDays == null ? 'D-?' : (remainingDays <= 0 ? 'D-0（到期）' : 'D-$remainingDays');

    return Scaffold(
      appBar: AppBar(
        title: const Text('行动进行中'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(dText, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text('开始：$startStr  结束：$endStr', style: const TextStyle(fontSize: 13)),
                  const SizedBox(height: 12),
                  const Text('提示：现在只需要做，不需要重新评判。', style: TextStyle(fontSize: 13)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('行动摘要', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text((c['action_plan']?.toString() ?? ''), style: const TextStyle(fontSize: 13, height: 1.4)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _addLog,
                  icon: const Icon(Icons.edit_note),
                  label: const Text('记录关键事实'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _openWillEngine,
                  icon: const Icon(Icons.bolt),
                  label: const Text('意志引擎'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => WillBreathAnchorPage(caseId: widget.caseId)),
                );
              },
              icon: const Icon(Icons.air),
              label: const Text('呼吸—努力锚点（60秒）'),
            ),
          ),

          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _openReview,
              icon: const Icon(Icons.fact_check),
              label: Text(remainingDays != null && remainingDays <= 0 ? '到期复盘与决断' : '提前复盘（可选）'),
            ),
          ),
          const SizedBox(height: 16),
          const Text('事实记录（最近在上）', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          if (_logs.isEmpty)
            const Text('暂无记录', style: TextStyle(fontSize: 13))
          else
            ..._logs.map((e) {
              final ts = e['ts_ms'] as int?;
              final d = ts == null ? null : DateTime.fromMillisecondsSinceEpoch(ts);
              final t = d == null ? '' : '${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
              return Card(
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t, style: const TextStyle(fontSize: 12)),
                      const SizedBox(height: 6),
                      Text(e['text']?.toString() ?? '', style: const TextStyle(fontSize: 13, height: 1.35)),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}
