import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 1.5: 代价澄清（不做也是选择）
///
/// Purpose:
/// - 把“被迫性”具象化：不做选择也会产生后果。
/// - 在进入期待/下注之前，先把风险与代价摆上桌。
class BeliefStakesPage extends StatefulWidget {
  final int caseId;
  const BeliefStakesPage({super.key, required this.caseId});

  @override
  State<BeliefStakesPage> createState() => _BeliefStakesPageState();
}

class _BeliefStakesPageState extends State<BeliefStakesPage> {
  bool _loading = true;
  final _worst = TextEditingController();
  final _likely = TextEditingController();
  final _actionCost = TextEditingController();

  bool _isBlank(String s) => s.trim().isEmpty;

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    _worst.text = (c?['stake_inaction_worst']?.toString() ?? '').trim();
    _likely.text = (c?['stake_inaction_likely']?.toString() ?? '').trim();
    _actionCost.text = (c?['stake_action_cost']?.toString() ?? '').trim();
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final worst = _worst.text.trim();
    final likely = _likely.text.trim();
    final actionCost = _actionCost.text.trim();

    if (_isBlank(worst) || _isBlank(likely) || _isBlank(actionCost)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请把三项都写完（不做/去做的代价都要摆出来）')),
      );
      return;
    }

    await BeliefDao().setStakes(
      widget.caseId,
      inactionWorst: worst,
      inactionLikely: likely,
      actionCost: actionCost,
    );
    await BeliefDao().addLog(widget.caseId, kind: 'stakes', text: '澄清代价：不做/去做');

    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _worst.dispose();
    _likely.dispose();
    _actionCost.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('代价澄清')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                '“不选择”也是一种选择。\n\n在进入期待审计/下注之前，把代价说清：\n1) 不做会发生什么？\n2) 最可能的后果是什么？\n3) 去做要承担哪些成本/风险？',
                style: TextStyle(fontSize: 12, height: 1.35),
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _worst,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: '如果我“不做选择”，最坏会发生什么？',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _likely,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: '如果我“不做选择”，最可能会发生什么？',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _actionCost,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: '如果我“去做选择/去下注”，我要承担哪些成本/风险？',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _save, child: const Text('保存并返回')),
        ],
      ),
    );
  }
}
