import 'package:workmanager/workmanager.dart';
import 'services/notification_service.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';

@pragma('vm:entry-point')
void alarmCallback() async {
  await NotificationService.init();
  await NotificationService.showSimple('闹钟通知', 'AlarmManager 定时触发');
}

@pragma('vm:entry-point')
void workCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    await NotificationService.init();
    await NotificationService.showSimple('后台任务', 'WorkManager 周期触发');
    return Future.value(true);
  });
}

Future<void> registerBackgroundTasks() async {
  // 初始化插件
  await Workmanager().initialize(workCallbackDispatcher, isInDebugMode: false);

  // 每 6 小时执行一次
  // 自检：2分钟后触发一次，验证后台通道是否正常
  await AndroidAlarmManager.oneShot(
    const Duration(minutes: 2),
    801,
    alarmCallback,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );

  await Workmanager().registerPeriodicTask(
    'periodic-notify',
    'periodic-notify',
    frequency: const Duration(hours: 6),
  );

  // 初始化 AlarmManager
  await AndroidAlarmManager.initialize();

  // 每日 8:30 闹钟
  final now = DateTime.now();
  final first = DateTime(now.year, now.month, now.day, 8, 30);
  final start = first.isBefore(now) ? first.add(const Duration(days: 1)) : first;

  await AndroidAlarmManager.periodic(
    const Duration(days: 1),
    888,
    alarmCallback,
    startAt: start,
    exact: true,
    wakeup: true,
    rescheduleOnReboot: true,
  );
}
