package com.example.quote_app

import io.flutter.app.FlutterApplication

/**
 * Minimal Application for Flutter V2 embedding.
 * android_alarm_manager_plus (4.x) no longer requires a V1 PluginRegistrant.
 * Background isolate will be bootstrapped by the plugin automatically.
 */
class MyApp : FlutterApplication()