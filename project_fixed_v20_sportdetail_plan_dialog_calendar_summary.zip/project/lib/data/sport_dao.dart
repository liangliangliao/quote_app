import 'dart:async';
import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import 'db.dart';

/// A lightweight data access object for sport plans and records.
///
/// The sport tables store user configured exercise plans (sport_plans)
/// and historical workout sessions (sport_records).  All fields are
/// optional to simplify migrations; consumers should perform null checks
/// where appropriate.  This DAO exposes basic CRUD operations and hides
/// the underlying SQLite details.
class SportDao {
  /// Fetch all sport plans ordered by descending id (latest first).
  Future<List<Map<String, dynamic>>> getPlans() async {
    final db = await AppDatabase.instance();
    return db.query('sport_plans', orderBy: 'id DESC');
  }

  /// Load a single plan by id. Returns null if not found.
  Future<Map<String, dynamic>?> getPlan(int id) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('sport_plans', where: 'id=?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// Insert a new plan. Returns the new row id.
  Future<int> insertPlan(Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['created_at'] = DateTime.now().toIso8601String();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.insert('sport_plans', data);
  }

  /// Update an existing plan. Returns the number of affected rows.
  Future<int> updatePlan(int id, Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.update('sport_plans', data, where: 'id=?', whereArgs: [id]);
  }

  /// Delete a plan by id. Returns the number of affected rows.
  Future<int> deletePlan(int id) async {
    final db = await AppDatabase.instance();
    return db.delete('sport_plans', where: 'id=?', whereArgs: [id]);
  }

  /// Fetch all sport records ordered by descending id (latest first).
  Future<List<Map<String, dynamic>>> getRecords() async {
    final db = await AppDatabase.instance();
    return db.query('sport_records', orderBy: 'id DESC');
  }

  /// Fetch records associated with a particular plan id.
  Future<List<Map<String, dynamic>>> getRecordsByPlan(int planId) async {
    final db = await AppDatabase.instance();
    return db.query('sport_records', where: 'plan_id=?', whereArgs: [planId], orderBy: 'id DESC');
  }

  /// Insert a new record. Returns the new row id.
  Future<int> insertRecord(Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['created_at'] = DateTime.now().toIso8601String();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.insert('sport_records', data);
  }

  /// Update a record by id. Returns the number of affected rows.
  Future<int> updateRecord(int id, Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.update('sport_records', data, where: 'id=?', whereArgs: [id]);
  }

  /// Delete a record by id. Returns the number of affected rows.
  Future<int> deleteRecord(int id) async {
    final db = await AppDatabase.instance();
    return db.delete('sport_records', where: 'id=?', whereArgs: [id]);
  }

  /// Load a single record by id. Returns null if not found.
  Future<Map<String, dynamic>?> getRecord(int id) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('sport_records', where: 'id=?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// Fetch the latest unfinished record (in_progress/paused/stopped/not_started).
  ///
  /// If [planId] is provided, filters to that plan.
  Future<Map<String, dynamic>?> getLatestUnfinishedRecord({int? planId}) async {
    final db = await AppDatabase.instance();
    final where = planId == null
        ? "status IN ('not_started','in_progress','paused','stopped')"
        : "plan_id=? AND status IN ('not_started','in_progress','paused','stopped')";
    final whereArgs = planId == null ? null : [planId];
    final rows = await db.query(
      'sport_records',
      where: where,
      whereArgs: whereArgs,
      orderBy: 'id DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// When the app process is killed, any in_progress record should be treated as paused.
  Future<void> markInProgressAsPaused() async {
    final db = await AppDatabase.instance();
    await db.update(
      'sport_records',
      {'status': 'paused', 'updated_at': DateTime.now().toIso8601String()},
      where: "status='in_progress'",
    );
  }

  /// Fetch records for a plan within [startInclusive, endExclusive].
  Future<List<Map<String, dynamic>>> getRecordsByPlanBetween(
    int planId,
    DateTime startInclusive,
    DateTime endExclusive,
  ) async {
    final db = await AppDatabase.instance();
    return db.query(
      'sport_records',
      where: 'plan_id=? AND start_time>=? AND start_time<?',
      whereArgs: [planId, startInclusive.toIso8601String(), endExclusive.toIso8601String()],
      orderBy: 'start_time ASC',
    );
  }

  /// Aggregate summary for records between [startInclusive, endExclusive].
  /// If [planId] is provided, filters to that plan.
  Future<Map<String, dynamic>> getHistorySummary(
    DateTime startInclusive,
    DateTime endExclusive, {
    int? planId,
  }) async {
    final db = await AppDatabase.instance();
    final where = planId == null
        ? 'start_time>=? AND start_time<?'
        : 'plan_id=? AND start_time>=? AND start_time<?';
    final whereArgs = planId == null
        ? [startInclusive.toIso8601String(), endExclusive.toIso8601String()]
        : [planId, startInclusive.toIso8601String(), endExclusive.toIso8601String()];

    final rows = await db.rawQuery(
      'SELECT '
      'COUNT(*) AS total_count, '
      "SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed_count, "
      'SUM(COALESCE(total_duration,0)) AS total_duration_sum, '
      'SUM(COALESCE(total_steps,0)) AS total_steps_sum, '
      'SUM(COALESCE(total_distance,0)) AS total_distance_sum '
      'FROM sport_records '
      'WHERE $where',
      whereArgs,
    );
    if (rows.isEmpty) {
      return {
        'total_count': 0,
        'completed_count': 0,
        'total_duration_sum': 0,
        'total_steps_sum': 0,
        'total_distance_sum': 0.0,
      };
    }
    return rows.first;
  }
}