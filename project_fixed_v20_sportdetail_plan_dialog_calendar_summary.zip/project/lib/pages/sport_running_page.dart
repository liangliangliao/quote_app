import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:audioplayers/audioplayers.dart';

import '../data/dao.dart';
import '../data/sport_dao.dart';

/// 运动进行时页面
///
/// 支持 10 秒倒计时、实时计时、距离和步数估算、状态切换
/// （进行中 / 已暂停 / 已停止 / 已完成）、目标检测与保存历史记录。
class SportRunningPage extends StatefulWidget {
  final int recordId;
  final Map<String, dynamic>? plan;
  final String mode; // 'plan' or 'instant'

  const SportRunningPage({super.key, required this.recordId, this.plan, required this.mode});

  @override
  State<SportRunningPage> createState() => _SportRunningPageState();
}

class _SportRunningPageState extends State<SportRunningPage> {
  final SportDao _dao = SportDao();
  final ConfigDao _configDao = ConfigDao();

  String? _bgImagePath;
  String? _startSoundPath;
  final AudioPlayer _audioPlayer = AudioPlayer();
  static const MethodChannel _sys = MethodChannel('com.example.quote_app/sys');
  int _countdown = 10;
  Timer? _countdownTimer;
  Timer? _updateTimer;
  Stopwatch _stopwatch = Stopwatch();
  bool _paused = false;
  String _status = 'not_started';
  double _distance = 0.0; // meters
  int _steps = 0;
  Position? _lastPosition;
  StreamSubscription<Position>? _positionSub;
  String get _targetType => widget.plan?['target_type']?.toString() ?? 'steps';
  double? get _targetValue => widget.plan?['target_value'] is num
      ? (widget.plan?['target_value'] as num).toDouble()
      : null;
  String get _targetUnit => widget.plan?['target_unit']?.toString() ?? '步';

  @override
  void initState() {
    super.initState();
    // Start countdown
    _status = 'not_started';
    _startCountdown();
    // Request location permission
    _initLocation();
    _loadUiSettings();
  }

  Future<void> _loadUiSettings() async {
    try {
      final bg = await _configDao.getSportRunningBg();
      final sound = await _configDao.getSportStartSound();
      if (!mounted) return;
      setState(() {
        _bgImagePath = (bg?.trim().isEmpty ?? true) ? null : bg;
        _startSoundPath = (sound?.trim().isEmpty ?? true) ? null : sound;
      });
    } catch (_) {}
  }

  Future<void> _initLocation() async {
    try {
      await Geolocator.requestPermission();
    } catch (_) {}
  }

  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _countdown--;
        if (_countdown <= 0) {
          timer.cancel();
          _startRunning();
        }
      });
    });
  }

  void _startRunning() {
    setState(() {
      _status = 'in_progress';
    });
    _playStartBell();
    _stopwatch.start();
    // subscribe location updates
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, distanceFilter: 5),
    ).listen((pos) {
      _onPositionUpdate(pos);
    });
    // periodic update timer for UI
    _updateTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {});
      _checkTargetReached();
    });
  }

  Future<void> _playStartBell() async {
    // Prefer custom selected sound file; if missing, fall back to system notification sound.
    try {
      final p = _startSoundPath;
      if (p != null && p.isNotEmpty) {
        await _audioPlayer.stop();
        await _audioPlayer.play(DeviceFileSource(p));
        return;
      }
    } catch (_) {}
    try {
      await _sys.invokeMethod('playSystemNotificationSound');
    } catch (_) {}
  }

  void _onPositionUpdate(Position pos) {
    if (_status != 'in_progress') return;
    if (_lastPosition != null) {
      final dist = Geolocator.distanceBetween(
        _lastPosition!.latitude,
        _lastPosition!.longitude,
        pos.latitude,
        pos.longitude,
      );
      if (dist.isFinite && dist > 0) {
        _distance += dist;
        // Estimate steps: approximate stride length 0.7 m
        _steps = (_distance / 0.7).floor();
      }
    }
    _lastPosition = pos;
  }

  String _formatDuration(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  double _calcAvgSpeed() {
    final seconds = _stopwatch.elapsed.inSeconds;
    if (seconds <= 0) return 0.0;
    final hours = seconds / 3600.0;
    final km = _distance / 1000.0;
    return km / hours;
  }

  void _togglePause() {
    if (_status == 'in_progress') {
      // pause
      setState(() {
        _status = 'paused';
        _paused = true;
        _stopwatch.stop();
      });
    } else if (_status == 'paused') {
      // resume
      setState(() {
        _status = 'in_progress';
        _paused = false;
        _stopwatch.start();
      });
    }
  }

  void _stop() {
    if (_status == 'completed') return;
    setState(() {
      _status = 'stopped';
    });
    _stopwatch.stop();
    _finishRecord();
  }

  void _restart() {
    // resets all data and start again
    setState(() {
      _status = 'in_progress';
      _distance = 0.0;
      _steps = 0;
      _lastPosition = null;
    });
    _stopwatch
      ..reset()
      ..start();
  }

  void _checkTargetReached() {
    if (_status != 'in_progress') return;
    if (_targetValue == null || _targetValue! <= 0) return;
    double progress;
    if (_targetType == 'steps') {
      progress = _steps.toDouble();
    } else if (_targetType == 'duration') {
      progress = _stopwatch.elapsed.inMinutes.toDouble();
    } else {
      // distance (km)
      progress = _distance / 1000.0;
    }
    if (progress >= _targetValue!) {
      _complete();
    }
  }

  void _complete() {
    if (_status == 'completed') return;
    setState(() {
      _status = 'completed';
    });
    _stopwatch.stop();
    _finishRecord(completed: true);
  }

  Future<void> _finishRecord({bool completed = false}) async {
    // Save to DB
    final record = <String, dynamic>{
      'end_time': DateTime.now().toIso8601String(),
      'total_duration': _stopwatch.elapsed.inSeconds,
      'total_steps': _steps,
      'total_distance': _distance,
      'avg_speed': _calcAvgSpeed(),
      'status': completed ? 'completed' : (_status == 'stopped' ? 'stopped' : 'paused'),
      'start_location': _lastPosition == null
          ? null
          : jsonEncode({
              'lat': _lastPosition!.latitude,
              'lon': _lastPosition!.longitude,
            }),
      'end_location': _lastPosition == null
          ? null
          : jsonEncode({
              'lat': _lastPosition!.latitude,
              'lon': _lastPosition!.longitude,
            }),
    };
    await _dao.updateRecord(widget.recordId, record);
    if (completed && mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('恭喜完成'),
          content: const Text('运动已达标！'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('确定'),
            ),
          ],
        ),
      ).then((_) {
        Navigator.of(context).pop();
      });
    }
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _updateTimer?.cancel();
    _positionSub?.cancel();
    try { _audioPlayer.dispose(); } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final elapsed = _stopwatch.elapsed;
    final targetVal = _targetValue;
    final remainingText = () {
      if (targetVal == null || targetVal <= 0) return '';
      double progress;
      double remain;
      String unit;
      if (_targetType == 'steps') {
        progress = _steps.toDouble();
        remain = targetVal - progress;
        unit = '步';
      } else if (_targetType == 'duration') {
        progress = elapsed.inMinutes.toDouble();
        remain = targetVal - progress;
        unit = '分钟';
      } else {
        progress = _distance / 1000.0;
        remain = targetVal - progress;
        unit = 'km';
      }
      if (remain < 0) remain = 0;
      return '剩余: ${remain.toStringAsFixed(1)} $unit';
    }();

    return Scaffold(
      appBar: AppBar(
        title: const Text('运动进行中'),
      ),
      body: Container(
        decoration: (_bgImagePath != null && _bgImagePath!.isNotEmpty && File(_bgImagePath!).existsSync())
            ? BoxDecoration(
                image: DecorationImage(
                  image: FileImage(File(_bgImagePath!)),
                  fit: BoxFit.cover,
                ),
              )
            : null,
        child: Container(
          color: (_bgImagePath != null && _bgImagePath!.isNotEmpty) ? Colors.white.withOpacity(0.88) : null,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
          children: [
            // 名人名言
            Card(
              color: const Color(0xFFF0F8FF),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Column(
                  children: [
                    Text('生命在于运动', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text('—— 伏尔泰', style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            if (_status == 'not_started')
              // 倒计时
              Column(
                children: [
                  Text('准备开始', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  Text(
                    '$_countdown',
                    style: const TextStyle(fontSize: 64, fontWeight: FontWeight.bold, color: Colors.green),
                  ),
                ],
              )
            else
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('状态: ${_status == 'in_progress' ? '进行中' : _status == 'paused' ? '已暂停' : _status == 'stopped' ? '已停止' : '已完成'}',
                        style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('已用时: ${_formatDuration(elapsed)}', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('步数: $_steps 步', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('距离: ${(_distance / 1000.0).toStringAsFixed(2)} km', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('平均速度: ${_calcAvgSpeed().toStringAsFixed(2)} km/h', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    if (targetVal != null && targetVal > 0) Text(remainingText, style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
          ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: _status == 'not_started'
          ? null
          : BottomAppBar(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  // Pause/Continue
                  if (_status == 'in_progress' || _status == 'paused')
                    IconButton(
                      icon: Icon(_status == 'paused' ? Icons.play_arrow : Icons.pause),
                      onPressed: _togglePause,
                    ),
                  // Stop / Restart
                  if (_status == 'in_progress' || _status == 'paused')
                    IconButton(
                      icon: const Icon(Icons.stop),
                      onPressed: _stop,
                    ),
                  if (_status == 'stopped')
                    IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: _restart,
                    ),
                ],
              ),
            ),
    );
  }
}