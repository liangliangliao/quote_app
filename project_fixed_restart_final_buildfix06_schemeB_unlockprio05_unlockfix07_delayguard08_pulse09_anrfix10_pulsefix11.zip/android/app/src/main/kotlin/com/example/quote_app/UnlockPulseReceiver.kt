package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.os.SystemClock
import kotlin.concurrent.thread

/**
 * UnlockPulse 的回调接收器：
 * - 每次触发后自循环调度下一次（非 WorkManager）；
 * - 只在检测到“从锁屏->已解锁”的状态跃迁时触发业务；
 * - 其余时间只更新 lastLocked 状态。
 */
class UnlockPulseReceiver : BroadcastReceiver() {

  override fun onReceive(context: Context, intent: Intent?) {
    val app = context.applicationContext
    thread(name = "unlock-pulse") {
      try {
        // 如果功能已关闭，则取消后续脉冲。
        if (!UnlockPulse.shouldEnable(app)) {
          UnlockPulse.logWithTime(app, "【解锁脉冲】功能已关闭，取消脉冲（回包：DISABLED）")
          UnlockPulse.cancel(app)
          return@thread
        }

        val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val km = app.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager

        // 记录“脉冲回调是否长期没跑”的 gap：用于兜底判断。
        val nowElapsed = try { SystemClock.elapsedRealtime() } catch (_: Throwable) { 0L }
        val lastElapsed = try { UnlockPulse.getLastPulseElapsed(app) } catch (_: Throwable) { 0L }
        val gapMs = if (nowElapsed > 0L && lastElapsed > 0L) (nowElapsed - lastElapsed) else 0L
        try { UnlockPulse.setLastPulseElapsed(app, nowElapsed) } catch (_: Throwable) {}

        val interactive = try { pm?.isInteractive ?: false } catch (_: Throwable) { false }
        val locked = try { km?.isKeyguardLocked ?: true } catch (_: Throwable) { true }

        // 将“屏幕不亮/不可交互”也视为 locked，便于后续识别 unlock 跃迁。
        val nowLocked = (!interactive) || locked
        val lastLocked = UnlockPulse.getLastLocked(app)

        // 更新 lastLocked（先更新，避免并发）
        UnlockPulse.setLastLocked(app, nowLocked)

        // 自循环调度下一次：
        // - 若当前处于锁屏/上锁：更频繁一点（30s）提高解锁后命中率
        // - 若已解锁：降低频率（90s）降低后台唤醒
        val nextDelay = if (nowLocked) 30_000L else 90_000L
        UnlockPulse.scheduleNext(app, delayMs = nextDelay, preferExact = !nowLocked)

        // 低频心跳日志（避免你在“日志表”里看不到任何动静，以为没生效）：
        // - 状态变化时记录
        // - 或每 10 分钟记录一次
        val nowWall = System.currentTimeMillis()
        val lastHeartbeat = try { UnlockPulse.getLastHeartbeatWall(app) } catch (_: Throwable) { 0L }
        val shouldHeartbeat = (lastLocked != nowLocked) || (lastHeartbeat <= 0L) || ((nowWall - lastHeartbeat) > 10 * 60_000L)
        if (shouldHeartbeat) {
          try { UnlockPulse.setLastHeartbeatWall(app, nowWall) } catch (_: Throwable) {}
          UnlockPulse.logWithTime(
            app,
            "【解锁脉冲】tick interactive=$interactive keyguardLocked=$locked nowLocked=$nowLocked lastLocked=$lastLocked gapMs=$gapMs nextDelayMs=$nextDelay"
          )
        }

        // 触发条件：
        // A) 正常状态跃迁：locked -> unlocked
        // B) 兜底：脉冲长时间未回调（常见于 Doze/冻结），但当前已是 unlocked，则推断“刚刚发生过解锁”
        //    - 该兜底可以覆盖“锁屏期间 alarm 被系统延迟，导致 lastLocked 没来得及更新为 true”的场景。
        val transitionUnlock = lastLocked && !nowLocked
        val gapUnlock = (!nowLocked) && (!lastLocked) && (gapMs >= 3 * 60_000L)
        if (transitionUnlock || gapUnlock) {
          val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
          val lastTrigger = sp.getLong("last_unlock_trigger_ts", 0L)
          if (lastTrigger > 0 && (nowWall - lastTrigger) < 3000L) {
            UnlockPulse.logWithTime(app, "【解锁脉冲】3 秒内已触发过解锁链路，跳过（回包：SKIP_DUP）")
            return@thread
          }
          // gapUnlock 可能发生在系统“补投递”多个延迟 alarm 的情况下，额外加一道更长的去重。
          if (gapUnlock && lastTrigger > 0 && (nowWall - lastTrigger) < 120_000L) {
            UnlockPulse.logWithTime(app, "【解锁脉冲】gapUnlock 2 分钟内已触发过，跳过（回包：SKIP_GAP_DUP）")
            return@thread
          }

          sp.edit().putLong("last_unlock_trigger_ts", nowWall).apply()

          // 已确认解锁并即将执行业务：取消 5 分钟窗口兜底（避免重复）
          try { UnlockWatchdog.cancel(app) } catch (_: Throwable) {}

          val reason = if (transitionUnlock) "TRANSITION" else "GAP"
          UnlockPulse.logWithTime(app, "【解锁脉冲】触发解锁链路 reason=$reason gapMs=$gapMs（回包：OK）")

          UnlockEventHandler.withHighPriority(app, "pulse") {
            try { UnlockEventHandler.handleUnlockLightReminder(app, source = "pulse") } catch (_: Throwable) {}
            try { GeoUnlockOrchestrator.run(app, "pulse") } catch (_: Throwable) {}
          }
        }
      } catch (t: Throwable) {
        try { UnlockPulse.logWithTime(app, "【解锁脉冲】异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
        // 异常时仍尽量保持脉冲链路不断：下一次 90s 再试
        try { UnlockPulse.scheduleNext(app, delayMs = 90_000L, preferExact = true) } catch (_: Throwable) {}
      }
    }
  }
}
