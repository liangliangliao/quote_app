
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../platform/native_scheduler.dart';
import 'task_runner.dart';

class SchedulerService {
  static Future<void> init() async { /* no-op: Workmanager.initialize is handled in main.dart */ }

  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final start = (t['start_time'] ?? '09:00').toString();
    final now = DateTime.now();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length>1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (!next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }

  static int _alarmId(String uid, String runKey) {
    return (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;
  }

  static String _runKeyFromTime(DateTime t) {
    return DateFormat('yyyyMMdd_HHmm').format(t);
  }

  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);

    try {
      await NativeScheduler.scheduleExactAt(
        id: _alarmId(uid, runKey),
        epochMs: next.millisecondsSinceEpoch,
        payload: {'uid': uid, 'runKey': runKey},
      );
      await DLog.i('SCH', 'AM 注册完成 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.w('SCH','AM 注册失败，忽略: '+e.toString());
    }

    try {
      final delay = next.difference(DateTime.now());
      await Workmanager().registerOneOffTask(
        'wm_run_'+uid+'_'+runKey,
        'wm_task',
        initialDelay: delay.isNegative ? Duration.zero : delay,
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.e('SCH','WM 注册失败: '+e.toString());
    }
  }

  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      await scheduleNextForTask((t['task_uid'] ?? '').toString());
    }
  }

  static Future<void> cancelNextForTask(String uid) async {
    try { await Workmanager().cancelAll(); } catch (_) {}
    try { await NativeScheduler.cancel(0); } catch (_) {}
  }

  static Future<void> wmRunTask(String uid, String? runKey) async {
    await TaskRunner.run(uid);
  }

  static Future<void> callback(String uid, String? runKey) async {
    await TaskRunner.run(uid);
  }

  static Future<void> catchupIfMissed() async {}
}
