package com.example.quote_app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.location.Location
import com.example.quote_app.data.DbRepo
import org.json.JSONObject

/**
 * 地点规则通用引擎：
 * - 读取 configs.location_rules_enabled 开关
 * - 遍历 vision_triggers(type='geo', enabled=1) 的所有目标位置
 * - 只要有一个目标位置在合理范围内，就发送一次通知提醒（取最近命中的那个）
 */
object GeoRuleEngine {

  data class GeoTarget(
    val lat: Double,
    val lng: Double,
    val place: String,
    val note: String
  )

  @JvmStatic
  fun isGeoEnabled(ctx: Context): Boolean {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return false
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
          c.moveToFirst() && (c.getInt(0) == 1)
        }
      } finally {
        try { db.close() } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {
      false
    }
  }

  @JvmStatic
  fun loadTargets(ctx: Context): List<GeoTarget> {
    val out = ArrayList<GeoTarget>()
    try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return emptyList()
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery(
          "SELECT config, then_text FROM vision_triggers WHERE type='geo' AND enabled=1",
          null
        ).use { c ->
          while (c.moveToNext()) {
            val cfgStr = c.getString(0) ?: ""
            val thenText = c.getString(1) ?: ""
            try {
              val jo = JSONObject(cfgStr)
              val lat = jo.optDouble("lat", Double.NaN)
              val lng = jo.optDouble("lng", Double.NaN)
              if (lat.isNaN() || lng.isNaN()) continue
              val place = jo.optString("place", "").ifBlank { "目标地点" }
              val note = jo.optString("note", "").ifBlank { thenText.ifBlank { "你已到达 $place ，别忘了你的目标" } }
              out.add(GeoTarget(lat, lng, place, note))
            } catch (_: Throwable) {
              // ignore malformed
            }
          }
        }
      } finally {
        try { db.close() } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {
      // ignore
    }
    return out
  }

  /**
   * 遍历所有目标位置，若命中任意一个则发送一次通知（最近命中者）。
   */
  @JvmStatic
  fun evaluateAndNotify(ctx: Context, current: Location, targets: List<GeoTarget>, radiusMeters: Double = 100.0): Boolean {
    if (targets.isEmpty()) return false
    var best: GeoTarget? = null
    var bestDist = Double.MAX_VALUE

    for (t in targets) {
      val distArr = FloatArray(1)
      android.location.Location.distanceBetween(current.latitude, current.longitude, t.lat, t.lng, distArr)
      val d = distArr[0].toDouble()
      try {
        logWithTime(ctx, "【地点规则】对比目标(${t.place}) 距离=${d}m")
      } catch (_: Throwable) {}
      if (d <= radiusMeters && d < bestDist) {
        bestDist = d
        best = t
      }
    }

    val hit = best
    if (hit != null) {
      try { logWithTime(ctx, "正在对比当前位置与目标位置距离，比对结果是当前位置在目标位置合理范围，将发送通知提醒") } catch (_: Throwable) {}
      val id = 3000 + ((hit.place.hashCode()) and 0x7fffffff)
      try { NotifyHelper.send(ctx, id, "愿景地点提醒", hit.note, null, "vision_focus", null) } catch (_: Throwable) {}
      try { logWithTime(ctx, "通知发送成功") } catch (_: Throwable) {}
      return true
    }

    try { logWithTime(ctx, "正在对比当前位置与目标位置距离，比对结果是当前位置不在目标位置合理范围，不发送通知提醒") } catch (_: Throwable) {}
    return false
  }

  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
