package com.example.quote_app

object BackCloser {
    @JvmStatic var finishOnResume: Boolean = false
}
