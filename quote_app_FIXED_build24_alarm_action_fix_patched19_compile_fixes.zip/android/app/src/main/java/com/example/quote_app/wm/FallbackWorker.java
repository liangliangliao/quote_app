package com.example.quote_app.wm;

import android.content.Context;
import com.example.quote_app.schedule.PostNotify;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ListenableWorker;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import androidx.core.app.NotificationCompat;
import androidx.work.ForegroundInfo;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.AutoRescheduler;
import com.example.quote_app.wm.WmNames;

import java.util.concurrent.TimeUnit;

public final class FallbackWorker extends Worker {

    public FallbackWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    
    private ForegroundInfo makeFg(Context ctx, String uid) {
        // Use existing default channel to minimize changes
        final String CHANNEL_ID = "quote_default";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Quotes", NotificationManager.IMPORTANCE_LOW);
                    nm.createNotificationChannel(ch);
                }
            } catch (Throwable ignore) {}
        }
        NotificationCompat.Builder nb = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("正在准备发送通知")
                .setContentText(uid == null ? "" : uid)
                .setOngoing(true);
        // The notificationId should be stable but not clash with normal notifications
        int notificationId = 10001;
        return new ForegroundInfo(notificationId, nb.build());
    }
    @Override public ListenableWorker.Result doWork() {
        try { setForegroundAsync(makeFg(getApplicationContext(), null)); } catch (Throwable ignore) {}
        Context ctx = getApplicationContext();
        Data in = getInputData();
        String uid = in.getString("uid");
        if (uid == null || uid.isEmpty()) uid = in.getString("task_uid");
        String runKey = in.getString("runKey");
        if (runKey == null || runKey.isEmpty()) runKey = in.getString("run_key");
        int attempt = in.getInt("attempt", 1);

        try {
            DbRepository.log(ctx, uid, "【原生】fallback-wm 触发 uid="+uid+" run="+runKey+" attempt="+attempt);
            boolean ok = Biz.run(ctx, uid);
            return com.example.quote_app.schedule.PostNotify.onWmResult(ctx, "fallback-wm", uid, runKey, ok, attempt);
        } catch (Throwable t) {
            DbRepository.log(ctx, uid, "WM兜底异常: " + t.getMessage());
            return Result.retry();
        }
    } catch (Throwable t) {
            DbRepository.log(ctx, uid, "WM兜底异常: " + t.getMessage());
            return Result.retry();
        }
    }
}