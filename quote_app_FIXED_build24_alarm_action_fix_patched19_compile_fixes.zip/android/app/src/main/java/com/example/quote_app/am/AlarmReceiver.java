package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import com.example.quote_app.schedule.PostNotify;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import androidx.work.WorkManager;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.wm.WmScheduler;
import com.example.quote_app.wm.WmNames;
import com.example.quote_app.schedule.AutoRescheduler;

import org.json.JSONObject;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try { com.example.quote_app.data.DbRepo.log(context, null, "【原生】AM 广播触发"); } catch (Throwable ignore) {}
        String _act = intent==null?null:intent.getAction();
try { com.example.quote_app.data.DbRepo.log(context, null, "【原生】AM Intent action="+String.valueOf(_act)); } catch (Throwable ignore) {}
int id = intent != null ? intent.getIntExtra("id", 0) : 0;
        String payload = intent != null ? intent.getStringExtra("payload") : "{}";
        String uid = null;
        String runKey = "";

        try {
            DbRepository.log(context.getApplicationContext(), uid==null?"":uid, "【原生】AM 触发 uid="+(uid==null?"":uid)+" run="+runKey);
            JSONObject obj = new JSONObject(payload == null ? "{}" : payload);
            uid = obj.optString("uid", null);
            runKey = obj.optString("runKey", "");
            try { DbRepository.log(context.getApplicationContext(), uid==null?"":uid, "【原生】AM 触发(解析后) uid="+(uid==null?"":uid)+" run="+runKey); } catch (Throwable ignore) {}

        } catch (Throwable ignore) {}

        if (TextUtils.isEmpty(uid)) {
            // 兜底：没有 uid 仍然发一个到点提醒
            String title = "提醒";
            String body = "到点了";
            try { NotifyHelper.send(context.getApplicationContext(), id, title, body, null); } catch (Throwable ignore) {}
            return;
        }

        boolean entered = false;
        try {
            entered = DbRepository.runGuardBegin(context.getApplicationContext(), uid, runKey, "am");
            if (!entered) return;

            boolean handled = Biz.run(context.getApplicationContext(), uid);
            com.example.quote_app.schedule.PostNotify.onAmResult(context.getApplicationContext(), uid, runKey, handled);
} catch (Throwable t) {
            DbRepository.log(context.getApplicationContext(), uid, "AM异常: " + (t.getMessage()==null?"未知错误":t.getMessage()));
            // Exception: cancel current and schedule next to avoid losing future tasks
            try {
                NativeSchedulerK.cancel(context.getApplicationContext(), id);
            } catch (Throwable ignore) {}
            try {  } catch (Throwable ignore) {}
        } finally {
            try { DbRepository.runGuardEnd(context.getApplicationContext(), uid, runKey, "am"); } catch (Throwable ignore) {}
        }
    }
}