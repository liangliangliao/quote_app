package com.example.quote_app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

    companion object {
        private const val REQ_POST_NOTIFICATIONS = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ensure notification channel exists before any notifications are posted
        NotificationUtils.ensureDefaultChannel(this)

        // Android 13+ notification runtime permission (request only if disabled)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationUtils.areNotificationsEnabled(this)) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQ_POST_NOTIFICATIONS
                )
            }
        }

        // Android 12+ exact alarm settings prompt (Android 14 defaults to denied for most apps)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try { startActivity(intent) } catch (_: Exception) {
            // Fallback to app details or special app access overview
            try {
                startActivity(Intent("android.settings.MANAGE_SPECIAL_APP_ACCESS"))
            } catch (_: Exception) {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:$packageName")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                } catch (_: Exception) {}
            }
        }
            }

        // Battery optimization whitelist request (helps OEMs that kill alarms when swiped away)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    try { startActivity(intent) } catch (_: Exception) {
                        // Fallback to battery optimization settings
                        try {
                            startActivity(Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"))
                        } catch (_: Exception) { /* ignore */ }
                    }
                }
            } catch (_: Exception) {}
        }


        try {
            val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()) {
                val prefs = getSharedPreferences("diag_prefs", Context.MODE_PRIVATE)
                if (!prefs.getBoolean("diag_alarm_scheduled", false)) {
                    val t = java.lang.System.currentTimeMillis() + 60_000L
                    ExactAlarmTestReceiver.scheduleOnce(this, t)
                    prefs.edit().putBoolean("diag_alarm_scheduled", true).apply()
                }
            }
        } catch (_: Exception) {}
    
        }
    }
}
