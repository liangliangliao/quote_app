package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

class UnlockWatchdogService : Service() {

    override fun onCreate() {
        super.onCreate()
        // 仅作为解锁链路的保活服务：不再额外注册广播，解锁事件由 Manifest 静态 UnlockReceiver 统一处理。
        startForeground(1607, buildTiny())
        try {
            com.example.quote_app.data.DbRepo.log(
                this,
                null,
                "[UnlockWatchdogService] onCreate：前台保活服务已启动"
            )
        } catch (_: Throwable) {
        }
    }

    private fun buildTiny(): Notification {
        val chanId = "unlock_watchdog"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(
                chanId,
                "Unlock Watchdog",
                NotificationManager.IMPORTANCE_MIN
            )
            chan.setShowBadge(false)
            chan.lockscreenVisibility = Notification.VISIBILITY_SECRET
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(chan)
        }
        val builder =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, chanId)
            } else {
                Notification.Builder(this)
            }
        return builder
            .setContentTitle("Unlock Watchdog running")
            .setContentText("Listening for unlock events")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 保持轻量运行；如果你希望长期保活，可以去掉 stopForeground/stopSelf。
        stopForeground(true)
        stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            com.example.quote_app.data.DbRepo.log(
                this,
                null,
                "[UnlockWatchdogService] onDestroy：服务被销毁"
            )
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
