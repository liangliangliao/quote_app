import 'dart:async';
import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import 'db.dart';

/// A lightweight data access object for sport plans and records.
///
/// The sport tables store user configured exercise plans (sport_plans)
/// and historical workout sessions (sport_records).  All fields are
/// optional to simplify migrations; consumers should perform null checks
/// where appropriate.  This DAO exposes basic CRUD operations and hides
/// the underlying SQLite details.
class SportDao {
  /// Fetch all sport plans ordered by descending id (latest first).
  Future<List<Map<String, dynamic>>> getPlans() async {
    final db = await AppDatabase.instance();
    return db.query('sport_plans', orderBy: 'id DESC');
  }

  /// Load a single plan by id. Returns null if not found.
  Future<Map<String, dynamic>?> getPlan(int id) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('sport_plans', where: 'id=?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// Insert a new plan. Returns the new row id.
  Future<int> insertPlan(Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['created_at'] = DateTime.now().toIso8601String();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.insert('sport_plans', data);
  }

  /// Update an existing plan. Returns the number of affected rows.
  Future<int> updatePlan(int id, Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.update('sport_plans', data, where: 'id=?', whereArgs: [id]);
  }

  /// Delete a plan by id. Returns the number of affected rows.
  Future<int> deletePlan(int id) async {
    final db = await AppDatabase.instance();
    return db.delete('sport_plans', where: 'id=?', whereArgs: [id]);
  }

  /// Fetch all sport records ordered by descending id (latest first).
  Future<List<Map<String, dynamic>>> getRecords() async {
    final db = await AppDatabase.instance();
    return db.query('sport_records', orderBy: 'id DESC');
  }

  /// Fetch records associated with a particular plan id.
  Future<List<Map<String, dynamic>>> getRecordsByPlan(int planId) async {
    final db = await AppDatabase.instance();
    return db.query('sport_records', where: 'plan_id=?', whereArgs: [planId], orderBy: 'id DESC');
  }

  /// Insert a new record. Returns the new row id.
  Future<int> insertRecord(Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['created_at'] = DateTime.now().toIso8601String();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.insert('sport_records', data);
  }

  /// Update a record by id. Returns the number of affected rows.
  Future<int> updateRecord(int id, Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    data['updated_at'] = DateTime.now().toIso8601String();
    return db.update('sport_records', data, where: 'id=?', whereArgs: [id]);
  }

  /// Delete a record by id. Returns the number of affected rows.
  Future<int> deleteRecord(int id) async {
    final db = await AppDatabase.instance();
    return db.delete('sport_records', where: 'id=?', whereArgs: [id]);
  }
}