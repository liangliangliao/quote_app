package com.example.quote_app

import io.flutter.app.FlutterApplication

/**
 * Minimal Application class – keeps a reference for future
 * custom initialisation if needed. No manual plugin registration
 * is required for Flutter Embedding V2.
 */
class MyApp : FlutterApplication()
