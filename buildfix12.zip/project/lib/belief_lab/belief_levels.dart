import 'belief_models.dart';

/// Concepts: 把 57 段内容按逻辑关系组织成可学习、可重演、可行动的“知识单元”。
///
/// 说明：
/// - segmentKeys 指向已入库的 57 段（如 "L6#12"）。
/// - episodeIds/missionIds 对应下面的 episodes / missions。
const List<BeliefConcept> beliefConcepts = [
  BeliefConcept(
    id: 'c1_limit_break',
    title: '信念的“可能性开关”',
    oneLiner: '先相信“可能”，才会愿意投入足够的努力与试错。',
    segmentKeys: ['L5#1', 'L5#2', 'L6#8', 'L6#15'],
    episodeIds: ['e_bannister', 'e_edison'],
    missionIds: ['m_possibility_switch'],
  ),
  BeliefConcept(
    id: 'c2_expectation',
    title: '期待效应（皮格马利翁）',
    oneLiner: '你怎样看一个人，会改变你怎样对待他，也改变他怎样成为。',
    segmentKeys: ['L5#5', 'L5#6', 'L5#7', 'L5#8'],
    episodeIds: ['e_rosenthal', 'e_jamison'],
    missionIds: ['m_expectation_upgrade'],
  ),
  BeliefConcept(
    id: 'c3_situation_power',
    title: '情境的力量与正向情境',
    oneLiner: '很多时候不是“人坏”，而是“情境强”；要学会创造正向情境。',
    segmentKeys: ['L5#9', 'L5#10', 'L6#2'],
    episodeIds: ['e_situation_mirror', 'e_langer_1959', 'e_langer_pilot'],
    missionIds: ['m_positive_situation_build'],
  ),
  BeliefConcept(
    id: 'c4_priming',
    title: '启动效应：环境在暗中塑造你',
    oneLiner: '你每天看到/听到/触到的线索，会在无意识层面推着你走。',
    segmentKeys: ['L5#11', 'L6#1', 'L6#3', 'L6#4', 'L6#5'],
    episodeIds: ['e_priming_walk', 'e_office_priming'],
    missionIds: ['m_priming_homework'],
  ),
  BeliefConcept(
    id: 'c5_placebo',
    title: '安慰剂：信念如何影响身体',
    oneLiner: '信念很强，但不是万能；关键是用它去支持行动与恢复。',
    segmentKeys: ['L6#11'],
    episodeIds: ['e_placebo', 'e_allergy_leaf'],
    missionIds: ['m_placebo_protocol'],
  ),
  BeliefConcept(
    id: 'c6_mechanisms',
    title: '信念变现实的两条路',
    oneLiner: '动机让你更努力；一致性让你要么改信念，要么改现实。',
    segmentKeys: ['L6#12', 'L6#13', 'L6#14'],
    episodeIds: ['e_dissonance', 'e_focus_filter'],
    missionIds: ['m_reality_alignment'],
  ),
  BeliefConcept(
    id: 'c7_fail_to_learn',
    title: '学会失败：把挫折变成学习',
    oneLiner: '最成功的人往往失败最多：失败不是相反面，而是路径。',
    segmentKeys: ['L6#16', 'L6#28', 'L7#4', 'L7#9'],
    episodeIds: ['e_fail_loop'],
    missionIds: ['m_fail_log'],
  ),
  BeliefConcept(
    id: 'c8_explanatory_style',
    title: '解释风格：把失败说成“暂时且特定”',
    oneLiner: '同一件事，不同解释，会导向不同命运。',
    segmentKeys: ['L6#17', 'L6#18', 'L6#19', 'L6#20', 'L7#5'],
    episodeIds: ['e_biondi', 'e_exam_story'],
    missionIds: ['m_style_rewrite'],
  ),
  BeliefConcept(
    id: 'c9_realistic_optimism',
    title: '现实乐观：Stockdale 悖论',
    oneLiner: '坚定相信能赢 + 严格面对残酷事实，二者缺一不可。',
    segmentKeys: ['L6#21', 'L6#22', 'L6#23', 'L6#24'],
    episodeIds: ['e_stockdale'],
    missionIds: ['m_stockdale_plan'],
  ),
  BeliefConcept(
    id: 'c10_tools',
    title: '三套工具：行动 / 可视化 / 认知疗法',
    oneLiner: '把“信念”做出来：做、看见、再把扭曲拉回现实。',
    segmentKeys: ['L7#6', 'L7#7', 'L7#8', 'L7#10', 'L7#12', 'L7#14', 'L7#17', 'L7#18'],
    episodeIds: ['e_visualization', 'e_3ms_zoomout'],
    missionIds: ['m_visualize_and_do', 'm_3ms_training'],
  ),
];

/// Episodes = “案例重演”关卡：尽量复刻课程原案例的结构，让用户在 App 里把链条走一遍。
const List<BeliefEpisode> beliefEpisodes = [
  BeliefEpisode(
    id: 'e_bannister',
    conceptId: 'c1_limit_break',
    title: '重演：四分钟一英里（Bannister）',
    subtitle: '把“不可能”改写成“可以尝试”，然后安排试错与训练。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '场景',
        body: '你生活中有没有一个“4分钟屏障”？它可能不是体育，而是：英语口语、转岗、写作、社交、减脂、创业、考试等。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下你的“4分钟屏障”',
        body: '用一句话描述：我目前相信自己做不到的是……（越具体越好）',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '把信念从“硬上限”拉回“可训练”',
        body: '课程的关键不是“坐着相信”，而是把“可能性”打开，让努力与试错得以发生。',
        choices: [
          BeliefChoice(id: 'a', text: '我愿意把它从“绝对不可能”改成“我还没找到方法”', score: 2),
          BeliefChoice(id: 'b', text: '我觉得这仍是硬上限（暂时不改）', score: 0),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: '做一个“解锁式训练计划”（7天）',
        body: '选择你能做到的最小可行动作：让努力与反馈发生。',
        checklist: [
          '把目标拆成 3 个可衡量指标（如：次数/分钟/页数/对话数）',
          '安排 7 天内至少 3 次练习（每次 10–30 分钟）',
          '为每次练习设一个“允许失败”的指标（如：只要开始就算成功）',
          '每次练习后写 1 句“我学到了什么”',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.rating,
        title: '现在的可能性感（0–5）',
        body: '你此刻对“我能推进它”的相信程度是？',
        minRating: 0,
        maxRating: 5,
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你刚完成了一次“把信念落到行动结构”的重演：信念→动机→行动→反馈→更强信念。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_rosenthal',
    conceptId: 'c2_expectation',
    title: '重演：Rosenthal 期待效应（fast spurters）',
    subtitle: '把“看见潜能”变成可执行的互动方式。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '场景',
        body: '你可以选择一个对象：孩子/伴侣/同事/下属/自己。你的“期待”会通过行为传递出去。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '选择对象',
        body: '写下这个人的称呼（如：小王/我自己/我的孩子）。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '你更常给他的期待是？',
        body: '期待会改变你的语气、关注点、机会给法。',
        choices: [
          BeliefChoice(id: 'a', text: '更像“他不行/会出错/不靠谱”', score: 0),
          BeliefChoice(id: 'b', text: '更像“他能学会/能成长/有潜力”', score: 2),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: '把“高期待”翻译成 4 个具体动作（7天内做）',
        body: '像老师对 fast spurters 那样“多一点关注+多一点机会+多一点反馈”。',
        checklist: [
          '每天至少一次“具体表扬”（表扬努力/策略/进步，不是空喊你真棒）',
          '给一次更难一点的任务/机会（在伸展区）',
          '给一次高质量反馈：指出一处做得好 + 一处可改进 + 下一步建议',
          '做一次“看见潜能”的记录：今天我看到了他/我自己的哪一点潜力？',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.input,
        title: '写下你的“潜能句”',
        body: '把对方当成“他能成为的样子”：一句话写出你希望他更靠近的版本。',
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '关键不是“骗自己”，而是用更完整的现实（潜能也属于现实）去指导互动。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_jamison',
    conceptId: 'c2_expectation',
    title: '重演：反向期待（Jamison 1997）',
    subtitle: '先相信对方更好，你会看见更多证据，关系与表现一起上升。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '场景',
        body: '在实验里：学生被告知老师很优秀→学生投入更多→成绩更好→老师评价更高。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '选一个你常“挑刺”的人',
        body: '写下名字/称呼（也可以是你自己）。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.checklist,
        title: '7 天“找证据挑战”',
        body: '每天强制自己找 2 条证据：他/我其实哪里做得不错？',
        checklist: [
          '证据 1：一个具体行为/选择/努力',
          '证据 2：一个具体能力/品质/潜力',
          '写下：如果我把他当成“更好的他”，我今天会怎么说/怎么做？',
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.singleChoice,
        title: '你愿意做一次“更高期待”的互动吗？',
        body: '只做一件事：说一句更高期待的话/给一个更高期待的机会。',
        choices: [
          BeliefChoice(id: 'a', text: '愿意，今天就做', score: 2),
          BeliefChoice(id: 'b', text: '暂时不做', score: 0),
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.input,
        title: '写下那一句话',
        body: '例如：“我相信你能把这件事推进到更好，我愿意给你/给自己这个机会。”',
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你刚练的是：先改变“看法”，再改变“互动”，让现实有机会跟上。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_situation_mirror',
    conceptId: 'c3_situation_power',
    title: '重演：情境镜像（负向情境 vs 正向情境）',
    subtitle: '同一个人放进不同情境，会像变了一个人。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程提示',
        body: 'Milgram / Zimbardo 让我们看到负向情境的强；Langer 让我们看到正向情境也同样强。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.singleChoice,
        title: '你最近更像被哪种情境推着走？',
        body: '选你更贴近的那一项。',
        choices: [
          BeliefChoice(id: 'a', text: '负向：压力、盯错、苛责、对比、羞耻', score: 0),
          BeliefChoice(id: 'b', text: '正向：鼓励、节奏、清晰边界、可见进步', score: 2),
        ],
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.checklist,
        title: '把情境拆开：哪 3 个线索在推你？',
        body: '情境不是空气，它由具体线索构成。',
        checklist: [
          '线索 1：某个地方/桌面/房间/手机屏幕/人',
          '线索 2：某种语言（你对自己说的话/别人说的话）',
          '线索 3：某种制度（deadline、打卡、排名、奖励/惩罚）',
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '写下一个“正向替代情境”',
        body: '只改动 1 个线索：例如把苛责换成“进步记录”，把混乱桌面换成“唯一任务卡”。',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.rating,
        title: '你愿意把它试 3 天吗？',
        body: '0=完全不愿意，5=非常愿意',
        minRating: 0,
        maxRating: 5,
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了一次“情境拆解→替代线索→小范围试验”的关卡。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_langer_1959',
    conceptId: 'c3_situation_power',
    title: '重演：Langer “1959 退修营”',
    subtitle: '用角色与环境，把自己带回“更有能力的我”。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '核心机制',
        body: '当环境不再不断提醒“你老了/你不行”，人会更像“更年轻/更有力”的自己。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '选一个你想“回到的自己”',
        body: '例如：刚入行时的好奇、学生时代的专注、某段高峰期的自信。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.checklist,
        title: '搭建“7天角色房间”（低成本版）',
        body: '把环境布置成能“启动那个自己”的样子。',
        checklist: [
          '找 1 张“那时的照片/象征物”放在桌面可见处',
          '找 1 首“那时常听的音乐”作为工作/学习启动曲',
          '把手机壁纸/锁屏改成“那个自己”的关键字',
          '写 1 句角色台词：今天我以“那个我”的方式行动',
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '你的角色台词',
        body: '写下那句台词（越具体越好）。',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.checklist,
        title: '每天 10 分钟“进入角色行动”',
        body: '选择 1 个动作：读/写/练/沟通/运动，像那个自己一样做。',
        checklist: [
          '今天我要做的动作是：____（填空）',
          '我将如何像“那个自己”去做：____（填空）',
        ],
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你把“角色×情境”的研究，变成了可执行的 7 天游戏。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_langer_pilot',
    conceptId: 'c3_situation_power',
    title: '重演：飞行员情境与视力表',
    subtitle: '身份情境会改变你对任务的调用方式。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '实验提示',
        body: '同一张视力表、同样距离，换成飞行员制服+模拟器，表现就变了。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '选一个你想提升的能力',
        body: '例如：演讲、自律、社交、代码、写作、跑步。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '给自己一个“身份外壳”',
        body: '你更喜欢哪种方式？',
        choices: [
          BeliefChoice(id: 'a', text: '装备/穿着（如：运动服/工位仪式）', score: 1),
          BeliefChoice(id: 'b', text: '空间/道具（如：特定桌面/特定音乐）', score: 1),
          BeliefChoice(id: 'c', text: '语言身份（如：我是今天的“飞行员/教练/作家”）', score: 1),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '写下你的身份句',
        body: '例：“现在我是‘飞行员’，我的任务是稳定地完成这一段飞行（30分钟专注）。”',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.checklist,
        title: '做一次 20 分钟“身份任务”',
        body: '只做一件事，计时 20 分钟。',
        checklist: [
          '设定计时器 20 分钟',
          '只做这一件事（不切换）',
          '结束后写 1 句：身份外壳对我有什么影响？',
        ],
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了“身份情境→任务表现”的一次小型复制实验。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_priming_walk',
    conceptId: 'c4_priming',
    title: '重演：Bargh 老年词启动 → 走路变慢',
    subtitle: '你以为你在“自由选择”，其实很多是被线索牵引。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '要点',
        body: '启动可以无意识发生：词语/图像/暗示能改变记忆、速度、坚持。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.singleChoice,
        title: '你更常被什么“启动”？',
        body: '选一个你最近的典型线索。',
        choices: [
          BeliefChoice(id: 'a', text: '负向词（累、差、来不及、完蛋）', score: 0),
          BeliefChoice(id: 'b', text: '正向词（进步、坚持、今天只做一步）', score: 2),
        ],
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.input,
        title: '写下你最常出现的 3 个“启动词”',
        body: '越口头越好（就是你脑海里自动冒出来的那种）。',
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: '把 1 个负向词改写成“行动词”',
        body: '例：把“完蛋了”→“我先做第一步”。',
        checklist: [
          '选择 1 个负向启动词',
          '写出 1 个替代行动词',
          '把替代词设置为手机小组件/桌面便签（可拍照留存）',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.rating,
        title: '今天你愿意试几次？',
        body: '0=不试，5=至少试 5 次以上',
        minRating: 0,
        maxRating: 5,
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你把“启动”从不可控，变成了可被设计的环境变量。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_office_priming',
    conceptId: 'c4_priming',
    title: '重演：我的办公室启动装置',
    subtitle: '把你的空间变成“把你推向更好”的机器。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程提示',
        body: '老师用雕塑/名言等物品提醒自己：别只想，要行动；保持热情。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.checklist,
        title: '建立你的“3件套启动装置”',
        body: '只要 3 个就够：看见→被启动→去做。',
        checklist: [
          '1 个视觉启动（壁纸/照片/一句话）',
          '1 个动作启动（计时器/开场音乐/喝水仪式）',
          '1 个价值启动（你最在乎的 1 句话/1 个原则）',
        ],
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.input,
        title: '写下你的“价值启动句”',
        body: '例：Talk is no substitute for action。',
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: '放置并拍照',
        body: '把它们放到你每天一定会看到的地方（桌面/锁屏/门上）。',
        checklist: [
          '放置完成',
          '拍照留存（可选）',
          '明天同一时间再看一次：它有没有启动你？',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了“环境设计作业”的 App 版本。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_placebo',
    conceptId: 'c5_placebo',
    title: '重演：安慰剂（糖丸也能止吐）',
    subtitle: '信念能影响身体，但要把它用在“恢复与坚持”上。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程要点',
        body: '安慰剂组也改善：信念会调动身体反应，但不等于“想什么就来什么”。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.singleChoice,
        title: '你现在更需要哪种“身体层面的支持”？',
        body: '选一个最贴近的。',
        choices: [
          BeliefChoice(id: 'a', text: '压力与睡眠', score: 1),
          BeliefChoice(id: 'b', text: '体能与精力', score: 1),
          BeliefChoice(id: 'c', text: '疼痛/不适管理', score: 1),
        ],
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.checklist,
        title: '做一个“安慰剂仪式”（3天）',
        body: '给身体一个明确的“恢复信号”，并配合行动。',
        checklist: [
          '固定一个时间点（如睡前）',
          '固定一个“信号动作”（热水澡/热茶/拉伸 5 分钟）',
          '固定一句“身体启动句”（如：现在进入恢复模式）',
          '记录 1 个可观察指标（入睡时间/心率/疼痛评分）',
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '你的身体启动句',
        body: '写一句你愿意每天对身体说的话。',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你把“信念影响身体”落到一个可重复的恢复协议。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_allergy_leaf',
    conceptId: 'c5_placebo',
    title: '重演：过敏叶子（被告知有毒就起疹）',
    subtitle: '标签与解释会影响身体反应：别把“想法”当事实。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '要点',
        body: '同一片叶子，换个解释，身体反应就变了：说明“解释”会塑造体验。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下你最近一个“被标签化”的体验',
        body: '例：我最近总觉得自己“很差/很慢/不行”。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '它更像事实还是解释？',
        body: '很多痛苦来自把解释当事实。',
        choices: [
          BeliefChoice(id: 'a', text: '更像事实', score: 0),
          BeliefChoice(id: 'b', text: '更像解释（我可以换一种解释）', score: 2),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '做一次“换标签”',
        body: '把它从“自我标签”换成“情境描述”。例：“我很蠢”→“我这次没准备好”。',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了一次把“解释”与“事实”拆开的练习。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_dissonance',
    conceptId: 'c6_mechanisms',
    title: '重演：一致性机制（认知失调）',
    subtitle: '当现实和信念冲突，你会怎么做？',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '四种修复方式',
        body: '更新信念 / 忽略信息 / 找支持证据（确认偏误）/ 改变现实（行动）。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下一个你正在“卡住”的冲突',
        body: '例：我想更健康，但我总熬夜；我想转岗，但我不投简历。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '你最常用哪种修复方式？',
        body: '诚实选择即可。',
        choices: [
          BeliefChoice(id: 'a', text: '忽略/拖延：当作没看见', score: 0),
          BeliefChoice(id: 'b', text: '找理由：为现状辩护', score: 0),
          BeliefChoice(id: 'c', text: '改信念：降低期待/放弃', score: 0),
          BeliefChoice(id: 'd', text: '改现实：做一个行动让它变真', score: 2),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: '设计一个“改现实”的最小行动（24小时内）',
        body: '让现实开始贴合你想要的信念。',
        checklist: [
          '写下最小行动（≤10分钟）',
          '设定触发条件（例如：今晚 9 点）',
          '做完立即记录结果',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你把“失调的不适”转化成“改变现实的一步”。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_focus_filter',
    conceptId: 'c6_mechanisms',
    title: '重演：注意力过滤（公交车上的孩子）',
    subtitle: '你没看见的那部分现实，仍然在影响你。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '要点',
        body: '我们会漏看：潜能、积极证据、可行路径。焦点在哪，现实就被“剪辑”成那样。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.singleChoice,
        title: '你最近更常聚焦哪里？',
        body: '选一个更贴近的。',
        choices: [
          BeliefChoice(id: 'a', text: '问题/缺陷/失败', score: 0),
          BeliefChoice(id: 'b', text: '进步/潜能/可行路径', score: 2),
        ],
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.checklist,
        title: '做一次“镜头拉远（zoom out）”',
        body: '把比例找回来。',
        checklist: [
          '列出 3 个“我做对了/在进步”的事实',
          '列出 1 个“我真正要解决的问题”',
          '列出 1 个“下一步可行动作”',
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你练习的是：让注意力成为工具，而不是牢笼。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_fail_loop',
    conceptId: 'c7_fail_to_learn',
    title: '重演：learn to fail, or fail to learn',
    subtitle: '把失败当成“数据点”，而不是“人格判决”。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程要点',
        body: 'Edison / Simonton：成功者往往失败最多；失败是学习机制的一部分。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下一个你最近的失败',
        body: '越具体越好（时间、地点、发生了什么）。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '你更像哪种解释？',
        body: '选更贴近的。',
        choices: [
          BeliefChoice(id: 'a', text: '我不行（人格判决）', score: 0),
          BeliefChoice(id: 'b', text: '我排除了一个不行的方法（数据点）', score: 2),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '把它改写成“排除法句子”',
        body: '参考 Edison：我不是失败了，而是发现了一个行不通的方法，所以我下一次将……',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.checklist,
        title: '把失败变成下一次实验',
        body: '做一个更小的版本再试一次。',
        checklist: [
          '把任务缩小 50%',
          '只改动 1 个变量（方法/时间/环境/伙伴）',
          '设定一次“只要开始就算成功”的标准',
        ],
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了把“失败→学习→下一次实验”的闭环。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_biondi',
    conceptId: 'c8_explanatory_style',
    title: '重演：Biondi 的“稳定乐观”翻盘',
    subtitle: '把失败解释为“暂时+特定”，继续回到赛场。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程要点',
        body: '稳定乐观者把失败看作暂时、特定；而不是永久、普遍。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下你最近一次“没达到期待”的事件',
        body: '像 Biondi 前两项没拿金牌那样：你被期待做什么？发生了什么？',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '你的解释更像哪种？',
        body: '选一项。',
        choices: [
          BeliefChoice(id: 'a', text: '永久+普遍：我不行/我什么都不行', score: 0),
          BeliefChoice(id: 'b', text: '暂时+特定：这次没准备好/策略不对', score: 2),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.input,
        title: '写出“暂时+特定”的解释句',
        body: '例如：这次我在____做得不够，所以我下一次要____。',
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.checklist,
        title: '回到赛场：下一次行动清单',
        body: '像 Biondi 一样继续比赛。',
        checklist: [
          '我下一次尝试的时间是：____',
          '我会改动的 1 个策略是：____',
          '我会如何给自己反馈：____',
        ],
      ),
      BeliefStep(
        id: 's6',
        type: BeliefStepType.summary,
        title: '完成',
        body: '解释风格不是嘴硬，而是给行动腾出空间。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_exam_story',
    conceptId: 'c8_explanatory_style',
    title: '重演：考试失利的两种解释',
    subtitle: '把“我很蠢”换成“这次没准备好”。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '两条轴',
        body: '永久/暂时、普遍/特定。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下一个你常用的负面解释句',
        body: '比如：我就是不行 / 我永远学不会 / 我什么都做不好。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.input,
        title: '把它改写成“暂时+特定”',
        body: '例如：这次我在____没做好，因为____，下一次我会____。',
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了“解释风格改写”的最小练习。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_stockdale',
    conceptId: 'c9_realistic_optimism',
    title: '重演：Stockdale 悖论（信念 + 残酷现实）',
    subtitle: '既不绝望，也不自欺：用两条腿走路。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '两条原则',
        body: '1) 坚信最终会赢；2) 严格面对当下残酷事实与纪律。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下你正在面对的一件“残酷现实”',
        body: '例：时间不够/资金有限/能力缺口/关系冲突。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.input,
        title: '写下你的“最终信念”',
        body: '例：我相信我会在____之前把____做到____。',
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: '把残酷现实翻译成纪律',
        body: '纪律=你每天要做的具体动作。',
        checklist: [
          '纪律 1：每天固定____分钟/次 做____',
          '纪律 2：每周复盘一次，调整策略',
          '纪律 3：不再靠“希望圣诞出狱”，而是靠行动积累',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了“现实乐观”模板：信念给方向，现实给策略，纪律给力量。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_visualization',
    conceptId: 'c10_tools',
    title: '重演：可视化（终点 + 过程）',
    subtitle: '把大脑当模拟器：先在脑内跑通，再回到现实跑步。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程要点',
        body: 'Kosslyn：想象与真实看到会激活相似神经网络；Taylor：只想终点不如把过程一起想。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '选择一个你要完成的目标',
        body: '越近期越好（7–14天内）。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.checklist,
        title: '写一份“过程可视化脚本”',
        body: '把过程写成可看可感的画面。',
        checklist: [
          '我在哪个地点开始？（视觉）',
          '我开始的第一动作是什么？（动作）',
          '我遇到阻力时怎么继续？（策略）',
          '我完成后的画面是什么？（终点）',
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.rating,
        title: '你愿意每天演练 2 分钟吗？',
        body: '0=不愿意，5=非常愿意',
        minRating: 0,
        maxRating: 5,
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你把“可视化”从鸡汤变成了可练的脚本。',
      ),
    ],
  ),

  BeliefEpisode(
    id: 'e_3ms_zoomout',
    conceptId: 'c10_tools',
    title: '重演：3Ms（放大/缩小）与 Zoom out',
    subtitle: '从“一个点毁一切”回到“真实比例”。',
    steps: [
      BeliefStep(
        id: 's1',
        type: BeliefStepType.info,
        title: '课程要点',
        body: 'Magnifying：一次挫折=世界末日；Minimizing：隧道视野只盯负面点。解决：zoom out。',
      ),
      BeliefStep(
        id: 's2',
        type: BeliefStepType.input,
        title: '写下你最近一次反刍的“那一句话/那一个点”',
        body: '像老师上节目后反刍那句后悔的话一样。',
      ),
      BeliefStep(
        id: 's3',
        type: BeliefStepType.singleChoice,
        title: '它更像放大还是缩小？',
        body: '选一项。',
        choices: [
          BeliefChoice(id: 'a', text: '放大：把一次当全部', score: 1),
          BeliefChoice(id: 'b', text: '缩小：忽略大量积极事实', score: 1),
        ],
      ),
      BeliefStep(
        id: 's4',
        type: BeliefStepType.checklist,
        title: 'Zoom out 三步',
        body: '把现实比例拉回来。',
        checklist: [
          '列 3 条“更大的事实”（积极或中性都行）',
          '列 1 条“我能改进的具体点”',
          '列 1 个“我现在就能做的下一步”',
        ],
      ),
      BeliefStep(
        id: 's5',
        type: BeliefStepType.summary,
        title: '完成',
        body: '你完成了一次“认知回归现实”的训练。',
      ),
    ],
  ),
];

/// Missions = “现实行动”关卡：把课程知识转成可执行的日常任务 + 复盘。
const List<BeliefMission> beliefMissions = [
  BeliefMission(
    id: 'm_possibility_switch',
    conceptId: 'c1_limit_break',
    title: '行动：可能性开关（7天）',
    subtitle: '把“硬上限”换成“可训练”，并安排 3 次试错。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.info, title: '规则', body: '7 天内完成至少 3 次练习；每次练习后写 1 句学习。'),
      BeliefStep(id: 'i2', type: BeliefStepType.input, title: '你的目标是什么？', body: '一句话写下你的“4分钟屏障”。'),
      BeliefStep(id: 'i3', type: BeliefStepType.checklist, title: '三次练习安排', body: '勾选你已经安排好的练习。', checklist: ['练习 1 已安排', '练习 2 已安排', '练习 3 已安排']),
      BeliefStep(id: 'i4', type: BeliefStepType.input, title: '失败学习句', body: '写一句：今天我排除了什么不行的方法？'),
      BeliefStep(id: 'i5', type: BeliefStepType.summary, title: '完成', body: '完成后你会发现：信念不是起点，而是结果的一部分。'),
    ],
  ),
  BeliefMission(
    id: 'm_expectation_upgrade',
    conceptId: 'c2_expectation',
    title: '行动：期待升级（7天）',
    subtitle: '把“更高期待”翻译成日常互动。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '对象', body: '选择一个对象：同事/伴侣/孩子/自己。'),
      BeliefStep(id: 'i2', type: BeliefStepType.checklist, title: '每天 3 分钟', body: '每天做一次：看见潜能+给机会+给反馈。', checklist: ['具体表扬努力/策略/进步', '给一次伸展区机会', '给一次高质量反馈', '记录今天看见的潜能']),
      BeliefStep(id: 'i3', type: BeliefStepType.input, title: '复盘', body: '7 天后：这段关系/表现发生了什么变化？'),
      BeliefStep(id: 'i4', type: BeliefStepType.summary, title: '完成', body: '你把“期待效应”从理论变成互动习惯。'),
    ],
  ),
  BeliefMission(
    id: 'm_positive_situation_build',
    conceptId: 'c3_situation_power',
    title: '行动：正向情境搭建（3天）',
    subtitle: '只改一个线索，让你更像“更好的自己”。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.checklist, title: '选一个线索', body: '选择你要改的线索（只改一个）。', checklist: ['空间（桌面/房间）', '语言（自我对话/他人对话）', '制度（时间/奖励/边界）']),
      BeliefStep(id: 'i2', type: BeliefStepType.input, title: '替代方案', body: '写下你的正向替代线索。'),
      BeliefStep(id: 'i3', type: BeliefStepType.rating, title: '三天后评分', body: '0=没变化，5=明显更好', minRating: 0, maxRating: 5),
      BeliefStep(id: 'i4', type: BeliefStepType.summary, title: '完成', body: '你完成了一次“情境微调”的小实验。'),
    ],
  ),
  BeliefMission(
    id: 'm_priming_homework',
    conceptId: 'c4_priming',
    title: '行动：积极启动作业（7天）',
    subtitle: '把环境变成“自动推你行动”的系统。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.checklist, title: '3件套', body: '建立你的 3 件套启动装置。', checklist: ['视觉启动', '动作启动', '价值启动']),
      BeliefStep(id: 'i2', type: BeliefStepType.input, title: '价值启动句', body: '写一句你每天都愿意看到的话。'),
      BeliefStep(id: 'i3', type: BeliefStepType.input, title: '观察记录', body: '7 天后：这些线索有没有改变你的行为？具体有哪些？'),
      BeliefStep(id: 'i4', type: BeliefStepType.summary, title: '完成', body: '你把 priming 变成了可被设计的变量。'),
    ],
  ),
  BeliefMission(
    id: 'm_placebo_protocol',
    conceptId: 'c5_placebo',
    title: '行动：恢复协议（3天）',
    subtitle: '用“信念+仪式+指标”支持身体恢复。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '选择指标', body: '选一个可观察指标：睡眠/心率/疼痛评分/精力。'),
      BeliefStep(id: 'i2', type: BeliefStepType.checklist, title: '固定仪式', body: '每天同一时间做一次。', checklist: ['固定时间', '固定动作', '固定启动句', '记录指标']),
      BeliefStep(id: 'i3', type: BeliefStepType.summary, title: '完成', body: '你把“信念影响身体”变成了可复用方案。'),
    ],
  ),
  BeliefMission(
    id: 'm_reality_alignment',
    conceptId: 'c6_mechanisms',
    title: '行动：一致性对齐（24小时）',
    subtitle: '用一个最小行动把现实拉向你的信念。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '冲突', body: '写下你的“信念-现实冲突”。'),
      BeliefStep(id: 'i2', type: BeliefStepType.input, title: '最小行动', body: '写下 ≤10 分钟的最小行动。'),
      BeliefStep(id: 'i3', type: BeliefStepType.input, title: '完成记录', body: '做完后写 1 句：我学到了什么？'),
      BeliefStep(id: 'i4', type: BeliefStepType.summary, title: '完成', body: '从今天开始，你在用行动修复失调。'),
    ],
  ),
  BeliefMission(
    id: 'm_fail_log',
    conceptId: 'c7_fail_to_learn',
    title: '行动：失败学习日志（7天）',
    subtitle: '每天记录 1 个失败→1 个学到的东西→1 个下一步。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.checklist, title: '每天三行', body: '坚持 7 天。', checklist: ['失败是什么？', '我学到了什么？', '下一步我改动一个变量再试一次']),
      BeliefStep(id: 'i2', type: BeliefStepType.summary, title: '完成', body: '7 天后你会拥有一份“成长证据”。'),
    ],
  ),
  BeliefMission(
    id: 'm_style_rewrite',
    conceptId: 'c8_explanatory_style',
    title: '行动：解释风格改写（7天）',
    subtitle: '把“永久+普遍”改成“暂时+特定”。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '原句', body: '写下你常用的负面解释句。'),
      BeliefStep(id: 'i2', type: BeliefStepType.input, title: '改写句', body: '改成暂时+特定（包含原因与下一步）。'),
      BeliefStep(id: 'i3', type: BeliefStepType.rating, title: '改写后情绪下降了吗？', body: '0=没有，5=明显下降', minRating: 0, maxRating: 5),
      BeliefStep(id: 'i4', type: BeliefStepType.summary, title: '完成', body: '解释风格的改变，会把你推回行动。'),
    ],
  ),
  BeliefMission(
    id: 'm_stockdale_plan',
    conceptId: 'c9_realistic_optimism',
    title: '行动：Stockdale 两栏计划（7天）',
    subtitle: '左边写残酷现实，右边写纪律行动。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '残酷现实', body: '写 3 条你必须面对的事实。'),
      BeliefStep(id: 'i2', type: BeliefStepType.input, title: '最终信念', body: '写一句你对最终胜利的信念。'),
      BeliefStep(id: 'i3', type: BeliefStepType.checklist, title: '纪律清单', body: '把现实翻译成行动。', checklist: ['每天固定行动 1', '每天固定行动 2', '每周复盘与调整']),
      BeliefStep(id: 'i4', type: BeliefStepType.summary, title: '完成', body: '你把“希望”升级成了“纪律”。'),
    ],
  ),
  BeliefMission(
    id: 'm_visualize_and_do',
    conceptId: 'c10_tools',
    title: '行动：2分钟可视化 + 10分钟行动（7天）',
    subtitle: '每天先在脑内跑通，再做最小行动。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '目标', body: '写下你要推进的目标。'),
      BeliefStep(id: 'i2', type: BeliefStepType.checklist, title: '每日流程', body: '每天重复一次。', checklist: ['2 分钟：过程+终点可视化', '10 分钟：最小行动', '1 句：今天我学到了什么']),
      BeliefStep(id: 'i3', type: BeliefStepType.summary, title: '完成', body: '你把可视化从幻想变成了执行。'),
    ],
  ),
  BeliefMission(
    id: 'm_3ms_training',
    conceptId: 'c10_tools',
    title: '行动：3Ms 训练（7天）',
    subtitle: '每天抓一个扭曲，把镜头拉远。',
    steps: [
      BeliefStep(id: 'i1', type: BeliefStepType.input, title: '今日扭曲', body: '写下今天的一个“放大/缩小”时刻。'),
      BeliefStep(id: 'i2', type: BeliefStepType.checklist, title: 'Zoom out', body: '把比例拉回来。', checklist: ['3 条更大事实', '1 条可改进点', '1 个下一步行动']),
      BeliefStep(id: 'i3', type: BeliefStepType.summary, title: '完成', body: '你在训练“大脑的剪辑台”。'),
    ],
  ),
];

BeliefConcept getConceptById(String id) => beliefConcepts.firstWhere((c) => c.id == id);
BeliefEpisode getEpisodeById(String id) => beliefEpisodes.firstWhere((e) => e.id == id);
BeliefMission getMissionById(String id) => beliefMissions.firstWhere((m) => m.id == id);
