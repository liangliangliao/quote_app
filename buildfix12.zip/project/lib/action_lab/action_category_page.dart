import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_models.dart';
import 'package:quote_app/action_lab/action_seed.dart';
import 'package:quote_app/action_lab/action_template_detail_page.dart';
import 'package:quote_app/action_lab/action_ui.dart';

class ActionCategoryPage extends StatefulWidget {
  final String categoryRoot;
  const ActionCategoryPage({super.key, required this.categoryRoot});

  @override
  State<ActionCategoryPage> createState() => _ActionCategoryPageState();
}

class _ActionCategoryPageState extends State<ActionCategoryPage> {
  final _dao = ActionDao();
  bool _loading = true;
  String? _err;

  String _q = '';
  List<ActionTemplate> _templates = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final customs = await _dao.listCustomTemplates();
      final all = <ActionTemplate>[...builtInActionTemplates, ...customs];
      final root = widget.categoryRoot.trim();
      final filtered = all.where((t) => t.categoryPath.startsWith(root)).toList();
      filtered.sort((a, b) => a.categoryPath.compareTo(b.categoryPath));
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = null;
        _templates = filtered;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  Map<String, List<ActionTemplate>> _grouped() {
    final m = <String, List<ActionTemplate>>{};
    for (final t in _templates) {
      if (_q.trim().isNotEmpty) {
        final qq = _q.trim().toLowerCase();
        final hay = '${t.title} ${t.concept} ${t.conceptDefinition} ${t.operationalDefinition}'.toLowerCase();
        if (!hay.contains(qq)) continue;
      }
      final k = t.categoryPath.trim().isEmpty ? widget.categoryRoot : t.categoryPath.trim();
      m.putIfAbsent(k, () => <ActionTemplate>[]).add(t);
    }
    final keys = m.keys.toList()..sort();
    return {for (final k in keys) k: m[k]!};
  }

  @override
  Widget build(BuildContext context) {
    final grouped = _grouped();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.categoryRoot),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _err != null
              ? Center(child: Text('加载失败：$_err'))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
                  children: [
                    TextField(
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: '搜索模板（标题/概念/定义）',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onChanged: (v) => setState(() => _q = v),
                    ),
                    const SizedBox(height: 14),

                    if (grouped.isEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 30),
                        child: Text('没有匹配的模板。', style: TextStyle(color: Colors.black.withOpacity(0.7))),
                      ),

                    ...grouped.entries.map((e) {
                      final path = e.key;
                      final list = e.value;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Material(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: Colors.black.withOpacity(0.06)),
                            ),
                            child: ExpansionTile(
                              tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                              title: Text(path, style: const TextStyle(fontWeight: FontWeight.w700)),
                              subtitle: Text('模板：${list.length}', style: TextStyle(color: Colors.black.withOpacity(0.6))),
                              children: [
                                ...list.map((t) {
                                  final mode = t.mode == ActionMode.plan ? '计划' : '即时';
                                  return Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: ActionSectionCard(
                                      title: t.title,
                                      subtitle: '概念：${t.concept}\n模式：$mode  ·  步骤：${t.steps.length}',
                                      icon: Icons.assignment_outlined,
                                      onTap: () => Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (_) => ActionTemplateDetailPage(template: t)),
                                      ).then((_) => _load()),
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                  ],
                ),
    );
  }
}
