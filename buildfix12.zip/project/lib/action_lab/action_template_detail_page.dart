import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_flow_page.dart';
import 'package:quote_app/action_lab/action_models.dart';
import 'package:quote_app/action_lab/action_template_editor_page.dart';

class ActionTemplateDetailPage extends StatefulWidget {
  final ActionTemplate template;
  final bool fromAiPreview;
  const ActionTemplateDetailPage({super.key, required this.template, this.fromAiPreview = false});

  @override
  State<ActionTemplateDetailPage> createState() => _ActionTemplateDetailPageState();
}

class _ActionTemplateDetailPageState extends State<ActionTemplateDetailPage> {
  final _dao = ActionDao();
  bool _saving = false;
  bool _exists = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    try {
      final ok = await _dao.templateExists(widget.template.id);
      if (!mounted) return;
      setState(() => _exists = ok);
    } catch (_) {}
  }

  Future<void> _saveAsMine() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await _dao.upsertTemplate(widget.template);
      if (!mounted) return;
      setState(() => _exists = true);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存到“我的模板”')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('保存失败：$e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteMine() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('删除模板？'),
        content: const Text('此操作会删除你的自定义/保存模板，但不影响行动历史。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(_, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(_, true), child: const Text('删除')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _dao.deleteTemplate(widget.template.id);
      if (!mounted) return;
      setState(() => _exists = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已删除')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('删除失败：$e')));
    }
  }

  Future<void> _start() async {
    try {
      final run = await _dao.createRun(template: widget.template);
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ActionFlowPage(runId: run.id)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('启动失败：$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.template;
    final mode = t.mode == ActionMode.plan ? '计划模式（关联目标）' : '非计划模式（即时行动）';

    return Scaffold(
      appBar: AppBar(
        title: const Text('行动模板'),
        actions: [
          if (_exists)
            IconButton(
              tooltip: '编辑',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ActionTemplateEditorPage(existing: t)),
              ).then((_) => _check()),
              icon: const Icon(Icons.edit),
            ),
          if (_exists)
            IconButton(
              tooltip: '删除',
              onPressed: _deleteMine,
              icon: const Icon(Icons.delete_outline),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
        children: [
          Text(t.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text('${t.categoryPath}\n$mode', style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35)),
          const SizedBox(height: 14),

          _card(
            '概念',
            '${t.concept}\n\n${t.conceptDefinition}',
          ),
          const SizedBox(height: 12),
          _card(
            '操作化定义（现实可观察指标）',
            t.operationalDefinition,
          ),
          const SizedBox(height: 12),

          _card(
            '行动步骤（将用于流程页）',
            '本模板共有 ${t.steps.length} 步（包含评分/复盘）。\n\n你可以直接开始行动，过程中可标记失败并记录阻力。',
          ),

          if (t.commonObstacles.isNotEmpty) ...[
            const SizedBox(height: 12),
            _card('常见困难（失败模块入口）', t.commonObstacles.map((e) => '• $e').join('\n')),
          ],
          if (t.changePath.isNotEmpty) ...[
            const SizedBox(height: 12),
            _card('改变路径（不良习惯/问题行为）', t.changePath.map((e) => '• $e').join('\n')),
          ],
          if (t.learningTags.isNotEmpty) ...[
            const SizedBox(height: 12),
            _card('学习标签（未来学习模块）', t.learningTags.map((e) => '• $e').join('\n')),
          ],

          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _start,
            icon: const Icon(Icons.play_arrow),
            label: const Text('开始行动'),
          ),
          const SizedBox(height: 10),
          if (!_exists)
            OutlinedButton.icon(
              onPressed: _saving ? null : _saveAsMine,
              icon: const Icon(Icons.bookmark_add_outlined),
              label: Text(widget.fromAiPreview ? '保存AI模板到“我的模板”' : '保存到“我的模板”'),
            ),
          if (_exists)
            OutlinedButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ActionTemplateEditorPage(existing: t, duplicateAsNew: true)),
              ),
              icon: const Icon(Icons.copy_all_outlined),
              label: const Text('复制为新模板（可修改）'),
            ),
        ],
      ),
    );
  }

  Widget _card(String title, String body) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(body, style: TextStyle(color: Colors.black.withOpacity(0.75), height: 1.35)),
        ],
      ),
    );
  }
}
