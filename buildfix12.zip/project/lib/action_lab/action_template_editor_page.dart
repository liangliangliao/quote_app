import 'dart:math';

import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_models.dart';

class ActionTemplateEditorPage extends StatefulWidget {
  final ActionTemplate? existing;
  final bool duplicateAsNew;
  const ActionTemplateEditorPage({super.key, this.existing, this.duplicateAsNew = false});

  @override
  State<ActionTemplateEditorPage> createState() => _ActionTemplateEditorPageState();
}

class _ActionTemplateEditorPageState extends State<ActionTemplateEditorPage> {
  final _dao = ActionDao();

  final _title = TextEditingController();
  final _category = TextEditingController();
  final _concept = TextEditingController();
  final _conceptDef = TextEditingController();
  final _opDef = TextEditingController();
  final _obstacles = TextEditingController();
  final _changePath = TextEditingController();
  final _learning = TextEditingController();
  final _goalHint = TextEditingController();

  ActionMode _mode = ActionMode.free;
  final List<ActionStep> _coreSteps = [];

  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadExisting();
  }

  @override
  void dispose() {
    _title.dispose();
    _category.dispose();
    _concept.dispose();
    _conceptDef.dispose();
    _opDef.dispose();
    _obstacles.dispose();
    _changePath.dispose();
    _learning.dispose();
    _goalHint.dispose();
    super.dispose();
  }

  void _loadExisting() {
    final t = widget.existing;
    if (t == null) {
      // default scaffold
      _category.text = '日常生活/自我成长/微行动';
      _mode = ActionMode.free;
      _coreSteps.add(
        const ActionStep(
          id: 'draft_s1',
          type: ActionStepType.checklist,
          title: '行动清单',
          body: '把行动写成可观察、可勾选的行为（越具体越好）。',
          checklist: ['（示例）做 2 分钟', '（示例）只开个头', '（示例）记录完成'],
        ),
      );
      return;
    }

    _title.text = t.title;
    _category.text = t.categoryPath;
    _concept.text = t.concept;
    _conceptDef.text = t.conceptDefinition;
    _opDef.text = t.operationalDefinition;
    _mode = t.mode;
    _goalHint.text = t.goalHint;

    _obstacles.text = t.commonObstacles.join('\n');
    _changePath.text = t.changePath.join('\n');
    _learning.text = t.learningTags.join('\n');

    // heuristic: remove auto steps
    for (final s in t.steps) {
      if (s.id.endsWith('_concept') ||
          s.id.endsWith('_goal') ||
          s.id.endsWith('_match') ||
          s.id.endsWith('_result') ||
          s.id.endsWith('_obstacle') ||
          s.id.endsWith('_next') ||
          s.id.endsWith('_summary')) {
        continue;
      }
      _coreSteps.add(s);
    }

    if (_coreSteps.isEmpty) {
      _coreSteps.add(
        const ActionStep(
          id: 'draft_s1',
          type: ActionStepType.checklist,
          title: '行动清单',
          body: '把行动写成可观察、可勾选的行为（越具体越好）。',
          checklist: ['（示例）做 2 分钟', '（示例）只开个头', '（示例）记录完成'],
        ),
      );
    }
  }

  String _newId() {
    final ms = DateTime.now().millisecondsSinceEpoch;
    final r = Random().nextInt(99999).toString().padLeft(5, '0');
    return 'custom_${ms}_$r';
  }

  List<String> _lines(TextEditingController c) {
    return c.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  List<ActionStep> _evalSteps(String id) => [
        ActionStep(
          id: '${id}_match',
          type: ActionStepType.rating,
          title: '概念一致性评分',
          body: '你的实际行动，是否是“概念”的直观表达？\n\n请对照“操作化定义/可观察指标”。',
          minRating: 1,
          maxRating: 5,
        ),
        ActionStep(
          id: '${id}_result',
          type: ActionStepType.rating,
          title: '现实结果评分',
          body: '这次行动在现实里带来了多大效果？',
          minRating: 1,
          maxRating: 5,
        ),
        ActionStep(
          id: '${id}_obstacle',
          type: ActionStepType.input,
          title: '遇到的困难（用于失败模块/改进）',
          body: '写下你遇到的阻力、挫折或失败点。没有也可以写“无”。',
          hint: '例如：手机干扰；情绪低落；时间不够；他人不配合…',
          required: false,
        ),
        ActionStep(
          id: '${id}_next',
          type: ActionStepType.input,
          title: '下一次的更小动作',
          body: '把下一次行动缩小到“再怎么不想也做得到”的程度。',
          hint: '例如：只做2分钟；只准备材料；只开个头…',
          required: false,
        ),
        ActionStep(
          id: '${id}_summary',
          type: ActionStepType.summary,
          title: '完成',
          body: '你已经完成一次“概念→现实”的落地。\n\n建议：把“下一次的更小动作”设成提醒或加入计划。',
          required: false,
        ),
      ];

  ActionTemplate _buildTemplate({required String id}) {
    // rebuild step ids
    final rebuiltCore = <ActionStep>[];
    var n = 1;
    for (final s in _coreSteps) {
      final sid = '${id}_s${n++}';
      rebuiltCore.add(ActionStep(
        id: sid,
        type: s.type,
        title: s.title,
        body: s.body,
        checklist: s.checklist,
        required: s.required,
        minRating: s.minRating,
        maxRating: s.maxRating,
        hint: s.hint,
      ));
    }

    final steps = <ActionStep>[];
    steps.add(ActionStep(
      id: '${id}_concept',
      type: ActionStepType.info,
      title: '概念与定义',
      body: '**概念：${_concept.text.trim()}**\n\n${_conceptDef.text.trim()}\n\n**操作化定义（现实可观察指标）**\n${_opDef.text.trim()}',
      required: false,
    ));

    if (_mode == ActionMode.plan) {
      steps.add(ActionStep(
        id: '${id}_goal',
        type: ActionStepType.input,
        title: '关联目标（计划模式）',
        body: _goalHint.text.trim().isEmpty
            ? '写下你要关联的目标（未来会接入目标模块）。\n\n格式建议：目标一句话 + 截止时间 + 衡量指标。'
            : _goalHint.text.trim(),
        hint: '例如：4周内把睡眠稳定到23:30入睡；用“连续天数”衡量。',
      ));
    }

    steps.addAll(rebuiltCore);
    steps.addAll(_evalSteps(id));

    return ActionTemplate(
      id: id,
      title: _title.text.trim(),
      concept: _concept.text.trim(),
      conceptDefinition: _conceptDef.text.trim(),
      operationalDefinition: _opDef.text.trim(),
      categoryPath: _category.text.trim(),
      mode: _mode,
      steps: steps,
      commonObstacles: _lines(_obstacles),
      changePath: _lines(_changePath),
      learningTags: _lines(_learning),
      goalHint: _goalHint.text.trim(),
    );
  }

  bool _validate() {
    if (_title.text.trim().isEmpty) return false;
    if (_category.text.trim().isEmpty) return false;
    if (_concept.text.trim().isEmpty) return false;
    if (_opDef.text.trim().isEmpty) return false;
    if (_coreSteps.isEmpty) return false;
    return true;
  }

  Future<void> _save() async {
    if (_saving) return;
    if (!_validate()) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请至少填写：标题、分类、概念、操作化定义，并添加一个步骤')));
      return;
    }

    setState(() => _saving = true);
    try {
      final isNew = widget.existing == null || widget.duplicateAsNew;
      final id = isNew ? _newId() : widget.existing!.id;
      final tpl = _buildTemplate(id: id);
      await _dao.upsertTemplate(tpl);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('保存失败：$e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _addStep() async {
    final res = await showDialog<ActionStep>(
      context: context,
      builder: (_) => _StepEditorDialog(),
    );
    if (res == null) return;
    setState(() => _coreSteps.add(res));
  }

  Future<void> _editStep(int i) async {
    final res = await showDialog<ActionStep>(
      context: context,
      builder: (_) => _StepEditorDialog(existing: _coreSteps[i]),
    );
    if (res == null) return;
    setState(() => _coreSteps[i] = res);
  }

  @override
  Widget build(BuildContext context) {
    final isNew = widget.existing == null || widget.duplicateAsNew;

    return Scaffold(
      appBar: AppBar(
        title: Text(isNew ? '新建行动模板' : '编辑行动模板'),
        actions: [
          TextButton(onPressed: _saving ? null : _save, child: const Text('保存')),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addStep,
        icon: const Icon(Icons.add),
        label: const Text('添加步骤'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 100),
        children: [
          _field('标题', _title, hint: '例如：25分钟深度工作块'),
          const SizedBox(height: 12),
          _field('分类路径（概念树）', _category, hint: '例如：工作/效率/专注'),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: SegmentedButton<ActionMode>(
                  segments: const [
                    ButtonSegment(value: ActionMode.free, label: Text('非计划模式')),
                    ButtonSegment(value: ActionMode.plan, label: Text('计划模式')),
                  ],
                  selected: {_mode},
                  onSelectionChanged: (s) => setState(() => _mode = s.first),
                ),
              ),
            ],
          ),
          if (_mode == ActionMode.plan) ...[
            const SizedBox(height: 12),
            _field('目标提示（可选）', _goalHint, hint: '这一步会在行动流程中出现（未来接入目标模块）', maxLines: 3),
          ],

          const SizedBox(height: 12),
          _field('概念（抽象目的/能力）', _concept, hint: '例如：深度工作块（单任务专注）'),
          const SizedBox(height: 12),
          _field('概念解释（为什么/是什么）', _conceptDef, hint: '一句话 + 必要细节', maxLines: 4),
          const SizedBox(height: 12),
          _field('操作化定义（现实可观察指标）*', _opDef, hint: '写清楚：在现实中怎么“看得见”，如何判断做到/没做到', maxLines: 4),

          const SizedBox(height: 18),
          const Text('步骤（概念 → 行动 → 评分验证）', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('这里编辑的是“行动清单/记录步骤”。\n概念说明与评分步骤会自动附加。', style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35)),
          const SizedBox(height: 12),

          ...List.generate(_coreSteps.length, (i) {
            final s = _coreSteps[i];
            final type = s.type.name;
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Material(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _editStep(i),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.black.withOpacity(0.06)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(s.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(color: Colors.black.withOpacity(0.06), borderRadius: BorderRadius.circular(999)),
                              child: Text(type, style: TextStyle(fontSize: 12, color: Colors.black.withOpacity(0.75))),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          s.type == ActionStepType.checklist ? '清单项：${s.checklist.length}' : s.body,
                          style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            IconButton(
                              tooltip: '上移',
                              onPressed: i == 0
                                  ? null
                                  : () => setState(() {
                                        final t = _coreSteps.removeAt(i);
                                        _coreSteps.insert(i - 1, t);
                                      }),
                              icon: const Icon(Icons.arrow_upward),
                            ),
                            IconButton(
                              tooltip: '下移',
                              onPressed: i == _coreSteps.length - 1
                                  ? null
                                  : () => setState(() {
                                        final t = _coreSteps.removeAt(i);
                                        _coreSteps.insert(i + 1, t);
                                      }),
                              icon: const Icon(Icons.arrow_downward),
                            ),
                            const Spacer(),
                            IconButton(
                              tooltip: '删除',
                              onPressed: () => setState(() => _coreSteps.removeAt(i)),
                              icon: const Icon(Icons.delete_outline),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),

          const SizedBox(height: 10),
          _field('常见困难（每行一条，可选）', _obstacles, hint: '用于失败模块/改进路径', maxLines: 4),
          const SizedBox(height: 12),
          _field('改变路径（每行一条，可选）', _changePath, hint: '用于识别不良习惯/问题行为并提供替代路径', maxLines: 4),
          const SizedBox(height: 12),
          _field('学习标签（每行一条，可选）', _learning, hint: '例如：行为主义、强化、刺激控制、习惯回路', maxLines: 3),

          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.04),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Text(
              '提示：\n- “操作化定义”一定要能被观察/测量，否则行动很容易跑偏。\n- 清单项尽量用动词开头（做/写/发/走/整理…），避免抽象词（努力/认真/专注…）。\n- 失败不是坏事：模板会自动附加“阻力记录/下一次更小动作”，未来可接入失败模块/改变模块。',
              style: TextStyle(color: Colors.black.withOpacity(0.75), height: 1.35),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {String hint = '', int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        TextField(
          controller: c,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ],
    );
  }
}

class _StepEditorDialog extends StatefulWidget {
  final ActionStep? existing;
  _StepEditorDialog({this.existing});

  @override
  State<_StepEditorDialog> createState() => _StepEditorDialogState();
}

class _StepEditorDialogState extends State<_StepEditorDialog> {
  late ActionStepType _type;
  final _title = TextEditingController();
  final _body = TextEditingController();
  final _checklist = TextEditingController();
  bool _required = true;

  @override
  void initState() {
    super.initState();
    final s = widget.existing;
    _type = s?.type ?? ActionStepType.checklist;
    _title.text = s?.title ?? '';
    _body.text = s?.body ?? '';
    _required = s?.required ?? true;
    if (s != null && s.type == ActionStepType.checklist) {
      _checklist.text = s.checklist.join('\n');
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    _checklist.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? '添加步骤' : '编辑步骤'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<ActionStepType>(
              value: _type,
              items: ActionStepType.values
                  .where((e) => e != ActionStepType.summary && e != ActionStepType.info)
                  .map((e) => DropdownMenuItem(value: e, child: Text(e.name)))
                  .toList(),
              onChanged: (v) => setState(() => _type = v ?? ActionStepType.input),
              decoration: const InputDecoration(labelText: '类型'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _title,
              decoration: const InputDecoration(labelText: '标题', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _body,
              maxLines: 4,
              decoration: const InputDecoration(labelText: '说明/引导', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            if (_type == ActionStepType.checklist)
              TextField(
                controller: _checklist,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: '清单项（每行一条）',
                  border: OutlineInputBorder(),
                ),
              ),
            const SizedBox(height: 10),
            SwitchListTile(
              value: _required,
              onChanged: (v) => setState(() => _required = v),
              title: const Text('必填/必做'),
              contentPadding: EdgeInsets.zero,
            )
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
        FilledButton(
          onPressed: () {
            if (_title.text.trim().isEmpty) return;
            final cl = _checklist.text
                .split('\n')
                .map((e) => e.trim())
                .where((e) => e.isNotEmpty)
                .toList();
            final step = ActionStep(
              id: widget.existing?.id ?? 'draft_${DateTime.now().millisecondsSinceEpoch}',
              type: _type,
              title: _title.text.trim(),
              body: _body.text.trim(),
              checklist: _type == ActionStepType.checklist ? cl : const [],
              required: _required,
            );
            Navigator.pop(context, step);
          },
          child: const Text('确定'),
        )
      ],
    );
  }
}
