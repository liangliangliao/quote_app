import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:quote_app/data/db.dart';
import 'action_models.dart';

class ActionDao {
  Future<Database> _db() => AppDatabase.instance();

  Future<void> ensureTables() async {
    final db = await _db();
    await db.execute('''
      CREATE TABLE IF NOT EXISTS action_templates (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category_path TEXT NOT NULL DEFAULT '',
        template_json TEXT NOT NULL,
        is_custom INTEGER NOT NULL DEFAULT 1,
        created_at_ms INTEGER NOT NULL DEFAULT 0,
        updated_at_ms INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS action_runs (
        id TEXT PRIMARY KEY,
        template_id TEXT NOT NULL,
        template_snapshot_json TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'in_progress',
        started_at_ms INTEGER NOT NULL DEFAULT 0,
        updated_at_ms INTEGER NOT NULL DEFAULT 0,
        ended_at_ms INTEGER,
        idx INTEGER NOT NULL DEFAULT 0,
        ans_json TEXT NOT NULL DEFAULT '{}',
        eval_json TEXT,
        note TEXT
      )
    ''');

    await db.execute('CREATE INDEX IF NOT EXISTS idx_action_runs_updated ON action_runs(updated_at_ms DESC)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_action_runs_status ON action_runs(status)');
  }

  Future<List<ActionTemplate>> listCustomTemplates() async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('action_templates', orderBy: 'updated_at_ms DESC');
    final out = <ActionTemplate>[];
    for (final r in rows) {
      final jsonStr = (r['template_json'] ?? '').toString();
      final t = ActionTemplate.tryFromJsonString(jsonStr);
      if (t != null) out.add(t);
    }
    return out;
  }

  Future<bool> templateExists(String id) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('action_templates', columns: ['id'], where: 'id=?', whereArgs: [id], limit: 1);
    return rows.isNotEmpty;
  }

  Future<ActionTemplate?> getTemplate(String id) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('action_templates', where: 'id=?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    final jsonStr = (rows.first['template_json'] ?? '').toString();
    return ActionTemplate.tryFromJsonString(jsonStr);
  }

  Future<void> upsertTemplate(ActionTemplate t) async {
    final db = await _db();
    await ensureTables();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert(
      'action_templates',
      {
        'id': t.id,
        'title': t.title,
        'category_path': t.categoryPath,
        'template_json': t.toJsonString(),
        'is_custom': 1,
        'created_at_ms': now,
        'updated_at_ms': now,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteTemplate(String id) async {
    final db = await _db();
    await ensureTables();
    await db.delete('action_templates', where: 'id=?', whereArgs: [id]);
  }

  String _uid(String prefix) => '$prefix${DateTime.now().millisecondsSinceEpoch}_${DateTime.now().microsecondsSinceEpoch % 100000}';

  Future<ActionRun> createRun({required ActionTemplate template}) async {
    final db = await _db();
    await ensureTables();
    final now = DateTime.now().millisecondsSinceEpoch;
    final rid = _uid('run_');
    final run = ActionRun(
      id: rid,
      templateId: template.id,
      templateSnapshotJson: template.toJsonString(),
      status: 'in_progress',
      startedAtMs: now,
      updatedAtMs: now,
      endedAtMs: null,
      idx: 0,
      ansJson: jsonEncode(<String, dynamic>{}),
      evalJson: null,
      note: null,
    );
    await db.insert('action_runs', run.toRow(), conflictAlgorithm: ConflictAlgorithm.replace);
    return run;
  }

  Future<ActionRun?> getRun(String id) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('action_runs', where: 'id=?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return ActionRun.fromRow(rows.first);
  }

  Future<void> saveRunProgress({required String runId, required int idx, required Map<String, dynamic> ans}) async {
    final db = await _db();
    await ensureTables();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.update(
      'action_runs',
      {
        'idx': idx,
        'ans_json': jsonEncode(ans),
        'updated_at_ms': now,
      },
      where: 'id=?',
      whereArgs: [runId],
    );
  }

  Future<void> finishRun({
    required String runId,
    required bool success,
    Map<String, dynamic>? eval,
    String? note,
  }) async {
    final db = await _db();
    await ensureTables();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.update(
      'action_runs',
      {
        'status': success ? 'done' : 'failed',
        'ended_at_ms': now,
        'updated_at_ms': now,
        'eval_json': eval == null ? null : jsonEncode(eval),
        'note': note,
      },
      where: 'id=?',
      whereArgs: [runId],
    );
  }

  Future<List<ActionRun>> listRuns({String? status, int limit = 200}) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query(
      'action_runs',
      where: status == null ? null : 'status=?',
      whereArgs: status == null ? null : [status],
      orderBy: 'updated_at_ms DESC',
      limit: limit,
    );
    return rows.map((r) => ActionRun.fromRow(r)).toList();
  }
}
