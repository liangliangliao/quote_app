import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_seed.dart';
import 'package:quote_app/action_lab/action_ui.dart';
import 'package:quote_app/action_lab/action_category_page.dart';
import 'package:quote_app/action_lab/action_custom_templates_page.dart';
import 'package:quote_app/action_lab/action_history_page.dart';
import 'package:quote_app/action_lab/action_generate_page.dart';
import 'package:quote_app/belief_lab/belief_mission_list_page.dart';

class ActionHomePage extends StatefulWidget {
  const ActionHomePage({super.key});

  @override
  State<ActionHomePage> createState() => _ActionHomePageState();
}

class _ActionHomePageState extends State<ActionHomePage> {
  final _dao = ActionDao();

  bool _loading = true;
  String? _err;

  int _customCount = 0;
  int _runCount = 0;
  List<String> _paths = const [];

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await _dao.ensureTables();
      final customs = await _dao.listCustomTemplates();
      final runs = await _dao.listRuns(limit: 200);

      final set = <String>{...builtInCategoryPaths()};
      for (final t in customs) {
        final p = t.categoryPath.trim();
        if (p.isNotEmpty) set.add(p);
      }
      final paths = set.toList()..sort();

      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = null;
        _customCount = customs.length;
        _runCount = runs.length;
        _paths = paths;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  Map<String, int> _rootCounts() {
    final m = <String, int>{};
    for (final p in _paths) {
      final root = p.split('/').first.trim();
      if (root.isEmpty) continue;
      m[root] = (m[root] ?? 0) + 1;
    }
    final entries = m.entries.toList()
      ..sort((a, b) => a.key.compareTo(b.key));
    return {for (final e in entries) e.key: e.value};
  }

  @override
  Widget build(BuildContext context) {
    final roots = _rootCounts();

    return Scaffold(
      appBar: AppBar(
        title: const Text('行动模板库'),
        actions: [
          IconButton(
            tooltip: '刷新',
            onPressed: _init,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _err != null
              ? Center(child: Text('加载失败：$_err'))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
                  children: [
                    const Text('行动 = 概念在现实中的直观表达', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text(
                      '每个模板都包含：概念定义 → 操作化定义（可观察指标）→ 行动清单 → 一致性/结果评分。\n\n已保存模板：$_customCount  ·  历史行动：$_runCount',
                      style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35),
                    ),
                    const SizedBox(height: 14),

                    ActionSectionCard(
                      title: 'AI 生成行动模板（关键词）',
                      subtitle: '输入关键词，让大模型生成“可执行”的现实行动模板；你可以保存到“我的模板”。',
                      icon: Icons.auto_awesome,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ActionGeneratePage())).then((_) => _init()),
                    ),
                    const SizedBox(height: 12),
                    ActionSectionCard(
                      title: '我的模板（自定义/AI保存）',
                      subtitle: '根据你的实际情况定制：计划模式（关联目标）/ 非计划模式（即时行动）。',
                      icon: Icons.edit_note,
                      trailing: ActionBadge('$_customCount'),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ActionCustomTemplatesPage())).then((_) => _init()),
                    ),
                    const SizedBox(height: 12),
                    ActionSectionCard(
                      title: '历史与复盘（评分/失败记录）',
                      subtitle: '查看完成/失败记录；每次行动都会验证“概念一致性”和“现实结果”。',
                      icon: Icons.history,
                      trailing: ActionBadge('$_runCount'),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ActionHistoryPage())),
                    ),
                    const SizedBox(height: 12),
                    ActionSectionCard(
                      title: '信念实验室：任务与复盘（原有）',
                      subtitle: '保留原有“信念实验室”的3天/7天任务与复盘流程。',
                      icon: Icons.checklist_outlined,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BeliefMissionListPage())),
                    ),

                    const SizedBox(height: 18),
                    const Text('类别（概念树）', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),

                    ...roots.entries.map((e) {
                      final root = e.key;
                      final count = e.value;
                      final desc = '包含 $count 个子类路径，内置+自定义模板都会汇总展示。';
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: ActionSectionCard(
                          title: root,
                          subtitle: desc,
                          icon: Icons.account_tree_outlined,
                          trailing: ActionBadge('$count'),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ActionCategoryPage(categoryRoot: root),
                            ),
                          ),
                        ),
                      );
                    }),

                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.04),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        '提示：计划模式会记录“目标描述/里程碑”，未来接入目标模块后可自动映射；失败时会记录“阻力/挫折”，未来可跳转到失败模块做复盘。',
                        style: TextStyle(color: Colors.black.withOpacity(0.75), height: 1.35),
                      ),
                    ),
                  ],
                ),
    );
  }
}
