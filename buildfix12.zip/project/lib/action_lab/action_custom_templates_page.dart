import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_models.dart';
import 'package:quote_app/action_lab/action_template_detail_page.dart';
import 'package:quote_app/action_lab/action_template_editor_page.dart';

class ActionCustomTemplatesPage extends StatefulWidget {
  const ActionCustomTemplatesPage({super.key});

  @override
  State<ActionCustomTemplatesPage> createState() => _ActionCustomTemplatesPageState();
}

class _ActionCustomTemplatesPageState extends State<ActionCustomTemplatesPage> {
  final _dao = ActionDao();
  bool _loading = true;
  String? _err;
  List<ActionTemplate> _list = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final list = await _dao.listCustomTemplates();
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = null;
        _list = list;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  Future<void> _create() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const ActionTemplateEditorPage()));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('我的模板'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _create,
        child: const Icon(Icons.add),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _err != null
              ? Center(child: Text('加载失败：$_err'))
              : _list.isEmpty
                  ? Center(child: Text('还没有自定义模板。点右下角 “+” 创建。', style: TextStyle(color: Colors.black.withOpacity(0.7))))
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
                      itemCount: _list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final t = _list[i];
                        final mode = t.mode == ActionMode.plan ? '计划' : '即时';
                        return Material(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(18),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => ActionTemplateDetailPage(template: t)),
                            ).then((_) => _load()),
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: Colors.black.withOpacity(0.06)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(t.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                                  const SizedBox(height: 6),
                                  Text('${t.categoryPath}\n概念：${t.concept}\n模式：$mode', style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35)),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
