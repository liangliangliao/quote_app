package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import androidx.work.WorkManager

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val payload = intent.getStringExtra("payload") ?: "{}"
            val json = JSONObject(payload)

            val id = json.optInt("id", (System.currentTimeMillis() % 1000000).toInt())
            val title = json.optString("title", "提醒")
            val body = json.optString("body", "")
            val uid = json.optString("task_uid", "")
            val runKey = json.optString("run_key", "")

            if (body.isNotEmpty()) {
                val builder = NotificationCompat.Builder(context, "quote_notify")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)

                NotificationManagerCompat.from(context).notify(id, builder.build())
            }

            if (uid.isNotEmpty() && runKey.isNotEmpty()) {
                val unique = "fb_next_${uid}_${runKey}"
                try { WorkManager.getInstance(context).cancelUniqueWork(unique) } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // ignore
        }
    }
}
