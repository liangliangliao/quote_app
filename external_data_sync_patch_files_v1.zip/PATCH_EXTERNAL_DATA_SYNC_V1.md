# PATCH_EXTERNAL_DATA_SYNC_V1

## Scope

新增“外部数据同步”模块，入口位于首页左侧抽屉菜单。

## Microsoft OneNote

- 已内置 Microsoft Client ID：`dccf2bf4-0571-4abe-a303-bf07fb967147`。
- 支持通过 Microsoft OAuth PKCE 登录。
- 支持同步当前登录账号的全部 OneNote 笔记本。
- 支持读取 notebook → section/sectionGroup → pages。
- 支持读取页面 HTML 正文并生成纯文本。
- 支持解析并下载 OneNote 页面中的 Graph resources 附件，保存到本地文件目录。
- 保存到本地 SQLite 表：external_accounts / external_entries / external_attachments / external_sync_state / external_api_logs。

## Sina Weibo

- 客户端不内置 App Secret。
- 当前版本支持粘贴已授权 access_token 后调用 `statuses/user_timeline/biz`。
- 支持分页拉取微博内容并保存到统一 external_entries 表。
- 微博图片先保存 URL 到 external_attachments 表。
- 后续如果提供后端，可将 OAuth code 换 token 放到后端完成。

## Android

- 在 AndroidManifest.xml 的 flutter_web_auth_2 CallbackActivity 增加 `msauth` scheme，用于 Microsoft 登录回调。

## Important

Microsoft Redirect URI 仍需在 Entra 中配置完整值：

`msauth://com.example.quote_app/<base64-signature-hash>`

然后在 App 的“外部数据同步”页面中填入同一个 Redirect URI。
