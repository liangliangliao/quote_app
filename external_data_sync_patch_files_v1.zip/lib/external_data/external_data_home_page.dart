import 'dart:io';

import 'package:flutter/material.dart';

import '../data/kv_dao.dart';
import 'external_data_config.dart';
import 'external_data_dao.dart';
import 'onenote_client.dart';
import 'weibo_client.dart';

class ExternalDataHomePage extends StatefulWidget {
  const ExternalDataHomePage({super.key});

  @override
  State<ExternalDataHomePage> createState() => _ExternalDataHomePageState();
}

class _ExternalDataHomePageState extends State<ExternalDataHomePage> {
  final _dao = ExternalDataDao();
  final _kv = KeyValueDao();
  final _oneNote = OneNoteClient();
  final _weibo = WeiboClient();
  final _clientId = TextEditingController(text: ExternalDataConfig.microsoftClientId);
  final _redirectUri = TextEditingController(text: ExternalDataConfig.defaultMicrosoftRedirectUri);
  final _weiboToken = TextEditingController();
  final _search = TextEditingController();

  bool _busy = false;
  bool _oneNoteConnected = false;
  bool _weiboConfigured = false;
  String _progress = '';
  String _filter = 'all';
  List<Map<String, dynamic>> _entries = [];
  Map<String, int> _counts = {};

  static const _kMsClientId = 'external_ms_client_id';
  static const _kMsRedirectUri = 'external_ms_redirect_uri';
  static const _kWeiboToken = 'external_weibo_access_token';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await _dao.ensureSchema();
    _clientId.text = await _kv.getString(_kMsClientId) ?? ExternalDataConfig.microsoftClientId;
    _redirectUri.text = await _kv.getString(_kMsRedirectUri) ?? ExternalDataConfig.defaultMicrosoftRedirectUri;
    _weiboToken.text = await _kv.getString(_kWeiboToken) ?? '';
    _oneNoteConnected = await _oneNote.isConnected();
    _weiboConfigured = await _weibo.isConfigured();
    _counts = await _dao.counts();
    await _reloadEntries();
  }

  Future<void> _reloadEntries() async {
    final rows = await _dao.listEntries(source: _filter, keyword: _search.text, limit: 100);
    if (!mounted) return;
    setState(() {
      _entries = rows;
    });
  }

  Future<void> _saveConfig() async {
    await _kv.setString(_kMsClientId, _clientId.text.trim());
    await _kv.setString(_kMsRedirectUri, _redirectUri.text.trim());
    await _kv.setString(_kWeiboToken, _weiboToken.text.trim());
    if (_weiboToken.text.trim().isNotEmpty) {
      await _weibo.saveAccessToken(_weiboToken.text.trim());
    }
    _weiboConfigured = await _weibo.isConfigured();
    if (!mounted) return;
    setState(() {});
    _toast('配置已保存');
  }

  Future<void> _connectMicrosoft() async {
    await _saveConfig();
    setState(() { _busy = true; _progress = '正在打开 Microsoft 登录...'; });
    try {
      await _oneNote.connect(clientId: _clientId.text.trim(), redirectUri: _redirectUri.text.trim());
      _oneNoteConnected = true;
      _toast('Microsoft OneNote 已连接');
    } catch (e) {
      _showError(e);
    } finally {
      if (mounted) setState(() { _busy = false; _progress = ''; });
    }
  }

  Future<void> _syncOneNote() async {
    setState(() { _busy = true; _progress = '准备同步 OneNote 所有笔记本...'; });
    try {
      final result = await _oneNote.syncAllNotebooks(onProgress: (p) {
        if (mounted) setState(() => _progress = p.message);
      });
      _counts = await _dao.counts();
      await _reloadEntries();
      _toast('OneNote 同步完成：${result.notebooks} 个笔记本，${result.pages} 条页面，${result.attachments} 个附件');
    } catch (e) {
      await _dao.saveSyncState(source: 'onenote', lastError: e.toString(), targetId: 'all');
      _showError(e);
    } finally {
      if (mounted) setState(() { _busy = false; _progress = ''; });
    }
  }

  Future<void> _syncWeibo() async {
    await _saveConfig();
    setState(() { _busy = true; _progress = '准备同步微博...'; });
    try {
      final result = await _weibo.syncTimeline(onProgress: (p) {
        if (mounted) setState(() => _progress = p.message);
      });
      _counts = await _dao.counts();
      await _reloadEntries();
      _toast('微博同步完成：${result.statuses} 条');
    } catch (e) {
      await _dao.saveSyncState(source: 'weibo', lastError: e.toString(), targetId: 'timeline');
      _showError(e);
    } finally {
      if (mounted) setState(() { _busy = false; _progress = ''; });
    }
  }

  void _showError(Object e) {
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('操作失败'),
        content: SingleChildScrollView(child: Text(e.toString())),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('知道了'))],
      ),
    );
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    _clientId.dispose();
    _redirectUri.dispose();
    _weiboToken.dispose();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('外部数据同步'),
        actions: [
          IconButton(onPressed: _busy ? null : _load, icon: const Icon(Icons.refresh), tooltip: '刷新'),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildNotice(),
          const SizedBox(height: 12),
          _buildOneNoteCard(),
          const SizedBox(height: 12),
          _buildWeiboCard(),
          const SizedBox(height: 12),
          if (_busy) _buildProgress(),
          _buildTimelineHeader(),
          const SizedBox(height: 8),
          ..._entries.map(_buildEntryCard),
          if (_entries.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 32),
              child: Center(child: Text('暂无同步数据')),
            ),
        ],
      ),
    );
  }

  Widget _buildNotice() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFF3F4F6), borderRadius: BorderRadius.circular(16)),
      child: const Text(
        '本模块会把 Microsoft OneNote 和新浪微博接口返回的数据统一保存到 App 本地数据库并按时间线显示。OneNote 支持同步所有笔记本；微博取决于你的微博应用是否已开通 user_timeline/biz 权限，不能承诺返回已删除微博、私信、收藏或全部媒体原文件。',
        style: TextStyle(height: 1.45, color: Color(0xFF374151)),
      ),
    );
  }

  Widget _buildOneNoteCard() {
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Icon(Icons.note_alt_outlined),
              const SizedBox(width: 8),
              const Expanded(child: Text('Microsoft OneNote', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
              Chip(label: Text(_oneNoteConnected ? '已连接' : '未连接')),
            ]),
            const SizedBox(height: 10),
            TextField(controller: _clientId, decoration: const InputDecoration(labelText: 'Microsoft Client ID')),
            const SizedBox(height: 8),
            TextField(
              controller: _redirectUri,
              decoration: const InputDecoration(
                labelText: 'Microsoft Redirect URI',
                helperText: '格式：msauth://com.example.quote_app/你的base64签名哈希',
              ),
            ),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(onPressed: _busy ? null : _connectMicrosoft, icon: const Icon(Icons.login), label: const Text('登录 Microsoft')),
              OutlinedButton.icon(onPressed: (!_oneNoteConnected || _busy) ? null : _syncOneNote, icon: const Icon(Icons.sync), label: const Text('同步所有笔记本')),
              TextButton.icon(onPressed: _busy ? null : () async { await _oneNote.disconnect(); await _load(); }, icon: const Icon(Icons.link_off), label: const Text('断开')),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildWeiboCard() {
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Icon(Icons.public),
              const SizedBox(width: 8),
              const Expanded(child: Text('新浪微博', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
              Chip(label: Text(_weiboConfigured ? '已配置Token' : '待配置')),
            ]),
            const SizedBox(height: 10),
            const Text('当前版本先支持粘贴 access_token 调用商业接口 statuses/user_timeline/biz；App Secret 不写入客户端，后续可接入你自己的后端完成 OAuth 换 token。', style: TextStyle(color: Color(0xFF6B7280), height: 1.4)),
            const SizedBox(height: 8),
            TextField(controller: _weiboToken, obscureText: true, decoration: const InputDecoration(labelText: '微博 access_token')),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(onPressed: _busy ? null : _saveConfig, icon: const Icon(Icons.save), label: const Text('保存配置')),
              OutlinedButton.icon(onPressed: _busy ? null : _syncWeibo, icon: const Icon(Icons.sync), label: const Text('同步我发过的微博')),
              TextButton.icon(onPressed: _busy ? null : () async { await _weibo.disconnect(); await _kv.setString(_kWeiboToken, ''); _weiboToken.clear(); await _load(); }, icon: const Icon(Icons.link_off), label: const Text('清除Token')),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildProgress() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(14)),
      child: Row(children: [
        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
        const SizedBox(width: 12),
        Expanded(child: Text(_progress.isEmpty ? '正在处理...' : _progress)),
      ]),
    );
  }

  Widget _buildTimelineHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 6),
        Row(children: [
          const Expanded(child: Text('同步记录时间线', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
          Text('OneNote ${_counts['onenote'] ?? 0} · 微博 ${_counts['weibo'] ?? 0}', style: const TextStyle(color: Color(0xFF6B7280))),
        ]),
        const SizedBox(height: 8),
        TextField(
          controller: _search,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            hintText: '搜索已同步内容',
            suffixIcon: IconButton(onPressed: () { _search.clear(); _reloadEntries(); }, icon: const Icon(Icons.clear)),
          ),
          onSubmitted: (_) => _reloadEntries(),
        ),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'all', label: Text('全部')),
            ButtonSegment(value: 'onenote', label: Text('OneNote')),
            ButtonSegment(value: 'weibo', label: Text('微博')),
          ],
          selected: {_filter},
          onSelectionChanged: (v) { setState(() => _filter = v.first); _reloadEntries(); },
        ),
      ],
    );
  }

  Widget _buildEntryCard(Map<String, dynamic> row) {
    final source = (row['source'] ?? '').toString();
    final title = (row['title'] ?? '').toString().trim();
    final text = (row['plain_text'] ?? '').toString().trim();
    final ts = int.tryParse((row['created_at_ms'] ?? row['updated_at_ms'] ?? '').toString());
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: CircleAvatar(child: Icon(source == 'weibo' ? Icons.public : Icons.note_alt_outlined)),
        title: Text(title.isEmpty ? '(无标题)' : title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${source == 'weibo' ? '新浪微博' : 'OneNote'} · ${_formatTime(ts)}\n${text.isEmpty ? '' : text}', maxLines: 3, overflow: TextOverflow.ellipsis),
        isThreeLine: true,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ExternalEntryDetailPage(entry: row))),
      ),
    );
  }

  String _formatTime(int? ms) {
    if (ms == null || ms <= 0) return '未知时间';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }
}

class ExternalEntryDetailPage extends StatefulWidget {
  const ExternalEntryDetailPage({super.key, required this.entry});
  final Map<String, dynamic> entry;

  @override
  State<ExternalEntryDetailPage> createState() => _ExternalEntryDetailPageState();
}

class _ExternalEntryDetailPageState extends State<ExternalEntryDetailPage> {
  final _dao = ExternalDataDao();
  List<Map<String, dynamic>> _attachments = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final id = (widget.entry['id'] as num).toInt();
    final rows = await _dao.listAttachments(id);
    if (mounted) setState(() => _attachments = rows);
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    final title = (e['title'] ?? '').toString();
    final text = (e['plain_text'] ?? '').toString();
    final source = (e['source'] ?? '').toString();
    final url = (e['original_url'] ?? '').toString();
    return Scaffold(
      appBar: AppBar(title: Text(source == 'weibo' ? '微博详情' : 'OneNote详情')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(title.isEmpty ? '(无标题)' : title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(source == 'weibo' ? '来源：新浪微博' : '来源：Microsoft OneNote', style: const TextStyle(color: Color(0xFF6B7280))),
          if (url.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('原始链接：$url', style: const TextStyle(color: Colors.blue))),
          const Divider(height: 28),
          SelectableText(text.isEmpty ? '(无正文)' : text, style: const TextStyle(fontSize: 16, height: 1.6)),
          if (_attachments.isNotEmpty) ...[
            const Divider(height: 28),
            const Text('附件', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ..._attachments.map((a) => _attachmentTile(a)),
          ],
        ],
      ),
    );
  }

  Widget _attachmentTile(Map<String, dynamic> a) {
    final local = (a['local_path'] ?? '').toString();
    final remote = (a['remote_url'] ?? '').toString();
    final name = (a['file_name'] ?? '').toString();
    final isImage = local.toLowerCase().endsWith('.png') || local.toLowerCase().endsWith('.jpg') || local.toLowerCase().endsWith('.jpeg') || remote.contains('sinaimg');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name.isEmpty ? '附件' : name, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          if (isImage && local.isNotEmpty && File(local).existsSync()) Image.file(File(local), height: 160, fit: BoxFit.contain),
          if (isImage && local.isEmpty && remote.isNotEmpty) Image.network(remote, height: 160, fit: BoxFit.contain, errorBuilder: (_, __, ___) => Text(remote)),
          if (!isImage) SelectableText(local.isNotEmpty ? local : remote),
        ]),
      ),
    );
  }
}
