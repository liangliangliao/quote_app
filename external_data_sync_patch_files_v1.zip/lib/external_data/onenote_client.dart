import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_web_auth_2/flutter_web_auth_2.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'external_data_config.dart';
import 'external_data_dao.dart';

class OneNoteSyncProgress {
  OneNoteSyncProgress({required this.message, this.synced = 0, this.total = 0});
  final String message;
  final int synced;
  final int total;
}

class OneNoteSyncResult {
  OneNoteSyncResult({required this.notebooks, required this.pages, required this.attachments});
  final int notebooks;
  final int pages;
  final int attachments;
}

class OneNoteClient {
  OneNoteClient({ExternalDataDao? dao}) : _dao = dao ?? ExternalDataDao();

  final ExternalDataDao _dao;
  static const _source = 'onenote';
  static const _base = 'https://graph.microsoft.com/v1.0';
  static const _tokenUrl = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';

  Future<bool> isConnected() async {
    final acc = await _dao.getAccount(_source);
    return ((acc?['refresh_token'] ?? '').toString().isNotEmpty || (acc?['access_token'] ?? '').toString().isNotEmpty);
  }

  Future<void> disconnect() async => _dao.deleteAccount(_source);

  Future<void> connect({required String clientId, required String redirectUri}) async {
    final cid = clientId.trim();
    final redirect = redirectUri.trim();
    if (cid.isEmpty) throw Exception('Microsoft Client ID 不能为空');
    if (redirect.isEmpty || !redirect.startsWith('msauth://')) {
      throw Exception('Microsoft Redirect URI 必须是 msauth:// 开头，并与 Entra 中配置一致');
    }
    final verifier = _codeVerifier();
    final challenge = _codeChallenge(verifier);
    final state = _randomString(24);
    final auth = Uri.https('login.microsoftonline.com', '/common/oauth2/v2.0/authorize', {
      'client_id': cid,
      'response_type': 'code',
      'redirect_uri': redirect,
      'response_mode': 'query',
      'scope': ExternalDataConfig.microsoftAuthScope,
      'code_challenge': challenge,
      'code_challenge_method': 'S256',
      'state': state,
      'prompt': 'select_account',
    });
    final result = await FlutterWebAuth2.authenticate(url: auth.toString(), callbackUrlScheme: 'msauth');
    final uri = Uri.parse(result);
    final err = uri.queryParameters['error'];
    if (err != null && err.isNotEmpty) {
      throw Exception('Microsoft 授权失败：$err ${uri.queryParameters['error_description'] ?? ''}');
    }
    if (uri.queryParameters['state'] != state) throw Exception('Microsoft 授权失败：state 校验不一致');
    final code = uri.queryParameters['code'];
    if (code == null || code.isEmpty) throw Exception('Microsoft 授权失败：未返回 code');
    await _exchangeCode(clientId: cid, redirectUri: redirect, code: code, codeVerifier: verifier);
  }

  Future<void> _exchangeCode({required String clientId, required String redirectUri, required String code, required String codeVerifier}) async {
    final resp = await http.post(
      Uri.parse(_tokenUrl),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'client_id': clientId,
        'scope': ExternalDataConfig.microsoftAuthScope,
        'code': code,
        'redirect_uri': redirectUri,
        'grant_type': 'authorization_code',
        'code_verifier': codeVerifier,
      },
    );
    await _dao.logApi(source: _source, endpoint: _tokenUrl, method: 'POST', requestParams: {'grant_type': 'authorization_code'}, statusCode: resp.statusCode, responseBody: resp.body);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('Microsoft token 获取失败：${resp.statusCode} ${resp.body}');
    }
    final json = jsonDecode(resp.body) as Map<String, dynamic>;
    final access = (json['access_token'] ?? '').toString();
    final refresh = (json['refresh_token'] ?? '').toString();
    final expiresIn = int.tryParse((json['expires_in'] ?? '3600').toString()) ?? 3600;
    await _dao.saveAccount(
      source: _source,
      accountId: 'default',
      displayName: 'Microsoft OneNote',
      accessToken: access,
      refreshToken: refresh,
      scope: (json['scope'] ?? '').toString(),
      expiresAtMs: DateTime.now().millisecondsSinceEpoch + expiresIn * 1000,
      extra: {'client_id': clientId, 'redirect_uri': redirectUri},
    );
  }

  Future<String> _accessToken() async {
    final acc = await _dao.getAccount(_source);
    if (acc == null) throw Exception('尚未连接 Microsoft OneNote');
    final token = (acc['access_token'] ?? '').toString();
    final refresh = (acc['refresh_token'] ?? '').toString();
    final expiresAt = int.tryParse((acc['expires_at_ms'] ?? '0').toString()) ?? 0;
    final extra = _decodeMap((acc['extra_json'] ?? '').toString());
    final clientId = (extra['client_id'] ?? ExternalDataConfig.microsoftClientId).toString();
    final now = DateTime.now().millisecondsSinceEpoch;
    if (token.isNotEmpty && now < expiresAt - 60 * 1000) return token;
    if (refresh.isEmpty) throw Exception('Microsoft token 已失效，请重新登录');
    final resp = await http.post(
      Uri.parse(_tokenUrl),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'client_id': clientId,
        'scope': ExternalDataConfig.microsoftAuthScope,
        'refresh_token': refresh,
        'grant_type': 'refresh_token',
      },
    );
    await _dao.logApi(source: _source, endpoint: _tokenUrl, method: 'POST', requestParams: {'grant_type': 'refresh_token'}, statusCode: resp.statusCode, responseBody: resp.body);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('Microsoft token 刷新失败，请重新登录：${resp.statusCode} ${resp.body}');
    }
    final json = jsonDecode(resp.body) as Map<String, dynamic>;
    final newAccess = (json['access_token'] ?? '').toString();
    final newRefresh = (json['refresh_token'] ?? refresh).toString();
    final expiresIn = int.tryParse((json['expires_in'] ?? '3600').toString()) ?? 3600;
    await _dao.saveAccount(
      source: _source,
      accountId: 'default',
      displayName: 'Microsoft OneNote',
      accessToken: newAccess,
      refreshToken: newRefresh,
      scope: (json['scope'] ?? '').toString(),
      expiresAtMs: DateTime.now().millisecondsSinceEpoch + expiresIn * 1000,
      extra: extra,
    );
    return newAccess;
  }

  Future<List<Map<String, dynamic>>> listNotebooks() async {
    return await _getPagedJson('$_base/me/onenote/notebooks?\$top=100');
  }

  Future<OneNoteSyncResult> syncAllNotebooks({void Function(OneNoteSyncProgress progress)? onProgress}) async {
    final notebooks = await listNotebooks();
    var pageCount = 0;
    var attachmentCount = 0;
    onProgress?.call(OneNoteSyncProgress(message: '已获取 ${notebooks.length} 个笔记本', total: notebooks.length));
    for (var i = 0; i < notebooks.length; i++) {
      final nb = notebooks[i];
      final notebookId = (nb['id'] ?? '').toString();
      final notebookName = (nb['displayName'] ?? nb['name'] ?? '未命名笔记本').toString();
      if (notebookId.isEmpty) continue;
      onProgress?.call(OneNoteSyncProgress(message: '正在同步笔记本：$notebookName', synced: i, total: notebooks.length));
      final sections = await _sectionsForNotebook(notebookId);
      for (final sec in sections) {
        final pages = await _pagesForSection((sec['id'] ?? '').toString());
        for (final page in pages) {
          final pageId = (page['id'] ?? '').toString();
          if (pageId.isEmpty) continue;
          final html = await _pageContent(pageId);
          final title = (page['title'] ?? '').toString().trim().isNotEmpty ? (page['title'] ?? '').toString().trim() : _titleFromHtml(html);
          final plain = _plainText(html);
          final created = _parseMs((page['createdDateTime'] ?? '').toString());
          final modified = _parseMs((page['lastModifiedDateTime'] ?? '').toString());
          final entryId = await _dao.upsertEntry(
            source: _source,
            sourceAccountId: 'default',
            sourceItemId: pageId,
            parentId: (sec['id'] ?? '').toString(),
            title: title,
            plainText: plain,
            htmlContent: html,
            originalUrl: (page['links'] is Map && page['links']['oneNoteWebUrl'] is Map) ? (page['links']['oneNoteWebUrl']['href'] ?? '').toString() : '',
            createdAtMs: created,
            updatedAtMs: modified,
            raw: {'notebook': nb, 'section': sec, 'page': page},
          );
          final savedAttachments = await _downloadResources(entryId: entryId, pageId: pageId, html: html);
          attachmentCount += savedAttachments;
          pageCount++;
          if (pageCount % 5 == 0) {
            onProgress?.call(OneNoteSyncProgress(message: '已同步 OneNote 页面 $pageCount 条，附件 $attachmentCount 个', synced: pageCount));
          }
        }
      }
    }
    await _dao.saveSyncState(source: _source, totalSynced: pageCount, success: true, targetId: 'all');
    onProgress?.call(OneNoteSyncProgress(message: 'OneNote 同步完成：$pageCount 条页面，$attachmentCount 个附件', synced: pageCount));
    return OneNoteSyncResult(notebooks: notebooks.length, pages: pageCount, attachments: attachmentCount);
  }

  Future<List<Map<String, dynamic>>> _sectionsForNotebook(String notebookId) async {
    final sections = <Map<String, dynamic>>[];
    sections.addAll(await _getPagedJson('$_base/me/onenote/notebooks/$notebookId/sections?\$top=100'));
    final groups = await _getPagedJson('$_base/me/onenote/notebooks/$notebookId/sectionGroups?\$top=100');
    for (final g in groups) {
      sections.addAll(await _sectionsForGroup((g['id'] ?? '').toString()));
    }
    return sections;
  }

  Future<List<Map<String, dynamic>>> _sectionsForGroup(String groupId) async {
    if (groupId.isEmpty) return [];
    final sections = <Map<String, dynamic>>[];
    sections.addAll(await _getPagedJson('$_base/me/onenote/sectionGroups/$groupId/sections?\$top=100'));
    final groups = await _getPagedJson('$_base/me/onenote/sectionGroups/$groupId/sectionGroups?\$top=100');
    for (final g in groups) {
      sections.addAll(await _sectionsForGroup((g['id'] ?? '').toString()));
    }
    return sections;
  }

  Future<List<Map<String, dynamic>>> _pagesForSection(String sectionId) async {
    if (sectionId.isEmpty) return [];
    return _getPagedJson('$_base/me/onenote/sections/$sectionId/pages?\$top=100');
  }

  Future<String> _pageContent(String pageId) async {
    final token = await _accessToken();
    final url = '$_base/me/onenote/pages/$pageId/content';
    final resp = await http.get(Uri.parse(url), headers: {'Authorization': 'Bearer $token', 'Accept': 'text/html'});
    await _dao.logApi(source: _source, endpoint: url, statusCode: resp.statusCode, responseBody: resp.body);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('OneNote 页面正文获取失败：${resp.statusCode} ${resp.body}');
    }
    return resp.body;
  }

  Future<List<Map<String, dynamic>>> _getPagedJson(String firstUrl) async {
    final out = <Map<String, dynamic>>[];
    var url = firstUrl;
    while (url.isNotEmpty) {
      final token = await _accessToken();
      final resp = await http.get(Uri.parse(url), headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'});
      await _dao.logApi(source: _source, endpoint: url, statusCode: resp.statusCode, responseBody: resp.body);
      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw Exception('Microsoft Graph 请求失败：${resp.statusCode} ${resp.body}');
      }
      final json = jsonDecode(resp.body) as Map<String, dynamic>;
      final value = json['value'];
      if (value is List) {
        for (final v in value) {
          if (v is Map) out.add(Map<String, dynamic>.from(v));
        }
      }
      final next = json['@odata.nextLink'];
      url = next == null ? '' : next.toString();
    }
    return out;
  }

  Future<int> _downloadResources({required int entryId, required String pageId, required String html}) async {
    final token = await _accessToken();
    final urls = <String>{};
    final re = RegExp("(https://graph\\.microsoft\\.com/[^\"'<>\\s]+/resources/([^/\"'<>\\s]+)/\\\$value[^\"'<>\\s]*)");
    for (final m in re.allMatches(html)) {
      final url = m.group(1);
      if (url != null && url.isNotEmpty) urls.add(url.replaceAll('&amp;', '&'));
    }
    var count = 0;
    if (urls.isEmpty) return 0;
    final dir = await getApplicationDocumentsDirectory();
    final baseDir = Directory(p.join(dir.path, 'external_data', 'onenote', pageId));
    if (!await baseDir.exists()) await baseDir.create(recursive: true);
    for (final url in urls) {
      try {
        final resourceId = _resourceId(url);
        final resp = await http.get(Uri.parse(url), headers: {'Authorization': 'Bearer $token'});
        await _dao.logApi(source: _source, endpoint: url, statusCode: resp.statusCode, responseBody: resp.statusCode >= 400 ? resp.body : '<binary ${resp.bodyBytes.length} bytes>');
        if (resp.statusCode < 200 || resp.statusCode >= 300) continue;
        final ext = _extensionFromHeaders(resp.headers['content-type']);
        final fileName = (resourceId.isEmpty ? 'resource_${count + 1}' : resourceId) + ext;
        final file = File(p.join(baseDir.path, fileName));
        await file.writeAsBytes(resp.bodyBytes);
        await _dao.upsertAttachment(
          entryId: entryId,
          source: _source,
          sourceResourceId: resourceId,
          fileName: fileName,
          mimeType: resp.headers['content-type'] ?? '',
          remoteUrl: url,
          localPath: file.path,
          sizeBytes: resp.bodyBytes.length,
        );
        count++;
      } catch (e) {
        await _dao.logApi(source: _source, endpoint: url, errorMessage: e.toString());
      }
    }
    return count;
  }

  String _resourceId(String url) {
    final m = RegExp(r'/resources/([^/]+)/\$value').firstMatch(url);
    return m?.group(1) ?? '';
  }

  String _extensionFromHeaders(String? contentType) {
    final ct = (contentType ?? '').toLowerCase();
    if (ct.contains('png')) return '.png';
    if (ct.contains('jpeg') || ct.contains('jpg')) return '.jpg';
    if (ct.contains('gif')) return '.gif';
    if (ct.contains('pdf')) return '.pdf';
    if (ct.contains('mpeg') || ct.contains('mp3')) return '.mp3';
    if (ct.contains('mp4')) return '.mp4';
    if (ct.contains('wav')) return '.wav';
    return '.bin';
  }

  String _titleFromHtml(String html) {
    final m = RegExp(r'<title[^>]*>(.*?)</title>', caseSensitive: false, dotAll: true).firstMatch(html);
    if (m != null) return _decodeEntities(m.group(1) ?? '').trim();
    final text = _plainText(html);
    if (text.isEmpty) return 'OneNote 页面';
    return text.length > 30 ? text.substring(0, 30) : text;
  }

  String _plainText(String html) {
    var s = html.replaceAll(RegExp(r'<script[^>]*>.*?</script>', caseSensitive: false, dotAll: true), ' ');
    s = s.replaceAll(RegExp(r'<style[^>]*>.*?</style>', caseSensitive: false, dotAll: true), ' ');
    s = s.replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');
    s = s.replaceAll(RegExp(r'</p\s*>', caseSensitive: false), '\n');
    s = s.replaceAll(RegExp(r'<[^>]+>'), ' ');
    s = _decodeEntities(s);
    s = s.replaceAll(RegExp(r'[ \t\x0B\f\r]+'), ' ');
    s = s.replaceAll(RegExp(r'\n\s+'), '\n');
    s = s.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return s.trim();
  }

  String _decodeEntities(String s) {
    return s
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'");
  }

  int? _parseMs(String value) {
    if (value.trim().isEmpty) return null;
    return DateTime.tryParse(value)?.millisecondsSinceEpoch;
  }

  Map<String, dynamic> _decodeMap(String value) {
    if (value.isEmpty) return {};
    try {
      final v = jsonDecode(value);
      return v is Map ? Map<String, dynamic>.from(v) : {};
    } catch (_) {
      return {};
    }
  }

  String _codeVerifier() {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~';
    final rnd = Random.secure();
    return List.generate(64, (_) => chars[rnd.nextInt(chars.length)]).join();
  }

  String _codeChallenge(String verifier) {
    final bytes = sha256.convert(utf8.encode(verifier)).bytes;
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  String _randomString(int len) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final rnd = Random.secure();
    return List.generate(len, (_) => chars[rnd.nextInt(chars.length)]).join();
  }
}
