import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import '../data/db.dart';

class ExternalDataDao {
  Future<Database> get _db async {
    final db = await AppDatabase.instance();
    await ensureSchema(db);
    return db;
  }

  Future<void> ensureSchema([Database? opened]) async {
    final db = opened ?? await AppDatabase.instance();
    await db.execute('''
      CREATE TABLE IF NOT EXISTS external_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source TEXT NOT NULL,
        account_id TEXT,
        display_name TEXT,
        access_token TEXT,
        refresh_token TEXT,
        scope TEXT,
        expires_at_ms INTEGER,
        extra_json TEXT,
        created_at_ms INTEGER NOT NULL,
        updated_at_ms INTEGER NOT NULL,
        UNIQUE(source, account_id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS external_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source TEXT NOT NULL,
        source_account_id TEXT,
        source_item_id TEXT NOT NULL,
        parent_id TEXT,
        title TEXT,
        plain_text TEXT,
        html_content TEXT,
        original_url TEXT,
        created_at_ms INTEGER,
        updated_at_ms INTEGER,
        raw_json TEXT,
        sync_status TEXT,
        local_deleted INTEGER DEFAULT 0,
        created_local_at_ms INTEGER NOT NULL,
        updated_local_at_ms INTEGER NOT NULL,
        UNIQUE(source, source_item_id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS external_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL,
        source TEXT NOT NULL,
        source_resource_id TEXT,
        file_name TEXT,
        mime_type TEXT,
        remote_url TEXT,
        local_path TEXT,
        size_bytes INTEGER,
        created_at_ms INTEGER NOT NULL,
        UNIQUE(entry_id, source_resource_id, remote_url),
        FOREIGN KEY(entry_id) REFERENCES external_entries(id) ON DELETE CASCADE
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS external_sync_state (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source TEXT NOT NULL,
        source_account_id TEXT,
        target_id TEXT,
        last_sync_at_ms INTEGER,
        last_success_at_ms INTEGER,
        last_cursor TEXT,
        last_error TEXT,
        total_synced INTEGER DEFAULT 0,
        created_at_ms INTEGER NOT NULL,
        updated_at_ms INTEGER NOT NULL,
        UNIQUE(source, source_account_id, target_id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS external_api_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source TEXT NOT NULL,
        endpoint TEXT,
        method TEXT,
        request_params TEXT,
        response_body TEXT,
        status_code INTEGER,
        error_message TEXT,
        created_at_ms INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_external_entries_time
      ON external_entries(created_at_ms DESC, updated_at_ms DESC)
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_external_entries_source
      ON external_entries(source, created_at_ms DESC)
    ''');
  }

  Future<void> saveAccount({
    required String source,
    String? accountId,
    String? displayName,
    String? accessToken,
    String? refreshToken,
    String? scope,
    int? expiresAtMs,
    Map<String, dynamic>? extra,
  }) async {
    final db = await _db;
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = (accountId == null || accountId.isEmpty) ? 'default' : accountId;
    await db.insert(
      'external_accounts',
      {
        'source': source,
        'account_id': id,
        'display_name': displayName ?? '',
        'access_token': accessToken ?? '',
        'refresh_token': refreshToken ?? '',
        'scope': scope ?? '',
        'expires_at_ms': expiresAtMs,
        'extra_json': extra == null ? null : jsonEncode(extra),
        'created_at_ms': now,
        'updated_at_ms': now,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, dynamic>?> getAccount(String source, {String accountId = 'default'}) async {
    final db = await _db;
    final rows = await db.query(
      'external_accounts',
      where: 'source = ? AND account_id = ?',
      whereArgs: [source, accountId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Map<String, dynamic>.from(rows.first);
  }

  Future<void> deleteAccount(String source, {String accountId = 'default'}) async {
    final db = await _db;
    await db.delete('external_accounts', where: 'source = ? AND account_id = ?', whereArgs: [source, accountId]);
  }

  Future<int> upsertEntry({
    required String source,
    String? sourceAccountId,
    required String sourceItemId,
    String? parentId,
    String? title,
    String? plainText,
    String? htmlContent,
    String? originalUrl,
    int? createdAtMs,
    int? updatedAtMs,
    Map<String, dynamic>? raw,
    String syncStatus = 'synced',
  }) async {
    final db = await _db;
    final now = DateTime.now().millisecondsSinceEpoch;
    final row = {
      'source': source,
      'source_account_id': sourceAccountId ?? '',
      'source_item_id': sourceItemId,
      'parent_id': parentId ?? '',
      'title': title ?? '',
      'plain_text': plainText ?? '',
      'html_content': htmlContent ?? '',
      'original_url': originalUrl ?? '',
      'created_at_ms': createdAtMs,
      'updated_at_ms': updatedAtMs,
      'raw_json': raw == null ? null : jsonEncode(raw),
      'sync_status': syncStatus,
      'local_deleted': 0,
      'created_local_at_ms': now,
      'updated_local_at_ms': now,
    };
    await db.insert('external_entries', row, conflictAlgorithm: ConflictAlgorithm.replace);
    final rows = await db.query(
      'external_entries',
      columns: ['id'],
      where: 'source = ? AND source_item_id = ?',
      whereArgs: [source, sourceItemId],
      limit: 1,
    );
    return (rows.first['id'] as num).toInt();
  }

  Future<void> upsertAttachment({
    required int entryId,
    required String source,
    String? sourceResourceId,
    String? fileName,
    String? mimeType,
    String? remoteUrl,
    String? localPath,
    int? sizeBytes,
  }) async {
    final db = await _db;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert(
      'external_attachments',
      {
        'entry_id': entryId,
        'source': source,
        'source_resource_id': sourceResourceId ?? '',
        'file_name': fileName ?? '',
        'mime_type': mimeType ?? '',
        'remote_url': remoteUrl ?? '',
        'local_path': localPath ?? '',
        'size_bytes': sizeBytes,
        'created_at_ms': now,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> listEntries({String? source, String? keyword, int limit = 100, int offset = 0}) async {
    final db = await _db;
    final where = <String>['local_deleted = 0'];
    final args = <Object?>[];
    if (source != null && source.isNotEmpty && source != 'all') {
      where.add('source = ?');
      args.add(source);
    }
    if (keyword != null && keyword.trim().isNotEmpty) {
      where.add('(title LIKE ? OR plain_text LIKE ?)');
      args.add('%${keyword.trim()}%');
      args.add('%${keyword.trim()}%');
    }
    return await db.query(
      'external_entries',
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: 'COALESCE(created_at_ms, updated_at_ms, created_local_at_ms) DESC',
      limit: limit,
      offset: offset,
    );
  }

  Future<Map<String, int>> counts() async {
    final db = await _db;
    final rows = await db.rawQuery('SELECT source, COUNT(*) AS c FROM external_entries WHERE local_deleted = 0 GROUP BY source');
    final out = <String, int>{};
    for (final r in rows) {
      out[(r['source'] ?? '').toString()] = ((r['c'] as num?) ?? 0).toInt();
    }
    return out;
  }

  Future<List<Map<String, dynamic>>> listAttachments(int entryId) async {
    final db = await _db;
    return await db.query('external_attachments', where: 'entry_id = ?', whereArgs: [entryId], orderBy: 'id ASC');
  }

  Future<void> saveSyncState({
    required String source,
    String sourceAccountId = 'default',
    String targetId = 'all',
    int? lastCursorMs,
    String? lastCursor,
    String? lastError,
    int? totalSynced,
    bool success = false,
  }) async {
    final db = await _db;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert(
      'external_sync_state',
      {
        'source': source,
        'source_account_id': sourceAccountId,
        'target_id': targetId,
        'last_sync_at_ms': lastCursorMs ?? now,
        'last_success_at_ms': success ? now : null,
        'last_cursor': lastCursor,
        'last_error': lastError,
        'total_synced': totalSynced ?? 0,
        'created_at_ms': now,
        'updated_at_ms': now,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, dynamic>?> getSyncState(String source, {String sourceAccountId = 'default', String targetId = 'all'}) async {
    final db = await _db;
    final rows = await db.query(
      'external_sync_state',
      where: 'source = ? AND source_account_id = ? AND target_id = ?',
      whereArgs: [source, sourceAccountId, targetId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Map<String, dynamic>.from(rows.first);
  }

  Future<void> logApi({
    required String source,
    required String endpoint,
    String method = 'GET',
    Map<String, dynamic>? requestParams,
    String? responseBody,
    int? statusCode,
    String? errorMessage,
  }) async {
    final db = await _db;
    await db.insert('external_api_logs', {
      'source': source,
      'endpoint': endpoint,
      'method': method,
      'request_params': requestParams == null ? null : jsonEncode(requestParams),
      'response_body': _clip(responseBody),
      'status_code': statusCode,
      'error_message': errorMessage,
      'created_at_ms': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, dynamic>>> latestApiLogs({int limit = 100}) async {
    final db = await _db;
    return await db.query('external_api_logs', orderBy: 'id DESC', limit: limit);
  }

  String? _clip(String? v) {
    if (v == null) return null;
    const max = 12000;
    if (v.length <= max) return v;
    return v.substring(0, max) + '...(truncated)';
  }
}
