/// External data sync constants.
///
/// Microsoft Client ID is safe to keep in the client app. Do not store any
/// client secret in the mobile app.
class ExternalDataConfig {
  static const microsoftClientId = 'dccf2bf4-0571-4abe-a303-bf07fb967147';

  /// This must match one of the Android redirect URIs configured in Microsoft
  /// Entra. The signature hash segment is intentionally configurable in the UI
  /// because debug/release/GitHub signing hashes may differ.
  static const defaultMicrosoftRedirectUri = 'msauth://com.example.quote_app/';

  static const microsoftAuthScope = 'offline_access User.Read Notes.Read';

  /// Weibo commercial API endpoint. The app does not store App Secret; for
  /// production OAuth exchange, use a backend. This endpoint is only used when
  /// the user supplies a valid access_token obtained through an approved app.
  static const weiboTimelineEndpoint = 'https://c.api.weibo.com/2/statuses/user_timeline/biz.json';
}
