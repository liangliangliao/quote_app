import 'dart:convert';

import 'package:http/http.dart' as http;

import 'external_data_config.dart';
import 'external_data_dao.dart';

class WeiboSyncProgress {
  WeiboSyncProgress({required this.message, this.synced = 0});
  final String message;
  final int synced;
}

class WeiboSyncResult {
  WeiboSyncResult({required this.statuses});
  final int statuses;
}

/// Sina Weibo sync client.
///
/// This implementation intentionally does not embed App Secret. It syncs when
/// the user supplies a valid access_token for an app that has the commercial
/// statuses/user_timeline/biz permission. Production OAuth should be completed
/// through a backend and then persisted with [saveAccessToken].
class WeiboClient {
  WeiboClient({ExternalDataDao? dao}) : _dao = dao ?? ExternalDataDao();
  final ExternalDataDao _dao;
  static const _source = 'weibo';

  Future<void> saveAccessToken(String token) async {
    final t = token.trim();
    if (t.isEmpty) throw Exception('微博 access_token 不能为空');
    await _dao.saveAccount(source: _source, accountId: 'default', displayName: '新浪微博', accessToken: t);
  }

  Future<bool> isConfigured() async {
    final acc = await _dao.getAccount(_source);
    return (acc?['access_token'] ?? '').toString().trim().isNotEmpty;
  }

  Future<void> disconnect() => _dao.deleteAccount(_source);

  Future<WeiboSyncResult> syncTimeline({void Function(WeiboSyncProgress progress)? onProgress, int maxPages = 200}) async {
    final acc = await _dao.getAccount(_source);
    final token = (acc?['access_token'] ?? '').toString().trim();
    if (token.isEmpty) throw Exception('请先填写微博 access_token，且该 token 所属应用必须已开通 statuses/user_timeline/biz 权限');

    var total = 0;
    for (var page = 1; page <= maxPages; page++) {
      onProgress?.call(WeiboSyncProgress(message: '正在同步微博第 $page 页...', synced: total));
      final uri = Uri.parse(ExternalDataConfig.weiboTimelineEndpoint).replace(queryParameters: {
        'access_token': token,
        'count': '25',
        'page': '$page',
      });
      final resp = await http.get(uri, headers: {'Accept': 'application/json'});
      await _dao.logApi(
        source: _source,
        endpoint: ExternalDataConfig.weiboTimelineEndpoint,
        requestParams: {'count': 25, 'page': page},
        statusCode: resp.statusCode,
        responseBody: resp.body,
      );
      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw Exception('微博接口请求失败：${resp.statusCode} ${resp.body}');
      }
      final json = jsonDecode(resp.body) as Map<String, dynamic>;
      final list = _extractStatuses(json);
      if (list.isEmpty) break;
      var newInPage = 0;
      for (final item in list) {
        final id = (item['idstr'] ?? item['id'] ?? '').toString();
        if (id.isEmpty) continue;
        final text = _stripHtml((item['text_raw'] ?? item['text'] ?? '').toString());
        final created = _parseWeiboDate((item['created_at'] ?? '').toString());
        final entryId = await _dao.upsertEntry(
          source: _source,
          sourceAccountId: 'default',
          sourceItemId: id,
          title: text.length > 30 ? text.substring(0, 30) : text,
          plainText: text,
          htmlContent: (item['text'] ?? '').toString(),
          originalUrl: _statusUrl(item),
          createdAtMs: created,
          updatedAtMs: created,
          raw: item,
        );
        await _savePicUrls(entryId, item);
        total++;
        newInPage++;
      }
      onProgress?.call(WeiboSyncProgress(message: '已同步微博 $total 条', synced: total));
      if (newInPage == 0 || list.length < 25) break;
    }
    await _dao.saveSyncState(source: _source, totalSynced: total, success: true, targetId: 'timeline');
    return WeiboSyncResult(statuses: total);
  }

  List<Map<String, dynamic>> _extractStatuses(Map<String, dynamic> json) {
    final candidates = [json['statuses'], json['data'], json['value']];
    for (final c in candidates) {
      if (c is List) return c.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (c is Map && c['statuses'] is List) {
        return (c['statuses'] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      }
    }
    return const [];
  }

  Future<void> _savePicUrls(int entryId, Map<String, dynamic> item) async {
    final urls = <String>{};
    void add(dynamic v) {
      final s = (v ?? '').toString().trim();
      if (s.startsWith('http')) urls.add(s);
    }
    add(item['thumbnail_pic']);
    add(item['bmiddle_pic']);
    add(item['original_pic']);
    final pics = item['pic_urls'];
    if (pics is List) {
      for (final p in pics) {
        if (p is Map) {
          add(p['thumbnail_pic']);
          add(p['bmiddle_pic']);
          add(p['original_pic']);
        } else {
          add(p);
        }
      }
    }
    var i = 0;
    for (final url in urls) {
      i++;
      await _dao.upsertAttachment(
        entryId: entryId,
        source: _source,
        sourceResourceId: 'pic_$i',
        fileName: 'weibo_pic_$i',
        remoteUrl: url,
      );
    }
  }

  String _stripHtml(String s) {
    return s
        .replaceAll(RegExp(r'<[^>]+>'), '')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .trim();
  }

  int? _parseWeiboDate(String s) {
    if (s.trim().isEmpty) return null;
    final parsed = DateTime.tryParse(s);
    if (parsed != null) return parsed.millisecondsSinceEpoch;
    // Example: Tue May 31 17:46:55 +0800 2011
    try {
      final parts = s.split(RegExp(r'\s+'));
      if (parts.length >= 6) {
        final mon = const {
          'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
          'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12,
        }[parts[1]];
        final day = int.tryParse(parts[2]);
        final time = parts[3].split(':');
        final year = int.tryParse(parts[5]);
        if (mon != null && day != null && time.length == 3 && year != null) {
          return DateTime(year, mon, day, int.parse(time[0]), int.parse(time[1]), int.parse(time[2])).millisecondsSinceEpoch;
        }
      }
    } catch (_) {}
    return null;
  }

  String _statusUrl(Map<String, dynamic> item) {
    final user = item['user'];
    final uid = user is Map ? (user['idstr'] ?? user['id'] ?? '').toString() : '';
    final mid = (item['mid'] ?? item['idstr'] ?? '').toString();
    if (uid.isNotEmpty && mid.isNotEmpty) return 'https://weibo.com/$uid/$mid';
    return '';
  }
}
