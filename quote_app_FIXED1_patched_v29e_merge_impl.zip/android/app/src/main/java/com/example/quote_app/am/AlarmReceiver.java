package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String taskUid = intent.getStringExtra("task_uid");
        String runKey  = intent.getStringExtra("run_key");
        if (taskUid == null || taskUid.isEmpty() || runKey == null || runKey.isEmpty()) {
            Log.e("AlarmReceiver","missing task_uid/run_key → fallback");
            com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native fallback");
            Notifier.fallback(context); return;
        }

        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                String dbPath = DbPaths.quotesDbPath(context);
                SqliteReader.Payload p = SqliteReader.queryExact(dbPath, taskUid, runKey);
                if (p == null) {
                    // try a small window: runKey +/- 10 minutes
                    java.util.AbstractMap.SimpleEntry<String,String> w = 
                        new java.util.AbstractMap.SimpleEntry<>(runKey, runKey);
                    try {
                        kotlin.Pair<String,String> pair = RunKey.INSTANCE.windowBefore(runKey, 10);
                        w = new java.util.AbstractMap.SimpleEntry<>(pair.getFirst(), pair.getSecond());
                    } catch (Throwable ignore) {}
                    p = SqliteReader.queryNear(dbPath, taskUid, w.getKey(), w.getValue());
                }
                if (p != null) {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] notify with payload");
                    Notifier.notify(context, p);
                } else {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native fallback");
                    Notifier.fallback(context);
                }
            } catch (Throwable t) {
                Log.e("AlarmReceiver","read db failed: " + t.getMessage(), t);
                com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] exception: "+t.getMessage());
                Notifier.fallback(context);
            } finally {
                pending.finish();
            }
        }).start();
    }
}
