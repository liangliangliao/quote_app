package com.example.quote_app.compat;

import android.content.Context;

public final class DartParity {
    private DartParity() {}

    public static int alarmId(String uid, String runKey) {
        String k = (uid == null ? "" : uid) + "#" + (runKey == null ? "" : runKey);
        int h = k.hashCode();
        return h & 0x7fffffff;
    }
}
