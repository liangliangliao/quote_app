package com.example.quote_app.wm;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

import com.example.quote_app.IdCard;
import com.example.quote_app.compat.DartParity;
import com.example.quote_app.data.DbRepository;

public final class WmScheduler {
    private WmScheduler() {}

    private static String uniqueName(String idCard) {
        String src = IdCard.sourceOf(idCard);
        String uid = IdCard.uidOf(idCard);
        String runKey = IdCard.runKeyOf(idCard);
        int id = DartParity.alarmId(uid, runKey);
        return "wm_" + src + "_" + id + "_" + (runKey == null ? "" : runKey);
    }

    public static void scheduleSingle(Context ctx, long triggerAt, String uid, String runKey, String idCard, boolean main) {
        Data in = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("id_card", idCard)
                .putString("job", "wm_run")
                .putString("chan", IdCard.sourceOf(idCard))
                .putInt("attempt", 0)
                .build();
        OneTimeWorkRequest.Builder b = new OneTimeWorkRequest.Builder(main ? NormalWorker.class : FallbackWorker.class)
                .setInputData(in)
                .setInitialDelay(Math.max(0, triggerAt - System.currentTimeMillis()), TimeUnit.MILLISECONDS);
        OneTimeWorkRequest req = b.build();

        String un = uniqueName(idCard);
        WorkManager wm = WorkManager.getInstance(ctx.getApplicationContext());
        DbRepository.log(ctx, uid, "【原生】WM 注册（" + IdCard.sourceOf(idCard) + "） 身份证=" + idCard + " ts=" + triggerAt);
        wm.enqueueUniqueWork(un, ExistingWorkPolicy.REPLACE, req);
    }

    public static void cancelByIdCard(Context ctx, String idCard) {
        String un = uniqueName(idCard);
        WorkManager.getInstance(ctx.getApplicationContext()).cancelUniqueWork(un);
        DbRepository.log(ctx, IdCard.uidOf(idCard), "【原生】WM 取消（" + IdCard.sourceOf(idCard) + "） 身份证=" + idCard);
    }

    public static void cancelAll(Context ctx) {
        WorkManager.getInstance(ctx.getApplicationContext()).cancelAllWork();
    }
}
