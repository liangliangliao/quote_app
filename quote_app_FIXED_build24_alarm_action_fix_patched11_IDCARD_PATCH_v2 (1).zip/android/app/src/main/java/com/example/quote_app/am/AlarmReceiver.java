package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.example.quote_app.IdCard;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;
import com.example.quote_app.wm.WmScheduler;

import org.json.JSONObject;

/** AM 主通道接收器（Java 版） */
public final class AlarmReceiver extends BroadcastReceiver {

    @Override public void onReceive(Context context, Intent intent) {
        String idCard = intent != null ? intent.getStringExtra("id_card") : "";
        String payload = intent != null ? intent.getStringExtra("payload") : "{}";
        String uid = null;
        String runKey = null;
        try {
            JSONObject obj = new JSONObject(payload == null ? "{}" : payload);
            uid = obj.optString("uid", null);
            runKey = obj.optString("runKey", null);
        } catch (Throwable ignore) {}

        if (TextUtils.isEmpty(uid)) uid = IdCard.uidOf(idCard);
        if (TextUtils.isEmpty(runKey)) runKey = IdCard.runKeyOf(idCard);

        DbRepository.log(context, uid, "【原生】AM 触发 身份证="+idCard+" runKey="+runKey);

        boolean ok = false;
        try {
            ok = Biz.run(context.getApplicationContext(), uid);
        } catch (Throwable e) {
            DbRepository.log(context, uid, "【原生】AM 业务异常: " + e.getMessage());
        }

        if (ok) {
            // a.1 成功：先取消兜底，再取消当前，最后续排下一次
            try {
                String fbCard = IdCard.build("fallback-wm", runKey == null ? "" : runKey, uid == null ? "" : uid);
                WmScheduler.cancelByIdCard(context, fbCard);
            } catch (Throwable ignore) {}
            try { NativeSchedulerK.cancelByIdCard(context, idCard); } catch (Throwable ignore) {}
            long next = NextTriggerCalculator.compute(context, uid);
            if (next > 0) {
                NativeSchedulerK.schedulePair(context, uid, runKey == null ? "" : runKey, next);
            }
        } else {
            // b.1 失败：取消当前并安排下一次
            try { NativeSchedulerK.cancelByIdCard(context, idCard); } catch (Throwable ignore) {}
            long next = NextTriggerCalculator.compute(context, uid);
            if (next > 0) {
                NativeSchedulerK.schedulePair(context, uid, runKey == null ? "" : runKey, next);
            }
        }
    }
}
