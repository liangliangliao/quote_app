package com.example.quote_app;

import android.text.TextUtils;

/**
 * 统一唯一标识（身份证）工具：
 * 格式：src=<来源>_runkey=<到点时间yyyy-MM-dd HH:mm:ss或其他字符串>_uid=<任务唯一ID>
 * 来源：am / main-wm / fallback-wm / selfck-wm
 */
public final class IdCard {
    private IdCard() {}

    public static String build(String src, String runKey, String uid) {
        String s = safe(src);
        String rk = safe(runKey);
        String u = safe(uid);
        return "src=" + s + "_runkey=" + rk + "_uid=" + u;
    }

    public static String sourceOf(String idCard) {
        if (TextUtils.isEmpty(idCard)) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("src=([^_]+)").matcher(idCard);
        return m.find() ? m.group(1) : "";
    }

    public static String runKeyOf(String idCard) {
        if (TextUtils.isEmpty(idCard)) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("runkey=([^_]+)").matcher(idCard);
        return m.find() ? m.group(1) : "";
    }

    public static String uidOf(String idCard) {
        if (TextUtils.isEmpty(idCard)) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("uid=([A-Za-z0-9_\\-:.]+)$").matcher(idCard);
        return m.find() ? m.group(1) : "";
    }

    public static boolean isAm(String idCard) { return "am".equals(sourceOf(idCard)); }
    public static boolean isMainWm(String idCard) { return "main-wm".equals(sourceOf(idCard)); }
    public static boolean isFallbackWm(String idCard) { return "fallback-wm".equals(sourceOf(idCard)); }
    public static boolean isSelfCheck(String idCard) { return "selfck-wm".equals(sourceOf(idCard)); }

    private static String safe(String v) { return v == null ? "" : v; }
}
