package com.example.quote_app.wm;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.quote_app.IdCard;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

public final class NormalWorker extends Worker {
    public NormalWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        String uid = getInputData().getString("uid");
        String runKey = getInputData().getString("runKey");
        String idCard = getInputData().getString("id_card");
        String chan = "main-wm";
        if (idCard != null && !idCard.isEmpty()) chan = IdCard.sourceOf(idCard);

        try {
            DbRepository.log(ctx, uid, "【原生】WM 主通道触发 身份证="+idCard);
            boolean ok = Biz.run(ctx, uid);
            if (ok) {
                // a.1 成功：先取消兜底，再取消当前，最后续排下一次
                String fbCard = IdCard.build("fallback-wm", runKey == null ? "" : runKey, uid == null ? "" : uid);
                try { WmScheduler.cancelByIdCard(ctx, fbCard); } catch (Throwable ignore) {}
                try { WmScheduler.cancelByIdCard(ctx, idCard); } catch (Throwable ignore) {}
                long next = NextTriggerCalculator.compute(ctx, uid);
                if (next > 0) {
                    com.example.quote_app.NativeSchedulerK.schedulePair(ctx, uid, runKey == null ? "" : runKey, next);
                }
                return ListenableWorker.Result.success();
            } else {
                // b.1 失败：取消当前并安排下一次
                try { WmScheduler.cancelByIdCard(ctx, idCard); } catch (Throwable ignore) {}
                long next = NextTriggerCalculator.compute(ctx, uid);
                if (next > 0) {
                    com.example.quote_app.NativeSchedulerK.schedulePair(ctx, uid, runKey == null ? "" : runKey, next);
                }
                return ListenableWorker.Result.success();
            }
        } catch (Throwable e) {
            DbRepository.log(ctx, uid, "【原生】WM 主通道异常: " + e.getMessage());
            return ListenableWorker.Result.retry();
        }
    }
}
