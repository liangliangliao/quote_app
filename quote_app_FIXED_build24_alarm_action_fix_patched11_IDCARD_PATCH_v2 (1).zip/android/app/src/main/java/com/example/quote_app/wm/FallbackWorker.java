package com.example.quote_app.wm;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ListenableWorker;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.concurrent.TimeUnit;

import com.example.quote_app.IdCard;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

public final class FallbackWorker extends Worker {
    public FallbackWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        String uid = getInputData().getString("uid");
        String runKey = getInputData().getString("runKey");
        String idCard = getInputData().getString("id_card");
        int attempt = getInputData().getInt("attempt", 0);

        try {
            DbRepository.log(ctx, uid, "【原生】WM 兜底通道触发 身份证="+idCard+" attempt="+attempt);
            boolean ok = Biz.run(ctx, uid);
            if (ok) {
                // a.2 成功：仅取消当前兜底
                try { WmScheduler.cancelByIdCard(ctx, idCard); } catch (Throwable ignore) {}
                return ListenableWorker.Result.success();
            } else {
                // b.2 失败：取消当前兜底，<=2 次重试；否则停止
                try { WmScheduler.cancelByIdCard(ctx, idCard); } catch (Throwable ignore) {}
                if (attempt < 2) {
                    Data in2 = new Data.Builder()
                            .putString("uid", uid)
                            .putString("runKey", runKey)
                            .putString("id_card", idCard)
                            .putString("job", "wm_run")
                            .putString("chan", "fallback-wm")
                            .putInt("attempt", attempt + 1)
                            .build();
                    OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(FallbackWorker.class)
                            .setInitialDelay(0, TimeUnit.MILLISECONDS)
                            .setInputData(in2)
                            .addTag("wm_fallback_retry")
                            .build();
                    WorkManager.getInstance(ctx).enqueue(req);
                    DbRepository.log(ctx, uid, "【原生】WM 兜底重试已提交 attempt="+(attempt+1));
                } else {
                    DbRepository.log(ctx, uid, "【原生】WM 兜底重试次数>2，停止");
                }
                return ListenableWorker.Result.success();
            }
        } catch (Throwable e) {
            DbRepository.log(ctx, uid, "【原生】WM 兜底通道异常: " + e.getMessage());
            return ListenableWorker.Result.retry();
        }
    }
}
