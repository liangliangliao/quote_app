package com.example.quote_app.biz;

import android.content.Context;
import android.text.TextUtils;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.data.DbRepository.Task;

public final class Biz {
    private Biz() {}

    /** 主入口：根据任务类型执行并发送通知；返回是否已处理 */
    public static boolean run(Context ctx, String uid) {
        if (TextUtils.isEmpty(uid)) return false;
        Task t = null;
        try { t = DbRepository.getTaskByUid(ctx, uid); } catch (Throwable ignore) {}
        if (t == null) {
            // 回退：仅通过 uid 发送一条通知
            try {
                NotifyHelper.send(ctx.getApplicationContext(), uid.hashCode(), "提醒", "到点提醒（uid="+uid+"）", null);
                DbRepository.log(ctx, uid, "【原生】找不到任务，已按默认模板发送");
                return true;
            } catch (Throwable e) {
                DbRepository.log(ctx, uid, "【原生】发送失败: " + e.getMessage());
                return false;
            }
        }
        if (!t.enabled) {
            DbRepository.log(ctx, uid, "【原生】任务已禁用，跳过");
            return true;
        }
        String content = !TextUtils.isEmpty(t.content) ? t.content : "到点提醒";
        String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
        int id = t.uid != null ? t.uid.hashCode() : 10001;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, t.avatarPath);
            DbRepository.log(ctx, t.uid, "【原生】发送成功");
            DbRepository.markLatestSuccess(ctx, t.uid);
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "【原生】发送失败: " + e.getMessage());
            return false;
        }
    }
}
