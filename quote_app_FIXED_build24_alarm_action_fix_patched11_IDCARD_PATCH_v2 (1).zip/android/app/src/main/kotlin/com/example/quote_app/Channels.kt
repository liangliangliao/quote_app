package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject

object Channels {
  private const val CH = "native.scheduler"

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
          "canScheduleExact" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestScheduleExact" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))

          // 统一对外：注册一对（主+兜底）任务，由原生决定 AM 或 WM 路径
          "schedulePair" -> {
            val args = call.arguments as? Map<*, *>
            val uid = args?.get("uid")?.toString() ?: ""
            val runKey = args?.get("runKey")?.toString() ?: ""
            val whenEpoch = (args?.get("whenEpoch") as? Number)?.toLong() ?: 0L
            val ok = NativeSchedulerK.schedulePair(appCtx, uid, runKey, whenEpoch)
            result.success(ok)
          }

          // 取消（身份证）
          "cancelByIdCard" -> {
            val idCard = (call.arguments as? Map<*, *>)?.get("idCard")?.toString() ?: ""
            val ok = NativeSchedulerK.cancelByIdCard(appCtx, idCard)
            result.success(ok)
          }

          // 仅供调试：取消全部 WM（不建议业务调用）
          "debugCancelAllWm" -> {
            val ok = NativeSchedulerK.cancelAllWm(appCtx)
            result.success(ok)
          }

          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
  }
}
