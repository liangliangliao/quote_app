package com.example.quote_app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val DEFAULT_CHANNEL_NAME = "提醒"

  @JvmStatic
  fun send(ctx: Context, id: Int, title: String, content: String, avatarPath: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val ch = NotificationChannel(DEFAULT_CHANNEL_ID, DEFAULT_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT)
      nm.createNotificationChannel(ch)
    }
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        // 没有通知权限，直接返回但记日志
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】无通知权限，已跳过通知发送") } catch (_: Throwable) {}
        return
      }
    }

    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(content)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)

    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }

    nm.notify(id, builder.build())
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】通知已发送 id="+id+" chan="+DEFAULT_CHANNEL_ID) } catch (_: Throwable) {}
  }
}
