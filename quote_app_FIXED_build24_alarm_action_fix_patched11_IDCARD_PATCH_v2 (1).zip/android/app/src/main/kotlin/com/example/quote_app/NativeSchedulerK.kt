package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*
import com.example.quote_app.wm.WmScheduler
import com.example.quote_app.data.DbRepo
import com.example.quote_app.schedule.NextTriggerCalculator
import java.util.concurrent.TimeUnit

object NativeSchedulerK {

  private fun pendingIntentFor(ctx: Context, id: Int, idCard: String, payload: String?): PendingIntent {
    val intent = Intent(ctx, com.example.quote_app.am.AlarmReceiver::class.java).apply {
      action = "com.example.quote_app.ALARM"
      putExtra("id", id)
      putExtra("payload", payload ?: "{}")
      putExtra("id_card", idCard)
    }
    val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    return PendingIntent.getBroadcast(ctx, id, intent, flags)
  }

  private fun alarmIdFrom(uid: String, runKey: String): Int {
    val v = (uid + "#" + runKey).hashCode()
    return v and 0x7fffffff.toInt()
  }

  /** 统一注册：根据精准闹权限选择 AM 路径或 WM 路径；同时注册主通道与兜底通道 */
  @JvmStatic fun schedulePair(ctx: Context, uid: String, runKey: String, whenEpoch: Long): Boolean {
    if (uid.isEmpty()) return false
    return try {
      val hasExact = ExactAlarmHelper.hasExactAlarmPermission(ctx)
      val id = alarmIdFrom(uid, runKey)
      if (hasExact) {
        // 主：AM；兜底：WM(+2min)
        val mainCard = IdCard.build("am", runKey, uid)
        val fbCard = IdCard.build("fallback-wm", runKey, uid)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntentFor(ctx, id, mainCard, """{"uid":"$uid","runKey":"$runKey"}""")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenEpoch, pi)
        } else {
          am.setExact(AlarmManager.RTC_WAKEUP, whenEpoch, pi)
        }
        try { DbRepo.log(ctx, uid, "【原生】AM 主通道注册（身份证=$mainCard） at=$whenEpoch") } catch (_: Throwable) {}
        // 兜底 WM
        WmScheduler.scheduleSingle(ctx, whenEpoch + 2 * 60 * 1000L, uid, runKey, fbCard, /*main*/ false)
        true
      } else {
        // 主：WM；兜底：WM(+2min)
        val mainCard = IdCard.build("main-wm", runKey, uid)
        val fbCard = IdCard.build("fallback-wm", runKey, uid)
        WmScheduler.scheduleSingle(ctx, whenEpoch, uid, runKey, mainCard, /*main*/ true)
        WmScheduler.scheduleSingle(ctx, whenEpoch + 2 * 60 * 1000L, uid, runKey, fbCard, /*main*/ false)
        true
      }
    } catch (_: Throwable) { false }
  }

  /** 通过身份证取消对应任务（自动识别来源） */
  @JvmStatic fun cancelByIdCard(ctx: Context, idCard: String): Boolean {
    return try {
      val src = IdCard.sourceOf(idCard)
      val uid = IdCard.uidOf(idCard)
      val runKey = IdCard.runKeyOf(idCard)
      if (src == "am") {
        val id = alarmIdFrom(uid, runKey)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntentFor(ctx, id, idCard, null)
        am.cancel(pi)
        try { DbRepo.log(ctx, uid, "【原生】AM 取消（身份证=$idCard）") } catch (_: Throwable) {}
        true
      } else {
        WmScheduler.cancelByIdCard(ctx, idCard)
        true
      }
    } catch (_: Throwable) { false }
  }

  @JvmStatic fun cancelAllWm(ctx: Context): Boolean {
    return try { WmScheduler.cancelAll(ctx); true } catch (_: Throwable) { false }
  }

  /** 自检 WM（保持原语义） */
  @JvmStatic fun scheduleSelfCheck(ctx: Context, minutes: Int): Boolean {
    val data = Data.Builder().putString("job","wm_selfcheck").build()
    val req = OneTimeWorkRequestBuilder<com.example.quote_app.wm.NormalWorker>()
      .setInitialDelay(minutes.toLong(), TimeUnit.MINUTES)
      .setInputData(data)
      .addTag("wm_selfcheck")
      .build()
    return try {
      WorkManager.getInstance(ctx).enqueue(req)
      try { DbRepo.log(ctx, null, "【原生】WM 自检计划 +${minutes}min") } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }
}
