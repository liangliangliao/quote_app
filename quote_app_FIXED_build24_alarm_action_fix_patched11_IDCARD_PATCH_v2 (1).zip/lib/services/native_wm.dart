import 'package:quote_app/platform/native_scheduler.dart';

class NativeWm {
  /// 按身份证取消（兼容旧名）
  static Future<bool> cancelByIdCard(String idCard) => NativeScheduler.cancelByIdCard(idCard);
}
