import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:quote_app/utils/debug_logger.dart';

/// 统一原生调度桥接（MethodChannel：native.scheduler）
class NativeScheduler {
  static const _ch = MethodChannel('native.scheduler');

  /// 统一身份证格式：src=<来源>_runkey=<到点时间yyyy-MM-dd HH:mm:ss或其他字符串>_uid=<唯一任务ID>
  static String buildIdCard({required String src, required String runKey, required String uid}) {
    return 'src=$src_runkey=$runKey_uid=$uid';
  }

  /// 注册一对任务（主+兜底）；原生根据精准闹权限选择 AM 或 WM 路径。
  static Future<bool> schedulePair({
    required String uid,
    required String runKey,
    required DateTime when,
  }) async {
    try {
      final ok = await _ch.invokeMethod<bool>('schedulePair', {
        'uid': uid,
        'runKey': runKey,
        'whenEpoch': when.millisecondsSinceEpoch,
      });
      return ok ?? false;
    } catch (e) {
      await DLog.e('SCH', 'schedulePair 调用失败: $e');
      return false;
    }
  }

  /// 取消（按身份证）
  static Future<bool> cancelByIdCard(String idCard) async {
    try {
      final ok = await _ch.invokeMethod<bool>('cancelByIdCard', {
        'idCard': idCard,
      });
      return ok ?? false;
    } catch (e) {
      await DLog.e('SCH', 'cancelByIdCard 调用失败: $e');
      return false;
    }
  }

  static Future<bool> canScheduleExact() async {
    try {
      final ok = await _ch.invokeMethod<bool>('canScheduleExact');
      return ok ?? false;
    } catch (_) { return false; }
  }

  static Future<bool> requestScheduleExact() async {
    try {
      final ok = await _ch.invokeMethod<bool>('requestScheduleExact');
      return ok ?? false;
    } catch (_) { return false; }
  }
}
