package com.example.quote_app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Reconstructed minimally-invasive repository.
 * Keeps the same class name, package, and public API as before.
 * Only uses Android SDK + SQLite and DbInspector helper.
 */
public final class DbRepository {

    private static final String TAG = "quote_app/native";

    private DbRepository() {}

    /** Simple struct objects returned to the Dart side via platform channels */
    public static final class Task {
        public String uid;
        public String title;
        public String content;
        public long triggerAtMillis;
        public boolean enabled = true;
        public String type;
        public String prompt;
        public String avatarPath;
    }

    public static final class Config {
        public String endpoint;
        public String apiKey;
        public String model;
    }

    private static void logAndRethrow(String where, Throwable e) {
        Log.e(TAG, where + ": " + e.getMessage(), e);
        if (e instanceof RuntimeException) throw (RuntimeException) e;
        throw new RuntimeException(e);
    }

    private static SQLiteDatabase open(String path) {
        try {
            SQLiteDatabase db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE);
            try {
                db.execSQL("PRAGMA busy_timeout=4000");
                db.execSQL("PRAGMA synchronous=NORMAL");
            } catch (Throwable ignore) {}
            return db;
        } catch (Throwable e) {
            Log.e(TAG, "open(" + path + "): " + e.getMessage(), e);
            return null;
        }
    }

    private static SQLiteDatabase openByCtx(Context ctx) {
        try {
            String path = DbInspector.resolveDbPath(ctx);
            if (path == null) return null;
            return open(path);
        } catch (Throwable e) {
            Log.e(TAG, "openByCtx: " + e.getMessage(), e);
            return null;
        }
    }

    /** Write a line into logs(task_uid,message,created_at) if table exists. Best effort. */
    public static void log(Context ctx, String taskUid, String message) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return;
        try {
            ContentValues cv = new ContentValues();
            cv.put("task_uid", taskUid);
            cv.put("message", message);
            cv.put("created_at", System.currentTimeMillis());
            try { db.insert("logs", null, cv); } catch (Throwable ignore) {}
        } catch (Throwable ignore) {
        } finally {
            try { db.close(); } catch (Throwable ignore) {}
        }
    }

    /** Load config from key/value table "config" with defaults. */
    public static Config loadConfig(Context ctx) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return null;
        try {
            Cursor c = db.rawQuery("SELECT key, value FROM config", null);
            try {
                Config cfg = new Config();
                if (c.moveToFirst()) {
                    do {
                        String k = c.getString(0);
                        String v = c.getString(1);
                        if ("endpoint".equals(k)) cfg.endpoint = v;
                        else if ("api_key".equals(k)) cfg.apiKey = v;
                        else if ("model".equals(k)) cfg.model = v;
                    } while (c.moveToNext());
                }
                if (cfg.endpoint == null) cfg.endpoint = "https://api.openai.com/v1";
                if (cfg.model == null) cfg.model = "gpt-5";
                if (cfg.apiKey == null) cfg.apiKey = "";
                return cfg;
            } finally { c.close(); }
        } catch (Throwable e) {
            logAndRethrow("loadConfig", e);
            return null; // unreachable
        } finally { db.close(); }
    }

    /** Return up to {limit} quote contents for a task. */
    public static List<String> listQuoteTextsForTask(Context ctx, String uid, int limit) {
        List<String> out = new ArrayList<>();
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return out;
        try {
            Cursor c = db.rawQuery(
                    "SELECT content FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT ?",
                    new String[]{ uid, String.valueOf(Math.max(1, limit)) }
            );
            try {
                while (c.moveToNext()) out.add(c.getString(0));
            } finally { c.close(); }
        } catch (Throwable e) {
            logAndRethrow("listQuoteTextsForTask", e);
        } finally { db.close(); }
        return out;
    }

    /** Insert a quote row and return rowId or -1. */
    public static long insertQuote(Context ctx, String uid, String content, String extraJson) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return -1L;
        try {
            ContentValues cv = new ContentValues();
            cv.put("task_uid", uid);
            cv.put("content", content);
            cv.put("extra_json", extraJson);
            cv.put("created_at", System.currentTimeMillis());
            cv.put("notified", 0);
            return db.insert("quotes", null, cv);
        } catch (Throwable e) {
            logAndRethrow("insertQuote", e);
            return -1L;
        } finally { db.close(); }
    }

    public static void markQuoteNotified(Context ctx, long id) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return;
        try {
            db.execSQL("UPDATE quotes SET notified=1 WHERE id=?", new Object[]{ id });
        } catch (Throwable e) {
            logAndRethrow("markQuoteNotified", e);
        } finally { db.close(); }
    }

    public static String getManualQuote(Context ctx, String uid) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return null;
        try {
            Cursor c = db.rawQuery(
                    "SELECT content FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT 1",
                    new String[]{ uid }
            );
            try { if (c.moveToFirst()) return c.getString(0); }
            finally { c.close(); }
        } catch (Throwable e) {
            logAndRethrow("getManualQuote", e);
        } finally { db.close(); }
        return null;
    }

    public static String getCarouselNextQuote(Context ctx, String uid) {
        // For now reuse manual strategy; can be enhanced to round-robin later.
        return getManualQuote(ctx, uid);
    }

    public static Task getTaskFull(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        SQLiteDatabase db = open(cc.dbPath);
        if (db == null) return null;
        try {
            String sql = "SELECT "
                    + cc.taskColMap.get("uid") + ","
                    + cc.taskColMap.get("title") + ","
                    + cc.taskColMap.get("content") + ","
                    + cc.taskColMap.get("trigger_at") + ","
                    + cc.taskColMap.get("enabled") + ","
                    + cc.taskColMap.get("type") + ","
                    + cc.taskColMap.get("prompt") + ","
                    + cc.taskColMap.get("avatar")
                    + " FROM " + cc.tasksSource + " WHERE " + cc.taskColMap.get("uid") + "=? LIMIT 1";
            Cursor c = db.rawQuery(sql, new String[]{ uid });
            try {
                if (c.moveToFirst()) {
                    Task t = new Task();
                    int col = 0;
                    t.uid = c.getString(col++);
                    t.title = c.getString(col++);
                    t.content = c.getString(col++);
                    t.triggerAtMillis = c.getLong(col++);
                    t.enabled = c.getInt(col++) != 0;
                    t.type = c.getString(col++);
                    t.prompt = c.getString(col++);
                    t.avatarPath = c.getString(col++);
                    return t;
                }
            } finally { c.close(); }
        } catch (Throwable e) {
            logAndRethrow("getTaskFull", e);
        } finally { db.close(); }
        return null;
    }

    public static List<Task> listFutureTasks(Context ctx) {
        List<Task> out = new ArrayList<>();
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        SQLiteDatabase db = open(cc.dbPath);
        if (db == null) return out;
        try {
            long now = System.currentTimeMillis();
            String sql = "SELECT "
                    + cc.taskColMap.get("uid") + ","
                    + cc.taskColMap.get("title") + ","
                    + cc.taskColMap.get("content") + ","
                    + cc.taskColMap.get("trigger_at")
                    + " FROM " + cc.tasksSource + " WHERE " + cc.taskColMap.get("trigger_at") + ">?";
            Cursor c = db.rawQuery(sql, new String[]{ String.valueOf(now) });
            try {
                while (c.moveToNext()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    out.add(t);
                }
            } finally { c.close(); }
        } catch (Throwable e) {
            logAndRethrow("listFutureTasks", e);
        } finally { db.close(); }
        return out;
    }
}
