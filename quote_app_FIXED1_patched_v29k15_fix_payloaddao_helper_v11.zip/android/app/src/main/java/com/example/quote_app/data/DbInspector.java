package com.example.quote_app.data;

import android.content.Context;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class DbInspector {
    public static String resolveDbPath(Context ctx) {
        try {
            java.io.File primary = ctx.getDatabasePath("quotes.db");
            if (primary != null && primary.exists()) return primary.getAbsolutePath();
            java.io.File appFlutterDir = new java.io.File(ctx.getFilesDir(), "../app_flutter");
            java.io.File appFlutterDb = new java.io.File(appFlutterDir, "quotes.db");
            if (appFlutterDb.exists()) return appFlutterDb.getAbsolutePath();
            java.io.File alt = new java.io.File(ctx.getFilesDir(), "../databases/quotes.db");
            if (alt.exists()) return alt.getAbsolutePath();
            return primary.getAbsolutePath();
        } catch (Throwable ignore) { return ctx.getDatabasePath("quotes.db").getAbsolutePath(); }
    }

    private DbInspector() {}

    public static final class Contract {
        public String dbPath;
        public String tasksSource;
        public Map<String,String> taskColMap = new HashMap<>();
    }

    public static Contract loadOrLightScan(Context ctx) {
        Contract c = new Contract();
        c.dbPath = resolveDbPath(ctx);
        c.tasksSource = "tasks";
        c.taskColMap.put("uid", "uid");
        c.taskColMap.put("title", "title");
        c.taskColMap.put("content", "content");
        c.taskColMap.put("trigger_at", "trigger_at");
        c.taskColMap.put("enabled", "enabled");
        c.taskColMap.put("type", "type");
        c.taskColMap.put("prompt", "prompt");
        c.taskColMap.put("avatar", "avatar_path");
        return c;
    }
}
