import 'package:flutter/services.dart';

class NativeNotify {
  static const _ch = MethodChannel('com.example.quote_app/notify');

  static Future<bool> show({
    required int id,
    required String title,
    required String body,
    String? largeIconPath,
  }) async {
    try {
      final ok = await _ch.invokeMethod<bool>('notify', {
        'id': id,
        'title': title,
        'body': body,
        'largeIconPath': largeIconPath,
      });
      return ok ?? true;
    } on PlatformException {
      // Missing native side implementation or channel inactive
      return false;
    } on MissingPluginException {
      // Channel not registered (e.g., background isolate). Fallback to Dart path.

      // Fallback: let caller handle or keep old Dart path
      return false;
    }
  }
}