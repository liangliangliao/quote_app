class RunContext {
  static bool isFromWM = false;
  static void markFromWM() { isFromWM = true; }
  static bool isBackground = false;
}
