
import 'dart:io';
import 'package:flutter/material.dart';

class GlobalBackground extends StatefulWidget {
  final String? imagePath;
  final double opacity;
  const GlobalBackground({super.key, this.imagePath, this.opacity = 1});

  @override
  State<GlobalBackground> createState() => _GlobalBackgroundState();
}

class _GlobalBackgroundState extends State<GlobalBackground> {
  ImageProvider? _provider;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _prepare();
  }

  @override
  void didUpdateWidget(covariant GlobalBackground oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.imagePath != widget.imagePath) {
      _prepare();
    }
  }

  Future<void> _prepare() async {
    if (widget.imagePath != null && widget.imagePath!.isNotEmpty && File(widget.imagePath!).existsSync()) {
      final img = FileImage(File(widget.imagePath!));
      await precacheImage(img, context);
      setState(() => _provider = img);
    } else {
      setState(() => _provider = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    const base = Color(0xFFE6F5EA);
    return IgnorePointer(
      ignoring: true,
      child: RepaintBoundary(
        child: DecoratedBox(
          decoration: const BoxDecoration(color: base),
          child: _provider == null
              ? const SizedBox.expand()
              : Opacity(
                  opacity: widget.opacity.clamp(0, 1).toDouble(),
                  child: Image(
                    image: _provider!,
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                  ),
                ),
        ),
      ),
    );
  }
}
