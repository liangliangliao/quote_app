package com.example.quote_app

import android.content.BroadcastReceiver
import android.preference.PreferenceManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import kotlin.concurrent.thread
import android.os.Handler
import android.os.Looper
import com.example.quote_app.data.DbRepo

/**
 * 解锁广播入口：
 * 1) 优先检查配置表中的地点规则开关；若关闭，直接返回（不触发已有的解锁轻提醒链路）
 * 2) 若开启，立即启动前台服务 GeoForegroundService 执行定位与提醒（不进入 WorkManager）
 * 3) 所有关键步骤写中文日志
 */
class UnlockReceiver : BroadcastReceiver() {
  private val GEO_FG_STARTED_KEY = "geo_fg_started_pref"
  override fun onReceive(context: Context, intent: Intent?) {
    val appCtx = context.applicationContext
    // 日志：解锁事件触发，准备创建两个后台线程
    try {
      logWithTime(appCtx, "【解锁后台】解锁事件触发，创建地点提醒线程")
    } catch (_: Throwable) {}
    // 线程1：地点规则通知提醒
    kotlin.concurrent.thread(name = "unlock-geo-thread") {
      try {
        // 记录线程启动
        try { logWithTime(appCtx, "【解锁后台】地点提醒线程启动") } catch (_: Throwable) {}
        // 启动前台服务以获取位置并发送提醒。按照要求：先注册和启动前台服务，然后由服务内部处理开关和定位逻辑。
        try {
          val svc = Intent(appCtx, GeoForegroundService::class.java)
          try {
            if (Build.VERSION.SDK_INT >= 26) {
              appCtx.startForegroundService(svc)
            } else {
              appCtx.startService(svc)
            }
          } catch (t: Throwable) {
            // Android 12+ 在后台可能抛出 ForegroundServiceStartNotAllowedException，兜底启动透明 Activity 间接拉起
            try {
              logWithTime(appCtx, "【解锁后台】直接启动前台服务失败，将通过透明Activity兜底：" + (t.message ?: "unknown"))
            } catch (_: Throwable) {}
            try {
              val kick = Intent(appCtx, FgKickActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
              }
              appCtx.startActivity(kick)
            } catch (_: Throwable) {}
          }
          logWithTime(appCtx, "【解锁后台】已请求启动 GeoForegroundService 前台服务进行定位与提醒")
          // Toast 必须在主线程调用，提示用户正在进行地点提醒（可忽略异常）
          Handler(Looper.getMainLooper()).post {
            try { Toast.makeText(appCtx, "正在执行地点提醒...", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
          }
        } catch (t: Throwable) {
          // 如果服务启动异常，记录错误
          try { logWithTime(appCtx, "【解锁后台】启动 GeoForegroundService 失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
        }
        
// 等待前台服务真正启动（最多2秒）
try {
  val sp = PreferenceManager.getDefaultSharedPreferences(appCtx)
  val start = System.currentTimeMillis()
  while (System.currentTimeMillis() - start < 2000) {
    val ts = sp.getLong(GEO_FG_STARTED_KEY, 0L)
    if (ts > 0L) break
    try { Thread.sleep(50) } catch (_: Throwable) {}
  }
} catch (_: Throwable) {}
// 线程结束
标识（逻辑继续由前台服务处理），此处仅用于补充日志
        try { logWithTime(appCtx, "【解锁后台】地点提醒线程结束（已交由前台服务处理）") } catch (_: Throwable) {}
      } catch (t: Throwable) {
        // 捕获所有异常，避免线程崩溃
        try { logWithTime(appCtx, "【解锁后台】地点提醒线程异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      }
    }
    // 日志：准备创建解锁轻提醒线程
    try {
      logWithTime(appCtx, "【解锁后台】解锁事件触发，创建解锁轻提醒线程")
    } catch (_: Throwable) {}
    // 线程2：解锁轻提醒
    kotlin.concurrent.thread(name = "unlock-light-thread") {
      // —— 先检查开关状态：若关闭，记录并返回 ——
      try {
        var switchOn = false
        try {
          val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(appCtx)
          if (cc != null) {
            val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
            try {
              db.rawQuery("SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1", null).use { c ->
                if (c.moveToFirst()) {
                  val v = c.getString(0) ?: "0"
                  switchOn = ("1" == v || "true".equals(v, true))
                }
              }
            } finally { try { db.close() } catch (_: Throwable) {} }
          }
        } catch (_: Throwable) {}
        if (!switchOn) {
          try { logWithTime(appCtx, "【解锁后台】解锁轻提醒开关已关闭，跳过（回包：SKIP_SWITCH_OFF）") } catch (_: Throwable) {}
          return@thread
        }
      } catch (_: Throwable) {}
try {
        // 记录线程启动
        try { logWithTime(appCtx, "【解锁后台】解锁轻提醒线程启动") } catch (_: Throwable) {}
        // 调用现有触发逻辑，保持业务不变
        try {
          UnlockWorker.trigger(appCtx)
        } catch (e: Throwable) {
          try { logWithTime(appCtx, "【解锁后台】触发 UnlockWorker 失败：" + (e.message ?: "unknown")) } catch (_: Throwable) {}
        }
        
// 等待前台服务真正启动（最多2秒）
try {
  val sp = PreferenceManager.getDefaultSharedPreferences(appCtx)
  val start = System.currentTimeMillis()
  while (System.currentTimeMillis() - start < 2000) {
    val ts = sp.getLong(GEO_FG_STARTED_KEY, 0L)
    if (ts > 0L) break
    try { Thread.sleep(50) } catch (_: Throwable) {}
  }
} catch (_: Throwable) {}
// 线程结束

        try { logWithTime(appCtx, "【解锁后台】解锁轻提醒线程结束") } catch (_: Throwable) {}
      } catch (t: Throwable) {
        try { logWithTime(appCtx, "【解锁后台】解锁轻提醒线程异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      }
    }
  }

  /**
   * 写入包含时间戳的日志。
   */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
