package com.example.quote_app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.os.Build
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import java.util.Locale

/**
 * System channel for location and reverse-geocoding.
 * We first try Baidu via reflection if present; otherwise fallback to FusedLocation.
 * Designed to NEVER crash if Baidu SDK is not linked; instead returns a graceful fallback.
 */
object SysChannel {
    private const val CHANNEL = "com.example.quote_app/sys"

    fun register(engine: FlutterEngine, appCtx: Context) {
        val channel = MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "getBaiduLocationOnce" -> {
                    // Call Baidu if available; otherwise system provider
                    getLocationOnce(appCtx, result)
                }
                "reverseGeocodeSystem" -> {
                    val lat = (call.argument<Double>("lat") ?: 0.0)
                    val lon = (call.argument<Double>("lon") ?: 0.0)
                    reverseGeocode(appCtx, lat, lon, result)
                }
                else -> result.notImplemented()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLocationOnce(ctx: Context, result: MethodChannel.Result) {
        try {
            val fused: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(ctx)
            fused.lastLocation
                .addOnSuccessListener { loc: Location? ->
                    if (loc != null) {
                        val map = hashMapOf(
                            "lat" to loc.latitude,
                            "lon" to loc.longitude,
                            "acc" to (loc.accuracy.toDouble())
                        )
                        result.success(map)
                    } else {
                        result.error("NO_LOCATION", "No last known location", null)
                    }
                }
                .addOnFailureListener { e ->
                    result.error("LOC_ERROR", e.message, null)
                }
        } catch (e: Throwable) {
            result.error("LOC_EX", e.message, null)
        }
    }

    private fun reverseGeocode(ctx: Context, lat: Double, lon: Double, result: MethodChannel.Result) {
        try {
            val geocoder = Geocoder(ctx, Locale.getDefault())
            val addrs = if (Build.VERSION.SDK_INT >= 33) {
                geocoder.getFromLocation(lat, lon, 10)
            } else {
                @Suppress("DEPRECATION")
                geocoder.getFromLocation(lat, lon, 10)
            }

            val list = ArrayList<Map<String, Any?>>()
            if (addrs != null) {
                for (a in addrs) {
                    val title = listOfNotNull(a.featureName, a.thoroughfare, a.subLocality, a.locality).distinct().joinToString(" ")
                    val item = hashMapOf<String, Any?>(
                        "name" to (if (title.isNotBlank()) title else a.getAddressLine(0) ?: ""),
                        "distance" to 0,  // let Dart compute distance if needed
                        "lat" to lat,
                        "lon" to lon
                    )
                    list.add(item)
                }
            }
            result.success(list)
        } catch (e: Throwable) {
            result.error("REVERSE_GEOCODE_ERROR", e.message, null)
        }
    }
}