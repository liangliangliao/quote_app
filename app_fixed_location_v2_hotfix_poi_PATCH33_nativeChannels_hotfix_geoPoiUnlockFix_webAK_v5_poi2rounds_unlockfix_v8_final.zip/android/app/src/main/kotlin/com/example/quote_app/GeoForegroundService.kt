package com.example.quote_app

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import android.database.sqlite.SQLiteDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 解锁瞬间的一次性地点规则检查（前台服务，避免后台启动限制）。
 * - 读取 quotes.db 中 vision_triggers(type='geo', enabled=1)；
 * - 使用系统最近位置（优先 GPS，其次 Network）；
 * - 若当前位置与任一目标位置距离 < 100m，则发送通知；
 * - 结束后立即 stopSelf()。
 */
class GeoForegroundService : Service() {

    private val channelId = "geo_kick_v1"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            var ch = nm.getNotificationChannel(channelId)
            if (ch == null) {
                ch = NotificationChannel(channelId, "地点规则触发", NotificationManager.IMPORTANCE_LOW)
                nm.createNotificationChannel(ch)
            }
            val nb = Notification.Builder(this, channelId)
                .setContentTitle("正在检查地点规则")
                .setContentText("解锁后立即进行一次地点规则校验")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            startForeground(1099, nb.build())
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Thread {
            try {
                runCheckOnce()
            } catch (_: Throwable) {
            } finally {
                try { stopForeground(true) } catch (_: Throwable) {}
                try { stopSelf() } catch (_: Throwable) {}
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun runCheckOnce() {
        val ctx = applicationContext
        logWithTime(ctx, "【GeoKick】开始一次性地点规则检查")

        // 1) 拿系统最近位置
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var base: Location? = null
        try { base = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Throwable) {}
        if (base == null) try { base = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Throwable) {}
        if (base == null) {
            logWithTime(ctx, "【GeoKick】无法获得最近位置，放弃本次检查")
            return
        }
        logWithTime(ctx, "【GeoKick】最近位置 lat=${'$'}{base.latitude}, lon=${'$'}{base.longitude}")

        // 2) 打开数据库读取 geo 触发器
        val dbFile = ctx.getDatabasePath("quotes.db")
        if (!dbFile.exists()) {
            logWithTime(ctx, "【GeoKick】数据库不存在：${'$'}{dbFile.absolutePath}")
            return
        }
        val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val c = db.rawQuery("SELECT config, then_text FROM vision_triggers WHERE type='geo' AND enabled=1", null)
            while (c.moveToNext()) {
                val cfg = c.getString(0) ?: ""
                val thenText = c.getString(1) ?: ""
                try {
                    val o = JSONObject(cfg)
                    val lat = when {
                        o.has("lat") -> o.optDouble("lat")
                        o.has("latitude") -> o.optDouble("latitude")
                        o.has("target_lat") -> o.optDouble("target_lat")
                        else -> Double.NaN
                    }
                    val lon = when {
                        o.has("lng") -> o.optDouble("lng")
                        o.has("longitude") -> o.optDouble("longitude")
                        o.has("target_lng") -> o.optDouble("target_lng")
                        else -> Double.NaN
                    }
                    if (!lat.isNaN() && !lon.isNaN()) {
                        val dist = FloatArray(1)
                        Location.distanceBetween(base.latitude, base.longitude, lat, lon, dist)
                        logWithTime(ctx, "【GeoKick】对比目标(${ '$' }lat,${ '$' }lon) 距离=${ '$' }{dist[0]}")
                        if (dist[0] <= 100f) {
                            val body = if (thenText.isNotEmpty()) thenText else "你已到达目标附近，别忘了你的计划"
                            NotifyHelper.send(ctx, 2010, "地点提醒", body, null, "vision_focus", null)
                            logWithTime(ctx, "【GeoKick】已发送地点提醒")
                            // 发送一条即可；不需要重复提醒
                            break
                        }
                    }
                } catch (_: Throwable) {
                    // 略过解析失败的行
                }
            }
            c.close()
        } finally {
            try { db.close() } catch (_: Throwable) {}
        }
    }

    private fun logWithTime(ctx: Context, msg: String) {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
            val now = sdf.format(Date())
            com.example.quote_app.data.DbRepo.log(ctx, null, "[$now] $msg")
        } catch (_: Throwable) { }
    }
}