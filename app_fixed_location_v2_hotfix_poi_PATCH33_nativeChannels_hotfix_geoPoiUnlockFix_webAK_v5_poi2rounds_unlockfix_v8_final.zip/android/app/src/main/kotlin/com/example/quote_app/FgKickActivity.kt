package com.example.quote_app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * 透明 Activity：
 * - 由 UnlockReceiver 在解锁瞬间启动；
 * - 并发执行两件事：A) 地点规则检查；B) 解锁轻提醒（WorkManager）。
 * - 无论成功失败，都会在 finally 中调用 finish() 销毁自身，避免占用资源。
 */
class FgKickActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val appCtx = applicationContext
        logWithTime(appCtx, "【解锁前台Activity】已启动，准备并发执行两路逻辑")

        thread(name = "kick-geo") {
            try {
                // 这里使用前台服务做一次“立即地点规则检查”，避免 WorkManager 可能的延迟
                val svc = Intent(appCtx, GeoForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= 26) appCtx.startForegroundService(svc) else appCtx.startService(svc)
                logWithTime(appCtx, "【解锁前台Activity】已请求启动 GeoForegroundService 进行一次立即地点规则检查")
            } catch (t: Throwable) {
                logWithTime(appCtx, "【解锁前台Activity】启动 GeoForegroundService 失败：" + (t.message ?: "unknown"))
            }
        }

        thread(name = "kick-unlock") {
            try {
                logWithTime(appCtx, "【解锁前台Activity】准备触发解锁轻提醒（UnlockWorker.trigger）")
                UnlockWorker.trigger(appCtx)
            } catch (t: Throwable) {
                logWithTime(appCtx, "【解锁前台Activity】触发 UnlockWorker 失败：" + (t.message ?: "unknown"))
            }
        }

        // 无界面，仅用于“立刻触发”。立即安排销毁自己
        thread(name = "kick-finish") {
            try {
                // 给子线程一点点时间启动，避免极端机型还没来得及启动服务就把 Activity 干掉
                Thread.sleep(300)
            } catch (_: Throwable) { }
            finallyFinish()
        }
    }

    private fun finallyFinish() {
        try {
            logWithTime(applicationContext, "【解锁前台Activity】finally：准备销毁透明Activity")
        } catch (_: Throwable) { }
        try {
            runOnUiThread { try { finish() } catch (_: Throwable) {} }
        } catch (_: Throwable) {
            // 兜底
            try { finish() } catch (_: Throwable) { }
        }
    }

    private fun logWithTime(ctx: Context, msg: String) {
        try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
            val now = fmt.format(Date())
            com.example.quote_app.data.DbRepo.log(ctx, null, "[$now] $msg")
        } catch (_: Throwable) { }
    }
}