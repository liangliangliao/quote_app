package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/**
 * 兜底探测：收到 SCREEN_ON 后，延迟 600ms 检查是否已解锁（无锁/智能解锁场景）。
 * 若已解锁，则触发一次 UnlockWorker。做 3 秒内的去重，避免重复触发。
 */
class ScreenOnProbeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_SCREEN_ON) return
        val app = context.applicationContext

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val km = app.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                val locked = km.isKeyguardLocked
                if (!locked) {
                    // 3 秒内去重
                    val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
                    val now = System.currentTimeMillis()
                    val last = sp.getLong("last_unlock_trigger_ts", 0L)
                    if (last == 0L || (now - last) >= 3000L) {
                        sp.edit().putLong("last_unlock_trigger_ts", now).apply()
                        try { Toast.makeText(app, "已捕获解锁事件（探测）", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
                        try { com.example.quote_app.data.DbRepo.log(app, null, "[${'$'}now] 【解锁后台-探测】已判定为解锁，触发 UnlockWorker") } catch (_: Throwable) {}
                        UnlockWorker.trigger(app)
                    }
                }
            } catch (_: Throwable) {
                // ignore
            }
        }, 600)
    }
}