import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import '../data/movie_favorite_dao.dart';
import '../services/tmdb_service.dart';
import '../widgets/movie_overview_box.dart';

/// A page displaying the user's favourited movies stored locally. Users can
/// search by title via a simple text field. Each item shows the poster,
/// title, overview and basic stats. A delete button allows removing
/// favourites directly from this list.
class MovieFavoritesPage extends StatefulWidget {
  const MovieFavoritesPage({super.key});

  @override
  State<MovieFavoritesPage> createState() => _MovieFavoritesPageState();
}

class _MovieFavoritesPageState extends State<MovieFavoritesPage> {
  final MovieFavoriteDao _dao = MovieFavoriteDao();
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _movies = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(() {
      _load();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
    });
    try {
      final query = _searchCtrl.text.trim();
      final rows = await _dao.listFavorites(query: query.isEmpty ? null : query);
      setState(() {
        _movies = rows;
      });
    } catch (_) {
      setState(() {
        _movies = [];
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  Future<void> _remove(Map<String, dynamic> movie) async {
    final id = movie['tmdb_id'];
    if (id is! int) return;
    await _dao.deleteByTmdbId(id);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('收藏电影', style: TextStyle(color: Colors.black87)),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: '搜索收藏的电影',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchCtrl.clear();
                          FocusScope.of(context).unfocus();
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _movies.isEmpty
                    ? const Center(child: Text('暂无收藏'))
                    : ListView.builder(
                        itemCount: _movies.length,
                        itemBuilder: (context, index) {
                          final movie = _movies[index];
                          final title = (movie['title'] ?? '').toString();
                          final overview = (movie['overview'] ?? '').toString();
                          final releaseDate = (movie['release_date'] ?? '').toString();
                          final voteAverage = movie['vote_average'];
                          final voteCount = movie['vote_count'];
                          final posterUrl = TMDbService.buildPosterUrl(movie['poster_path'], size: 'w342');
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            elevation: 2,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Poster image
                                  if (posterUrl != null)
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(4),
                                      child: Image.network(
                                        posterUrl,
                                        width: 80,
                                        height: 120,
                                        fit: BoxFit.cover,
                                      ),
                                    )
                                  else
                                    Container(
                                      width: 80,
                                      height: 120,
                                      color: Colors.grey.shade300,
                                      alignment: Alignment.center,
                                      child: const Icon(Icons.movie, size: 40, color: Colors.grey),
                                    ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          title,
                                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 4),
                                        MovieOverviewBox(text: overview),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            if (releaseDate.isNotEmpty) ...[
                                              const Icon(Icons.calendar_today, size: 14, color: Colors.black45),
                                              const SizedBox(width: 4),
                                              Text(releaseDate, style: const TextStyle(fontSize: 12, color: Colors.black45)),
                                              const SizedBox(width: 12),
                                            ],
                                            const Icon(Icons.star, size: 14, color: Colors.amber),
                                            const SizedBox(width: 4),
                                            Text(
                                              (voteAverage != null ? (voteAverage as num).toStringAsFixed(1) : '-') +
                                                  ' (${voteCount ?? '-'})',
                                              style: const TextStyle(fontSize: 12, color: Colors.black45),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                                    onPressed: () => _remove(movie),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}