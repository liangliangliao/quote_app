import 'package:flutter/material.dart';

/// Movie overview widget:
///
/// 默认显示 [maxLines] 行（默认 4 行）。如果文本超过该行数，会在文本
/// 末尾区域显示 “查看” 按钮，点击弹窗展示完整简介。
///
/// 这样既不会像完全展开那样占据列表空间，也避免了在卡片内滚动造成
/// 的手势冲突。
class MovieOverviewBox extends StatefulWidget {
  final String text;
  final int maxLines;
  final TextStyle style;
  final String dialogTitle;

  const MovieOverviewBox({
    super.key,
    required this.text,
    this.maxLines = 4,
    this.style = const TextStyle(
      fontSize: 13,
      color: Colors.black54,
      height: 1.35,
    ),
    this.dialogTitle = '电影简介',
  });

  @override
  State<MovieOverviewBox> createState() => _MovieOverviewBoxState();
}

class _MovieOverviewBoxState extends State<MovieOverviewBox> {
  bool _overflow = false;

  void _measureOverflow(BoxConstraints constraints, String content) {
    final painter = TextPainter(
      text: TextSpan(text: content, style: widget.style),
      maxLines: widget.maxLines,
      textDirection: TextDirection.ltr,
      ellipsis: '…',
    );
    painter.layout(maxWidth: constraints.maxWidth);
    final did = painter.didExceedMaxLines;
    if (did != _overflow) {
      // Avoid setState during build phase by scheduling.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          setState(() => _overflow = did);
        }
      });
    }
  }

  void _showFull(String content) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(widget.dialogTitle),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Text(content, style: widget.style),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final String content = widget.text.trim().isEmpty ? '暂无简介' : widget.text.trim();
    return LayoutBuilder(
      builder: (context, constraints) {
        // Measure overflow based on current width.
        _measureOverflow(constraints, content);

        return Stack(
          children: [
            // Base text (clamped to maxLines)
            Text(
              content,
              style: widget.style,
              maxLines: widget.maxLines,
              overflow: TextOverflow.ellipsis,
            ),
            if (_overflow)
              Positioned(
                right: 0,
                bottom: 0,
                child: GestureDetector(
                  onTap: () => _showFull(content),
                  child: Container(
                    padding: const EdgeInsets.only(left: 8),
                    // Use a solid background to cover the ellipsis area.
                    color: Colors.white,
                    child: const Text(
                      '查看',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.blue,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}
