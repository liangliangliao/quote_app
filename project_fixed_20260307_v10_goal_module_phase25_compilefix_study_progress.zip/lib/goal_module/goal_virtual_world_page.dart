import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'goal_dao.dart';
import 'goal_models.dart';
import 'goal_world_scene_detail_page.dart';
import 'goal_world_seed.dart';

class GoalVirtualWorldPage extends StatefulWidget {
  const GoalVirtualWorldPage({super.key});

  @override
  State<GoalVirtualWorldPage> createState() => _GoalVirtualWorldPageState();
}

class _GoalVirtualWorldPageState extends State<GoalVirtualWorldPage> {
  final _dao = GoalDao();
  late Future<List<GoalWorldSceneProgress>> _future;

  @override
  void initState() {
    super.initState();
    _future = _dao.listWorldSceneProgress();
  }

  Future<void> _reload() async {
    setState(() {
      _future = _dao.listWorldSceneProgress();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('目标试验场')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: FutureBuilder<List<GoalWorldSceneProgress>>(
        future: _future,
        builder: (context, snap) {
          final map = {
            for (final item in (snap.data ?? const <GoalWorldSceneProgress>[])) item.sceneId: item,
          };
          final completedScenes = goalWorldScenes.where((scene) => (map[scene.sceneId]?.completedTaskIds.length ?? 0) == scene.tasks.length && scene.tasks.isNotEmpty).length;
          final claimedRewards = goalWorldScenes.where((scene) => map[scene.sceneId]?.rewardClaimed == true).length;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            children: [
              _HeroCard(completedScenes: completedScenes, totalScenes: goalWorldScenes.length, claimedRewards: claimedRewards),
              const SizedBox(height: 12),
              for (final scene in goalWorldScenes) ...[
                _SceneCard(
                  scene: scene,
                  progress: map[scene.sceneId] ?? GoalWorldSceneProgress.empty(scene.sceneId),
                  onTap: () async {
                    await Navigator.of(context).push(CupertinoPageRoute(builder: (_) => GoalWorldSceneDetailPage(sceneId: scene.sceneId)));
                    await _reload();
                  },
                ),
                const SizedBox(height: 12),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  final int completedScenes;
  final int totalScenes;
  final int claimedRewards;

  const _HeroCard({
    required this.completedScenes,
    required this.totalScenes,
    required this.claimedRewards,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('轻量虚拟世界：把课程内容变成可完成的场景任务', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text(
            '这一页不再只是静态入口：每个场景都有任务、完成状态、现实映射输入和奖励解锁。完成后可以把结果同步到目标工坊。',
            style: TextStyle(height: 1.6, color: Color(0xFF4B5563)),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _mini('完成场景', '$completedScenes/$totalScenes')),
              const SizedBox(width: 10),
              Expanded(child: _mini('已领奖励', '$claimedRewards')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _mini(String label, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        decoration: BoxDecoration(
          color: const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
          ],
        ),
      );
}

class _SceneCard extends StatelessWidget {
  final GoalWorldSceneDef scene;
  final GoalWorldSceneProgress progress;
  final VoidCallback onTap;

  const _SceneCard({required this.scene, required this.progress, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final done = progress.completedTaskIds.length;
    final total = scene.tasks.length;
    final ratio = total == 0 ? 0.0 : done / total;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: scene.accentColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(Icons.landscape_outlined, color: scene.accentColor),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(scene.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text(scene.subtitle, style: const TextStyle(color: Color(0xFF4B5563), height: 1.55)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: Color(0xFF9CA3AF)),
                ],
              ),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value: ratio,
                minHeight: 8,
                backgroundColor: const Color(0xFFE5E7EB),
                valueColor: AlwaysStoppedAnimation<Color>(scene.accentColor),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _statusChip('$done/$total 任务', const Color(0xFFF3F4F6), const Color(0xFF374151)),
                  _statusChip(progress.rewardClaimed ? '已领奖励' : '奖励未领取', progress.rewardClaimed ? scene.accentColor.withOpacity(0.12) : const Color(0xFFF3F4F6), progress.rewardClaimed ? scene.accentColor : const Color(0xFF6B7280)),
                ],
              ),
              const SizedBox(height: 10),
              Text(scene.rewardTitle + '：' + scene.rewardDescription, style: const TextStyle(color: Color(0xFF374151), height: 1.55)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusChip(String text, Color bg, Color fg) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: TextStyle(fontSize: 12, color: fg, fontWeight: FontWeight.w700)),
      );
}
