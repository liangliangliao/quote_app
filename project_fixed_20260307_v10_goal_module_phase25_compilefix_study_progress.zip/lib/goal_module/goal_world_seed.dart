import "package:flutter/material.dart";

class GoalWorldTaskDef {
  final String taskId;
  final String title;
  final String description;

  const GoalWorldTaskDef({
    required this.taskId,
    required this.title,
    required this.description,
  });
}

class GoalWorldSceneDef {
  final String sceneId;
  final String title;
  final String subtitle;
  final String mission;
  final String inputLabel;
  final String rewardTitle;
  final String rewardDescription;
  final Color accentColor;
  final List<String> relatedSegmentIds;
  final List<GoalWorldTaskDef> tasks;

  const GoalWorldSceneDef({
    required this.sceneId,
    required this.title,
    required this.subtitle,
    required this.mission,
    required this.inputLabel,
    required this.rewardTitle,
    required this.rewardDescription,
    required this.accentColor,
    required this.relatedSegmentIds,
    required this.tasks,
  });
}

const goalWorldScenes = <GoalWorldSceneDef>[
  GoalWorldSceneDef(
    sceneId: 'fog_plain',
    title: '迷雾平原',
    subtitle: '适合“我现在很迷茫，不知道该追什么”的状态。',
    mission: '先从混乱里找出一个暂时方向：区分别人期待的目标、自己真正不想失去的东西，以及眼下最值得先走的一步。',
    inputLabel: '把你在迷雾平原里找到的“暂时方向”写下来。',
    rewardTitle: '方向火种',
    rewardDescription: '完成后可把“暂时方向”同步到目标工坊，作为当前愿景与身份线索。',
    accentColor: Color(0xFF0F766E),
    relatedSegmentIds: ['PP12_16', 'ST13_10', 'ST13_09'],
    tasks: [
      GoalWorldTaskDef(
        taskId: 'fog_expectation',
        title: '辨认一个“别人期待”的目标',
        description: '先承认它存在，而不是把它误认为真实自我。',
      ),
      GoalWorldTaskDef(
        taskId: 'fog_cannot_without',
        title: '回答“我不能没有什么”',
        description: '用一句话写出你不愿长期失去的东西。',
      ),
      GoalWorldTaskDef(
        taskId: 'fog_direction',
        title: '形成一个暂时方向',
        description: '不是一辈子答案，而是接下来一段时间更想朝哪里走。',
      ),
    ],
  ),
  GoalWorldSceneDef(
    sceneId: 'mirror_lake',
    title: '镜湖',
    subtitle: '适合“我有目标，但不确定是不是属于自己”的状态。',
    mission: '围绕自我一致性做一次校准：判断目标是否真的像你、有没有让你更有能量，以及你是为了热爱还是为了迎合。',
    inputLabel: '写下：这个目标最像我的地方，或最不像我的地方。',
    rewardTitle: '清晰镜片',
    rewardDescription: '完成后可把“像我/不像我”的判断同步到目标工坊，帮助修正 why 与现实阻碍。',
    accentColor: Color(0xFF1D4ED8),
    relatedSegmentIds: ['PP12_16', 'ST13_02', 'PP12_18'],
    tasks: [
      GoalWorldTaskDef(
        taskId: 'mirror_real_me',
        title: '判断这个目标像不像真正的我',
        description: '从兴趣、价值、身份三个角度看它。',
      ),
      GoalWorldTaskDef(
        taskId: 'mirror_energy',
        title: '观察它是否带来能量',
        description: '回想做这件事时，你是更有劲还是更耗竭。',
      ),
      GoalWorldTaskDef(
        taskId: 'mirror_pressure',
        title: '分辨热爱与迎合',
        description: '这件事里有多少来自你自己，有多少只是外界压力。',
      ),
    ],
  ),
  GoalWorldSceneDef(
    sceneId: 'workshop_city',
    title: '工坊城',
    subtitle: '适合“我已经知道方向，但就是落不下来”的状态。',
    mission: '把方向打造成现实路径：把目标写下来、设 lifeline、拆成本周推进和明天第一步，再准备 if-then 应对阻碍。',
    inputLabel: '写下你准备真正落地的一步，或你现在最需要的本周推进。',
    rewardTitle: '执行蓝图',
    rewardDescription: '完成后可把本周推进与下一步同步到目标工坊，形成现实执行草稿。',
    accentColor: Color(0xFF7C3AED),
    relatedSegmentIds: ['ST13_11', 'ST13_14', 'ST13_12'],
    tasks: [
      GoalWorldTaskDef(
        taskId: 'workshop_lifeline',
        title: '设一个 lifeline',
        description: '给目标一个明确时间点，而不是“以后再说”。',
      ),
      GoalWorldTaskDef(
        taskId: 'workshop_weekly',
        title: '写出本周推进',
        description: '把长期方向压缩成这周能推进的一步。',
      ),
      GoalWorldTaskDef(
        taskId: 'workshop_ifthen',
        title: '准备一个 if-then',
        description: '提前决定：如果遇到阻碍，我先做什么。',
      ),
    ],
  ),
];

GoalWorldSceneDef sceneById(String sceneId) => goalWorldScenes.firstWhere((e) => e.sceneId == sceneId);
