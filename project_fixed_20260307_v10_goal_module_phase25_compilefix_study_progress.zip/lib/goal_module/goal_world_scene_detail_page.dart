import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'goal_action_runner_page.dart';
import 'goal_dao.dart';
import 'goal_models.dart';
import 'goal_segment_detail_page.dart';
import 'goal_workshop_page.dart';
import 'goal_world_seed.dart';

class GoalWorldSceneDetailPage extends StatefulWidget {
  final String sceneId;
  const GoalWorldSceneDetailPage({super.key, required this.sceneId});

  @override
  State<GoalWorldSceneDetailPage> createState() => _GoalWorldSceneDetailPageState();
}

class _GoalWorldSceneDetailPageState extends State<GoalWorldSceneDetailPage> {
  final _dao = GoalDao();
  late final GoalWorldSceneDef _scene;
  final _note = TextEditingController();
  final _scrollController = ScrollController();
  Timer? _autosaveTimer;
  bool _restoreChecked = false;
  Set<String> _completedTaskIds = <String>{};
  bool _rewardClaimed = false;
  bool _saving = false;
  bool _loaded = false;
  List<GoalSceneActionSuggestion> _recommendedActions = const <GoalSceneActionSuggestion>[];

  @override
  void initState() {
    super.initState();
    _scene = sceneById(widget.sceneId);
    _note.addListener(_scheduleAutosave);
    _scrollController.addListener(_scheduleAutosave);
    _load();
  }

  Future<void> _load() async {
    final progress = await _dao.getWorldSceneProgress(widget.sceneId);
    final recommended = await _dao.listRecommendedActionsForScene(widget.sceneId);
    if (!mounted) return;
    setState(() {
      _completedTaskIds = progress.completedTaskIds.toSet();
      _rewardClaimed = progress.rewardClaimed;
      _note.text = progress.realityNote;
      _recommendedActions = recommended;
      _loaded = true;
    });
  }

  void _scheduleAutosave() {
    _autosaveTimer?.cancel();
    _autosaveTimer = Timer(const Duration(milliseconds: 350), () { _persistDraftState(); });
  }

  Future<void> _persistDraftState() async {
    await _dao.saveWorldSceneProgress(
      sceneId: _scene.sceneId,
      completedTaskIds: _completedTaskIds.toList(),
      realityNote: _note.text.trim(),
      rewardClaimed: _rewardClaimed,
    );
    final offset = _scrollController.hasClients ? _scrollController.offset : 0.0;
    await _dao.saveContinueState(
      stateKey: 'last_scene',
      targetId: _scene.sceneId,
      scrollOffset: offset,
      extra: {'title': _scene.title},
    );
  }

  Future<void> _restorePositionIfNeeded() async {
    if (_restoreChecked) return;
    _restoreChecked = true;
    final state = await _dao.getContinueState('last_scene');
    if (!mounted || state.targetId != _scene.sceneId) return;
    final offset = state.scrollOffset;
    if (offset <= 0) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      final max = _scrollController.position.maxScrollExtent;
      final target = offset.clamp(0.0, max);
      _scrollController.jumpTo(target);
    });
  }

  @override
  void dispose() {
    _autosaveTimer?.cancel();
    _persistDraftState();
    _note.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  bool get _allDone => _completedTaskIds.length == _scene.tasks.length;

  Future<void> _save({bool claimReward = false, bool openWorkshop = false}) async {
    if (claimReward && _note.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('先写下你这一关在现实里的收获或方向。')));
      return;
    }
    setState(() => _saving = true);
    final shouldClaim = claimReward || _rewardClaimed;
    await _dao.saveWorldSceneProgress(
      sceneId: _scene.sceneId,
      completedTaskIds: _completedTaskIds.toList(),
      realityNote: _note.text.trim(),
      rewardClaimed: shouldClaim,
    );
    if (claimReward) {
      await _dao.mergeWorldSceneIntoWorkshop(sceneId: _scene.sceneId, realityNote: _note.text.trim());
    }
    if (!mounted) return;
    setState(() {
      _rewardClaimed = shouldClaim;
      _saving = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(claimReward ? '已领取${_scene.rewardTitle}，并同步到目标工坊。' : '场景进度已保存。')),
    );
    if (claimReward && openWorkshop) {
      Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const GoalWorkshopPage()));
    }
  }

  Future<void> _openRecommendedAction(GoalSceneActionSuggestion item) async {
    final result = await Navigator.of(context).push<bool>(
      CupertinoPageRoute(
        builder: (_) => GoalActionRunnerPage(
          action: item.action,
          conceptTitle: item.conceptTitle,
          segmentTitle: item.segmentTitle,
        ),
      ),
    );
    if (!mounted) return;
    if (result == true) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已从试验场进入行动执行，并记录到行动闭环。')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Scaffold(
        appBar: AppBar(title: Text(_scene.title)),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final progress = _scene.tasks.isEmpty ? 0.0 : _completedTaskIds.length / _scene.tasks.length;
    _restorePositionIfNeeded();
    return Scaffold(
      appBar: AppBar(title: Text(_scene.title)),
      backgroundColor: const Color(0xFFF5F6FA),
      body: ListView(
        controller: _scrollController,
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        children: [
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: _scene.accentColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(Icons.explore_outlined, color: _scene.accentColor),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_scene.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(_scene.subtitle, style: const TextStyle(color: Color(0xFF4B5563), height: 1.5)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                LinearProgressIndicator(
                  value: progress,
                  minHeight: 8,
                  backgroundColor: const Color(0xFFE5E7EB),
                  valueColor: AlwaysStoppedAnimation<Color>(_scene.accentColor),
                ),
                const SizedBox(height: 8),
                Text('已完成 ${_completedTaskIds.length}/${_scene.tasks.length} 个场景任务', style: const TextStyle(color: Color(0xFF6B7280))),
                const SizedBox(height: 14),
                Text(_scene.mission, style: const TextStyle(height: 1.65, color: Color(0xFF374151))),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            title: '场景任务',
            child: Column(
              children: [
                for (final task in _scene.tasks)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          if (_completedTaskIds.contains(task.taskId)) {
                            _completedTaskIds.remove(task.taskId);
                          } else {
                            _completedTaskIds.add(task.taskId);
                          }
                        });
                        _scheduleAutosave();
                      },
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: _completedTaskIds.contains(task.taskId) ? _scene.accentColor.withOpacity(0.08) : const Color(0xFFF9FAFB),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: _completedTaskIds.contains(task.taskId) ? _scene.accentColor.withOpacity(0.35) : const Color(0xFFE5E7EB),
                          ),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Checkbox(
                              value: _completedTaskIds.contains(task.taskId),
                              onChanged: (_) {
                                setState(() {
                                  if (_completedTaskIds.contains(task.taskId)) {
                                    _completedTaskIds.remove(task.taskId);
                                  } else {
                                    _completedTaskIds.add(task.taskId);
                                  }
                                });
                              },
                              activeColor: _scene.accentColor,
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(task.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                                  const SizedBox(height: 4),
                                  Text(task.description, style: const TextStyle(color: Color(0xFF4B5563), height: 1.55)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            title: '现实映射',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_scene.inputLabel, style: const TextStyle(color: Color(0xFF374151), height: 1.55)),
                const SizedBox(height: 10),
                TextField(
                  controller: _note,
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: '把你在这个场景里看清楚、决定好或准备执行的内容写下来。',
                    filled: true,
                    fillColor: const Color(0xFFF9FAFB),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _rewardClaimed ? _scene.accentColor.withOpacity(0.08) : const Color(0xFFF9FAFB),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(_rewardClaimed ? Icons.workspace_premium_outlined : Icons.card_giftcard_outlined, color: _scene.accentColor),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_scene.rewardTitle, style: const TextStyle(fontWeight: FontWeight.w800)),
                            const SizedBox(height: 4),
                            Text(_scene.rewardDescription, style: const TextStyle(color: Color(0xFF4B5563), height: 1.55)),
                            const SizedBox(height: 6),
                            Text(_rewardClaimed ? '状态：已领取并同步到工坊' : (_allDone ? '状态：任务已完成，可领取奖励' : '状态：完成全部任务后可领取奖励'), style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          if (_allDone || _rewardClaimed) ...[
            const SizedBox(height: 12),
            _card(
              title: '推荐现实行动',
              child: _recommendedActions.isEmpty
                  ? const Text('当前场景还没有可用的行动模板。', style: TextStyle(color: Color(0xFF6B7280)))
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '完成场景后，下一步最好立刻做一个现实动作。${_recommendedActions.first.sceneReason}',
                          style: const TextStyle(color: Color(0xFF4B5563), height: 1.6),
                        ),
                        const SizedBox(height: 10),
                        for (final item in _recommendedActions)
                          Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: const Color(0xFFE5E7EB)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(item.action.actionTitle, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: _scene.accentColor.withOpacity(0.10),
                                        borderRadius: BorderRadius.circular(999),
                                      ),
                                      child: Text(item.action.actionLevel, style: TextStyle(color: _scene.accentColor, fontSize: 12, fontWeight: FontWeight.w700)),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Text(item.conceptTitle, style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
                                const SizedBox(height: 8),
                                Text(item.action.goalOfAction, style: const TextStyle(color: Color(0xFF374151), height: 1.55)),
                                const SizedBox(height: 10),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    FilledButton.icon(
                                      onPressed: () => _openRecommendedAction(item),
                                      icon: const Icon(Icons.play_circle_outline),
                                      label: const Text('直接进入执行'),
                                    ),
                                    OutlinedButton.icon(
                                      onPressed: () => Navigator.of(context).push(
                                        CupertinoPageRoute(builder: (_) => GoalSegmentDetailPage(segmentId: item.action.segmentId)),
                                      ),
                                      icon: const Icon(Icons.menu_book_outlined),
                                      label: const Text('回看课程正文'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
            ),
          ],
          const SizedBox(height: 12),
          _card(
            title: '相关课程 / 快捷入口',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final id in _scene.relatedSegmentIds)
                      OutlinedButton(
                        onPressed: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => GoalSegmentDetailPage(segmentId: id))),
                        child: Text('查看 $id'),
                      ),
                    OutlinedButton(
                      onPressed: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const GoalWorkshopPage())),
                      child: const Text('进入目标工坊'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _saving ? null : () => _save(),
              child: const Text('保存场景进度'),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: FilledButton.tonal(
              onPressed: _saving || !_allDone ? null : () => _save(claimReward: true, openWorkshop: true),
              child: Text(_rewardClaimed ? '再次同步到目标工坊' : '领取奖励并同步到工坊'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _card({String? title, required Widget child}) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (title != null) ...[
              Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
            ],
            child,
          ],
        ),
      );
}
