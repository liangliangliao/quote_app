import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/notification_service.dart';
import '../platform/native_scheduler.dart';

/// 首次进入的双门卡权限引导：系统通知 -> 精确闹钟
class PermissionGate {
  static bool _ran = false;

  static Future<void> runOnLaunch(BuildContext context) async {
    if (_ran) return;
    _ran = true;
    // 只有 Android 需要处理；iOS 直接放行
    if (!Platform.isAndroid) return;

    // ===== 第一关：系统通知权限 =====
    final hasNotif = await NotificationService.isEnabled();
    if (!hasNotif) {
      final allow = await _ask(context,
        title: '系统通知权限授权',
        content: '为了正常提醒，请先开启系统通知权限。',
        allowText: '允许',
        denyText: '不允许',
      );
      if (allow == true) {
        try { await NotificationService.request(); } catch (_){}
        // 再次检测
        final ok = await NotificationService.isEnabled();
        if (!ok) {
          await _alert(context, '提示', '未开启系统通知权限，应用将退出。');
          SystemNavigator.pop();
          return;
        }
      } else {
        await _alert(context, '提示', '未开启系统通知权限，应用将退出。');
        SystemNavigator.pop();
        return;
      }
    }

    // ===== 第二关：精确闹钟权限 =====
    bool hasExact = false;
    try { hasExact = await NativeScheduler.hasExactAlarmPermission(); } catch (_){}
    if (hasExact) return; // 解锁成功，进入首页

    while (true) {
      final allowAlarm = await _ask(context,
        title: '闹钟提醒权限授权',
        content: '建议开启“精确闹钟”权限以确保到点提醒。',
        allowText: '允许',
        denyText: '不允许',
      );
      if (allowAlarm == true) {
        try { await NativeScheduler.requestExactAlarmPermission(); } catch (_){}
        // 用户返回后再检查一次
        try { hasExact = await NativeScheduler.hasExactAlarmPermission(); } catch (_){ hasExact = false; }
        // 不论成功与否都进入首页；成功则下次不再出现；失败则下次还会提示这第二关
        return;
      } else {
        final sure = await _askYesNo(context,
          title: '提示',
          content: '你将不启用精准闹钟提醒功能！',
          yesText: '是',
          noText: '否',
        );
        if (sure == true) {
          // 进入首页，不再停留在权限页
          return;
        } else {
          // 回到第二关弹框
          continue;
        }
      }
    }
  }

  static Future<bool?> _ask(BuildContext context, {required String title, required String content, required String allowText, required String denyText}) {
    return showDialog<bool>(context: context, barrierDismissible: false, builder: (_) {
      return AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(onPressed: ()=> Navigator.pop(context, false), child: Text(denyText)),
          FilledButton(onPressed: ()=> Navigator.pop(context, true), child: Text(allowText)),
        ],
      );
    });
  }

  static Future<bool?> _askYesNo(BuildContext context, {required String title, required String content, required String yesText, required String noText}) {
    return showDialog<bool>(context: context, barrierDismissible: false, builder: (_) {
      return AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(onPressed: ()=> Navigator.pop(context, true), child: Text(yesText)),
          FilledButton(onPressed: ()=> Navigator.pop(context, false), child: Text(noText)),
        ],
      );
    });
  }

  static Future<void> _alert(BuildContext context, String title, String msg) {
    return showDialog<void>(context: context, barrierDismissible: false, builder: (_) {
      return AlertDialog(
        title: Text(title),
        content: Text(msg),
        actions: [ FilledButton(onPressed: ()=> Navigator.pop(context), child: const Text('知道了')) ],
      );
    });
  }
}
