
import 'dart:io';
import 'package:flutter/services.dart';
import '../utils/debug_logger.dart';

class PermHelper {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');
  static bool? _lastHasExact;
  static DateTime? _lastExactCheckedAt;

  /// 是否拥有“精确闹钟”权限（带缓存与容错，避免偶发抖动）
  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return true;
    // 10 秒内重复查询直接使用缓存
    if (_lastExactCheckedAt != null &&
        DateTime.now().difference(_lastExactCheckedAt!) < const Duration(seconds: 10) &&
        _lastHasExact != null) {
      return _lastHasExact!;
    }
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      _lastExactCheckedAt = DateTime.now();
      _lastHasExact = ok ?? false;
      return _lastHasExact!;
    } catch (e) {
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
      return false;
    }
  }

  /// 跳转系统界面申请“精确闹钟”权限（Android 12+）
  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } catch (e) {
      DLog.e('platform/perm_helper.dart', 'requestExactAlarmPermission catch: ' + e.toString());
    }
  }
}
