package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread

/**
 * 解锁广播入口（方案B）：
 * - 广播回调里只做“去重 + 触发 WorkManager”，避免耗时操作导致广播延迟/丢失。
 * - 通过 3 秒窗口去重，避免 USER_PRESENT 与 SCREEN_ON 探测双触发。
 *
 * 注意：不使用前台服务，因此不会在通知栏常驻通知。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val app = context.applicationContext
    val pending = goAsync()

    thread(name = "unlock-receiver") {
      try {
        val action = intent?.action ?: "unknown"
        val now = System.currentTimeMillis()
        val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        val last = sp.getLong("last_unlock_trigger_ts", 0L)
        if (last > 0 && (now - last) < 3000L) {
          logWithTime(app, "【解锁后台】收到解锁广播($action) 但 3 秒内已触发过，跳过重复（回包：SKIP_DUP）")
          return@thread
        }
        sp.edit()
          .putLong("last_unlock_trigger_ts", now)
          .putLong("last_user_present_ts", now)
          .apply()

        logWithTime(app, "【解锁后台】收到解锁广播($action)，立即触发 UnlockWorker + 方案B地点规则快路径（回包：OK）")

        try { UnlockWorker.trigger(app) } catch (t: Throwable) {
          logWithTime(app, "【解锁后台】触发 UnlockWorker 失败：" + (t.message ?: "unknown"))
        }

        try { GeoUnlockOrchestrator.run(app, "unlock:$action") } catch (t: Throwable) {
          logWithTime(app, "【解锁后台】触发 GeoUnlockOrchestrator 失败：" + (t.message ?: "unknown"))
        }
      } catch (t: Throwable) {
        try {
          logWithTime(app, "【解锁后台】UnlockReceiver 异常：" + (t.message ?: "unknown"))
        } catch (_: Throwable) {}
      } finally {
        try { pending.finish() } catch (_: Throwable) {}
      }
    }
  }

  /** 写入包含时间戳的中文日志。 */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
