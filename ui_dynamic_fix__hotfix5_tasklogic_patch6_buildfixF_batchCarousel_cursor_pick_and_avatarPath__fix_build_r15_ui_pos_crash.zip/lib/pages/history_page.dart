import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:path/path.dart' as p;

import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final _dao = QuoteDao();
  final _scroll = ScrollController();
  String _q = '';
  List<Map<String, dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && !_done) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 100, offset: _offset, q: _q.isEmpty ? null : _q);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
  }

  Future<String?> _saveAvatarTemp(File file) async {
    final docs = await getApplicationDocumentsDirectory();
    final ext = p.extension(file.path);
    final f = File(p.join(docs.path, 'avatar_import$ext'));
    try {
      await file.copy(f.path);
      return f.path;
    } catch (_) {
      return null;
    }
  }

  Future<void> _openImportDialog() async {
    File? csvFile;
    File? avatarFile;
    String? csvError;
    await showDialog(context: context, builder: (ctx) {
      return StatefulBuilder(builder: (ctx, setStateDialog) {
        return AlertDialog(
          title: const Text('批量导入名言'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('上传文件 (CSV)'),
              Row(children: [
                OutlinedButton.icon(
                  onPressed: () async {
                    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv']);
                    if (res != null && res.files.isNotEmpty) {
                      final picked = res.files.single;
                      if (picked.path != null) {
                        csvFile = File(picked.path!);
                      } else if (picked.bytes != null) {
                        final tmpDir = await getTemporaryDirectory();
                        final f = File(p.join(tmpDir.path, 'import.csv'));
                        await f.writeAsBytes(picked.bytes!);
                        csvFile = f;
                      }
                      setStateDialog(() { csvError = null; });
                    }
                  },
                  icon: const Icon(Icons.upload_file),
                  label: const Text('选择 CSV'),
                ),
                const SizedBox(width: 12),
                Flexible(child: Text(csvFile != null ? p.basename(csvFile!.path) : '未选择', overflow: TextOverflow.ellipsis)),
              ]),
              if (csvError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(csvError!, style: const TextStyle(color: Colors.red)),
                ),
              const SizedBox(height: 12),
              const Text('上传头像（可选）'),
              Row(children: [
                OutlinedButton.icon(
                  onPressed: () async {
                    final picker = ImagePicker();
                    final x = await picker.pickImage(source: ImageSource.gallery);
                    if (x != null) {
                      avatarFile = File(x.path);
                      setStateDialog((){});
                    }
                  },
                  icon: const Icon(Icons.photo),
                  label: const Text('选择图片'),
                ),
                const SizedBox(width: 12),
                Flexible(child: Text(avatarFile != null ? p.basename(avatarFile!.path) : '可不上传', overflow: TextOverflow.ellipsis)),
              ]),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
            FilledButton(
              onPressed: () async {
                if (csvFile == null) {
                  setStateDialog(() { csvError = '请先选择 CSV 文件'; });
                  return;
                }
                String? avatarPath;
                if (avatarFile != null) {
                  avatarPath = await _saveAvatarTemp(avatarFile!);
                }
                await _dao.bulkImportCsv(csvPath: csvFile!.path, avatarPath: avatarPath);
                if (ctx.mounted) Navigator.pop(ctx);
                // 刷新列表
                _items.clear();
                _offset = 0;
                _done = false;
                await _loadMore();
              },
              child: const Text('导入'),
            ),
          ],
        );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;
    return SafeArea(
      top: false,
      bottom: false,
      child: Stack(
        children: [
          Column(
            children: [
              // 顶部搜索栏（去掉上下内边距）
              SizedBox(
                height: topPad + kToolbarHeight,
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText: '搜索',
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          isDense: true,
                        ),
                        onChanged: (v) {
                          _q = v;
                          _items.clear();
                          _offset = 0;
                          _done = false;
                          _loadMore();
                        },
                      ),
                    ),
                    // 旧的嵌入式导入按钮移除，改为悬浮按钮
                    const SizedBox.shrink(),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  controller: _scroll,
                  padding: EdgeInsets.zero,
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final e = _items[i];
                    return ListTile(
                      title: Text((e['task_name'] ?? '') as String),
                      subtitle: Text((e['content'] ?? '') as String, maxLines: 3, overflow: TextOverflow.ellipsis),
                    );
                  },
                ),
              ),
            ],
          ),
          // 左上角悬浮导入按钮
          Positioned(
            right: 12,
            top: topPad + 8,
            child: FloatingActionButton.small(
              heroTag: 'fab_import',
              onPressed: _openImportDialog,
              child: const Icon(Icons.upload_file),
            ),
          ),
        ],
      ),
    );
  }
}
