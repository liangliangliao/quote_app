
package com.example.quote_app

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.baidu.location.LocationClient
import com.baidu.location.LocationClientOption
import com.baidu.location.BDAbstractLocationListener
import com.baidu.location.BDLocation
import io.flutter.plugin.common.MethodChannel

object BaiduLocator {

    fun requestSingle(context: Context, result: MethodChannel.Result) {
        val client = LocationClient(context.applicationContext)
        val option = LocationClientOption()
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy)
        option.setCoorType("wgs84")
        option.setScanSpan(0) // single
        option.setIsNeedAddress(false)
        client.locOption = option
        client.registerLocationListener(object : BDAbstractLocationListener() {
            override fun onReceiveLocation(location: BDLocation?) {
                if (location != null && location.latitude != BDLocation.INVALID_COORDINATE
                    && location.longitude != BDLocation.INVALID_COORDINATE) {
                    val map = hashMapOf<String, Any>(
                        "lat" to location.latitude,
                        "lon" to location.longitude,
                        "acc" to location.radius
                    )
                    result.success(map)
                } else {
                    result.error("NO_LOCATION", "Baidu location failed", null)
                }
                client.stop()
            }
        })
        client.start()
    }
}
