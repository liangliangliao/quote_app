
package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.os.SystemClock

/**
 * 解锁/亮屏广播接收器：
 * - 记录最近一次解锁时间（SharedPreferences + 日志表）；
 * - 触发 UnlockWorker 在后台执行“解锁轻提醒 + 地点规则自检”；
 * - 在前台弹出 Toast，作为用户可见的即时反馈。
 *
 * 注意：
 * - 仅在收到 USER_PRESENT / USER_UNLOCKED 时才认为是真正的“解锁”；
 * - SCREEN_ON 仅用于补充日志观察，不触发业务，以免在锁屏界面提前弹通知。
 */
class UnlockReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val appCtx = context.applicationContext

        // 统一写一条粗粒度日志，方便排查是否真的收到了广播。
        try {
            com.example.quote_app.data.DbRepo.log(
                appCtx,
                null,
                "【解锁广播】收到系统广播：$action"
            )
        } catch (_: Throwable) { }

        // 仅在真正解锁后触发后续逻辑。
        val isUnlockAction = (
            action == Intent.ACTION_USER_PRESENT ||
            action == Intent.ACTION_USER_UNLOCKED
        )

        if (!isUnlockAction) {
            // 对于 SCREEN_ON 等仅做简单日志，避免打扰用户。
            return
        }

        // 1）记录最近一次解锁时间，供 Application 级兜底逻辑使用。
        try {
            val prefs = appCtx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            prefs.edit().putLong("last_unlock_time", now).apply()
        } catch (_: Throwable) { }

        // 2）触发后台 UnlockWorker，负责：
        //    - 读取 notify_config / configs 表；
        //    - 根据冷却时间与开关决定是否下发“解锁轻提醒”通知；
        //    - 在开启地点规则开关时启动 GeoWorker / 前台服务。
        try {
            UnlockWorker.trigger(appCtx)
        } catch (_: Throwable) {
            try {
                com.example.quote_app.data.DbRepo.log(
                    appCtx,
                    null,
                    "【解锁广播】调用 UnlockWorker.trigger 失败"
                )
            } catch (_: Throwable) { }
        }

        // 3）给用户一个即时可见的反馈 Toast（在后台也能弹出）。
        try {
            Toast.makeText(
                appCtx,
                "已解锁：轻提醒和地点规则检查已就绪",
                Toast.LENGTH_SHORT
            ).show()
        } catch (_: Throwable) {
            // 某些机型可能禁用后台 Toast，忽略即可。
        }
    }
}
