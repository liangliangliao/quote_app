package com.example.quote_app

import android.app.Application
import com.example.quote_app.GeoWorker
import com.example.quote_app.NotifyHelper
import com.example.quote_app.data.DbInspector
import android.database.sqlite.SQLiteDatabase

/**
 * Application (Flutter V2 embedding).
 * No custom plugin registrant callbacks are used.
 * Workmanager/plugin registration is handled by the framework and plugins themselves.
 */
class App : Application() {
  override fun onCreate() {
    super.onCreate()
    // Schedule the periodic GeoWorker so geo triggers run even if the device isn't rebooted.
    try {
      GeoWorker.schedule(this)
    } catch (_: Throwable) {
      // Ignore any failures silently
    }
    // Send a one-off unlock reminder when launching the app if the screen-unlock trigger is enabled.
    try {
      maybeSendUnlockReminderOnAppStart()
    } catch (_: Throwable) {
      // Ignore any failures silently
    }
    // Previously onCreate did nothing else.
  }

  /**
   * Check whether there is an active screen_unlock trigger in the vision_triggers table.
   * If so, send a gentle reminder notification immediately. This acts as a fallback
   * when system broadcast (e.g. USER_PRESENT) might be restricted on newer Android versions.
   */
  private fun maybeSendUnlockReminderOnAppStart() {
    try {
      val contract = DbInspector.loadOrLightScan(this)
      if (contract == null || contract.dbPath == null) return
      val path = contract.dbPath!!
      val db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY)
      val c = db.rawQuery("SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1", null)
      val has = c.moveToFirst()
      c.close()
      db.close()
      if (has) {
        // Use a fixed notification id to avoid duplicates
        NotifyHelper.send(this, 2000, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null)
      }
    } catch (_: Throwable) {
      // swallow errors
    }
  }
}
