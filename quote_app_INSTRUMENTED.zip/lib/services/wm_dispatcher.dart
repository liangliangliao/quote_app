import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'notification_service.dart';
import '../data/db.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    await DLog.i('WM', 'workmanager dispatch');
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();

    try { await NotificationService.init(); } catch (e) { await DLog.e('WM', 'init catch: ' + e.toString()); }
    try { await NotificationService.dumpState('workmanager'); } catch (e) { await DLog.e('WM', 'dumpState catch: ' + e.toString()); }
    try { await AppDatabase.instance(); } catch (e) { await DLog.e('WM', 'db init catch: ' + e.toString()); }
    try { await SchedulerService.callback(); } catch (e) { await DLog.e('WM', 'callback catch: ' + e.toString()); }

    // 补发一次（当天漏发）
    try {
      await SchedulerService.catchupIfMissed();
    } catch (e, s) {
      DLog.e('services/wm_dispatcher.dart', 'catch: ' + e.toString());
    }
    return true;
  });
}
