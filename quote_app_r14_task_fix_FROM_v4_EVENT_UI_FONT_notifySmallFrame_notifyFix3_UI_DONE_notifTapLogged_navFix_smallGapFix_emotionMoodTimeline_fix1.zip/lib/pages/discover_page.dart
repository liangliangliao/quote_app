import 'package:flutter/material.dart';
import '../data/emotions.dart';

/// 发现之旅：展示当天的心情状态与时间轴
class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});

  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _DiscoverPageState extends State<DiscoverPage> {
  Map<String, dynamic>? _latestToday;
  List<Map<String, dynamic>> _todayList = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
    });
    try {
      final dao = EmotionDao();
      final latest = await dao.latestToday();
      final list = await dao.listTodayOrdered();
      if (!mounted) return;
      setState(() {
        _latestToday = latest;
        _todayList = list;
      });
    } catch (_) {
      if (!mounted) return;
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  String _formatTime(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return '';
    // 期望格式：YYYY-MM-DD HH:mm:ss
    final parts = insertedAt.split(' ');
    if (parts.length < 2) return insertedAt;
    return parts[1];
  }

  @override
  Widget build(BuildContext context) {
    final latest = _latestToday;
    final String moodLine;
    if (latest == null) {
      moodLine = '当下心情：今天还没有记录心情';
    } else {
      final name = (latest['emoji_name'] ?? '').toString();
      final char = (latest['emoji_char'] ?? '').toString();
      moodLine = '当下心情：$name $char';
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text(
          '发现之旅',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: _loading && _todayList.isEmpty && _latestToday == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 第一行：当下心情 + 名称 + 图标
                          Text(
                            moodLine,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 12),
                          // 第二行：当天所有情绪图标 + 时间轴
                          if (_todayList.isEmpty)
                            const Text(
                              '今天还没有记录心情，回到首页试试分享你的此时此刻吧～',
                              style: TextStyle(fontSize: 13, color: Colors.black54),
                            )
                          else
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: [
                                  for (int i = 0; i < _todayList.length; i++) ...[
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          (_todayList[i]['emoji_char'] ?? '').toString(),
                                          style: const TextStyle(fontSize: 22),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          _formatTime(_todayList[i]['inserted_at']?.toString()),
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: Colors.black54,
                                          ),
                                        ),
                                      ],
                                    ),
                                    if (i != _todayList.length - 1)
                                      Row(
                                        children: const [
                                          SizedBox(width: 4),
                                          Text('——'),
                                          SizedBox(width: 4),
                                        ],
                                      ),
                                  ],
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
