package com.example.quote_app

import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONObject

class NotifyWorker(appContext: Context, params: WorkerParameters)
  : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val id = inputData.getInt("id", 0)
    val payload = inputData.getString("payload") ?: "{}"
    val o = JSONObject(payload)
    val title = o.optString("title", "提醒")
    val body  = o.optString("body",  "到点了")

    val notif = NotificationCompat.Builder(applicationContext, "quote_notify")
      .setSmallIcon(applicationContext.applicationInfo.icon)
      .setContentTitle(title)
      .setContentText(body)
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .build()
    NotificationManagerCompat.from(applicationContext).notify(id, notif)
    return Result.success()
  }
}
