package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Short-lived foreground service (Scheme B).
 *
 * Key design goals:
 * - If we can finish fast (before the foreground notification is shown), we stop the service
 *   before calling startForeground, so the user will NOT see a persistent notification.
 * - If we cannot finish quickly, we call startForeground within ~1s (well below the 5s limit)
 *   so the OS won't kill us.
 * - After the geo reminder logic finishes (sent or not), we immediately stopSelf.
 */
class GeoForegroundService : Service() {

  private val finished = AtomicBoolean(false)
  private val foregroundStarted = AtomicBoolean(false)
  private val mainHandler = Handler(Looper.getMainLooper())

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val reason = intent?.getStringExtra("reason") ?: "unknown"

    // Schedule a watchdog to start foreground if we don't finish quickly.
    val watchdog = Runnable {
      if (finished.get()) return@Runnable
      try {
        startForegroundInternal()
        foregroundStarted.set(true)
        log("【GeoFGS】watchdog startForeground (reason=$reason)")
      } catch (t: Throwable) {
        log("【GeoFGS】watchdog startForeground failed: ${t.javaClass.simpleName}:${t.message}")
      }
    }
    mainHandler.postDelayed(watchdog, 2500L)

    thread(name = "geo-fgs") {
      try {
        log("【GeoFGS】start reason=$reason")

        // Try to get a better fix than quick-check.
        val fix = runCatching {
          LocationCore.getBestFixPreferSystem(
            this,
            targetAccMeters = 80f,
            timeoutMs = 4500L,
            baiduTimeoutMs = 6500L,
            allowLastKnown = true,
          )
        }.getOrNull()

        if (fix == null) {
          log("【GeoFGS】fix=null (reason=$reason)")
        } else {
          GeoRuleEvaluator.evaluateAndNotify(this, fix, source = "fgs:$reason")
        }
      } catch (t: Throwable) {
        log("【GeoFGS】exception: ${t.javaClass.simpleName}:${t.message}")
      } finally {
        finished.set(true)
        try { mainHandler.removeCallbacks(watchdog) } catch (_: Throwable) {}

        try {
          if (foregroundStarted.get()) {
            // remove foreground notification
            stopForeground(true)
          }
        } catch (_: Throwable) {}

        try { stopSelf(startId) } catch (_: Throwable) {}
        log("【GeoFGS】stopSelf done")
      }
    }

    return START_NOT_STICKY
  }

  private fun startForegroundInternal() {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val channelId = "geo_fgs_v1"
    if (Build.VERSION.SDK_INT >= 26) {
      val existing = nm.getNotificationChannel(channelId)
      if (existing == null) {
        val ch = NotificationChannel(channelId, "定位服务", NotificationManager.IMPORTANCE_MIN)
        nm.createNotificationChannel(ch)
      }
    }

    val notif: Notification = NotificationCompat.Builder(this, channelId)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setContentTitle("正在定位")
      .setContentText("用于地点提醒")
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_MIN)
      .build()

    startForeground(41001, notif)
  }

  private fun log(msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(this, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(this, null, msg) } catch (_: Throwable) {}
    }
  }
}
