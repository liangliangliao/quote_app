package com.example.quote_app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.KeyguardManager
import android.content.Context
import android.view.accessibility.AccessibilityEvent

/**
 * Optional but highly reliable unlock trigger.
 *
 * When the user enables this Accessibility Service, the system will keep it bound
 * and will (re)start the app process as needed, so unlock events can be captured
 * even when the app is in background or the process has been killed.
 */
class UnlockAccessibilityService : AccessibilityService() {

  private var lastLocked: Boolean? = null
  private var lastTriggerTs: Long = 0L

  override fun onServiceConnected() {
    super.onServiceConnected()
    // Keep event list minimal; we only need window changes to infer unlock.
    val info = serviceInfo ?: AccessibilityServiceInfo()
    info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
      AccessibilityEvent.TYPE_WINDOWS_CHANGED or
      AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
    info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
    info.notificationTimeout = 0
    serviceInfo = info

    lastLocked = isLocked()
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    if (event == null) return

    // Light filtering: most unlock related transitions come from system ui.
    val pkg = event.packageName?.toString() ?: ""
    if (pkg.isNotEmpty()) {
      val p = pkg.lowercase()
      val isSystemUi = p.contains("systemui") || p.contains("launcher") || p.contains("keyguard")
      if (!isSystemUi) {
        // still allow some OEM packages, but avoid heavy noise
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
      }
    }

    val lockedNow = isLocked()
    val lockedBefore = lastLocked
    lastLocked = lockedNow

    // Trigger on transition: locked -> unlocked
    if (lockedBefore == true && lockedNow == false) {
      val now = System.currentTimeMillis()
      if (now - lastTriggerTs > 1200L) {
        lastTriggerTs = now
        UnlockOrchestrator.onUnlock(this, source = "a11y", allowStartGeoForeground = true)
      }
    }
  }

  override fun onInterrupt() {
    // no-op
  }

  private fun isLocked(): Boolean {
    return try {
      val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
      if (android.os.Build.VERSION.SDK_INT >= 23) {
        km.isDeviceLocked
      } else {
        km.isKeyguardLocked
      }
    } catch (_: Throwable) {
      // fallback to keyguard locked state
      try {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        km.isKeyguardLocked
      } catch (_: Throwable) {
        false
      }
    }
  }
}
