package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread

/**
 * 解锁广播入口（方案B + 即时触发）：
 * - 使用 goAsync + 后台线程，避免在广播主线程做耗时操作。
 * - 先跑 fast-path（轻提醒 + 地点 quick check），再触发 WorkManager 兜底。
 * - 最终仍不会让通知栏出现常驻通知（只有在 quick check 需要兜底时才可能短暂启动前台服务）。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val app = context.applicationContext
    val pending = goAsync()

    thread(name = "unlock-receiver") {
      try {
        val action = intent?.action ?: "unknown"
        logWithTime(app, "【解锁后台】收到解锁广播($action)，进入 UnlockOrchestrator")
        // allowStartGeoForeground=true (scheme B): 若 quick check 取不到位置，会尝试短前台服务兜底
        UnlockOrchestrator.onUnlock(app, source = "receiver:$action", allowStartGeoForeground = true)
      } catch (t: Throwable) {
        logWithTime(app, "【解锁后台】UnlockReceiver 异常：" + (t.message ?: "unknown"))
      } finally {
        try { pending.finish() } catch (_: Throwable) {}
      }
    }
  }

  /** 写入包含时间戳的中文日志。 */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
