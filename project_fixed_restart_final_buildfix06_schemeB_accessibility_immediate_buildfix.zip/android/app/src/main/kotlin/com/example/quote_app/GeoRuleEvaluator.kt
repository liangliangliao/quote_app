package com.example.quote_app

import android.content.Context
import android.location.Location
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbRepo
import org.json.JSONObject
import kotlin.math.min

/**
 * Evaluate all enabled geo triggers and send ONE notification if ANY target is in range.
 *
 * Behavior:
 * - Always iterate all enabled geo triggers from DB.
 * - If any target is within the effective threshold, send a single geo reminder and stop.
 * - Uses a simple cooldown in SharedPreferences to avoid spamming on frequent unlock events.
 */
object GeoRuleEvaluator {

  data class Target(
    val id: String,
    val place: String,
    val note: String,
    val lat: Double,
    val lng: Double,
    val coordType: String?,
  )

  private fun log(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return false
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
          if (c.moveToFirst()) (c.getInt(0) == 1) else false
        }
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { false }
  }

  private fun loadTargets(ctx: Context): List<Target> {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return emptyList()
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        val out = ArrayList<Target>()
        db.rawQuery("SELECT id, config FROM vision_triggers WHERE enabled=1 AND type='geo' ORDER BY updated_at DESC", null).use { c ->
          while (c.moveToNext()) {
            val id = c.getString(0) ?: continue
            val cfgStr = c.getString(1) ?: ""
            if (cfgStr.isBlank()) continue
            try {
              val jo = JSONObject(cfgStr)
              val lat = jo.optDouble("lat", Double.NaN)
              val lng = jo.optDouble("lng", Double.NaN)
              if (lat.isNaN() || lng.isNaN()) continue
              val place = jo.optString("place", "")
              val note = jo.optString("note", "")
              val coordType = jo.optString("coordType", null)
              out.add(Target(id, place, note, lat, lng, coordType))
            } catch (_: Throwable) {
              // ignore per-row parse failure
            }
          }
        }
        out
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) {
      emptyList()
    }
  }

  private fun inCooldown(ctx: Context): Boolean {
    return try {
      val prefs = ctx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
      val last = prefs.getLong("last_geo_reminder_time", 0L)
      if (last <= 0L) return false
      val now = System.currentTimeMillis()
      // default geo cooldown: 10 minutes
      val cooldownMs = 10L * 60L * 1000L
      (now - last) < cooldownMs
    } catch (_: Throwable) {
      false
    }
  }

  private fun markCooldown(ctx: Context) {
    try {
      val prefs = ctx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
      prefs.edit().putLong("last_geo_reminder_time", System.currentTimeMillis()).apply()
    } catch (_: Throwable) {}
  }

  private fun distanceMeters(aLat: Double, aLng: Double, bLat: Double, bLng: Double): Double {
    val out = FloatArray(1)
    Location.distanceBetween(aLat, aLng, bLat, bLng, out)
    return out[0].toDouble()
  }

  private fun distanceToTargetBdSpace(
    current: LocationCore.Fix,
    target: Target,
  ): Double {
    // Convert current to BD09 space
    val curBd = CoordUtil.toBd09(current.latitude, current.longitude, current.coordType)

    // Determine target coord type; for legacy rows without coordType, we try both wgs84 and bd09ll
    val t = (target.coordType ?: "").trim().lowercase()
    val candidates = if (t.isNotEmpty()) {
      listOf(t)
    } else {
      listOf("wgs84", "bd09ll")
    }

    var best = Double.MAX_VALUE
    for (ct in candidates) {
      val tgtBd = CoordUtil.toBd09(target.lat, target.lng, ct)
      val d = distanceMeters(curBd[0], curBd[1], tgtBd[0], tgtBd[1])
      if (d < best) best = d
    }
    return best
  }

  /**
   * Returns true if notification was sent.
   */
  fun evaluateAndNotify(ctx: Context, fix: LocationCore.Fix, source: String): Boolean {
    if (!isLocationRulesEnabled(ctx)) {
      log(ctx, "【GeoEval】开关关闭，跳过 source=$source")
      return false
    }

    if (inCooldown(ctx)) {
      log(ctx, "【GeoEval】处于冷却期，跳过 source=$source")
      return false
    }

    val targets = loadTargets(ctx)
    if (targets.isEmpty()) {
      log(ctx, "【GeoEval】无启用地点规则，跳过 source=$source")
      return false
    }

    val baseThreshold = 100.0
    val acc = fix.accuracyMeters.toDouble().coerceAtLeast(0.0)
    val extra = min(80.0, acc) // accuracy fudge
    val threshold = baseThreshold + extra

    var bestTarget: Target? = null
    var bestDist = Double.MAX_VALUE
    var hitTarget: Target? = null
    var hitDist = Double.MAX_VALUE

    // Traverse ALL targets; send once if ANY is within threshold.
    for (t in targets) {
      val d = runCatching { distanceToTargetBdSpace(fix, t) }.getOrNull() ?: continue
      if (d < bestDist) {
        bestDist = d
        bestTarget = t
      }
      if (d <= threshold && d < hitDist) {
        hitDist = d
        hitTarget = t
      }
    }

    // Prefer a target that is in range; otherwise keep closest for debugging logs.
    if (hitTarget != null) {
      bestTarget = hitTarget
      bestDist = hitDist
    }

    if (bestTarget == null) {
      log(ctx, "【GeoEval】目标为空，跳过 source=$source")
      return false
    }

    log(ctx, "【GeoEval】bestDist=${"%.1f".format(bestDist)}m threshold=${"%.1f".format(threshold)}m provider=${fix.provider} acc=${fix.accuracyMeters} source=$source")

    if (bestDist <= threshold) {
      val place = bestTarget!!.place.trim()
      val note = bestTarget!!.note.trim()
      val body = when {
        note.isNotEmpty() -> note
        place.isNotEmpty() -> "你已到达「$place」，别忘了今天的一件事。"
        else -> "你已到达目标地点，别忘了今天的一件事。"
      }
      try {
        NotifyHelper.sendUnlockReminder(ctx, 901001, "愿景提醒", body)
        markCooldown(ctx)
        log(ctx, "【GeoEval】命中并已发送地点提醒，targetId=${bestTarget!!.id}")
        return true
      } catch (t: Throwable) {
        log(ctx, "【GeoEval】发送地点提醒失败: ${t.message ?: "unknown"}")
      }
    }
    return false
  }
}
