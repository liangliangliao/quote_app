package com.example.quote_app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Unified "get current location" logic for both:
 * - manual "tap locate" in geo rule UI
 * - background geo reminder checks
 *
 * Default order (per new requirement):
 *   1) System high accuracy stream (Fused, then GPS/Network)
 *   2) Baidu SDK stream (BD09LL)
 *   3) Last known location
 */
object LocationCore {

  data class Fix(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val provider: String,
    val coordType: String,
  )

  @SuppressLint("MissingPermission")
  fun getBestFixPreferSystem(
    ctx: Context,
    targetAccMeters: Float = 80f,
    timeoutMs: Long = 1800L,
    baiduTimeoutMs: Long = 6000L,
    allowBaiduFallback: Boolean = true,
    allowLastKnown: Boolean = true,
  ): Fix? {
    // 1) System high accuracy stream
    val sys = runCatching { getSystemHighAccuracy(ctx, targetAccMeters.toDouble(), timeoutMs) }.getOrNull()
    if (sys != null) {
      return Fix(sys.latitude, sys.longitude, sys.accuracy, sys.provider ?: "system", "wgs84")
    }

    // 2) Baidu SDK
    if (allowBaiduFallback) {
    val bd = runCatching {
      var out: BaiduLocator.Simple? = null
      val latch = CountDownLatch(1)
      BaiduLocator.getOnce(ctx, allowSystemFallback = false) {
        out = it
        latch.countDown()
      }
      latch.await(baiduTimeoutMs, TimeUnit.MILLISECONDS)
      out
    }.getOrNull()

    if (bd != null) {
      return Fix(bd.latitude, bd.longitude, bd.accuracy, "baidu", "bd09ll")
    }

    }
    // 3) Last known
    if (allowLastKnown) {
      val last = runCatching { getLastKnown(ctx) }.getOrNull()
      if (last != null) {
        return Fix(last.latitude, last.longitude, last.accuracy, last.provider ?: "last_known", "wgs84")
      }
    }

    return null
  }

  @SuppressLint("MissingPermission")
  fun getSystemHighAccuracy(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    // Try Fused first
    val fused = runCatching { obtainFusedHighAcc(ctx, targetAccMeters, timeoutMs) }.getOrNull()
    if (fused != null) return fused
    // Fallback GPS/Network
    return runCatching { obtainGpsHighAcc(ctx, targetAccMeters, timeoutMs) }.getOrNull()
  }

  @SuppressLint("MissingPermission")
  private fun obtainFusedHighAcc(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val client = LocationServices.getFusedLocationProviderClient(ctx)
      val latch = CountDownLatch(1)
      var best: Location? = null

      val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 500L)
        .setWaitForAccurateLocation(true)
        .setMaxUpdates(5)
        .build()

      val cb = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
          for (l in result.locations) {
            if (best == null || l.accuracy < best!!.accuracy) best = l
          }
          if (best != null && best!!.accuracy <= targetAccMeters) {
            latch.countDown()
          }
        }
      }

      try { client.requestLocationUpdates(req, cb, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { client.removeLocationUpdates(cb) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) {
      null
    }
  }

  @SuppressLint("MissingPermission")
  private fun obtainGpsHighAcc(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val latch = CountDownLatch(1)
      var best: Location? = null

      val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
          if (best == null || loc.accuracy < best!!.accuracy) best = loc
          if (best != null && best!!.accuracy <= targetAccMeters) {
            latch.countDown()
          }
        }

        @Deprecated("deprecated")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
      }

      try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, listener, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500L, 0f, listener, Looper.getMainLooper()) } catch (_: Throwable) {}

      try { latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) {
      null
    }
  }

  @SuppressLint("MissingPermission")
  private fun getLastKnown(ctx: Context): Location? {
    return try {
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
      providers.mapNotNull {
        try { lm.getLastKnownLocation(it) } catch (_: Throwable) { null }
      }.maxByOrNull { it.time }
    } catch (_: Throwable) {
      null
    }
  }
}
