package com.example.quote_app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * Immediate unlock "light nudge" sender.
 *
 * This mirrors UnlockWorker logic but runs synchronously without WorkManager delay.
 */
object UnlockNudgeEngine {

  private fun log(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun getUnlockSwitchEnabled(ctx: Context): Boolean {
    return try {
      val cc = DbInspector.loadOrLightScan(ctx) ?: return false
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1", null).use { c ->
          if (c.moveToFirst()) {
            val v = c.getString(0) ?: "0"
            v == "1" || v.equals("true", ignoreCase = true)
          } else false
        }
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { false }
  }

  private fun getUnlockCooldownHours(ctx: Context): Double {
    return try {
      val cc = DbInspector.loadOrLightScan(ctx) ?: return 2.0
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT value FROM notify_config WHERE key='unlock_cooldown_hours' LIMIT 1", null).use { c ->
          if (c.moveToFirst()) {
            val v = c.getString(0) ?: "2"
            (v.toDoubleOrNull() ?: 2.0).coerceAtLeast(0.0)
          } else 2.0
        }
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { 2.0 }
  }

  /**
   * Returns true if a notification was posted.
   */
  fun tryNotifyNow(ctx: Context, source: String): Boolean {
    val appCtx = ctx.applicationContext

    if (!getUnlockSwitchEnabled(appCtx)) {
      log(appCtx, "【UnlockFast】开关关闭，跳过 source=$source")
      return false
    }

    val cooldownHours = getUnlockCooldownHours(appCtx)
    val cooldownMs = (cooldownHours * 3600_000.0).toLong().coerceAtLeast(0L)

    val prefs = appCtx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
    val last = prefs.getLong("last_unlock_reminder_time", 0L)
    val now = System.currentTimeMillis()

    if (cooldownMs > 0 && last > 0 && now - last < cooldownMs) {
      log(appCtx, "【UnlockFast】冷却中，剩余=${(cooldownMs - (now - last)) / 1000}s source=$source")
      return false
    }

    return try {
      NotifyHelper.sendUnlockReminder(appCtx, 10086, "愿景提醒", "解锁一下，想起今天的一件事。")
      prefs.edit().putLong("last_unlock_reminder_time", now).apply()
      log(appCtx, "【UnlockFast】已发送 source=$source")
      true
    } catch (t: Throwable) {
      log(appCtx, "【UnlockFast】发送失败: ${t.message ?: "unknown"} source=$source")
      false
    }
  }
}
