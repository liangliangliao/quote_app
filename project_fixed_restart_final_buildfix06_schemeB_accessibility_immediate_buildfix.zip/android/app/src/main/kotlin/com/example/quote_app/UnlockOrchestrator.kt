package com.example.quote_app

import android.content.Context
import android.content.Intent
import com.example.quote_app.data.DbRepo

/**
 * Central entry for "unlock" signal, used by:
 * - manifest BroadcastReceiver (UnlockReceiver)
 * - Accessibility service (UnlockAccessibilityService)
 *
 * It runs fast-path logic immediately, then schedules WorkManager as fallback.
 */
object UnlockOrchestrator {

  private fun log(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  /**
   * @param allowStartGeoForeground When true, we may start a short-lived GeoForegroundService
   *                                (scheme B) if quick location is unavailable.
   */
  fun onUnlock(ctx: Context, source: String, allowStartGeoForeground: Boolean = true) {
    val appCtx = ctx.applicationContext

    // Global dedupe: avoid double triggers from USER_PRESENT + USER_UNLOCKED, or receiver + a11y.
    val prefs = appCtx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
    val now = System.currentTimeMillis()
    val last = prefs.getLong("last_unlock_event_ts", 0L)
    if (now - last < 1500L) {
      return
    }
    prefs.edit().putLong("last_unlock_event_ts", now).apply()

    log(appCtx, "【UnlockOrch】onUnlock source=$source")

    // 1) Unlock nudge fast-path (no WorkManager)
    runCatching { UnlockNudgeEngine.tryNotifyNow(appCtx, source) }

    // 2) Geo fast-path
    val geoRes = runCatching { GeoQuickCheck.tryOnce(appCtx, source) }.getOrNull()
    if (geoRes != null && geoRes.needFallback && allowStartGeoForeground) {
      // Start a short-lived foreground service only if needed.
      try {
        val intent = Intent(appCtx, GeoForegroundService::class.java).apply {
          putExtra("reason", "unlock:$source")
        }
        // startForegroundService on O+; service itself will delay startForeground.
        if (android.os.Build.VERSION.SDK_INT >= 26) {
          appCtx.startForegroundService(intent)
        } else {
          appCtx.startService(intent)
        }
        log(appCtx, "【UnlockOrch】GeoForegroundService started (schemeB) source=$source")
      } catch (t: Throwable) {
        log(appCtx, "【UnlockOrch】GeoForegroundService start failed: ${t.javaClass.simpleName}:${t.message}")
      }
    }

    // 3) WorkManager fallback (may be delayed by system)
    runCatching { UnlockWorker.trigger(appCtx) }
    runCatching { GeoWorker.triggerOnce(appCtx, reason = "unlock:$source") }
  }
}
