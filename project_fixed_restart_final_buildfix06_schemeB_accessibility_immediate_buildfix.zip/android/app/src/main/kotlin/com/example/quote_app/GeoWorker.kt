package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.quote_app.data.DbRepo
import java.util.concurrent.TimeUnit

/**
 * Background geo reminder worker.
 *
 * Updated behavior:
 * - Location retrieval order matches manual "tap locate":
 *   System high-accuracy stream -> Baidu SDK -> lastKnown
 * - Always遍历数据库中所有启用的目标位置；只要命中任意一个，就发送一次提醒。
 */
class GeoWorker(
  appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  private fun log(msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(applicationContext, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(applicationContext, null, msg) } catch (_: Throwable) {}
    }
  }

  override suspend fun doWork(): Result {
    val reason = inputData.getString("reason") ?: "periodic"
    log("【GeoWorker】doWork start reason=$reason")

    val fix = try {
      LocationCore.getBestFixPreferSystem(
        applicationContext,
        targetAccMeters = 80f,
        timeoutMs = 8000L,
        baiduTimeoutMs = 8000L,
        allowLastKnown = true,
      )
    } catch (_: Throwable) {
      null
    }

    if (fix == null) {
      log("【GeoWorker】fix=null, skip")
      return Result.success()
    }

    try {
      GeoRuleEvaluator.evaluateAndNotify(applicationContext, fix, source = "worker:$reason")
    } catch (t: Throwable) {
      log("【GeoWorker】evaluate exception: ${t.javaClass.simpleName}:${t.message}")
    }

    log("【GeoWorker】doWork end")
    return Result.success()
  }

  companion object {
    private const val UNIQUE_NAME = "vision_geo_worker"
    private const val UNIQUE_ONCE = "vision_geo_worker_once"

    /**
     * 立即触发一次性地点规则检查（用于解锁后尽快刷新）。
     * 使用 WorkManager expedited + unique work (REPLACE) 避免积压。
     */
    @JvmStatic
    fun triggerOnce(ctx: Context, reason: String? = null) {
      try {
        val data = Data.Builder().apply {
          if (reason != null) putString("reason", reason)
        }.build()
        val req = OneTimeWorkRequestBuilder<GeoWorker>()
          .setInputData(data)
          .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
          .addTag(UNIQUE_NAME)
          .addTag(UNIQUE_ONCE)
          .build()
        WorkManager.getInstance(ctx.applicationContext)
          .enqueueUniqueWork(UNIQUE_ONCE, ExistingWorkPolicy.REPLACE, req)
        try {
          val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
          val now = sdf.format(java.util.Date())
          DbRepo.log(ctx, null, "[$now] 【GeoWorker】已触发一次性地点规则检查（回包：OK）")
        } catch (_: Throwable) {}
      } catch (_: Throwable) {
        try {
          val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
          val now = sdf.format(java.util.Date())
          DbRepo.log(ctx, null, "[$now] 【GeoWorker】触发一次性地点规则检查失败（回包：FAIL）")
        } catch (_: Throwable) {}
      }
    }

    /**
     * Schedule the GeoWorker to run periodically every 15 minutes.
     */
    @JvmStatic
    fun schedule(context: Context) {
      val request = PeriodicWorkRequestBuilder<GeoWorker>(15, TimeUnit.MINUTES)
        .addTag(UNIQUE_NAME)
        .build()
      try {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
          UNIQUE_NAME,
          ExistingPeriodicWorkPolicy.REPLACE,
          request
        )
      } catch (_: Throwable) { /* ignore */ }
    }

    /**
     * 取消周期性的 GeoWorker（用于地点规则开关关闭时彻底停止后台自动定位）。
     */
    @JvmStatic
    fun cancel(ctx: Context) {
      try {
        WorkManager.getInstance(ctx.applicationContext)
          .cancelUniqueWork(UNIQUE_NAME)
      } catch (_: Throwable) { }
      try {
        DbRepo.log(ctx, null, "【GeoWorker】已取消周期任务（回包：OK）")
      } catch (_: Throwable) { }
    }
  }
}
