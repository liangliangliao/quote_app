package com.example.quote_app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * Fast-path geo check intended to run during unlock (BroadcastReceiver or Accessibility).
 *
 * Goals:
 * - Execute quickly (<= ~2s) without WorkManager delay.
 * - If a quick system high-accuracy fix is available, evaluate rules and send notifications.
 * - If location cannot be obtained quickly, return needFallback=true so caller can start
 *   GeoForegroundService / WorkManager as fallback.
 */
object GeoQuickCheck {

  data class Result(val success: Boolean, val needFallback: Boolean)

  private fun log(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isGeoRulesEnabled(ctx: Context): Boolean {
    return try {
      val cc = DbInspector.loadOrLightScan(ctx) ?: return false
      val db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
      try {
        db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
          if (c.moveToFirst()) (c.getInt(0) == 1) else false
        }
      } finally {
        try { db.close() } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {
      false
    }
  }

  /** Backward-compatible name used by UnlockOrchestrator. */
  fun tryOnce(ctx: Context, source: String): Result = run(ctx, source)

  /**
   * Quick check:
   * - targetAcc: 120m (fast) on unlock path
   * - timeout: ~1200ms
   */
  fun run(ctx: Context, source: String): Result {
    val appCtx = ctx.applicationContext

    if (!isGeoRulesEnabled(appCtx)) {
      log(appCtx, "【GeoQuick】开关关闭，跳过 source=$source")
      return Result(success = false, needFallback = false)
    }

    val fix = LocationCore.getBestFixPreferSystem(
      ctx = appCtx,
      targetAccMeters = 120f,
      timeoutMs = 1200L,
      baiduTimeoutMs = 2500L,
      allowBaiduFallback = true,
      allowLastKnown = true,
    )

    if (fix == null) {
      log(appCtx, "【GeoQuick】定位失败，needFallback=true source=$source")
      return Result(success = false, needFallback = true)
    }

    val sent = GeoRuleEvaluator.evaluateAndNotify(appCtx, fix, source)
    // If accuracy is very poor and we didn't send, ask for fallback to be safe.
    val needFallback = !sent && fix.accuracyMeters > 200f

    log(appCtx, "【GeoQuick】done sent=$sent needFallback=$needFallback provider=${fix.provider} acc=${fix.accuracyMeters} source=$source")
    return Result(success = sent, needFallback = needFallback)
  }
}
