
import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();
  List<Map<String, dynamic>> _tasks = [];
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;
    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _saveConfig() async {
    setState(() => _saving = true);
    try {
      await _configDao.save(
        apiKey: _apiKeyCtrl.text.trim(),
        model: _modelCtrl.text.trim(),
        endpoint: _endpointCtrl.text.trim(),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('配置已保存')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _rescheduleAll() async {
    await SchedulerService.scheduleNextForAll();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已重新安排所有任务')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('OpenAI 配置', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(controller: _apiKeyCtrl, decoration: const InputDecoration(labelText: 'API Key', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: _modelCtrl, decoration: const InputDecoration(labelText: '模型', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: _endpointCtrl, decoration: const InputDecoration(labelText: 'Endpoint', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: _saving ? null : _saveConfig,
            icon: const Icon(Icons.save),
            label: Text(_saving ? '保存中...' : '保存配置'),
          ),
          const Divider(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('任务列表', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
            ],
          ),
          ..._tasks.map((t) {
            final name = (t['name'] ?? '') as String;
            final start = (t['start_time'] ?? '') as String;
            final status = (t['status'] ?? '') as String;
            final type = (t['type'] ?? '') as String;
            return ListTile(
              leading: const Icon(Icons.alarm),
              title: Text(name.isEmpty ? '未命名任务' : name),
              subtitle: Text('时间: $start   类型: $type   状态: $status'),
            );
          }),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: _rescheduleAll,
            icon: const Icon(Icons.schedule),
            label: const Text('重新安排所有任务'),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
