import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');
  // Baidu 插件是否可用；如果发现 MissingPluginException，则标记为 false，后续不再调用 Baidu 通道。
  static bool _baiduPluginAvailable = true;

  /// 获取位置时希望的最大精度（半径）阈值，单位：米。
  /// 当精度大于此阈值时，将视为不满足高精度要求而继续回退到下一方案。
  static const double _desiredAccuracyMeters = 30.0;

  /// 最近一次成功定位所采用的提供者名称（baidu 或 system）。
  /// 如果定位失败或尚未调用，则为 null。
  static String? lastProvider;

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 优先尝试百度定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        // 检查精度：仅当满足阈值时才认为成功
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i('LocationService', '【定位】Baidu SDK成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w('LocationService', '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，回退系统定位');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_) {}
    }
    // 回退系统定位
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i('LocationService', '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w('LocationService', '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_) {}
    }
    // 再尝试使用系统最近一次已知位置作为兜底。
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}
    // 都失败
    lastProvider = null;
    try { await DLog.w('LocationService', '【定位】无法获取符合精度要求的位置'); } catch (_) {}
    return null;
  }

  
  /// 系统定位优先 -> Baidu 兜底 -> lastKnown 最终兜底。
  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1. 系统高精度
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try {
          await DLog.i(
            'LocationService',
            '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      } else if (sys != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)，尝试 Baidu 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位异常（优先分支）：$e',
        );
      } catch (_) {}
    }

    // 2. Baidu 兜底（如果插件可用）
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try {
          await DLog.i(
            'LocationService',
            '【定位】Baidu SDK 兜底成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      } else if (bd != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu SDK 兜底精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，尝试 lastKnown 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu SDK 兜底异常：$e',
        );
      } catch (_) {}
    }

    // 3. 最后使用最近一次已知位置兜底
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】系统/Baidu/lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

static Future<Position?> _getCurrentPositionHighAccuracy() async {
  final enabled = await Geolocator.isLocationServiceEnabled();
  if (!enabled) {
    try { await DLog.w('LocationService', '【定位】系统定位服务未开启'); } catch (_) {}
    return null;
  }
  LocationPermission perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    try { await DLog.w('LocationService', '【定位】未授予定位权限'); } catch (_) {}
    return null;
  }
  try {
    // 第一次：高精度 + 15s
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.best,
      timeLimit: const Duration(seconds: 15),
    );
  } on TimeoutException catch (e) {
    try { await DLog.w('LocationService','【定位】高精度定位超时，尝试中等精度：$e'); } catch (_){}
    try {
      // 第二次：中精度 + 20s
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 20),
      );
    } on TimeoutException catch (e2) {
      try { await DLog.w('LocationService','【定位】中等精度定位仍然超时：$e2'); } catch (_){}
      // 第三次：位置流拿第一条（低精度）+ 15s；Android 强制使用 LocationManager
      final low = await _getPositionByStreamOnce(
        accuracy: LocationAccuracy.low,
        timeout: const Duration(seconds: 15),
        forceLocationManager: true,
      );
      return low;
    } catch (e2) {
      try { await DLog.w('LocationService','【定位】中等精度定位异常：$e2'); } catch (_){}
      return null;
    }
  } catch (e) {
    try { await DLog.w('LocationService','【定位】系统定位异常：$e'); } catch (_){}
    return null;
  }

  /// 监听位置流，获取首个位置点；失败或超时返回 null。
  static Future<Position?> _getPositionByStreamOnce({
    LocationAccuracy accuracy = LocationAccuracy.low,
    Duration timeout = const Duration(seconds: 15),
    bool forceLocationManager = false,
  }) async {
    try {
      LocationSettings settings;
      if (Platform.isAndroid) {
        settings = AndroidSettings(
          accuracy: accuracy,
          distanceFilter: 0,
          forceLocationManager: forceLocationManager,
        );
      } else {
        settings = LocationSettings(
          accuracy: accuracy,
          distanceFilter: 0,
        );
      }
      final stream = Geolocator.getPositionStream(locationSettings: settings);
      final pos = await stream.first.timeout(timeout);
      return pos;
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取超时：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

}

  /// 仅使用系统最近一次已知位置，失败返回 null。
  static Future<Position?> _getLastKnownPosition() async {
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        try { await DLog.i('LocationService', '【定位】使用系统最近一次已知位置: acc=${last.accuracy}m, lat=${last.latitude}, lon=${last.longitude}'); } catch (_){}
      }
      return last;
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】获取系统最近一次已知位置异常：$e'); } catch (_){}
      return null;
    }
  }

  /// 单次调用百度 SDK 获取位置。如果插件不可用或调用失败，返回 null。
  static Future<Position?> _baiduSdkLocationOnce() async {
    if (!_baiduPluginAvailable) return null;
    try {
      await _sysCh.invokeMethod('getBaiduLocationOnce');
      return null;
    } on MissingPluginException catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 插件未注册或方法未实现，后续改为仅使用系统定位: $e'); } catch(_){}
      _baiduPluginAvailable = false;
      return null;
    } on PlatformException catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 调用失败：$e'); } catch(_){}
      return null;
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 未知异常：$e'); } catch(_){}
      return null;
    }
  }

  /// 尝试做一次逆地理，记录附近标志物信息，仅用于调试日志。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      final placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
      if (placemarks.isEmpty) return;
      final p = placemarks.first;
      final parts = <String?>[p.name, p.street, p.subLocality, p.locality, p.administrativeArea]
        .where((e) => e != null && e!.isNotEmpty).map((e) => e!).toList();
      final desc = parts.isEmpty ? '未知标志物' : parts.join(' ');
      try { await DLog.i('LocationService', '【定位】逆地理附近标志物: $desc (lat=${pos.latitude}, lon=${pos.longitude})'); } catch(_){}
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】逆地理查询附近标志物失败：$e'); } catch(_){}
    }
  }

  /// 使用系统逆地理简单构造附近地点列表（伪 POI），以保证页面正常工作。
  static Future<List<PoiItem>> fetchNearbyPoisSystem({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String? keyword,
    required int page,
    required int pageSize,
  }) async {
    try {
      final placemarks = await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isEmpty) return <PoiItem>[];
      final List<PoiItem> list = [];
      for (final p in placemarks) {
        final nm = (p.name?.isNotEmpty == true) ? p.name! : (p.street?.isNotEmpty == true ? p.street! : '当前位置附近');
        final addrParts = <String?>[p.street, p.subLocality, p.locality, p.administrativeArea]
          .where((e) => e != null && e!.isNotEmpty).map((e) => e!).toList();
        final addr = addrParts.isEmpty ? null : addrParts.join(' ');
        list.add(PoiItem(name: nm, address: addr, latitude: latitude, longitude: longitude, distanceMeters: 0));
      }
      final start = (page * pageSize).clamp(0, list.length);
      final end = ((page + 1) * pageSize).clamp(0, list.length);
      return list.sublist(start, end);
    } catch (e) {
      try { await DLog.w('LocationService', '【地点】系统逆地理获取附近地点失败：$e'); } catch(_){}
      return <PoiItem>[];
    }
  }

  /// 统一对外的附近地点查询（当前复用系统逆地理实现）。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String? keyword,
    required int page,
    required int pageSize,
  }) {
    return fetchNearbyPoisSystem(
      latitude: latitude,
      longitude: longitude,
      radiusMeters: radiusMeters,
      keyword: keyword,
      page: page,
      pageSize: pageSize,
    );
  }

  /// 监听位置流，在给定时限内拿到第一条位置后返回；超时返回 null。
  static Future<Position?> _getPositionByStreamOnce({
    LocationAccuracy accuracy = LocationAccuracy.low,
    Duration timeout = const Duration(seconds: 15),
    bool forceLocationManager = false,
  }) async {
    try {
      LocationSettings settings;
      if (Platform.isAndroid) {
        settings = AndroidSettings(
          accuracy: accuracy,
          distanceFilter: 0,
          forceLocationManager: forceLocationManager,
        );
      } else {
        settings = LocationSettings(accuracy: accuracy, distanceFilter: 0);
      }
      final stream = Geolocator.getPositionStream(locationSettings: settings);
      final pos = await stream.first.timeout(timeout);
      return pos;
    } on TimeoutException catch (e) {
      try { await DLog.w('LocationService', '【定位】位置流获取超时：$e'); } catch(_){}
      return null;
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】位置流获取异常：$e'); } catch(_){}
      return null;
    }
  }

import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');
  // Baidu 插件是否可用；如果发现 MissingPluginException，则标记为 false，后续不再调用 Baidu 通道。
  static bool _baiduPluginAvailable = true;

  /// 获取位置时希望的最大精度（半径）阈值，单位：米。
  /// 当精度大于此阈值时，将视为不满足高精度要求而继续回退到下一方案。
  static const double _desiredAccuracyMeters = 30.0;

  /// 最近一次成功定位所采用的提供者名称（baidu 或 system）。
  /// 如果定位失败或尚未调用，则为 null。
  static String? lastProvider;

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 优先尝试百度定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        // 检查精度：仅当满足阈值时才认为成功
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i('LocationService', '【定位】Baidu SDK成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w('LocationService', '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，回退系统定位');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_) {}
    }
    // 回退系统定位
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i('LocationService', '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w('LocationService', '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_) {}
    }
    // 再尝试使用系统最近一次已知位置作为兜底。
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}
    // 都失败
    lastProvider = null;
    try { await DLog.w('LocationService', '【定位】无法获取符合精度要求的位置'); } catch (_) {}
    return null;
  }

  
  /// 系统定位优先 -> Baidu 兜底 -> lastKnown 最终兜底。
  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1. 系统高精度
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try {
          await DLog.i(
            'LocationService',
            '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      } else if (sys != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)，尝试 Baidu 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位异常（优先分支）：$e',
        );
      } catch (_) {}
    }

    // 2. Baidu 兜底（如果插件可用）
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try {
          await DLog.i(
            'LocationService',
            '【定位】Baidu SDK 兜底成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
          );
        } catch (_) {}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      } else if (bd != null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu SDK 兜底精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，尝试 lastKnown 兜底',
          );
        } catch (_) {}
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu SDK 兜底异常：$e',
        );
      } catch (_) {}
    }

    // 3. 最后使用最近一次已知位置兜底
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】系统/Baidu/lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

static Future<Position?> _getCurrentPositionHighAccuracy() async {
  final enabled = await Geolocator.isLocationServiceEnabled();
  if (!enabled) {
    try { await DLog.w('LocationService', '【定位】系统定位服务未开启'); } catch (_) {}
    return null;
  }
  LocationPermission perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    try { await DLog.w('LocationService', '【定位】未授予定位权限'); } catch (_) {}
    return null;
  }
  try {
    // 第一次：高精度 + 15s
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.best,
      timeLimit: const Duration(seconds: 15),
    );
  } on TimeoutException catch (e) {
    try { await DLog.w('LocationService','【定位】高精度定位超时，尝试中等精度：$e'); } catch (_){}
    try {
      // 第二次：中精度 + 20s
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 20),
      );
    } on TimeoutException catch (e2) {
      try { await DLog.w('LocationService','【定位】中等精度定位仍然超时：$e2'); } catch (_){}
      // 第三次：位置流拿第一条（低精度）+ 15s；Android 强制使用 LocationManager
      final low = await _getPositionByStreamOnce(
        accuracy: LocationAccuracy.low,
        timeout: const Duration(seconds: 15),
        forceLocationManager: true,
      );
      return low;
    } catch (e2) {
      try { await DLog.w('LocationService','【定位】中等精度定位异常：$e2'); } catch (_){}
      return null;
    }
  } catch (e) {
    try { await DLog.w('LocationService','【定位】系统定位异常：$e'); } catch (_){}
    return null;
  }

  /// 监听位置流，获取首个位置点；失败或超时返回 null。
  static Future<Position?> _getPositionByStreamOnce({
    LocationAccuracy accuracy = LocationAccuracy.low,
    Duration timeout = const Duration(seconds: 15),
    bool forceLocationManager = false,
  }) async {
    try {
      LocationSettings settings;
      if (Platform.isAndroid) {
        settings = AndroidSettings(
          accuracy: accuracy,
          distanceFilter: 0,
          forceLocationManager: forceLocationManager,
        );
      } else {
        settings = LocationSettings(
          accuracy: accuracy,
          distanceFilter: 0,
        );
      }
      final stream = Geolocator.getPositionStream(locationSettings: settings);
      final pos = await stream.first.timeout(timeout);
      return pos;
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取超时：$e',
        );
      } catch (_) {}
      return null;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】位置流获取异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

}
