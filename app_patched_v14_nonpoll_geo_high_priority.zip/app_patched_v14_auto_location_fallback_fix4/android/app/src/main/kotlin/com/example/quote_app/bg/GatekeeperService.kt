package com.example.quote_app.bg
import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ActivityCompat
import androidx.work.*
import com.example.quote_app.*
import com.example.quote_app.data.DbRepo

class GatekeeperService : Service() {
  private val channelId = "gatekeeper_fg"
  override fun onCreate() {
    super.onCreate()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (nm.getNotificationChannel(channelId) == null) {
        nm.createNotificationChannel(NotificationChannel(channelId, "Gatekeeper Service", NotificationManager.IMPORTANCE_MIN))
      }
    }
    val n = NotificationCompat.Builder(this, channelId).setContentTitle("后台守护").setContentText("提高提醒稳定性").setSmallIcon(android.R.drawable.stat_notify_more).setOngoing(true).build()
    startForeground(11, n)
    val f = IntentFilter().apply {
      addAction(Intent.ACTION_SCREEN_ON)
      addAction(Intent.ACTION_USER_PRESENT)
      addAction(Intent.ACTION_USER_UNLOCKED)
    }
    registerReceiver(object: BroadcastReceiver(){
      override fun onReceive(c: Context, i: Intent) {
        try { DbRepo.log(c, null, "正在解锁屏幕将触发通知发送") } catch (_: Throwable) {}
        val granted = ActivityCompat.checkSelfPermission(c, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) {
          try {
            DbRepo.log(c, null, "正在发送通知")
            NotifyHelper.send(c, 2000, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null)
            DbRepo.log(c, null, "通知发送成功")
          } catch (_: Throwable) {}
        }
        try {
          val data = Data.Builder().putBoolean("force_unlock_geo", true).build()
          val req = OneTimeWorkRequestBuilder<GeoWorker>().setInputData(data).build()
          WorkManager.getInstance(c).enqueue(req)
        } catch (_: Throwable) {}
      }
    }, f)
  }
  override fun onStartCommand(i: Intent?, f: Int, s: Int): Int = START_STICKY
  override fun onBind(i: Intent?): IBinder? = null
  override fun onTaskRemoved(rootIntent: Intent?) {
    super.onTaskRemoved(rootIntent)
    // Schedule restart
    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val it = Intent(this, GatekeeperService::class.java)
    val pi = PendingIntent.getService(this, 2002, it, if (Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_UPDATE_CURRENT)
    val at = SystemClock.elapsedRealtime() + 3000L
    try { am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) } catch (_: Throwable) { am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
  }
}
