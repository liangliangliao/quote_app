package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.location.Geocoder
import android.database.sqlite.SQLiteDatabase
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.Locale
import com.example.quote_app.data.DbRepo
import java.util.concurrent.TimeUnit

/**
 * GeoWorker is a periodic WorkManager worker that polls the device's last
 * known location and compares it against any enabled geo vision triggers.
 * When the device is within a 200 meter radius of a configured place,
 * a notification is sent to remind the user of their intention at that
 * location.
 *
 * This implementation uses Android's LocationManager for a quick read
 * of the most recent location and the Geocoder API to resolve place
 * names to coordinates. It deliberately avoids continuous location
 * updates to conserve battery, instead running at a fixed interval.
 */
class GeoWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {
    override fun doWork(): Result {
        val ctx = applicationContext
        try {
            // Attempt to obtain a location. We first try the system's last known providers
            // to determine an approximate coordinate. With this coordinate we can check
            // whether the device is within mainland China. If so, we will prefer Baidu's
            // IP geolocation to obtain a more reliable location. Otherwise we keep the
            // system location. All steps are logged to the logs table.
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var currentLoc: Location? = null
            // Try to read the last known location from GPS then network providers
            run {
                val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                for (p in providers) {
                    try {
                        val loc = lm.getLastKnownLocation(p)
                        if (loc != null) {
                            currentLoc = loc
                            // Log provider used for this approximate location
                            try {
                                DbRepo.log(ctx, null, "[GeoWorker] provider=" + p + " location: lat=" + loc.latitude + ", lon=" + loc.longitude)
                            } catch (_: Throwable) {}
                            break
                        }
                    } catch (_: SecurityException) {
                        // Permission may be missing; ignore and continue
                    }
                }
            }
            // Load Baidu API key from database for later use
            var baiduAk: String? = null
            try {
                val contractAk = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx)
                if (contractAk != null && contractAk.dbPath != null) {
                    val dbAk = SQLiteDatabase.openDatabase(contractAk.dbPath, null, SQLiteDatabase.OPEN_READONLY)
                    val cAk = dbAk.rawQuery("SELECT value FROM notify_config WHERE key='baidu_ak' LIMIT 1", null)
                    if (cAk.moveToFirst()) {
                        baiduAk = cAk.getString(0)
                    }
                    cAk.close()
                    dbAk.close()
                }
            } catch (_: Throwable) {
                // ignore database errors when loading AK
            }
            // If we have an approximate location, determine if it's in mainland China
            if (currentLoc != null) {
                val lat = currentLoc.latitude
                val lon = currentLoc.longitude
                val inChina = lat >= 3.86 && lat <= 53.55 && lon >= 73.66 && lon <= 135.05
                if (inChina) {
                    // Log detection of China region
                    try {
                        DbRepo.log(ctx, null, "[GeoWorker] 检测目前所在地为中国将采用百度定位服务获取位置")
                    } catch (_: Throwable) {}
                    if (baiduAk != null && baiduAk!!.isNotBlank()) {
                        try {
                            val urlStr = java.net.URI("https://api.map.baidu.com/location/ip?ak=" +
                                    java.net.URLEncoder.encode(baiduAk, "UTF-8") + "&coor=gcj02").toURL().toString()
                            val url = java.net.URL(urlStr)
                            val conn = url.openConnection() as java.net.HttpURLConnection
                            conn.requestMethod = "GET"
                            conn.connectTimeout = 5000
                            conn.readTimeout = 5000
                            val responseCode = conn.responseCode
                            if (responseCode == 200) {
                                val resp = conn.inputStream.bufferedReader().use { it.readText() }
                                try {
                                    val json = org.json.JSONObject(resp)
                                    val content = json.optJSONObject("content")
                                    val point = content?.optJSONObject("point")
                                    val lonStr = point?.optString("x")
                                    val latStr = point?.optString("y")
                                    if (!latStr.isNullOrBlank() && !lonStr.isNullOrBlank()) {
                                        val latD = latStr.toDoubleOrNull()
                                        val lonD = lonStr.toDoubleOrNull()
                                        if (latD != null && lonD != null) {
                                            val loc = Location(LocationManager.NETWORK_PROVIDER)
                                            loc.latitude = latD
                                            loc.longitude = lonD
                                            currentLoc = loc
                                            // Log that Baidu IP provided a location
                                            try {
                                                DbRepo.log(ctx, null, "[GeoWorker] provider=BAIDU_IP location: lat=" + latD + ", lon=" + lonD)
                                            } catch (_: Throwable) {}
                                        }
                                    }
                                } catch (_: Throwable) {
                                    // JSON parsing error; ignore
                                }
                            }
                            conn.disconnect()
                        } catch (_: Throwable) {
                            // network error when calling Baidu; log and continue with system location
                            try {
                                DbRepo.log(ctx, null, "[GeoWorker] 调用百度定位服务出现异常，将采用系统默认定位服务获取位置")
                            } catch (_: Throwable) {}
                        }
                    } else {
                        // Baidu AK not configured; log and continue with system location
                        try {
                            DbRepo.log(ctx, null, "[GeoWorker] 检测目前所在地为中国但未配置百度AK，将采用系统默认定位获取位置")
                        } catch (_: Throwable) {}
                    }
                } else {
                    // Not in mainland China; log detection and continue with system location
                    try {
                        DbRepo.log(ctx, null, "[GeoWorker] 检测目前所在地为非中国地区，将采用系统默认定位获取位置")
                    } catch (_: Throwable) {}
                }
            } else {
                // We could not get any last known location. As a last resort, attempt Baidu IP if AK is available.
                if (baiduAk != null && baiduAk!!.isNotBlank()) {
                    try {
                        val urlStr = java.net.URI("https://api.map.baidu.com/location/ip?ak=" +
                                java.net.URLEncoder.encode(baiduAk, "UTF-8") + "&coor=gcj02").toURL().toString()
                        val url = java.net.URL(urlStr)
                        val conn = url.openConnection() as java.net.HttpURLConnection
                        conn.requestMethod = "GET"
                        conn.connectTimeout = 5000
                        conn.readTimeout = 5000
                        val responseCode = conn.responseCode
                        if (responseCode == 200) {
                            val resp = conn.inputStream.bufferedReader().use { it.readText() }
                            try {
                                val json = org.json.JSONObject(resp)
                                val content = json.optJSONObject("content")
                                val point = content?.optJSONObject("point")
                                val lonStr = point?.optString("x")
                                val latStr = point?.optString("y")
                                if (!latStr.isNullOrBlank() && !lonStr.isNullOrBlank()) {
                                    val latD = latStr.toDoubleOrNull()
                                    val lonD = lonStr.toDoubleOrNull()
                                    if (latD != null && lonD != null) {
                                        val loc = Location(LocationManager.NETWORK_PROVIDER)
                                        loc.latitude = latD
                                        loc.longitude = lonD
                                        currentLoc = loc
                                        try {
                                            DbRepo.log(ctx, null, "[GeoWorker] provider=BAIDU_IP location: lat=" + latD + ", lon=" + lonD)
                                        } catch (_: Throwable) {}
                                    }
                                }
                            } catch (_: Throwable) {
                                // JSON parse error
                            }
                        }
                        conn.disconnect()
                    } catch (_: Throwable) {
                        // network error; ignore
                    }
                }
            }
            // If still no location is available, we cannot evaluate geo triggers; bail out.
            if (currentLoc == null) return Result.success()

            // Load the database contract to locate the SQLite DB
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx)
            if (contract == null || contract.dbPath == null) return Result.success()
            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config, then_text FROM vision_triggers WHERE type='geo' AND enabled=1",
                null
            )
            val geocoder = Geocoder(ctx, Locale.getDefault())
            while (cursor.moveToNext()) {
                val cfgStr = cursor.getString(0) ?: ""
                val thenText = cursor.getString(1) ?: ""
                try {
                    val cfg = org.json.JSONObject(cfgStr)
                    val place = cfg.optString("place", "")
                    val userNote = cfg.optString("note", thenText)
                    val lat = if (cfg.has("lat")) cfg.optDouble("lat", Double.NaN) else Double.NaN
                    val lon = if (cfg.has("lng")) cfg.optDouble("lng", Double.NaN) else Double.NaN
                    var within = false
                    var displayName = place
                    // If lat/lon provided, compute distance directly
                    if (!lat.isNaN() && !lon.isNaN()) {
                        val distArr = FloatArray(1)
                        Location.distanceBetween(
                            currentLoc.latitude,
                            currentLoc.longitude,
                            lat,
                            lon,
                            distArr
                        )
                        if (distArr[0] < 200f) within = true
                        displayName = if (place.isNotEmpty()) place else "目标地点"
                    } else if (place.isNotEmpty()) {
                        val addrs = geocoder.getFromLocationName(place, 1)
                        if (addrs != null && addrs.isNotEmpty()) {
                            val trgLat = addrs[0].latitude
                            val trgLon = addrs[0].longitude
                            val distArr = FloatArray(1)
                            Location.distanceBetween(
                                currentLoc.latitude,
                                currentLoc.longitude,
                                trgLat,
                                trgLon,
                                distArr
                            )
                            if (distArr[0] < 200f) within = true
                        }
                    } else {
                        // No coordinates and no place name configured; log and skip
                        try {
                            DbRepo.log(ctx, null, "[GeoWorker] trigger skipped: no target coordinates or place")
                        } catch (_: Throwable) {}
                    }
                    if (within) {
                        val body: String = if (userNote.isNotEmpty()) userNote else "你已到达 $displayName ，别忘了你的目标"
                        val id = 3100 + ((displayName.hashCode()) and 0x7fffffff)
                        // Use vision_focus so tapping notification goes to focus page
                        NotifyHelper.send(ctx, id, "愿景地点提醒", body, null, "vision_geo", null)
                    }
                } catch (_: Throwable) {
                    // Ignore malformed JSON or geocoder failures
                }
            }
            cursor.close()
            db.close()
        } catch (_: Throwable) {
            // Swallow any errors; worker will succeed silently
        }
        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "vision_geo_worker"

        /**
         * Schedule the GeoWorker to run periodically every 15 minutes. If a worker is
         * already scheduled, it will be replaced. This should be invoked on boot
         * or when geo triggers are configured to ensure timely reminders.
         */
        @JvmStatic
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<GeoWorker>(15, TimeUnit.MINUTES)
                .addTag(UNIQUE_NAME)
                .build()
            try {
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    UNIQUE_NAME,
                    ExistingPeriodicWorkPolicy.REPLACE,
                    request
                )
            } catch (_: Throwable) { /* ignore */ }
        }
    }
}