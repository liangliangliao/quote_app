package com.example.quote_app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.content.Intent
import android.app.PendingIntent
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

object NotifyHelper {

  private fun ensureChannels(ctx: Context) {
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
      val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      // default channel (normal)
      if (nm.getNotificationChannel(DEFAULT_CHANNEL_ID) == null) {
        val ch = NotificationChannel(DEFAULT_CHANNEL_ID, "默认提醒", NotificationManager.IMPORTANCE_DEFAULT)
        nm.createNotificationChannel(ch)
      }
      // geo high channel
      if (nm.getNotificationChannel(GEO_CHANNEL_ID) == null) {
        val geo = NotificationChannel(GEO_CHANNEL_ID, GEO_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
        geo.enableVibration(true)
        geo.vibrationPattern = longArrayOf(0L, 250L, 150L, 350L)
        // use default notification sound
        try {
          val uri = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
          geo.setSound(uri, android.media.AudioAttributes.Builder()
              .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
              .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
              .build())
        } catch (_: Throwable) {}
        nm.createNotificationChannel(geo)
      }
    }
  }

  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val GEO_CHANNEL_ID = "quote_geo_high"
  private const val GEO_CHANNEL_NAME = "地点提醒（高优先级）"

  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val DEFAULT_CHANNEL_NAME = "Quotes"

  @JvmStatic
  fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    avatarPath: String?,
    notifType: String? = null,
    payload: String? = null
  ) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Android 13+ 需要 POST_NOTIFICATIONS 运行时权限；若缺失，静默失败。这里直接短路并记录。
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
        return
      }
    }

    // 系统级通知开关被关也会静默丢弃
    if (!nm.areNotificationsEnabled()) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: notifications disabled at system level") } catch (_: Throwable) {}
      return
    }

    // 8.0+ 必须先创建渠道
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(
        DEFAULT_CHANNEL_ID,
        DEFAULT_CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      )
      nm.createNotificationChannel(ch)
    }

    val builder = NotificationCompat.Builder(ctx, channelId)
      .setContentTitle(title)
      .setContentText(body)
      .setPriority(if (notifType == "vision_geo") NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
      .setDefaults(if (notifType == "vision_geo") NotificationCompat.DEFAULT_ALL else 0)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      // Open MainActivity when tapping notification; extras carry notification type and payload for navigation
      .apply {
        val launchIntent = Intent(ctx, MainActivity::class.java).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
          putExtra("from_notification", true)
          if (notifType != null) putExtra("notif_type", notifType)
          if (payload != null) putExtra("payload", payload)
        }
        val pi = PendingIntent.getActivity(
          ctx,
          1001,
          launchIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setContentIntent(pi)
      }


    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }

    nm.notify(id, builder.build())
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] posted id="+id+" chan="+DEFAULT_CHANNEL_ID) } catch (_: Throwable) {}
  }

  // 兼容旧版 Java 调用（仅有 avatarPath，缺少 notifType / payload）
  // Java 侧会匹配到这个重载方法，内部再委托给带完整参数的实现。
  @JvmStatic
  fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    avatarPath: String?
  ) {
    send(ctx, id, title, body, avatarPath, null, null)
  }
}
