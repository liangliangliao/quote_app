
import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  final String endpoint; // e.g., https://api.openai.com/v1/chat/completions
  final String apiKey;
  final String model;

  OpenAIService({required this.endpoint, required this.apiKey, required this.model});

  
Future<String> generateQuote(String prompt) async {
  final uri = Uri.parse(endpoint);
  final headers = {
    'Authorization': 'Bearer $apiKey',
    'Content-Type': 'application/json'
  };
  Map<String, dynamic> body;
  if (endpoint.contains('/responses')) {
    body = {
      'model': model,
      'input': '给我一句简洁的中文名人名言，并附带作者或来源。主题提示：' + prompt,
    };
  } else {
    // chat/completions fallback
    body = {
      'model': model,
      'messages': [
        {'role': 'system', 'content': '你是一位擅长中文名人名言的写手。'},
        {'role': 'user', 'content': '给我一句简洁的中文名人名言，并附带作者或来源。主题提示：' + prompt}
      ]
    };
  }
  final resp = await http.post(uri, headers: headers, body: jsonEncode(body));
  if (resp.statusCode >= 200 && resp.statusCode < 300) {
    final data = jsonDecode(utf8.decode(resp.bodyBytes));
    // Responses API
    if (data['output'] != null) {
      // output could be array of content parts
      final out = data['output'];
      if (out is List && out.isNotEmpty) {
        final first = out.first;
        if (first is Map && first['content'] is List && first['content'].isNotEmpty) {
          final txt = first['content'][0]['text']?['value'] ?? '';
          return txt.toString().trim();
        }
      }
    }
    // Chat Completions API
    final choices = data['choices'];
    if (choices is List && choices.isNotEmpty) {
      final msg = choices.first['message'];
      final content = (msg is Map) ? (msg['content'] ?? '') : '';
      return content.toString().trim();
    }
    if (data['content'] != null) return data['content'].toString().trim();
    throw Exception('未知返回结构');
  } else {
    throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
  }
}
;
    final body = jsonEncode({
      'model': model,
      'messages': [
        {'role': 'system', 'content': '你是一个返回名人名言的助手，只返回一句完整的名人名言，不要加其它解释。'},
        {'role': 'user', 'content': prompt}
      ],
      'temperature': 0.7,
      'max_tokens': 200
    });
    final resp = await http.post(uri, headers: headers, body: body);
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      final data = jsonDecode(resp.body);
      // try parse OpenAI format
      final choices = data['choices'];
      if (choices is List && choices.isNotEmpty) {
        final msg = choices.first['message'];
        final content = (msg is Map) ? (msg['content'] ?? '') : '';
        return content.toString().trim();
      }
      // fallback to anthropic-like 'content'
      if (data['content'] != null) return data['content'].toString().trim();
      throw Exception('未知返回结构');
    } else {
      throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
    }
  }
}
