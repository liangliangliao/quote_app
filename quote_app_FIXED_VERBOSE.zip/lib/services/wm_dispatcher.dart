import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'notification_service.dart';
import '../data/db.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    await DLog.i('WM', 'dispatcher start: task='+task.toString());
    // Step 1: ensure Flutter & plugins
    try { WidgetsFlutterBinding.ensureInitialized(); ui.DartPluginRegistrant.ensureInitialized(); await DLog.i('WM','plugins inited'); }
    catch (e) { await DLog.e('WM','plugins init error: ' + e.toString()); }
    // Step 2: init notifications
    try { await NotificationService.init(); await DLog.i('WM','NotificationService.init OK'); }
    catch (e) { await DLog.e('WM','NotificationService.init error: ' + e.toString()); }
    // Step 3: init database
    try { await AppDatabase.instance(); await DLog.i('WM','DB ready'); }
    catch (e) { await DLog.e('WM','DB init error: ' + e.toString()); }
    // Step 4: run callback
    try { await SchedulerService.callback(); await DLog.i('WM','SchedulerService.callback OK'); }
    catch (e) { await DLog.e('WM','SchedulerService.callback error: ' + e.toString()); }
    // Step 5: catchup (best-effort)
    try { await SchedulerService.catchupIfMissed(); await DLog.i('WM','catchupIfMissed OK'); }
    catch (e) { await DLog.e('WM','catchupIfMissed error: ' + e.toString()); }
    await DLog.i('WM', 'workmanager dispatch');
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    await SchedulerService.callback();
    // 补发一次（当天漏发）
    try {
      await SchedulerService.catchupIfMissed();
    } catch (e, s) {
      DLog.e('services/wm_dispatcher.dart', 'catch: ' + e.toString());
    }
    return true;
  });
}