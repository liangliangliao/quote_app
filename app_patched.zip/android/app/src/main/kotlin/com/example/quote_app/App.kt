package com.example.quote_app

import android.app.Application
import com.example.quote_app.GeoWorker
import com.example.quote_app.NotifyHelper
import com.example.quote_app.data.DbInspector
import android.database.sqlite.SQLiteDatabase
import android.content.Context

/**
 * Application (Flutter V2 embedding).
 * No custom plugin registrant callbacks are used.
 * Workmanager/plugin registration is handled by the framework and plugins themselves.
 */
class App : Application() {
  override fun onCreate() {
    super.onCreate()
    // Schedule the periodic GeoWorker so geo triggers run even if the device isn't rebooted.
    try {
      GeoWorker.schedule(this)
    } catch (_: Throwable) {
      // Ignore any failures silently
    }
    // Send a one-off unlock reminder when launching the app if the screen-unlock trigger is enabled.
    try {
      maybeSendUnlockReminderOnAppStart()
    } catch (_: Throwable) {
      // Ignore any failures silently
    }
    // Previously onCreate did nothing else.
  }

  /**
   * Check whether there is an active screen_unlock trigger in the vision_triggers table.
   * If so, send a gentle reminder notification immediately. This acts as a fallback
   * when system broadcast (e.g. USER_PRESENT) might be restricted on newer Android versions.
   */
  private fun maybeSendUnlockReminderOnAppStart() {
    try {
      // Check whether the app was opened very soon after a screen unlock. The
      // UnlockReceiver stores the most recent unlock timestamp in shared
      // preferences. If the app starts within a short window (e.g. 10 seconds)
      // of that timestamp, we'll send a reminder. This prevents sending
      // reminders when the user simply opens the app later on.
      val prefs = getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
      val last = prefs.getLong("last_unlock_time", 0L)
      val now = System.currentTimeMillis()
      val withinWindow = last > 0L && (now - last) <= 10_000L
      if (!withinWindow) {
        return
      }
      // Reset the stored timestamp so we don't repeatedly send reminders
      prefs.edit().putLong("last_unlock_time", 0L).apply()
      // Check that a screen_unlock trigger is actually enabled in the DB
      val contract = DbInspector.loadOrLightScan(this)
      if (contract == null || contract.dbPath == null) return
      val path = contract.dbPath!!
      val db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY)
      val c = db.rawQuery("SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1", null)
      val has = c.moveToFirst()
      c.close()
      db.close()
      if (has) {
        NotifyHelper.send(this, 2000, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null)
      }
    } catch (_: Throwable) {
      // swallow errors
    }
  }
}
