
package com.example.quote_app

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle

class FgKickActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    try {
      val intent = Intent(this, GeoForegroundService::class.java)
      if (Build.VERSION.SDK_INT >= 26) {
        startForegroundService(intent)
      } else {
        startService(intent)
      }
    } catch (_: Throwable) {}
    finish()
  }
}
