import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView 容器：统一处理“空白→兜底/动态”的展示与 JS 注入
class HomeHtmlView extends StatefulWidget {
  final String assetPath;                 // 兜底/模板 HTML
  final Map<String, dynamic>? data;       // null 表示兜底（无/异常）

  const HomeHtmlView({super.key, required this.assetPath, required this.data});

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _revealed = false; // 是否已经把内容展示给用户
  bool _currentHasData = false; // 跟踪当前页面是否已注入动态数据，避免兜底→动态转换时闪屏

  // 隐藏首页 HTML 所有可见元素。通过修改元素的不透明度隐藏，确保内容不可见且不发生布局重排
  Future<void> _hideHtml() async {
    const jsHide = '''
      (function(){
        try {
          var root = document.documentElement || document.body;
          if (root) {
            // Use opacity instead of visibility to avoid reflow and flicker.
            root.style.opacity = '0';
          }
          return true;
        } catch(e) { return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(jsHide);
    } catch (_) {
      // 在页面未准备好时可能会失败，稍后再次尝试
      await Future.delayed(const Duration(milliseconds: 50));
      try { await _controller.runJavaScriptReturningResult(jsHide); } catch(__) {}
    }
  }

  // 显示之前隐藏的 HTML 元素，将不透明度恢复为正常。使用 opacity 可以避免闪屏
  Future<void> _showHtml() async {
    const jsShow = '''
      (function(){
        try {
          var root = document.documentElement || document.body;
          if (root) {
            root.style.opacity = '1';
          }
          return true;
        } catch(e) { return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(jsShow);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 50));
      try { await _controller.runJavaScriptReturningResult(jsShow); } catch(__) {}
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) async {
            // 页面加载完成后：判断是否有动态数据（忽略 __blank__ 标记）
            final hasDynamicData = widget.data != null && !(widget.data is Map && (widget.data as Map).containsKey('__blank__'));
            // 若有数据则注入，无数据则直接展示默认内容
            if (hasDynamicData) {
              await _injectDynamic(widget.data!);
            }
            // 展示页面（html 初始已隐藏）
            await _showHtml();
            // 更新当前数据状态，避免后续闪屏逻辑判断错误
            _currentHasData = hasDynamicData;
            _revealIfNeeded();
          },
        ),
      );
    _loadBlankThenDecide();
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 当 data 发生变化时重新决定是否注入数据并显隐内容
    if (widget.data != oldWidget.data) {
      // 使用微任务确保在 build 完成后执行 JS
      Future.microtask(() async {
        final newHasData = widget.data != null && !(widget.data is Map && (widget.data as Map).containsKey('__blank__'));
        // 未显示页面：延续首次加载逻辑
        if (!_revealed) {
          if (newHasData) {
            await _injectDynamic(widget.data!);
          }
          await _showHtml();
          _currentHasData = newHasData;
          _revealIfNeeded();
        } else {
          // 已经展示过页面
          if (newHasData != _currentHasData) {
            // 从无数据→有数据或有数据→无数据，需要重新显隐避免兜底闪现
            if (newHasData) {
              // 从兜底转换为动态：先隐藏再注入再显示
              await _hideHtml();
              await _injectDynamic(widget.data!);
              await _showHtml();
            } else {
              // 从动态转换为兜底：重新隐藏再显示；不注入
              await _hideHtml();
              await _showHtml();
            }
            _currentHasData = newHasData;
          } else if (newHasData) {
            // 已经是动态且仍为动态，仅更新数据
            await _injectDynamic(widget.data!);
          }
        }
      });
    }
  }

  void _revealIfNeeded() {
    if (!_revealed && mounted) setState(() => _revealed = true);
  }

  Future<void> _loadBlankThenDecide() async {
    // 先加载透明空白，避免兜底闪屏
    await _controller.loadHtmlString(
      '<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>'
      '<body style="background:transparent;margin:0;padding:0;"></body></html>'
    );

    // 再加载模板：通过 file uri 加载原生资产，确保相对路径可用
    final uri = Uri.parse('file:///android_asset/flutter_assets/' + widget.assetPath);
    try {
      await _controller.loadRequest(uri);
    } catch (_) {
      // 回退到内联加载（当本地加载失败时）
      final html = await rootBundle.loadString(widget.assetPath);
      await _controller.loadHtmlString(html);
    }
  }

  Future<void> _injectDynamic(Map<String, dynamic> data) async {
    final payloadJson = jsonEncode(data);
    final js = '''
      (function(){
        try{
          var payload = $payloadJson;
          if (window.setDynamicData && typeof window.setDynamicData === 'function') {
            window.setDynamicData(payload);
          } else {
            window.PAYLOAD = payload;
            try{ if (window.onPayloadArrived) window.onPayloadArrived(payload); }catch(e){}
          }
          return true;
        }catch(e){ return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(js);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 60));
      try { await _controller.runJavaScriptReturningResult(js); } catch(__) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    // 使用零时长过渡，避免动画造成的闪屏。通过 _revealed 标志控制完全隐藏/显示。
    return AnimatedOpacity(
      opacity: _revealed ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 0),
      child: IgnorePointer(
        ignoring: !_revealed,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}