import 'package:flutter/material.dart';

/// Text controller for diary content that keeps the underlying text
/// storage-compatible (including attachment marker lines like
///   [图片] /path/to/file
///   [语音] /path/to/file
/// ) but hides the concrete file paths from the user interface while
/// preserving caret/selection behaviour.
class DiaryContentController extends TextEditingController {
  DiaryContentController({String? text}) : super(text: text);

  static bool _isMarkerLine(String line) {
    final l = line.trimLeft();
    return l.startsWith('[图片]') || l.startsWith('[语音]');
  }

  /// Replace everything after the leading "[图片]" / "[语音]" token with
  /// zero-width spaces so that:
  ///  * the real file path is not visible to the user;
  ///  * the number of characters in the line stays identical to the
  ///    original text, keeping caret positions valid.
  static String _maskMarkerLine(String line) {
    if (line.isEmpty) return line;
    final int leadingSpaces = line.length - line.trimLeft().length;
    final String trimmed = line.trimLeft();
    // 整行（包括前缀 "[图片]"/"[语音]" 和后面的路径）全部用零宽字符替换，
    // 保证文本长度不变，同时在界面上完全看不到占位文字和路径。
    final String invisible = '\u200B' * trimmed.length;
    return ' ' * leadingSpaces + invisible;
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    bool withComposing = true,
  }) {
    final TextStyle baseStyle = style ?? DefaultTextStyle.of(context).style;
    final String fullText = value.text;
    if (fullText.isEmpty) {
      return TextSpan(style: baseStyle);
    }

    final List<InlineSpan> children = <InlineSpan>[];
    final List<String> lines = fullText.split('\n');
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i];
      if (_isMarkerLine(line)) {
        line = _maskMarkerLine(line);
      }
      _buildLineSpans(line, baseStyle, children);

      if (i < lines.length - 1) {
        children.add(TextSpan(text: '\n', style: baseStyle));
      }
    }

    return TextSpan(style: baseStyle, children: children);
  }

  void _buildLineSpans(
    String line,
    TextStyle baseStyle,
    List<InlineSpan> out,
  ) {
    // Very small URL highlighter so existing behaviour is roughly preserved.
    final RegExp linkReg = RegExp(r'https?://[^\s]+');

    int index = 0;
    for (final Match m in linkReg.allMatches(line)) {
      if (m.start > index) {
        out.add(TextSpan(
          text: line.substring(index, m.start),
          style: baseStyle,
        ));
      }
      out.add(TextSpan(
        text: line.substring(m.start, m.end),
        style: baseStyle.copyWith(decoration: TextDecoration.underline),
      ));
      index = m.end;
    }
    if (index < line.length) {
      out.add(TextSpan(
        text: line.substring(index),
        style: baseStyle,
      ));
    }
  }
}
