package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.WorkManager
import org.json.JSONObject

class AlarmReceiver : BroadcastReceiver() {

  private fun cancelWmForRun(ctx: Context, uid: String, runKey: String) {
    try { WorkManager.getInstance(ctx).cancelUniqueWork("fb_next_${'$'}uid_${'$'}runKey") } catch (_: Exception) {}
    try { WorkManager.getInstance(ctx).cancelUniqueWork("wm_run_${'$'}uid_${'$'}runKey") } catch (_: Exception) {}
    try { WorkManager.getInstance(ctx).cancelUniqueWork("wm_after_am_${'$'}uid_${'$'}runKey") } catch (_: Exception) {}
  }

  override fun onReceive(context: Context, intent: Intent) {
    val id = intent.getIntExtra("id", 0)
    val payloadStr = intent.getStringExtra("payload") ?: "{}"
    val o = try { JSONObject(payloadStr) } catch (_: Exception) { JSONObject() }
    val title = o.optString("title", "提醒")
    val body = o.optString("body", "到点了")
    val uid = o.optString("task_uid", "")
    val runKey = o.optString("run_key", "")

    val n = NotificationCompat.Builder(context, "quote_notify")
      .setSmallIcon(context.applicationInfo.icon)
      .setContentTitle(title)
      .setContentText(body)
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .build()
    NotificationManagerCompat.from(context).notify(id, n)

    if (uid.isNotEmpty() && runKey.isNotEmpty()) {
      cancelWmForRun(context, uid, runKey)
    }
  }
}
