package com.example.quote_app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class NativeSchedulerK {
  companion object {
    private const val CHANNEL_ID = "quote_notify"

    private fun ensureChannel(ctx: Context) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val mgr = ctx.getSystemService(NotificationManager::class.java)
        val existing = mgr.getNotificationChannel(CHANNEL_ID)
        if (existing == null) {
          val ch = NotificationChannel(CHANNEL_ID, "Quote Notify", NotificationManager.IMPORTANCE_HIGH)
          ch.description = "Notifications for scheduled tasks"
          mgr.createNotificationChannel(ch)
        }
      }
    }

    @JvmStatic
    fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payload: String): Boolean {
      ensureChannel(ctx)
      val am = ctx.getSystemService(AlarmManager::class.java)
      val intent = Intent(ctx, AlarmReceiver::class.java).apply {
        action = "ALARM_FIRE"
        putExtra("id", id)
        putExtra("payload", payload)
      }
      val pi = PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
      return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
        } else {
          am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
        }
        true
      } catch (e: Exception) {
        false
      }
    }

    @JvmStatic
    fun cancel(ctx: Context, id: Int) {
      val am = ctx.getSystemService(AlarmManager::class.java)
      val intent = Intent(ctx, AlarmReceiver::class.java).apply { action = "ALARM_FIRE" }
      val pi = PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
      if (pi != null) { am.cancel(pi) }
    }

    @JvmStatic
    fun hasExactAlarmPermission(ctx: Context): Boolean {
      return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.canScheduleExactAlarms()
      } else true
    }

    @JvmStatic
    fun requestExactAlarm(ctx: Context) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
      }
    }
  }
}
