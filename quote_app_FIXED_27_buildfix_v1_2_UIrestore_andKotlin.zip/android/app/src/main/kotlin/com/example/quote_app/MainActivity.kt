package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "native.scheduler")
      .setMethodCallHandler { call, result ->
        try {
          when (call.method) {
            "scheduleExactAt" -> {
              val id = call.argument<Int>("id") ?: 0
              val epochMs = (call.argument<Long>("epochMs") ?: 0L)
              val payload = call.argument<String>("payload") ?: "{}"
              val ok = NativeSchedulerK.scheduleExactAt(this, id, epochMs, payload)
              result.success(ok)
            }
            "cancel" -> {
              val id = call.argument<Int>("id") ?: 0
              NativeSchedulerK.cancel(this, id)
              result.success(null)
            }
            "hasExactAlarmPermission" -> {
              result.success(NativeSchedulerK.hasExactAlarmPermission(this))
            }
            "requestExactAlarmPermission" -> {
              NativeSchedulerK.requestExactAlarm(this)
              result.success(null)
            }
            else -> result.notImplemented()
          }
        } catch (e: Exception) {
          result.error("err", e.message, null)
        }
      }
  }
}
