import 'dart:async';
import 'package:flutter/material.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';
import '../utils/debug_logger.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _cfgDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController();

  bool _editingConfig = false;
  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _apiKeyCtrl.text = await _cfgDao.getString('api_key', '');
    _modelCtrl.text = await _cfgDao.getString('model', 'gpt-5');
    _endpointCtrl.text = await _cfgDao.getString('endpoint', '');
    _tasks = await _taskDao.all();
    if (mounted) setState((){});
  }

  Future<void> _saveConfig() async {
    await _cfgDao.save(
      apiKey: _apiKeyCtrl.text.trim(),
      model: _modelCtrl.text.trim(),
      endpoint: _endpointCtrl.text.trim(),
    );
    setState(()=> _editingConfig = false);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('配置已保存')));
  }

  Future<void> _toggleTaskStatus(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    final status = (t['status'] ?? 'on').toString();
    final next = status == 'on' ? 'off' : 'on';
    await _taskDao.update(uid, {'status': next});
    await SchedulerService.cancelNextForTask(uid, includeFallback: true);
    if (next == 'on') { await SchedulerService.scheduleNextForTask(uid); }
    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _deleteTask(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    await _taskDao.delete(uid);
    await SchedulerService.cancelForTask(uid);
    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _editTaskDialog({Map<String,dynamic>? task}) async {
    final isNew = task == null;
    final nameCtrl = TextEditingController(text: (task?['name'] ?? '').toString());
    final type = ValueNotifier<String>((task?['type'] ?? 'manual').toString());
    final timeCtrl = TextEditingController(text: (task?['start_time'] ?? '08:00').toString());
    final avatarCtrl = TextEditingController(text: (task?['avatar'] ?? '').toString());
    final promptCtrl = TextEditingController(text: (task?['prompt'] ?? '来一句今天的箴言').toString());

    await showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: Text(isNew ? '新增任务' : '编辑任务'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: '名称')),
              const SizedBox(height: 8),
              ValueListenableBuilder<String>(
                valueListenable: type,
                builder: (_, v, __) => DropdownButtonFormField<String>(
                  value: v,
                  items: const [
                    DropdownMenuItem(value: 'manual', child: Text('手动队列')),
                    DropdownMenuItem(value: 'carousel', child: Text('轮播队列')),
                    DropdownMenuItem(value: 'auto', child: Text('自动生成')),
                  ],
                  onChanged: (x) => type.value = x ?? 'manual',
                  decoration: const InputDecoration(labelText: '类型'),
                ),
              ),
              const SizedBox(height: 8),
              TextField(controller: timeCtrl, decoration: const InputDecoration(labelText: '时间 (HH:mm)')),
              const SizedBox(height: 8),
              TextField(controller: avatarCtrl, decoration: const InputDecoration(labelText: '头像(可选: 本地路径或URL)')),
              const SizedBox(height: 8),
              ValueListenableBuilder<String>(
                valueListenable: type,
                builder: (_, v, __) {
                  if (v != 'auto') return const SizedBox.shrink();
                  return TextField(controller: promptCtrl, decoration: const InputDecoration(labelText: '自动生成提示词'));
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('取消')),
          TextButton(onPressed: () async {
            final name = nameCtrl.text.trim();
            final t = type.value;
            final st = timeCtrl.text.trim().isEmpty ? '08:00' : timeCtrl.text.trim();
            final avatar = avatarCtrl.text.trim();
            if (name.isEmpty) return;
            if (isNew) {
              await _taskDao.create(
                name: name,
                type: t,
                startTime: st,
                avatar: avatar,
                prompt: t == 'auto' ? promptCtrl.text.trim() : '',
              );
            } else {
              final uid = (task!['task_uid'] ?? '').toString();
              await _taskDao.update(uid, {
                'name': name,
                'type': t,
                'start_time': st,
                'avatar': avatar,
                if (t == 'auto') 'prompt': promptCtrl.text.trim(),
              });
              await SchedulerService.cancelNextForTask(uid, includeFallback: true);
            }
            await SchedulerService.scheduleNextForAll();
            Navigator.pop(context);
            await _load();
          }, child: const Text('保存')),
        ],
      );
    });
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('模型配置', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            if (!_editingConfig) IconButton(onPressed: ()=> setState(()=> _editingConfig = true), icon: const Icon(Icons.edit)),
            if (_editingConfig) IconButton(onPressed: _saveConfig, icon: const Icon(Icons.save)),
          ],
        ),
        const SizedBox(height: 8),
        TextField(controller: _apiKeyCtrl, decoration: const InputDecoration(labelText: 'API Key'), enabled: _editingConfig),
        TextField(controller: _modelCtrl, decoration: const InputDecoration(labelText: 'Model'), enabled: _editingConfig),
        TextField(controller: _endpointCtrl, decoration: const InputDecoration(labelText: 'Endpoint (可选)'), enabled: _editingConfig),
      ],
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('系统设置'),
        actions: [
          IconButton(onPressed: () async { await SchedulerService.scheduleNextForAll(); }, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            cfgFields,
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                TextButton.icon(onPressed: ()=> _editTaskDialog(), icon: const Icon(Icons.add), label: const Text('新增')),
              ],
            ),
            const SizedBox(height: 8),
            if (_tasks.isEmpty) const Text('暂无任务，点击右上角“新增”创建。'),
            for (final t in _tasks)
              Card(
                margin: const EdgeInsets.symmetric(vertical: 6),
                child: ListTile(
                  title: Text((t['name'] ?? '') as String),
                  subtitle: Text('类型: ${(t['type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}  时间: ${(t['start_time'] ?? '') as String}'),
                  onTap: ()=> _editTaskDialog(task: t),
                  trailing: Wrap(
                    spacing: 6,
                    children: [
                      IconButton(onPressed: ()=> SchedulerService.scheduleNextForTask((t['task_uid'] ?? '').toString()), icon: const Icon(Icons.schedule)),
                      IconButton(onPressed: ()=> SchedulerService.cancelNextForTask((t['task_uid'] ?? '').toString(), includeFallback: true), icon: const Icon(Icons.cancel)),
                      IconButton(onPressed: ()=> _toggleTaskStatus(t), icon: const Icon(Icons.power_settings_new)),
                      IconButton(onPressed: ()=> _deleteTask(t), icon: const Icon(Icons.delete_outline)),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 12),
            const Text('注：此页为恢复版，包含新增/编辑/删除/续排/取消等功能。'),
          ],
        ),
      ),
    );
  }
}
