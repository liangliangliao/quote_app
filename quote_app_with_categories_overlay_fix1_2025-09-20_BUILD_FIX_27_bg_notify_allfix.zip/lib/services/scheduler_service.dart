import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'wm_dispatcher.dart';
import 'openai_service.dart';
import '../platform/perm_helper.dart';

class SchedulerService {

  /// WorkManager 后台兜底：当用户未授予精确闹钟或被系统强限电时，
  /// 以 15 分钟粒度唤醒一次执行 callback()，保证后台也能收到通知（可能会有延迟）。
  @pragma('vm:entry-point')
  static void workmanagerCallbackDispatcher() {
    Workmanager().executeTask((task, inputData) async {
      WidgetsFlutterBinding.ensureInitialized();
      await NotificationService.init();
      await AppDatabase.instance();
      await SchedulerService.callback();
      return Future.value(true);
    });
  }

  static Future<void> init() async {
    // 初始化 Workmanager（一次即可）
    try {
      await Workmanager().initialize(workmanagerCallbackDispatcher, isInDebugMode: false);
    } catch (_) {}
    // 始终注册 15 分钟兜底任务（keep 去重）
    try {
      await Workmanager().registerPeriodicTask(
        'due_check_periodic',
        'due_check_periodic',
        frequency: const Duration(minutes: 15),
        initialDelay: const Duration(minutes: 15),
        existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
        constraints: const Constraints(
          networkType: NetworkType.notRequired,
          requiresBatteryNotLow: false,
          requiresCharging: false,
          requiresDeviceIdle: false,
        ),
      );
    } catch (_) {}
    // 初始化 AndroidAlarmManager（精确闹钟）
    try { await AndroidAlarmManager.initialize(); } catch (_) {}
    // 记录权限状态（不弹引导）
    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (!ok) {
        await LogDao().add(taskUid: 'system', detail: '警告! 系统未授予精确闹钟权限(Alarms & reminders)。Android 14+ 默认关闭。');
      }
    } catch (_) {}
    // 安排所有任务的下一次触发
    await scheduleNextForAll();
  }

        if (q != null) {
          final content = (q['content'] ?? '') as String;
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          await QuoteDao().markNotified(q['id'] as int);
          await LogDao().add(taskUid: taskUid, detail: '轮播任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '轮播任务无可用名言');
        }
      } else {
        // auto
        final cfg = await ConfigDao().getOne();
        try {
          final openai = OpenAIService(
            endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
            apiKey: (cfg['api_key'] ?? '') as String,
            model: (cfg['model'] ?? 'gpt-5') as String,
          );
          final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;
          String? uid;
          for (int i=0; i<10; i++) {
            final quote = (await openai.generateQuote(prompt)).trim();
            if (quote.isEmpty) break;
            final exists = await QuoteDao().existsSimilar(quote, threshold: 0.9);
            if (exists) {
              if (i==9) {
                await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
              }
              continue;
            }
            uid = await QuoteDao().insertIfUnique(
              taskUid: taskUid,
              type: 'auto',
              taskName: name,
              avatarPath: avatar,
              content: quote,
            );
            break;
          }
          if (uid != null) {
            final q = await QuoteDao().latestForTask(taskUid);
            final content = (q?['content'] ?? '') as String;
            if (content.isNotEmpty) {
              await NotificationService.show(
                id: _alarmIdForTask(taskUid),
                title: name,
                body: content,
                largeIconPath: avatar.isEmpty ? null : avatar,
              );
              await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送');
              final db2 = await AppDatabase.instance();
              await db2.update('quotes', {'notified': 1}, where: 'id=?', whereArgs: [q?['id']]);
            }
          }
        } catch (e) {
          await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
        }
      }

      // After firing: compute next and persist + reschedule
      final next = _computeNext(t, from: now.add(const Duration(seconds: 1)));
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
      final id = _alarmIdForTask(taskUid);
      final canExact = await PermHelper.hasExactAlarmPermission();
      final ok = await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: canExact,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
      if (!ok) {
        try { await LogDao().add(taskUid: t['task_uid'] as String, detail: '⚠️闹钟注册失败: exact='+canExact.toString()); } catch (_) {}
      }
    }
  }

  static bool _isDue(String start, DateTime now) {
    // start format: YYYY-MM-DD HH:mm
    try {
      final dt = DateFormat('yyyy-MM-dd HH:mm').parse(start);
      return !dt.isAfter(now);
    } catch (_) {
      return false;
    }
  }
}

@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await AppDatabase.instance();
  await SchedulerService.callback();
}

String _fmt(DateTime dt) {
  final f = DateFormat('yyyy-MM-dd HH:mm');
  return f.format(dt);
}
