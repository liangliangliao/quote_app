import 'package:workmanager/workmanager.dart';
import 'package:flutter/widgets.dart';
import '../data/db.dart';
import 'notification_service.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    await SchedulerService.callback();
    return Future.value(true);
  });
}
