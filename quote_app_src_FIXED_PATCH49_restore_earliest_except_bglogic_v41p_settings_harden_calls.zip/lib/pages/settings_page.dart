import 'package:quote_app/util/kv_store.dart';
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _simulateDartFail = false;

  
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  final TextEditingController _apiKeyCtrl = TextEditingController();
  final TextEditingController _modelCtrl = TextEditingController();
  final TextEditingController _endpointCtrl = TextEditingController();

  bool _editingConfig = false;
  bool get editingConfig => _editingConfig;
  void _setEditing(bool v){ setState(()=> _editingConfig = v); }
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    
    _loadSimToggle();
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  void showToast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? '') as String;

    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _saveConfig() async {
    try {
      await _configDao.save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
      this._setEditing(false);
      showToast('配置已保存');
    } catch (e) {
      showToast('配置保存失败');
    }
  }

  Future<String?> _saveAvatarTemp(File file) async {
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png');
    await f.writeAsBytes(await file.readAsBytes());
    return f.path;
    // NotificationService 会把这个路径作为 largeIcon 使用
  }

  Future<void> _openTaskDialog({Map<String, dynamic>? task}) async {
    final isEdit = task != null;

    String name = isEdit ? (task['name'] ?? '') as String : '';
    String type = isEdit ? (task['type'] ?? 'manual') as String : 'manual'; // manual / auto / carousel
    String status = isEdit ? (task['status'] ?? 'on') as String : 'on';     // on / off
    String prompt = isEdit ? (task['prompt'] ?? '') as String : '';
    String manualQuote = '';
    
    // 回显手动任务的名言
    if (isEdit && type == 'manual' && (task?['task_uid']!=null)) {
      final mq = await QuoteDao().latestForTask(task!['task_uid'] as String);
      manualQuote = (mq?['content'] ?? '') as String;
    }
String avatarPath = isEdit ? (task['avatar_path'] ?? '') as String : '';

    // freq
    String freqType = isEdit ? (task['freq_type'] ?? 'daily') as String : 'daily'; // daily/weekly/monthly/custom
    int? selectedWeekday = (task?['freq_weekday'] as int?);
    int? selectedMonthDay = (task?['freq_day_of_month'] as int?);
    TimeOfDay time = _parseTimeOfDay((task?['start_time'] ?? '') as String) ?? const TimeOfDay(hour: 9, minute: 0);
    final formKey = GlobalKey<FormState>();

    // Auto-refresh "next trigger" preview
    Timer? ticker;
    void ensureTicker(StateSetter setStateDialog, BuildContext ctx) {
      ticker ??= Timer.periodic(const Duration(seconds: 30), (_){
        if (Navigator.of(ctx).mounted) setStateDialog((){});
      });
    }

    String two(int n)=> n.toString().padLeft(2,'0');
    String weekdayText(int w){
      const names = ['一','二','三','四','五','六','日'];
      return (w>=1 && w<=7)? names[w-1] : '一';
    }
    DateTime computeNext(DateTime now){
      if (freqType == 'weekly'){
        final wd = (selectedWeekday ?? 1);
        int delta = (wd - now.weekday) % 7;
        var cand = DateTime(now.year, now.month, now.day, time.hour, time.minute).add(Duration(days: delta));
        if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
        return cand;
      } else if (freqType == 'monthly'){
        final d = (selectedMonthDay ?? 1);
        int y = now.year, m = now.month;
        int end = DateTime(y, m + 1, 0).day;
        var cand = DateTime(y, m, d.clamp(1, end), time.hour, time.minute);
        if (!cand.isAfter(now)) {
          m += 1;
          end = DateTime(y, m + 1, 0).day;
          cand = DateTime(y, m, d.clamp(1, end), time.hour, time.minute);
        }
        return cand;
      } else {
        final today = DateTime(now.year, now.month, now.day, time.hour, time.minute);
        if (today.isAfter(now)) return today;
        return today.add(const Duration(days: 1));
      }
    }

    String _fmt(DateTime dt){ String two(int n)=> n.toString().padLeft(2,'0'); return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}'; }
    await showDialog(context: context, builder: (dialogCtx) {
      return StatefulBuilder(
        builder: (ctx, setStateDialog) {
          ensureTicker(setStateDialog, ctx);
          final next = computeNext(DateTime.now());
          final nextStr = '${next.year}-${two(next.month)}-${two(next.day)} ${two(next.hour)}:${two(next.minute)}';

          return AlertDialog(
            title: Text(isEdit ? '编辑任务' : '新增任务'),
            content: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
            
              value: _simulateDartFail,
              onChanged: (v) async {
                setState(() => _simulateDartFail = v);
                final kv = await KVStore.instance();
                await kv.setInt('simulate_dart_fail', v ? 1 : 0);
              },
            ),
                    const Text('任务标题'),
                    TextFormField(
                      initialValue: name,
                      onChanged: (v)=> name = v,
                      validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务标题' : null,
                    ),
                    const SizedBox(height: 8),
                    const Text('任务类型'),
                    DropdownButton<String>(
                      value: type,
                      onChanged: (v){ setStateDialog(()=> type = v ?? 'manual'); },
                      items: const [
                        DropdownMenuItem(value: 'manual', child: Text('手动')),
                        DropdownMenuItem(value: 'auto', child: Text('自动')),
                        DropdownMenuItem(value: 'carousel', child: Text('轮播')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (type == 'auto') ...[
                      const Text('提示词'),
                      TextFormField(
                        initialValue: prompt,
                        onChanged: (v)=> prompt = v,
                        validator: (v)=> (type=='auto' && (v==null || v.trim().isEmpty)) ? '请输入提示词' : null,
                      ),
                    ],
                    if (type == 'manual') ...[
                      const Text('名人名言'),
                      TextFormField(
                        initialValue: manualQuote,
                        onChanged: (v)=> manualQuote = v,
                        validator: (v)=> (type=='manual' && (v==null || v.trim().isEmpty)) ? '请输入名人名言' : null,
                        minLines: 3,
                        maxLines: null,
                        keyboardType: TextInputType.multiline,
                        textInputAction: TextInputAction.newline,
                      ),
                    ],
                    const SizedBox(height: 8),
                    const Text('头像（用于通知图标）'),
                    Row(
                      children: [
            
                        CircleAvatar(
                          backgroundImage: (avatarPath.isNotEmpty && File(avatarPath).existsSync()) ? FileImage(File(avatarPath)) : null,
                          child: (avatarPath.isEmpty || !File(avatarPath).existsSync()) ? const Icon(Icons.person) : null,
                        ),
                        const SizedBox(width: 8),
                        OutlinedButton.icon(
                          onPressed: () async {
                            final picker = ImagePicker();
                            final x = await picker.pickImage(source: ImageSource.gallery);
                            if (x != null) {
                              final p = await _saveAvatarTemp(File(x.path));
                              setStateDialog(()=> avatarPath = p ?? '');
                            }
                          },
                          icon: const Icon(Icons.photo),
                          label: const Text('选择图片'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('状态'),
                    DropdownButton<String>(
                      value: status,
                      onChanged: (v){ setStateDialog(()=> status = v ?? 'on'); },
                      items: const [
                        DropdownMenuItem(value: 'on', child: Text('开启')),
                        DropdownMenuItem(value: 'off', child: Text('关闭')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('时间：'),
                    // frequency row
                    Row(
                      children: [
            
                        DropdownButton<String>(
                          value: freqType,
                          onChanged: (v){ setStateDialog(()=> freqType = v ?? 'daily'); },
                          items: const [
                            DropdownMenuItem(value: 'daily', child: Text('每天')),
                            DropdownMenuItem(value: 'weekly', child: Text('每周')),
                            DropdownMenuItem(value: 'monthly', child: Text('每月')),
                          ],
                        ),
                        const SizedBox(width: 12),
                        if (freqType=='weekly')
                          DropdownButton<int>(
                            value: selectedWeekday ?? 1,
                            onChanged: (v){ setStateDialog(()=> selectedWeekday = v ?? 1); },
                            items: const [
                              DropdownMenuItem(value: 1, child: Text('周一')),
                              DropdownMenuItem(value: 2, child: Text('周二')),
                              DropdownMenuItem(value: 3, child: Text('周三')),
                              DropdownMenuItem(value: 4, child: Text('周四')),
                              DropdownMenuItem(value: 5, child: Text('周五')),
                              DropdownMenuItem(value: 6, child: Text('周六')),
                              DropdownMenuItem(value: 7, child: Text('周日')),
                            ],
                          ),
                        if (freqType=='monthly')
                          DropdownButton<int>(
                            value: (selectedMonthDay ?? 1).clamp(1, 28),
                            onChanged: (v){ setStateDialog(()=> selectedMonthDay = (v ?? 1).clamp(1, 28)); },
                            items: [
                              for (int d=1; d<=28; d++)
                                DropdownMenuItem(value: d, child: Text('$d日')),
                            ],
                          ),
                        const Spacer(),
                        IconButton(
                          onPressed: () async {
                            final t = await showTimePicker(context: ctx, initialTime: time);
                            if (t != null) setStateDialog(()=> time = t);
                          },
                          icon: const Icon(Icons.access_time),
                        ),
                        Text('${two(time.hour)}:${two(time.minute)}'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      () {
                        final hhmm = '${two(time.hour)}:${two(time.minute)}';
                        if (freqType=='weekly') {
                          final w = selectedWeekday ?? 1;
                          return '每周${weekdayText(w)} $hhmm （下一次：$nextStr）';
                        } else if (freqType=='monthly') {
                          final d = selectedMonthDay ?? 1;
                          return '每月${d}日 $hhmm （下一次：$nextStr）';
                        } else {
                          return '每天 $hhmm （下一次：$nextStr）';
                        }
                      }(),
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              if (isEdit)
                TextButton(
                  onPressed: () async {
                    await _taskDao.delete(task!['task_uid'] as String);
                    showToast('已删除任务');
                    await _load();
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('删除'),
                ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: () async {
                  if (formKey.currentState?.validate() != true) return;

                  // Compose freq_custom for potential future use (not required now)
                  final freqCustomJson = '';

                  if (isEdit) {
                    final patch = <String, dynamic>{
                      'name': name.trim(),
                      'type': type,
                      'prompt': type=='auto' ? prompt.trim() : '',
                      'avatar_path': avatarPath,
                      'status': status,
                      'freq_type': freqType,
                      'freq_weekday': selectedWeekday,
                      'freq_day_of_month': selectedMonthDay,
                      'start_time': _fmt(computeNext(DateTime.now())),
                      'freq_custom': freqCustomJson,
                      'start_time': '${DateTime.now().year.toString().padLeft(4,'0')}-${DateTime.now().month.toString().padLeft(2,'0')}-${DateTime.now().day.toString().padLeft(2,'0')} ${two(time.hour)}:${two(time.minute)}',
                    };
                    await _taskDao.update(task!['task_uid'] as String, patch);

                    if (type == 'manual') {
                      final content = manualQuote.trim();
                      if (content.isNotEmpty) {
                        final ok = await QuoteDao().updateLatestForTask(task['task_uid'] as String, content);
                        if (!ok) {
                          // 按你的要求：编辑手动任务时不新增，只更新
                          showToast('未找到该任务的现有名言（未新增）');
                        }
                      }
                    }
                  } else {
                    final newUid = await _taskDao.create(
                      name: name.trim(),
                      type: type,
                      startTime: computeNext(DateTime.now()),
                      prompt: type=='auto' ? prompt.trim() : '',
                      avatarPath: avatarPath,
                      status: status,
                      freqType: freqType,
                      freqWeekday: selectedWeekday,
                      freqDayOfMonth: selectedMonthDay,
                      freqCustom: freqCustomJson,
                    );
                    if (type == 'manual') {
                      final content = manualQuote.trim();
                      if (content.isNotEmpty) {
                        final dup = await QuoteDao().existsSimilar(content);
                        if (dup) {
                          showToast('数据重复!请重新输入名人名言');
                          return;
                        }
                        await QuoteDao().insertIfUnique(
                          taskUid: newUid,
                          type: 'manual',
                          taskName: name.trim(),
                          avatarPath: avatarPath,
                          content: content,
                        );
                      }
                    }
                  }

                  await SchedulerService.scheduleNextForAll();
                  await _load();
                  showToast('已保存');
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('保存'),
              ),
            ],
          );
        },
  });
    ticker?.cancel();
  }

  TimeOfDay? _parseTimeOfDay(String startTime){
    // expects 'YYYY-MM-DD HH:mm'
    final parts = startTime.split(' ');
    if (parts.length != 2) return null;
    final hm = parts[1].split(':');
    if (hm.length != 2) return null;
    final h = int.tryParse(hm[0]); final m = int.tryParse(hm[1]);
    if (h == null || m == null) return null;
    return TimeOfDay(hour: h, minute: m);
  }

  Future<void> _loadSimToggle() async {
  try {
    final kv = await KVStore.instance();
    setState(() {
      _simulateDartFail = (kv.getInt('simulate_dart_fail') ?? 0) == 1;
    });
  } catch (_) {}
}

@override
  





Widget build(BuildContext context) {
    // Capture instance fields into locals to avoid any analyzer scoping quirks
    final apiCtrl = _apiKeyCtrl;
    final modelCtrl = _modelCtrl;
    final endpointCtrl = _endpointCtrl;
    final bool isEditingCfg = this._editingConfig;

    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
            
        const Text('API key', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: apiCtrl, enabled: isEditingCfg),
        const SizedBox(height: 8),
        const Text('模型名称', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: modelCtrl, enabled: isEditingCfg),
        const SizedBox(height: 8),
        const Text('接口地址', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: endpointCtrl, enabled: isEditingCfg),
      ],
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        actions: [
          IconButton(onPressed: (){
            this._setEditing(true);
          }, icon: const Icon(Icons.edit)),
          IconButton(onPressed: () => _saveConfig(), icon: const Icon(Icons.save)),
        ],
      ),
      body: Padding(
  padding: const EdgeInsets.all(12),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // ===== 顶部固定区域（不随任务列表滚动） =====
      // 临时测试开关（测完会移除）
      SwitchListTile(
        title: Text('【临时】模拟 Dart 通知失败，改走原生兜底'),
        subtitle: Text('仅用于测试，测完后会移除'),
        value: _simulateDartFail,
        onChanged: (v) async {
          setState(() => _simulateDartFail = v);
          final kv = await KVStore.instance();
          await kv.setInt('simulate_dart_fail', v ? 1 : 0);
        },
      ),
      const SizedBox(height: 8),
      cfgFields,
      const SizedBox(height: 16),
      const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),

      // ===== 只有任务列表可滚动 =====
      Expanded(
        child: ListView.builder(
          itemCount: _tasks.length,
          itemBuilder: (context, index) {
            final t = _tasks[index];
            return ListTile(
              title: InkWell(
                onTap: () => _openTaskDialog(task: t),
                child: Text((t['name'] ?? '') as String, style: const TextStyle(decoration: TextDecoration.underline)),
              ),
              subtitle: Text('时间: ${(t['start_time'] ?? '') as String}  类型: ${(t['type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}'),
            );
          },
        ),
      ),
    ],
  ),
),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}
