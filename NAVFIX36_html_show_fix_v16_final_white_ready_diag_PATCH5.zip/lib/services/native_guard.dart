import 'package:flutter/foundation.dart';
// Minimal, non-breaking helper for checking native takeover
import 'dart:async';
import 'package:flutter/services.dart';

class NativeGuard {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> isNativeWM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeWmEnabled');
      return ok == true;
    } catch (_) {
      return false; // 若通道不存在，默认 Dart 继续注册
    }
  }

  static Future<bool> isNativeAM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeAmEnabled');
      return ok == true;
    } catch (_) {
      return false;
    }
  }

  /// Check if Android System WebView (or Chrome WebView) is available on device.
  /// Returns false when the native side reports no WebView package.
  static Future<bool> isWebViewOk() async {
    try {
      final info = await _ch.invokeMethod('webViewInfo');
      if (info is Map) {
        final ok = info['ok'];
        return ok == true || ok == 'true';
      }
    } catch (_) {}
    // If channel not implemented (iOS or old builds), assume true to keep existing behavior.
    return true;
  }

}


/// Lightweight refresh bus (no polling, no channel)
class SimpleBus {
  static final ValueNotifier<int> homeTick = ValueNotifier<int>(0);
  // 添加用于日志页和设置页的刷新通知器
  static final ValueNotifier<int> logsTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> settingsTick = ValueNotifier<int>(0);
  static bool _inited = false;
  static final ValueNotifier<int> navIndex = ValueNotifier<int>(-1);
  static void navHome(){ navIndex.value = 0; }
  static void init() { if (_inited) return; _inited = true; }
  static void pokeHome() { homeTick.value = homeTick.value + 1; }

  /// 通知日志页刷新
  static void pokeLogs() { logsTick.value = logsTick.value + 1; }

  /// 通知设置页刷新
  static void pokeSettings() { settingsTick.value = settingsTick.value + 1; }
}
