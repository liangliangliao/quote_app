package com.example.quote_app

import android.content.Context
import androidx.webkit.WebViewCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

object SysChannel {
  private const val CH = "com.example.quote_app/sys"

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
          "isNativeWmEnabled" -> {
            result.success(false)
          }
          "webViewInfo" -> {
            val map = HashMap<String, Any?>()
            try {
              val p = WebViewCompat.getCurrentWebViewPackage(appCtx)
              if (p == null) {
                map["ok"] = false
              } else {
                map["ok"] = true
                map["pkg"] = p.packageName
                map["ver"] = p.versionName
              }
            } catch (t: Throwable) {
              map["ok"] = false
            }
            result.success(map)
          }
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
  }
}