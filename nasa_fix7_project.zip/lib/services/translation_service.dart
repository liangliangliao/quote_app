import 'dart:convert';

import 'package:http/http.dart' as http;

/// Lightweight translation helper.
///
/// Uses LibreTranslate-compatible endpoints. For stability, this class
/// tries multiple public endpoints. For production apps, it is strongly
/// recommended to deploy your own LibreTranslate instance or proxy.
class TranslationService {
  TranslationService({List<String>? endpoints})
      : _endpoints = endpoints ??
            const <String>[
              // Public endpoints (best effort). You can override by passing
              // your own endpoints when constructing this service.
              'https://libretranslate.com/translate',
              'https://translate.argosopentech.com/translate',
            ];

  final List<String> _endpoints;

  /// MyMemory is a free, no-key translation endpoint.
  ///
  /// Public LibreTranslate instances may be rate-limited or intermittently
  /// unreachable. We try MyMemory first for better real-world reliability.
  static const String _myMemoryEndpoint = 'https://api.mymemory.translated.net/get';

  // MyMemory 的 GET 参数 `q` 有长度限制（超出会返回
  // "QUERY LENGTH LIMIT EXCEEDED. MAX ALLOWED QUERY : 500 CHARS"）。
  // 为了避免触发限制，这里预留冗余并做分片翻译。
  static const int _myMemoryMaxChars = 450;
  static const String _myMemoryLimitHint = 'QUERY LENGTH LIMIT EXCEEDED';

  String _toMyMemoryLangCode(String code) {
    // UI uses: zh, en, ja, ko, es, fr, de, ru, ar, pt
    if (code == 'zh') return 'zh-CN';
    if (code == 'pt') return 'pt-PT';
    return code;
  }

  /// In-memory cache: key = "<target>|<text>"
  final Map<String, String> _cache = <String, String>{};

  void clearCache() => _cache.clear();

  /// Translate a single [text] from English to [target].
  /// Returns the original [text] if translation fails.
  Future<String> translateOne({
    required String text,
    required String target,
  }) async {
    if (target == 'en' || text.trim().isEmpty) return text;
    final key = '$target|$text';
    final cached = _cache[key];
    if (cached != null) return cached;

    // 1) Try MyMemory (GET) first.
    try {
      final translated = await _translateViaMyMemoryChunked(text: text, target: target);
      if (translated.trim().isNotEmpty && translated.trim() != text.trim()) {
        _cache[key] = translated;
        return translated;
      }
    } catch (_) {
      // fallthrough
    }

    // 2) Fallback to LibreTranslate instances in order.
    for (final endpoint in _endpoints) {
      try {
        final res = await http
            .post(
              Uri.parse(endpoint),
              headers: const {'Content-Type': 'application/json'},
              body: jsonEncode({
                'q': text,
                'source': 'en',
                'target': target,
                'format': 'text',
              }),
            )
            .timeout(const Duration(seconds: 18));
        if (res.statusCode != 200) continue;
        final data = jsonDecode(res.body);
        final translated = (data is Map<String, dynamic>)
            ? (data['translatedText'] ?? '').toString()
            : '';
        if (translated.trim().isEmpty) continue;
        _cache[key] = translated;
        return translated;
      } catch (_) {
        // try next endpoint
      }
    }

    return text;
  }

  List<String> _splitByMaxLen(String input, int maxLen) {
    final s = input;
    if (s.length <= maxLen) return <String>[s];

    final chunks = <String>[];
    var start = 0;
    while (start < s.length) {
      var end = start + maxLen;
      if (end >= s.length) {
        chunks.add(s.substring(start));
        break;
      }

      // Prefer splitting on whitespace/newlines near the boundary.
      final windowStart = (end - 80).clamp(start, end);
      final window = s.substring(windowStart, end);
      final lastSpace = window.lastIndexOf(RegExp(r'[\s\n\r\t]'));
      if (lastSpace != -1) {
        end = windowStart + lastSpace + 1;
      }

      chunks.add(s.substring(start, end));
      start = end;
    }

    return chunks;
  }

  Future<String> _translateViaMyMemoryChunked({
    required String text,
    required String target,
  }) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || target == 'en') return text;
    if (trimmed.length <= _myMemoryMaxChars) {
      return _translateViaMyMemory(text: trimmed, target: target);
    }

    // 分片翻译，避免触发 MyMemory 的长度限制。
    final parts = _splitByMaxLen(trimmed, _myMemoryMaxChars);
    final out = StringBuffer();
    for (final p in parts) {
      final t = await _translateViaMyMemory(text: p, target: target);
      out.write(t);
    }
    return out.toString();
  }

  Future<String> _translateViaMyMemory({
    required String text,
    required String target,
  }) async {
    if (target == 'en' || text.trim().isEmpty) return text;
    final targetCode = _toMyMemoryLangCode(target);
    final uri = Uri.parse(_myMemoryEndpoint).replace(queryParameters: {
      'q': text,
      'langpair': 'en|$targetCode',
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return text;
    final data = jsonDecode(res.body);
    if (data is Map<String, dynamic>) {
      final responseData = data['responseData'];
      if (responseData is Map<String, dynamic>) {
        final t = (responseData['translatedText'] ?? '').toString();
        final tt = t.trim();
        if (tt.isEmpty) return text;
        // MyMemory 超长会把错误信息塞进 translatedText。
        if (tt.contains(_myMemoryLimitHint)) return text;
        return t;
      }
    }
    return text;
  }

  /// Backward-compatible wrapper used by UI code.
  ///
  /// The Space module calls `translateTexts(texts, targetLang: ...)`.
  /// We keep this wrapper so the rest of the code can stay clean.
  Future<List<String>> translateTexts(
    List<String> texts, {
    required String targetLang,
  }) async {
    return translateMany(texts: texts, target: targetLang);
  }

  /// Best-effort batch translation.
  ///
  /// To avoid dozens of network calls, we join texts with a delimiter
  /// and translate once. If parsing fails, we fall back to per-item
  /// translation.
  Future<List<String>> translateMany({
    required List<String> texts,
    required String target,
  }) async {
    if (target == 'en' || texts.isEmpty) return texts;

    // Use cache as much as possible.
    final out = List<String>.filled(texts.length, '');
    final toTranslate = <int, String>{};
    for (var i = 0; i < texts.length; i++) {
      final t = texts[i];
      if (t.trim().isEmpty) {
        out[i] = t;
        continue;
      }
      final key = '$target|$t';
      final cached = _cache[key];
      if (cached != null) {
        out[i] = cached;
      } else {
        toTranslate[i] = t;
      }
    }
    if (toTranslate.isEmpty) return out;

    const sep = '\n<<<SEP>>>\n';

    // 1) Try MyMemory in *small batches* to avoid query length limits.
    // Titles are short, so this keeps network requests low and UI fast.
    final entries = toTranslate.entries.toList(growable: false);
    var cursor = 0;
    while (cursor < entries.length) {
      final batch = <MapEntry<int, String>>[];
      var joinedLen = 0;
      while (cursor < entries.length) {
        final candidate = entries[cursor];
        final candLen = candidate.value.length + (batch.isEmpty ? 0 : sep.length);
        if (batch.isNotEmpty && joinedLen + candLen > _myMemoryMaxChars) break;
        batch.add(candidate);
        joinedLen += candLen;
        cursor++;
        // 在同一批里最多放 50 个，避免服务端偶发异常。
        if (batch.length >= 50) break;
      }

      final joined = batch.map((e) => e.value).join(sep);
      try {
        final translatedJoined = await _translateViaMyMemory(text: joined, target: target);
        final parts = translatedJoined.split(sep);
        if (parts.length == batch.length) {
          for (var i = 0; i < batch.length; i++) {
            final entry = batch[i];
            final v = parts[i];
            out[entry.key] = v;
            _cache['$target|${entry.value}'] = v;
          }
          continue;
        }
      } catch (_) {
        // fallthrough
      }

      // Batch failed: fallback per item for this batch.
      for (final entry in batch) {
        out[entry.key] = await translateOne(text: entry.value, target: target);
      }
    }

    // If something is still empty (shouldn't), fallback to original.
    for (var i = 0; i < out.length; i++) {
      if (out[i].isEmpty) out[i] = texts[i];
    }
    return out;
  }
}
