package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * 在系统重启/应用更新后，确保解锁守护服务（ScreenGatekeeperService）被启动，
 * 以便在后台可靠地动态注册解锁/亮屏广播。
 */
class BootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val action = intent.action ?: return
    val appCtx = context.applicationContext
    try {
      val svc = Intent(appCtx, ScreenGatekeeperService::class.java)
      if (Build.VERSION.SDK_INT >= 26) {
        appCtx.startForegroundService(svc)
      } else {
        appCtx.startService(svc)
      }
    } catch (_: Throwable) {
    }
  }
}
