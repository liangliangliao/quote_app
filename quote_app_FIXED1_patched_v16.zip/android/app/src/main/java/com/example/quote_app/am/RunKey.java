package com.example.quote_app.am;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
public final class RunKey {
  private RunKey(){}
  public static String nowKey(){
    return new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
  }
  public static String[] windowBefore(String runKey, int seconds){
    try{
      SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US);
      Date d = fmt.parse(runKey);
      Calendar cal = Calendar.getInstance();
      cal.setTime(d);
      long end = cal.getTimeInMillis();
      long start = end - seconds*1000L;
      return new String[]{ fmt.format(new Date(start)), fmt.format(new Date(end)) };
    }catch(Throwable t){
      long now = System.currentTimeMillis();
      SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US);
      return new String[]{ fmt.format(new Date(now- seconds*1000L)), fmt.format(new Date(now)) };
    }
  }
}
