import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static Future<void> showFailureToast(String msg) async {
    try {
      await _sysCh.invokeMethod('showToast', {'message': msg});
    } catch (_){}
  }

  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    try { await DLog.i('LocationService', '【定位】优先使用百度SDK定位（目标≤30m），失败回退系统定位'); } catch (_){}
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        unawaited(_logNearbyLandmarkIfPossible(bd));
        if (bd.accuracy <= 30) return bd;
        // 如果百度返回但精度>30m，则继续等待系统高精度流至≤30m
        try { await DLog.w('LocationService', '【定位】Baidu返回但精度 ' + bd.accuracy.toString() + 'm，大于30m，回退系统流继续获取'); } catch (_){}
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：' + e.toString()); } catch (_){}
    }
    final sys = await _systemLocationOnce();
    if (sys != null) {
      unawaited(_logNearbyLandmarkIfPossible(sys));
      return sys;
    }
    try {
      await DLog.e('LocationService', '【定位】两种方式均失败');
    } catch (_){}
    return null;
  }

  /// 读取百度地图 AK：优先读取新的 notify_config 表，其次回退到 configs 表；
  /// 若均为空，则返回空字符串。
  static Future<String> _loadBaiduAk() async {
    try {
      // 优先使用设置页中保存到 notify_config 的 AK
      String ak = '';
      try {
        ak = (await NotifyConfigDao().getBaiduAk()).trim();
      } catch (_) {}
      if (ak.isEmpty) {
        // 回退到旧的 configs 表读取（内部已包含默认值）
        try {
          ak = (await ConfigDao().getBaiduAk()).trim();
        } catch (_) {}
      }
      return ak;
    } catch (_) {
      return '';
    }
  }

  /// 调用百度 Place API 的圆形区域检索接口，拉取附近 POI 列表。
  /// 参考文档：https://api.map.baidu.com/place/v2/search（query+location+radius）
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String? keyword,
    int page = 1,
    int pageSize = 5,
  }) async {
    final List<PoiItem> list = <PoiItem>[];
    try {
      final ak = await _loadBaiduAk();
      if (ak.isEmpty) {
        // 未配置 AK 时直接返回空列表，避免无效请求
        return list;
      }

      String query = (keyword ?? '').trim();
      if (query.isEmpty) {
        // 百度地点检索 query 为必填；这里给一个通用关键字，保证请求合法
        query = '美食';
      }

      // Baidu place/v2/search 圆形区域检索，使用 GPS(WGS84) 坐标：coord_type=1。
      final uri = Uri.https('api.map.baidu.com', '/place/v2/search', <String, String>{
        'query': query,
        'location': '$latitude,$longitude',
        'radius': radiusMeters.toString(),
        'output': 'json',
        'ak': ak,
        'page_size': pageSize.toString(),
        // Baidu page_num 从 0 开始；页面从 1 开始。
        'page_num': page <= 0 ? '0' : (page - 1).toString(),
        'scope': '1',
        'coord_type': '1', // wgs84ll：使用 geolocator 返回的 GPS 坐标
      });

      final resp = await http.get(uri).timeout(const Duration(seconds: 8));
      if (resp.statusCode != 200) {
        try {
          await DLog.w('LocationService', 'fetchNearbyPois http ${resp.statusCode}');
        } catch (_) {}
        return list;
      }

      final data = jsonDecode(resp.body);
      if (data is! Map || (data['status'] ?? -1) != 0) {
        try {
          await DLog.w('LocationService', 'fetchNearbyPois status=${data is Map ? data['status'] : 'INVALID'}');
        } catch (_) {}
        return list;
      }

      final results = data['results'];
      if (results is! List) return list;

      for (final item in results) {
        if (item is! Map) continue;
        final name = (item['name'] ?? '').toString();
        if (name.isEmpty) continue;

        final loc = item['location'];
        double? lat;
        double? lng;
        if (loc is Map) {
          final latVal = loc['lat'] ?? loc['latitude'];
          final lngVal = loc['lng'] ?? loc['longitude'];
          lat = latVal is num ? latVal.toDouble() : double.tryParse((latVal ?? '').toString());
          lng = lngVal is num ? lngVal.toDouble() : double.tryParse((lngVal ?? '').toString());
        }
        if (lat == null || lng == null) continue;

        final addrStr = (item['address'] ?? '').toString().trim();
        int? distance;
        final dVal = (item['detail_info'] is Map ? item['detail_info']['distance'] : null) ?? item['distance'];
        if (dVal != null) {
          distance = int.tryParse(dVal.toString());
        }

        list.add(PoiItem(
          name: name,
          address: addrStr.isEmpty ? null : addrStr,
          latitude: lat,
          longitude: lng,
          distance: distance,
        ));
      }

      return list;
    } catch (e) {
      try {
        await DLog.w('LocationService', 'fetchNearbyPois error: ' + e.toString());
      } catch (_) {}
      return list;
    }
  }
}
