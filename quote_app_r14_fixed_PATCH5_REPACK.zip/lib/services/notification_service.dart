import 'dart:io';
import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'native_guard.dart';

@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) async {
  // 标记来自通知；导航逻辑在主线程首帧后统一处理
  try { await NotificationService.markLaunchedFromNotification(); } catch (_) {}
}

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static bool _launchFromNotif = false;
  static bool _homeVisible = false;
  static bool _requestedThisSession = false;

  /// 仅供主入口消费使用：是否由通知启动（冷启动）
  static Future<bool> didLaunchFromNotification() async {
    try {
      final details = await _plugin.getNotificationAppLaunchDetails();
      return details?.didNotificationLaunchApp ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> markLaunchedFromNotification() async { _launchFromNotif = true; }
  static bool consumeLaunchFromNotificationFlag() { final v = _launchFromNotif; _launchFromNotif = false; return v; }
  static void markHomeVisible() { _homeVisible = true; _requestedThisSession = false; }

  /// 初始化通知插件与通道（不在此处申请权限）
  static Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(
      initSettings,
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        try { await NotificationService.markLaunchedFromNotification(); } catch (_) {}
        SimpleBus.navHome();
        SimpleBus.pokeHome();
      },
    );

    // Android 通知通道
    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android != null) {
        const AndroidNotificationChannel channel = AndroidNotificationChannel(
          'quote_high', '定时提醒',
          description: 'Quote 定时提醒',
          importance: Importance.high,
          playSound: true,
        );
        await android.createNotificationChannel(channel);
      }
    }
  }

  /// 系统层开关（Android 13+ 的 POST_NOTIFICATIONS）
  static Future<bool> areNotificationsEnabled() async {
    try {
      if (!Platform.isAndroid) return true;
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return true;
      final enabled = await android.areNotificationsEnabled();
      return enabled ?? true;
    } catch (_) {
      return true;
    }
  }

  /// 发送通知（可选大图/大图标）
  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'quote_high', '定时提醒',
      channelDescription: 'Quote 定时提醒',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? BigPictureStyleInformation(
              FilePathAndroidBitmap(largeIconPath),
              largeIcon: FilePathAndroidBitmap(largeIconPath),
              contentTitle: title,
              summaryText: body,
            )
          : const DefaultStyleInformation(true, true),
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails);
    final nid = id ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000);
    await _plugin.show(nid, title, body, details);
  }

  /// 仅在首页可见后、且每个进程只弹一次
  static Future<void> request() async {
    if (!_homeVisible || _requestedThisSession) return;
    _requestedThisSession = true;
    try {
      if (!Platform.isAndroid) return;
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return;
      // 新 API
      try { await android.requestNotificationsPermission(); return; } catch (_) {}
      // 兼容旧版本插件的 API
      try { await (android as dynamic).requestPermission(); } catch (_) {}
    } catch (_) {}
  }

  /// 冷启动捕获：应用由通知启动时标记一次
  static Future<void> captureInitialLaunchFromNotification() async {
    try {
      final details = await _plugin.getNotificationAppLaunchDetails();
      if (details?.didNotificationLaunchApp ?? false) {
        await markLaunchedFromNotification();
      }
    } catch (_) {}
  }
}
