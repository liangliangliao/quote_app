import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView 容器（稳态版）：
/// 1) WebView 透明 + 外层白容器兜底 => 首帧必白；
/// 2) 顶层白遮罩，只有收到 JS Channel 'READY' 才淡出 => 不露灰；
/// 3) onPageFinished 注入两次 rAF 的首帧探针 + 600ms 兜底 + 1s fallback。
class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data;

  const HomeHtmlView({super.key, required this.assetPath, required this.data});

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _webReady = false;
  bool _htmlLoaded = false;
  bool _dataApplied = false;
  Timer? _firstPaintTimeout;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000)) // 透明，交由外层白容器兜底
      ..addJavaScriptChannel('READY', onMessageReceived: (JavaScriptMessage msg){
        if (!_webReady && mounted) setState(() => _webReady = true);
      })
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (url) async {
          _htmlLoaded = true;
          // 注入首帧探针：两次 rAF + load + 600ms 兜底
          const readyProbe = """
            (function(){
              try{
                const mark=()=>{ try{ if(window.READY&&READY.postMessage) READY.postMessage('ok'); }catch(e){} };
                requestAnimationFrame(()=>requestAnimationFrame(mark));
                window.addEventListener('load', ()=>setTimeout(mark,0), {once:true,capture:true});
                setTimeout(mark, 600);
              }catch(e){}
            })();
          """;
          try { await _controller.runJavaScript(readyProbe); } catch (_) {}

          // 有数据则注入
          if (widget.data != null) {
            try {
              final jsonStr = jsonEncode(widget.data);
              await _controller.runJavaScript("window.APP_DATA = $jsonStr; if(window.applyData){ try{ applyData(window.APP_DATA); }catch(e){} }");
              _dataApplied = true;
            } catch (_) {}
          }

          // 1s 安全兜底，防止 READY 丢失导致一直白遮罩
          _firstPaintTimeout?.cancel();
          _firstPaintTimeout = Timer(const Duration(seconds: 1), () {
            if (mounted && !_webReady) setState(() => _webReady = true);
          });
        },
      ));

    // 先加载一页纯白，保证第0帧就是白
    _controller.loadHtmlString('<!doctype html><meta name="color-scheme" content="light"><style>html,body{margin:0;height:100%;background:#fff}</style>');
    // 再加载真实 asset
    _controller.loadFlutterAsset(widget.assetPath);
  }

  @override
  void dispose() {
    _firstPaintTimeout?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: Colors.white,
          clipBehavior: Clip.hardEdge,
          child: WebViewWidget(controller: _controller),
        ),
        AnimatedOpacity(
          opacity: _webReady ? 0.0 : 1.0,
          duration: const Duration(milliseconds: 180),
          child: const ColoredBox(color: Colors.white),
        ),
        // 底部细线（若你原设计有）
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: IgnorePointer(
            child: SizedBox(
              height: (2.0 / MediaQuery.of(context).devicePixelRatio),
              child: const ColoredBox(color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}