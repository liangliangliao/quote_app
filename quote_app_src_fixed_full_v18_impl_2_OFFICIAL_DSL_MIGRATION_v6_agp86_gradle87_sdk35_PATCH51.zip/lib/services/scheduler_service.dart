
import 'dart:isolate';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';

import '../data/dao.dart';
import '../data/db.dart';
import '../platform/perm_helper.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import '../main.dart';

class SchedulerService {
  static const int _kDispatcherAlarmId = 999000;
  static const int _kSafetyTickerId = 999001;

  /// Initialize AlarmManager and Notification plugin (idempotent).
  static Future<void> init() async {
    await AndroidAlarmManager.initialize();
    await NotificationService.init();
  }

  /// Format helper consistent with DB schema.
  static String _fmt(DateTime dt) => DateFormat('yyyy-MM-dd HH:mm').format(dt);

  /// Parse an 'yyyy-MM-dd HH:mm' string to DateTime (local).
  static DateTime? _parse(String s) {
    if (s.isEmpty) return null;
    try { return DateFormat('yyyy-MM-dd HH:mm').parse(s); } catch (_) { return null; }
  }

  /// Compute next time for a task record, from a given 'now'.
  static DateTime _computeNext(Map<String, dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    // baseline hour:minute from current or from existing start_time
    int hh = now.hour, mm = now.minute;
    final st = (t['start_time'] ?? '') as String;
    final parsed = _parse(st);
    if (parsed != null) { hh = parsed.hour; mm = parsed.minute; }

    final String freqType = (t['freq_type'] ?? 'daily') as String;
    if (freqType == 'weekly') {
      final int wd = (t['freq_weekday'] as int?) ?? 1; // Mon=1..Sun=7
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freqType == 'monthly') {
      final int d = (t['freq_day_of_month'] as int?) ?? 1;
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1; if (m > 12) { m = 1; y += 1; }
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      var cand = DateTime(now.year, now.month, now.day, hh, mm);
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 1));
      return cand;
    }
  }

  /// Whether a start_time string is due within a small window around 'now'.
  static bool _isDue(String start, DateTime now) {
    final dt = _parse(start);
    if (dt == null) return false;
    return !dt.isAfter(now.add(const Duration(seconds: 59)));
  }

  static int _alarmIdForTask(String uid) {
    // simple stable hash
    var h = 1125899906842597; // prime
    for (final c in uid.codeUnits) { h = (h * 31 + c) & 0x7fffffff; }
    return 1000 + (h % 500000); // stay in safe range
  }

  /// Recompute next times for all ON tasks and schedule ONE dispatcher at the earliest time.
  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    final canExact = await PermHelper.hasExactAlarmPermission();
    final now = DateTime.now();
    DateTime? earliest;
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final next = _computeNext(t, from: now);
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [t['task_uid']]);
      if (earliest == null || next.isBefore(earliest!)) earliest = next;
    }
    if (earliest != null) {
      await AndroidAlarmManager.oneShotAt(
        earliest!,
        _kDispatcherAlarmId,
        _alarmEntryPoint,
        exact: canExact,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
    }
    // schedule a safety ticker every ~15 minutes to catch missed events in Doze/app-standby
    final when = DateTime.now().add(const Duration(minutes: 15));
    await AndroidAlarmManager.oneShotAt(
      when,
      _kSafetyTickerId,
      _tickerEntryPoint,
      exact: false,
      wakeup: true,
      allowWhileIdle: true,
      rescheduleOnReboot: true,
    );
  }

  /// Dispatcher callback: run due tasks and then schedule the next dispatcher at the earliest next time.
  static Future<void> callback() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final tasks = await db.query('tasks');
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final start = (t['start_time'] ?? '') as String;
      if (start.isEmpty) continue;
      if (!_isDue(start, now)) continue;

      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;

      try {
        if (type == 'manual') {
          final q = await QuoteDao().latestForTask(taskUid);
          final content = (q?['content'] ?? '') as String;
          if (content.isNotEmpty) {
            await NotificationService.show(
              id: _alarmIdForTask(taskUid),
              title: name,
              body: content,
              largeIconPath: avatar.isEmpty ? null : avatar,
            );
            await LogDao().add(taskUid: taskUid, detail: '手动任务通知已发送');
          }
        } else if (type == 'auto') {
          final prompt = (t['prompt'] ?? '') as String;
          if (prompt.isNotEmpty) {
            try {
              final cfg = await ConfigDao().getOne();
              final endpoint = (cfg['endpoint'] ?? '') as String;
              final apiKey = (cfg['api_key'] ?? '') as String;
              final model = (cfg['model'] ?? '') as String;
              if (endpoint.isNotEmpty && apiKey.isNotEmpty && model.isNotEmpty) {
                final ai = OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model);
                final content = await ai.generateQuote(prompt);
                if (content.isNotEmpty) {
                  await QuoteDao().insertIfUnique(
                    taskUid: taskUid,
                    type: type,
                    taskName: name,
                    avatarPath: avatar,
                    content: content,
                  );
                  await NotificationService.show(
                    id: _alarmIdForTask(taskUid),
                    title: name,
                    body: content,
                    largeIconPath: avatar.isEmpty ? null : avatar,
                  );
                  await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送');
                }
              } else {
                await LogDao().add(taskUid: taskUid, detail: '自动任务跳过：缺少 OpenAI 配置');
              }
            } catch (e) {
              await LogDao().add(taskUid: taskUid, detail: '自动任务错误：$e');
            }
          }
        } else if (type == 'carousel') {
          final q = await QuoteDao().carouselNextSequential(taskUid);
          final content = (q?['content'] ?? '') as String;
          if (content.isNotEmpty) {
            await NotificationService.show(
              id: _alarmIdForTask(taskUid),
              title: name,
              body: content,
              largeIconPath: avatar.isEmpty ? null : avatar,
            );
            await LogDao().add(taskUid: taskUid, detail: '轮播任务通知已发送');
            final id = (q?['id'] ?? 0) as int;
            if (id != 0) { try { await QuoteDao().markNotified(id); } catch (_){ } }
          }
        }
      } catch (_) {
        await LogDao().add(taskUid: taskUid, detail: '任务执行发生错误');
      }

      // compute and persist next; dispatcher reschedule will be done after loop
      final next = _computeNext(t, from: now.add(const Duration(seconds: 1)));
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
    }

    // After processing: schedule next dispatcher at earliest start_time among ON tasks
    final rows2 = await db.query('tasks');
    DateTime? minNext;
    for (final t2 in rows2) {
      if ((t2['status'] ?? 'on') != 'on') continue;
      final st = (t2['start_time'] ?? '') as String;
      final dt = _parse(st);
      if (dt == null) continue;
      if (minNext == null || dt.isBefore(minNext!)) minNext = dt;
    }
    if (minNext != null) {
      final canExact2 = await PermHelper.hasExactAlarmPermission();
      await AndroidAlarmManager.oneShotAt(
        minNext!,
        _kDispatcherAlarmId,
        _alarmEntryPoint,
        exact: canExact2,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
    }
  }
}

/// Alarm entrypoint (must be top-level or @pragma annotated).
@pragma('vm:entry-point')
Future<void> _alarmEntryPoint(int id) async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (IsolateTokens.token != null) {
      BackgroundIsolateBinaryMessenger.ensureInitialized(IsolateTokens.token!);
    }
  } catch (_) {}
  await SchedulerService.callback();
}

/// Safety ticker: periodically wake and reschedule dispatcher if needed.
@pragma('vm:entry-point')
Future<void> _tickerEntryPoint(int id) async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (IsolateTokens.token != null) {
      BackgroundIsolateBinaryMessenger.ensureInitialized(IsolateTokens.token!);
    }
  } catch (_) {}
  await SchedulerService.scheduleNextForAll();
}
