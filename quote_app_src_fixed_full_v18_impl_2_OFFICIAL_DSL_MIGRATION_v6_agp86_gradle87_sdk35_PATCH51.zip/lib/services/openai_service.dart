
import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  final String endpoint; // e.g., https://api.openai.com/v1/chat/completions or /responses
  final String apiKey;
  final String model;

  OpenAIService({required this.endpoint, required this.apiKey, required this.model});

  Future<String> generateQuote(String prompt) async {
    if (endpoint.isEmpty || apiKey.isEmpty || model.isEmpty) return '';

    final uri = Uri.parse(endpoint);
    final headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
    };

    Map<String, dynamic> payload;

    // Heuristics: support both /responses (Responses API) and /chat/completions
    if (endpoint.endsWith('/responses')) {
      payload = {
        'model': model,
        'input': '请生成一句简洁的中文名人名言，并附上作者或来源。主题：$prompt',
      };
    } else {
      payload = {
        'model': model,
        'messages': [
          {'role': 'system', 'content': '你是一位擅长中文名人名言的助手，只返回一句完整的名人名言并附上作者或来源。'},
          {'role': 'user', 'content': '主题：$prompt'}
        ]
      };
    }

    final resp = await http.post(uri, headers: headers, body: jsonEncode(payload));
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      return '';
    }

    final data = jsonDecode(utf8.decode(resp.bodyBytes));

    // Responses API
    if (data is Map && data['output'] is List && (data['output'] as List).isNotEmpty) {
      final first = (data['output'] as List).first;
      if (first is Map && first['content'] is List && (first['content'] as List).isNotEmpty) {
        final c0 = (first['content'] as List).first;
        if (c0 is Map) {
          final text = c0['text']?['value'] ?? '';
          return text.toString().trim();
        }
      }
    }

    // Chat Completions API
    if (data is Map && data['choices'] is List && (data['choices'] as List).isNotEmpty) {
      final choice0 = (data['choices'] as List).first;
      if (choice0 is Map) {
        final msg = choice0['message'];
        final content = (msg is Map) ? (msg['content'] ?? '') : '';
        return content.toString().trim();
      }
    }

    // Fallback
    if (data is Map && data['content'] != null) {
      return data['content'].toString().trim();
    }

    return '';
  }
}
