

import 'dart:io';
import 'package:flutter/services.dart';

class NotificationService {
  static const _ch = MethodChannel('com.example.quote_app/sysperms');

  static Future<void> gateExactAlarmOnFirstOpen() async {
    if (!Platform.isAndroid) return;
    final noti = await areNotificationsEnabled();
    if (!noti) return;
    final can = await _ch.invokeMethod<bool>('canScheduleExactAlarms') ?? true;
    if (!can) { await _ch.invokeMethod('requestExactAlarm'); }
  }

  static Future<bool> areNotificationsEnabled() async {
    if (!Platform.isAndroid) return true;
    try { return await _ch.invokeMethod<bool>('notificationsEnabled') ?? true; } catch (_) { return true; }
  }
}
