package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver：仅作为轻量入口，接收解锁广播，然后触发后台 UnlockWorker。
 * 具体业务逻辑（查库、开关、冷却时间以及发送通知）全部在 UnlockWorker 中完成。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val act = intent?.action ?: "null"
    try {
      // 记录收到的解锁广播（解锁场景仅关心 USER_PRESENT）
      DbRepo.log(context, null, "【解锁后台】UnlockReceiver 收到系统解锁广播 action=$act，准备触发后台 UnlockWorker（回包：OK）")
    } catch (_: Throwable) {}

    // 轻量提示：仅在进程仍存活且收到解锁事件时，给出一次 Toast 提示
    try {
      Toast.makeText(context.applicationContext, "已捕获解锁事件，后台正在准备解锁提醒", Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) {}

    // 触发后台解锁 Worker，避免在广播线程中做重活
    try {
      UnlockWorker.trigger(context.applicationContext)
    } catch (_: Throwable) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 触发 UnlockWorker 失败（回包：FAIL）")
      } catch (_: Throwable) {}
    }
  }
}
