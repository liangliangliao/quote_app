package com.example.quote_app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import com.example.quote_app.data.DbRepo

/**
 * UnlockAccessibilityService
 *
 * An AccessibilityService used as an alternate path to observe real
 * device unlocks on ROMs where USER_PRESENT / SCREEN_ON broadcasts
 * are aggressively filtered for background apps.
 *
 * It detects a transition from "keyguard locked" to "unlocked" with
 * a HOME/launcher or user app window in the foreground, then delegates
 * to [UnlockReceiver] so that all existing business logic (user switch,
 * cooldown, geo rules, logging, notifications) remains centralized.
 */
class UnlockAccessibilityService : AccessibilityService() {

    private var lastLocked: Boolean = false
    private var lastUnlockTs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        lastLocked = isKeyguardLockedSafe()
        try {
            DbRepo.log(this, null, "[Accessibility] service connected, initial locked=" + lastLocked)
        } catch (_: Throwable) {
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) {
            return
        }
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            return
        }

        val nowLocked = isKeyguardLockedSafe()
        val pkg = event.packageName?.toString() ?: ""

        if (nowLocked) {
            // Still on keyguard; mark as locked and ignore.
            lastLocked = true
            try {
                DbRepo.log(this, null, "[Accessibility] still locked, pkg=" + pkg)
            } catch (_: Throwable) {
            }
            return
        }

        // Device is now unlocked.
        if (!lastLocked) {
            // We did not observe a locked->unlocked transition; treat as normal
            // window change (e.g. app-to-app) and ignore.
            return
        }

        // Candidate unlock transition: previously locked, now unlocked.
        if (!isHomeOrUserApp(pkg)) {
            // Foreground window is not launcher or this app; be conservative
            // and ignore to avoid false positives.
            lastLocked = false
            try {
                DbRepo.log(this, null, "[Accessibility] unlock candidate rejected, pkg=" + pkg)
            } catch (_: Throwable) {
            }
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastUnlockTs < 3000L) {
            // Multiple WINDOW_STATE changes may fire around a single unlock;
            // debounce within a short window.
            lastLocked = false
            try {
                DbRepo.log(this, null, "[Accessibility] unlock debounce, pkg=" + pkg)
            } catch (_: Throwable) {
            }
            return
        }

        lastLocked = false
        lastUnlockTs = now
        try {
            DbRepo.log(this, null, "[Accessibility] unlock detected, pkg=" + pkg)
        } catch (_: Throwable) {
        }

        onUnlockDetected("accessibility_keyguard_transition")
    }

    override fun onInterrupt() {
        // no-op
    }

    private fun isKeyguardLockedSafe(): Boolean {
        return try {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                km.isKeyguardLocked || km.isDeviceLocked
            } else {
                km.isKeyguardLocked
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun isHomeOrUserApp(pkg: String): Boolean {
        if (pkg.isEmpty()) return false
        if (pkg == packageName) return true
        return try {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            val resolveInfos = pm.queryIntentActivities(intent, 0)
            for (ri in resolveInfos) {
                val ai = ri.activityInfo ?: continue
                if (pkg == ai.packageName) {
                    return true
                }
            }
            false
        } catch (_: Throwable) {
            false
        }
    }

    private fun onUnlockDetected(reason: String) {
        val ctx = applicationContext
        try {
            DbRepo.log(ctx, null, "[Accessibility] onUnlockDetected, reason=" + reason)
        } catch (_: Throwable) {
        }

        // Delegate to existing UnlockReceiver so that switch/cooldown/geo logic
        // and logging remain centralized.
        try {
            val receiver = UnlockReceiver()
            val intent = Intent(Intent.ACTION_USER_PRESENT).apply {
                putExtra("from_accessibility", reason)
            }
            receiver.onReceive(ctx, intent)
        } catch (_: Throwable) {
            // never crash the service
        }

        // Best-effort: ensure ScreenGatekeeperService is running so that any
        // geo/location related work stays active in the background.
        try {
            val svcIntent = Intent(ctx, ScreenGatekeeperService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(svcIntent)
            } else {
                ctx.startService(svcIntent)
            }
            try {
                DbRepo.log(ctx, null, "[Accessibility] requested ScreenGatekeeperService start")
            } catch (_: Throwable) {
            }
        } catch (_: Throwable) {
            // ignore; unlock notification already handled above
        }
    }
}
