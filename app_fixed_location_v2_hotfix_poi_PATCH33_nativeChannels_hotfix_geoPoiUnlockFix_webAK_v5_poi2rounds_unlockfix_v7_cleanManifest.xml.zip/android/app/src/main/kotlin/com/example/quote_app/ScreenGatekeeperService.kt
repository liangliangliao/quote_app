package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 解锁守护前台服务：
 * - 以可见通知保持进程常驻；
 * - 动态注册 ACTION_USER_PRESENT / ACTION_USER_UNLOCKED / ACTION_SCREEN_ON；
 * - 在收到事件后：立刻 Toast + 启动透明 Activity（FgKickActivity），并写中文日志；
 * - 3 秒去抖，避免重复触发。
 */
class ScreenGatekeeperService : Service() {

  private var probe: BroadcastReceiver? = null

  override fun onCreate() {
    super.onCreate()
    try { DbRepo.log(this, null, "【解锁守护服务】onCreate：准备启动前台并注册监听") } catch (_: Throwable) {}

    startAsForeground()

    // 动态注册解锁 / 亮屏相关广播
    val filter = IntentFilter().apply {
      addAction(Intent.ACTION_USER_PRESENT)
      addAction(Intent.ACTION_USER_UNLOCKED)
      addAction(Intent.ACTION_SCREEN_ON)
    }

    probe = object : BroadcastReceiver() {
      override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val appCtx = applicationContext

        // 3 秒去抖
        val prefs = appCtx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
        val nowRt = SystemClock.elapsedRealtime()
        val last = prefs.getLong("gatekeeper_last_rt", 0L)
        if (last > 0L && (nowRt - last) < 3000L) {
          return
        }
        prefs.edit().putLong("gatekeeper_last_rt", nowRt).apply()

        try {
          Toast.makeText(appCtx, "已解锁：事件已被监听（守护）", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {}

        try { DbRepo.log(appCtx, null, "【解锁守护服务】收到广播：$action，已弹出Toast，准备启动透明Activity") } catch (_: Throwable) {}

        // 启动透明 Activity 统一调度地点规则+轻提醒
        try {
          val act = Intent(appCtx, FgKickActivity::class.java)
          act.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          appCtx.startActivity(act)
        } catch (t: Throwable) {
          try { DbRepo.log(appCtx, null, "【解锁守护服务】启动透明Activity异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
        }
      }
    }
    registerReceiver(probe, filter)

    try { DbRepo.log(this, null, "【解锁守护服务】已完成动态注册解锁/亮屏监听") } catch (_: Throwable) {}
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // 保持常驻
    return START_STICKY
  }

  private fun startAsForeground() {
    val channelId = "unlock_guard"
    val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(channelId, "解锁守护", NotificationManager.IMPORTANCE_MIN)
      nm.createNotificationChannel(ch)
      val n: Notification = Notification.Builder(this, channelId)
        .setContentTitle("解锁监听已启用")
        .setContentText("确保解锁时立刻响应 Toast 与提醒")
        .setSmallIcon(android.R.drawable.stat_sys_warning)
        .setOngoing(true)
        .build()
      startForeground(1002, n)
    }
  }

  override fun onDestroy() {
    try { unregisterReceiver(probe) } catch (_: Throwable) {}
    probe = null
    try { DbRepo.log(this, null, "【解锁守护服务】onDestroy：已注销监听") } catch (_: Throwable) {}
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null
}
