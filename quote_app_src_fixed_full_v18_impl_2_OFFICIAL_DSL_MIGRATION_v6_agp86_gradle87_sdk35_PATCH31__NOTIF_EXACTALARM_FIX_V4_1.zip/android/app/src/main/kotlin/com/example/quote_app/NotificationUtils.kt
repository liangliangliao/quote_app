package com.example.quote_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat

object NotificationUtils {
    const val DEFAULT_CHANNEL_ID = "quote_app.default"
    private const val DEFAULT_CHANNEL_NAME = "General"
    private const val DEFAULT_CHANNEL_DESC = "General notifications for Quote App"

    fun ensureDefaultChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val existing = nm.getNotificationChannel(DEFAULT_CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    DEFAULT_CHANNEL_ID,
                    DEFAULT_CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                )
                channel.description = DEFAULT_CHANNEL_DESC
                channel.enableVibration(true)
                nm.createNotificationChannel(channel)
            }
        }
    }

    fun areNotificationsEnabled(context: Context): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }
}