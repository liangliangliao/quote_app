package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String taskUid = intent.getStringExtra("task_uid");
        String runKey  = intent.getStringExtra("run_key");
        if (taskUid == null || taskUid.isEmpty() || runKey == null || runKey.isEmpty()) {
            Log.e("AlarmReceiver","missing task_uid/run_key → fallback");
            com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native fallback");
            Notifier.fallback(context); return;
        }

        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] alarm received runKey="+runKey);
                try {
                    boolean handled = com.example.quote_app.biz.Biz.run(context.getApplicationContext(), taskUid);
                    if (handled) {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] Biz.run handled");
                        pending.finish();
                        return;
                    } else {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] Biz.run returned false → try native lookup");
                    }
                } catch (Throwable t) {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] Biz.run exception: "+t.getMessage());
                }

                String dbPath = DbPaths.quotesDbPath(context);
                SqliteReader.Payload exact = SqliteReader.queryExact(dbPath, taskUid, runKey);
                if (exact != null) {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native exact hit for runKey="+runKey);
                    Notifier.notify(context, exact);
                } else {
                    String[] win = RunKey.windowBefore(runKey, 30);
                    SqliteReader.Payload near = SqliteReader.queryNearest(dbPath, taskUid, win[0], win[1]);
                    if (near != null) {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native nearest hit");
                        Notifier.notify(context, near);
                    } else {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native fallback");
                        Notifier.fallback(context);
                    }
                }
            } catch (Throwable t) {
                Log.e("AlarmReceiver","read db failed: " + t.getMessage(), t);
                com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] exception: "+t.getMessage());
                Notifier.fallback(context);
            } finally {
                pending.finish();
            }
        }).start();
    }
}
