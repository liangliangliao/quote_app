package com.example.quote_app.am;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;

public final class SqliteReader {
  private SqliteReader(){}
  public static final class Payload {
    public final String title, content, avatarPath, actionsJson, payloadJson;
    public Payload(String t, String c, String a, String act, String pj){
      this.title=t; this.content=c; this.avatarPath=a; this.actionsJson=act; this.payloadJson=pj;
    }
  }
  private static SQLiteDatabase open(String path){
    try { return SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY); } catch (Throwable t){ return null; }
  }
  public static Payload queryExact(String dbPath, String taskUid, String runKey){
    SQLiteDatabase db = open(dbPath);
    if (db==null) return null;
    try {
      Cursor c = db.rawQuery("SELECT title,content,avatar_path,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key=? LIMIT 1", new String[]{taskUid, runKey});
      try {
        if (c.moveToFirst()){
          return new Payload(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4));
        }
      } finally { c.close(); }
    } catch(Throwable ignore){} finally { db.close(); }
    return null;
  }
  public static Payload queryNearest(String dbPath, String taskUid, String fromRunKey, String toRunKey){
    SQLiteDatabase db = open(dbPath);
    if (db==null) return null;
    try {
      Cursor c = db.rawQuery("SELECT title,content,avatar_path,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key>=? AND run_key<=? ORDER BY run_key DESC LIMIT 1", new String[]{taskUid, fromRunKey, toRunKey});
      try {
        if (c.moveToFirst()){
          return new Payload(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4));
        }
      } finally { c.close(); }
    } catch(Throwable ignore){} finally { db.close(); }
    return null;
  }
}
