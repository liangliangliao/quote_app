# 距离：高贵者 - 单机安卓版工程

这是一个可在 Android Studio 中直接打开的**单机版 Android App 工程**。

## 形态
- 本地单机
- 无服务器依赖
- 游戏内容运行在本地 WebView 中
- 存档使用浏览器 localStorage，保存在设备本地

## 运行方式
1. 用 Android Studio 打开本项目根目录
2. 等待 Gradle 同步完成
3. 连接 Android 手机或启动模拟器
4. 点击 Run 运行
5. 也可以用 Build > Build APK(s) 生成 APK

## 目录说明
- `app/src/main/java/.../MainActivity.kt`：Android 入口
- `app/src/main/assets/web/`：游戏前端原型资源
- `app/build.gradle`：App 模块构建配置

## 当前已实现
- 主城
- 建筑升级
- 角色
- 文明指标
- 主线任务
- 招募
- 简化战斗
- 编年史
- 本地存档

## 下一步建议
- 把法令页、静室页、商店页、活动页补进 `assets/web`
- 再把战斗系统从简化回合制升级成正式玩法
- 最后再做图像资源和音效接入
