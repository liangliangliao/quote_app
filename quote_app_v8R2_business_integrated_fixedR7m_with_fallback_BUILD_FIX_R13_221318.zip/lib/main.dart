import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:workmanager/workmanager.dart';
import 'package:flutter/widgets.dart';
//import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'data/db.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'services/wm_dispatcher.dart';
import 'background_tasks.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';
import 'utils/debug_logger.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  //ui.DartPluginRegistrant.ensureInitialized();


  await AppDatabase.instance();
  await NotificationService.init();
 // WidgetsFlutterBinding.ensureInitialized();
  await AndroidAlarmManager.initialize();
  await scheduleOneShotAt124456();
 



  runApp(const MyApp());
}



/// 回调：必须是顶层/静态函数，并标注 entry-point，才能在后台 isolate 被调用
@pragma('vm:entry-point')
Future<void> alarmCb124456() async {
  // 背景 isolate 中使用插件前先确保初始化
  WidgetsFlutterBinding.ensureInitialized();
//  DartPluginRegistrant.ensureInitialized();
await DLog.i('SCH', '测试函数被调用！');
  // 发送一条本地通知（需要已集成 flutter_local_notifications）
  final flnp = FlutterLocalNotificationsPlugin();
  const init = InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
  );
  await flnp.initialize(init);

  const androidDetails = AndroidNotificationDetails(
    'alarm_channel_124456',            // 渠道 ID
    'Alarm & Reminders',               // 渠道名（用户可见）
    channelDescription: 'Alarm fired notifications',
    importance: Importance.max,
    priority: Priority.high,
    playSound: true,
    enableVibration: true,
    ticker: 'alarm_ticker',
  );

  await flnp.show(
    124456,                            // 通知 ID
    '到点提醒',
    '两分钟前设置的闹钟已触发（ID=124456）',
    const NotificationDetails(android: androidDetails),
    payload: 'alarm:124456',
  );
}

/// 安排：从“当前系统时间”延后 2 分钟触发
Future<void> scheduleOneShotAt124456() async {
  final when = DateTime.now().add(const Duration(minutes: 2));
  await AndroidAlarmManager.oneShotAt(
    when,
    124456,
    alarmCb124456,
    exact: true,
    allowWhileIdle: true,
    wakeup: true,
    alarmClock: true,
  );
  await DLog.i('SCH', '测试函数注册！');
}

/// 在合适位置调用一次（例如 main 里



class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const AppGate(),
    );
  }
}

class AppGate extends StatefulWidget {
  const AppGate({super.key});
  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    // 仅保留“系统通知权限授权弹框”：首次打开直接弹系统授权
    await NotificationService.request();
    final enabled = await NotificationService.isEnabled();
    if (!enabled) {
      await DLog.i('PERM', 'notification denied -> exit');
      SystemNavigator.pop();
      return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const _Shell()));
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

class _Shell extends StatefulWidget {
  const _Shell({super.key});
  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) => setState(() => _idx = i),
      ),
    );
  }
}