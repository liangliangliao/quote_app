package com.example.quote_app

import android.app.Application
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugins.GeneratedPluginRegistrant
import dev.fluttercommunity.plus.workmanager.WorkmanagerPlugin

class App : Application(), WorkmanagerPlugin.FlutterEngineInitializer {
  override fun onCreate() {
    super.onCreate()
    WorkmanagerPlugin.setFlutterEngineInitializer(this)
  }

  override fun initialize(engine: FlutterEngine) {
    GeneratedPluginRegistrant.registerWith(engine)
    Channels.register(engine, applicationContext)
  }
}
