import 'dart:isolate';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:quote_app/app_globals.dart';
import 'package:quote_app/platform/perm_helper.dart';
import 'package:flutter/services.dart' show BackgroundIsolateBinaryMessenger;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
// ignore: implementation_imports

class SchedulerService {
  static Future<void> init() async {
    // Already initialized in main(); safe to call again (idempotent)
    await AndroidAlarmManager.initialize(); // idempotent
    // 记录精确闹钟权限状态（不弹任何引导）
    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (!ok) { await LogDao().add(taskUid: 'system', detail: '警告! 系统未授予精确闹钟权限(Alarms & reminders)。Android 14+ 默认关闭。'); }
    } catch (_) {}

    await scheduleNextForAll();
  }

  static int _alarmIdForTask(String taskUid) {
    // stable 31-bit hash
    int h = 0;
    for (int i=0;i<taskUid.length;i++) {
      h = (h * 131 + taskUid.codeUnitAt(i)) & 0x7fffffff;
    }
    return h;
  }

  static DateTime _computeNext(Map<String,dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    String freq = (t['freq_type'] ?? 'daily') as String;
    int? weekday = t['freq_weekday'] as int?;
    int? dayOfMonth = t['freq_day_of_month'] as int?;
    final startStr = (t['start_time'] ?? '') as String;
    int hh = 9, mm = 0;
    if (startStr.contains(' ')) {
      final hm = startStr.split(' ')[1].split(':');
      if (hm.length==2) {
        hh = int.tryParse(hm[0]) ?? 9;
        mm = int.tryParse(hm[1]) ?? 0;
      }
    }
    if (freq == 'weekly') {
      final wd = (weekday ?? 1);
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freq == 'monthly') {
      final d = (dayOfMonth ?? 1);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      final today = DateTime(now.year, now.month, now.day, hh, mm);
      if (today.isAfter(now)) return today;
      return today.add(const Duration(days: 1));
    }
  }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    // Fallback: if system denies exact alarm, use inexact scheduling
    final canExact = await PermHelper.hasExactAlarmPermission();
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final next = _computeNext(t);
      // Persist next into tasks.start_time —— 1.1需求
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [t['task_uid']]);
      final id = _alarmIdForTask(t['task_uid'] as String);
      await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: canExact,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );

      // Also schedule a native fallback notification at the same time.
      try {
        final title = (t['name'] ?? '') as String;
        final type = (t['type'] ?? 'auto') as String;
        String body = '到点啦，打开App查看内容';
        if (type == 'manual') {
          final q = await QuoteDao().latestForTask(t['task_uid'] as String);
          final content = (q?['content'] ?? '') as String;
          if (content.isNotEmpty) body = content;
        }
        await PermHelper.scheduleNativeNotification(
          whenMs: next.millisecondsSinceEpoch,
          title: title,
          body: body,
          nid: id,
        );
      } catch (_) {}

    }
  }

  static Future<void> callback() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nowStr = _fmt(now);
    final tasks = await db.query('tasks');
    // Fallback: if system denies exact alarm, use inexact scheduling
    final canExact = await PermHelper.hasExactAlarmPermission();
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final start = (t['start_time'] ?? '') as String;
      // fire if start_time <= now + 59s window
      if (start.isEmpty) continue;
      if (!_isDue(start, now)) continue;

      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        final content = (q?['content'] ?? '') as String;
        if (content.isNotEmpty) {
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
await LogDao().add(taskUid: taskUid, detail: '手动任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '手动任务没有可发送内容');
        }
      } else if (type == 'carousel') {
        var q = await QuoteDao().carouselNextSequential(taskUid);
if (q == null) {
  const def = '保持饥饿，保持愚蠢。—— 史蒂夫·乔布斯';
  final exists = await QuoteDao().existsSimilar(def, threshold: 0.9);
  if (!exists) {
    await QuoteDao().insertIfUnique(
      taskUid: taskUid,
      type: 'carousel',
      taskName: name,
      avatarPath: avatar,
      content: def,
    );
  }
  q = await QuoteDao().carouselNextSequential(taskUid);
  if (q == null) {
    // 仍为空，写日志并返回
    await LogDao().add(taskUid: taskUid, detail: '错误! 轮播无可用名言（兜底失败）');
    return;
  }
}

        if (q != null) {
          final content = (q['content'] ?? '') as String;
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
await QuoteDao().markNotified(q['id'] as int);
          await LogDao().add(taskUid: taskUid, detail: '轮播任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '轮播任务无可用名言');
        }
      } else {

// auto
bool didNotify = false;
final cfg = await ConfigDao().getOne();
// 0) Try to show quickly from cache if we have any previous content
try {
  final prev = await QuoteDao().latestForTask(taskUid);
  final prevContent = (prev?['content'] ?? '') as String;
  if (prevContent.isNotEmpty) {
    await NotificationService.show(
      id: _alarmIdForTask(taskUid),
      title: name,
      body: prevContent,
      largeIconPath: avatar.isEmpty ? null : avatar,
    );
    try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
    await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送(缓存)');
    didNotify = true;
  }
} catch (_) {}
// 1) Generate new content for next round (non-blocking for current notification experience)
try {
  final openai = OpenAIService(
    endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
    apiKey: (cfg['api_key'] ?? '') as String,
    model: (cfg['model'] ?? 'gpt-5') as String,
  );
  final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;
  String? uid;
  for (int i=0; i<5; i++) {
    final reply = (await openai.generateQuote(prompt)).trim();
    if (reply.isNotEmpty) {
      uid = await QuoteDao().insertIfUnique(
        taskUid: taskUid,
        type: 'auto',
        taskName: name,
        avatarPath: avatar,
        content: reply,
      );
      if (uid != null) break;
    }
  }
  // If we didn't notify earlier (no cache), at least show default content this time
  if (!didNotify) {
    final latest = await QuoteDao().latestForTask(taskUid);
    final content = ((latest?['content'] ?? '') as String).trim();
    final body = content.isNotEmpty ? content : '到点啦，打开App查看内容';
    await NotificationService.show(
      id: _alarmIdForTask(taskUid),
      title: name,
      body: body,
      largeIconPath: avatar.isEmpty ? null : avatar,
    );
    try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
    await LogDao().add(taskUid: taskUid, detail: content.isNotEmpty ? '自动任务通知已发送(新生成)' : '自动任务通知已发送(默认)');
    didNotify = true;
  }
} catch (e) {
  // openai或数据库失败，本次仍确保已经尽力通知
  if (!didNotify) {
    try {
      await NotificationService.show(
        id: _alarmIdForTask(taskUid),
        title: name,
        body: '到点啦，打开App查看内容',
        largeIconPath: avatar.isEmpty ? null : avatar,
      );
      try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
      await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送(默认, 生成失败)');
      didNotify = true;
    } catch (_) {}
  }
  await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
}

}

      // After firing: compute next and persist + reschedule
      final next = _computeNext(t, from: now.add(const Duration(seconds: 1)));
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
      final id = _alarmIdForTask(taskUid);
      final canExact2 = await PermHelper.hasExactAlarmPermission();
      await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: canExact2,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
    
      // Also schedule a native fallback notification at the same time.
      try {
        final title = name;
        final ttype = type;
        String body = '到点啦，打开App查看内容';
        if (ttype == 'manual') {
          final q = await QuoteDao().latestForTask(taskUid);
          final content = (q?['content'] ?? '') as String;
          if (content.isNotEmpty) body = content;
        }
        await PermHelper.scheduleNativeNotification(
          whenMs: next.millisecondsSinceEpoch,
          title: title,
          body: body,
          nid: id,
        );
      } catch (_) {}
}
  }

  static bool _isDue(String start, DateTime now) {
    // start format: YYYY-MM-DD HH:mm
    try {
      final dt = DateFormat('yyyy-MM-dd HH:mm').parse(start);
      return !dt.isAfter(now);
    } catch (_) {
      return false;
    }
  }
}

@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();
  
  
try {
  if (AppGlobals.rootIsolateToken != null) {
    BackgroundIsolateBinaryMessenger.ensureInitialized(AppGlobals.rootIsolateToken!);
    try { await LogDao().add(taskUid: 'system', detail: '后台通道已用RootIsolateToken绑定'); } catch (_) {}
  } else {
    // 进程被系统冷启动时常见为null；无需阻塞，按无token模式继续（依赖DartPluginRegistrant.ensureInitialized）
    try { await LogDao().add(taskUid: 'system', detail: '警告! RootIsolateToken为空，按无token模式初始化'); } catch (_) {}
  }
} catch (e) {
  try { await LogDao().add(taskUid: 'system', detail: 'RootIsolateToken绑定异常: ' + e.toString()); } catch (_) {}
}

  try {
    await NotificationService.init();
  } catch (e) {
    try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: '通知初始化失败: ' + e.toString()); } catch (_) {}
  }
  await AppDatabase.instance();
  try {
    await SchedulerService.callback();
      } catch (e, st) {
    try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: 'callback异常: ' + e.toString()); } catch (_) {}
    await _scheduleRetryIn(minutes: 1);
  }
}

String _fmt(DateTime dt) {
  final f = DateFormat('yyyy-MM-dd HH:mm');
  return f.format(dt);
}


// -----------------------------------------------------------------------------
// Background retry helper: schedule a one-shot retry to re-enter alarmCallback.
// Safe to call from background isolate.
// -----------------------------------------------------------------------------
Future<void> _scheduleRetryIn({int minutes = 1}) async {
  try {
    final when = DateTime.now().add(Duration(minutes: minutes));
    const int _retryId = 19997;
    await AndroidAlarmManager.oneShotAt(
      when,
      _retryId,
      alarmCallback,
      exact: true,
      wakeup: true,
      allowWhileIdle: true,
      rescheduleOnReboot: true,
    );
  } catch (e) {
    try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: 'retry安排失败: ' + e.toString()); } catch (_) {}
  }
}
