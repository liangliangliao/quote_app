package com.example.quote_app

import java.util.Locale
import java.security.MessageDigest

object IdCard {
  // src=am|main-wm|fallback-wm|selfck-wm
  @JvmStatic fun srcOf(id: String?): String {
    if (id==null) return ""
    val m = Regex("src=([^_]+)").find(id) ?: return ""
    return m.groupValues.getOrNull(1) ?: ""
  }
  @JvmStatic fun runKeyOf(id: String?): String {
    if (id==null) return ""
    val m = Regex("runkey=([^_]+)").find(id) ?: return ""
    return m.groupValues.getOrNull(1) ?: ""
  }
  @JvmStatic fun uidOf(id: String?): String {
    if (id==null) return ""
    val m = Regex("uid=(.+)$").find(id) ?: return ""
    return m.groupValues.getOrNull(1) ?: ""
  }
  @JvmStatic fun build(src: String, runKey: String, uid: String): String {
    return "src="+src+"_runkey="+runKey+"_uid="+uid
  }
  @JvmStatic fun wmUniqueName(id: String?): String {
    val s = (id ?: "")
    // use SHA-1 to avoid invalid characters and length limits
    val md = MessageDigest.getInstance("SHA-1")
    val bytes = md.digest(s.toByteArray(Charsets.UTF_8))
    val hex = bytes.joinToString("") { "%02x".format(it) }
    return "wm_uni_"+hex
  }
}