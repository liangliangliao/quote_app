import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Text controller for diary content that keeps the underlying text
/// storage-compatible (including attachment marker lines like
///   [图片] /path/to/file
///   [语音] /path/to/file
/// ) but hides the concrete file paths from the user interface while
/// preserving caret/selection behaviour.
class DiaryContentController extends TextEditingController {
  DiaryContentController({String? text}) : super(text: text);

  static bool _isMarkerLine(String line) {
    final l = line.trimLeft();
    return l.startsWith('[图片]') || l.startsWith('[语音]');
  }

  /// Replace the entire logical marker line with zero-width spaces so that:
  ///  * neither the "[图片]"/"[语音]" token nor the real file path are visible;
  ///  * the number of characters in the line stays identical to the
  ///    original text, keeping caret positions valid.
  static String _maskMarkerLine(String line) {
    if (line.isEmpty) return line;
    final int leadingSpaces = line.length - line.trimLeft().length;
    final String trimmed = line.trimLeft();
    if (trimmed.isEmpty) {
      return line;
    }
    final String invisible = '\u200B' * trimmed.length;
    return ' ' * leadingSpaces + invisible;
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    bool withComposing = true,
  }) {
    final TextStyle baseStyle = style ?? DefaultTextStyle.of(context).style;
    final String fullText = value.text;
    if (fullText.isEmpty) {
      return TextSpan(style: baseStyle);
    }

    final List<InlineSpan> children = <InlineSpan>[];
    final List<String> lines = fullText.split('\n');

    for (int i = 0; i < lines.length; i++) {
      final String rawLine = lines[i];
      final String trimmedLeft = rawLine.trimLeft();

      if (trimmedLeft.startsWith('[图片]')) {
        // 富文本图片：将整行 marker 渲染为一个内联图片组件。
        final String path = trimmedLeft.substring('[图片]'.length).trimLeft();
        if (path.isNotEmpty) {
          children.add(
            WidgetSpan(
              alignment: PlaceholderAlignment.bottom,
              baseline: TextBaseline.alphabetic,
              child: _InlineImage(path: path),
            ),
          );
        }
      } else if (_isMarkerLine(rawLine)) {
        // 其它附件类型（目前是 [语音]）仍按旧逻辑隐藏 marker 文本，
        // 只保留行高，具体展示由外部附件区域负责。
        final String masked = _maskMarkerLine(rawLine);
        if (masked.isNotEmpty) {
          _buildLineSpans(masked, baseStyle, children);
        }
      } else {
        _buildLineSpans(rawLine, baseStyle, children);
      }

      if (i < lines.length - 1) {
        children.add(TextSpan(text: '\n', style: baseStyle));
      }
    }

    return TextSpan(style: baseStyle, children: children);
  }

  static void _buildLineSpans(
      String line,
      TextStyle baseStyle,
      List<InlineSpan> out,
    ) {
      // Very small URL highlighter so existing behaviour is roughly preserved.
      final RegExp linkReg = RegExp(r'https?://[^\s]+');

      int index = 0;
      for (final Match m in linkReg.allMatches(line)) {
        if (m.start > index) {
          out.add(TextSpan(
            text: line.substring(index, m.start),
            style: baseStyle,
          ));
        }
        out.add(TextSpan(
          text: line.substring(m.start, m.end),
          style: baseStyle.copyWith(decoration: TextDecoration.underline),
        ));
        index = m.end;
      }
      if (index < line.length) {
        out.add(TextSpan(
          text: line.substring(index),
          style: baseStyle,
        ));
      }
    }

}

class _InlineImage extends StatelessWidget {
  final String path;
  const _InlineImage({Key? key, required this.path}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final file = File(path);
    if (!file.existsSync()) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: LayoutBuilder(
        builder: (ctx, cons) {
          final Size screenSize = MediaQuery.of(ctx).size;
          final double maxWidth = math.min(screenSize.width - 32, 560).toDouble();
          final double maxHeight = math.min(screenSize.height * 0.35, 320).toDouble();

          return SizedBox(
            width: maxWidth,
            height: maxHeight,
            child: InteractiveViewer(
              minScale: 0.5,
              maxScale: 4,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  file,
                  width: maxWidth,
                  height: maxHeight,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}