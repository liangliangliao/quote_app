import 'dart:io';
import 'package:flutter/services.dart';

/// Android-only native foreground tracking for Sport.
/// 
/// Purpose:
/// - Keep distance/steps/time/speeds computing even if user leaves SportRunningPage
///   or removes the app from the recent tasks list.
/// 
/// Notes:
/// - On iOS, force-quit from app switcher stops all background execution; this
///   helper is Android-only.
class NativeSportFg {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');

  static Future<void> ensureStarted({
    required int recordId,
    String title = '运动进行中',
  }) async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('startSportForeground', <String, dynamic>{
        'recordId': recordId,
        'title': title,
      });
    } catch (_) {
      // ignore: best-effort
    }
  }

  static Future<void> stop() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('stopSportForeground');
    } catch (_) {
      // ignore
    }
  }

  static Future<bool> isRunning() async {
    if (!Platform.isAndroid) return false;
    try {
      final v = await _ch.invokeMethod('isSportForegroundRunning');
      return v == true;
    } catch (_) {
      return false;
    }
  }
}
