
package com.example.quote_app.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.util.*;

/**
 * Contract discovery for alarm data sources.
 * - Scans both /databases and /files/../app_flutter directories for sqlite dbs
 * - Picks best source for tasks and quotes based on column heuristics or views v_alarm_*
 * - Caches the result in SharedPreferences for fast access from receivers.
 */
public final class DbInspector {
    private static final String TAG = "DbInspector";
    private static final String PREF_KEY = "alarm_contract_v2";

    public static final class Contract {
        public String dbPath;       // absolute path to selected DB
        public String tasksSource;  // table/view name
        public String quotesSource; // table/view name
        public Map<String,String> taskColMap = new HashMap<>();
        public Map<String,String> quoteColMap = new HashMap<>();
        public int version = 1;

        public JSONObject toJson() {
            try {
                JSONObject j = new JSONObject();
                j.put("db_path", dbPath);
                j.put("tasks_source", tasksSource);
                j.put("quotes_source", quotesSource);
                j.put("version", version);
                JSONObject tc = new JSONObject();
                for (Map.Entry<String,String> e: taskColMap.entrySet()) tc.put(e.getKey(), e.getValue());
                j.put("task_cols", tc);
                JSONObject qc = new JSONObject();
                for (Map.Entry<String,String> e: quoteColMap.entrySet()) qc.put(e.getKey(), e.getValue());
                j.put("quote_cols", qc);
                return j;
            } catch (Exception e) { return null; }
        }

        public static Contract fromJson(String s) {
            if (s == null) return null;
            try {
                JSONObject j = new JSONObject(s);
                Contract c = new Contract();
                c.dbPath = j.optString("db_path", null);
                c.tasksSource = j.optString("tasks_source", null);
                c.quotesSource = j.optString("quotes_source", null);
                c.version = j.optInt("version", 1);
                JSONObject tc = j.optJSONObject("task_cols");
                if (tc != null) {
                    Iterator<String> it = tc.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.taskColMap.put(k, tc.optString(k, null));
                    }
                }
                JSONObject qc = j.optJSONObject("quote_cols");
                if (qc != null) {
                    Iterator<String> it = qc.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.quoteColMap.put(k, qc.optString(k, null));
                    }
                }
                return c;
            } catch (Exception e) { return null; }
        }
    }

    private DbInspector() {}

    public static Contract discoverAndCache(Context ctx) {
        Contract cached = loadCached(ctx);
        if (isUsable(cached)) return cached;
        Contract c = scanAllAndGuess(ctx);
        if (c != null) saveCached(ctx, c);
        return c;
    }

    public static Contract loadOrLightScan(Context ctx) {
        Contract c = loadCached(ctx);
        if (isUsable(c)) return c;
        return scanAllAndGuess(ctx);
    }

    private static boolean isUsable(Contract c) {
        if (c == null || TextUtils.isEmpty(c.dbPath)) return false;
        File f = new File(c.dbPath);
        return f.exists() && !TextUtils.isEmpty(c.tasksSource);
    }

    private static Contract loadCached(Context ctx) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
        return Contract.fromJson(sp.getString(PREF_KEY, null));
    }

    private static void saveCached(Context ctx, Contract c) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
        JSONObject j = c.toJson();
        if (j != null) sp.edit().putString(PREF_KEY, j.toString()).apply();
    }

    private static Contract scanAllAndGuess(Context ctx) {
        List<File> candidates = new ArrayList<>();

        // 1) /databases
        File dbDir = ctx.getDatabasePath("x").getParentFile();
        if (dbDir != null && dbDir.exists()) {
            File[] arr = dbDir.listFiles();
            if (arr != null) {
                for (File f: arr) {
                    String n = f.getName();
                    if (n.endsWith("-wal") || n.endsWith("-shm") || n.endsWith("-journal")) continue;
                    if (f.isFile()) candidates.add(f);
                }
            }
        }
        // 2) app_flutter (path_provider documents)
        File files = ctx.getFilesDir();
        if (files != null) {
            File appFlutter = new File(files.getParent(), "app_flutter");
            if (appFlutter.exists()) {
                File[] arr = appFlutter.listFiles();
                if (arr != null) {
                    for (File f: arr) {
                        String n = f.getName().toLowerCase(Locale.US);
                        if (n.endsWith(".db") || n.contains("sqlite")) candidates.add(f);
                    }
                }
            }
        }

        for (File f: candidates) {
            Contract c = tryOneDb(f);
            if (c != null) return c;
        }
        return null;
    }

    private static Contract tryOneDb(File dbFile) {
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Map<String, List<String>> schema = new HashMap<>();
            Map<String, String> types = new HashMap<>();
            Cursor c = db.rawQuery("SELECT name, type FROM sqlite_master WHERE type IN ('table','view')", null);
            while (c.moveToNext()) {
                String name = c.getString(0);
                String type = c.getString(1);
                types.put(name, type);
                List<String> cols = new ArrayList<>();
                Cursor tc = null;
                try {
                    tc = db.rawQuery("PRAGMA table_info(" + name + ")", null);
                    while (tc.moveToNext()) {
                        cols.add(tc.getString(tc.getColumnIndexOrThrow("name")));
                    }
                } finally {
                    if (tc != null) tc.close();
                }
                schema.put(name, cols);
            }
            c.close();

            String tasksSource = pickBestTasksSource(schema, types);
            String quotesSource = pickBestQuotesSource(schema, types);

            if (tasksSource == null && quotesSource == null) return null;

            Contract out = new Contract();
            out.dbPath = dbFile.getAbsolutePath();
            out.tasksSource = tasksSource;
            out.quotesSource = quotesSource;
            if (tasksSource != null) out.taskColMap = mapTaskColumns(schema.get(tasksSource));
            if (quotesSource != null) out.quoteColMap = mapQuoteColumns(schema.get(quotesSource));
            return out;
        } catch (Throwable e) {
            Log.w(TAG, "open db fail: " + dbFile + ", " + e.getMessage());
            return null;
        } finally {
            if (db != null) db.close();
        }
    }

    private static String pickBestTasksSource(Map<String, List<String>> schema, Map<String, String> types) {
        if (schema.containsKey("v_alarm_tasks")) return "v_alarm_tasks";
        for (Map.Entry<String,List<String>> e: schema.entrySet()) {
            String name = e.getKey();
            if (!"view".equals(types.get(name))) continue;
            if (looksLikeTasks(e.getValue())) return name;
        }
        for (Map.Entry<String,List<String>> e: schema.entrySet()) {
            String name = e.getKey();
            if (!"table".equals(types.get(name))) continue;
            if (looksLikeTasks(e.getValue())) return name;
        }
        return null;
    }

    private static String pickBestQuotesSource(Map<String, List<String>> schema, Map<String, String> types) {
        if (schema.containsKey("v_alarm_quotes")) return "v_alarm_quotes";
        for (Map.Entry<String,List<String>> e: schema.entrySet()) {
            String name = e.getKey();
            if (!"view".equals(types.get(name))) continue;
            if (looksLikeQuotes(e.getValue())) return name;
        }
        for (Map.Entry<String,List<String>> e: schema.entrySet()) {
            String name = e.getKey();
            if (!"table".equals(types.get(name))) continue;
            if (looksLikeQuotes(e.getValue())) return name;
        }
        return null;
    }

    private static boolean looksLikeTasks(List<String> cols) {
        if (cols == null) return false;
        String s = joinLower(cols);
        return containsAny(s, "uid") &&
               containsAny(s, "title") &&
               containsAny(s, "content","body","desc","message","text") &&
               containsAny(s, "trigger_at","fire_at","scheduled_at","when","time","ts");
    }

    private static boolean looksLikeQuotes(List<String> cols) {
        if (cols == null) return false;
        String s = joinLower(cols);
        return containsAny(s, "text","quote","content") && containsAny(s, "author","by");
    }

    private static Map<String,String> mapTaskColumns(List<String> cols) {
        Map<String,String> m = new HashMap<>();
        m.put("uid", pick(cols, "uid","task_uid","id"));
        m.put("title", pick(cols, "title","name"));
        m.put("content", pick(cols, "content","body","desc","message","text"));
        m.put("trigger_at", pick(cols, "trigger_at","fire_at","scheduled_at","when","time","ts"));
        String enabled = pick(cols, "enabled","active","on");
        if (enabled != null) m.put("enabled", enabled);
        return m;
    }

    private static Map<String,String> mapQuoteColumns(List<String> cols) {
        Map<String,String> m = new HashMap<>();
        m.put("text", pick(cols, "text","quote","content"));
        String auth = pick(cols, "author","by");
        if (auth != null) m.put("author", auth);
        return m;
    }

    private static String pick(List<String> cols, String... candidates) {
        Set<String> low = new HashSet<>();
        for (String c : cols) low.add(c.toLowerCase(Locale.US));
        Map<String,String> idx = new HashMap<>();
        for (String c: cols) idx.put(c.toLowerCase(Locale.US), c);
        for (String k : candidates) {
            if (low.contains(k)) return idx.get(k);
        }
        return null;
    }

    private static boolean containsAny(String s, String... keys) {
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }

    private static String joinLower(List<String> cols) {
        StringBuilder sb = new StringBuilder();
        for (String c : cols) sb.append(',').append(c.toLowerCase(Locale.US));
        return sb.toString();
    }
}
