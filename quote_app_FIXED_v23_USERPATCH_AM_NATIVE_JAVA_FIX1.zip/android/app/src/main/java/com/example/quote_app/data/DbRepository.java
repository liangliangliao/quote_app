
package com.example.quote_app.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class DbRepository {

    public static final class Task {
        public String uid;
        public String title;
        public String content;
        public long triggerAtMillis;
        public int enabled = 1;
    }

    private DbRepository() {}

    private static SQLiteDatabase openByPath(String path) {
        if (TextUtils.isEmpty(path)) return null;
        File f = new File(path);
        if (!f.exists()) return null;
        return SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
    }

    public static Task findTaskByUid(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.tasksSource)) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        try {
            String uidCol = or(cc.taskColMap.get("uid"), "uid");
            String titleCol = or(cc.taskColMap.get("title"), "title");
            String contentCol = or(cc.taskColMap.get("content"), "content");
            String whenCol = or(cc.taskColMap.get("trigger_at"), "trigger_at");
            String sql = "SELECT " + uidCol + "," + titleCol + "," + contentCol + "," + whenCol +
                         " FROM " + cc.tasksSource + " WHERE " + uidCol + "=? LIMIT 1";
            Cursor c = db.rawQuery(sql, new String[]{ uid });
            try {
                if (c.moveToFirst()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    return t;
                }
            } finally {
                c.close();
            }
        } catch (Throwable ignore) {
        } finally {
            db.close();
        }
        return null;
    }

    public static List<Task> listFutureTasks(Context ctx) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        List<Task> out = new ArrayList<>();
        if (cc == null || TextUtils.isEmpty(cc.tasksSource)) return out;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return out;
        try {
            long now = System.currentTimeMillis();
            String uidCol = or(cc.taskColMap.get("uid"), "uid");
            String titleCol = or(cc.taskColMap.get("title"), "title");
            String contentCol = or(cc.taskColMap.get("content"), "content");
            String whenCol = or(cc.taskColMap.get("trigger_at"), "trigger_at");
            String enabledCol = or(cc.taskColMap.get("enabled"), "enabled");
            // enabled 可能缺失，使用 1=1 兜底
            String where = (enabledCol != null ? (enabledCol + "=1 AND ") : "") + whenCol + ">?";
            String sql = "SELECT " + uidCol + "," + titleCol + "," + contentCol + "," + whenCol +
                         " FROM " + cc.tasksSource + " WHERE " + where;
            Cursor c = db.rawQuery(sql, new String[]{ String.valueOf(now) });
            try {
                while (c.moveToNext()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    out.add(t);
                }
            } finally {
                c.close();
            }
        } catch (Throwable ignore) {
        } finally {
            db.close();
        }
        return out;
    }

    public static String pickRandomQuote(Context ctx) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.quotesSource)) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        try {
            String textCol = or(cc.quoteColMap.get("text"), "text");
            String authorCol = cc.quoteColMap.get("author");
            String select = "SELECT " + textCol + (authorCol != null ? ("," + authorCol) : "") +
                            " FROM " + cc.quotesSource + " ORDER BY RANDOM() LIMIT 1";
            Cursor c = db.rawQuery(select, null);
            try {
                if (c.moveToFirst()) {
                    String text = c.getString(0);
                    String author = authorCol != null ? c.getString(1) : null;
                    return (author == null || author.isEmpty()) ? text : (text + " — " + author);
                }
            } finally {
                c.close();
            }
        } catch (Throwable ignore) {
        } finally {
            db.close();
        }
        return null;
    }

    private static String or(String a, String b) {
        return a != null ? a : b;
    }
}
