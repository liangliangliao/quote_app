import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../data/db.dart';
import '../platform/native_scheduler.dart';
import '../platform/perm_helper.dart';
import 'task_runner.dart';

class SchedulerService {
  static Future<void> init() async { /* 初始化已在 main.dart 完成 */ }

  /// 计算下一次运行时间：优先 next_time；否则使用 start_time(HH:mm) 今日/明日
  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final now = DateTime.now();
    const grace = Duration(seconds: 10);
    try {
      final raw = (t['next_time'] ?? '').toString();
      if (raw.isNotEmpty) {
        final dt = DateTime.tryParse(raw);
        if (dt != null && dt.isAfter(now.subtract(grace))) return dt;
      }
    } catch (_) {}
    final start = (t['start_time'] ?? '09:00').toString();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (next.isBefore(now.subtract(grace))) next = next.add(const Duration(days: 1));
    return next;
  }

  /// 计算下一次运行时间（新实现）：根据任务配置计算下一次运行时间。
  /// 如果 start_time 为绝对时间且在未来，则直接使用之；否则按 freq_type 计算每日/每周/每月下一次。
  static DateTime _computeNextRun(Map<String, dynamic> t) {
    final now = DateTime.now();
    String start = (t['start_time'] ?? '09:00').toString().trim();
    if (start.isEmpty) start = '09:00';
    // 解析 HH:mm 或 YYYY-MM-DD HH:mm[:ss]
    DateTime? absDt;
    int hh = 9, mm = 0;
    // 如果包含日期
    final reAbs = RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?\$');
    if (reAbs.hasMatch(start)) {
      try {
        // 标准化为 T 分隔
        final s = start.replaceFirst(' ', 'T');
        absDt = DateTime.parse(s);
      } catch (_) {
        absDt = null;
      }
      if (absDt != null) {
        hh = absDt.hour;
        mm = absDt.minute;
      }
    } else {
      // 尝试从任意字符串中提取 HH:mm 或 H:mm
      final m = RegExp(r'\b(\d{1,2}):(\d{2})\b').firstMatch(start);
      if (m != null) {
        hh = int.tryParse(m.group(1) ?? '9') ?? 9;
        mm = int.tryParse(m.group(2) ?? '0') ?? 0;
      }
    }
    // 读取频率。对于手动任务或未设置的情况，默认 daily
    String freqType = (t['freq_type'] ?? 'daily').toString();
    if (freqType.isEmpty || freqType == 'null' || freqType == 'manual') {
      freqType = 'daily';
    }
    final int? weekDay = t['freq_weekday'] is int ? t['freq_weekday'] as int? : null;
    final int? dayOfMonth = t['freq_day_of_month'] is int ? t['freq_day_of_month'] as int? : null;
    // 如果 start_time 为未来的绝对时间，直接使用
    if (absDt != null && absDt.isAfter(now)) {
      return absDt;
    }
    // 周期计算
    if (freqType == 'weekly' && weekDay != null) {
      final wd = weekDay;
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      // 如果候选时间尚未过去（含相等），则本周即将触发，否则推迟到下周
      if (!cand.isBefore(now)) return cand;
      return cand.add(const Duration(days: 7));
    }
    if (freqType == 'monthly' && dayOfMonth != null) {
      final d = dayOfMonth.clamp(1,31);
      int y = now.year;
      int mth = now.month;
      int end = DateTime(y, mth + 1, 0).day;
      var cand = DateTime(y, mth, d.clamp(1, end), hh, mm);
      // 若未来仍有本月候选(含同一时刻)，使用之；否则顺延至下月对应日
      if (!cand.isBefore(now)) return cand;
      mth += 1;
      end = DateTime(y, mth + 1, 0).day;
      cand = DateTime(y, mth, d.clamp(1, end), hh, mm);
      return cand;
    }
    // 默认：每日
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    if (!today.isBefore(now)) return today;
    return today.add(const Duration(days: 1));
  }

  static String _runKeyFromTime(DateTime dt) => DateFormat('yyyyMMdd_HHmmss_SSS').format(dt);

  static int _alarmId(String uid, String runKey) {
    // 稳定哈希，转正数
    final v = uid.hashCode ^ runKey.hashCode;
    return (v & 0x7fffffff);
  }

  static String _wmUniqueNormal(String uid, String runKey) => 'wm_run_${uid}_${runKey}_N';
  static String _wmUniqueFallback(String uid, String runKey, int attempt) => 'wm_run_${uid}_${runKey}_FB_${attempt}';

  /// 取消 WM 正常/兜底（按唯一名）
  static Future<void> _cancelWmNormal(String uid, String runKey) async {
    try { await Workmanager().cancelByUniqueName(_wmUniqueNormal(uid, runKey)); } catch (_) {}
  }
  static Future<void> _cancelWmFallback(String uid, String runKey, int attempt) async {
    try { await Workmanager().cancelByUniqueName(_wmUniqueFallback(uid, runKey, attempt)); } catch (_) {}
  }

  /// 注册下一次（按权限分支：有精准=仅AM+兜底WM；无精准=仅WM正常+兜底WM）
  static Future<void> scheduleNextForTask(String uid) async {
    // Ensure DB columns exist before using them
    try { await ensureExtraTaskColumns(); } catch (_) {}
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    // 计算下一次运行时间
    final nextTime = _computeNextRun(t);
    final runKey = _runKeyFromTime(nextTime);
    final now = DateTime.now();
    final diff = nextTime.difference(now);
    final normalDelay = diff.isNegative ? Duration.zero : diff;

    // 更新 DB：保存 next_time 与 scheduled_run_key。如果缺少列则补充后重试。
    try {
      final db = await AppDatabase.instance();
      await db.update('tasks', {'next_time': nextTime.toIso8601String()}, where: 'task_uid=?', whereArgs: [uid]);
      await DLog.i('SCH','更新下一次时间 uid='+uid+' next='+_runKeyFromTime(nextTime));
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('no such column') && msg.contains('next_time')) {
        try {
          await ensureExtraTaskColumns();
          final db = await AppDatabase.instance();
          await db.update('tasks', {'next_time': nextTime.toIso8601String()}, where: 'task_uid=?', whereArgs: [uid]);
          await DLog.i('SCH','更新下一次时间(重试) uid='+uid+' next='+_runKeyFromTime(nextTime));
        } catch (e2) {
          await DLog.e('SCH','更新下一次时间失败(重试) uid='+uid+' err='+e2.toString());
        }
      } else {
        await DLog.e('SCH','更新下一次时间失败 uid='+uid+' err='+e.toString());
      }
    }
    try {
      await TaskDao().setScheduledRunKey(uid, runKey);
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('no such column') && msg.contains('scheduled_run_key')) {
        try {
          await ensureExtraTaskColumns();
          await TaskDao().setScheduledRunKey(uid, runKey);
        } catch (_) {}
      }
    }

    bool hasExact = false;
    try { hasExact = await PermHelper.hasExactAlarmPermission(); } catch (_) {}

    if (hasExact) {
      // ✅ 仅 AM + WM 兜底(+2 分钟)。兜底通道标识为 am_fallback
      try {
        await NativeScheduler.scheduleExactAt(
          id: _alarmId(uid, runKey),
          epochMs: nextTime.millisecondsSinceEpoch,
          payload: {'uid': uid, 'runKey': runKey, 'chan': 'am', 'attempt': 1},
        );
        await DLog.i('SCH', 'AM 注册完成 uid='+uid+' am_id='+_alarmId(uid, runKey).toString()+' run='+runKey);
      } catch (e) {
        await DLog.w('SCH', 'AM 注册失败，忽略: '+e.toString());
      }
      try {
        final u = _wmUniqueFallback(uid, runKey, 1);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay + const Duration(minutes: 2),
          inputData: {'job':'wm_run', 'task_uid': uid, 'run_key': runKey, 'chan': 'am_fallback', 'attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+u+' run='+runKey);
      } catch (e) {
        await DLog.e('SCH', 'WM 兜底注册失败: '+e.toString());
      }
    } else {
      // ❌ 无精准：WM 正常 + 兜底（wm_fallback）
      try {
        final u = _wmUniqueNormal(uid, runKey);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay,
          inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'normal','attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH','WM 正常注册完成 uid='+uid+' wm_unique='+u+' run='+runKey+' delay='+normalDelay.inSeconds.toString()+'s');
      } catch (e) {
        await DLog.e('SCH','WM 正常注册失败: '+e.toString());
      }
      try {
        final u = _wmUniqueFallback(uid, runKey, 1);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay + const Duration(minutes: 2),
          inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'wm_fallback','attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH','WM 兜底注册完成 uid='+uid+' wm_unique='+u+' run='+runKey);
      } catch (e) {
        await DLog.e('SCH','WM 兜底注册失败: '+e.toString());
      }
    }
  }

  /// 精准取消（根据保存的 scheduled_run_key）
  static Future<void> cancelNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    final runKey = (t['scheduled_run_key'] ?? '').toString();
    if (runKey.isEmpty) {
      await DLog.w('SCH','取消下一次：没有保存的 runKey，uid='+uid);
      return;
    }
    try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
    await _cancelWmNormal(uid, runKey);
    await _cancelWmFallback(uid, runKey, 1);
    await _cancelWmFallback(uid, runKey, 2);
    await DLog.i('SCH','已取消下一次计划 uid='+uid+' run='+runKey);
  }

  /// 为全部任务安排下一次
  static Future<void> scheduleNextForAll() async {
    // Ensure DB contains required auxiliary columns before scheduling
    try { await ensureExtraTaskColumns(); } catch (_) {}
    final list = await TaskDao().all();
    for (final t in list) {
      final uid = (t['task_uid'] ?? '').toString();
      if (uid.isEmpty) continue;
      await scheduleNextForTask(uid);
    }
  }

  /// 保存 next_time 并重新安排
  static Future<void> _updateNextAndReschedule(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    // 计算并保存下一次运行时间
    final next = _computeNextRun(t);
    // Ensure auxiliary columns exist before writing
    try { await ensureExtraTaskColumns(); } catch (_) {}
    final db = await AppDatabase.instance();
    try {
      await db.update('tasks', {'next_time': next.toIso8601String()}, where: 'task_uid=?', whereArgs: [uid]);
      await DLog.i('SCH','更新下一次时间 uid='+uid+' next='+_runKeyFromTime(next));
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('no such column') && msg.contains('next_time')) {
        // As a last resort, ensure columns again then retry once
        try {
          await ensureExtraTaskColumns();
          await db.update('tasks', {'next_time': next.toIso8601String()}, where: 'task_uid=?', whereArgs: [uid]);
          await DLog.i('SCH','更新下一次时间(重试) uid='+uid+' next='+_runKeyFromTime(next));
        } catch (e2) {
          await DLog.e('SCH','更新下一次时间失败(重试) uid='+uid+' err='+e2.toString());
        }
      } else {
        await DLog.e('SCH','更新下一次时间失败 uid='+uid+' err='+e.toString());
      }
    }
    // 安排下一次
    await scheduleNextForTask(uid);
  }

  /// 后台 WM 回调执行：统一走 TaskRunner
  
static Future<void> wmRunTask(String uid, String? runKey, {String? chan, int attempt = 1}) async {
    // 记录即将发送的来源、尝试次数与关键信息
    final String source = (chan ?? 'normal');
    try {
      await DLog.i('SCH', '开始发送通知 chan='+source+' attempt='+attempt.toString()+' uid='+uid+' run='+(runKey ?? ''));
    } catch (_) {}

    // 幂等：同一任务同一 runKey 只能发送一次
    if (runKey != null && runKey.isNotEmpty) {
      try {
        final sent = await NotifyGuardDao().alreadySent(uid, runKey, chan: source, attempt: attempt);
        if (sent) {
          await DLog.w('SCH','幂等拦截：uid='+uid+' run='+runKey+' 已发送过，忽略');
          return;
        } else {
          await NotifyGuardDao().markSent(uid, runKey, chan: source, attempt: attempt);
        }
      } catch (_) {}
    }

    // ★ 先精准取消“自己当前这一次任务”
    try {
      if (runKey != null && runKey.isNotEmpty) {
        final ch = source.toLowerCase();
        if (ch == 'normal') {
          await _cancelWmNormal(uid, runKey);
          try { await LogDao().add(taskUid: uid, detail: '精准取消当前任务(主WM)：uid='+uid+' run='+runKey); } catch (_) {}
        } else if (ch == 'am' || ch == 'am_fallback') {
          try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
          try { await LogDao().add(taskUid: uid, detail: '精准取消当前任务(主AM/AM_FALLBACK入口)：uid='+uid+' run='+runKey); } catch (_) {}
        } else if (ch.endsWith('_fallback') || ch == 'fallback' || ch == 'wm_fallback') {
          await _cancelWmFallback(uid, runKey, attempt);
          try { await LogDao().add(taskUid: uid, detail: '精准取消当前任务(兜底 attempt='+attempt.toString()+')：uid='+uid+' run='+runKey); } catch (_) {}
        }
      }
    } catch (_) {}

    try {
      await TaskRunner.run(uid);
      // 成功：标记失败记录成功并取消兜底任务
      try {
        await DLog.i('SCH', '发送成功 chan='+source+' attempt='+attempt.toString()+' uid='+uid+' run='+(runKey ?? ''));
      } catch (_) {}
      try { await FailureStatDao().markLatestSuccess(uid); } catch (_) {}

      // 主通道成功后：取消兜底和AM；兜底成功不负责续排
      if (runKey != null && runKey.isNotEmpty) {
        await _cancelWmFallback(uid, runKey, 1);
        await _cancelWmFallback(uid, runKey, 2);
        try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
      }
      final bool isFallback = source.toLowerCase() == 'fallback' || source.toLowerCase().endsWith('_fallback') || source.toLowerCase() == 'wm_fallback';
      if (!isFallback) {
        await _updateNextAndReschedule(uid);
      }
    } catch (e) {
      // 捕获失败：记录来源与尝试次数
      try {
        await DLog.e('SCH','发送失败 chan='+source+' attempt='+attempt.toString()+' uid='+uid+' run='+(runKey ?? '')+' err='+e.toString());
      } catch (_) {}
      final dateStr = DateTime.now().toIso8601String().substring(0,10);
      try {
        await FailureStatDao().insertFail(taskUid: uid, channel: source, uniqueId: (runKey ?? ''), dateStr: dateStr);
      } catch (_) {}

      final bool isFallback = source.toLowerCase() == 'fallback' || source.toLowerCase().endsWith('_fallback') || source.toLowerCase() == 'wm_fallback';
      if (!isFallback && (source.toLowerCase() == 'normal' || source.toLowerCase() == 'am')) {
        // 主 AM/WM 失败：已取消自己但不要取消兜底；安排下一次
        await _updateNextAndReschedule(uid);
        return;
      } else if (isFallback) {
        // 兜底失败：做最多两次重试（每次先取消自己）
        if (attempt <= 1) {
          if (runKey != null && runKey.isNotEmpty) {
            await _cancelWmFallback(uid, runKey, attempt);
          }
          try {
            final u = _wmUniqueFallback(uid, runKey ?? _runKeyFromTime(DateTime.now()), attempt + 1);
            await Workmanager().registerOneOffTask(
              u, 'wm_task',
              initialDelay: Duration.zero,
              inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan': source, 'attempt': attempt + 1},
              existingWorkPolicy: ExistingWorkPolicy.replace,
              tag: uid,
            );
            await DLog.w('SCH','兜底失败，已注册第'+(attempt+1).toString()+'次兜底 uid='+uid+' run='+(runKey ?? ''));
          } catch (e2) {
            await DLog.e('SCH','兜底再次注册失败 uid='+uid+' err='+e2.toString());
          }
          return;
        } else {
          if (runKey != null && runKey.isNotEmpty) {
            await _cancelWmFallback(uid, runKey, attempt);
          }
          await _updateNextAndReschedule(uid);
          return;
        }
      } else {
        await _updateNextAndReschedule(uid);
        return;
      }
    }
  }
/// 兼容旧入口
  static Future<void> callback() async {}

  /// 注册/刷新自检周期任务（最小 15 分钟）
  static Future<void> scheduleSelfCheck() async {
    final minutes = await NotifyConfigDao().getSelfCheckMinutes();
    final freq = Duration(minutes: minutes < 15 ? 15 : minutes);
    try {
      await Workmanager().registerPeriodicTask(
        'wm_selfcheck_unique',
        'wm_task',
        frequency: freq,
        initialDelay: const Duration(minutes: 1),
        inputData: {'job':'wm_selfcheck'},
        existingWorkPolicy: ExistingPeriodicWorkPolicy.update,
        constraints: Constraints(networkType: NetworkType.notRequired),
      );
      await DLog.i('SCH','自检任务已注册，频率='+minutes.toString()+'分钟');
    } catch (e) {
      await DLog.e('SCH','自检任务注册失败: '+e.toString());
    }
  }

  /// 每日自检：扫描当天失败记录并立刻补发
  static Future<void> selfCheckTodayFailures() async {
    try {
      final fails = await FailureStatDao().failsOfToday();
      if (fails.isEmpty) {
        await DLog.i('SCH','自检：今日无失败记录');
        return;
      }
      for (final row in fails) {
        final uid = (row['task_uid'] ?? '').toString();
        if (uid.isEmpty) continue;
        final runKey = _runKeyFromTime(DateTime.now());
        try {
          final u = _wmUniqueNormal(uid, runKey);
          await Workmanager().registerOneOffTask(
            u, 'wm_task',
            initialDelay: Duration.zero,
            inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'normal','attempt': 1},
            existingWorkPolicy: ExistingWorkPolicy.replace,
            tag: uid,
          );
          await DLog.i('SCH','自检补发：已注册 WM 正常 uid='+uid+' run='+runKey);
        } catch (e) {
          await DLog.e('SCH','自检补发注册失败 uid='+uid+' err='+e.toString());
        }
      }
    } catch (e) {
      await DLog.e('SCH','自检执行失败: '+e.toString());
    }
  }
}