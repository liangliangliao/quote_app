import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import '../platform/perm_helper.dart';

class PermissionGate extends StatefulWidget {
  final Widget child;
  const PermissionGate({super.key, required this.child});

  @override
  State<PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<PermissionGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    // 1) Notifications
    final notifStatus = await Permission.notification.status;
    if (!notifStatus.isGranted) {
      final ok = await _showNotifDialog();
      if (!ok) { SystemNavigator.pop(); return; }
      final req = await Permission.notification.request();
      if (!req.isGranted) { SystemNavigator.pop(); return; }
    }

    // 2) Exact alarm
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact) {
      final allow = await _showExactDialog();
      if (allow) {
        await PermHelper.requestExactAlarmPermission();
        // user returns from system page -> proceed
      } else {
        final exit = await _confirmExit();
        if (exit) { setState(() => _ready = true); return; }
        // stay on dialog layer
        await _check();
        return;
      }
    }

    setState(() => _ready = true);
  }

  Future<bool> _showNotifDialog() async {
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('通知权限授权'),
        content: const Text('需要通知权限以确保消息提醒'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('不允许')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('允许')),
        ],
      ),
    ) ?? false;
  }

  Future<bool> _showExactDialog() async {
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('闹钟提醒权限授权'),
        content: const Text('需要精准闹钟权限以保证准时提醒'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('不允许')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('允许')),
        ],
      ),
    ) ?? false;
  }

  Future<bool> _confirmExit() async {
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('提示'),
        content: const Text('你将不启用精准闹钟提醒功能！'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('否')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('是')),
        ],
      ),
    ) ?? true;
  }

  @override
  Widget build(BuildContext context) {
    return _ready ? widget.child : const Scaffold(body: SizedBox());
  }
}
