
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:isolate';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:workmanager/workmanager.dart';
import 'package:path_provider/path_provider.dart';

import 'data/db.dart';
import 'data/dao.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'services/wm_dispatcher.dart';
import 'background_tasks.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';

import 'utils/debug_logger.dart';
import 'platform/perm_helper.dart';
// Global tab index notifier for Home refresh on tab switch
final ValueNotifier<int> tabIndexNotifier = ValueNotifier<int>(0);


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
  ));
  ui.DartPluginRegistrant.ensureInitialized();
  await AppDatabase.instance();
  // Ensure auxiliary columns exist (scheduled_run_key, next_time).  This should
  // be called once after opening the database to migrate older installations.
  try {
    await ensureExtraTaskColumns();
  } catch (_) {}
  await NotificationService.init();
  await SchedulerService.init();
  Workmanager().initialize(workmanagerCallbackDispatcher, isInDebugMode: false);
  // Foreground refresh bus: receive 'refresh_home' from background isolate
  final rp = ReceivePort();
  IsolateNameServer.removePortNameMapping('fg_bus');
  IsolateNameServer.registerPortWithName(rp.sendPort, 'fg_bus');
  rp.listen((msg){
    try {
      if (msg == 'refresh_home') {
        // noop here; HomePage will listen via tabIndexNotifier or a static hook if needed
        tabIndexNotifier.notifyListeners();
      }
    } catch(_){ }
  });
  runApp(const MyApp());
}


class NoOverscrollBehavior extends MaterialScrollBehavior {
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) {
    return child; // 禁用全局overscroll指示
  }
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      scrollBehavior: NoOverscrollBehavior(),
      title: '',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const GateKeeper(),
    );
  }
}

class GateKeeper extends StatefulWidget {
  const GateKeeper({super.key});
  @override
  State<GateKeeper> createState() => _GateKeeperState();
}

class _GateKeeperState extends State<GateKeeper> {
  Future<bool> _isFirstOpen() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final f = File('${dir.path}/.first_open_done');
      final exists = await f.exists();
      return !exists;
    } catch (_) { return false; }
  }
  Future<void> _markFirstHandled() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final f = File('${dir.path}/.first_open_done');
      if (!await f.exists()) { await f.writeAsString('ok'); }
    } catch (_){}
  }

  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _checkPerms();
  }

  Future<void> _checkPerms() async {
    // 第一道门卡：系统通知权限
    final hasNoti = await _areNotificationsEnabled();
    if (!hasNoti) {
      // 直接触发系统通知授权弹框，无自定义弹框
      try {
        await NotificationService.request();
      } catch (_) {}
      // 再次检查，如果仍未授权，则尝试打开系统设置界面
      final stillNo = !(await _areNotificationsEnabled());
      if (stillNo) {
        try { await _openNotificationSettings(); } catch (_) {}
      }
    }

    // 第二道门卡：精确闹钟权限（仅 Android）—— 仅首次打开App时弹框
        // 第二道门卡：精确闹钟权限（仅 Android）—— 仅首次打开App时弹框
    final firstOpen = await _isFirstOpen();
    if (firstOpen) {
final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact && mounted) {
      final allow = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx)=> AlertDialog(
          title: const Text('闹钟提醒权限授权'),
          content: const Text('为确保定点提醒，请授予“闹钟与提醒(精确闹钟)”权限。'),
          actions: [
            TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('不允许')),
            FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('允许')),
          ],
        ),
      );
      if (allow == true) {
        await PermHelper.requestExactAlarmPermission();
        // 返回键回到此处后直接进入首页
      } else {
        // 小确认框：是 / 否
        final go = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx)=> AlertDialog(
            content: const Text('你将不启用精准闹钟提醒功能！'),
            actions: [
              TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('否')),
              FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('是')),
            ],
          ),
        );
        if (go != true) {
          // 停留在当前闹钟提醒框层面（重新弹出第二道门卡）
          _checkPerms();
          return;
        }
      }
    }

    }
    // 非首次或首次流程走完
    await _markFirstHandled();
    setState(()=> _ready = true);
  }

  Future<bool> _areNotificationsEnabled() async {
    try {
      const ch = MethodChannel('com.example.quote_app/sys');
      final ok = await ch.invokeMethod<bool>('areNotificationsEnabled');
      return ok ?? true;
    } catch (_) {
      // 如果原生未实现，默认通过（实际发送时也会失败不崩溃）
      return true;
    }
  }

  Future<void> _openNotificationSettings() async {
    try {
      const ch = MethodChannel('com.example.quote_app/sys');
      await ch.invokeMethod('openNotificationSettings');
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return const RootShell();
  }
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});
  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _idx = 0;

  @override
  void initState() {
    super.initState();
    SchedulerService.scheduleNextForAll();
  }

  @override
  Widget build(BuildContext context) {
    final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];
    return Scaffold(
      body: IndexedStack(index: _idx, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) { setState(()=> _idx = i); try { tabIndexNotifier.value = i; } catch(_){ } },
      ),
    );
  }
}
