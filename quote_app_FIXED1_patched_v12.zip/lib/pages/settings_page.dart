import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _notifyDao = NotifyConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _endpointCtrl = TextEditingController();
  final _selfCheckCtrl = TextEditingController();

  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1') as String;
    final m = await _notifyDao.getSelfCheckMinutes();
    _selfCheckCtrl.text = '$m';

    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _saveConfig() async {
    await _configDao.setAll(
      endpoint: _endpointCtrl.text.trim(),
      apiKey: _apiKeyCtrl.text.trim(),
      model: _modelCtrl.text.trim(),
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('配置已保存')));
  }

  Future<void> _saveSelfCheck() async {
    final m = int.tryParse(_selfCheckCtrl.text.trim()) ?? 30;
    await _notifyDao.setSelfCheckMinutes(m < 15 ? 15 : m);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('自检频率已保存')));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('OpenAI 配置', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(controller: _apiKeyCtrl, decoration: const InputDecoration(labelText: 'API Key')),
        TextField(controller: _modelCtrl, decoration: const InputDecoration(labelText: 'Model')),
        TextField(controller: _endpointCtrl, decoration: const InputDecoration(labelText: 'Endpoint')),
        const SizedBox(height: 8),
        ElevatedButton(onPressed: _saveConfig, child: const Text('保存配置')),
        const Divider(height: 32),
        const Text('自检频率（分钟）', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(controller: _selfCheckCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: '>=15')),
        const SizedBox(height: 8),
        ElevatedButton(onPressed: _saveSelfCheck, child: const Text('保存并生效')),
        const Divider(height: 32),
        const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ..._tasks.map((e)=> ListTile(
          title: Text((e['title'] ?? '') as String),
          subtitle: Text('uid=${e['uid'] ?? ''}  at=${e['trigger_at'] ?? ''}'),
          trailing: IconButton(icon: const Icon(Icons.alarm), onPressed: () async {
            await SchedulerService.registerOne(e);
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已下发精准闹钟')));
          }),
        )),
      ],
    );
  }
}
