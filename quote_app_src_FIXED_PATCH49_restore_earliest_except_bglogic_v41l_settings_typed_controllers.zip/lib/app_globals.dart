import 'dart:ui';

class AppGlobals {
  static RootIsolateToken? rootIsolateToken;
  static String handshakeKey = 'quote_app_handshake_v1';
}
