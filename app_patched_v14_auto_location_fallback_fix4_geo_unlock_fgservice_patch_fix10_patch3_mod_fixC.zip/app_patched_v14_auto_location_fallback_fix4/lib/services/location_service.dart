import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 先尝试百度SDK一次定位；若可用且精度<=30m则直接返回；
    // 否则回退到系统高精度流（<=30m），仍失败则返回 null。
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        try { await DLog.i('LocationService', '【定位】百度SDK坐标 acc=' + bd.accuracy.toString()); } catch (_) {}
        if (bd.accuracy <= 30.0 && bd.accuracy > 0) {
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try { await DLog.w('LocationService', '【定位】百度返回但精度>' + bd.accuracy.toString() + '，进入系统定位回退'); } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_) {}
    }

    try {
      final sys = await _getCurrentPositionHighAccuracyStream30();
      if (sys != null) {
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_) {}
    }
    return null;
  }


  static Future<Position?> _getCurrentPositionHighAccuracy() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      try { await DLog.w('LocationService', '【定位】系统定位服务未开启'); } catch (_) {}
      return null;
    }
    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      try { await DLog.w('LocationService', '【定位】未授予定位权限'); } catch (_) {}
      return null;
    }
    // 使用最高精度
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
  }

  /// 通过原生（Baidu SDK）获取一次坐标，失败返回 null。
  static Future<Position?> _baiduSdkLocationOnce() async {
    try {
      final ret = await _sysCh.invokeMethod('getBaiduLocationOnce');
      if (ret is Map) {
        final lat = (ret['lat'] as num?)?.toDouble();
        final lng = (ret['lng'] as num?)?.toDouble();
        final acc = (ret['acc'] as num?)?.toDouble() ?? 0.0;
        if (lat != null && lng != null) {
          return Position(
            latitude: lat, longitude: lng, timestamp: DateTime.now(),
            accuracy: acc, altitude: 0, heading: 0, speed: 0,
            speedAccuracy: 0, altitudeAccuracy: 0, headingAccuracy: 0,
          );
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 调用失败：$e'); } catch (_) {}
    }
    return null;
  }

  /// 记录附近地标（百度逆地理），仅写日志，失败不抛出。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2';
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?ak=${Uri.encodeComponent(effectiveAk)}&coordtype=wgs84ll&extensions_poi=1&radius=600&location=${pos.latitude},${pos.longitude}'
      );
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && (data['status'] == 0 || data['status'] == '0')) {
          final result = data['result'];
          if (result is Map) {
            final pois = result['pois'];
            if (pois is List && pois.isNotEmpty) {
              final first = pois.first;
              String? name; int? distance;
              if (first is Map) {
                final n = first['name']; final d = first['distance'];
                if (n is String) name = n; if (d is int) distance = d;
              }
              if (name != null) {
                final suffix = distance != null ? '（约' + distance.toString() + '米）' : '';
                try { await DLog.i('LocationService', '附近地标：' + name + suffix); } catch (_) {}
              }
            }
          }
        }
      }
    } catch (_) {}
  }

  /// 页面“新增地点规则”需要的 POI 拉取（默认100米，百度逆地理接口，同步到UI分页）；
  /// 签名保持与页面一致。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    int radiusMeters = 100,
    String keyword = '',
    int page = 1,
    int pageSize = 5,
  }) async {
    try {
      // 读取 AK：空则使用默认值
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2';

      // 优先调用百度逆地理（extensions_poi）
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?'
        'ak=${Uri.encodeComponent(effectiveAk)}&coordtype=wgs84ll&radius=${radiusMeters.toString()}'
        '&extensions_poi=1&page_num=${(page-1).clamp(0, 50)}&location=$latitude,$longitude'
      );
      final res = await http.get(url);
      if (res.statusCode == 200) {
        try {
          final m = jsonDecode(res.body);
          final result = (m is Map) ? m['result'] : null;
          final pois = (result is Map) ? result['pois'] : null;
          if (pois is List) {
            final out = <PoiItem>[];
            for (final e in pois) {
              if (e is! Map) continue;
              final name = (e['name'] ?? '').toString();
              if (name.isEmpty) continue;
              if (keyword.isNotEmpty && !name.contains(keyword)) continue;
              final point = e['point'];
              final x = (point is Map) ? point['x'] : null;
              final y = (point is Map) ? point['y'] : null;
              final lng = (x is num) ? x.toDouble() : null;
              final lat = (y is num) ? y.toDouble() : null;
              if (lat == null || lng == null) continue;
              final dis = (e['distance'] is num) ? (e['distance'] as num).toInt() : null;
              out.add(PoiItem(name: name, address: e['addr']?.toString(), latitude: lat, longitude: lng, distance: dis));
            }
            final startIdx = (page-1) * pageSize;
            final endIdx = (startIdx + pageSize);
            return startIdx >= out.length ? <PoiItem>[] : out.sublist(startIdx, endIdx.clamp(0, out.length));
          }
        } catch (_) {
          // fall through to system reverse geocoding
        }
      }
      // 非 200 / 解析失败：系统逆地理兜底
      return await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】拉取附近POI失败：$e'); } catch (_) {}
      return await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
    }
  }
) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2';
      // 百度逆地理接口支持 extensions_poi，page_num 从 0 开始
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?'
        'ak=${Uri.encodeComponent(effectiveAk)}&coordtype=wgs84ll&radius=${radiusMeters.toString()}'
        '&extensions_poi=1&page_num=${(page-1).clamp(0, 50)}&location=$latitude,$longitude'
      );
      final res = await http.get(url);
      if (res.statusCode != 200) final fb = await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
      return fb;
      final m = jsonDecode(res.body);
      final result = (m is Map) ? m['result'] : null;
      final pois = (result is Map) ? result['pois'] : null;
      if (pois is! List) final fb = await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
      return fb;

      final out = <PoiItem>[];
      for (final e in pois) {
        if (e is! Map) continue;
        final name = (e['name'] ?? '').toString();
        if (name.isEmpty) continue;
        if (keyword.isNotEmpty && !name.contains(keyword)) continue;
        final point = e['point'];
        final x = (point is Map) ? point['x'] : null;
        final y = (point is Map) ? point['y'] : null;
        final lng = (x is num) ? x.toDouble() : null;
        final lat = (y is num) ? y.toDouble() : null;
        if (lat == null || lng == null) continue;
        final dis = (e['distance'] is num) ? (e['distance'] as num).toInt() : null;
        out.add(PoiItem(name: name, address: e['addr']?.toString(), latitude: lat, longitude: lng, distance: dis));
      }
      // 简单分页：客户端再截断
      final start = (page-1) * pageSize;
      final end = (start + pageSize);
      return start >= out.length ? <PoiItem>[] : out.sublist(start, end.clamp(0, out.length));
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】拉取附近POI失败：$e'); } catch (_) {}
      final fb = await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
      return fb;
    }
  

  /// 当百度逆地理失败时，使用系统逆地理作为 UI 兜底（不保证距离字段）。
  static Future<List<PoiItem>> _fallbackSystemReverseGeocodingAsPois({
    required double latitude,
    required double longitude,
  }) async {
    try {
      final marks = await placemarkFromCoordinates(latitude, longitude);
      if (marks.isEmpty) final fb = await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
      return fb;
      final m = marks.first;
      final name = ((m.name ?? '') + ' ' + (m.street ?? '') + ' ' + (m.locality ?? '')).trim();
      return <PoiItem>[
        PoiItem(name: name.isEmpty ? '当前位置附近' : name, address: m.administrativeArea, latitude: latitude, longitude: longitude, distance: null),
      ];
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统逆地理兜底失败：$e'); } catch (_) {}
      final fb = await _fallbackSystemReverseGeocodingAsPois(latitude: latitude, longitude: longitude);
      return fb;
    }
  }

}
