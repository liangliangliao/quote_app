package com.example.quote_app.schedule;

import android.content.Context;
import java.util.Calendar;

public final class NextTriggerCalculator {
    private NextTriggerCalculator() {}

    /** 最小可用实现：若无法从 DB 精准计算，则回退到 +1 天 */
    public static long compute(Context ctx, String uid) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTimeInMillis();
    }
}
