
import 'dart:math';
import 'dart:io';
import 'dart:convert';
import 'package:csv/csv.dart';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';
import '../utils/debug_logger.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
  final rnd = r.nextInt(1<<32).toRadixString(36);
  return '${prefix}_${ts}_${rnd}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    await db.insert('configs', {'api_key':'','model':'gpt-5','endpoint':'https://api.openai.com/v1/responses'});
    final one = await db.query('configs', limit: 1);
    return one.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint});
    } else {
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint}, where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }
}

class TaskDao {
  Future<List<Map<String,dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return await db.query('tasks', orderBy: 'id DESC');
  }

  Future<Map<String,dynamic>?> getByUid(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<String> create({
    required String name,
    required String type,
    String status = 'on',
    String prompt = '',
    String avatarPath = '',
    String startTime = '09:00',
    String? freqType,
    int? freqWeekday,
    int? freqDayOfMonth,
    String? freqCustom,
    String carouselOrder = 'desc',
  }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'status': status,
      'prompt': prompt,
      'avatar_path': avatarPath,
      'start_time': startTime,
      'freq_type': (freqType ?? 'daily'),
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': (freqCustom ?? ''),
      'carousel_order': carouselOrder,
    });
    return uid;
  }

  Future<void> update(String uid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [uid]);
  }

  Future<void> delete(String uid) async {
    final db = await AppDatabase.instance();
    // Fill snapshots in logs before deleting the task
    final t = await getByUid(uid);
    if (t != null) {
      await db.rawUpdate(
        "UPDATE logs SET task_name_snapshot = COALESCE(task_name_snapshot, ?), task_start_time_snapshot = COALESCE(task_start_time_snapshot, ?) WHERE task_uid = ?",
        [ (t['name'] ?? '') as String, (t['start_time'] ?? '') as String, uid ]
      );
    }
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [uid]);
  }
}

class QuoteDao {
  Future<Map<String,dynamic>?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<Map<String, dynamic>?> latestNotifiedToday() async {
  final db = await AppDatabase.instance();
  String two(int v) => v.toString().padLeft(2,'0');
  final now = DateTime.now();
  final ymd = "${now.year}-${two(now.month)}-${two(now.day)}";

  // 动态检测是否存在旧列 last_notify_time，避免 SQLite 在编译含有不存在列的 SQL 时抛错
  bool _hasLegacy;
  try {
    final _info = await db.rawQuery("PRAGMA table_info(quotes)");
    _hasLegacy = _info.any((row) => (row['name']?.toString().toLowerCase() ?? '') == 'last_notify_time');
  } catch (_) {
    _hasLegacy = false;
  }
  if (!_hasLegacy) {
    // 直接使用仅 last_notified_at 的查询，避免引用不存在的列导致的编译错误
    final rows2 = await db.query(
      'quotes',
      where: "notified=1 AND substr(last_notified_at,1,10)=?",
      whereArgs: [ymd],
      orderBy: "last_notified_at DESC",
      limit: 1,
    );
    try { await DLog.i('DAO', 'latestNotifiedToday 列检测：无 last_notify_time，仅按 last_notified_at 检索；返回: ' + rows2.length.toString()); } catch (_){ }
    return rows2.isNotEmpty ? rows2.first : null;
  }
  try {
    final rows = await db.rawQuery(
      """
      SELECT * FROM quotes
      WHERE notified=1 AND (
        substr(COALESCE(last_notified_at, last_notify_time),1,10) = ?
        OR (
          /* 兼容 last_notify_time 为毫秒时间戳（int/string）的旧数据 */
          (CASE WHEN CAST(COALESCE(last_notify_time,'0') AS INTEGER) > 1000000000 THEN 1 ELSE 0 END) = 1
          AND DATE(DATETIME(CAST(last_notify_time AS INTEGER)/1000,'unixepoch','localtime')) = DATE('now','localtime')
        )
      )
      ORDER BY COALESCE(last_notified_at, last_notify_time) DESC
      LIMIT 1
      """,
      [ymd],
    );
    try { await DLog.i('DAO', 'latestNotifiedToday 查询成功，返回条数: ' + rows.length.toString()); } catch (_){ }
    return rows.isNotEmpty ? rows.first : null;
  } catch (e) {
    try { await DLog.e('DAO', 'latestNotifiedToday 查询失败，将回退到仅按 last_notified_at 检索: ' + e.toString()); } catch (_){ }
    final rows2 = await db.query(
      'quotes',
      where: "notified=1 AND substr(last_notified_at,1,10)=?",
      whereArgs: [ymd],
      orderBy: "last_notified_at DESC",
      limit: 1,
    );
    return rows2.isNotEmpty ? rows2.first : null;
  }
}
Future<List<Map<String,dynamic>>> all({int limit=100, int offset=0, String q=''}) async {
    final db = await AppDatabase.instance();
    if (q.trim().isEmpty) {
      return await db.query('quotes', orderBy: 'id DESC', limit: limit, offset: offset);
    } else {
      return await db.query('quotes', where: 'content LIKE ?', whereArgs: ['%$q%'], orderBy: 'id DESC', limit: limit, offset: offset);
    }
  }

  Future<String> insertQuote({required String taskUid, required String content, String? theme, String? authorName, String? sourceFrom, String? explanation, String? avatarPath, String? taskName, String? taskType, String? insertedAt}) async {
    final db = await AppDatabase.instance();
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'task_type': taskType ?? '',
      'task_name': taskName ?? '',
      'content': content,
      'theme': theme ?? '',
      'author_name': authorName ?? '',
      'source_from': sourceFrom ?? '',
      'explanation': explanation ?? '',
      'avatar': avatarPath ?? '',
      'inserted_at': insertedAt ?? '',
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    await LogDao().add(taskUid: taskUid, detail: '成功! 已插入名言');
    return uid;
  }

  // Deduplication: return true if content is unique against all existing quotes
  Future<bool> isUnique(String content, {double threshold = 0.90}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content']);
    final normNew = normalizeText(content);
    for (final r in rows) {
      final c = (r['content'] ?? '').toString();
      if (c.trim().isEmpty) continue;
      final sim = jaroWinkler(normNew, normalizeText(c));
      if (sim >= threshold || normalizeText(c) == normNew) {
        return false;
      }
    }
    return true;
  }

  // Round-robin (sequential) carousel for a task: oldest -> newest loop
  Future<Map<String,dynamic>?> carouselNextSequential(String taskUid) async {
    final db = await AppDatabase.instance();
    // Try to fetch quotes bound to this task first
    List<Map<String, dynamic>> rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC');
    // Fallback: if none exist, read all quotes globally (for carousel tasks with empty task)
    if (rows.isEmpty) {
      rows = await db.query('quotes', orderBy: 'id ASC');
      if (rows.isEmpty) return null;
      // Do not persist index for global fallback; always pick first row
      return rows.first;
    }
    final key = 'carousel_index_'+taskUid;
    final meta = await db.query('meta', where: 'key=?', whereArgs: [key], limit: 1);
    int idx = -1;
    if (meta.isNotEmpty) {
      idx = int.tryParse((meta.first['value'] ?? '-1').toString()) ?? -1;
    }
    final nextIdx = (idx + 1) % rows.length;
    final row = rows[nextIdx];
    // update cursor
    if (meta.isEmpty) {
      await db.insert('meta', {'key': key, 'value': nextIdx.toString()});
    } else {
      await db.update('meta', {'value': nextIdx.toString()}, where: 'key=?', whereArgs: [key]);
    }
    return row;
  }

  Future<void> markNotifiedByUid(String quoteUid) async {
  final db = await AppDatabase.instance();
  final now = DateTime.now();
  String two(int v)=> v.toString().padLeft(2,'0');
  final ts = "${now.year}-${two(now.month)}-${two(now.day)} ${two(now.hour)}:${two(now.minute)}:${two(now.second)}";
  try {
    await db.rawUpdate("UPDATE quotes SET notified=1, last_notified_at=? WHERE quote_uid=?", [ts, quoteUid]);
    try { await db.rawUpdate("UPDATE quotes SET last_notify_time=? WHERE quote_uid=?", [ts, quoteUid]); } catch (_) {}
    try { await db.rawUpdate("UPDATE quotes SET notify_status=1 WHERE quote_uid=?", [quoteUid]); } catch (_) {}
  } catch (_) {}
}
  // Compatibility wrapper used by UI pages
  Future<List<Map<String,dynamic>>> latest({int limit=100, int offset=0, String? q}) {
    return all(limit: limit, offset: offset, q: q ?? '');
  }


  Future<Map<String,dynamic>?> latestOne() async {
    final rows = await all(limit: 1, offset: 0);
    return rows.isNotEmpty ? rows.first : null;
  }


  Future<bool> existsSimilar(String content, {double threshold=0.90}) async {
    return !(await isUnique(content, threshold: threshold));
  }


  Future<bool> insertIfUnique({required String taskUid, required String content}) async {
    if (await isUnique(content, threshold: 0.90)) {
      await insertQuote(taskUid: taskUid, content: content);
      return true;
    }
    return false;
  }


  
          Future<bool> insertIfUniqueDetailed({required String taskUid, required String content, String? theme, String? authorName, String? sourceFrom, String? explanation, String? avatarPath, String? taskName, String? taskType, String? insertedAt}) async {
  if (await isUnique(content, threshold: 0.90)) {
    await insertQuote(taskUid: taskUid, content: content, theme: theme, authorName: authorName, sourceFrom: sourceFrom, explanation: explanation, avatarPath: avatarPath, taskName: taskName, taskType: taskType, insertedAt: insertedAt);
    return true;
  }
  return false;
}

Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isNotEmpty) {
      final id = rows.first['id'] as int;
      await db.update('quotes', {'content': content}, where: 'id=?', whereArgs: [id]);
      return true;
    } else {
      await insertQuote(taskUid: taskUid, content: content);
      return true;
    }
  }

  /// Update the latest quote for a task with additional fields.  If no quote
  /// exists for the task, a new one will be inserted with the provided
  /// values.  Returns true on success.
  Future<bool> updateLatestForTaskDetailed({
    required String taskUid,
    required String content,
    String? theme,
    String? authorName,
    String? sourceFrom,
    String? explanation,
    String? avatarPath,
  }) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    final now = DateTime.now();
    String two(int n) => n < 10 ? '0$n' : '$n';
    final nowStr = '${now.year}-${two(now.month)}-${two(now.day)} ${two(now.hour)}:${two(now.minute)}:${two(now.second)}';
    if (rows.isNotEmpty) {
      final id = rows.first['id'] as int;
      final patch = <String, Object?>{
        'content': content,
        'theme': theme ?? '',
        'author_name': authorName ?? '',
        'source_from': sourceFrom ?? '',
        'explanation': explanation ?? '',
      };
      if (avatarPath != null) patch['avatar'] = avatarPath;
      patch['inserted_at'] = nowStr;
      await db.update('quotes', patch, where: 'id=?', whereArgs: [id]);
      return true;
    } else {
      // Insert new quote with provided fields and the generated timestamp
      await insertQuote(
        taskUid: taskUid,
        content: content,
        theme: theme,
        authorName: authorName,
        sourceFrom: sourceFrom,
        explanation: explanation,
        avatarPath: avatarPath,
        taskName: '',
        taskType: '',
        insertedAt: nowStr,
      );
      return true;
    }
  }

  /// Fetch the most recent notified quote (notify_status=1) sorted by last_notified_at descending.
  /// Returns null if none exist.
  Future<Map<String,dynamic>?> latestNotified() async {
    final db = await AppDatabase.instance();
    // Use last_notified_at if present, otherwise fall back to inserted_at or created_at
    // We order by last_notified_at DESC to get the most recently notified quote
    final rows = await db.query('quotes', where: 'notified=1', orderBy: 'last_notified_at DESC', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    return null;
  }

  /// Fetch a quote belonging to [taskUid] by descending order index.  The
  /// [offset] parameter specifies which quote to return (0=latest, 1=second
  /// latest, etc).  Returns null if there are fewer quotes than the offset+1.
  Future<Map<String, dynamic>?> findByTaskOffsetDesc(String taskUid, int offset) async {
    final db = await AppDatabase.instance();
    // Use rawQuery with limit/offset to fetch by offset due to Sqflite limitations on offset in query method
    final rows = await db.rawQuery(
      'SELECT * FROM quotes WHERE task_uid = ? ORDER BY id DESC LIMIT 1 OFFSET ?',
      [taskUid, offset],
    );
    return rows.isNotEmpty ? rows.first : null;
  }
}class LogDao {
  Future<void> clearAll() async { final db = await AppDatabase.instance(); await db.delete('logs'); }

  Future<String> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    // snapshot task name and start_time
    String? name, start;
    final trows = await db.query('tasks', where: 'task_uid=?', whereArgs: [taskUid], limit: 1);
    if (trows.isNotEmpty) {
      name = (trows.first['name'] ?? '').toString();
      start = (trows.first['start_time'] ?? '').toString();
    }
    final logUid = _uid('log');
    await db.insert('logs', {
      'log_uid': logUid,
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'task_name_snapshot': name,
      'task_start_time_snapshot': start,
    }, conflictAlgorithm: ConflictAlgorithm.ignore);
    return logUid;
  }

  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0}) async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
      'SELECT logs.*, '
      'COALESCE(logs.task_name_snapshot, tasks.name, "") AS task_name, '
      'COALESCE(logs.task_start_time_snapshot, tasks.start_time, "") AS task_start_time '
      'FROM logs LEFT JOIN tasks ON tasks.task_uid = logs.task_uid '
      'ORDER BY logs.id DESC LIMIT ? OFFSET ?', [limit, offset]);
    return rows;
  }
}


class FailureStatDao {
  Future<void> insertFail({required String taskUid, required String channel, required String uniqueId, required String dateStr}) async {
    final db = await AppDatabase.instance();
    await db.insert('notify_failures', {
      'task_uid': taskUid,
      'channel': channel,
      'unique_id': uniqueId,
      'status': 'fail',
      'date_str': dateStr,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> markLatestSuccess(String taskUid) async {
    final db = await AppDatabase.instance();
    await db.execute("UPDATE notify_failures SET status='success' WHERE id=(SELECT id FROM notify_failures WHERE task_uid=? ORDER BY id DESC LIMIT 1)", [taskUid]);
  }

  Future<List<Map<String,dynamic>>> failsOfToday() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final d = now.toIso8601String().substring(0,10); // YYYY-MM-DD
    return await db.query('notify_failures', where: "date_str=? AND status='fail'", whereArgs: [d]);
  }
}


class NotifyConfigDao {
  Future<int> getSelfCheckMinutes() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_config', where: 'key=?', whereArgs: ['selfcheck_minutes']);
    if (rows.isEmpty) return 15;
    final v = int.tryParse((rows.first['value'] ?? '15').toString()) ?? 15;
    return v < 15 ? 15 : v; // WM 最小 15 分钟
  }

  Future<void> setSelfCheckMinutes(int minutes) async {
    final db = await AppDatabase.instance();
    final m = minutes < 15 ? 15 : minutes;
    final exists = await db.query('notify_config', where: 'key=?', whereArgs: ['selfcheck_minutes']);
    if (exists.isEmpty) {
      await db.insert('notify_config', {'key':'selfcheck_minutes','value': m.toString()});
    } else {
      await db.update('notify_config', {'value': m.toString()}, where:'key=?', whereArgs: ['selfcheck_minutes']);
    }
  }
}


class NotifyGuardDao {
  Future<bool> alreadySent(String taskUid, String runKey, {String chan='main-wm', int attempt=1}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_guard', where: 'task_uid=? AND run_key=? AND (chan=? OR chan IS NULL) AND (attempt=? OR attempt IS NULL)', whereArgs: [taskUid, runKey, chan, attempt]);
    return rows.isNotEmpty;
  }
  Future<void> markSent(String taskUid, String runKey, {String chan='main-wm', int attempt=1}) async {
    final db = await AppDatabase.instance();
    await db.insert('notify_guard', {'task_uid': taskUid, 'run_key': runKey, 'chan': chan, 'attempt': attempt, 'created_at': DateTime.now().toIso8601String()});
  }
}


class _AuxTables {
  static Future<void> ensure() async {
    final db = await AppDatabase.instance();
    await db.execute("CREATE TABLE IF NOT EXISTS notify_failures (id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT, channel TEXT, unique_id TEXT, status TEXT, date_str TEXT, created_at TEXT)");
    await db.execute("CREATE TABLE IF NOT EXISTS notify_config (key TEXT PRIMARY KEY, value TEXT)");
    await db.execute("CREATE TABLE IF NOT EXISTS notify_guard (id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT, run_key TEXT, created_at TEXT, UNIQUE(task_uid, run_key))");
  
    await _AuxTablesTasksExt.ensureTaskColumns();
    // Migrate notify_guard to precise keys
    try { await db.execute("ALTER TABLE notify_guard ADD COLUMN chan TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE notify_guard ADD COLUMN attempt INTEGER"); } catch (_) {}
    try { await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_notify_guard ON notify_guard(task_uid, run_key, chan, attempt)"); } catch (_) {}

  }
}

class _AuxTablesTasksExt {
  static Future<void> ensureTaskColumns() async {
    final db = await AppDatabase.instance();
    try { await db.execute("ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN next_time TEXT"); } catch (_) {}
  }
}

// Public helper to ensure auxiliary tables and columns exist.  This should be
// invoked early in the app startup to add missing columns (like next_time
// and scheduled_run_key) on older databases.  It simply forwards to the
// internal _AuxTables.ensure() which is private to this library.  Do not
// reference _AuxTables from outside this file directly since it is
// library‑private.
Future<void> ensureExtraTaskColumns() async {
  await _AuxTables.ensure();
}

extension TaskDaoPatch on TaskDao {
  Future<void> setScheduledRunKey(String uid, String runKey) async {
    final db = await AppDatabase.instance();
    try {
      // Try update scheduled_run_key normally. If column missing, ensure extra columns then retry.
      await db.update('tasks', {'scheduled_run_key': runKey}, where: 'task_uid=?', whereArgs: [uid]);
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('no such column') && msg.contains('scheduled_run_key')) {
        try {
          await ensureExtraTaskColumns();
          await db.update('tasks', {'scheduled_run_key': runKey}, where: 'task_uid=?', whereArgs: [uid]);
        } catch (_) {}
      }
    }
  }
}


class BulkImportResult {
  final bool success;
  final List<Map<String, dynamic>> details; // [{row, reason}]
  BulkImportResult(this.success, this.details);
}

extension QuoteDaoBulk on QuoteDao {
  Future<BulkImportResult> bulkImportCsv({required String csvPath, String? avatarPath}) async {
    final db = await AppDatabase.instance();
    final content = await File(csvPath).readAsString();
    final rows = LineSplitter().convert(content);
    if (rows.isEmpty) return BulkImportResult(false, [{'row':0,'reason':'CSV为空'}]);
    // Parse using simple CSV rules or rely on commas
    // Try to use package:csv if available
    List<List<dynamic>> table = [];
    try {
      // ignore: undefined_prefixed_name
      table = CsvToListConverter(eol: '\n').convert(content);
    } catch (_) {
      // Fallback naive split
      for (final line in rows) {
        table.add(line.split(','));
      }
    }
    if (table.isEmpty) return BulkImportResult(false, [{'row':0,'reason':'CSV解析失败'}]);
    final header = table.first.map((e)=> e.toString().trim()).toList();
    // 自动匹配 CSV 标题与字段名称（支持关键词匹配）。
    // 定义每个字段名称对应的一组中文关键词。只要标题包含其中任意一个关键词，就认为匹配到该字段。
    final Map<String, List<String>> _fieldKeywords = {
      '主题': ['主题','标题','中心思想','中心主题','主题思想'],
      '名人名言内容': ['名人名言内容','名句内容','名言','经典名言','核心内容','内容'],
      '署名': ['署名','作者','签名'],
      '出处': ['出处','来源','著作','出自','引用出处'],
      '解释': ['解释','概要','详细解释','解释和具体案例','为什么和该如何做','为什么','该如何做','深度分析','是什么'],
    };
    // 根据表头逐列匹配字段索引。若列标题包含某个字段的关键词且该字段尚未被匹配，则记录索引。
    final Map<String,int> idx = {};
    for (int i = 0; i < header.length; i++) {
      final col = header[i];
      _fieldKeywords.forEach((field, keywords) {
        for (final kw in keywords) {
          if (!idx.containsKey(field) && col.contains(kw)) {
            idx[field] = i;
            break;
          }
        }
      });
    }
    // 检查是否缺少必需的字段；若任何字段未匹配，则返回错误。
    final missingFields = _fieldKeywords.keys.where((k) => !idx.containsKey(k)).toList();
    if (missingFields.isNotEmpty) {
      return BulkImportResult(false, [{'row':1,'reason':'缺少表头: ' + missingFields.join('、')}]);
    }
    // Prepare duplicate checks
    final errors = <Map<String,dynamic>>[];
    final seen = <String>{};
    // DB duplicates
    final dbRows = await db.query('quotes', columns: ['content']);
    final dbSet = dbRows.map((e)=> (e['content']??'').toString().trim().toLowerCase()).toSet();
    for (int i=1;i<table.length;i++){
      final row = table[i];
      String contentCell = (row.length>idx['名人名言内容']! ? row[idx['名人名言内容']!].toString() : '').trim();
      final rnum = i+1;
      if (contentCell.isEmpty) {
        errors.add({'row': rnum, 'reason': '名人名言内容为空'});
      } else {
        final key = contentCell.toLowerCase();
        if (seen.contains(key)) errors.add({'row': rnum, 'reason': '名人名言内容在CSV中重复'});
        if (dbSet.contains(key)) errors.add({'row': rnum, 'reason': '名人名言内容与数据库重复'});
        seen.add(key);
      }
    }
    if (errors.isNotEmpty) return BulkImportResult(false, errors);

    // Ensure a task '批量导入' exists
    final taskDao = TaskDao();
    String bulkTaskUid;
    final rowsTasks = await db.query('tasks', where: 'name=?', whereArgs: ['批量导入'], limit: 1);
    if (rowsTasks.isEmpty) {
      // Create a bulk import task with type '批量导入任务'.  Use empty fields for prompt and startTime; cursor defaults to 0.
      bulkTaskUid = await taskDao.create(
        name: '批量导入',
        type: '批量导入任务',
        status: 'on',
        prompt: '',
        avatarPath: '',
        startTime: '',
        freqType: 'daily',
        freqWeekday: null,
        freqDayOfMonth: null,
        freqCustom: null,
      );
    } else {
      bulkTaskUid = rowsTasks.first['task_uid'] as String;
      // Ensure the existing bulk-import task has the correct type
      final existingType = (rowsTasks.first['type'] ?? '').toString();
      if (existingType != '批量导入任务') {
        await taskDao.update(bulkTaskUid, {'type': '批量导入任务'});
      }
    }

    // Insert all within a transaction
    try {
      await db.transaction((txn) async {
        // Compute once the timestamp string used for all inserted quotes' task_name (批量导入_YYYY-MM-DD HH:mm:SS)
        final now = DateTime.now();
        String two(int n) => n < 10 ? '0$n' : '$n';
        final nowStr = '${now.year}-${two(now.month)}-${two(now.day)} ${two(now.hour)}:${two(now.minute)}:${two(now.second)}';
        for (int i = 1; i < table.length; i++) {
          final row = table[i];
          String theme = row.length > idx['主题']! ? row[idx['主题']!].toString().trim() : '';
          String contentCell = row.length > idx['名人名言内容']! ? row[idx['名人名言内容']!].toString().trim() : '';
          String authorName = row.length > idx['署名']! ? row[idx['署名']!].toString().trim() : '';
          String sourceFrom = row.length > idx['出处']! ? row[idx['出处']!].toString().trim() : '';
          String explanation = row.length > idx['解释']! ? row[idx['解释']!].toString().trim() : '';
          final uid = _uid('quote');
          await txn.insert('quotes', {
            'quote_uid': uid,
            'task_uid': bulkTaskUid,
            // task_type for bulk import tasks is 批量导入任务
            'task_type': '批量导入任务',
            // task_name should include timestamp to differentiate this batch
            'task_name': '批量导入_$nowStr',
            'content': contentCell,
            'theme': theme,
            'author_name': authorName,
            'source_from': sourceFrom,
            'explanation': explanation,
            'avatar': avatarPath ?? '',
            'inserted_at': nowStr,
            'notified': 0,
            'created_at': now.millisecondsSinceEpoch,
          });
          await txn.insert('logs', {
            'log_uid': _uid('log'),
            'task_uid': bulkTaskUid,
            'detail': '批量导入: 已插入一条名言'
          }, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
      });
      return BulkImportResult(true, []);
    } catch (e) {
      // Transaction will rollback automatically
      return BulkImportResult(false, [{'row': 0, 'reason': '插入数据库失败: ' + e.toString()}]);
    }
  }


/// 物理洗牌：真正改变 quotes 表的行顺序（方案B：重建表并写入新 id）
Future<void> shuffleQuotesPhysically() async {
  // -- 改进版物理洗牌：随机写入 quotes_new，然后替换 --
  final db = await AppDatabase.instance();
  await db.transaction((txn) async {
    // 1) 复制表结构到 quotes_new
    final schemaRows = await txn.query(
      'sqlite_master',
      columns: ['sql'],
      where: "type='table' AND name='quotes'",
      limit: 1,
    );
    final String rawCreate = (schemaRows.first['sql'] as String);
    final String createSql = rawCreate.replaceFirst(
      RegExp(r'CREATE\s+TABLE\s+[\"`]?quotes[\"`]?', caseSensitive: false),
      'CREATE TABLE quotes_new'
    );
    await txn.execute('DROP TABLE IF EXISTS quotes_new');
    await txn.execute(createSql);

    // 2) 随机盐 + random() 打散行顺序，然后直接插入 quotes_new
    final int salt = DateTime.now().millisecondsSinceEpoch & 0x7fffffff;
    await txn.rawInsert('''
      INSERT INTO quotes_new (
        quote_uid, task_uid, content, notified, created_at,
        theme, author_name, source_from, explanation, avatar,
        inserted_at, last_notified_at, taskType, taskName, task_type, task_name
      )
      SELECT
        quote_uid, task_uid, content, notified, created_at,
        theme, author_name, source_from, explanation, avatar,
        inserted_at, last_notified_at, taskType, taskName, task_type, task_name
      FROM quotes
      ORDER BY abs(random() + ?), rowid
    ''', [salt]);

    // 3) 替换旧表
    await txn.execute('DROP TABLE quotes');
    await txn.execute('ALTER TABLE quotes_new RENAME TO quotes');
  });

  // 4) VACUUM 固化页顺序
  try {
    await db.execute('PRAGMA wal_checkpoint(TRUNCATE)');
  } catch (_) {}
  try {
    await db.execute('VACUUM');
  } catch (_) {}
}

/// 恢复到“最初插入表时”的顺序（使用备份表中 original_pos / original_id）
Future<void> restoreQuotesToOriginalOrder() async {
  final db = await AppDatabase.instance();
  await db.transaction((txn) async {
    // 1) 确保备份表存在（若不存在则无从恢复）
    await txn.execute('CREATE TABLE IF NOT EXISTS quotes_id_backup (quote_uid TEXT PRIMARY KEY, original_id INTEGER, original_pos INTEGER)');
    await txn.execute('INSERT OR IGNORE INTO quotes_id_backup(quote_uid, original_id, original_pos) SELECT quote_uid, id, rowid FROM quotes');

    // 2) 用当前 quotes 表的结构创建新表
    final schemaRows = await txn.rawQuery("SELECT sql FROM sqlite_master WHERE type='table' AND name='quotes'");
    if (schemaRows.isEmpty || schemaRows.first['sql'] == null) {
      throw Exception('无法读取 quotes 表结构');
    }
    final String rawCreate2 = (schemaRows.first['sql'] as String);
final String createSql2 = rawCreate2.replaceFirst(
  RegExp(r'CREATE\s+TABLE\s+[\"`]?quotes[\"`]?', caseSensitive: false),
  'CREATE TABLE quotes_new'
);
await txn.execute('DROP TABLE IF EXISTS quotes_new');
await txn.execute(createSql2);

    // 2.1 备份索引
    final idxRows = await txn.rawQuery("SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name='quotes' AND sql IS NOT NULL");

    // 3) 动态列集合（除 id 外）
    final cols = await txn.rawQuery('PRAGMA table_info(quotes)');
    final allCols = <String>[];
    for (final c in cols) {
      final name = (c['name'] ?? '') as String;
      if (name.isNotEmpty) allCols.add(name);
    }
    final nonId = allCols.where((e) => e != 'id').toList();
    final nonIdJoined = nonId.map((c) => 'q.' + c).join(', ');
    final newColsJoined = nonId.join(', ');

    // 4) 按 original_pos 顺序恢复，并把 id 恢复为 original_id
    final insertSql = 'INSERT INTO quotes_new (id, ' + newColsJoined + ') '
        'SELECT b.original_id, ' + nonIdJoined + ' FROM quotes q JOIN quotes_id_backup b ON b.quote_uid=q.quote_uid '
        'ORDER BY b.original_pos ASC';
    await txn.execute(insertSql);

    // 5) 替换原表
    await txn.execute('DROP TABLE quotes');
    await txn.execute('ALTER TABLE quotes_new RENAME TO quotes');

    // 6) 重建索引
    for (final row in idxRows) {
      final sql = row['sql'] as String?;
      if (sql != null && sql.trim().isNotEmpty) {
        await txn.execute(sql);
      }
    }
  });
}
}