package com.example.quote_app

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.JobIntentService
import com.example.quote_app.data.DbRepo

/**
 * 屏幕看门人【后台作业服务版】：不再使用前台服务。
 * - 通过 JobIntentService 在后台线程执行：查库 -> 判断开关 -> 冷却判定 -> 发送通知。
 * - 由各处（解锁/亮屏广播“前”和“后”）调用 enqueueUnlockWork() 触发。
 * - 全程详细中文日志，便于在数据库日志表追踪。
 */
class ScreenGatekeeperService : JobIntentService() {

    override fun onHandleWork(intent: Intent) {
        val action = intent.action
        val source = intent.getStringExtra(EXTRA_SOURCE) ?: "unknown"
        val whenMs = System.currentTimeMillis()
        try {
            DbRepo.log(this, null, "【后台服务】onHandleWork：开始处理解锁/亮屏流程，source=" + source + "，action=" + (action ?: "null") + "，when=" + whenMs)
        } catch (_: Throwable) {}

        // 1) 查库：配置与冷却
        var hasTrigger = false
        var configEnabled = false
        var coolDownOk = true
        try {
            val info = DbRepo.queryUnlockConfig(this)
            hasTrigger = info.hasTrigger
            configEnabled = info.configEnabled
            coolDownOk = DbRepo.isUnlockCoolDownOk(this)
            DbRepo.log(this, null, "【后台服务】查库完成：hasTrigger=" + hasTrigger + "，configEnabled=" + configEnabled + "，coolDownOk=" + coolDownOk)
        } catch (e: Throwable) {
            try { DbRepo.log(this, null, "【后台服务】查库异常，exception=" + e.javaClass.simpleName + "，message=" + (e.message ?: "null")) } catch (_: Throwable) {}
        }

        // 2) 满足条件则发送提醒
        if (hasTrigger && configEnabled && coolDownOk) {
            try { DbRepo.log(this, null, "【后台服务】满足触发条件，准备立即通过 NotifyHelper 发送解锁提醒通知") } catch (_: Throwable) {}
            try {
                val id = 2000
                val title = "愿景提醒"
                val body = "（后台服务触发）"
                NotifyHelper.sendUnlockReminder(this, id, title, body)
                DbRepo.log(this, null, "【后台服务】已调用 NotifyHelper.sendUnlockReminder 发送解锁提醒通知，id=" + id)
                DbRepo.updateUnlockCoolDown(this, whenMs)
            } catch (e: Throwable) {
                try { DbRepo.log(this, null, "【后台服务】发送解锁提醒时异常，exception=" + e.javaClass.simpleName + "，message=" + (e.message ?: "null")) } catch (_: Throwable) {}
            }
        } else {
            try { DbRepo.log(this, null, "【后台服务】未满足触发条件，hasTrigger=" + hasTrigger + "，configEnabled=" + configEnabled + "，coolDownOk=" + coolDownOk) } catch (_: Throwable) {}
        }

        try { DbRepo.log(this, null, "【后台服务】onHandleWork：处理完毕，source=" + source) } catch (_: Throwable) {}
    }

    companion object {
        private const val JOB_ID = 2001
        private const val EXTRA_SOURCE = "source"

        @JvmStatic
        fun enqueueUnlockWork(ctx: Context, source: String) {
            try { DbRepo.log(ctx, null, "【后台服务】enqueueUnlockWork：收到请求，source=" + source + "，将入队到 JobIntentService 执行") } catch (_: Throwable) {}
            val intent = Intent(ctx, ScreenGatekeeperService::class.java).apply {
                action = "com.example.quote_app.action.PROCESS_UNLOCK"
                putExtra(EXTRA_SOURCE, source)
            }
            try {
                enqueueWork(ctx, ScreenGatekeeperService::class.java, JOB_ID, intent)
            } catch (e: Throwable) {
                try { DbRepo.log(ctx, null, "【后台服务】enqueueUnlockWork：enqueueWork 异常，exception=" + e.javaClass.simpleName + "，message=" + (e.message ?: "null")) } catch (_: Throwable) {}
            }
        }
    }
}
