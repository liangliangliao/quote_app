import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class DeliverGuard {
  static const String _fileName = 'deliver_guard.json';

  static Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  static Future<Map<String, dynamic>> _read() async {
    try {
      final f = await _file();
      if (!await f.exists()) return {};
      final txt = await f.readAsString();
      final obj = jsonDecode(txt);
      if (obj is Map<String, dynamic>) return obj;
      return {};
    } catch (_) {
      return {};
    }
  }

  static Future<void> _write(Map<String, dynamic> data) async {
    try {
      final f = await _file();
      await f.writeAsString(jsonEncode(data));
    } catch (_) {}
  }

  static Future<bool> recentlyDelivered(String key, {Duration window = const Duration(seconds: 90)}) async {
    final data = await _read();
    final now = DateTime.now().millisecondsSinceEpoch;
    final ts = data[key];
    if (ts is int) {
      if (now - ts <= window.inMilliseconds) return true;
    }
    // clean expired
    final keys = List<String>.from(data.keys);
    for (final k in keys) {
      final v = data[k];
      if (v is int && now - v > window.inMilliseconds * 4) {
        data.remove(k);
      }
    }
    await _write(data);
    return false;
  }

  static Future<void> markDelivered(String key) async {
    final data = await _read();
    data[key] = DateTime.now().millisecondsSinceEpoch;
    await _write(data);
  }
}
