import 'dart:isolate';
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import 'bg_init.dart';
import 'workmanager_bridge.dart';
import 'deliver_guard.dart';

class SchedulerService {
  static const int _retryId = 77777;

  static Future<void> init() async {
    try { await AndroidAlarmManager.initialize(); } catch (_) {}
    try { await WorkManagerBridge.init(); } catch (_) {}
  }

  static String _fmt(DateTime dt) => DateFormat('yyyy-MM-dd HH:mm').format(dt);

  static int _alarmIdForTask(String taskUid) {
    // stable positive int
    final h = taskUid.hashCode & 0x7fffffff;
    // avoid colliding with retry id
    return (h == _retryId) ? h ^ 0x11111 : h;
  }

  static DateTime? _computeNext(Map<String, Object?> t, DateTime now) {
    final type = (t['type'] ?? 'manual') as String;
    final startStr = (t['start_time'] ?? '') as String;
    final freqType = (t['freq_type'] ?? 'daily') as String;
    final freqWeekday = t['freq_weekday'] as int?;       // 1..7
    final freqDayOfMonth = t['freq_day_of_month'] as int?;

    // Parse HH:mm
    final parts = startStr.split(':');
    final hh = parts.isNotEmpty ? int.tryParse(parts[0]) ?? 9 : 9;
    final mm = parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0;

    if (freqType == 'weekly') {
      final wd = (freqWeekday ?? 1).clamp(1, 7);
      final today = DateTime(now.year, now.month, now.day, hh, mm);
      int delta = (wd - now.weekday) % 7;
      var cand = today.add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freqType == 'monthly') {
      final d = (freqDayOfMonth ?? 1).clamp(1, 28);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      // daily / default
      var cand = DateTime(now.year, now.month, now.day, hh, mm);
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 1));
      return cand;
    }
  }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');

    final now = DateTime.now();
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final taskUid = (t['task_uid'] as String);
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;

      final next = _computeNext(t, now);
      if (next == null) continue;

      final id = _alarmIdForTask(taskUid);
      bool canExact = true;
      try {
        await AndroidAlarmManager.oneShotAt(
          next,
          id,
          alarmCallback,
          exact: canExact,
          wakeup: true,
          allowWhileIdle: true,
          rescheduleOnReboot: true,
        );
      } catch (_) {
        canExact = false;
      }

      if (!canExact) {
        // Fallback: WorkManager one-off (仍然是 Dart 链路，不是原生兜底)
        try { await WorkManagerBridge.scheduleOneOff(next, nid: id); } catch (_) {}
      }

      try {
        await LogDao().add(taskUid: taskUid, detail: '已安排: ' + _fmt(next));
      } catch (_) {}
    }
  }

  static Future<void> callback() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    final now = DateTime.now();

    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final taskUid = (t['task_uid'] as String);
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;
      final startStr = (t['start_time'] ?? '') as String;

      // 是否应当在此刻触发（按分钟）
      final next = _computeNext(t, now.subtract(const Duration(minutes: 1)));
      if (next == null) continue;
      if ((now.difference(next)).inMinutes.abs() > 1) continue;

      // 去重（同一分钟内只发一次）
      final dedupKey = 'task:' + taskUid + '@' + DateFormat('yyyy-MM-dd HH:mm').format(now);
      if (await DeliverGuard.recentlyDelivered(dedupKey)) {
        await LogDao().add(taskUid: taskUid, detail: '去重：本分钟已发送，忽略');
        continue;
      }

      // 构造内容
      String body = '';
      if (type == 'manual') {
        final last = await QuoteDao().latestForTask(taskUid);
        body = ((last?['content'] ?? '') as String).trim();
      } else {
        // 自动生成：先用本次生成，失败则回退最近缓存
        String? generated;
        try {
          final cfg = await ConfigDao().getOne();
          final endpoint = (cfg['endpoint'] ?? '').toString();
          final apiKey = (cfg['api_key'] ?? '').toString();
          final model = (cfg['model'] ?? 'gpt-4o-mini').toString();
          final prompt = (t['prompt'] ?? '').toString();
          if (endpoint.isNotEmpty && apiKey.isNotEmpty) {
            generated = await OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model).generateQuote(prompt);
          } else {
            generated = '';
          }
        } catch (_) {}
        body = (generated ?? '').trim();
        if (body.isEmpty) {
          final last = await QuoteDao().latestForTask(taskUid);
          body = ((last?['content'] ?? '') as String).trim();
        }
        if (body.isNotEmpty) {
          // 记录
          try {
            await QuoteDao().insertIfUnique(
              taskUid: taskUid,
              type: 'auto',
              taskName: name,
              avatarPath: avatar,
              content: body,
            );
          } catch (_) {}
        }
      }

      if (body.isEmpty) {
        await LogDao().add(taskUid: taskUid, detail: '跳过：名人名言内容为空');
        continue;
      }

      try {
        if (!NotificationService.isReady) {
          try { await NotificationService.ensureReady(tries: 10, delay: const Duration(milliseconds: 600)); } catch (_) {}
        }
        await NotificationService.show(
          id: _alarmIdForTask(taskUid),
          title: name,
          body: body,
          largeIconPath: avatar.isEmpty ? null : avatar,
        );
      } catch (e) {
        try { await LogDao().add(taskUid: taskUid, detail: '通知发送失败: ' + e.toString()); } catch (_) {}
      }

      await DeliverGuard.markDelivered(dedupKey);
    }

    // 安排下一轮
    await scheduleNextForAll();
  }

  static Future<void> scheduleRetryIn(Duration delta) async {
    final when = DateTime.now().add(delta);
    try {
      await AndroidAlarmManager.oneShotAt(
        when,
        _retryId,
        alarmCallback,
        exact: true,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
    } catch (e) {
      try { await LogDao().add(taskUid: 'system', detail: 'retry安排失败: ' + e.toString()); } catch (_) {}
    }
  }
}

// 顶层后台入口：避免被 tree-shake
@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  await BackgroundBootstrap.initForBackground();
  try {
    await SchedulerService.callback();
  } catch (e) {
    try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: 'callback异常: ' + e.toString()); } catch (_) {}
  }
}