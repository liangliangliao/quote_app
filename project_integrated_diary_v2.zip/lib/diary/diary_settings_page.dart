import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../data/db.dart';

class DiarySettingsPage extends StatefulWidget {
  const DiarySettingsPage({super.key});

  @override
  State<DiarySettingsPage> createState() => _DiarySettingsPageState();
}

class _DiarySettingsPageState extends State<DiarySettingsPage> {
  String? _bgPath;
  double _opacity = 0.25;
  final _pinCtrl = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = await AppDatabase.instance();
    try {
      final rows = await db.query('configs', orderBy: 'id DESC', limit: 1);
      if (rows.isNotEmpty) {
        _bgPath = (rows.first['diary_bg_image'] ?? '') as String?;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _opacity = double.tryParse(op.toString()) ?? _opacity;
        _pinCtrl.text = (rows.first['diary_pin'] ?? '').toString();
      }
    } catch (_) {}
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _save() async {
    final db = await AppDatabase.instance();
    await db.insert('configs', {
      'diary_bg_image': _bgPath,
      'diary_bg_opacity': _opacity,
      'diary_pin': _pinCtrl.text.trim(),
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

  Future<void> _pickBg() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;
    setState(() => _bgPath = path);
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final exists = _bgPath != null && _bgPath!.isNotEmpty && File(_bgPath!).existsSync();
    return Scaffold(
      appBar: AppBar(title: const Text('日记设置')),
      body: ListView(
        children: [
          const ListTile(title: Text('背景设置')),
          ListTile(
            title: const Text('选择背景图'),
            subtitle: Text(exists ? _bgPath! : '未设置'),
            onTap: _pickBg,
          ),
          if (exists) ListTile(title: const Text('清除背景图'), onTap: () => setState(()=>_bgPath=null)),
          ListTile(title: const Text('背景透明度'), subtitle: Text('${(_opacity*100).round()}%')),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Slider(value: _opacity, onChanged: (v)=>setState(()=>_opacity=v))),
          const Divider(),
          const ListTile(title: Text('PIN 锁（进入日记模块时验证）')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(controller: _pinCtrl, decoration: const InputDecoration(labelText: '4位数字（留空表示不开启）', border: OutlineInputBorder()), maxLength: 4, keyboardType: TextInputType.number),
          ),
          const SizedBox(height: 12),
          Center(child: FilledButton(onPressed: _save, child: const Text('保存设置'))),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
