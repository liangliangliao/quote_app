import 'mood_trend_page.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:convert';
import 'dart:io';
import '../data/db.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'diary_dao.dart';
import 'entry_editor_page.dart';
import 'entry_reader_page.dart';

class NotebookPage extends StatefulWidget {
  final Notebook notebook;
  const NotebookPage({super.key, required this.notebook});

  @override
  State<NotebookPage> createState() => _NotebookPageState();
}

class _NotebookPageState extends State<NotebookPage> {

  Future<void> _rememberNotebook() async {
    try {
      final db = await AppDatabase.instance();
      await db.insert('configs', {'diary_last_notebook_id': widget.notebook.id});
    } catch (_) {}
  }

  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy-MM-dd HH:mm');
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();

  List<DiaryEntry> _items = [];
  int? _tagId;
  String? _tagName;
  DateTime? _day;
  String? _cursor;
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;

  String? _keyword;


  Future<void> _filterByTag() async {
    final tags = await _dao.listTags();
    final result = await showModalBottomSheet<(int?, String?)>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(child: ListView(
        children: [
          ListTile(leading: Icon(_tagId==null?Icons.check_circle:Icons.circle_outlined), title: const Text('全部'), onTap: ()=>Navigator.pop(context,(null,null))),
          const Divider(height:1),
          ...tags.map((t)=>ListTile(
            leading: Icon(_tagId==t.id?Icons.check_circle:Icons.circle_outlined),
            title: Text(t.name),
            onTap: ()=>Navigator.pop(context,(t.id, t.name)),
          )),
        ],
      )),
    );
    if (result==null) return;
    setState((){ _tagId = result.\$1; _tagName = result.\$2; });
    await _loadFirst();
  }


  Future<void> _pickDay() async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: _day ?? now, firstDate: DateTime(2000,1,1), lastDate: DateTime(now.year+1));
    setState(()=>_day = picked);
    await _loadFirst();
  }

  @override
  void initState() {
    super.initState();
    _loadFirst();
    _rememberNotebook();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200) _loadMore();
    });
  }

  Future<void> _loadFirst() async {
    setState(() { _loading = true; _cursor = null; _hasMore = true; _items = []; });
    final res = await _dao.listEntries(notebookId: widget.notebook.id, limit: 50, cursor: null, keyword: _keyword, day: _day, tagId: _tagId);
    setState(() {
      _items = res.items;
      _cursor = res.nextCursor;
      _hasMore = res.nextCursor != null;
      _loading = false;
    });
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _loadingMore || _loading) return;
    setState(() => _loadingMore = true);
    final res = await _dao.listEntries(notebookId: widget.notebook.id, limit: 50, cursor: _cursor, keyword: _keyword, day: _day, tagId: _tagId);
    setState(() {
      _items.addAll(res.items);
      _cursor = res.nextCursor;
      _hasMore = res.nextCursor != null;
      _loadingMore = false;
    });
  }

  Future<void> _newEntry() async {
    final id = await Navigator.push<int?>(context, MaterialPageRoute(builder: (_) => EntryEditorPage(notebookId: widget.notebook.id)));
    if (id != null) _loadFirst();
    _rememberNotebook();
  }

  void _openEntry(DiaryEntry e) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => EntryReaderPage(notebookId: widget.notebook.id, initialEntryId: e.id)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.notebook.name),
        actions: [
          IconButton(tooltip:'标签筛选', onPressed: _filterByTag, icon: const Icon(Icons.label_outline)),
          IconButton(tooltip:'日期定位', onPressed: _pickDay, icon: const Icon(Icons.calendar_month_outlined)),
          PopupMenuButton<String>(onSelected: (v) async {
            if (v=='export') {
              final data = await _dao.exportNotebook(widget.notebook.id);
              final dir = await FilePicker.platform.getDirectoryPath();
              if (dir!=null){ final f = File('$dir/notebook_${widget.notebook.id}_${DateTime.now().millisecondsSinceEpoch}.json'); await f.writeAsString(const JsonEncoder.withIndent('  ').convert(data)); if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已导出到: '+f.path))); }
            } else if (v=='import') {
              final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
              if (res!=null && res.files.isNotEmpty && res.files.single.path!=null) {
                final txt = await File(res.files.single.path!).readAsString();
                final data = jsonDecode(txt) as Map<String,dynamic>;
                await _dao.importToNotebook(widget.notebook.id, data);
                await _loadFirst();
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('导入完成')));
              }
            } else if (v=='mood') {
              Navigator.push(context, MaterialPageRoute(builder: (_)=> const MoodTrendPage()));
            }
          }, itemBuilder: (c)=> const [
            PopupMenuItem(value:'export', child: Text('导出 JSON')), 
            PopupMenuItem(value:'import', child: Text('导入 JSON')),
            PopupMenuItem(value:'mood', child: Text('心情趋势')),
          ]),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: _newEntry, child: const Icon(Icons.create)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索当前日记本…', border: OutlineInputBorder(), isDense: true),
              onSubmitted: (v) { _keyword = v.trim().isEmpty ? null : v.trim(); _loadFirst();
    _rememberNotebook(); },
            ),
          ),
          if (_tagId!=null || _day!=null) Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Wrap(spacing: 8, children: [
            if (_tagId!=null) Chip(label: Text('标签: '+(_tagName??_tagId.toString())), onDeleted: () async { setState(()=>_tagId=null); await _loadFirst(); }),
            if (_day!=null) Chip(label: Text('日期: '+DateFormat('yyyy-MM-dd').format(_day!)), onDeleted: () async { setState(()=>_day=null); await _loadFirst(); }),
          ],)),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.separated(
                    controller: _scroll,
                    itemCount: _items.length + 1,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      if (i == _items.length) {
                        if (_loadingMore) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                        if (!_hasMore) return const Padding(padding: EdgeInsets.all(16), child: Center(child: Text('没有更多了')));
                        return const SizedBox(height: 56);
                      }
                      final e = _items[i];
                      return ListTile(
                        title: Text(e.preview, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(_fmt.format(DateTime.fromMillisecondsSinceEpoch(e.entryTime))),
                        onTap: () => _openEntry(e),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
