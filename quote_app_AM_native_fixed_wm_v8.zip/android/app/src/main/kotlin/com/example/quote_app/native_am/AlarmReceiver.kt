package com.example.quote_app.native_am

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val svc = Intent(context, TaskService::class.java).apply {
            putExtras(intent.extras ?: return)
        }
        ContextCompat.startForegroundService(context, svc)
    }
}
