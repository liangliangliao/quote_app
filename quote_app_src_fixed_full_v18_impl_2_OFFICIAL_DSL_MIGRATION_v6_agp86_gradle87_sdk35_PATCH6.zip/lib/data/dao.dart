import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';

String _uid(String prefix) {
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  return '$prefix-$ts-${r.nextInt(1<<32)}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    return rows.isEmpty ? {} : rows.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint, String backgroundImage = ''}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    final data = {
      'api_key': apiKey,
      'model': model,
      'endpoint': endpoint,
      'background_image': backgroundImage,
    };
    if (rows.isEmpty) {
      await db.insert('configs', data);
    } else {
      await db.update('configs', data, where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }
}

class TaskDao {
  /// Compute the next run time (epoch ms) based on the base time's hour/minute and the frequency.
  static int computeNextRunAt(DateTime now, DateTime base, String freqType, int? freqWeekday, int? freqDayOfMonth) {
    final timeToday = DateTime(now.year, now.month, now.day, base.hour, base.minute);
    DateTime next;
    if (freqType == 'weekly') {
      final wd = (freqWeekday ?? 1).clamp(1, 7);
      int delta = (wd - now.weekday) % 7;
      next = DateTime(now.year, now.month, now.day, base.hour, base.minute).add(Duration(days: delta));
      if (!next.isAfter(now)) next = next.add(const Duration(days: 7));
    } else if (freqType == 'monthly') {
      final d = (freqDayOfMonth ?? 1).clamp(1, 31);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      next = DateTime(y, m, d.clamp(1, end), base.hour, base.minute);
      if (!next.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        next = DateTime(y, m, d.clamp(1, end), base.hour, base.minute);
      }
    } else {
      // daily/custom => treat as daily at the chosen time
      next = timeToday.isAfter(now) ? timeToday : timeToday.add(const Duration(days: 1));
    }
    return next.millisecondsSinceEpoch;
  }

  Future<String> create({
    required String name,
    required String type,
    required DateTime startTime,
    String prompt = '',
    String avatarPath = '',
    String status = 'open',
    String freqType = 'daily',
    int? freqWeekday,
    int? freqDayOfMonth,
    String freqCustom = '',
  }) async {
    return await insert(
      name: name,
      type: type,
      startTime: startTime,
      prompt: prompt,
      avatarPath: avatarPath,
      status: status,
      freqType: freqType,
      freqWeekday: freqWeekday,
      freqDayOfMonth: freqDayOfMonth,
      freqCustom: freqCustom,
    );
  }

  Future<String> insert({
    required String name,
    required String type,
    required DateTime startTime,
    String prompt = '',
    String avatarPath = '',
    String status = 'open',
    String freqType = 'daily',
    int? freqWeekday,
    int? freqDayOfMonth,
    String freqCustom = '',
  }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    final now = DateTime.now();
    final nextRun = TaskDao.computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'start_time': '${startTime.year.toString().padLeft(4,'0')}-${startTime.month.toString().padLeft(2,'0')}-${startTime.day.toString().padLeft(2,'0')} ${startTime.hour.toString().padLeft(2,'0')}:${startTime.minute.toString().padLeft(2,'0')}',
      'prompt': prompt,
      'avatar_path': avatarPath,
      'status': status,
      'freq_type': freqType,
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': freqCustom,
      'next_run_at': nextRun,
    });
    return uid;
  }

  Future<void> update({
    required String taskUid,
    String? name,
    String? type,
    DateTime? startTime,
    String? prompt,
    String? avatarPath,
    String? status,
    String? freqType,
    int? freqWeekday,
    int? freqDayOfMonth,
    String? freqCustom,
  }) async {
    final db = await AppDatabase.instance();
    final data = <String, Object?>{};
    if (name != null) data['name'] = name;
    if (type != null) data['type'] = type;
    if (startTime != null) {
      data['start_time'] = '${startTime.year.toString().padLeft(4,'0')}-${startTime.month.toString().padLeft(2,'0')}-${startTime.day.toString().padLeft(2,'0')} ${startTime.hour.toString().padLeft(2,'0')}:${startTime.minute.toString().padLeft(2,'0')}';
    }
    if (prompt != null) data['prompt'] = prompt;
    if (avatarPath != null) data['avatar_path'] = avatarPath;
    if (status != null) data['status'] = status;
    if (freqType != null) data['freq_type'] = freqType;
    if (freqWeekday != null) data['freq_weekday'] = freqWeekday;
    if (freqDayOfMonth != null) data['freq_day_of_month'] = freqDayOfMonth;
    if (freqCustom != null) data['freq_custom'] = freqCustom;

    if (data.isNotEmpty) {
      await db.update('tasks', data, where: 'task_uid=?', whereArgs: [taskUid]);
    }

    // recompute next_run_at if any of the scheduling fields changed
    if (startTime != null || freqType != null || freqWeekday != null || freqDayOfMonth != null) {
      final row = await byUid(taskUid);
      if (row != null) {
        final s = (row['start_time'] as String);
        DateTime base;
        try { base = DateTime.parse(s.replaceFirst(' ', 'T')); } catch (_) {
          base = DateTime.now();
        }
        final nextRun = TaskDao.computeNextRunAt(DateTime.now(), base, (row['freq_type'] ?? 'daily') as String, row['freq_weekday'] as int?, row['freq_day_of_month'] as int?);
        await db.update('tasks', {'next_run_at': nextRun}, where: 'task_uid=?', whereArgs: [taskUid]);
      }
    }
  }

  Future<void> delete(String taskUid) async {
    final db = await AppDatabase.instance();
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [taskUid]);
  }

  Future<List<Map<String,dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return await db.query('tasks', orderBy: 'id DESC');
  }

  Future<Map<String,dynamic>?> byUid(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [taskUid], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }
}

class QuoteDao {
  Future<bool> existsSimilar(String content, {double threshold = 0.9}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content']);
    for (final r in rows) {
      final c = (r['content'] ?? '') as String;
      if (c.trim().isEmpty) continue;
      final sim = jaroWinkler(content, c);
      if (sim >= threshold) return true;
    }
    return false;
  }

  Future<String?> insertIfUnique({required String taskUid, required String type, required String taskName, required String avatarPath, required String content}) async {
    if (await existsSimilar(content)) return null;
    final db = await AppDatabase.instance();
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'content': content,
      'type': type,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    return uid;
  }

  Future<String?> latestOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }

  Future<String?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }

  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return false;
    final id = rows.first['id'] as int;
    await db.update('quotes', {'content': content, 'notified': 0, 'created_at': DateTime.now().millisecondsSinceEpoch}, where: 'id=?', whereArgs: [id]);
    return true;
  }

  Future<String?> contentForTask(String taskUid) async {
    return await latestForTask(taskUid);
  }

  Future<void> markNewestNotifiedForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return;
    final id = rows.first['id'] as int;
    await db.update('quotes', {'notified': 1}, where: 'id=?', whereArgs: [id]);
  }

  Future<void> markNotifiedByUid(String quoteUid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
  }


  Future<List<Map<String, dynamic>>> latest({int limit = 50, int offset = 0, String? q}) async {
    final db = await AppDatabase.instance();
    String where = '';
    List<Object?> args = [];
    if (q != null && q.trim().isNotEmpty) {
      where = 'content LIKE ?';
      args = ['%$q%'];
    }
    return await db.query('quotes', where: where.isEmpty ? null : where, whereArgs: where.isEmpty ? null : args, orderBy: 'id DESC', limit: limit, offset: offset);
  }

  /// Very simple carousel: pick the oldest quote for this task.
  Future<String?> nextCarouselContent(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }
}


class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {
      'log_uid': _uid('log'),
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, dynamic>>> latest({int limit = 50, int offset = 0}) async {
    final db = await AppDatabase.instance();
    return await db.rawQuery('''
      SELECT l.*, t.name AS task_name, t.start_time AS task_start_time
      FROM logs l LEFT JOIN tasks t ON l.task_uid = t.task_uid
      ORDER BY l.id DESC
      LIMIT ? OFFSET ?
    ''', [limit, offset]);
  }
}
) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {
      'log_uid': _uid('log'),
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, dynamic>>> latest({int limit = 50, int offset = 0}) async {
    final db = await AppDatabase.instance();
    return await db.query('logs', orderBy: 'id DESC', limit: limit, offset: offset);
  }
}