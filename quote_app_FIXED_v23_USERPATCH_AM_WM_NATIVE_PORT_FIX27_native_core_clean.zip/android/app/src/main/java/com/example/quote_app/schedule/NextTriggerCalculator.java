package com.example.quote_app.schedule;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.example.quote_app.data.DbInspector;

import java.util.Calendar;
import java.util.Set;

public final class NextTriggerCalculator {
    private static String pick(Set<String> cols, String... candidates) {
        for (String c : candidates) { if (c == null) continue; if (cols.contains(c)) return c; }
        return candidates[0];
    }

    public static long compute(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.dbPath) || TextUtils.isEmpty(cc.tasksSource)) return -1L;
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY);
            Set<String> cols = DbInspector.listColumns(db, cc.tasksSource);
            String uidCol = pick(cols, cc.taskColMap.get("uid"), "uid","task_uid","id");
            String whenCol = pick(cols, cc.taskColMap.get("trigger_at"), "trigger_at","fire_at","scheduled_at","when","time","ts");
            String nextCol = pick(cols, "next_time","next_run","next");
            long now = System.currentTimeMillis();
            long next = -1L;
            String sql = "SELECT " + whenCol + "," + nextCol + " FROM " + cc.tasksSource + " WHERE " + uidCol + "=? LIMIT 1";
            try (Cursor c = db.rawQuery(sql, new String[]{uid})) {
                if (c.moveToFirst()) {
                    if (!c.isNull(1)) next = c.getLong(1);
                    else if (!c.isNull(0)) next = c.getLong(0);
                }
            }
            if (next <= now) {
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(now);
                cal.add(Calendar.DAY_OF_YEAR, 1);
                next = cal.getTimeInMillis();
            }
            return next;
        } catch (Throwable ignored) {
            return -1L;
        } finally {
            if (db != null) try { db.close(); } catch (Throwable ignored) {}
        }
    }
}
