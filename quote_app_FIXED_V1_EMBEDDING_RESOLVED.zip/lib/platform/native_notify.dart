import 'package:flutter/services.dart';

class NativeNotify {
  static const _ch = MethodChannel('com.example.quote_app/notify');

  static Future<bool> show({
    required int id,
    required String title,
    required String body,
    String? largeIconPath,
  }) async {
    try {
      final ok = await _ch.invokeMethod<bool>('notify', {
        'id': id,
        'title': title,
        'body': body,
        'largeIconPath': largeIconPath,
      });
      return ok ?? true;
    } on PlatformException {
      // Fallback: let caller handle or keep old Dart path
      return false;
    }
  }
}