package com.example.quote_app

import android.os.Bundle
import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 仅注册通道；不引入业务逻辑，避免后续维护成本
        Channels.register(flutterEngine, applicationContext) // Context 在前，Engine 在后
        // 注册系统级通道，用于通知点击事件桥接。
        SysChannels.register(flutterEngine, applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent?.let { maybeHandleNotificationIntent(it) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        maybeHandleNotificationIntent(intent)
    }

    private fun maybeHandleNotificationIntent(intent: Intent) {
        if (intent.getBooleanExtra("from_notification", false)) {
            // 1. 标记 flag，给冷启动 / 兜底用
            LaunchFlags.markNotificationTapped()
            // 2. 如果此时 Flutter 已经在跑，则直接推事件给 Dart
            SysChannels.emitNotificationTap()
        }
    }
}
