package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * 系统级通道：负责把“从通知点击进来”的信息暴露给 Flutter。
 * 模式参考 Firebase 的 getInitialMessage + onMessageOpenedApp，
 * 一次性读取 + 事件通知，不做轮询。
 */
object SysChannels {
  @Volatile
  private var channel: MethodChannel? = null

  private const val SYS_CH = "com.example.quote_app/sys"

  fun register(engine: FlutterEngine, appCtx: Context) {
    // 这里只是保存一个可复用的 MethodChannel 用于 native → Dart 的事件推送。
    // 真正的 MethodCallHandler 仍然由 Channels.kt 中的 sys 通道负责。
    channel = MethodChannel(engine.dartExecutor.binaryMessenger, SYS_CH)
  }

  /** 给 Dart 主动推一个 “点击通知” 事件（app 已经在内存时用） */
  fun emitNotificationTap() {
    try {
      channel?.invokeMethod("onNotificationTap", null)
    } catch (_: Throwable) {
      // 如果 Flutter 端还没就绪，吞掉异常即可，冷启动会通过 flag 兜底。
    }
  }
}
