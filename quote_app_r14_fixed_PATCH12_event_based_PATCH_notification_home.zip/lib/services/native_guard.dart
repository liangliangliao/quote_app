import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/services.dart';

// Pages
import '../pages/home_page.dart';

/// Native capability guard (kept minimal and backwards-compatible)
class NativeGuard {
  static const _ch = MethodChannel('com.example.quote_app/sys');

static Future<bool> isNativeAM() async {
  // Some pages call this legacy probe; keep it as an alias/fallback.
  try {
    final ok = await _ch.invokeMethod('isNativeAmEnabled');
    return ok == true;
  } catch (_) {
    // Fallback to WM probe if the native side doesn't implement AM.
    try {
      return await isNativeWM();
    } catch (_) {
      return false;
    }
  }
}


  static Future<bool> isNativeWM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeWmEnabled');
      return ok == true;
    } catch (_) {
      return false;
    }
  }
}

/// App-wide simple event bus & navigation utilities.
/// Many pages rely on these static members; keep names unchanged.
class SimpleBus {
  // Global navigator for out-of-context navigation (e.g., from notification callbacks)
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  // Bottom nav index (if used by the app)
  static final ValueNotifier<int> navIndex = ValueNotifier<int>(0);

  // Page refresh ticks
  static final ValueNotifier<int> homeTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> logsTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> settingsTick = ValueNotifier<int>(0);

  static bool _inited = false;
  static const MethodChannel _sys = MethodChannel('com.example.quote_app/sys');

  /// Initialize simple bus & native notification tap bridge.
  static void init() {
    if (_inited) return;
    _inited = true;

    // 1) App 在内存：监听原生推送上来的 "onNotificationTap" 事件
    _sys.setMethodCallHandler((call) async {
      if (call.method == 'onNotificationTap') {
        _handleNotificationTap();
      }
      return;
    });

    // 2) 冷启动：初始化完成后异步检查一次 flag
    scheduleMicrotask(() async {
      try {
        final v = await _sys.invokeMethod<bool>('consumeLaunchFromNotificationFlag');
        if (v == true) {
          _handleNotificationTap();
        }
      } catch (_) {
        // ignore – best-effort only
      }
    });
  }

  /// 内部统一处理“从通知点击进入”的导航逻辑：清空栈并回到首页。
  static void _handleNotificationTap() {
    final nav = navigatorKey.currentState;
    if (nav == null) return;

    nav.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomePage()),
      (route) => false,
    );

    // Align bottom nav & trigger refresh if the app uses these
    try { navIndex.value = 0; } catch (_) {}
    try { pokeHome(); } catch (_) {}
  }

  /// Navigate to Home by replacing the whole stack.
  static void navHome() {
    _handleNotificationTap();
  }

  /// Notify home to refresh
  static void pokeHome() { homeTick.value = homeTick.value + 1; }

  /// Notify logs page to refresh
  static void pokeLogs() { logsTick.value = logsTick.value + 1; }

  /// Notify settings page to refresh
  static void pokeSettings() { settingsTick.value = settingsTick.value + 1; }
}

