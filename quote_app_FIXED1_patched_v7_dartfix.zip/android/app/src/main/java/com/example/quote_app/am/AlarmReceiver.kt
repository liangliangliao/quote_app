package com.example.quote_app.am

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskUid = intent.getStringExtra("task_uid")
        val runKey  = intent.getStringExtra("run_key")
        if (taskUid.isNullOrEmpty() || runKey.isNullOrEmpty()) {
            Log.e("AlarmReceiver","missing task_uid/run_key → fallback")
            Notifier.fallback(context); return
        }

        val pending = goAsync()
        Thread {
            try {
                com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] alarm received runKey="+runKey)
                try {
                    val handled = com.example.quote_app.biz.Biz.run(context.applicationContext, taskUid)
                    if (handled) {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] Biz.run handled")
                        pending.finish()
                        return@Thread
                    }
                } catch (t: Throwable) {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] Biz.run failed: "+t.message)
                }

                val dbPath = DbPaths.quotesDbPath(context)
                val exact = SqliteReader.queryExact(dbPath, taskUid, runKey)
                if (exact != null) {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native exact hit for runKey="+runKey)
                    Notifier.notify(context, exact)
                } else {
                    val (from, to) = RunKey.windowBefore(runKey, 30)
                    val near = SqliteReader.queryNearest(dbPath, taskUid, from, to)
                    if (near != null) {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native nearest hit")
                        Notifier.notify(context, near)
                    } else {
                        com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native fallback")
                        Notifier.fallback(context)
                    }
                }
            } catch (t: Throwable) {
                Log.e("AlarmReceiver","read db failed: ${t.message}", t)
                com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] exception: "+t.message)
                Notifier.fallback(context)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
