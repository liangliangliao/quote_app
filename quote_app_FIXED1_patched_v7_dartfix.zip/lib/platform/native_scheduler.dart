import 'dart:convert';
import 'package:flutter/services.dart';

class NativeScheduler {
  static const MethodChannel _ch = MethodChannel('native.scheduler');

  /// 打开系统通知权限弹框（原生侧实现），返回是否已授权
  static Future<bool> requestNotificationPermissionSystem() async {
    try {
      final r = await _ch.invokeMethod('request_notification_permission');
      return r == true;
    } catch (_) {
      return false;
    }
  }

  /// 注册精准闹钟，并把 task_uid / run_key 作为 extras 传给原生侧
  static Future<bool> scheduleExactAt({
    required int id,
    required int epochMs,
    required String taskUid,
    required String runKey,
    Map<String, dynamic>? payload,
  }) async {
    final args = {
      'id': id,
      'epochMs': epochMs,
      'task_uid': taskUid,
      'run_key': runKey,
      'payload': jsonEncode(payload ?? {}),
    };
    final ok = await _ch.invokeMethod<bool>('scheduleExactAt', args);
    return ok ?? false;
  }

  /// 取消精准闹钟
  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
  }
}
