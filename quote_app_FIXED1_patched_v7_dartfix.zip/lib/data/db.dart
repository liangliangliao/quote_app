import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory(); // equals app_flutter/
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 5,
      onCreate: (db, v) async {
        await _migrate(db);
      },
      onUpgrade: (db, ov, nv) async {
        await _migrate(db);
      },
    );
    return _db!;
  }

  static Future<void> _migrate(Database db) async {
    // Core tables
    await db.execute("CREATE TABLE IF NOT EXISTS tasks(uid TEXT PRIMARY KEY, title TEXT, content TEXT, trigger_at INTEGER, enabled INTEGER DEFAULT 1, type TEXT, prompt TEXT, avatar_path TEXT, scheduled_run_key TEXT)");
    await db.execute("CREATE TABLE IF NOT EXISTS quotes(id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT, content TEXT, extra TEXT, notified INTEGER DEFAULT 0, created_at INTEGER)");
    await db.execute("CREATE TABLE IF NOT EXISTS config(endpoint TEXT, api_key TEXT, model TEXT)");
    await db.execute("CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT, message TEXT, created_at INTEGER DEFAULT (strftime('%s','now')))");
    await db.execute("CREATE TABLE IF NOT EXISTS payloads(task_uid TEXT, run_key TEXT, title TEXT, content TEXT, avatar_path TEXT, actions_json TEXT, payload_json TEXT, PRIMARY KEY(task_uid, run_key))");
    // columns existence (idempotent)
    final info = await db.rawQuery("PRAGMA table_info(tasks)");
    final cols = info.map((e)=> (e['name'] as String)).toList();
    Future ensure(String col, String ddl) async {
      if (!cols.contains(col)) { await db.execute(ddl); }
    }
    await ensure('scheduled_run_key', "ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
    // logs extra snapshots（可选字段，向后兼容）
    final infoLogs = await db.rawQuery("PRAGMA table_info(logs)");
    final lcols = infoLogs.map((e)=> (e['name'] as String)).toList();
    if (!lcols.contains('task_name_snapshot')) await db.execute("ALTER TABLE logs ADD COLUMN task_name_snapshot TEXT");
    if (!lcols.contains('task_start_time_snapshot')) await db.execute("ALTER TABLE logs ADD COLUMN task_start_time_snapshot TEXT");
  }
}
