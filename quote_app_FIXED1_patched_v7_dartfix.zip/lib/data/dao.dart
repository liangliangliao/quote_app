import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
  final rnd = r.nextInt(1<<32).toRadixString(36);
  return '${prefix}_${ts}_${rnd}';
}

class ConfigDao {
  Future<Map<String, dynamic>?> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('config', limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }
}

class TaskDao {
  Future<Map<String, dynamic>?> getByUid(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'uid=?', whereArgs: [uid], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> upsertScheduledRunKey(String uid, String runKey) async {
    final db = await AppDatabase.instance();
    try {
      await db.update('tasks', {'scheduled_run_key': runKey}, where: 'uid=?', whereArgs: [uid]);
    } catch (_) {
      await db.execute("ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
      await db.update('tasks', {'scheduled_run_key': runKey}, where: 'uid=?', whereArgs: [uid]);
    }
  }
}

class QuoteDao {
  Future<void> markNotifiedByUid(String uid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'task_uid=?', whereArgs: [uid]);
  }
}

class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {'task_uid': taskUid, 'message': detail, 'created_at': DateTime.now().millisecondsSinceEpoch ~/ 1000});
  }
}

class PayloadDao {
  Future<void> upsert({required String taskUid, required String runKey, String? title, String? content, String? avatarPath, String? actionsJson, String? payloadJson}) async {
    final db = await AppDatabase.instance();
    final values = {
      'task_uid': taskUid,
      'run_key': runKey,
      'title': title,
      'content': content,
      'avatar_path': avatarPath,
      'actions_json': actionsJson,
      'payload_json': payloadJson,
    };
    await db.insert('payloads', values, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
