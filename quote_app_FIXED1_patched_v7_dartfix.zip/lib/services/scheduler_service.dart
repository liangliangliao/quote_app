import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../data/db.dart';
import '../platform/native_scheduler.dart';

class SchedulerService {
  static Future<void> init() async {}

  static String _runKeyFromEpoch(int epochMs) {
    final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
    return DateFormat('yyyyMMdd_HHmmss_SSS').format(dt);
    }

  /// 根据任务一条记录注册精准闹钟，并将业务文案预绑定到 payloads(task_uid, run_key)
  static Future<void> registerOne(Map<String, dynamic> task) async {
    final uid = (task['uid'] ?? task['task_uid']).toString();
    if (uid.isEmpty) return;

    // 计算下一次触发时间（简化版：直接使用 trigger_at）
    final epoch = (task['trigger_at'] is int) ? task['trigger_at'] as int : DateTime.now().millisecondsSinceEpoch + 60000;
    final runKey = _runKeyFromEpoch(epoch);

    // 预绑定业务文案（如果已有 title/content 就用；否则给兜底）
    final title = (task['title'] ?? '提醒').toString();
    final content = (task['content'] ?? '该做正事啦').toString();
    await PayloadDao().upsert(taskUid: uid, runKey: runKey, title: title, content: content, avatarPath: task['avatar_path']?.toString());

    // 更新 scheduled_run_key，便于原生“就近命中”策略
    await TaskDao().upsertScheduledRunKey(uid, runKey);

    // 下发到原生精准闹钟
    final ok = await NativeScheduler.scheduleExactAt(
      id: uid.hashCode,
      epochMs: epoch,
      taskUid: uid,
      runKey: runKey,
      payload: {'task_uid': uid, 'run_key': runKey},
    );
    await DLog.i('SCH', 'schedule exact uid=$uid run=$runKey ok=$ok');
  }
}
