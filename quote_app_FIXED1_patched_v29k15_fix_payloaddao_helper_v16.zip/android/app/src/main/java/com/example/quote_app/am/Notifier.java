package com.example.quote_app.am;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public final class Notifier {
    private static final String CHANNEL_ID = "quote_channel";

    private static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager mgr = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Quote Reminders", NotificationManager.IMPORTANCE_DEFAULT);
                mgr.createNotificationChannel(ch);
            }
        }
    }

    public static void notify(Context ctx, SqliteReader.Payload p) {
        ensureChannel(ctx);
        NotificationCompat.Builder n = new NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(p.getTitle() != null ? p.getTitle() : "提醒")
            .setContentText(p.getContent() != null ? p.getContent() : "该做正事啦")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(p.getContent() != null ? p.getContent() : "该做正事啦"))
            .setAutoCancel(true);
        NotificationManagerCompat.from(ctx).notify((int)(System.currentTimeMillis()%100000), n.build());
    }

    public static void fallback(Context ctx) {
        notify(ctx, new SqliteReader.Payload("提醒","该做正事啦", null, null, null));
    }
}
