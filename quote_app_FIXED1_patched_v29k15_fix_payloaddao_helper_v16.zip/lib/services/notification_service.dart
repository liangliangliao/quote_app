import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const init = InitializationSettings(android: androidInit);
    await _plugin.initialize(init);

    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      const AndroidNotificationChannel channel = AndroidNotificationChannel(
        'quote_high', '定时提醒',
        description: 'Quote 定时提醒',
        importance: Importance.high,
        playSound: true,
      );
      await android.createNotificationChannel(channel);
    }
  }

  static Future<void> request() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      await android.requestNotificationsPermission();
    }
  }

  static Future<bool> isEnabled() async {
    if (!Platform.isAndroid) return true;
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return true;
    return await android.areNotificationsEnabled() ?? true;
  }

  static Future<void> showSimple(String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'quote_high', '定时提醒',
        importance: Importance.high, priority: Priority.high,
      ),
    );
    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    await _plugin.show(id, title, body, details);
  }

  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'quote_high', '定时提醒',
      channelDescription: 'Quote 定时提醒',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? BigPictureStyleInformation(
              FilePathAndroidBitmap(largeIconPath),
              largeIcon: FilePathAndroidBitmap(largeIconPath),
              contentTitle: title,
              summaryText: body,
            )
          : const DefaultStyleInformation(true, true),
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails);
    final nid = id ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000);
    await _plugin.show(nid, title, body, details);
  }

}
