import 'dart:convert';
import 'package:flutter/services.dart';

class NativeScheduler {
  static const MethodChannel _ch = MethodChannel('native.scheduler');

  static Future<bool> requestNotificationPermissionSystem() async {
    try {
      final r = await _ch.invokeMethod('request_notification_permission');
      return r == true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> scheduleExactAt({
    required int id,
    required int epochMs,
    required String taskUid,
    required String runKey,
    Map<String, dynamic>? payload,
  }) async {
    final args = {
      'id': id,
      'epochMs': epochMs,
      'task_uid': taskUid,
      'run_key': runKey,
      'payload': jsonEncode(payload ?? {}),
    };
    try {
      final ok = await _ch.invokeMethod<bool>('scheduleExactAt', args);
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
  }
}
