
import '../utils/debug_logger.dart';
import '../data/notify_dao.dart';
import '../services/scheduler_service.dart';

class SelfCheckService {
  /// 手动触发自检：扫描当天失败并补发（注册正常 wm 立刻执行）。
  static Future<void> run() async {
    await PatchMigration20251001.ensure();
    await DLog.i('SELF', '开始每日自检：扫描当天失败记录');
    final list = await NotifyFailureDao.failuresToday();
    if (list.isEmpty) {
      await DLog.i('SELF', '当天无失败记录');
      return;
    }
    // 去重 (task_uid + run_key)
    final seen = <String>{};
    var count = 0;
    for (final row in list) {
      final uid = (row['task_uid'] ?? '').toString();
      final rk  = (row['run_key'] ?? '').toString();
      if (uid.isEmpty || rk.isEmpty) continue;
      final key = uid + '::' + rk;
      if (seen.contains(key)) continue;
      seen.add(key);
      try {
        await DLog.i('SELF', '补发 uid='+uid+' run='+rk);
        // 直接执行一次（相当于立即正常 WM）
        await SchedulerService.wmRunTask(uid, rk, chan: 'manual', attempt: 1);
        count++;
      } catch (e) {
        await DLog.e('SELF', '补发失败 uid='+uid+' run='+rk+' err='+e.toString());
      }
    }
    await DLog.i('SELF', '自检完成，本次补发数='+count.toString());
  }
}
