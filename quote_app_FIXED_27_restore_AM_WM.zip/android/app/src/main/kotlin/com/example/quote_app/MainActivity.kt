package com.example.quote_app

import android.os.Build
import android.provider.Settings
import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import androidx.work.Data

class MainActivity: FlutterActivity() {
  private val CHANNEL = "quote/native_scheduler"

  override fun configureFlutterEngine(engine: FlutterEngine) {
    super.configureFlutterEngine(engine)

    MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
      when (call.method) {
        "ensureChannel" -> {
          NativeSchedulerK.ensureChannel(this)
          result.success(true)
        }
        "hasExactAlarmPermission" -> {
          result.success(NativeSchedulerK.canScheduleExact(this))
        }
        "requestExactAlarmPermission" -> {
          if (Build.VERSION.SDK_INT >= 31) {
            val uri = Uri.parse("package:$packageName")
            val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, uri)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
          }
          result.success(true)
        }
        "scheduleAfter" -> {
          val id = call.argument<Int>("id") ?: 0
          val ms = call.argument<Long>("epochMs") ?: 0L
          val payload = call.argument<String>("payload") ?: "{}"
          val ok = NativeSchedulerK.scheduleAfter(this, id, ms, payload)
          result.success(ok)
        }
        "scheduleFallback" -> {
          val unique = call.argument<String>("unique") ?: ""
          val delayMs = call.argument<Long>("delayMs") ?: 0L
          val payload = call.argument<String>("payload") ?: "{}"
          val data = Data.Builder()
            .putInt("id", (System.currentTimeMillis() % 1_000_000_000).toInt())
            .putString("payload", payload)
            .putString("job", "wm_fallback")
            .build()
          val ok = NativeSchedulerK.scheduleFallback(this, unique, data, delayMs)
          result.success(ok)
        }
        "cancelFallback" -> {
          val unique = call.argument<String>("unique") ?: ""
          NativeSchedulerK.cancelFallbackByUnique(this, unique)
          result.success(true)
        }
        else -> result.notImplemented()
      }
    }
  }
}
