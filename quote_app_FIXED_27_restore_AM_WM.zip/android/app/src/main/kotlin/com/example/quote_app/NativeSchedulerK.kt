package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

object NativeSchedulerK {
  private const val CHANNEL_ID = "quote_notify"

  fun ensureChannel(ctx: Context) {
    val mgr = NotificationManagerCompat.from(ctx)
    val has = mgr.notificationChannelsCompat.any { it.id == CHANNEL_ID }
    if (!has) {
      val ch = NotificationChannelCompat.Builder(
        CHANNEL_ID,
        NotificationManagerCompat.IMPORTANCE_HIGH
      ).setName("提醒")
       .setDescription("名人名言提醒")
       .build()
      mgr.createNotificationChannel(ch)
    }
  }

  fun canScheduleExact(ctx: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= 31) {
      (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    } else true
  }

  fun scheduleAfter(ctx: Context, id: Int, triggerAtMillis: Long, payloadJson: String): Boolean {
    ensureChannel(ctx)
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(ctx, AlarmReceiver::class.java).apply {
      action = "ALARM_FIRE"
      putExtra("id", id)
      putExtra("payload", payloadJson)
    }
    val pi = PendingIntent.getBroadcast(
      ctx, id, intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    return try {
      if (Build.VERSION.SDK_INT >= 23) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
      }
      true
    } catch (_: Exception) { false }
  }

  fun scheduleFallback(ctx: Context, unique: String, data: Data, delayMs: Long): Boolean {
    ensureChannel(ctx)
    val req = OneTimeWorkRequestBuilder<NotifyWorker>()
      .setInitialDelay(delayMs, java.util.concurrent.TimeUnit.MILLISECONDS)
      .setBackoffCriteria(BackoffPolicy.LINEAR, 5, java.util.concurrent.TimeUnit.MINUTES)
      .setInputData(data)
      .addTag(unique)
      .build()
    return try {
      WorkManager.getInstance(ctx).enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
      true
    } catch (_: Exception) { false }
  }

  fun cancelFallbackByUnique(ctx: Context, unique: String) {
    try { WorkManager.getInstance(ctx).cancelUniqueWork(unique) } catch (_: Exception) {}
  }
}
