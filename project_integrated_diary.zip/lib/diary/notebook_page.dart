import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'diary_dao.dart';
import 'entry_editor_page.dart';
import 'entry_reader_page.dart';

class NotebookPage extends StatefulWidget {
  final Notebook notebook;
  const NotebookPage({super.key, required this.notebook});

  @override
  State<NotebookPage> createState() => _NotebookPageState();
}

class _NotebookPageState extends State<NotebookPage> {
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy-MM-dd HH:mm');
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();

  List<DiaryEntry> _items = [];
  String? _cursor;
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;

  String? _keyword;

  @override
  void initState() {
    super.initState();
    _loadFirst();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200) _loadMore();
    });
  }

  Future<void> _loadFirst() async {
    setState(() { _loading = true; _cursor = null; _hasMore = true; _items = []; });
    final res = await _dao.listEntries(notebookId: widget.notebook.id, limit: 50, cursor: null, keyword: _keyword);
    setState(() {
      _items = res.items;
      _cursor = res.nextCursor;
      _hasMore = res.nextCursor != null;
      _loading = false;
    });
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _loadingMore || _loading) return;
    setState(() => _loadingMore = true);
    final res = await _dao.listEntries(notebookId: widget.notebook.id, limit: 50, cursor: _cursor, keyword: _keyword);
    setState(() {
      _items.addAll(res.items);
      _cursor = res.nextCursor;
      _hasMore = res.nextCursor != null;
      _loadingMore = false;
    });
  }

  Future<void> _newEntry() async {
    final id = await Navigator.push<int?>(context, MaterialPageRoute(builder: (_) => EntryEditorPage(notebookId: widget.notebook.id)));
    if (id != null) _loadFirst();
  }

  void _openEntry(DiaryEntry e) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => EntryReaderPage(notebookId: widget.notebook.id, initialEntryId: e.id)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.notebook.name),
      ),
      floatingActionButton: FloatingActionButton(onPressed: _newEntry, child: const Icon(Icons.create)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索当前日记本…', border: OutlineInputBorder(), isDense: true),
              onSubmitted: (v) { _keyword = v.trim().isEmpty ? null : v.trim(); _loadFirst(); },
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.separated(
                    controller: _scroll,
                    itemCount: _items.length + 1,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      if (i == _items.length) {
                        if (_loadingMore) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                        if (!_hasMore) return const Padding(padding: EdgeInsets.all(16), child: Center(child: Text('没有更多了')));
                        return const SizedBox(height: 56);
                      }
                      final e = _items[i];
                      return ListTile(
                        title: Text(e.preview, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(_fmt.format(DateTime.fromMillisecondsSinceEpoch(e.entryTime))),
                        onTap: () => _openEntry(e),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
