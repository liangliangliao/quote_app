package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread

class GeoForegroundService : Service() {

  private val CHANNEL_ID = "geo_fg_channel"
  private val NOTIF_ID = 7771001

  override fun onBind(intent: Intent?) = null

  override fun onCreate() {
    super.onCreate()
    try { logWithTime(this, "【前台服务-地点规则】onCreate") } catch (_: Throwable) {}
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // 第一时间启动前台
    startForeground(NOTIF_ID, buildOngoingNotification("正在获取位置..."))
    // 记录启动前台服务的日志
    try { logWithTime(this, "【前台服务-地点规则】已调用 startForeground，开始在前台运行") } catch (_: Throwable) {}
    thread(name = "geo-fg-exec") {
      try {
        executeCore()
      } catch (t: Throwable) {
        try { logWithTime(this, "【前台服务-地点规则】执行失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      } finally {
        try {
          // 尽快移除前台通知，避免常驻
          try {
            if (Build.VERSION.SDK_INT >= 24) {
              stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
              @Suppress("DEPRECATION")
              stopForeground(true)
            }
          } catch (_: Throwable) {
            @Suppress("DEPRECATION")
            try { stopForeground(true) } catch (_: Throwable) {}
          }
          stopSelf()
          // 记录销毁前台服务的日志
          try { logWithTime(this, "【前台服务-地点规则】前台服务已停止并销毁") } catch (_: Throwable) {}
        } catch (_: Throwable) {}
      }
    }
    return START_NOT_STICKY
  }

  private fun buildOngoingNotification(text: String): Notification {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val ch = NotificationChannel(CHANNEL_ID, "地点规则检测", NotificationManager.IMPORTANCE_MIN).apply {
        setShowBadge(false)
        enableVibration(false)
        enableLights(false)
        setSound(null, null)
      }
      nm.createNotificationChannel(ch)
    }
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("愿景提醒")
      .setContentText(text)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setSilent(true)
      .setPriority(NotificationCompat.PRIORITY_MIN)
      .setVisibility(NotificationCompat.VISIBILITY_SECRET)
      .build()
  }

  private fun executeCore() {
    val ctx = this

    // 1) 配置开关
    if (!GeoRuleEngine.isGeoEnabled(ctx)) {
      try { logWithTime(ctx, "【前台服务-地点规则】开关=关闭，直接返回") } catch (_: Throwable) {}
      return
    }

    // 2) 读取所有启用地点规则（遍历）
    val targets = GeoRuleEngine.loadTargets(ctx)
    if (targets.isEmpty()) {
      try { logWithTime(ctx, "【前台服务-地点规则】未找到启用的地点规则，返回") } catch (_: Throwable) {}
      return
    }

    // 3) 获取当前位置：系统高精度流 -> 百度SDK -> lastKnown
    var loc: Location? = runCatching { LocationCore.getSystemHighAcc(ctx, 60.0, 6_000L) }.getOrNull()
    if (loc != null) {
      try { logWithTime(ctx, "【前台服务-地点规则】系统高精度流定位成功 acc=${loc.accuracy}") } catch (_: Throwable) {}
    }

    if (loc == null) {
      val ak = getBaiduAk(ctx)
      loc = runCatching { obtainBaiduLocation(ctx, ak, 60.0, 8_000L) }.getOrNull()
      if (loc != null) {
        try { logWithTime(ctx, "【前台服务-地点规则】百度SDK定位成功 acc=${loc.accuracy}") } catch (_: Throwable) {}
      }
    }

    if (loc == null) {
      loc = LocationCore.getLastKnown(ctx)
      if (loc != null) {
        try { logWithTime(ctx, "【前台服务-地点规则】使用最近已知位置 acc=${loc.accuracy}") } catch (_: Throwable) {}
      }
    }

    if (loc == null) {
      try { logWithTime(ctx, "【前台服务-地点规则】无法获取位置，返回") } catch (_: Throwable) {}
      return
    }

    // 4) 遍历比对并通知（只要命中任意一个目标就发送一次）
    GeoRuleEngine.evaluateAndNotify(ctx, loc, targets, radiusMeters = 100.0)
  }

  /**
   * 写入包含时间戳的日志。所有地点规则前台服务的日志都通过此方法统一前缀当前时间，
   * 便于调试和排查问题。
   */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      // fallback to original log without timestamp
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun getBaiduAk(ctx: Context): String {
    val defAndroid = "oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh"
    val defWeb = "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return defAndroid
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try {
        var v: String? = null
        try {
          db.rawQuery("SELECT baidu_ak_android FROM configs LIMIT 1", null).use { c ->
            if (c.moveToFirst()) v = c.getString(0)
          }
        } catch (_: Throwable) {}

        if (v == null || v!!.trim().isEmpty()) {
          // 兼容旧列：仅当旧列不是默认 Web AK 才沿用
          var oldV: String? = null
          try {
            db.rawQuery("SELECT baidu_ak FROM configs LIMIT 1", null).use { c ->
              if (c.moveToFirst()) oldV = c.getString(0)
            }
          } catch (_: Throwable) {}
          if (oldV != null) {
            val vv = oldV!!.trim()
            if (vv.isNotEmpty() && vv != defWeb) v = vv
          }
        }

        val out = v?.trim() ?: ""
        if (out.isEmpty()) defAndroid else out
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { defAndroid }
  }

  // obtainBaiduLocation 仍保留作为兜底：通过反射调用百度定位（若依赖不可用将直接返回 null）

  // 通过反射调用百度定位（若依赖不可用将直接返回 null）
  private fun obtainBaiduLocation(ctx: Context, ak: String, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val clientClazz = Class.forName("com.baidu.location.LocationClient")
      val optionsClazz = Class.forName("com.baidu.location.LocationClientOption")
      val listenerIfc = Class.forName("com.baidu.location.BDAbstractLocationListener")
      val bdLocClazz = Class.forName("com.baidu.location.BDLocation")

      val client = clientClazz.getConstructor(Context::class.java).newInstance(ctx)
      val opts = optionsClazz.getDeclaredConstructor().newInstance()

      optionsClazz.getMethod("setOpenGps", Boolean::class.java).invoke(opts, true)
      try { optionsClazz.getMethod("setScanSpan", Int::class.java).invoke(opts, 0) } catch (_: Throwable) {}
      try { optionsClazz.getMethod("setIsNeedAddress", Boolean::class.java).invoke(opts, false) } catch (_: Throwable) {}

      clientClazz.getMethod("setLocOption", optionsClazz).invoke(client, opts)

      val holder = arrayOfNulls<Any>(1)
      val handler = java.lang.reflect.Proxy.newProxyInstance(
        listenerIfc.classLoader, arrayOf(listenerIfc)
      ) { _, method, args ->
        if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
          holder[0] = args[0]
        }
        null
      }
      clientClazz.getMethod("registerLocationListener", listenerIfc).invoke(client, handler)
      clientClazz.getMethod("start").invoke(client)

      val start = System.currentTimeMillis()
      while (System.currentTimeMillis() - start < timeoutMs) {
        val cur = holder[0]
        if (cur != null) {
          val acc = (bdLocClazz.getMethod("getRadius").invoke(cur) as? Float) ?: 9999f
          val lat = bdLocClazz.getMethod("getLatitude").invoke(cur) as? Double
          val lng = bdLocClazz.getMethod("getLongitude").invoke(cur) as? Double
          if (lat != null && lng != null && acc <= targetAccMeters) {
            val l = Location("baidu")
            l.latitude = lat
            l.longitude = lng
            l.accuracy = acc
            try { clientClazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
            return l
          }
        }
        Thread.sleep(300)
      }
      try { clientClazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
      null
    } catch (_: Throwable) {
      null
    }
  }

}
