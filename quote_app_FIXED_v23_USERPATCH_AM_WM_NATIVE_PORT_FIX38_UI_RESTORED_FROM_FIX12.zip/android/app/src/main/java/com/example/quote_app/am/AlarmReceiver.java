package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import androidx.work.WorkManager;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

import org.json.JSONObject;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int id = intent != null ? intent.getIntExtra("id", 0) : 0;
        String payload = intent != null ? intent.getStringExtra("payload") : "{}";
        String uid = null;
        String runKey = "";

        try {
            JSONObject obj = new JSONObject(payload == null ? "{}" : payload);
            uid = obj.optString("uid", null);
            runKey = obj.optString("runKey", "");
        } catch (Throwable ignore) {}

        if (TextUtils.isEmpty(uid)) {
            // 兜底：没有 uid 仍然发一个到点提醒
            String title = "提醒";
            String body = "到点了";
            try { NotifyHelper.send(context.getApplicationContext(), id, title, body, null); } catch (Throwable ignore) {}
            return;
        }

        final Context app = context.getApplicationContext();
        boolean entered = false;
        try {
            entered = DbRepository.runGuardBegin(app, uid, runKey, "am");
            if (!entered) return;

            boolean handled = Biz.run(app, uid);
            if (handled) {
                DbRepository.markLatestSuccess(app, uid);
                long next = NextTriggerCalculator.compute(app, uid);
                if (next > 0) {
                    NativeSchedulerK.scheduleExactWmCompat(app, id, next, payload);
                }
                try { WorkManager.getInstance(app).cancelUniqueWork("wm_once_" + id); } catch (Throwable ignore) {}
            } else {
                DbRepository.log(app, uid, "AM通道：业务未处理");
            }
        } catch (Throwable t) {
            DbRepository.log(app, uid, "AM异常: " + (t.getMessage()==null?"未知错误":t.getMessage()));
        } finally {
            try { DbRepository.runGuardEnd(app, uid, runKey, "am"); } catch (Throwable ignore) {}
        }
    }
}
