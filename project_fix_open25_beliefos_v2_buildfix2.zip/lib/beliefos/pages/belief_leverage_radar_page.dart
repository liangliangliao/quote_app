import 'package:flutter/material.dart';
import '../belief_dao.dart';

/// Step 7: 动态窄带雷达
///
/// 用“主干/软层/微行动库”把行动收敛到低摩擦、可重复。
class BeliefLeverageRadarPage extends StatefulWidget {
  final int caseId;
  const BeliefLeverageRadarPage({super.key, required this.caseId});

  @override
  State<BeliefLeverageRadarPage> createState() => _BeliefLeverageRadarPageState();
}

class _BeliefLeverageRadarPageState extends State<BeliefLeverageRadarPage> {
  bool _loading = true;
  final _trunkCtl = TextEditingController();
  final _softCtl = TextEditingController();
  final _microCtl = TextEditingController();

  Future<void> _load() async {
    await BeliefDao().ensureSchema();
    final c = await BeliefDao().getCase(widget.caseId);
    if (!mounted) return;
    _trunkCtl.text = (c?['leverage_trunk']?.toString() ?? '').trim();
    _softCtl.text = (c?['leverage_soft_layer']?.toString() ?? '').trim();
    _microCtl.text = (c?['leverage_micro_actions']?.toString() ?? '').trim();
    setState(() => _loading = false);
  }

  void _insertTemplates() {
    final t = _microCtl.text.trim();
    final add = [
      '• 2分钟：只做“打开文档/写标题/列出3个事实”',
      '• 5分钟：只做“发一条澄清消息/约一个10分钟电话”',
      '• 10分钟：只做“跑一次最小实验/做一次最小验证”',
      '• 如果卡住：先做“停止损耗”动作（睡、吃、收拾桌面）',
    ].join('\n');
    _microCtl.text = (t.isEmpty) ? add : '$t\n$add';
    setState(() {});
  }

  Future<void> _save() async {
    final trunk = _trunkCtl.text.trim();
    final soft = _softCtl.text.trim();
    final micro = _microCtl.text.trim();
    if (trunk.isEmpty || soft.isEmpty || micro.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请填写主干/软层/微行动库')));
      return;
    }
    await BeliefDao().setLeverageRadar(widget.caseId, trunk: trunk, softLayer: soft, microActions: micro);
    await BeliefDao().addLog(widget.caseId, kind: 'leverage', text: '完成动态窄带雷达');
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _trunkCtl.dispose();
    _softCtl.dispose();
    _microCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Step 7  动态窄带雷达')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _card(
            title: '主干（不可或缺、少而重）',
            hint: '例：每天固定30分钟写作/每周一次复盘/每天一次关键沟通…',
            ctl: _trunkCtl,
            lines: 3,
          ),
          const SizedBox(height: 12),
          _card(
            title: '软层（降低摩擦、提高可持续）',
            hint: '例：环境、工具、提醒、同伴、默认选项、降门槛…',
            ctl: _softCtl,
            lines: 4,
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('微行动库（2-10分钟）', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _microCtl,
                    maxLines: 8,
                    decoration: const InputDecoration(
                      hintText: '用项目符号写：\n• 2分钟…\n• 5分钟…',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      OutlinedButton.icon(
                        onPressed: _insertTemplates,
                        icon: const Icon(Icons.auto_awesome_outlined),
                        label: const Text('插入模板'),
                      ),
                      const Spacer(),
                      FilledButton(onPressed: _save, child: const Text('保存并继续')),
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _card({required String title, required String hint, required TextEditingController ctl, required int lines}) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: ctl,
              maxLines: lines,
              decoration: InputDecoration(hintText: hint, border: const OutlineInputBorder()),
            ),
          ],
        ),
      ),
    );
  }
}
