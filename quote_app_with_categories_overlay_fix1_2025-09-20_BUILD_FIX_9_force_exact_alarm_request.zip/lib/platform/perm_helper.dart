import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? false;
    } catch (_) { return false; }
  }

  static Future<bool> hasOverlayPermission() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('hasOverlayPermission');
      return ok ?? false;
    } catch (_) { return false; }
  }

  static Future<void> requestOverlayPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestOverlayPermission');
    } catch (_) {}
  }

  static Future<void> ensureOverlayPermission() async {
    final ok = await hasOverlayPermission();
    if (!ok) {
      await requestOverlayPermission();
    }
  }

  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } catch (_) {}
  }

  static Future<void> ensureExactAlarmPermission() async {
    final ok = await hasExactAlarmPermission();
    if (!ok) {
      await requestExactAlarmPermission();
    }
  

  static Future<bool> hasBatteryOptExemption() async {
    try {
      final ok = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestBatteryOptExemption() async {
    try {
      await _ch.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {}
  }

  static Future<void> ensureBatteryOptExemption() async {
    final ok = await hasBatteryOptExemption();
    if (!ok) {
      await requestBatteryOptExemption();
    }
  }
}
