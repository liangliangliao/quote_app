import 'package:flutter/material.dart';
import 'belief_levels.dart';
import 'belief_dao.dart';
import 'belief_models.dart';
import 'belief_flow_page.dart';
import 'belief_ui.dart';

class BeliefEpisodeListPage extends StatefulWidget {
  final String? filterConceptId;
  const BeliefEpisodeListPage({super.key, this.filterConceptId});

  @override
  State<BeliefEpisodeListPage> createState() => _BeliefEpisodeListPageState();
}

class _BeliefEpisodeListPageState extends State<BeliefEpisodeListPage> {
  final _dao = BeliefDao();

  @override
  Widget build(BuildContext context) {
    final list = widget.filterConceptId == null
        ? beliefEpisodes
        : beliefEpisodes.where((e) => e.conceptId == widget.filterConceptId).toList();

    return Scaffold(
      appBar: AppBar(title: Text(widget.filterConceptId == null ? '重演：案例关卡' : '重演：本概念关卡')),
      body: FutureBuilder(
        future: _dao.listProgressByPrefix('episode:'),
        builder: (context, snap) {
          final progress = snap.data as List<BeliefProgress>? ?? const [];
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (_, i) {
              final ep = list[i];
              final key = 'episode:${ep.id}';
              final p = progress.where((x) => x.key == key).toList();
              final status = p.isEmpty ? 0 : p.first.status;

              String badge = '未开始';
              if (status == 1) badge = '进行中';
              if (status == 2) badge = '已完成';

              return InkWell(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BeliefFlowPage(
                      kind: BeliefFlowKind.episode,
                      id: ep.id,
                      title: ep.title,
                      subtitle: ep.subtitle,
                      steps: ep.steps,
                    ),
                  ),
                ).then((_) => setState(() {})),
                borderRadius: BorderRadius.circular(18),
                child: BeliefSectionCard(
                  title: ep.title,
                  subtitle: '${ep.subtitle}\n状态：$badge',
                  icon: Icons.theaters_outlined,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BeliefFlowPage(
                        kind: BeliefFlowKind.episode,
                        id: ep.id,
                        title: ep.title,
                        subtitle: ep.subtitle,
                        steps: ep.steps,
                      ),
                    ),
                  ).then((_) => setState(() {})),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
