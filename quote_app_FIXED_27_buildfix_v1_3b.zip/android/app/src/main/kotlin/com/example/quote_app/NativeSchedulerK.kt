package com.example.quote_app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.app.NotificationChannel
import android.app.NotificationManager

object NativeSchedulerK {
  private const val CHANNEL_ID = "quote_notify"

  private fun ensureChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val mgr = ctx.getSystemService(NotificationManager::class.java)
      val existing = mgr.getNotificationChannel(CHANNEL_ID)
      if (existing == null) {
        val ch = NotificationChannel(CHANNEL_ID, "Quote Notify", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Notifications for scheduled tasks"
        mgr.createNotificationChannel(ch)
      }
    }
  }

  fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payload: String): Boolean {
    ensureChannel(ctx)
    val am = ctx.getSystemService(AlarmManager::class.java)
    val intent = Intent(ctx, AlarmReceiver::class.java).apply {
      action = "ALARM_FIRE"
      putExtra("id", id)
      putExtra("payload", payload)
    }
    val pi = PendingIntent.getBroadcast(
      ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
      }
      return true
    } catch (_: Exception) {
      return false
    }
  }

  fun cancel(ctx: Context, id: Int) {
    val am = ctx.getSystemService(AlarmManager::class.java)
    val intent = Intent(ctx, AlarmReceiver::class.java).apply { action = "ALARM_FIRE" }
    val pi = PendingIntent.getBroadcast(
      ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
    )
    if (pi != null) {
      am.cancel(pi)
    }
  }

  fun hasExactAlarmPermission(ctx: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val am = ctx.getSystemService(AlarmManager::class.java)
      am.canScheduleExactAlarms()
    } else true
  }

  fun requestExactAlarm(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      ctx.startActivity(intent)
    }
  }
}
