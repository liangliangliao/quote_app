
import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  return '$prefix-$ts-${r.nextInt(1<<32)}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('configs', limit: 1);
    return rows.isEmpty ? {} : rows.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint, String backgroundImage = ''}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint, 'background_image': backgroundImage});
    } else {
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint, 'background_image': backgroundImage},
          where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }
}



class TaskDao {
  int _computeNextRunAt(DateTime now, DateTime base, String freqType, int? freqWeekday, int? freqDayOfMonth) {
    final timeToday = DateTime(now.year, now.month, now.day, base.hour, base.minute);
    DateTime next;
    if (freqType == 'weekly') {
      final wd = (freqWeekday ?? 1).clamp(1,7);
      int delta = (wd - now.weekday) % 7;
      next = DateTime(now.year, now.month, now.day, base.hour, base.minute).add(Duration(days: delta));
      if (!next.isAfter(now)) next = next.add(const Duration(days: 7));
    } else if (freqType == 'monthly') {
      final d = (freqDayOfMonth ?? 1).clamp(1, 31);
      int y = now.year, m = now.month;
      int end = DateTime(y, m+1, 0).day;
      next = DateTime(y, m, d.clamp(1, end), base.hour, base.minute);
      if (!next.isAfter(now)) {
        m += 1
        ;
        end = DateTime(y, m+1, 0).day;
        next = DateTime(y, m, d.clamp(1, end), base.hour, base.minute);
      }
    } else { // daily/custom default daily
      next = timeToday.isAfter(now) ? timeToday : timeToday.add(const Duration(days: 1));
    }
    return next.millisecondsSinceEpoch;
  }

  Future<String> create({required String name, required String type, required DateTime startTime, String prompt='', String avatarPath='', String status='open', String freqType='daily', int? freqWeekday, int? freqDayOfMonth, String freqCustom=''}) async {
    return await insert(name: name, type: type, startTime: startTime, prompt: prompt, avatarPath: avatarPath, status: status, freqType: freqType, freqWeekday: freqWeekday, freqDayOfMonth: freqDayOfMonth, freqCustom: freqCustom);
  }

  Future<List<Map<String, dynamic>>> all() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    return db.query('tasks', orderBy: 'id DESC');
  }

  Future<Map<String, dynamic>?> byUid(String uid) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<String> insert({required String name, required String type, required DateTime startTime, String prompt = '', String avatarPath = '', String status = 'open', String freqType='daily', int? freqWeekday, int? freqDayOfMonth, String freqCustom=''} ) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'start_time': '${startTime.year}-${startTime.month.toString().padLeft(2,'0')}-${startTime.day.toString().padLeft(2,'0')} ${startTime.hour.toString().padLeft(2,'0')}:${startTime.minute.toString().padLeft(2,'0')}',
      'prompt': prompt,
      'avatar_path': avatarPath,
      'status': status,
      'freq_type': freqType,
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': freqCustom,
      'next_run_at': nextRun,
    });
    return uid;
  }

  Future<void> update(String taskUid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [taskUid]);
  }

  Future<void> delete(String taskUid) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [taskUid]);
  }
}

class QuoteDao {
  Future<int> count() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM quotes')) ?? 0;
  }

  Future<List<Map<String,dynamic>>> latest({int limit=100, int offset=0, String? q}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    if (q!=null && q.trim().isNotEmpty) {
      return db.query('quotes', where: 'content LIKE ?', whereArgs: ['%$q%'], orderBy: 'id DESC', limit: limit, offset: offset);
    }
    return db.query('quotes', orderBy: 'id DESC', limit: limit, offset: offset);
  }

  Future<Map<String,dynamic>?> latestOne() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('quotes', orderBy: 'id DESC', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String,dynamic>>> unnotified() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    return db.query('quotes', where: 'notified=0', orderBy: 'created_at ASC');
  }

  Future<void> markNotifiedByUid(String quoteUid) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
  }

  Future<bool> existsSimilar(String content, {double threshold=0.9}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('quotes', columns: ['content']);
    final sNorm = normalizeText(content);
    for (final r in rows) {
      final c = normalizeText((r['content'] ?? '') as String);
      if (c == sNorm) return true;
      final sim = jaroWinkler(sNorm, c);
      if (sim >= threshold) return true;
    }
    return false;
  }

  Future<String?> insertIfUnique({required String taskUid, required String type, required String taskName, required String avatarPath, required String content}) async {
    if (await existsSimilar(content)) return null;
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'content': content,
      'type': type,
      'notified': 0,
      'task_name': taskName,
      'avatar_path': avatarPath,
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
    return uid;
  }
}

class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    await db.insert('logs', {
      'log_uid': _uid('log'),
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
  }

  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    // join with tasks for name and start_time
    return await db.rawQuery('''
      SELECT l.*, t.name as task_name, t.start_time as task_start_time
      FROM logs l LEFT JOIN tasks t ON l.task_uid = t.task_uid
      ORDER BY l.id DESC LIMIT ? OFFSET ?
    ''', [limit, offset]);
  }
}


extension QuoteDaoExtras on QuoteDao {
  Future<String?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }

  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nextRun = _computeNextRunAt(now, startTime, freqType, freqWeekday, freqDayOfMonth);
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return false;
    final id = rows.first['id'] as int;
    await db.update('quotes', {'content': content, 'notified': 0, 'created_at': DateTime.now().millisecondsSinceEpoch}, where: 'id=?', whereArgs: [id]);
    return true;
  }
}

extension QuoteDaoRead on QuoteDao {
  Future<String?> contentForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }
  Future<void> markNewestNotifiedForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return;
    final id = rows.first['id'] as int;
    await db.update('quotes', {'notified': 1}, where: 'id=?', whereArgs: [id]);
  }
  Future<String?> nextCarouselContent(String taskUid) async {
    final db = await AppDatabase.instance();
    // read carousel index from configs meta
    var idxRows = await db.query('configs', limit: 1);
    int nextIndex = 0;
    if (idxRows.isNotEmpty) {
      final row = idxRows.first;
      // Simple global counter per task
    }
    // For simplicity, pick the oldest not-notified first, else fallback to oldest
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC', limit: 1,);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }
}
