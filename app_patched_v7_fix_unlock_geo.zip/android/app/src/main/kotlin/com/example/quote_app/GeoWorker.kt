package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.location.Geocoder
import android.database.sqlite.SQLiteDatabase
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.Locale
import com.example.quote_app.data.DbRepo
import java.util.concurrent.TimeUnit

/**
 * GeoWorker is a periodic WorkManager worker that polls the device's last
 * known location and compares it against any enabled geo vision triggers.
 * When the device is within a 200 meter radius of a configured place,
 * a notification is sent to remind the user of their intention at that
 * location.
 *
 * This implementation uses Android's LocationManager for a quick read
 * of the most recent location and the Geocoder API to resolve place
 * names to coordinates. It deliberately avoids continuous location
 * updates to conserve battery, instead running at a fixed interval.
 */
class GeoWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {
    override fun doWork(): Result {
        val ctx = applicationContext
        try {
            // Obtain last known location from GPS or network provider.  If unavailable
            // (for example when the device has never requested a location or is
            // restricted by battery/region settings), fall back to Baidu's IP
            // geolocation service using the configured API key in notify_config.
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var currentLoc: Location? = null
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (p in providers) {
                try {
                    val loc = lm.getLastKnownLocation(p)
                    if (loc != null) {
                        currentLoc = loc
                        // Log which provider supplied the last known location and its coordinates
                        try {
                            DbRepo.log(ctx, null, "[GeoWorker] used provider=" + p + " location: lat=" + loc.latitude + ", lon=" + loc.longitude)
                        } catch (_: Throwable) {}
                        break
                    }
                } catch (_: SecurityException) {
                    // Permission may be missing; ignore and try next provider
                }
            }
            if (currentLoc == null) {
                // Attempt to fetch location via Baidu IP geolocation as a fallback.  This
                // is particularly useful for devices in China where Google location
                // services may be unavailable.  The API key (ak) is stored in the
                // notify_config table under 'baidu_ak'.  A network call is made to
                // Baidu only if a non‑empty key is configured.
                try {
                    var ak: String? = null
                    val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx)
                    if (contract != null && contract.dbPath != null) {
                        val db = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
                        val cAk = db.rawQuery(
                            "SELECT value FROM notify_config WHERE key='baidu_ak' LIMIT 1",
                            null
                        )
                        if (cAk.moveToFirst()) {
                            ak = cAk.getString(0)
                        }
                        cAk.close()
                        db.close()
                    }
                    if (ak != null && ak!!.isNotBlank()) {
                        // Compose the Baidu IP location request.  We use gcj02 coordinates
                        // so that the resulting latitude/longitude aligns with the
                        // distance computations used later.  Any exceptions are swallowed
                        // so the worker can still return success.
                        val urlStr = java.net.URI("https://api.map.baidu.com/location/ip?ak=" +
                                java.net.URLEncoder.encode(ak, "UTF-8") + "&coor=gcj02").toURL().toString()
                        val url = java.net.URL(urlStr)
                        val conn = url.openConnection() as java.net.HttpURLConnection
                        conn.requestMethod = "GET"
                        conn.connectTimeout = 5000
                        conn.readTimeout = 5000
                        val responseCode = conn.responseCode
                        if (responseCode == 200) {
                            val resp = conn.inputStream.bufferedReader().use { it.readText() }
                            try {
                                val json = org.json.JSONObject(resp)
                                val content = json.optJSONObject("content")
                                val point = content?.optJSONObject("point")
                                val lonStr = point?.optString("x")
                                val latStr = point?.optString("y")
                                if (!latStr.isNullOrBlank() && !lonStr.isNullOrBlank()) {
                                    val latD = latStr.toDoubleOrNull()
                                    val lonD = lonStr.toDoubleOrNull()
                                    if (latD != null && lonD != null) {
                                        val loc = Location(LocationManager.NETWORK_PROVIDER)
                                        loc.latitude = latD
                                        loc.longitude = lonD
                                        currentLoc = loc
                                        // Log that the fallback IP location from Baidu was used and record the coordinates
                                        try {
                                            DbRepo.log(ctx, null, "[GeoWorker] fallback to Baidu IP location: lat=" + latD + ", lon=" + lonD)
                                        } catch (_: Throwable) {}
                                    }
                                }
                            } catch (_: Throwable) {
                                // JSON parsing error; ignore
                            }
                        }
                        conn.disconnect()
                    }
                } catch (_: Throwable) {
                    // Network or database failure; no fallback available
                }
            }
            // If still no location is available, we cannot evaluate geo triggers; bail out.
            if (currentLoc == null) return Result.success()

            // Load the database contract to locate the SQLite DB
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx)
            if (contract == null || contract.dbPath == null) return Result.success()
            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config, then_text FROM vision_triggers WHERE type='geo' AND enabled=1",
                null
            )
            val geocoder = Geocoder(ctx, Locale.getDefault())
            while (cursor.moveToNext()) {
                val cfgStr = cursor.getString(0) ?: ""
                val thenText = cursor.getString(1) ?: ""
                try {
                    val cfg = org.json.JSONObject(cfgStr)
                    val place = cfg.optString("place", "")
                    val userNote = cfg.optString("note", thenText)
                    val lat = if (cfg.has("lat")) cfg.optDouble("lat", Double.NaN) else Double.NaN
                    val lon = if (cfg.has("lng")) cfg.optDouble("lng", Double.NaN) else Double.NaN
                    var within = false
                    var displayName = place
                    // If lat/lon provided, compute distance directly
                    if (!lat.isNaN() && !lon.isNaN()) {
                        val distArr = FloatArray(1)
                        Location.distanceBetween(
                            currentLoc.latitude,
                            currentLoc.longitude,
                            lat,
                            lon,
                            distArr
                        )
                        if (distArr[0] < 200f) within = true
                        displayName = if (place.isNotEmpty()) place else "目标地点"
                    } else if (place.isNotEmpty()) {
                        val addrs = geocoder.getFromLocationName(place, 1)
                        if (addrs != null && addrs.isNotEmpty()) {
                            val trgLat = addrs[0].latitude
                            val trgLon = addrs[0].longitude
                            val distArr = FloatArray(1)
                            Location.distanceBetween(
                                currentLoc.latitude,
                                currentLoc.longitude,
                                trgLat,
                                trgLon,
                                distArr
                            )
                            if (distArr[0] < 200f) within = true
                        }
                    }
                    if (within) {
                        val body: String = if (userNote.isNotEmpty()) userNote else "你已到达 $displayName ，别忘了你的目标"
                        val id = 3000 + ((displayName.hashCode()) and 0x7fffffff)
                        // Use vision_focus so tapping notification goes to focus page
                        NotifyHelper.send(ctx, id, "愿景地点提醒", body, null, "vision_focus", null)
                    }
                } catch (_: Throwable) {
                    // Ignore malformed JSON or geocoder failures
                }
            }
            cursor.close()
            db.close()
        } catch (_: Throwable) {
            // Swallow any errors; worker will succeed silently
        }
        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "vision_geo_worker"

        /**
         * Schedule the GeoWorker to run periodically every 15 minutes. If a worker is
         * already scheduled, it will be replaced. This should be invoked on boot
         * or when geo triggers are configured to ensure timely reminders.
         */
        @JvmStatic
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<GeoWorker>(15, TimeUnit.MINUTES)
                .addTag(UNIQUE_NAME)
                .build()
            try {
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    UNIQUE_NAME,
                    ExistingPeriodicWorkPolicy.REPLACE,
                    request
                )
            } catch (_: Throwable) { /* ignore */ }
        }
    }
}