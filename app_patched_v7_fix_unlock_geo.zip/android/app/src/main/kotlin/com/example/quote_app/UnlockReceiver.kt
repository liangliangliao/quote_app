package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver listens for the USER_PRESENT broadcast which fires
 * when the user unlocks the device. When triggered, it checks for
 * any enabled screen‑unlock vision triggers and, if present, sends a
 * gentle reminder notification encouraging the user to recall their
 * vision goal.
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            // Log the received broadcast action for debugging and analytics
            try {
                DbRepo.log(context, null, "[UnlockReceiver] onReceive action=" + (intent?.action ?: "null"))
            } catch (_: Throwable) {}
            // Open the SQLite database and query for enabled screen_unlock triggers.
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
            if (contract == null || contract.dbPath == null) {
                // If contract or db path is unavailable, assume triggers may exist
                try {
                    DbRepo.log(context, null, "[UnlockReceiver] contract or dbPath unavailable, fallback to send reminder")
                } catch (_: Throwable) {}
                sendReminder(context)
                return
            }
            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                null
            )
            val hasTrigger = cursor.moveToFirst()
            try {
                DbRepo.log(context, null, "[UnlockReceiver] hasTrigger=" + hasTrigger)
            } catch (_: Throwable) {}
            cursor.close()
            db.close()
            if (hasTrigger) {
                // Record the timestamp of this unlock event so the app can detect
                // recent unlocks when it starts. This value will be consumed
                // by App.maybeSendUnlockReminderOnAppStart to avoid sending
                // reminders when the app is opened long after unlocking.
                try {
                    val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                    try {
                        DbRepo.log(context, null, "[UnlockReceiver] recorded last_unlock_time")
                    } catch (_: Throwable) {}
                } catch (_: Throwable) { /* ignore errors */ }
                sendReminder(context)
            }
        } catch (_: Throwable) {
            // On any error, fallback to sending reminder. Record the unlock time
            try {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                try {
                    DbRepo.log(context, null, "[UnlockReceiver] exception occurred, fallback to send reminder")
                } catch (_: Throwable) {}
            } catch (_: Throwable) { /* ignore */ }
            sendReminder(context)
        }
    }

    /**
     * Sends a notification reminding the user about their vision goal.
     */
    private fun sendReminder(context: Context) {
        val now = System.currentTimeMillis()

        // 默认 30 分钟，如 notify_config 中配置 unlock_cooldown_days 或 unlock_cooldown_minutes 则覆盖。
        var cooldownMs = 30L * 60L * 1000L
        try {
            // 读取数据库中的冷却配置，与 App.maybeSendUnlockReminderOnAppStart 保持一致
            val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
            if (cc != null && cc.dbPath != null) {
                val dbConf = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
                try {
                    // 优先读取天数配置
                    val cDay = dbConf.rawQuery("SELECT value FROM notify_config WHERE key='unlock_cooldown_days' LIMIT 1", null)
                    try {
                        if (cDay.moveToFirst()) {
                            val v = cDay.getString(0)
                            try {
                                val d = v?.toDouble()
                                if (d != null && d > 0.0) {
                                    cooldownMs = (d * 24.0 * 60.0 * 60.0 * 1000.0).toLong()
                                }
                            } catch (_: Throwable) {
                                // ignore parse
                            }
                        }
                    } finally {
                        cDay.close()
                    }
                } catch (_: Throwable) {
                    // ignore
                }
                // 如果未由天数配置覆盖，则读取分钟配置
                if (cooldownMs == 30L * 60L * 1000L) {
                    try {
                        val cMin = dbConf.rawQuery("SELECT value FROM notify_config WHERE key='unlock_cooldown_minutes' LIMIT 1", null)
                        try {
                            if (cMin.moveToFirst()) {
                                val v2 = cMin.getString(0)
                                try {
                                    val m = v2?.toInt()
                                    if (m != null && m > 0) {
                                        cooldownMs = m.toLong() * 60L * 1000L
                                    }
                                } catch (_: Throwable) {
                                    // ignore parse
                                }
                            }
                        } finally {
                            cMin.close()
                        }
                    } catch (_: Throwable) {
                        // ignore
                    }
                }
                dbConf.close()
            }
        } catch (_: Throwable) {
            // ignore any config read errors
        }

        // 频率控制：若上次解锁提醒在冷却期内，则跳过本次发送
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            val lastUnlockReminder = prefs.getLong("last_unlock_reminder_time", 0L)
            if (lastUnlockReminder > 0L && (now - lastUnlockReminder) <= cooldownMs) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "[UnlockReceiver] skip reminder due to cooldown, last=" + lastUnlockReminder + ", now=" + now + ", cooldownMs=" + cooldownMs
                    )
                } catch (_: Throwable) {}
                return
            }
            // 通过频率检查，更新最近一次解锁提醒时间
            prefs.edit().putLong("last_unlock_reminder_time", now).apply()
        } catch (_: Throwable) {
            // ignore prefs errors
        }

        // Use a deterministic ID to avoid flooding the notification drawer
        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        // Pass notifType so that tapping the notification opens the vision focus page
        try {
            DbRepo.log(context, null, "[UnlockReceiver] sending reminder notification at ts=" + now)
        } catch (_: Throwable) {}
        NotifyHelper.send(context, id, title, body, null, "vision_focus", null)
    }
}