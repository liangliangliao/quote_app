package com.example.quote_app.data;

import android.util.Log;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class DbInspector {

    public static final class Contract {
        public String dbPath;
        public String tasksSource;
        public String quotesSource;
        public String logsSource;
        public int version;
        public final Map<String, String> taskColMap = new HashMap<>();
        public final Map<String, String> quoteColMap = new HashMap<>();
        public final Map<String, String> logColMap = new HashMap<>();
    }

    private static final String PREF_KEY = "db.contract";

    public static Contract loadOrLightScan(Context ctx) {
        Contract cached = loadFromPrefs(ctx);
        if (cached != null && !TextUtils.isEmpty(cached.dbPath)) {
            try { if (new java.io.File(cached.dbPath).exists()) return cached; } catch (Throwable ignore) {}
        }
        Contract c = new Contract();
        try {
            File dbDir = new File(ctx.getApplicationInfo().dataDir, "databases");
            if (dbDir.exists()) {
                File[] files = dbDir.listFiles();
        if (files != null && files.length > 0) {
            // prefer DB that has our expected tables/columns
            for (File f : files) {
                try (SQLiteDatabase db = SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY)) {
                    try (Cursor tc = db.rawQuery("PRAGMA table_info(tasks)", null)) {
                        boolean hasTasks = false;
                        while (tc.moveToNext()) {
                            String col = tc.getString(1);
                            if ("task_uid".equals(col) || "uid".equals(col)) { hasTasks = true; break; }
                        }
                        if (hasTasks) { c.dbPath = f.getAbsolutePath(); break; }
                    } catch (Throwable e) { Log.e("DbInspector", "error", e); }
                } catch (Throwable e) { Log.e("DbInspector", "error", e); }
            }
            if (TextUtils.isEmpty(c.dbPath)) c.dbPath = files[0].getAbsolutePath();
        }
            }
            if (TextUtils.isEmpty(c.dbPath)) {
            // Prefer sqflite default db name if present
            File cand = ctx.getDatabasePath("quote_app.db");
            if (cand != null && cand.exists()) {
                c.dbPath = cand.getAbsolutePath();
            } else {
                c.dbPath = ctx.getDatabasePath("app.db").getAbsolutePath();
            // Fallbacks for common sqflite locations
            if (TextUtils.isEmpty(c.dbPath)) {
                try { java.io.File f1 = new java.io.File(ctx.getFilesDir(), "quotes.db"); if (f1.exists()) c.dbPath = f1.getAbsolutePath(); } catch (Throwable e) { Log.e("DbInspector","error", e);} 
            }
            if (TextUtils.isEmpty(c.dbPath)) {
                try { java.io.File f2 = new java.io.File(ctx.getApplicationInfo().dataDir + "/app_flutter/quotes.db"); if (f2.exists()) c.dbPath = f2.getAbsolutePath(); } catch (Throwable e) { Log.e("DbInspector","error", e);} 
            }

            }
            }
        } catch (Throwable e) { Log.e("DbInspector", "error", e); }

        if (TextUtils.isEmpty(c.tasksSource)) c.tasksSource = "tasks";
        if (TextUtils.isEmpty(c.quotesSource)) c.quotesSource = "quotes";
        if (TextUtils.isEmpty(c.logsSource)) c.logsSource = "logs";

        if (!c.taskColMap.containsKey("uid")) c.taskColMap.put("uid", "task_uid");
if (!c.taskColMap.containsKey("title")) c.taskColMap.put("title", "name");
if (!c.taskColMap.containsKey("content")) c.taskColMap.put("content", "prompt");
if (!c.taskColMap.containsKey("avatar")) c.taskColMap.put("avatar", "avatar_path");
if (!c.taskColMap.containsKey("enabled")) c.taskColMap.put("enabled", "status");
if (!c.taskColMap.containsKey("trigger_at")) c.taskColMap.put("trigger_at", "start_time");
if (!c.taskColMap.containsKey("next_time")) c.taskColMap.put("next_time", "next_time");
if (!c.quoteColMap.containsKey("uid")) c.quoteColMap.put("uid", "task_uid");
if (!c.quoteColMap.containsKey("content")) c.quoteColMap.put("content", "content");

        if (!c.logColMap.containsKey("uid")) c.logColMap.put("uid", "task_uid");
if (!c.logColMap.containsKey("detail")) c.logColMap.put("detail", "detail");

        c.version = 1;
        
        // Map to Flutter DB schema
        if (!c.taskColMap.containsKey("uid")) c.taskColMap.put("uid", "task_uid");
if (!c.taskColMap.containsKey("title")) c.taskColMap.put("title", "name");
if (!c.taskColMap.containsKey("content")) c.taskColMap.put("content", "prompt");
if (!c.taskColMap.containsKey("avatar")) c.taskColMap.put("avatar", "avatar_path");
if (!c.taskColMap.containsKey("enabled")) c.taskColMap.put("enabled", "status");
        if (!c.taskColMap.containsKey("title")) c.taskColMap.put("title", "name");
        if (!c.taskColMap.containsKey("content")) c.taskColMap.put("content", "prompt");
        if (!c.taskColMap.containsKey("type")) c.taskColMap.put("type", "type");
        if (!c.taskColMap.containsKey("avatar")) c.taskColMap.put("avatar", "avatar_path");
        if (!c.taskColMap.containsKey("enabled")) c.taskColMap.put("enabled", "status");
        if (!c.taskColMap.containsKey("trigger_at")) c.taskColMap.put("trigger_at", "start_time");
        if (!c.taskColMap.containsKey("next_time")) c.taskColMap.put("next_time", "next_time");
if (!c.quoteColMap.containsKey("uid")) c.quoteColMap.put("uid", "task_uid");
        if (!c.quoteColMap.containsKey("content")) c.quoteColMap.put("content", "content");
        if (!c.quoteColMap.containsKey("avatar")) c.quoteColMap.put("avatar", "avatar");

        if (!c.logColMap.containsKey("uid")) c.logColMap.put("uid", "task_uid");
        if (!c.logColMap.containsKey("detail")) c.logColMap.put("detail", "detail");
    saveToPrefs(ctx, c);
        return c;
    }

    private static Contract loadFromPrefs(Context ctx) {
Contract c = new Contract();
try {
    // ① FlutterSharedPreferences: flutter.quote.db_path
    android.content.SharedPreferences sp = ctx.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
    String p1 = sp.getString("flutter.quote.db_path", null);
    if (!android.text.TextUtils.isEmpty(p1)) { c.dbPath = p1; return c; }

    // ② system default path: /databases/app.db
    java.io.File f2 = ctx.getDatabasePath("app.db");
    if (f2 != null && f2.exists()) { c.dbPath = f2.getAbsolutePath(); return c; }

    // ③ app_flutter/quotes.db (PathProvider on Android)
    java.io.File appFlutter = new java.io.File(new java.io.File(ctx.getFilesDir().getParent()), "app_flutter");
    java.io.File f3 = new java.io.File(appFlutter, "quotes.db");
    if (f3.exists()) { c.dbPath = f3.getAbsolutePath(); return c; }

    // ④ scan databases dir and verify by our tables
    java.io.File dir = new java.io.File(ctx.getApplicationInfo().dataDir, "databases");
    java.io.File[] list = (dir!=null)? dir.listFiles((d, name) -> name.endsWith(".db")) : null;
    if (list != null) {
        for (java.io.File f : list) {
            if (hasOurTables(f.getAbsolutePath())) { c.dbPath = f.getAbsolutePath(); return c; }
        }
    }

    // ⑤ fallback default absolute path
    c.dbPath = ctx.getDatabasePath("app.db").getAbsolutePath();
} catch (Throwable ignore) {
    c.dbPath = ctx.getDatabasePath("app.db").getAbsolutePath();
}
return c;
}

    private static void saveToPrefs(Context ctx, Contract c) {
        try {
            JSONObject o = new JSONObject();
            o.put("dbPath", c.dbPath);
            o.put("tasksSource", c.tasksSource);
            o.put("quotesSource", c.quotesSource);
            o.put("logsSource", c.logsSource);
            o.put("version", c.version);

            JSONObject tm = new JSONObject();
            for (Map.Entry<String, String> e : c.taskColMap.entrySet()) {
                tm.put(e.getKey(), e.getValue());
            }
            o.put("taskColMap", tm);

            JSONObject qm = new JSONObject();
            for (Map.Entry<String, String> e : c.quoteColMap.entrySet()) {
                qm.put(e.getKey(), e.getValue());
            }
            o.put("quoteColMap", qm);

            JSONObject lm = new JSONObject();
            for (Map.Entry<String, String> e : c.logColMap.entrySet()) {
                lm.put(e.getKey(), e.getValue());
            }
            o.put("logColMap", lm);

            if (TextUtils.isEmpty(c.dbPath)) {
            File af = new File(ctx.getApplicationInfo().dataDir, "app_flutter");
            if (af.exists()) {
                File[] afs = af.listFiles();
                if (afs != null) {
                    // prefer quotes.db
                    File preferred = null;
                    for (File f : afs) {
                        if (f.getName().equalsIgnoreCase("quotes.db")) { preferred = f; break; }
                    }
                    if (preferred != null) {
                        c.dbPath = preferred.getAbsolutePath();
                    } else {
                        for (File f : afs) {
                            if (!f.getName().endsWith(".db")) continue;
                            try (SQLiteDatabase db = SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY)) {
                                try (Cursor tc = db.rawQuery("PRAGMA table_info(tasks)", null)) {
                                    boolean hasTasks = false;
                                    while (tc.moveToNext()) {
                                        String col = tc.getString(1);
                                        if ("task_uid".equals(col) || "uid".equals(col)) { hasTasks = true; break; }
                                    }
                                    if (hasTasks) { c.dbPath = f.getAbsolutePath(); }
                                } catch (Throwable e) { Log.e("DbInspector", "error", e); }
                            } catch (Throwable ignore) {}
                            if (!TextUtils.isEmpty(c.dbPath)) break;
                        }
                    }
                }
            }
        }

            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
            sp.edit().putString(PREF_KEY, o.toString()).apply();
        } catch (Throwable e) { Log.e("DbInspector", "error", e); }
    }

    public static Set<String> listColumns(SQLiteDatabase db, String table) {
        Set<String> s = new HashSet<>();
        if (db == null || TextUtils.isEmpty(table)) return s;
        try (Cursor c = db.rawQuery("PRAGMA table_info(" + table + ")", null)) {
            while (c.moveToNext()) s.add(c.getString(1));
        } catch (Throwable e) { Log.e("DbInspector", "error", e); }
        return s;
    }
private static boolean hasOurTables(String path) {
    android.database.sqlite.SQLiteDatabase db = null;
    android.database.Cursor c = null;
    try {
        db = android.database.sqlite.SQLiteDatabase.openDatabase(path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null);
        if (c == null) return false;
        while (c.moveToNext()) {
            String t = c.getString(0);
            if ("tasks".equalsIgnoreCase(t) || "quotes".equalsIgnoreCase(t)
                || "logs".equalsIgnoreCase(t) || "sent_guard".equalsIgnoreCase(t)) return true;
        }
        return false;
    } catch (Throwable ignore) {
        return false;
    } finally {
        if (c != null) try { c.close(); } catch (Throwable ignore) {}
        if (db != null) try { db.close(); } catch (Throwable ignore) {}
    }
}
}