package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.location.Geocoder
import android.database.sqlite.SQLiteDatabase
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * GeoWorker：周期性检查当前地理位置，对比 vision_triggers 中的 geo 规则，
 * 若进入某个地点 200 米范围内，则发送一条愿景提醒。
 */
class GeoWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {
    override fun doWork(): Result {
        val ctx = applicationContext
        DbRepo.log(ctx, null, "[Geo] doWork begin")
        try {
            // 1. 获取最近一次定位（GPS / 网络）
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var currentLoc: Location? = null
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (p in providers) {
                try {
                    val loc = lm.getLastKnownLocation(p)
                    if (loc != null) {
                        currentLoc = loc
                        break
                    }
                } catch (se: SecurityException) {
                    DbRepo.log(ctx, null, "[Geo] SecurityException for provider=$p")
                }
            }
            if (currentLoc == null) {
                DbRepo.log(ctx, null, "[Geo] no lastKnownLocation, skip")
                return Result.success()
            }

            // 2. 打开数据库，读取启用的 geo 规则
            val contract = DbInspector.loadOrLightScan(ctx)
            if (contract == null || contract.dbPath == null) {
                DbRepo.log(ctx, null, "[Geo] no contract/dbPath, skip")
                return Result.success()
            }
            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config, then_text FROM vision_triggers WHERE type='geo' AND enabled=1",
                null
            )
            val geocoder = Geocoder(ctx, Locale.getDefault())

            while (cursor.moveToNext()) {
                val cfgStr = cursor.getString(0) ?: ""
                val thenText = cursor.getString(1) ?: ""
                try {
                    val cfg = org.json.JSONObject(cfgStr)
                    val place = cfg.optString("place", "")
                    val userNote = cfg.optString("note", thenText)
                    if (place.isNotEmpty()) {
                        val addrs = geocoder.getFromLocationName(place, 1)
                        if (addrs != null && addrs.isNotEmpty()) {
                            val trgLat = addrs[0].latitude
                            val trgLon = addrs[0].longitude
                            val dist = FloatArray(1)
                            Location.distanceBetween(
                                currentLoc.latitude,
                                currentLoc.longitude,
                                trgLat,
                                trgLon,
                                dist
                            )
                            DbRepo.log(ctx, null, "[Geo] place=$place dist=${dist[0]}")
                            if (dist[0] < 200f) {
                                val body = if (userNote.isNotEmpty()) userNote else "你已到达 $place ，别忘了你的目标"
                                val id = 3000 + (place.hashCode() and 0x7fffffff)
                                DbRepo.log(ctx, null, "[Geo] notify place=$place id=$id")
                                NotifyHelper.send(ctx, id, "愿景地点提醒", body, null)
                            }
                        } else {
                            DbRepo.log(ctx, null, "[Geo] geocoder no result for place=$place")
                        }
                    }
                } catch (t: Throwable) {
                    DbRepo.log(ctx, null, "[Geo] error parsing cfg: ${t.javaClass.simpleName}")
                }
            }
            cursor.close()
            db.close()
        } catch (t: Throwable) {
            DbRepo.log(ctx, null, "[Geo] doWork error: ${t.javaClass.simpleName}")
        }
        DbRepo.log(ctx, null, "[Geo] doWork end")
        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "vision_geo_worker"

        /**
         * 注册周期性任务（15 分钟一次），使用唯一名字，避免重复调度。
         */
        @JvmStatic
        fun schedule(context: Context) {
            try {
                val request = PeriodicWorkRequestBuilder<GeoWorker>(15, TimeUnit.MINUTES)
                    .addTag(UNIQUE_NAME)
                    .build()
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    UNIQUE_NAME,
                    ExistingPeriodicWorkPolicy.REPLACE,
                    request
                )
                DbRepo.log(context, null, "[Geo] schedule periodic worker")
            } catch (t: Throwable) {
                DbRepo.log(context, null, "[Geo] schedule error: ${t.javaClass.simpleName}")
            }
        }
    }
}

