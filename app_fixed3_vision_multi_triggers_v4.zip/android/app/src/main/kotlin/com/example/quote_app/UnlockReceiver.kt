package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver 监听 USER_PRESENT 广播（用户解锁设备后触发）。
 *
 * 触发时会检查 vision_triggers 表中是否存在启用的 screen_unlock 规则，
 * 若存在，则发送一条温和的愿景提醒通知。
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        try {
            DbRepo.log(context, null, "[Unlock] onReceive action=$action")

            val contract = DbInspector.loadOrLightScan(context)
            if (contract == null || contract.dbPath == null) {
                DbRepo.log(context, null, "[Unlock] no contract/dbPath, fallback notify")
                sendReminder(context)
                return
            }

            val db: SQLiteDatabase =
                SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                null
            )
            val hasTrigger = cursor.moveToFirst()
            cursor.close()
            db.close()

            DbRepo.log(context, null, "[Unlock] hasTrigger=$hasTrigger")
            if (hasTrigger) {
                sendReminder(context)
            }
        } catch (t: Throwable) {
            DbRepo.log(context, null, "[Unlock] error=${t.javaClass.simpleName}")
            // 任何异常情况下，不影响用户体验，直接尝试发一条提醒
            sendReminder(context)
        }
    }

    /**
     * 真正发送提醒通知（使用固定 ID，避免刷屏，只会覆盖上一条）。
     */
    private fun sendReminder(context: Context) {
        DbRepo.log(context, null, "[Unlock] notify id=2000")
        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        NotifyHelper.send(context, id, title, body, null)
    }
}

