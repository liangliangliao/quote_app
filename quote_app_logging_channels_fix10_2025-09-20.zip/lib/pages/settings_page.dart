
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';
import '../services/notification_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();
  final _logDao = LogDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');

  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;
    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _saveConfig() async {
    try {
      await _configDao.save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存配置')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('保存失败: $e')));
    }
  }

  Future<void> _openTaskDialog() async {
    final nameCtrl = TextEditingController();
    String type = 'manual';
    await showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: const Text('新增任务'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: '任务名称')),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: type,
              items: const [
                DropdownMenuItem(value: 'manual', child: Text('手动任务')),
                DropdownMenuItem(value: 'auto', child: Text('自动任务')),
              ],
              onChanged: (v){ if (v!=null) type=v; },
              decoration: const InputDecoration(labelText: '类型'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('取消')),
          FilledButton(
            onPressed: () async {
              final now = DateTime.now().add(const Duration(minutes: 1));
              await _taskDao.create(
                name: nameCtrl.text.trim().isEmpty ? '新任务' : nameCtrl.text.trim(),
                type: type,
                startTime: now,
                prompt: '',
                avatarPath: '',
                status: 'on',
              );
              await _logDao.add(taskUid: 'system', detail: '[Settings] 新增任务，计划于 ${now.toString()} 首次触发');
              Navigator.pop(context);
              await _load();
            },
            child: const Text('保存'),
          ),
        ],
      );
    });
  }

  Future<void> _requestNotifPerm() async {
    await NotificationService.requestAndroidPermissionSafely();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已尝试申请通知权限(仅Android13+)')));
  }

  Future<void> _rescheduleAll() async {
    await SchedulerService.scheduleNextForAll();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已重新调度所有任务')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('OpenAI 配置', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            TextField(controller: _apiKeyCtrl, decoration: const InputDecoration(labelText: 'API Key')),
            TextField(controller: _modelCtrl, decoration: const InputDecoration(labelText: '模型'),),
            TextField(controller: _endpointCtrl, decoration: const InputDecoration(labelText: 'Endpoint'),),
            const SizedBox(height: 8),
            Row(
              children: [
                FilledButton(onPressed: _saveConfig, child: const Text('保存配置')),
                const SizedBox(width: 8),
                OutlinedButton(onPressed: _requestNotifPerm, child: const Text('申请通知权限')),
                const SizedBox(width: 8),
                OutlinedButton(onPressed: _rescheduleAll, child: const Text('重新调度')),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('任务列表', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(onPressed: _openTaskDialog, icon: const Icon(Icons.add)),
              ],
            ),
            for (final t in _tasks)
              ListTile(
                leading: const Icon(Icons.schedule),
                title: Text((t['name'] ?? '') as String),
                subtitle: Text('时间: ${(t['start_time'] ?? '') as String}   类型: ${(t['type'] ?? '') as String}   状态: ${(t['status'] ?? '') as String}'),
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openTaskDialog,
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}
