import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../platform/perm_helper.dart';

/// PermissionGate
/// 方案A：完全在 Flutter 层处理权限引导。
///
/// 业务约束：
/// 1) 第一关：系统通知权限（Android 13+ 的 POST_NOTIFICATIONS）。
///    - 若拒绝：直接退出应用（不可绕过）。
///    - 若已授权：继续第二关。
/// 2) 第二关：精准闹钟（SCHEDULE_EXACT_ALARM）。
///    - 若已授权：直接进入首页。
///    - 若未授权：弹自定义对话框【允许/不允许】；
///        a) 点【允许】：跳系统设置页；从设置返回（含返回键）后重新检测：
///           - 若已授权：进入首页；
///           - 若仍未授权：继续停留在该对话层面（重复流程）
///        b) 点【不允许】：再弹确认小框（是/否；提示“你将不启用精准闹钟提醒功能！”）
///           - 点【是】：进入首页（下次打开若仍未授权，会继续触发第二关流程）
///           - 点【否】：关闭小框，仍停留在闹钟提醒对话框。
class PermissionGate extends StatefulWidget {
  final Widget child;
  const PermissionGate({super.key, required this.child});

  @override
  State<PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<PermissionGate>
    with WidgetsBindingObserver {
  bool _ready = false; // 两道门全部通过后才为 true
  bool _askedExactThisSession = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _boot();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// 当从系统设置页返回时（App 生命周期回到 resumed），重检第二道门
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_ready) {
      _checkSecondGate(forceAsk: _askedExactThisSession);
    }
  }

  Future<void> _boot() async {
    // 先过第一道门（通知权限）
    final ok = await _ensureNotificationGate();
    if (!ok) return; // 已经退出
    // 再过第二道门（精准闹钟）
    await _checkSecondGate(forceAsk: true);
  }

  /// 第一关：系统通知权限
  Future<bool> _ensureNotificationGate() async {
    if (!Platform.isAndroid) {
      setState(() => _ready = true);
      return true;
    }
    // Android 13+ 才需要运行时的通知权限
    if ((await Permission.notification.status).isGranted ||
        !await _needPostNotifications()) {
      return true;
    }

    final allow = await _showNotificationExplainDialog();
    if (!allow) {
      // 用户点了“不允许” → 直接退出
      await SystemNavigator.pop();
      return false;
    }

    final status = await Permission.notification.request();
    if (status.isGranted) {
      return true;
    } else {
      // “拒绝授权时无法进入首页”
      await SystemNavigator.pop();
      return false;
    }
  }

  /// Android 13+ 需要 POST_NOTIFICATIONS
  Future<bool> _needPostNotifications() async {
    try {
      final method = const MethodChannel('com.example.quote_app/sys');
      final int sdk = await method.invokeMethod<int>('sdkInt') ?? 33;
      return sdk >= 33;
    } catch (_) {
      return true; // 保守起见
    }
  }

  /// 第二关：精准闹钟
  Future<void> _checkSecondGate({required bool forceAsk}) async {
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (hasExact) {
      setState(() => _ready = true);
      return;
    }
    if (!forceAsk) return;

    _askedExactThisSession = true;
    final granted = await _askExactAlarmOnce();
    if (granted) {
      setState(() => _ready = true);
    } else {
      // 未授权但选择“是（不启用）”时，也可进入首页
      setState(() => _ready = true);
    }
  }

  Future<bool> _askExactAlarmOnce() async {
    final allow = await _showExactExplainDialog();
    if (!allow) {
      final ignore = await _showIgnoreExactConfirm();
      // ignore==true 表示“是（不启用精准闹钟）”，允许进入首页
      return ignore; // true=视作放行，false=停留在本弹框
    }

    await PermHelper.requestExactAlarmPermission();
    // 等用户从系统设置返回后在 didChangeAppLifecycleState 里重检
    return false;
  }

  /// 通知权限说明弹框（第一道门入口）
  Future<bool> _showNotificationExplainDialog() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            title: const Text('系统通知权限'),
            content: const Text('为了发送每日名言提醒，需要开启系统通知。请点击“允许”。'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('不允许')),
              ElevatedButton(
                  onPressed: () => Navigator.of(ctx).pop(true),
                  child: const Text('允许')),
            ],
          ),
        ) ??
        false;
  }

  /// 精准闹钟说明弹框（第二道门入口）
  Future<bool> _showExactExplainDialog() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            title: const Text('闹钟提醒权限授权'),
            content: const Text('为保证提醒的精准触达，需要开启“精准闹钟”权限。'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('不允许')),
              ElevatedButton(
                  onPressed: () => Navigator.of(ctx).pop(true),
                  child: const Text('允许')),
            ],
          ),
        ) ??
        false;
  }

  /// 拒绝精准闹钟后的二次确认
  Future<bool> _showIgnoreExactConfirm() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            content: const Text('你将不启用精准闹钟提醒功能！'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('否')),
              ElevatedButton(
                  onPressed: () => Navigator.of(ctx).pop(true),
                  child: const Text('是')),
            ],
          ),
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    // 未通过两道门之前显示一个空白页，避免“灰屏”的系统原生活动界面
    return _ready ? widget.child : const Scaffold(body: SizedBox());
  }
}
