// ignore_for_file: avoid_print
import 'dart:io';
import 'package:flutter/services.dart';

/// Native permission helpers (Android only).
/// Channel implemented in MainActivity.kt
class PermHelper {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');

  /// Whether app has EXACT ALARM privilege (Android 12+, otherwise true).
  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? true;
    } on PlatformException catch (e) {
      print('hasExactAlarmPermission error: ${e.message}');
      return true; // 不阻塞应用
    }
  }

  /// Open system settings page to request EXACT ALARM privilege.
  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } on PlatformException catch (e) {
      print('requestExactAlarmPermission error: ${e.message}');
    }
  }
}
