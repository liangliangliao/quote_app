package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 解锁广播入口：
 * 1) 优先检查配置表中的地点规则开关；若关闭，直接返回（不触发已有的解锁轻提醒链路）
 * 2) 若开启，立即启动前台服务 GeoForegroundService 执行定位与提醒（不进入 WorkManager）
 * 3) 所有关键步骤写中文日志
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    // ① 优先检查地点规则总开关
    try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
      var enabled = false
      if (cc != null && cc.dbPath != null) {
        val db = android.database.sqlite.SQLiteDatabase.openDatabase(
          cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY
        )
        try {
          db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
            if (c.moveToFirst()) enabled = (c.getInt(0) == 1)
          }
        } finally { try { db.close() } catch (_: Throwable) {} }
      }
      if (!enabled) {
        try { DbRepo.log(context, null, "【解锁后台】地点规则开关=关闭，直接返回；不触发解锁轻提醒") } catch (_: Throwable) {}
        return
      }
    } catch (_: Throwable) {
      // 兜底：若读取开关异常，当作关闭处理，直接返回（避免异常放大）
      try { DbRepo.log(context, null, "【解锁后台】读取地点规则开关异常，按关闭处理") } catch (_: Throwable) {}
      return
    }

    // ② 开关=开启：立即启动前台服务（不走 WorkManager）
    try {
      val svc = Intent(context, GeoForegroundService::class.java)
      if (Build.VERSION.SDK_INT >= 26) {
        context.startForegroundService(svc)
      } else {
        context.startService(svc)
      }
      try { DbRepo.log(context, null, "【解锁后台】已启动 GeoForegroundService 前台服务进行定位与提醒") } catch (_: Throwable) {}
      try { Toast.makeText(context.applicationContext, "正在执行地点提醒...", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
    } catch (t: Throwable) {
      try { DbRepo.log(context, null, "【解锁后台】启动 GeoForegroundService 失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
    }
  }
}
