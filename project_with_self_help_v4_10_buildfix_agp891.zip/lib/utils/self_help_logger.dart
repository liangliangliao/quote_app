import 'dart:convert';

import '../data/db.dart';

/// Minimal persistent logger for the "Change · Self-help" module.
///
/// Why: on some devices (esp. Android 14), camera PPG may fail due to
/// hardware/driver differences. Persisting a compact diagnostic summary helps
/// reproduce and fix issues without spamming console logs.
class SelfHelpLogger {
  static Future<void> log(
    String level,
    String module,
    String message, {
    Map<String, dynamic>? extra,
  }) async {
    try {
      final db = await AppDatabase.instance();
      await db.insert('self_help_logs', {
        'ts_ms': DateTime.now().millisecondsSinceEpoch,
        'level': level,
        'module': module,
        'message': message,
        'extra_json': extra == null ? null : jsonEncode(extra),
      });
    } catch (_) {
      // Never crash app due to logging.
    }
  }

  static Future<List<Map<String, dynamic>>> latest({int limit = 100}) async {
    try {
      final db = await AppDatabase.instance();
      return await db.query(
        'self_help_logs',
        orderBy: 'ts_ms DESC, id DESC',
        limit: limit,
      );
    } catch (_) {
      return const [];
    }
  }
}
