
import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _editing = false;
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');

  @override
  void dispose() {
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  void _toggleEdit() {
    setState(()=> _editing = !_editing);
  }

  void _save() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
    setState(()=> _editing = false);
  }

  void _addTask() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('新增任务（占位）')));
  }

  @override
  Widget build(BuildContext context) {
    final double topPad = MediaQuery.of(context).padding.top;
    return Column(
      children: [
        SizedBox(height: topPad),
        Container(
          height: kToolbarHeight,
          color: Colors.white,
          alignment: Alignment.centerRight,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(onPressed: _toggleEdit, icon: const Icon(Icons.edit)),
              IconButton(onPressed: _save, icon: const Icon(Icons.save)),
              IconButton(onPressed: _addTask, icon: const Icon(Icons.add)),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const SizedBox(height: 8),
              const Text('模型名称', style: TextStyle(fontSize: 14, color: Colors.black54)),
              const SizedBox(height: 8),
              TextField(
                controller: _modelCtrl,
                enabled: _editing,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('接口地址', style: TextStyle(fontSize: 14, color: Colors.black54)),
              const SizedBox(height: 8),
              TextField(
                controller: _endpointCtrl,
                enabled: _editing,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('任务列表', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('（此处为占位显示；真实数据逻辑保留在原服务内）'),
            ],
          ),
        ),
      ],
    );
  }
}
