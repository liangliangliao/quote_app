package com.example.quote_app.wm;

import com.example.quote_app.compat.DartParity;

public final class WmNames {
    private WmNames() {}

    public static String normUnique(String uid, String runKey) {
        int id = DartParity.alarmId(uid, runKey);
        return "wm_normal_" + id + "_" + (runKey == null ? "" : runKey);
    }
    public static String fbUnique(String uid, String runKey) {
        int id = DartParity.alarmId(uid, runKey);
        return "wm_fb_" + id + "_" + (runKey == null ? "" : runKey);
    }
}
