// GENERATED FIX: robust data injection + avatar base64 scaling
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:image/image.dart' as img;
import '../utils/debug_logger.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  // -- Helpers -----------------------------------------------------------------

  static bool _looksLikeUrl(String s) => s.startsWith('http://') || s.startsWith('https://');
  static bool _looksLikeData(String s) => s.startsWith('data:image/');

  static String _extToMime(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    if (p.endsWith('.gif')) return 'image/gif';
    return 'image/jpeg';
  }

  /// Read an avatar source and return a **small** data URL (<= ~60KB) to avoid
  /// evaluateJavascript length limits on Android WebView.
  Future<String> _normalizeAvatar(dynamic raw) async {
    if (raw == null) return '';
    final s = raw.toString();
    if (s.isEmpty) return '';
    if (_looksLikeUrl(s) || _looksLikeData(s)) return s;

    // Try file path (absolute or file://)
    var path = s;
    if (path.startsWith('file://')) path = path.substring(7);
    final f = File(path);
    if (!(await f.exists())) return '';

    // Decode -> downscale -> JPEG(85)
    try {
      final bytes = await f.readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return '';
      final maxSide = 256;
      final resized = img.copyResize(decoded, width: decoded.width > decoded.height ? maxSide : null, height: decoded.height >= decoded.width ? maxSide : null, interpolation: img.Interpolation.average);
      final out = img.encodeJpg(resized, quality: 85);
      final b64 = base64Encode(out);
      return 'data:image/jpeg;base64,' + b64;
    } catch (e) {
      try { await DLog.e('HTML','avatar normalize failed: ' + e.toString()); } catch(_){}
      return '';
    }
  }

  Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
    if (d == null) return;
    final payloadMap = <String, dynamic>{
      'topic': d['topic'] ?? d['title'] ?? '',
      'quote': d['quote'] ?? d['content'] ?? '',
      'author': d['author'] ?? d['speaker'] ?? '',
      'note': (d['explain'] ?? d['explanation'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? ''),
    };
    // avatar
    final rawAvatar = d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url'];
    payloadMap['avatarUrl'] = await _normalizeAvatar(rawAvatar);
    if (d.containsKey('focalX')) payloadMap['focalX'] = d['focalX'];
    if (d.containsKey('focalY')) payloadMap['focalY'] = d['focalY'];

    final payloadJson = jsonEncode(payloadMap);

    try { await DLog.i('HTML', '注入数据: ' + (payloadJson.length > 256 ? (payloadJson.substring(0,256)+'...('+payloadJson.length.toString()+' bytes)') : payloadJson)); } catch(_){}

    // Some WebViews have trouble with very long evaluateJavascript strings.
    // Keep it small by compressing avatar above. Additionally, guard with try..catch in JS.
    final script = "try { window.setDynamicData(PAYLOAD); } catch(e) { console && console.error && console.error('inject failed', e); }".replaceFirst("PAYLOAD", payloadJson);
    await _controller.runJavaScript(script);
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
