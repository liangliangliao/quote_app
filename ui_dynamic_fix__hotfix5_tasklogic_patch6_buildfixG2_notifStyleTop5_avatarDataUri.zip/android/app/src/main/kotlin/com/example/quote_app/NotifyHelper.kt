package com.example.quote_app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.example.quote_app.R

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val DEFAULT_CHANNEL_NAME = "Quotes"

  private fun ensureChannel(nm: NotificationManager) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val ch = NotificationChannel(DEFAULT_CHANNEL_ID, DEFAULT_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT)
      nm.createNotificationChannel(ch)
    }
  }

  /**
   * 统一发送入口；title/desc/头像路径 均来自 Biz 流程。
   * 如果自定义布局可用（布局和类存在），则使用 notif_card_top5_fulljustify，自定义大图标在右上角。
   */
  @JvmStatic
  fun send(ctx: Context, id: Int, title: String?, content: String?, avatarPath: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    ensureChannel(nm)

    // 点击跳转应用（可保留默认）
    val pi: PendingIntent? = null

    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setContentTitle(title ?: "提醒")
      .setContentText(content ?: "")
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)

    // 大图标
    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }

    // 尝试使用自定义 RemoteViews 样式（如果资源存在）
    try {
      val resId = ctx.resources.getIdentifier("notif_card_top5_fulljustify", "layout", ctx.packageName)
      if (resId != 0) {
        val rv = NotifTop5FullJustify.buildRemoteViews(ctx, resId, title ?: "", content ?: "", true)
        if (!avatarPath.isNullOrEmpty()) {
          try { val bmp = BitmapFactory.decodeFile(avatarPath); if (bmp != null) rv.setImageViewBitmap(R.id.hero, bmp) } catch (_: Throwable) {}
        }
        builder.setCustomContentView(rv)
        builder.setStyle(NotificationCompat.DecoratedCustomViewStyle())
      }
    } catch (_: Throwable) {}

    if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < 33) {
      nm.notify(id, builder.build())
    }
  }
}
