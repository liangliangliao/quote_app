
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import 'utils/debug_logger.dart';
import 'data/notify_dao.dart';
import 'services/self_check_service.dart';

class BackgroundTasks {
  static Future<void> registerSelfCheck() async {
    await PatchMigration20251001.ensure();
    final minutes = await NotifyParamsDao.getSelfCheckFrequencyMinutes();
    final uniq = 'bg_selfcheck_next';
    try { await Workmanager().cancelByUniqueName(uniq); } catch (_) {}
    try {
      await Workmanager().registerPeriodicTask(
        uniq, // unique name
        'self_check', // task name
        frequency: Duration(minutes: minutes < 15 ? 15 : minutes),
        initialDelay: const Duration(minutes: 1),
        inputData: const {'job': 'self_check'},
        constraints: const Constraints(networkType: NetworkType.not_required),
        backoffPolicy: BackoffPolicy.exponential,
        backoffPolicyDelay: const Duration(minutes: 15),
      );
      await DLog.i('BG', '已注册自检任务：每'+minutes.toString()+'分钟');
    } catch (e) {
      await DLog.e('BG', '注册自检失败：'+e.toString());
    }
  }
}
