
import '../data/dao.dart';
import '../services/openai_service.dart';
import '../services/notification_service.dart';

class TaskRunner {
  /// Run task by uid. Return true if notification was sent successfully.
  static Future<bool> run(String uid) async {
    try {
      final task = await TaskDao().getByUid(uid);
      if (task == null) return false;
      final status = (task['status'] ?? 'on').toString();
      if (status != 'on') return false; // 2.1.2 关闭状态直接退出

      final type = (task['type'] ?? 'manual').toString(); // manual | auto | carousel
      if (type == 'auto') return await _runAuto(task);
      if (type == 'carousel') return await _runCarousel(task);
      return await _runManual(task);
    } catch (_) {
      return false;
    }
  }

  // -------- helpers --------

  static Future<bool> _notify(Map<String,dynamic> t, String content) async {
    final title = (t['name'] ?? '提醒').toString();
    final avatar = (t['avatar_path'] ?? '').toString();
    try {
      await NotificationService.show(title: title, body: content, largeIconPath: avatar);
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _runManual(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) return false;
    final row = await QuoteDao().latestForTask(uid);
    if (row == null) {
      await LogDao().add(taskUid: uid, detail: '错误! 手动任务无名人名言数据');
      return false;
    }
    final content = (row['content'] ?? '').toString();
    final ok = await _notify(t, content);
    if (!ok) return false;
    if (row['quote_uid'] != null) {
      await QuoteDao().markNotifiedByUid(row['quote_uid'].toString());
    }
    await LogDao().add(taskUid: uid, detail: '成功! 发送手动任务通知');
    return true;
  }

  static Future<bool> _runCarousel(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) return false;
    final row = await QuoteDao().carouselNextSequential(uid);
    if (row == null) {
      await LogDao().add(taskUid: uid, detail: '错误! 轮播任务无名人名言数据');
      return false;
    }
    final content = (row['content'] ?? '').toString();
    final ok = await _notify(t, content);
    if (!ok) return false;
    if (row['quote_uid'] != null) {
      await QuoteDao().markNotifiedByUid(row['quote_uid'].toString());
    }
    await LogDao().add(taskUid: uid, detail: '成功! 发送轮播任务通知');
    return true;
  }

  static Future<bool> _runAuto(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) return false;
    final prompt = (t['prompt'] ?? '').toString();

    // 读取配置
    final cfg = await ConfigDao().getOne();
    final model = (cfg['model'] ?? 'gpt-5').toString();
    final apiKey = (cfg['api_key'] ?? '').toString();
    final endpoint = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses').toString();

    final openai = OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model);

    // 最多 10 次去重检验
    String? content;
    for (int i=0;i<10;i++) {
      try {
        final res = await openai.generateQuote(prompt.isEmpty ? '请生成一句中文简短的名人名言' : prompt);
        if (res.trim().isEmpty) {
          continue;
        }
        final duplicated = await QuoteDao().existsSimilar(res.trim(), threshold: 0.90);
        if (!duplicated) {
          content = res.trim();
          break;
        }
      } catch (_) {
        // ignore and retry
      }
    }

    if (content == null) {
      await LogDao().add(taskUid: uid, detail: '错误! 连续调用api10次去重检验未通过！');
      return false;
    }

    // 插入 + 通知 + 记录日志
    final inserted = await QuoteDao().insertIfUnique(taskUid: uid, content: content);
    if (!inserted) {
      await LogDao().add(taskUid: uid, detail: '错误! 去重失败导致未插入');
      return false;
    }

    final ok = await _notify(t, content);
    if (!ok) return false;

    // 标记最新一条为已通知（如果 insertIfUnique 返回不了 uid，则尝试 latest 再标记）
    final latest = await QuoteDao().latestForTask(uid);
    if (latest != null && latest['quote_uid'] != null) {
      await QuoteDao().markNotifiedByUid(latest['quote_uid'].toString());
    }
    await LogDao().add(taskUid: uid, detail: '成功! 已插入名言并发送通知');
    return true;
  }
}
