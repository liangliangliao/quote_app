package com.example.quote_app.quote_app_

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
