import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'diary_dao.dart';
import 'entry_editor_page.dart';
import 'entry_editor_pager.dart';
import 'entry_reader_page.dart';
import 'mood_trend_page.dart';
import '../data/db.dart';

class NotebookPage extends StatefulWidget {
  final Notebook notebook;
  const NotebookPage({super.key, required this.notebook});

  @override
  State<NotebookPage> createState() => _NotebookPageState();
}

class _NotebookPageState extends State<NotebookPage> {
  static const Color _baseBg = Color(0xFFE6F5EA);
  // App bar & system bars style
  final SystemUiOverlayStyle _opaqueBarsStyle = const SystemUiOverlayStyle(
    statusBarColor: _baseBg,
    systemNavigationBarColor: _baseBg,
    systemNavigationBarDividerColor: _baseBg,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarIconBrightness: Brightness.dark,
  );
  // Native channel for stronger control (Samsung etc.)
  static const MethodChannel _sysBars = MethodChannel('com.example.quote_app/sysbars');
  Future<void> _applyOpaqueBarsNative() async { try { await _sysBars.invokeMethod('setBarsColor', {'color': _baseBg.value}); } catch (_) {} }
  Future<void> _restoreBarsNative() async { try { await _sysBars.invokeMethod('setTransparent'); } catch (_) {} }

  String? _bgPath; double _bgOpacity = 0.25;
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy-MM-dd HH:mm');
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();

  List<DiaryEntry> _items = [];
  String? _cursor;
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;
  int _totalCount = 0;

  String? _keyword;
  int? _tagId;
  String? _tagName;
  DateTime? _day;

  @override
  void initState() {
    super.initState();
    _applyOpaqueBarsNative(); _dao.ensureSchema();
    _bootstrapBg();
    _loadFirst();
    _refreshCount();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200) {
        _loadMore();
      }
    });
  }

  Future<void> _bootstrapBg() async {
    try {
      await _loadBg();
    } catch (_) {
      // ignore
    }
  }


  @override
  void dispose() {
    _restoreBarsNative(); _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFirst() async {
    setState(() {
      _loading = true;
      _cursor = null;
      _hasMore = true;
      _items = [];
    });
    final res = await _dao.listEntries(
      notebookId: widget.notebook.id,
      limit: 50,
      cursor: null,
      keyword: _keyword,
      day: _day,
      tagId: _tagId,
    );
    setState(() {
      _items = res.items;
      _cursor = res.nextCursor;
      _hasMore = res.nextCursor != null;
      _loading = false;
    });
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _loadingMore || _loading) return;
    setState(() => _loadingMore = true);
    final res = await _dao.listEntries(
      notebookId: widget.notebook.id,
      limit: 50,
      cursor: _cursor,
      keyword: _keyword,
      day: _day,
      tagId: _tagId,
    );
    setState(() {
      _items.addAll(res.items);
      _cursor = res.nextCursor;
      _hasMore = res.nextCursor != null;
      _loadingMore = false;
    });
  }

  
  Future<void> _refreshCount() async {
    final c = await _dao.countEntries(widget.notebook.id);
    if (mounted) setState(() { _totalCount = c; });
  }
Future<void> _newEntry() async {
    final id = await Navigator.push<int?>(
      context,
      MaterialPageRoute(builder: (_) => EntryEditorPage(notebookId: widget.notebook.id)),
    );
    if (id != null) { _loadFirst();
     _refreshCount(); }
    _refreshCount();
  }

  
void _openEntry(DiaryEntry e) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EntryEditorPagerPage(notebookId: widget.notebook.id, initialEntryId: e.id)),
    ).then((_) { _loadFirst(); _refreshCount(); });
  }


  Future<void> _pickDay() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _day ?? now,
      firstDate: DateTime(2000, 1, 1),
      lastDate: DateTime(now.year + 1),
    );
    setState(() => _day = picked);
    await _loadFirst();
    
    _refreshCount();
  }

  Future<void> _filterByTag() async {
    final tags = await _dao.listTags();
    final res = await showModalBottomSheet<Map<String, dynamic>?>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: ListView(
          children: [
            ListTile(
              leading: Icon(_tagId == null ? Icons.check_circle : Icons.circle_outlined),
              title: const Text('全部'),
              onTap: () => Navigator.pop(context, {'id': null, 'name': null}),
            ),
            const Divider(height: 1),
            ...tags.map(
              (t) => ListTile(
                leading: Icon(_tagId == t.id ? Icons.check_circle : Icons.circle_outlined),
                title: Text(t.name),
                onTap: () => Navigator.pop(context, {'id': t.id, 'name': t.name}),
              ),
            ),
          ],
        ),
      ),
    );
    if (res == null) return;
    setState(() {
      _tagId = res['id'] as int?;
      _tagName = res['name'] as String?;
    });
    await _loadFirst();
    
    _refreshCount();
  }

  Future<void> _exportNotebook() async {
    final data = await _dao.exportNotebook(widget.notebook.id);
    final jsonStr = const JsonEncoder.withIndent('  ').convert(data);

    final dir = await FilePicker.platform.getDirectoryPath();
    if (dir == null) return;

    final safeName = widget.notebook.name.replaceAll(RegExp(r'[^a-zA-Z0-9_\-\u4e00-\u9fa5]'), '_');
    final stamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
    final file = File('$dir/diary_${safeName}_$stamp.json');
    await file.writeAsString(jsonStr, flush: true);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已导出：${file.path}')));
  }

  Future<void> _importNotebook() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['json']);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;

    final txt = await File(path).readAsString();
    final obj = jsonDecode(txt);
    if (obj is! Map<String, dynamic>) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('导入失败：文件格式不正确')));
      return;
    }

    await _dao.importToNotebook(widget.notebook.id, obj);
    await _dao.touchNotebook(widget.notebook.id);
    await _loadFirst();
    
    _refreshCount();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('导入完成')));
  }

  void _openMoodTrend() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const MoodTrendPage()));
  }

  
  Future<void> _loadBg() async {
    try {
      await AppDatabase.ensureDiaryColumns();
      final db = await AppDatabase.instance();
      final rows = await db.rawQuery(
        'SELECT diary_bg_image, diary_bg_opacity FROM configs ORDER BY id DESC LIMIT 1',
      );
      if (rows.isNotEmpty) {
        _bgPath = (rows.first['diary_bg_image'] ?? '') as String?;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(
      fit: StackFit.expand,
      children: [
        // White base: when the background becomes more "transparent", we
        // should reveal white instead of the default black canvas.
        const ColoredBox(color: Colors.white),
        Opacity(
          opacity: (1.0 - _bgOpacity).clamp(0.0, 1.0),
          child: Image.file(f, fit: BoxFit.cover),
        ),
        child,
      ],
    );
  }

  
  Widget? _leadingForEntry(DiaryEntry e) {
    try {
      final img = RegExp(r'^\[图片\]\s*(.+)$', multiLine: true).firstMatch(e.content);
      if (img != null) {
        final p = img.group(1)!;
        final f = File(p);
        if (f.existsSync()) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(f, width: 56, height: 56, fit: BoxFit.cover),
          );
        }
      }
      final au = RegExp(r'^\[语音\]\s*(.+)$', multiLine: true).firstMatch(e.content);
      if (au != null) {
        // For audio attachments, we intentionally do not show a microphone icon in
        // the notebook list.  Leaving this block empty ensures no icon is
        // returned and the list item simply has no leading widget.
      }
    } catch (_) {}
    return null;
  }
@override
  Widget build(BuildContext context) {
    return _bgWrap(Scaffold(
      backgroundColor: ((_bgPath==null||_bgPath!.isEmpty) || (_bgOpacity>=0.999)) ? _baseBg : Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(systemOverlayStyle: _opaqueBarsStyle, backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0,
        title: Row(children:[Text(widget.notebook.name), const SizedBox(width:8), Text('(${_totalCount})', style: const TextStyle(fontSize:14))]),
        actions: [
          IconButton(tooltip: '标签筛选', onPressed: _filterByTag, icon: const Icon(Icons.label_outline)),
          IconButton(tooltip: '日期定位', onPressed: _pickDay, icon: const Icon(Icons.calendar_month_outlined)),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'export') await _exportNotebook();
              if (v == 'import') await _importNotebook();
              if (v == 'mood') _openMoodTrend();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'export', child: Text('导出（JSON）')),
              PopupMenuItem(value: 'import', child: Text('导入（JSON）')),
              PopupMenuItem(value: 'mood', child: Text('心情趋势')),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: _newEntry, child: const Icon(Icons.create)),
      body: SafeArea(child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: '搜索当前日记本…',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              onSubmitted: (v) {
                _keyword = v.trim().isEmpty ? null : v.trim();
                _loadFirst();
    
    _refreshCount();
              },
            ),
          ),
          if (_tagId != null || _day != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Wrap(
                spacing: 8,
                children: [
                  if (_tagId != null)
                    Chip(
                      label: Text('标签: ${_tagName ?? _tagId}'),
                      onDeleted: () async {
                        setState(() {
                          _tagId = null;
                          _tagName = null;
                        });
                        await _loadFirst();
    
    _refreshCount();
                      },
                    ),
                  if (_day != null)
                    Chip(
                      label: Text('日期: ${DateFormat('yyyy-MM-dd').format(_day!)}'),
                      onDeleted: () async {
                        setState(() => _day = null);
                        await _loadFirst();
    
    _refreshCount();
                      },
                    ),
                ],
              ),
            ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _loadFirst,
                    child: ListView.separated(
                      controller: _scroll,
                      itemCount: _items.length + 1,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        if (i == _items.length) {
                          if (_loadingMore) {
                            return const Padding(
                              padding: EdgeInsets.all(16),
                              child: Center(child: CircularProgressIndicator()),
                            );
                          }
                          if (!_hasMore) {
                            return const Padding(
                              padding: EdgeInsets.all(16),
                              child: Center(child: Text('已经到底了')),
                            );
                          }
                          return const SizedBox(height: 56);
                        }
                        final e = _items[i];
                        return ListTile(
                          leading: _leadingForEntry(e),
                          title: Text(e.preview, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(_fmt.format(DateTime.fromMillisecondsSinceEpoch(e.entryTime))),
                          onTap: () => _openEntry(e),
                        );
                      },
                    ),
                  ),
          ),
        ],
      )),
    ));
  }
}
