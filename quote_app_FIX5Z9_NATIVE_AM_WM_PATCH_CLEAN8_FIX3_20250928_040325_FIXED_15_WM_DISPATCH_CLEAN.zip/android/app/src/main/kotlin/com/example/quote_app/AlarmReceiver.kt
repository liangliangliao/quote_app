package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

class AlarmReceiver : BroadcastReceiver() {
  override fun onReceive(ctx: Context, intent: Intent) {
    val id = intent.getIntExtra("id", 0)
    val payload = intent.getStringExtra("payload") ?: "{}"
    val o = JSONObject(payload)
    val notify = o.optBoolean("notify", true)
    if (!notify) return
    val title = o.optString("title", "提醒")
    val body  = o.optString("body",  "到点了")

    val notif = NotificationCompat.Builder(ctx, "quote_notify")
      .setSmallIcon(ctx.applicationInfo.icon)
      .setContentTitle(title)
      .setContentText(body)
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .build()
    NotificationManagerCompat.from(ctx).notify(id, notif)
  }
}
