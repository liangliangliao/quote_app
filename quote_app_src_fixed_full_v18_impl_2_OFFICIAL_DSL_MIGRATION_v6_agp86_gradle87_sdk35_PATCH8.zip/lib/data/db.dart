import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// Central database with all tables and foreign keys enabled.
class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) {
      await _ensureColumns(_db!);
      return _db!;
    }
    final dir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(dir.path, 'quotes_app.db');
    _db = await openDatabase(
      dbPath,
      version: 3,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, v) async {
        // configs
        await db.execute('''
          CREATE TABLE IF NOT EXISTS configs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_key TEXT,
            model TEXT,
            endpoint TEXT,
            background_image TEXT
          )
        ''');
        // tasks
        await db.execute('''
          CREATE TABLE IF NOT EXISTS tasks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_uid TEXT UNIQUE,
            name TEXT,
            type TEXT,                -- 'auto' | 'manual' | 'carousel'
            start_ts INTEGER NOT NULL,
            next_run_ts INTEGER,
            prompt TEXT,
            avatar_path TEXT,
            status TEXT DEFAULT 'open',
            freq_type TEXT NOT NULL DEFAULT 'daily',  -- 'daily'|'weekly'|'monthly'|'custom'
            freq_weekday INTEGER,
            freq_day_of_month INTEGER,
            freq_custom TEXT
          )
        ''');
        // quotes
        await db.execute('''
          CREATE TABLE IF NOT EXISTS quotes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_uid TEXT,
            content TEXT,
            type TEXT,            -- 'auto'|'manual'
            task_name TEXT,
            avatar_path TEXT,
            notified INTEGER DEFAULT 0,
            created_at INTEGER
          )
        ''');
        // logs
        await db.execute('''
          CREATE TABLE IF NOT EXISTS logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_uid TEXT,
            detail TEXT,
            created_at INTEGER
          )
        ''');
      },
      onOpen: (db) async {
        await _ensureColumns(db);
      },
    );
    return _db!;
  }

  static Future<void> _ensureColumns(Database db) async {
    // tasks columns
    final infoTasks = await db.rawQuery("PRAGMA table_info(tasks)");
    final colsTasks = infoTasks.map((e) => e['name'] as String).toList();
    Future<void> addCol(String sql) async => await db.execute(sql);

    if (!colsTasks.contains('start_ts')) {
      await addCol("ALTER TABLE tasks ADD COLUMN start_ts INTEGER DEFAULT 0");
    }
    if (!colsTasks.contains('next_run_ts')) {
      await addCol("ALTER TABLE tasks ADD COLUMN next_run_ts INTEGER");
    }
    if (!colsTasks.contains('freq_type')) {
      await addCol("ALTER TABLE tasks ADD COLUMN freq_type TEXT NOT NULL DEFAULT 'daily'");
    }
    if (!colsTasks.contains('freq_weekday')) {
      await addCol("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
    }
    if (!colsTasks.contains('freq_day_of_month')) {
      await addCol("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
    }
    if (!colsTasks.contains('freq_custom')) {
      await addCol("ALTER TABLE tasks ADD COLUMN freq_custom TEXT DEFAULT ''");
    }

    // configs columns
    final infoCfg = await db.rawQuery("PRAGMA table_info(configs)");
    final colsCfg = infoCfg.map((e) => e['name'] as String).toList();
    if (!colsCfg.contains('background_image')) {
      await db.execute("ALTER TABLE configs ADD COLUMN background_image TEXT");
    }
  }
}