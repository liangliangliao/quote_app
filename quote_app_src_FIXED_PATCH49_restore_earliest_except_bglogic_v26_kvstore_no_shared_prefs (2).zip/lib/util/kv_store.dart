
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class KVStore {
  static KVStore? _instance;
  Map<String, dynamic> _data = {};
  File? _file;

  KVStore._();

  static Future<KVStore> instance() async {
    if (_instance != null) return _instance!;
    final inst = KVStore._();
    await inst._init();
    _instance = inst;
    return inst;
  }

  Future<void> _init() async {
    final dir = await getApplicationDocumentsDirectory();
    _file = File('${dir.path}/prefs.json');
    if (await _file!.exists()) {
      try {
        final txt = await _file!.readAsString();
        _data = json.decode(txt) as Map<String, dynamic>;
      } catch (_) {
        _data = {};
      }
    } else {
      _data = {};
    }
  }

  Future<void> _flush() async {
    if (_file == null) return;
    try {
      await _file!.writeAsString(json.encode(_data));
    } catch (_) {}
  }

  Future<void> setInt(String key, int value) async {
    _data[key] = value;
    await _flush();
  }

  Future<void> setString(String key, String value) async {
    _data[key] = value;
    await _flush();
  }

  int? getInt(String key) {
    final v = _data[key];
    if (v is int) return v;
    if (v is String) {
      return int.tryParse(v);
    }
    return null;
  }

  String? getString(String key) {
    final v = _data[key];
    if (v == null) return null;
    return v.toString();
  }
}
