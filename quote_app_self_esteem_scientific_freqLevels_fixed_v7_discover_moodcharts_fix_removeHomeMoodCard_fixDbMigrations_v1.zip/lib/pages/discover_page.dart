import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../data/emotions.dart';
import '../utils/simple_bus.dart';

/// 发现之旅：展示当天的心情状态与时间轴
class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});

  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _EsteemPoint {
  final DateTime time;
  final double score;
  const _EsteemPoint({required this.time, required this.score});
}

class _EmotionLegendEntry {
  final String name;
  final double percent;
  final Color color;

  const _EmotionLegendEntry({
    required this.name,
    required this.percent,
    required this.color,
  });
}

class _DiscoverPageState extends State<DiscoverPage> with SingleTickerProviderStateMixin {
  Map<String, dynamic>? _latestToday;
  List<Map<String, dynamic>> _todayList = [];
  bool _loading = false;

  // 自尊分析相关状态
  String _esteemRangeKey = 'today'; // 时间范围：today / 7d / 30d
  String _esteemGranularityKey = 'record'; // record / hour / day
  List<Map<String, dynamic>> _esteemList = [];


  // 心情分享卡片相关状态（迁移自首页）
  static bool _moodCardShownThisSession = false;
  bool _moodCardVisible = false;
  bool _moodCardMounted = false;
  late final AnimationController _moodCardController;
  final TextEditingController _behaviorController = TextEditingController();
  final TextEditingController _triggerController = TextEditingController();
  final TextEditingController _thoughtController = TextEditingController();
  final TextEditingController _typeController = TextEditingController();
  EmojiItem? _selectedEmotion;
  bool _showEmojiPicker = false;
  Timer? _moodCardTimer;

  @override
  void initState() {
    super.initState();
    _moodCardController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
    _moodCardMounted = true;
    try {
      SimpleBus.navIndex.addListener(_onNavIndexChanged);
    } catch (_) {}
    // 如果启动时已经位于“发现之旅”页面，也按规则尝试弹出一次。
    _onNavIndexChanged();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
    });
    try {
      final dao = EmotionDao();
      final latest = await dao.latestToday();
      final list = await dao.listTodayOrdered();

      // 默认用“今天 + 单次记录粒度”作为自尊分析的初始数据
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final esteemRows = await dao.listByRange(start, now);

      if (!mounted) return;
      setState(() {
        _latestToday = latest;
        _todayList = list;
        _esteemList = esteemRows;
      });
    } catch (_) {
      if (!mounted) return;
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  /// 根据当前选择的时间范围重新加载自尊分析数据
  Future<void> _reloadEsteemByFilter() async {
    final dao = EmotionDao();
    final now = DateTime.now();
    DateTime start;
    switch (_esteemRangeKey) {
      case '7d':
        start = now.subtract(const Duration(days: 7));
        break;
      case '30d':
        start = now.subtract(const Duration(days: 30));
        break;
      case 'today':
      default:
        start = DateTime(now.year, now.month, now.day);
        break;
    }

    final rows = await dao.listByRange(start, now);
    if (!mounted) return;
    setState(() {
      _esteemList = rows;
    });
  }




  List<double> _rawEsteemScores() {
    if (_esteemList.isEmpty) return const <double>[];
    return _esteemList.map<double>((row) {
      final name = (row['emoji_name'] ?? '').toString();
      return estimateSelfEsteemScore(name);
    }).toList();
  }

  Map<String, List<int>> _computeEsteemStats(List<double> scores) {
    // 统计每一个“整数自尊值”在当前时间范围内出现的频率，
    // 然后按照占比区间划分到 50% / 60% / 70% / 80% / 90% 档位。
    final Map<String, List<int>> result = <String, List<int>>{
      '50': <int>[],
      '60': <int>[],
      '70': <int>[],
      '80': <int>[],
      '90': <int>[],
    };

    if (scores.isEmpty) {
      return result;
    }

    // 先统计每一个整数自尊得分出现的次数
    final Map<int, int> countByScore = <int, int>{};
    for (final s in scores) {
      final int v = s.round(); // 0~100
      if (v < 0 || v > 100) continue;
      countByScore[v] = (countByScore[v] ?? 0) + 1;
    }

    final int total = scores.length;
    if (total == 0) {
      return result;
    }

    // 将每个分数按照它在全部记录中所占的百分比分配到对应档位
    countByScore.forEach((int score, int count) {
      final double p = (count * 100.0) / total;

      // 小于 50% 的自尊水平不统计
      if (p < 50.0) {
        return;
      } else if (p >= 50.0 && p < 60.0) {
        result['50']!.add(score);
      } else if (p >= 60.0 && p < 70.0) {
        result['60']!.add(score);
      } else if (p >= 70.0 && p < 80.0) {
        result['70']!.add(score);
      } else if (p >= 80.0 && p < 90.0) {
        result['80']!.add(score);
      } else if (p >= 90.0 && p <= 100.0) {
        // 大于等于 90% 且小于等于 100%
        result['90']!.add(score);
      }
    });

    // 为了展示稳定一些，对每个档位里的自尊分数做一次排序。
    for (final key in result.keys) {
      result[key]!.sort();
    }

    return result;
  }

  
  Map<String, double> _computeBasicEsteemStats(List<double> scores) {
    if (scores.isEmpty) {
      return <String, double>{
        'min': double.nan,
        'max': double.nan,
        'avg': double.nan,
        'mid': double.nan,
      };
    }

    // 将自尊得分统一映射为 0~100 的整数，并排序，便于统计最小值 / 最大值 / 中间值 / 平均值。
    final List<int> intScores = scores
        .map((s) => s.round().clamp(0, 100))
        .toList()
      ..sort();

    final int minScore = intScores.first;
    final int maxScore = intScores.last;

    final int sum = intScores.fold<int>(0, (a, b) => a + b);
    final double avgScore = sum / intScores.length;

    double midScore;
    if (intScores.length.isOdd) {
      midScore = intScores[intScores.length ~/ 2].toDouble();
    } else {
      final int left = intScores[intScores.length ~/ 2 - 1];
      final int right = intScores[intScores.length ~/ 2];
      midScore = (left + right) / 2.0;
    }

    return <String, double>{
      'min': minScore.toDouble(),
      'max': maxScore.toDouble(),
      'avg': avgScore,
      'mid': midScore,
    };
  }


  void _onNavIndexChanged() {
    try {
      final idx = SimpleBus.navIndex.value;
      if (idx == 3) {
        _scheduleMoodCard();
      } else {
        _cancelMoodCardTimer();
      }
    } catch (_) {}
  }

  void _scheduleMoodCard() {
    if (_moodCardShownThisSession) return;
    _moodCardTimer?.cancel();
    _moodCardTimer = Timer(const Duration(seconds: 5), () {
      if (!mounted) return;
      try {
        final idx = SimpleBus.navIndex.value;
        if (idx != 3) return;
      } catch (_) {
        return;
      }
      _moodCardShownThisSession = true;
      _showMoodCard();
    });
  }

  void _cancelMoodCardTimer() {
    _moodCardTimer?.cancel();
    _moodCardTimer = null;
  }

  void _showMoodCard() {
    if (_moodCardVisible || !_moodCardMounted) {
      if (!_moodCardMounted) {
        setState(() {
          _moodCardMounted = true;
        });
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        try {
          _moodCardController.forward(from: 0);
          setState(() {
            _moodCardVisible = true;
          });
        } catch (_) {}
      });
    } else {
      try {
        _moodCardController.forward(from: 0);
      } catch (_) {}
      setState(() {
        _moodCardVisible = true;
      });
    }
  }

  Future<void> _hideMoodCard() async {
    try {
      await _moodCardController.reverse();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _moodCardVisible = false;
      _showEmojiPicker = false;
    });
  }

  Future<void> _onShareMood() async {
    final emoji = _selectedEmotion;
    if (emoji == null) {
      try {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请选择情绪状态')),
        );
      } catch (_) {}
      return;
    }
    String limit500(String s) => s.length > 500 ? s.substring(0, 500) : s;
    final behavior = limit500(_behaviorController.text.trim());
    final trigger = limit500(_triggerController.text.trim());
    final thought = limit500(_thoughtController.text.trim());
    final type = limit500(_typeController.text.trim());
    try {
      await EmotionDao().insert(
        emojiChar: emoji.char,
        emojiName: emoji.name,
        emojiTags: emoji.tags,
        behavior: behavior,
        triggerEvent: trigger,
        thought: thought,
        type: type,
      );
    } catch (_) {}
    await _hideMoodCard();
    _behaviorController.clear();
    _triggerController.clear();
    _thoughtController.clear();
    _typeController.clear();
    setState(() {
      _selectedEmotion = null;
    });
  }

  Widget _buildMoodCardOverlay() {
    if (!_moodCardMounted) return const SizedBox.shrink();
    return Positioned.fill(
      child: IgnorePointer(
        ignoring: !_moodCardVisible,
        child: AnimatedBuilder(
          animation: _moodCardController,
          builder: (context, child) {
            final slide = Tween<Offset>(
              begin: const Offset(0, -1),
              end: Offset.zero,
            ).animate(
              CurvedAnimation(
                parent: _moodCardController,
                curve: Curves.easeOutCubic,
                reverseCurve: Curves.easeInCubic,
              ),
            );
            return Stack(
              children: [
                GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: _hideMoodCard,
                  child: Container(color: Colors.transparent),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: SlideTransition(
                    position: slide,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 40, left: 16, right: 16),
                      child: _buildMoodCard(),
                    ),
                  ),
                ),
                if (_showEmojiPicker)
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 40),
                      child: _buildEmojiPicker(),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildMoodCard() {
    final emoji = _selectedEmotion;
    final String emojiSummary = emoji == null
        ? ''
        : '${emoji.char}  ${emoji.name}  ${emoji.tags.join(' ')}';
    return Material(
      elevation: 12,
      borderRadius: BorderRadius.circular(16),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            if (_showEmojiPicker) {
              setState(() {
                _showEmojiPicker = false;
              });
            }
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    '分享此时此刻的心情',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    tooltip: '关闭',
                    onPressed: _hideMoodCard,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Center(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _showEmojiPicker = true;
                    });
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('情绪'),
                      const SizedBox(width: 12),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 260),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: const BoxDecoration(
                            border: Border(
                              bottom: BorderSide(color: Colors.black54, width: 1),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child: Text(
                                  emojiSummary,
                                  style: const TextStyle(fontSize: 14),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Icon(Icons.expand_more, size: 18),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              _buildTextRow(
                label: '行为',
                controller: _behaviorController,
                hint: '例如：我选择了拖延、争吵或积极面对...',
              ),
              const SizedBox(height: 8),
              _buildTextRow(
                label: '事件',
                controller: _triggerController,
                hint: '例如：上司的批评、工作任务堆积、人际冲突...',
              ),
              const SizedBox(height: 8),
              _buildTextRow(
                label: '认知',
                controller: _thoughtController,
                hint: '例如：我认为自己不够好、别人都在否定我...',
              ),
              const SizedBox(height: 8),
              _buildTextRow(
                label: '类型',
                controller: _typeController,
                hint: '例如：可能来自生活、工作、他人、自我...',
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _onShareMood,
                  child: const Text('分享'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextRow({
    required String label,
    required TextEditingController controller,
    String? hint,
  }) {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label),
          const SizedBox(width: 12),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 260),
            child: TextField(
              controller: controller,
              maxLines: null,
              maxLength: 500,
              decoration: InputDecoration(
                isDense: true,
                counterText: '',
                border: const UnderlineInputBorder(),
                hintText: hint,
                filled: false,
                fillColor: null,
                hintStyle: const TextStyle(color: Colors.grey),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmojiPicker() {
    return Material(
      elevation: 8,
      borderRadius: BorderRadius.circular(16),
      color: Colors.white,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: SizedBox(
          height: 230,
          child: GridView.count(
            padding: const EdgeInsets.fromLTRB(4, 12, 4, 0),
            crossAxisCount: 6,
            mainAxisSpacing: 0,
            crossAxisSpacing: 0,
            childAspectRatio: 0.9,
            physics: const AlwaysScrollableScrollPhysics(),
            children: [
              for (final item in unicornEmotions)
                InkWell(
                  onTap: () {
                    setState(() {
                      _selectedEmotion = item;
                      _showEmojiPicker = false;
                    });
                  },
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        item.char,
                        style: const TextStyle(fontSize: 20),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.name,
                        style: const TextStyle(fontSize: 11),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

DateTime? _parseInsertedAt(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return null;
    try {
      return DateTime.parse(insertedAt);
    } catch (_) {
      return null;
    }
  }

  /// 根据当前选择的粒度构建自尊曲线数据点。
  List<_EsteemPoint> _buildEsteemPoints() {
    if (_esteemList.isEmpty) return const <_EsteemPoint>[];

    // 逐条记录：直接按照每条记录的情绪计算自尊指数
    if (_esteemGranularityKey == 'record') {
      final List<_EsteemPoint> points = [];
      for (final row in _esteemList) {
        final dt = _parseInsertedAt(row['inserted_at']?.toString()) ?? DateTime.now();
        final name = (row['emoji_name'] ?? '').toString();
        final score = estimateSelfEsteemScore(name);
        points.add(_EsteemPoint(time: dt, score: score));
      }
      points.sort((a, b) => a.time.compareTo(b.time));
      return points;
    }

    // 按小时 / 按天聚合：在时间窗内收集所有情绪名称，用 computeSelfEsteemIndexFromEmotions 算出该时间窗的自尊指数
    final Map<String, List<String>> bucketNames = {};
    final Map<String, DateTime> bucketTime = {};

    for (final row in _esteemList) {
      final dt = _parseInsertedAt(row['inserted_at']?.toString());
      if (dt == null) continue;

      DateTime bucket;
      if (_esteemGranularityKey == 'day') {
        bucket = DateTime(dt.year, dt.month, dt.day);
      } else {
        bucket = DateTime(dt.year, dt.month, dt.day, dt.hour);
      }
      final key = bucket.toIso8601String();
      final name = (row['emoji_name'] ?? '').toString();
      if (name.isEmpty) continue;

      bucketNames.putIfAbsent(key, () => <String>[]).add(name);
      bucketTime[key] = bucket;
    }

    final keys = bucketNames.keys.toList()
      ..sort((a, b) => bucketTime[a]!.compareTo(bucketTime[b]!));

    final List<_EsteemPoint> points = [];
    for (final key in keys) {
      final names = bucketNames[key]!;
      if (names.isEmpty) continue;
      final score = computeSelfEsteemIndexFromEmotions(names);
      points.add(_EsteemPoint(time: bucketTime[key]!, score: score));
    }

    points.sort((a, b) => a.time.compareTo(b.time));
    return points;
  }

  String _formatTime(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return '';
    // 期望格式：YYYY-MM-DD HH:mm:ss
    final parts = insertedAt.split(' ');
    if (parts.length < 2) return insertedAt;
    return parts[1];
  }

  List<List<Map<String, dynamic>>> _chunkEmotions(List<Map<String, dynamic>> src, int size) {
    if (src.isEmpty) return <List<Map<String, dynamic>>>[];
    final List<List<Map<String, dynamic>>> rows = [];
    for (var i = 0; i < src.length; i += size) {
      final end = (i + size < src.length) ? i + size : src.length;
      rows.add(src.sublist(i, end));
    }
    return rows;
  }

  Widget _buildTimelineRow(List<Map<String, dynamic>> rowItems) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 时间轴横线 + 表情在上方
          SizedBox(
            height: 36,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned.fill(
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      height: 1,
                      color: Colors.black26,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    for (final item in rowItems)
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Text(
                              (item['emoji_char'] ?? '').toString(),
                              style: const TextStyle(fontSize: 22),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          // 时间显示在横线下方
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              for (final item in rowItems)
                Text(
                  _formatTime(item['inserted_at']?.toString()),
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.black54,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTimeline(List<Map<String, dynamic>> items) {
    if (items.isEmpty) {
      return const Text(
        '今天还没有记录心情，回到首页试试分享你的此时此刻吧～',
        style: TextStyle(fontSize: 13, color: Colors.black54),
      );
    }
    final rows = _chunkEmotions(items, 4);
    // 计算是否需要垂直滚动：超过 3 行时开启
    final bool needScroll = rows.length > 3;

    final timelineColumn = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final r in rows) _buildTimelineRow(r),
      ],
    );

    if (!needScroll) {
      return timelineColumn;
    } else {
      return SizedBox(
        // 每行高度约 56 左右，3 行 + 边距
        height: 56.0 * 3,
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: timelineColumn,
        ),
      );
    }
  }



  Widget _buildEsteemFilterBar() {
    return Row(
      children: [
        Expanded(
          child: DropdownButton<String>(
            value: _esteemRangeKey,
            isExpanded: true,
            items: const [
              DropdownMenuItem(
                value: 'today',
                child: Text('今天'),
              ),
              DropdownMenuItem(
                value: '7d',
                child: Text('近7天'),
              ),
              DropdownMenuItem(
                value: '30d',
                child: Text('近30天'),
              ),
            ],
            onChanged: (value) {
              if (value == null) return;
              setState(() {
                _esteemRangeKey = value;
              });
              _reloadEsteemByFilter();
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: DropdownButton<String>(
            value: _esteemGranularityKey,
            isExpanded: true,
            items: const [
              DropdownMenuItem(
                value: 'record',
                child: Text('逐条记录'),
              ),
              DropdownMenuItem(
                value: 'hour',
                child: Text('按小时'),
              ),
              DropdownMenuItem(
                value: 'day',
                child: Text('按天'),
              ),
            ],
            onChanged: (value) {
              if (value == null) return;
              setState(() {
                _esteemGranularityKey = value;
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _buildEsteemLineChart() {
    final points = _buildEsteemPoints();
    if (points.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final spots = <FlSpot>[];
    for (var i = 0; i < points.length; i++) {
      spots.add(FlSpot(i.toDouble(), points[i].score));
    }

    // 纵轴固定在 0~100 区间，方便直观感知自尊得分所处位置。
    double yMin = 0;
    double yMax = 100;
    final double yInterval = 10;

    String formatBottomLabel(int index) {
      if (index < 0 || index >= points.length) return '';
      final t = points[index].time;
      if (_esteemGranularityKey == 'day') {
        // 仅显示月-日，保持简洁。
        return '${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      } else {
        // 小时粒度或更细时统一使用 HH:mm，避免过长的时间字符串被截断。
        return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
      }
    }

    return SizedBox(
      height: 220,
      child: LineChart(
        LineChartData(
          // 向左右各扩展一点，避免首尾标签被裁剪
          minX: -0.5,
          maxX: (points.length - 1).toDouble() + 0.5,
          minY: yMin,
          maxY: yMax,
          gridData: FlGridData(show: true),
          borderData: FlBorderData(show: true),
          titlesData: FlTitlesData(
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              axisNameWidget: const Text(
                '自尊值',
                style: TextStyle(fontSize: 11),
              ),
              axisNameSize: 28,
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 36,
                interval: yInterval,
                getTitlesWidget: (value, meta) {
                  // 只显示间隔为 10 的刻度文本，避免纵坐标文字过于密集重叠。
                  final int v = value.toInt();
                  if (v % 10 != 0) {
                    return const SizedBox.shrink();
                  }
                  return Text(
                    v.toString(),
                    style: const TextStyle(fontSize: 10),
                  );
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: points.length <= 6 ? 1 : (points.length / 6).ceilToDouble(),
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();
                  final label = formatBottomLabel(index);
                  if (label.isEmpty) {
                    return const SizedBox.shrink();
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      label,
                      style: const TextStyle(fontSize: 8),
                      textAlign: TextAlign.center,
                    ),
                  );
                },
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              spots: spots,
              dotData: FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEsteemStatsView() {
    final scores = _rawEsteemScores();
    if (_esteemList.isEmpty || scores.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Text(
          '当前时间范围内还没有足够的数据用于统计',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    // 使用新的频率分档统计：50% / 60% / 70% / 80% / 90%
    final Map<String, List<int>> buckets = _computeEsteemStats(scores);
    // 基础统计：最小值 / 中间值 / 最大值 / 平均值
    final Map<String, double> basic = _computeBasicEsteemStats(scores);

    String joinBucketValues(String key) {
      final values = buckets[key] ?? <int>[];
      if (values.isEmpty) {
        return '--';
      }
      final sorted = List<int>.from(values)..sort();
      return sorted.join('，');
    }

    String fmtDouble(double? v, int fractionDigits) {
      if (v == null || v.isNaN) return '--';
      return v.toStringAsFixed(fractionDigits);
    }

    // 更加类似 Excel 的行列布局，将所有指标放在一个表格中，支持左右滑动。
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        columnSpacing: 24,
        headingRowHeight: 32,
        dataRowMinHeight: 28,
        dataRowMaxHeight: 36,
        border: TableBorder.all(color: Colors.black12),
        columns: const <DataColumn>[
          DataColumn(
            label: Text(
              '指标',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
          DataColumn(label: Text('50%')),
          DataColumn(label: Text('60%')),
          DataColumn(label: Text('70%')),
          DataColumn(label: Text('80%')),
          DataColumn(label: Text('90%')),
          DataColumn(label: Text('最小值')),
          DataColumn(label: Text('中间值')),
          DataColumn(label: Text('最大值')),
          DataColumn(label: Text('平均值')),
        ],
        rows: <DataRow>[
          DataRow(
            cells: <DataCell>[
              const DataCell(Text('自尊水平值')),
              DataCell(Text(joinBucketValues('50'))),
              DataCell(Text(joinBucketValues('60'))),
              DataCell(Text(joinBucketValues('70'))),
              DataCell(Text(joinBucketValues('80'))),
              DataCell(Text(joinBucketValues('90'))),
              DataCell(Text(fmtDouble(basic['min'], 0))),
              DataCell(Text(fmtDouble(basic['mid'], 1))),
              DataCell(Text(fmtDouble(basic['max'], 0))),
              DataCell(Text(fmtDouble(basic['avg'], 1))),
            ],
          ),
        ],
      ),
    );
  }



Widget _buildEmotionPieChart() {
    if (_esteemList.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final Map<String, int> counts = {};
    for (final row in _esteemList) {
      final name = (row['emoji_name'] ?? '').toString();
      if (name.isEmpty) continue;
      counts[name] = (counts[name] ?? 0) + 1;
    }
    if (counts.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final total = counts.values.fold<int>(0, (a, b) => a + b);
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final legendEntries = <_EmotionLegendEntry>[];
    const palette = <Color>[
      Color(0xFF26C6DA),
      Color(0xFFAB47BC),
      Color(0xFFFFA726),
      Color(0xFF66BB6A),
      Color(0xFFEC407A),
      Color(0xFF7E57C2),
      Color(0xFFFF7043),
      Color(0xFF29B6F6),
    ];

    for (var i = 0; i < entries.length; i++) {
      final e = entries[i];
      final double percent = total == 0 ? 0 : (e.value * 100.0 / total);
      final Color color = palette[i % palette.length];

      legendEntries.add(
        _EmotionLegendEntry(
          name: e.key,
          percent: percent,
          color: color,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 220,
          child: BarChart(
            BarChartData(
              maxY: 100,
              minY: 0,
              gridData: FlGridData(show: true),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 30,
                    interval: 20,
                    getTitlesWidget: (value, meta) {
                      final v = value.toInt();
                      if (v % 20 != 0) {
                        return const SizedBox.shrink();
                      }
                      return Text(
                        '$v%',
                        style: const TextStyle(fontSize: 10),
                      );
                    },
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final index = value.toInt();
                      if (index < 0 || index >= entries.length) {
                        return const SizedBox.shrink();
                      }
                      final name = entries[index].key;
                      return Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          name,
                          style: const TextStyle(fontSize: 9),
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    },
                  ),
                ),
              ),
              barGroups: [
                for (var i = 0; i < entries.length; i++)
                  BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: total == 0 ? 0 : (entries[i].value * 100.0 / total),
                        color: palette[i % palette.length],
                        width: 14,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 12,
          runSpacing: 4,
          children: legendEntries
              .map<Widget>(
                (_EmotionLegendEntry item) => Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: item.color,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${item.name} ${item.percent.toStringAsFixed(0)}%',
                      style: const TextStyle(fontSize: 11),
                    ),
                  ],
                ),
              )
              .toList(),
        ),
      ],
    );
  }


  Widget _buildEsteemAnalyticsCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7F7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '自尊分析',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          _buildEsteemFilterBar(),
          const SizedBox(height: 8),
          _buildEsteemLineChart(),
          const SizedBox(height: 8),
          _buildEsteemStatsView(),
          const SizedBox(height: 16),
          const Text(
            '自尊得分根据情绪在「正向 / 负向 + 与自尊相关程度」两维度上的加权平均得到，'
            '积极、自我肯定情绪（如自信、胜利）会提高得分，羞愧、自卑等自我意识负性情绪会拉低得分；'
            '当找不到对应情绪定义时，会使用中性得分 50。',
            style: TextStyle(fontSize: 11, color: Colors.black54),
          ),
          const SizedBox(height: 12),
          const Text(
            '情绪分布（百分比）',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          _buildEmotionPieChart(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    try {
      SimpleBus.navIndex.removeListener(_onNavIndexChanged);
    } catch (_) {}
    _cancelMoodCardTimer();
    try {
      _moodCardController.dispose();
    } catch (_) {}
    _behaviorController.dispose();
    _triggerController.dispose();
    _thoughtController.dispose();
    _typeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final latest = _latestToday;
    final String moodLine;
    if (latest == null) {
      moodLine = '当下心情：今天还没有记录心情';
    } else {
      final name = (latest['emoji_name'] ?? '').toString();
      final char = (latest['emoji_char'] ?? '').toString();
      moodLine = '当下心情：$name $char';
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text(
          '发现之旅',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Stack(
          children: [
            RefreshIndicator(
              onRefresh: _load,
              child: _loading && _todayList.isEmpty && _latestToday == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 10),
                          // 当下心情文本
                          Text(
                            moodLine,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          // 当天所有情绪图标 + 时间轴
                          _buildTimeline(_todayList),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildEsteemAnalyticsCard(),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.assignment_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '问卷调查',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.flag_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '愿景与目标',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.self_improvement, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '冥想',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.note_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '记事本',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
            ),
            _buildMoodCardOverlay(),
          ],
        ),
      ),
    );
  }
}