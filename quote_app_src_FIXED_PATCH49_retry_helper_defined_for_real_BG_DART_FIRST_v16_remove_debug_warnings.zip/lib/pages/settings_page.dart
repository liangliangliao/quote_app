
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TaskDao _taskDao = TaskDao();
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final rows = await _taskDao.all();
    setState(() { _tasks = rows; });
  }

  Future<String?> _saveAvatarTemp(File f) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final target = File('${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png');
      await f.copy(target.path);
      return target.path;
    } catch (_) {
      return null;
    }
  }

  TimeOfDay? _parseTimeOfDay(String s) {
    if (s.isEmpty) return null;
    try {
      final parts = s.split(' ');
      final hm = parts.last.split(':');
      return TimeOfDay(hour: int.parse(hm[0]), minute: int.parse(hm[1]));
    } catch (_) { return null; }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: _tasks.length,
        itemBuilder: (ctx, i) {
          final t = _tasks[i];
          return Card(
            child: ListTile(
              title: Text((t['name'] ?? '') as String, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('时间: ${(t['start_time'] ?? '') as String}  类型: ${(t['type'] ?? '') as String}  频率: ${(t['freq_type'] ?? 'daily') as String}  状态: ${(t['status'] ?? '') as String}'),
              onTap: () => _openTaskDialog(task: t),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(icon: const Icon(Icons.edit), onPressed: () => _openTaskDialog(task: t)),
                  IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
                    await _taskDao.delete((t['task_uid'] ?? '') as String);
                    await SchedulerService.scheduleNextForAll();
                    _reload();
                  }),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }

  Future<void> _openTaskDialog({Map<String, dynamic>? task}) async {
    final bool isEdit = task != null;
    String name = isEdit ? (task['name'] ?? '') as String : '';
    String type = isEdit ? (task['type'] ?? 'manual') as String : 'manual'; // manual / auto / carousel
    String status = isEdit ? (task['status'] ?? 'on') as String : 'on';     // on / off
    String prompt = isEdit ? (task['prompt'] ?? '') as String : '';
    String manualQuote = '';

    // 回显手动任务名言（仅显示在编辑时）
    if (isEdit && type == 'manual' && (task['task_uid'] != null)) {
      final mq = await QuoteDao().latestForTask(task['task_uid'] as String);
      manualQuote = (mq?['content'] ?? '') as String;
    }

    String avatarPath = isEdit ? (task['avatar_path'] ?? '') as String : '';

    // 频率
    String freqType = isEdit ? (task['freq_type'] ?? 'daily') as String : 'daily'; // daily/weekly/monthly
    int? selectedWeekday = (task?['freq_weekday'] as int?);
    int? selectedMonthDay = (task?['freq_day_of_month'] as int?);
    TimeOfDay time = _parseTimeOfDay((task?['start_time'] ?? '') as String) ?? const TimeOfDay(hour: 9, minute: 0);

    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (ctx, setStateDialog) {
            String two(int n)=> n.toString().padLeft(2,'0');
            return AlertDialog(
              title: Text(isEdit ? '编辑任务' : '新增任务'),
              content: SingleChildScrollView(
                child: Form(
                  key: formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('任务标题'),
                      TextFormField(
                        initialValue: name,
                        onChanged: (v)=> name = v,
                        validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务标题' : null,
                      ),
                      const SizedBox(height: 10),
                      const Text('任务类型'),
                      DropdownButton<String>(
                        value: type,
                        onChanged: (v){ setStateDialog(()=> type = v ?? 'manual'); },
                        items: const [
                          DropdownMenuItem(value: 'manual', child: Text('手动')),
                          DropdownMenuItem(value: 'auto', child: Text('自动')),
                          DropdownMenuItem(value: 'carousel', child: Text('轮播')),
                        ],
                      ),
                      const SizedBox(height: 10),
                      const Text('频率'),
                      DropdownButton<String>(
                        value: freqType,
                        onChanged: (v){ setStateDialog(()=> freqType = v ?? 'daily'); },
                        items: const [
                          DropdownMenuItem(value: 'daily', child: Text('每天')),
                          DropdownMenuItem(value: 'weekly', child: Text('每周')),
                          DropdownMenuItem(value: 'monthly', child: Text('每月')),
                        ],
                      ),
                      if (freqType == 'weekly') ...[
                        const SizedBox(height: 8),
                        const Text('选择星期'),
                        DropdownButton<int>(
                          value: selectedWeekday ?? 1,
                          onChanged: (v){ setStateDialog(()=> selectedWeekday = v ?? 1); },
                          items: const [
                            DropdownMenuItem(value: 1, child: Text('周一')),
                            DropdownMenuItem(value: 2, child: Text('周二')),
                            DropdownMenuItem(value: 3, child: Text('周三')),
                            DropdownMenuItem(value: 4, child: Text('周四')),
                            DropdownMenuItem(value: 5, child: Text('周五')),
                            DropdownMenuItem(value: 6, child: Text('周六')),
                            DropdownMenuItem(value: 7, child: Text('周日')),
                          ],
                        ),
                      ],
                      if (freqType == 'monthly') ...[
                        const SizedBox(height: 8),
                        const Text('选择日期'),
                        DropdownButton<int>(
                          value: (selectedMonthDay ?? 1).clamp(1, 31),
                          onChanged: (v){ setStateDialog(()=> selectedMonthDay = v ?? 1); },
                          items: [
                            for (int d=1; d<=31; d++) DropdownMenuItem(value: d, child: Text('$d 日'))
                          ],
                        ),
                      ],
                      const SizedBox(height: 10),
                      const Text('每日时间'),
                      TextButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(context: ctx, initialTime: time);
                          if (picked != null) setStateDialog(()=> time = picked);
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text('${two(time.hour)}:${two(time.minute)}'),
                      ),
                      if (type == 'auto' || type == 'carousel') ...[
                        const SizedBox(height: 8),
                        const Text('提示词'),
                        TextFormField(
                          initialValue: prompt,
                          onChanged: (v)=> prompt = v,
                          minLines: 2,
                          maxLines: null,
                          keyboardType: TextInputType.multiline,
                        ),
                      ],
                      if (type == 'manual') ...[
                        const SizedBox(height: 8),
                        const Text('名言内容'),
                        TextFormField(
                          initialValue: manualQuote,
                          onChanged: (v)=> manualQuote = v,
                          validator: (v)=> (type=='manual' && (v==null || v.trim().isEmpty)) ? '请输入名言内容' : null,
                          minLines: 3,
                          maxLines: null,
                          keyboardType: TextInputType.multiline,
                        ),
                      ],
                      const SizedBox(height: 8),
                      const Text('头像（用于通知图标）'),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundImage: (avatarPath.isNotEmpty && File(avatarPath).existsSync())
                              ? FileImage(File(avatarPath)) : null,
                            child: (avatarPath.isEmpty || !File(avatarPath).existsSync())
                              ? const Icon(Icons.person) : null,
                          ),
                          const SizedBox(width: 8),
                          OutlinedButton.icon(
                            onPressed: () async {
                              final picker = ImagePicker();
                              final x = await picker.pickImage(source: ImageSource.gallery);
                              if (x != null) {
                                final p = await _saveAvatarTemp(File(x.path));
                                setStateDialog(()=> avatarPath = p ?? '');
                              }
                            },
                            icon: const Icon(Icons.photo),
                            label: const Text('选择图片'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(onPressed: ()=> Navigator.of(dialogCtx).pop(), child: const Text('取消')),
                ElevatedButton(
                  onPressed: () async {
                    if (!(formKey.currentState?.validate() ?? false)) return;
                    String two(int n)=> n.toString().padLeft(2,'0');
                    final DateTime now0 = DateTime.now();
                    final DateTime startTime = DateTime(now0.year, now0.month, now0.day, time.hour, time.minute);
                    final startTimeStr = '${startTime.year}-${two(startTime.month)}-${two(startTime.day)} ${two(startTime.hour)}:${two(startTime.minute)}';

                    String? uid;
                    if (isEdit) {
                      uid = task!['task_uid'] as String;
                      await _taskDao.update(uid, {
                        'name': name,
                        'type': type,
                        'start_time': startTimeStr,
                        'prompt': prompt,
                        'avatar_path': avatarPath,
                        'status': status,
                        'freq_type': freqType,
                        'freq_weekday': selectedWeekday,
                        'freq_day_of_month': selectedMonthDay,
                      });
                    } else {
                      uid = await _taskDao.create(
                        name: name,
                        type: type,
                        startTime: startTime,
                        prompt: prompt,
                        avatarPath: avatarPath,
                        status: status,
                        freqType: freqType,
                        freqWeekday: selectedWeekday,
                        freqDayOfMonth: selectedMonthDay,
                        freqCustom: '',
                      );
                    }

                    if (type=='manual' && manualQuote.trim().isNotEmpty) {
                      await QuoteDao().insertIfUnique(
                        taskUid: uid!,
                        type: type,
                        taskName: name,
                        avatarPath: avatarPath,
                        content: manualQuote.trim(),
                      );
                    }
                    await SchedulerService.scheduleNextForAll();
                    if (mounted) {
                      Navigator.of(dialogCtx).pop();
                      _reload();
                    }
                  },
                  child: const Text('保存'),
                ),
              ],
            );
          },
        );
      }
    );
  }
}
