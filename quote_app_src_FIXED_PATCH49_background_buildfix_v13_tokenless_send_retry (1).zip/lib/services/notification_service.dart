import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static bool get isReady => _inited;

  /// 在后台回调中反复尝试初始化通知插件，直到就绪或重试次数用尽。
  static Future<bool> ensureReady({int tries = 10, Duration delay = const Duration(milliseconds: 600)}) async {
    if (_inited) return true;
    for (var i = 0; i < tries; i++) {
      try { await init(); } catch (_) {}
      if (_inited) return true;
      await Future.delayed(delay);
    }
    return _inited;
  }

  static bool get isReady => _inited;
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  static Future<void> init() async {
    if (_inited) return;
    try {
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    const settings = InitializationSettings(android: android, iOS: ios);
    await _plugin.initialize(settings);
    // Android 13+ runtime notifications permission
    try {
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}

    final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl != null) {
      const channel = AndroidNotificationChannel(
        'quotes_channel',
        '名言通知',
        description: '任务触发时展示名言',
        importance: Importance.high,
      );
      try { await androidImpl.createNotificationChannel(channel); } catch (_) {}
    }
    _inited = true;
    } catch (e) {
      _inited = false;
      rethrow;
    }
  }

  static Future<void> show({
    required int id,
    required String title,
    required String body,
    String? largeIconPath,
  }) async {
    await init();

    const style = BigTextStyleInformation('');
    final AndroidBitmap<Object>? largeIcon = (largeIconPath != null && largeIconPath.isNotEmpty && File(largeIconPath).existsSync())
        ? FilePathAndroidBitmap(largeIconPath)
        : null;

    final androidDetails = AndroidNotificationDetails(
      'quotes_channel',
      '名言通知',
      channelDescription: '任务触发时展示名言',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: style,
      largeIcon: largeIcon,
      icon: '@mipmap/ic_launcher',
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: const DarwinNotificationDetails(),
    );

    await _plugin.show(id, title, body, details);
  }
}