
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// Central database with all new tables and foreign keys enabled.
/// Version history:
/// v3 -> introduce new tables: configs, tasks, quotes, logs (replacing old schedules/settings).
class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 3,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON;');
      },
      onCreate: (db, v) async {
        await _createAll(db);
        await _seedDefaults(db);
      },
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 3) {
          // Rename old tables if exist to avoid conflicts
          await db.execute('DROP TABLE IF EXISTS schedules');
          await db.execute('DROP TABLE IF EXISTS settings');
          await db.execute('DROP TABLE IF EXISTS quotes');
          await _createAll(db);
          await _seedDefaults(db);
        }
      },
    );
    return _db!;
  }

  static Future<void> _createAll(Database db) async {
    // configs
    await db.execute('''
      CREATE TABLE configs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        api_key TEXT DEFAULT '',
        model TEXT DEFAULT 'gpt-5',
        endpoint TEXT DEFAULT '',
        background_image TEXT DEFAULT ''
      )
    ''');
    await db.insert('configs', {
      'api_key': '',
      'model': 'gpt-5',
      'endpoint': '',
      'background_image': ''
    });

    // tasks
    await db.execute('''
      CREATE TABLE tasks(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        type TEXT NOT NULL,         -- auto | manual | carousel
        start_time TEXT NOT NULL,   -- ISO local time like "2025-09-11 12:00"
        prompt TEXT DEFAULT '',
        avatar_path TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'open', -- open | closed
        freq_type TEXT NOT NULL DEFAULT 'daily',
        freq_weekday INTEGER,
        freq_day_of_month INTEGER,
        freq_custom TEXT DEFAULT ''
      )
    ''');

    // quotes
    await db.execute('''
      CREATE TABLE quotes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_uid TEXT UNIQUE NOT NULL,
        task_uid TEXT,
        content TEXT NOT NULL,
        type TEXT NOT NULL,          -- same as task type at time of insert
        notified INTEGER NOT NULL DEFAULT 0,
        task_name TEXT DEFAULT '',
        avatar_path TEXT DEFAULT '',
        created_at INTEGER NOT NULL,
        FOREIGN KEY(task_uid) REFERENCES tasks(task_uid) ON DELETE SET NULL
      )
    ''');
    await db.execute('CREATE UNIQUE INDEX IF NOT EXISTS uq_quote_content ON quotes(content)');

    // logs
    await db.execute('''
      CREATE TABLE logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_uid TEXT UNIQUE NOT NULL,
        task_uid TEXT,
        detail TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        FOREIGN KEY(task_uid) REFERENCES tasks(task_uid) ON DELETE SET NULL
      )
    ''');
  }

  static Future<void> _seedDefaults(Database db) async {
    // default quote for testing
    await db.insert('quotes', {
      'quote_uid': 'qseed-1',
      'task_uid': null,
      'content': '凡是不能杀死我的，必使我更坚强。\n—— 弗里德里希·尼采，《偶像的黄昏》\n\n📖 解释：\n尼采想表达的是：生活中的痛苦、挫折和困难，并不会彻底摧毁我们，反而会让我们成长，获得更强的韧性和力量。换句话说，经历苦难是让人更加坚强的重要途径。',
      'type': 'manual',
      'notified': 0,
      'task_name': '默认示例',
      'avatar_path': '',
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
  }



  static Future<void> _ensureColumns(Database db) async {
    // Add new scheduling columns if missing
    final info = await db.rawQuery("PRAGMA table_info(tasks)");
    final cols = info.map((e)=> e['name'] as String).toList();
    if (!cols.contains('freq_type')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT NOT NULL DEFAULT 'daily'");
    }
    if (!cols.contains('freq_weekday')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
    }
    if (!cols.contains('freq_day_of_month')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
    }
    if (!cols.contains('freq_custom')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT DEFAULT ''");
    }
  }
}
