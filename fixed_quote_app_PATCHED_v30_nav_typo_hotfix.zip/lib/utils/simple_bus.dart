
// Lightweight navigation bus to let services navigate without a BuildContext.
import 'package:flutter/material.dart';

class SimpleBus {
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  /// Navigate to home (root '/') and clear back stack.
  static void navHome() {
    final state = navigatorKey.currentState;
    if (state == null) return;
    state.pushNamedAndRemoveUntil('/', (route) => false);
  }
}
