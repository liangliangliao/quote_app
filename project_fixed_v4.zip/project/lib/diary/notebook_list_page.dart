import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'diary_dao.dart';
import 'notebook_page.dart';

class DiaryNotebookListPage extends StatefulWidget {
  const DiaryNotebookListPage({super.key});

  @override
  State<DiaryNotebookListPage> createState() => _DiaryNotebookListPageState();
}

class _DiaryNotebookListPageState extends State<DiaryNotebookListPage> {
  final _dao = DiaryDao();
  bool _loading = true;
  List<Notebook> _items = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await _dao.ensureSchema();
      final list = await _dao.listNotebooks();
      setState(() {
        _items = list;
        _loading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _create() async {
    final ctrl = TextEditingController();
    final name = await showDialog<String?>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('新增日记本'),
        content: TextField(controller: ctrl, decoration: const InputDecoration(hintText: '输入日记本名称')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, null), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, ctrl.text), child: const Text('保存')),
        ],
      ),
    );
    if ((name ?? '').trim().isEmpty) return;
    await _dao.createNotebook(name!.trim());
    await _init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('日记本'),
        // Fix: status bar icons (battery/time) were invisible on some
        // diary pages due to an implicit SystemUiOverlayStyle overriding
        // the global overlay style.
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
          statusBarBrightness: Brightness.light,
        ),
      ),
      floatingActionButton: FloatingActionButton(onPressed: _create, child: const Icon(Icons.add)),
      // User wants no extra blank space above Android system navigation keys.
      body: SafeArea(bottom: false, top: false, child: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : RefreshIndicator(
                  onRefresh: _init,
                  child: ListView.separated(
                    itemCount: _items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final n = _items[i];
                      return ListTile(
                        title: Text(n.name),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NotebookPage(notebook: n))),
                      );
                    },
                  ),
                ),
      ),
    );
  }
}
