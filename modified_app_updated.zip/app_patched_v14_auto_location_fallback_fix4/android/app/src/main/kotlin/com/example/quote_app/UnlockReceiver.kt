package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import kotlin.concurrent.thread
import android.os.Handler
import android.os.Looper
import com.example.quote_app.data.DbRepo

/**
 * 解锁广播入口：
 * 1) 优先检查配置表中的地点规则开关；若关闭，直接返回（不触发已有的解锁轻提醒链路）
 * 2) 若开启，立即启动前台服务 GeoForegroundService 执行定位与提醒（不进入 WorkManager）
 * 3) 所有关键步骤写中文日志
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val appCtx = context.applicationContext
    // 线程1：地点规则通知提醒
    kotlin.concurrent.thread(name = "unlock-geo-thread") {
      try {
        // 检查地点规则开关
        var enabled = false
        try {
          val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(appCtx)
          if (cc != null && cc.dbPath != null) {
            val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
            try {
              db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
                if (c.moveToFirst()) enabled = (c.getInt(0) == 1)
              }
            } finally { try { db.close() } catch (_: Throwable) {} }
          }
        } catch (e: Throwable) {
          // 读取异常视为关闭
          enabled = false
          logWithTime(appCtx, "【解锁后台】读取地点规则开关异常，按关闭处理")
        }
        if (!enabled) {
          logWithTime(appCtx, "【解锁后台】地点规则开关=关闭，直接返回；不触发地点提醒")
          return@thread
        }
        // 开关开启，启动前台服务
        try {
          val svc = Intent(appCtx, GeoForegroundService::class.java)
          if (Build.VERSION.SDK_INT >= 26) {
            appCtx.startForegroundService(svc)
          } else {
            appCtx.startService(svc)
          }
          logWithTime(appCtx, "【解锁后台】已启动 GeoForegroundService 前台服务进行定位与提醒")
          // Toast 必须在主线程调用
          android.os.Handler(android.os.Looper.getMainLooper()).post {
            try { Toast.makeText(appCtx, "正在执行地点提醒...", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
          }
        } catch (t: Throwable) {
          logWithTime(appCtx, "【解锁后台】启动 GeoForegroundService 失败：" + (t.message ?: "unknown"))
        }
      } catch (t: Throwable) {
        // 捕获所有异常，避免线程崩溃
        try { logWithTime(appCtx, "【解锁后台】地点提醒线程异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      }
    }
    // 线程2：解锁轻提醒
    kotlin.concurrent.thread(name = "unlock-light-thread") {
      try {
        // 直接调用现有触发逻辑（WorkManager），保持业务不变
        try {
          UnlockWorker.trigger(appCtx)
        } catch (e: Throwable) {
          logWithTime(appCtx, "【解锁后台】触发 UnlockWorker 失败：" + (e.message ?: "unknown"))
        }
      } catch (t: Throwable) {
        try { logWithTime(appCtx, "【解锁后台】解锁轻提醒线程异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      }
    }
  }

  /**
   * 写入包含时间戳的日志。
   */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
