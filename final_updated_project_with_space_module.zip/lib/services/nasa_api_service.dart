import 'dart:convert';
import 'package:http/http.dart' as http;

/// A simple service for fetching astronomy pictures from NASA's public APIs.
///
/// This service currently exposes methods to retrieve the Astronomy Picture
/// of the Day (APOD) for a single day or a range of dates. The API key
/// must be provided by callers. NASA provides generous rate limits for
/// personal keys; if you do not supply a key your requests will fall back
/// to the built in demo key which is more restricted.
///
/// See: https://api.nasa.gov/#apod for full documentation.
class NasaApiService {
  /// Your NASA API key. See https://api.nasa.gov for instructions on
  /// generating a key. If omitted the service will use the public demo
  /// key which is subject to stricter rate limits.
  final String apiKey;

  NasaApiService({required this.apiKey});

  static const String _baseUrl = 'https://api.nasa.gov/planetary/apod';

  /// Fetches the APOD for today. If the network request fails an
  /// [Exception] is thrown. On success a single [Apod] object is
  /// returned.
  Future<Apod> fetchTodayApod() async {
    final uri = Uri.parse('$_baseUrl?api_key=$apiKey');
    final res = await http.get(uri);
    if (res.statusCode != 200) {
      throw Exception('NASA API error: ${res.statusCode}, ${res.body}');
    }
    final Map<String, dynamic> data = jsonDecode(res.body);
    return Apod.fromJson(data);
  }

  /// Fetches APOD entries between [startDate] and [endDate] inclusive.
  /// The NASA API supports returning a list of results when both
  /// `start_date` and `end_date` are supplied. If the response body is
  /// not a list a single element list will be returned.
  Future<List<Apod>> fetchApods({required DateTime startDate, required DateTime endDate}) async {
    final start = _formatDate(startDate);
    final end = _formatDate(endDate);
    final uri = Uri.parse('$_baseUrl?api_key=$apiKey&start_date=$start&end_date=$end');
    final res = await http.get(uri);
    if (res.statusCode != 200) {
      throw Exception('NASA API error: ${res.statusCode}, ${res.body}');
    }
    final body = res.body;
    final decoded = jsonDecode(body);
    if (decoded is List) {
      return decoded.map<Apod>((e) => Apod.fromJson(e as Map<String, dynamic>)).toList();
    } else if (decoded is Map<String, dynamic>) {
      return [Apod.fromJson(decoded)];
    }
    throw Exception('Unexpected NASA API response format');
  }

  String _formatDate(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }
}

/// A model representing NASA's Astronomy Picture of the Day entry.
///
/// Most APOD entries are images but the API also returns videos on
/// occasion; callers should check [mediaType] and handle non‑image
/// entries appropriately.
class Apod {
  final String date;
  final String title;
  final String explanation;
  final String mediaType;
  final String url;
  final String? hdUrl;

  Apod({
    required this.date,
    required this.title,
    required this.explanation,
    required this.mediaType,
    required this.url,
    this.hdUrl,
  });

  factory Apod.fromJson(Map<String, dynamic> json) {
    return Apod(
      date: (json['date'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      explanation: (json['explanation'] ?? '').toString(),
      mediaType: (json['media_type'] ?? '').toString(),
      url: (json['url'] ?? '').toString(),
      hdUrl: json['hdurl']?.toString(),
    );
  }
}