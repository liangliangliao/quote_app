import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import '../services/nasa_api_service.dart';
import 'apod_detail_page.dart';

/// A page for exploring NASA's Astronomy Picture of the Day (APOD).
///
/// When first opened the page fetches the last 30 days of APOD entries
/// using the provided API key. Results are displayed in reverse
/// chronological order with the newest entry first. Tapping an item
/// opens a detailed view showing the full image and description.
class SpaceExplorerPage extends StatefulWidget {
  const SpaceExplorerPage({super.key});

  @override
  State<SpaceExplorerPage> createState() => _SpaceExplorerPageState();
}

class _SpaceExplorerPageState extends State<SpaceExplorerPage> {
  // Replace this with your own API key. If left empty the NASA demo
  // key will be used but may be subject to rate limiting. The user
  // supplied key is passed down through this field.
  static const String _nasaApiKey = 'yl0Zwzo2DiDT6BvM3ITCieFjuiGhhgjFvak56sRS';

  late final NasaApiService _service;
  List<Apod> _apods = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = NasaApiService(apiKey: _nasaApiKey);
    _loadApods();
  }

  Future<void> _loadApods() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final now = DateTime.now();
      // Fetch the last 30 days of APODs including today.
      final start = now.subtract(const Duration(days: 29));
      final results = await _service.fetchApods(startDate: start, endDate: now);
      // Sort results in descending date order.
      results.sort((a, b) => b.date.compareTo(a.date));
      if (mounted) {
        setState(() {
          _apods = results;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('看宇宙', style: TextStyle(color: Colors.black87)),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loading ? null : _loadApods,
          ),
        ],
      ),
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '加载宇宙图片失败\n$_error',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _loadApods,
                child: const Text('重试'),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.separated(
      itemCount: _apods.length,
      separatorBuilder: (context, index) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final apod = _apods[index];
        // Show a different leading widget for video entries. NASA
        // occasionally posts videos.
        final bool isImage = apod.mediaType == 'image';
        return ListTile(
          leading: isImage
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    apod.url,
                    width: 64,
                    height: 64,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return const SizedBox(
                        width: 64,
                        height: 64,
                        child: Center(
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      );
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return const SizedBox(
                        width: 64,
                        height: 64,
                        child: Center(child: Icon(Icons.broken_image)),
                      );
                    },
                  ),
                )
              : const Icon(Icons.videocam_outlined, size: 32),
          title: Text(apod.title),
          subtitle: Text(apod.date),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.of(context).push(
              CupertinoPageRoute(
                builder: (_) => ApodDetailPage(apod: apod),
              ),
            );
          },
        );
      },
    );
  }
}