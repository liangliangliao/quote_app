import 'package:sqflite/sqflite.dart';
import '../data/db.dart';
import '../utils/debug_logger.dart';

class RunGuard {
  static Future<void> _ensure(Database db) async {
    await db.execute(
      "CREATE TABLE IF NOT EXISTS run_guard("
      "uid TEXT NOT NULL,"
      "run_key TEXT NOT NULL,"
      "source TEXT,"
      "ts INTEGER DEFAULT (strftime('%s','now')),"
      "PRIMARY KEY(uid, run_key)"
      ")"
    );
  }

  /// 返回 true 表示本次是首次执行；false 表示重复（应跳过）。
  static Future<bool> begin(String uid, String runKey, {String source = ''}) async {
    final db = await AppDatabase.instance();
    await _ensure(db);
    try {
      await db.insert('run_guard', {
        'uid': uid,
        'run_key': runKey,
        'source': source,
        'ts': DateTime.now().millisecondsSinceEpoch
      });
      return true;
    } catch (e) {
      await DLog.w('RunGuard', 'dup run suppressed uid=$uid runKey=$runKey src=$source');
      return false;
    }
  }
}
