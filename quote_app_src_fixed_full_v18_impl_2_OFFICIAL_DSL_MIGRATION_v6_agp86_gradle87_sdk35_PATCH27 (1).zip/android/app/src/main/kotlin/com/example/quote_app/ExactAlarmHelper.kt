package com.example.quote_app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

object ExactAlarmHelper {
    fun requestExactAlarmAndBatteryWhitelist(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
            }
            val p = context.packageName
            val i2 = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$p"))
            i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i2)
        } catch (e: Exception) {
            try {
                val i3 = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                i3.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i3)
            } catch (_: Exception) {}
        }
    }
}
