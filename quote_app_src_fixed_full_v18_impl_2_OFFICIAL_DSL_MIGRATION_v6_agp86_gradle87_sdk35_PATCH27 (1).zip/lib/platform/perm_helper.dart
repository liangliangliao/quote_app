import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<void> requestExactAlarmAndBatteryWhitelist() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmAndBatteryWhitelist');
    } catch (_) {}
  }
}
