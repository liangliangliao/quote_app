import 'diary/diary_dao.dart';
import 'diary/notebook_page.dart';
import 'diary/notebook_list_page.dart';
import 'diary/diary_theme.dart';
import './services/native_guard.dart';
import 'services/native_sport_fg.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:path/path.dart' as p;
import 'dart:isolate';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'package:workmanager/workmanager.dart';

import 'data/db.dart';
import 'data/dao.dart';
import 'data/sport_dao.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'services/wm_dispatcher.dart';
import 'background_tasks.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';
import 'pages/notepad_page.dart';
import 'pages/discover_page.dart';
import 'belief_lab/belief_lab_home.dart';
import 'services/native_guard.dart';
import 'utils/debug_logger.dart';
import 'platform/perm_helper.dart';
import 'platform/native_scheduler.dart';

Future<bool> _guardDiaryTab(BuildContext context) async {
  try {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery("SELECT diary_pin FROM configs WHERE diary_pin IS NOT NULL AND diary_pin != '' ORDER BY id DESC LIMIT 1");
    if (rows.isEmpty) return true;
    final pin = (rows.first['diary_pin'] ?? '').toString();
    if (pin.isEmpty) return true;

    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('输入日记 PIN'),
        content: TextField(
          controller: ctrl,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 4,
          decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '4位数字'),
        ),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(_, false), child: const Text('取消')),
          FilledButton(onPressed: ()=>Navigator.pop(_, ctrl.text.trim()==pin), child: const Text('确定')),
        ],
      ),
    );
    return ok == true;
  } catch (_) {
    return true;
  }
}



Future<void> _navToHomeIfLaunchedFromNotification() async {
  final plugin = FlutterLocalNotificationsPlugin();
  final details = await plugin.getNotificationAppLaunchDetails();
  if (details?.didNotificationLaunchApp ?? false) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      try { NativeGuard.ensureRuntimeReceiversRegistered(); } catch (_) {}
      SimpleBus.navHome();
      SimpleBus.pokeHome();
    });
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  NativeGuard.ensureNotificationTapHandler();
  
  await NotificationService.captureInitialLaunchFromNotification();
try {
    const MethodChannel _sys = MethodChannel('com.example.quote_app/sys');
    await _sys.invokeMethod('createNoMediaGuards');
  try { await NativeGuard.ensureRuntimeReceiversRegistered(); } catch (_) {}
  } catch (_) {}

	// Enable edge-to-edge. We still keep default system bar colors white.
	// Diary pages may set bars to transparent to let background images cover them.
	await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
	SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
	  statusBarColor: Colors.transparent,
	  statusBarIconBrightness: Brightness.dark,
	  statusBarBrightness: Brightness.light,
	  systemNavigationBarColor: Colors.transparent,
	  systemNavigationBarDividerColor: Colors.transparent,
	));
  ui.DartPluginRegistrant.ensureInitialized();
  /* moved to post-frame */ AppDatabase.instance(); // warm-up (non-blocking)

  // Sport safety net:
  // - If a sport is still in progress, ensure Android native foreground tracking keeps running.
  //   (iOS cannot keep tracking after user force-quits from app switcher.)
  try {
    final rec = await SportDao().getLatestUnfinishedRecord();
    if (rec != null && (rec['status'] ?? '').toString() == 'in_progress' && (Platform.isAndroid || Platform.isIOS)) {
      final rid = (rec['id'] is num) ? (rec['id'] as num).toInt() : int.tryParse(rec['id']?.toString() ?? '');
      if (rid != null) {
        await NativeSportFg.ensureStarted(
            recordId: rid,
            title: (rec['title'] ?? '运动进行中').toString(),
            targetType: rec['target_type']?.toString(),
            targetValue: (rec['target_value'] is num) ? (rec['target_value'] as num).toDouble() : double.tryParse(rec['target_value']?.toString() ?? ''),
            targetUnit: rec['target_unit']?.toString(),
          );
      }
    }
  } catch (_) {}

  // Schedule a daily midnight renewal alarm (native side will renew plans even if process is killed).
  // This is best-effort; if exact alarm permission is missing, native side may fall back to WM.
  try {
    final now = DateTime.now();
    final nextMidnight = DateTime(now.year, now.month, now.day).add(const Duration(days: 1));
    await NativeScheduler.scheduleExactAt(
      id: 1800000000,
      epochMs: nextMidnight.millisecondsSinceEpoch + 1000,
      payload: const {'type': 'sport_midnight_renew'},
    );
  } catch (_) {}

  // Ensure auxiliary columns exist (scheduled_run_key, next_time).  This should
  // be called once after opening the database to migrate older installations.
  
  // CHECK_NOTIF_AND_NAV_HOME: post-frame ensure notification launch always goes to Home
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    final fromNotif = NotificationService.consumeLaunchFromNotificationFlag();
    if (fromNotif) {
      try {
        await DLog.i('NotifTap', 'main() postFrame: fromNotif=true -> navHome');
      } catch (_) {}
      SimpleBus.navHome();
      SimpleBus.pokeHome();
    }
  });
  runApp(const MyApp());
  _navToHomeIfLaunchedFromNotification();

  // Do heavy initializations after first frame to avoid splash卡住
  Future.microtask(() async {
    try { await ensureExtraTaskColumns(); } catch (_) {}
    try { await NotificationService.init(); } catch (_) {}
    try { await SchedulerService.init(); } catch (_) {}
    // 预加载日记背景配置到内存，避免日记页面首次进入时出现背景闪烁
    try { await DiaryTheme.reloadFromDatabase(); } catch (_) {}
    try { Workmanager().initialize(workmanagerCallbackDispatcher, isInDebugMode: false); } catch (_) {}
    try { SimpleBus.init(); } catch (_) {}
    try { _registerHomeRefreshPort(); } catch (_) {}
  });

}


class NoOverscrollBehavior extends MaterialScrollBehavior {
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) {
    return child; // 禁用全局overscroll指示
  }
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
		// Keep system navigation bar white by default. Some diary pages with a
		// configured background image may override it to transparent.
		return AnnotatedRegion<SystemUiOverlayStyle>(
			value: const SystemUiOverlayStyle(
				statusBarColor: Colors.transparent,
				statusBarIconBrightness: Brightness.dark,
				statusBarBrightness: Brightness.light,
				systemNavigationBarColor: Colors.transparent,
				systemNavigationBarDividerColor: Colors.transparent,
			),
			child: MaterialApp(
				navigatorKey: SimpleBus.navigatorKey,
				scrollBehavior: NoOverscrollBehavior(),
				title: '',
				theme: ThemeData(
					scaffoldBackgroundColor: Colors.white,
					useMaterial3: true,
					colorSchemeSeed: Colors.indigo,
					// 底部导航组件背景保持白色，避免出现异常底色
					navigationBarTheme: NavigationBarThemeData(
						backgroundColor: Colors.white,
						indicatorColor: Colors.white,
						labelTextStyle: MaterialStateProperty.all(
							const TextStyle(color: Colors.black87),
						),
						iconTheme: MaterialStateProperty.all(
							const IconThemeData(color: Colors.black87),
						),
						elevation: 0,
						surfaceTintColor: Colors.transparent,
						shadowColor: Colors.transparent,
						height: 64,
					),
					dividerColor: Colors.transparent,
					dividerTheme: const DividerThemeData(
						color: Colors.transparent,
						thickness: 0,
						space: 0,
					),
				),
				home: const GateKeeper(),
			),
		);
  }
}

class GateKeeper extends StatefulWidget {
  const GateKeeper({super.key});
  @override
  State<GateKeeper> createState() => _GateKeeperState();
}

class _GateKeeperState extends State<GateKeeper> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _checkPerms();
  }

  Future<void> _checkPerms() async {
    // 第一道门卡：系统通知权限
    final hasNoti = await _areNotificationsEnabled();
    if (!hasNoti) {
      // 直接触发系统通知授权弹框，无自定义弹框
      try {
        // /* EARLY-BLOCKED */ // REMOVED: early notification request (only request after Home visible)
/* END */  // removed: request only after Home is visible // 非阻塞，避免按Home后恢复黑屏/卡顿
      } catch (_) {}
      // 再次检查，如果仍未授权，则尝试打开系统设置界面
      final stillNo = !(await _areNotificationsEnabled());
      if (stillNo) {
        try { await _openNotificationSettings(); } catch (_) {}
      }
    }

      /* DEFER_EXACT_TO_HOME_START */
if (false) {
// 第二道门卡：精确闹钟权限（仅 Android，仅首次打开弹框）
  final _first = await _isFirstOpenAndMark();
  if (_first) {
// 第二道门卡：精确闹钟权限（仅 Android）
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact && mounted) {
      final allow = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx)=> AlertDialog(
          title: const Text('闹钟提醒权限授权'),
          content: const Text('为确保定点提醒，请授予“闹钟与提醒(精确闹钟)”权限。'),
          actions: [
            TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('不允许')),
            FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('允许')),
          ],
        ),
      );
      if (allow == true) {
        await PermHelper.requestExactAlarmPermission();
        // 返回键回到此处后直接进入首页
  } // 非首次：跳过弹框
      } else {
        // 小确认框：是 / 否
        final go = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx)=> AlertDialog(
            content: const Text('你将不启用精准闹钟提醒功能！'),
            actions: [
              TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('否')),
              FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('是')),
            ],
          ),
        );
        if (go != true) {
          // 停留在当前闹钟提醒框层面（重新弹出第二道门卡）
          _checkPerms();
          return;
        }
      }
    }

    
}
/* DEFER_EXACT_TO_HOME_END */
setState(()=> _ready = true);
  }

  Future<bool> _areNotificationsEnabled() async {
    try {
      const ch = MethodChannel('com.example.quote_app/sys');
      final ok = await ch.invokeMethod<bool>('areNotificationsEnabled');
      return ok ?? true;
    } catch (_) {
      // 如果原生未实现，默认通过（实际发送时也会失败不崩溃）
      return true;
    }
  }

  Future<void> _openNotificationSettings() async {
    try {
      const ch = MethodChannel('com.example.quote_app/sys');
      await ch.invokeMethod('openNotificationSettings');
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      // 加载页面（权限检查）阶段恢复为默认白色背景
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return const RootShell();
  }
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});
  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _idx = 0;
  int _diarySeed = 0; // force rebuild diary tab after unlock (fix first-load blank)


Future<void> _handleSelectTab(int i) async {
  if (i == 1) {
    final ok = await _guardDiaryTab(context);
    if (!ok) return;
    // Ensure diary schema is ready and force rebuild diary tab (fix first-load blank after PIN)
    try { await DiaryDao().ensureSchema(); } catch (_) {}
    _diarySeed++;
  }
  if (!mounted) return;
  setState(() { _idx = i; });
  try { SimpleBus.navIndex.value = i; } catch (_) {}
  if (i == 5) { SimpleBus.pokeLogs(); }
  if (i == 0) { try { SimpleBus.pokeHome(); } catch (_) {} }
}

  @override
  void initState() {
    super.initState();
    SchedulerService.scheduleNextForAll();
    // Ensure runtime unlock receivers on first launch (post-frame)
    Future.delayed(const Duration(milliseconds: 80), () { try { NativeGuard.ensureRuntimeReceiversRegistered(); } catch (_) {} });
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try {
      final launchedViaPlugin = await NotificationService.didLaunchFromNotification();
      final launchedViaFlag   = NotificationService.consumeLaunchFromNotificationFlag();
      final viaNativeChannel  = await NativeGuard.consumeLaunchFromNotificationFlag();
      if (launchedViaPlugin || launchedViaFlag || viaNativeChannel) {
        try {
          await DLog.i(
            'NotifTap',
            'RootShell postFrame: plugin=$launchedViaPlugin flag=$launchedViaFlag native=$viaNativeChannel -> navHome',
          );
        } catch (_) {}
        SimpleBus.navHome();
      }
    } catch (_) {}
  });
    // Navigate to home if launched from notification (foreground/background/terminated)
    Future.delayed(const Duration(milliseconds: 60), () {
      try {
        if (NotificationService.consumeLaunchFromNotificationFlag()) {
          try {
            DLog.i('NotifTap', 'RootShell delayed check: flag=true -> navHome');
          } catch (_) {}
          SimpleBus.navHome();
        }
      } catch (_) {}
    });
    // Listen for navigation requests (e.g., notification taps)
    SimpleBus.navIndex.addListener(() {
      final i = SimpleBus.navIndex.value;
      if (i >= 0 && i != _idx) {
        setState(() { _idx = i; });
  try { SimpleBus.navIndex.value = i; } catch (_) {}
  if (i == 5) { SimpleBus.pokeLogs(); }
        if (i == 0) { try { SimpleBus.pokeHome(); } catch (_) {} }
      }
    });
    // 主动清理可能残留的自检任务（自检已禁用）
    SchedulerService.scheduleSelfCheck();
  
    try { SimpleBus.navIndex.value = _idx; } catch (_) {}
}

  @override
  Widget build(BuildContext context) {
    final _pages = [
      const HomePage(),
      DiaryNotebookListPage(key: ValueKey('diary_' + _diarySeed.toString())),
      const HistoryPage(),
      const DiscoverPage(),
      const BeliefLabHomePage(),
      const LogsPage(),
      const SettingsPage(),
    ];
    return Scaffold(
      drawerScrimColor: Colors.black54,
      drawer: Builder(
        builder: (context) {
          final w = MediaQuery.of(context).size.width * 0.75;
          return Drawer(
            width: w,
            elevation: 0,
            child: SafeArea(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                children: const [
                  SizedBox(height: 8),
                  Text('GPT', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                  SizedBox(height: 8),
                  Divider(),
                  ListTile(leading: Icon(Icons.tune), title: Text('样式调整与通知跳转')),
                  ListTile(leading: Icon(Icons.bug_report), title: Text('App功能修复分析')),
                  ListTile(leading: Icon(Icons.system_update), title: Text('R13 补丁更新')),
                  ListTile(leading: Icon(Icons.dashboard_customize), title: Text('修改需求解决方案')),
                  ListTile(leading: Icon(Icons.account_balance), title: Text('银行项目测试账户类型')),
                  ListTile(leading: Icon(Icons.psychology), title: Text('意识与潜意识冲突')),
                  ListTile(leading: Icon(Icons.rule), title: Text('潜意识觉察量表')),
                ],
              ),
            ),
          );
        },
      ),
      backgroundColor: Colors.white,
      // 使用 IndexedStack 保持各页面的状态，避免切换时重新构建导致白屏或闪烁
      body: IndexedStack(index: _idx, children: _pages),
      bottomNavigationBar: SafeArea(
        top: false,
        child: SizedBox(
        height: 60, // reduce bottom bar height by another 10 (total -20)
        child: NavigationBar(        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,

        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.note), label: '写日记'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.travel_explore), label: '发现之旅'),
          NavigationDestination(icon: Icon(Icons.psychology_alt_outlined), label: '信念实验室'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) { _handleSelectTab(i); },
      ),
        ),
      ),
    );
  }
}


void _registerHomeRefreshPort() {
  const name = 'HOME_REFRESH_PORT';
  try { ui.IsolateNameServer.removePortNameMapping(name); } catch (_) {}
  final port = ReceivePort();
  ui.IsolateNameServer.registerPortWithName(port.sendPort, name);
  port.listen((_) {
    try { SimpleBus.pokeHome(); } catch (_) {}
  });
}

Future<bool> _isFirstOpenAndMark() async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final f = File(p.join(dir.path, '.first_open_done'));
    if (await f.exists()) return false;
    await f.writeAsString(DateTime.now().toIso8601String());
    return true;
  } catch (_) { return false; }
}
