package com.example.quote_app.biz;

import android.content.Context;
import android.text.TextUtils;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.data.DbRepository.Task;

import java.util.List;

public final class Biz {
    private Biz() {}

    /** 主入口：根据任务类型执行并发送通知；返回是否已处理 */
    public static boolean run(Context ctx, String uid) {
        Task t = DbRepository.getTaskByUid(ctx, uid);
        if (t == null || !t.enabled) {
            DbRepository.log(ctx, uid, "任务关闭或不存在，跳过");
            return false;
        }
        String type = t.type == null ? "MANUAL" : t.type.toUpperCase();
        switch (type) {
            case "AUTO":
                return autoTask(ctx, t);
            case "CAROUSEL":
                return carouselTask(ctx, t);
            default:
                return manualTask(ctx, t);
        }
    }

    private static boolean manualTask(Context ctx, Task t) {
        // For manual tasks the quote text is stored in the quotes table rather than directly in Task.content.
        // If the task content is empty, fetch the latest quote for this task from the database.
        String content = t.content;
        try {
            if (content == null || content.trim().isEmpty()) {
                java.util.List<String> quotes = DbRepository.listQuoteTextsForTask(ctx, t.uid, 1);
                if (quotes != null && !quotes.isEmpty()) {
                    content = quotes.get(0);
                }
            }
        } catch (Throwable ignore) {
            // ignore any DB errors and fall back to original content
        }
        if (content == null || content.trim().isEmpty()) {
            DbRepository.log(ctx, t.uid, "手动任务无名人名言内容");
            return false;
        }
        String title = !TextUtils.isEmpty(pickedTitle) ? pickedTitle : (!TextUtils.isEmpty(t.title) ? t.title : "提醒");
        int id = t.uid != null ? t.uid.hashCode() : 10001;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, (pickedAvatar!=null ? pickedAvatar : t.avatarPath));
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "发送失败: " + e.getMessage());
            return false;
        }
    }

    private static boolean carouselTask(Context ctx, Task t) {
        String content = DbRepository.getCarouselNextQuote(ctx, t.uid);
        if (TextUtils.isEmpty(content)) content = (pickedContent!=null ? pickedContent : t.content);
        String title = !TextUtils.isEmpty(pickedTitle) ? pickedTitle : (!TextUtils.isEmpty(t.title) ? t.title : "提醒");
        int id = t.uid != null ? t.uid.hashCode() : 10003;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, (pickedAvatar!=null ? pickedAvatar : t.avatarPath));
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "发送失败: " + e.getMessage());
            return false;
        }
    }

    private static boolean autoTask(Context ctx, Task t) {
        // 简化：此处不直接联网上游 API，先用任务内容或最近一条名言回退
        String content = null;
        List<String> recent = DbRepository.listQuoteTextsForTask(ctx, t.uid, 1);
        
        // 按任务类型与游标选择将要发送的名人名言（降序 + OFFSET 游标；批量/自动限定 task_uid；轮播全表；手动按 task_uid 单条）
        String[] pick = DbRepository.selectQuoteForNotify(ctx, uid);
        if (pick == null) {
            // 已在 selectQuoteForNotify 内写入中文错误日志并标记失败返回
            return false;
        }
        String pickedTitle = pick[0];
        String pickedContent = pick[1];
        String pickedAvatar = pick[2];
if (!recent.isEmpty()) content = recent.get(0);
        if (TextUtils.isEmpty(content)) content = (pickedContent!=null ? pickedContent : t.content);
        String title = !TextUtils.isEmpty(pickedTitle) ? pickedTitle : (!TextUtils.isEmpty(t.title) ? t.title : "提醒");
        int id = t.uid != null ? t.uid.hashCode() : 10002;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, (pickedAvatar!=null ? pickedAvatar : t.avatarPath));
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "发送失败: " + e.getMessage());
            return false;
        }
    }
}
