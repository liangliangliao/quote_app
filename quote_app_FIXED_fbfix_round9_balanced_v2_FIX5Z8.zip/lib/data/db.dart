import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 4,
      onCreate: _create,
      onUpgrade: (db, oldV, newV) async {
        await _ensureColumns(db);
        await db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
      },
    );
    await _db!.execute('PRAGMA foreign_keys = ON');
    await _ensureColumns(_db!);
    return _db!;
  }

  static Future<void> _create(Database db, int version) async {
    await db.execute('''
      CREATE TABLE configs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        api_key TEXT,
        model TEXT,
        endpoint TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT UNIQUE,
        name TEXT,
        type TEXT,
        start_time TEXT,
        prompt TEXT,
        avatar_path TEXT,
        status TEXT,
        freq_type TEXT NOT NULL DEFAULT 'daily',
        freq_weekday INTEGER,
        freq_day_of_month INTEGER,
        freq_custom TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_uid TEXT UNIQUE,
        task_uid TEXT,
        content TEXT,
        notified INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER
      )
    ''');

    await db.execute('''
      CREATE TABLE logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_uid TEXT UNIQUE,
        task_uid TEXT,
        detail TEXT,
        created_at INTEGER,
        task_name_snapshot TEXT,
        task_start_time_snapshot TEXT
      )
    ''');

    await db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
  }

  static Future<void> _ensureColumns(Database db) async {
    // tasks table
    final infoT = await db.rawQuery("PRAGMA table_info(tasks)");
    final tcols = infoT.map((e)=> e['name'] as String).toList();
    if (!tcols.contains('freq_type')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT NOT NULL DEFAULT 'daily'");
    }
    if (!tcols.contains('freq_weekday')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
    }
    if (!tcols.contains('freq_day_of_month')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
    }
    if (!tcols.contains('freq_custom')) {
      await db.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT DEFAULT ''");
    }

    // logs table snapshots
    final infoL = await db.rawQuery("PRAGMA table_info(logs)");
    final lcols = infoL.map((e)=> e['name'] as String).toList();
    if (!lcols.contains('task_name_snapshot')) {
      await db.execute("ALTER TABLE logs ADD COLUMN task_name_snapshot TEXT");
    }
    if (!lcols.contains('task_start_time_snapshot')) {
      await db.execute("ALTER TABLE logs ADD COLUMN task_start_time_snapshot TEXT");
    }
  }
}
// ensure pending_run table
/* MIGRATION NOTE: pending_run(uid TEXT PRIMARY KEY, run_key TEXT, wm_unique TEXT, alarm_id INTEGER) */
