import 'package:flutter/services.dart';
import 'package:quote_app/utils/debug_logger.dart';

class NativeAm {
  static const _ch = MethodChannel('com.example.quote_app/sys');
  static Future<bool> cancelExactById(String uid, String? runKey) async {
    try {
      await DLog.i('SCH', '【Dart→原生】AM 取消请求 uid='+uid+' run='+(runKey ?? ''));
      final ret = await _ch.invokeMethod('cancelExactById', {'uid': uid, 'runKey': runKey});
      return ret == true;
    } catch (_) { return false; }
  }
}


  /// 统一身份证取消（首选）
  static Future<bool> cancelByIdCard(String idCard) async {
    try {
      await DLog.i('SCH', '【Dart→原生】AM 取消请求(身份证)='+idCard);
      const ch2 = MethodChannel('native.scheduler');
      final ret = await ch2.invokeMethod('cancelByIdCard', {'id_card': idCard});
      return ret == true;
    } catch (_) { return false; }
  }
