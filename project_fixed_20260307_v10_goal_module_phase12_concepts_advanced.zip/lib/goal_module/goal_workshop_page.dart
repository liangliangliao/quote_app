import 'package:flutter/material.dart';

import 'goal_dao.dart';
import 'goal_models.dart';

class GoalWorkshopPage extends StatefulWidget {
  final String? entryNote;

  const GoalWorkshopPage({super.key, this.entryNote});

  @override
  State<GoalWorkshopPage> createState() => _GoalWorkshopPageState();
}

class _GoalWorkshopPageState extends State<GoalWorkshopPage> {
  final _dao = GoalDao();
  final _identity = TextEditingController();
  final _vision = TextEditingController();
  final _why = TextEditingController();
  final _realityProblem = TextEditingController();
  final _lifeline = TextEditingController();
  final _weeklyGoal = TextEditingController();
  final _firstStep = TextEditingController();
  final _ifThen = TextEditingController();
  double _stretch = 5;
  bool _loading = true;
  bool _saving = false;
  int _step = 0;

  GoalWorkshopDraft _snapshot = GoalWorkshopDraft.empty();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final draft = await _dao.getWorkshopDraft();
    _snapshot = draft;
    _identity.text = draft.identityStatement;
    _vision.text = draft.vision;
    _why.text = draft.whyText;
    _realityProblem.text = draft.realityProblem;
    _lifeline.text = draft.lifeline;
    _weeklyGoal.text = draft.weeklyGoal;
    _firstStep.text = draft.firstStep;
    _ifThen.text = draft.ifThenText;
    _stretch = draft.stretchScore;
    if (mounted) setState(() => _loading = false);
  }

  GoalWorkshopDraft _buildDraft() {
    return GoalWorkshopDraft(
      identityStatement: _identity.text.trim(),
      vision: _vision.text.trim(),
      whyText: _why.text.trim(),
      realityProblem: _realityProblem.text.trim(),
      lifeline: _lifeline.text.trim(),
      stretchScore: _stretch,
      weeklyGoal: _weeklyGoal.text.trim(),
      firstStep: _firstStep.text.trim(),
      ifThenText: _ifThen.text.trim(),
      updatedAtMs: DateTime.now().millisecondsSinceEpoch,
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final draft = _buildDraft();
    await _dao.saveWorkshopDraft(
      identityStatement: draft.identityStatement,
      vision: draft.vision,
      whyText: draft.whyText,
      realityProblem: draft.realityProblem,
      lifeline: draft.lifeline,
      stretchScore: draft.stretchScore,
      weeklyGoal: draft.weeklyGoal,
      firstStep: draft.firstStep,
      ifThenText: draft.ifThenText,
    );
    _snapshot = draft;
    if (!mounted) return;
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('目标工坊已保存')));
  }

  @override
  void dispose() {
    _identity.dispose();
    _vision.dispose();
    _why.dispose();
    _realityProblem.dispose();
    _lifeline.dispose();
    _weeklyGoal.dispose();
    _firstStep.dispose();
    _ifThen.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('目标工坊')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                if ((widget.entryNote ?? '').trim().isNotEmpty) ...[
                  _noticeCard(widget.entryNote!.trim()),
                  const SizedBox(height: 12),
                ],
                _heroCard(_buildDraft()),
                const SizedBox(height: 12),
                _stepper(),
                const SizedBox(height: 12),
                ..._stepCards(),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _step == 0 ? null : () => setState(() => _step -= 1),
                        icon: const Icon(Icons.chevron_left),
                        label: const Text('上一步'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _saving
                            ? null
                            : () async {
                                if (_step < 3) {
                                  setState(() => _step += 1);
                                } else {
                                  await _save();
                                }
                              },
                        icon: _saving
                            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                            : Icon(_step < 3 ? Icons.chevron_right : Icons.save_outlined),
                        label: Text(_saving ? '保存中…' : (_step < 3 ? '下一步' : '保存工坊')),
                      ),
                    ),
                  ],
                ),
              ],
            ),
    );
  }

  Widget _noticeCard(String text) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFECFDF5),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFA7F3D0)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.move_down_outlined, color: Color(0xFF065F46)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(height: 1.55, color: Color(0xFF065F46), fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _heroCard(GoalWorkshopDraft draft) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('从“想要一个目标”到“能真正执行的目标”', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text(
            '这一页把课程里的目标思想压成四步：身份与方向、why 与现实问题、生命线与拉伸度、每周推进与 if-then。',
            style: TextStyle(height: 1.6, color: Color(0xFF4B5563)),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _scoreCard('完成度', '${(draft.completionRate * 100).round()}%')),
              const SizedBox(width: 10),
              Expanded(child: _scoreCard('一致性分', '${draft.consistencyScore}')),
            ],
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: draft.completionRate,
            minHeight: 10,
            borderRadius: BorderRadius.circular(99),
            backgroundColor: const Color(0xFFE5E7EB),
          ),
          if (_snapshot.updatedAtMs > 0) ...[
            const SizedBox(height: 10),
            Text(
              '上次保存：${DateTime.fromMillisecondsSinceEpoch(_snapshot.updatedAtMs).toLocal().toString().substring(0, 16)}',
              style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
            ),
          ],
        ],
      ),
    );
  }

  Widget _scoreCard(String label, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        decoration: BoxDecoration(color: const Color(0xFFF9FAFB), borderRadius: BorderRadius.circular(16)),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
          ],
        ),
      );

  Widget _stepper() {
    const labels = ['方向', 'why', '拉力', '执行'];
    return Row(
      children: List.generate(labels.length, (i) {
        final active = i == _step;
        final done = i < _step;
        return Expanded(
          child: Column(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: done || active ? const Color(0xFF111827) : Colors.white,
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: active ? const Color(0xFF111827) : const Color(0xFFD1D5DB)),
                ),
                child: Center(
                  child: Text(
                    '${i + 1}',
                    style: TextStyle(color: done || active ? Colors.white : const Color(0xFF6B7280), fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(labels[i], style: TextStyle(fontWeight: active ? FontWeight.w800 : FontWeight.w600, color: const Color(0xFF374151))),
            ],
          ),
        );
      }),
    );
  }

  List<Widget> _stepCards() {
    switch (_step) {
      case 0:
        return [
          _fieldCard(
            title: '1. 我想成为什么样的人',
            subtitle: '先把目标和身份连接起来，而不是只写一件待办。',
            child: _textField(_identity, hint: '例如：成为一个更诚实行动、持续推进长期目标的人'),
          ),
          const SizedBox(height: 12),
          _fieldCard(
            title: '2. 我真正想追求的目标',
            subtitle: '写出你此刻最想认真面对的一件事。',
            child: _textField(_vision, hint: '例如：建立更像自己的职业路径 / 连续8周完成健康训练计划'),
          ),
        ];
      case 1:
        return [
          _fieldCard(
            title: '3. Why：这件事为什么重要',
            subtitle: '不是“应该做”，而是“它为什么值得我花生命”。',
            child: _textField(_why, hint: '例如：因为它让我更像真正的自己，也会改善我的工作与情绪', maxLines: 4),
          ),
          const SizedBox(height: 12),
          _fieldCard(
            title: '4. 当前真正卡住我的问题',
            subtitle: '把含糊焦虑翻译成一个清楚的现实阻碍。',
            child: _textField(_realityProblem, hint: '例如：晚上下班后精力低，遇到难度就逃开，容易刷手机', maxLines: 4),
          ),
        ];
      case 2:
        return [
          _fieldCard(
            title: '5. Lifeline（生命线）',
            subtitle: '给目标一个清晰时间点，不要只说“我以后会做”。',
            child: _textField(_lifeline, hint: '例如：我会在 2026-06-30 前完成第一阶段'),
          ),
          const SizedBox(height: 12),
          _fieldCard(
            title: '6. Stretch 拉伸程度',
            subtitle: '0 很容易，10 很难。课程里更推荐“有拉力但不是压垮你”的区间。',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Slider(
                  min: 0,
                  max: 10,
                  divisions: 10,
                  value: _stretch,
                  label: _stretch.toStringAsFixed(0),
                  onChanged: (v) => setState(() => _stretch = v),
                ),
                Text(
                  _stretch <= 3 ? '当前偏容易：可能不够点燃你。' : (_stretch >= 8 ? '当前偏高压：建议再拆台阶。' : '当前处于可激励区间：有拉力，也更有机会推进。'),
                  style: const TextStyle(color: Color(0xFF6B7280), height: 1.5),
                ),
              ],
            ),
          ),
        ];
      default:
        return [
          _fieldCard(
            title: '7. 本周推进点',
            subtitle: '把长期目标压缩成本周真正可推进的一件事。',
            child: _textField(_weeklyGoal, hint: '例如：本周完成第一版作品集框架 / 本周跑步 3 次'),
          ),
          const SizedBox(height: 12),
          _fieldCard(
            title: '8. 明天第一步',
            subtitle: '不要再写“大计划”，而是写最小可执行的下一步。',
            child: _textField(_firstStep, hint: '例如：明天 20:30 打开电脑，只整理目录 15 分钟'),
          ),
          const SizedBox(height: 12),
          _fieldCard(
            title: '9. If-Then 脚本',
            subtitle: '提前给阻碍写好脚本，减少临场靠意志硬扛。',
            child: _textField(_ifThen, hint: '例如：如果我下班后只想躺着，那么我先做 5 分钟而不是要求自己做 1 小时', maxLines: 4),
          ),
          const SizedBox(height: 12),
          _summaryCard(_buildDraft()),
        ];
    }
  }

  Widget _summaryCard(GoalWorkshopDraft draft) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('当前工坊总结', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          _summaryLine('身份', draft.identityStatement),
          _summaryLine('目标', draft.vision),
          _summaryLine('why', draft.whyText),
          _summaryLine('阻碍', draft.realityProblem),
          _summaryLine('生命线', draft.lifeline),
          _summaryLine('本周推进', draft.weeklyGoal),
          _summaryLine('明天第一步', draft.firstStep),
          _summaryLine('if-then', draft.ifThenText),
        ],
      ),
    );
  }

  Widget _summaryLine(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: RichText(
          text: TextSpan(
            style: const TextStyle(color: Color(0xFF374151), height: 1.6),
            children: [
              TextSpan(text: '$label：', style: const TextStyle(fontWeight: FontWeight.w700)),
              TextSpan(text: value.trim().isEmpty ? '（待填写）' : value),
            ],
          ),
        ),
      );

  Widget _fieldCard({required String title, required String subtitle, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: Color(0xFF6B7280), height: 1.5)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _textField(TextEditingController controller, {required String hint, int maxLines = 2}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: const Color(0xFFF9FAFB),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    );
  }
}
