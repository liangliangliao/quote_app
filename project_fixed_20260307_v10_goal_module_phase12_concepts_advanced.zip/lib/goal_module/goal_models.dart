import 'dart:convert';



class GoalCourseProgress {
  final String sourceCourse;
  final String sourceCourseName;
  final int totalCount;
  final int reviewedCount;
  final int favoriteCount;
  final int difficultCount;
  final int keyCount;

  const GoalCourseProgress({
    required this.sourceCourse,
    required this.sourceCourseName,
    required this.totalCount,
    required this.reviewedCount,
    required this.favoriteCount,
    required this.difficultCount,
    required this.keyCount,
  });

  double get completionRate => totalCount == 0 ? 0 : reviewedCount / totalCount;
}

class GoalModuleProgress {
  final String moduleGroup;
  final String sourceCourse;
  final int totalCount;
  final int reviewedCount;
  final int favoriteCount;
  final int difficultCount;
  final int keyCount;

  const GoalModuleProgress({
    required this.moduleGroup,
    required this.sourceCourse,
    required this.totalCount,
    required this.reviewedCount,
    required this.favoriteCount,
    required this.difficultCount,
    required this.keyCount,
  });

  double get completionRate => totalCount == 0 ? 0 : reviewedCount / totalCount;
}
class GoalCourseSegment {
  final String segmentId;
  final int segmentNo;
  final String sourceCourse;
  final String sourceCourseName;
  final String sectionTitle;
  final String segmentText;
  final String moduleGroup;
  final String tagsJson;
  final int isLocked;

  GoalCourseSegment({
    required this.segmentId,
    required this.segmentNo,
    required this.sourceCourse,
    required this.sourceCourseName,
    required this.sectionTitle,
    required this.segmentText,
    required this.moduleGroup,
    required this.tagsJson,
    this.isLocked = 1,
  });

  List<String> get tags {
    try {
      final v = json.decode(tagsJson);
      if (v is List) return v.map((e) => e.toString()).toList();
    } catch (_) {}
    return const [];
  }

  Map<String, Object?> toRow() => {
        'segment_id': segmentId,
        'segment_no': segmentNo,
        'source_course': sourceCourse,
        'source_course_name': sourceCourseName,
        'section_title': sectionTitle,
        'segment_text': segmentText,
        'module_group': moduleGroup,
        'tags_json': tagsJson,
        'is_locked': isLocked,
      };

  static GoalCourseSegment fromRow(Map<String, Object?> r) => GoalCourseSegment(
        segmentId: (r['segment_id'] ?? '').toString(),
        segmentNo: (r['segment_no'] as num?)?.toInt() ?? 0,
        sourceCourse: (r['source_course'] ?? '').toString(),
        sourceCourseName: (r['source_course_name'] ?? '').toString(),
        sectionTitle: (r['section_title'] ?? '').toString(),
        segmentText: (r['segment_text'] ?? '').toString(),
        moduleGroup: (r['module_group'] ?? '').toString(),
        tagsJson: (r['tags_json'] ?? '[]').toString(),
        isLocked: (r['is_locked'] as num?)?.toInt() ?? 1,
      );
}

class GoalSegmentReview {
  final String segmentId;
  final int reviewedAtMs;
  final bool isFavorited;
  final bool isDifficult;
  final bool isKey;

  const GoalSegmentReview({
    required this.segmentId,
    required this.reviewedAtMs,
    required this.isFavorited,
    required this.isDifficult,
    required this.isKey,
  });

  const GoalSegmentReview.empty(this.segmentId)
      : reviewedAtMs = 0,
        isFavorited = false,
        isDifficult = false,
        isKey = false;

  static GoalSegmentReview fromRow(Map<String, Object?> r) => GoalSegmentReview(
        segmentId: (r['segment_id'] ?? '').toString(),
        reviewedAtMs: (r['reviewed_at_ms'] as num?)?.toInt() ?? 0,
        isFavorited: ((r['is_favorited'] as num?)?.toInt() ?? 0) == 1,
        isDifficult: ((r['is_difficult'] as num?)?.toInt() ?? 0) == 1,
        isKey: ((r['is_key'] as num?)?.toInt() ?? 0) == 1,
      );
}

class GoalReviewedSegment {
  final GoalCourseSegment segment;
  final GoalSegmentReview review;

  GoalReviewedSegment({required this.segment, required this.review});
}

class GoalConceptCard {
  final String conceptId;
  final String segmentId;
  final String conceptTitle;
  final String oneLineDefinition;
  final String whatIsIt;
  final String whyItMatters;
  final String interactionType;
  final String interactionDescription;
  final String reflectionJson;

  GoalConceptCard({
    required this.conceptId,
    required this.segmentId,
    required this.conceptTitle,
    required this.oneLineDefinition,
    required this.whatIsIt,
    required this.whyItMatters,
    required this.interactionType,
    required this.interactionDescription,
    required this.reflectionJson,
  });

  List<String> get reflections {
    try {
      final v = json.decode(reflectionJson);
      if (v is List) return v.map((e) => e.toString()).toList();
    } catch (_) {}
    return const [];
  }

  Map<String, Object?> toRow() => {
        'concept_id': conceptId,
        'segment_id': segmentId,
        'concept_title': conceptTitle,
        'one_line_definition': oneLineDefinition,
        'what_is_it': whatIsIt,
        'why_it_matters': whyItMatters,
        'interaction_type': interactionType,
        'interaction_description': interactionDescription,
        'reflection_json': reflectionJson,
      };

  static GoalConceptCard fromRow(Map<String, Object?> r) => GoalConceptCard(
        conceptId: (r['concept_id'] ?? '').toString(),
        segmentId: (r['segment_id'] ?? '').toString(),
        conceptTitle: (r['concept_title'] ?? '').toString(),
        oneLineDefinition: (r['one_line_definition'] ?? '').toString(),
        whatIsIt: (r['what_is_it'] ?? '').toString(),
        whyItMatters: (r['why_it_matters'] ?? '').toString(),
        interactionType: (r['interaction_type'] ?? '').toString(),
        interactionDescription: (r['interaction_description'] ?? '').toString(),
        reflectionJson: (r['reflection_json'] ?? '[]').toString(),
      );
}


class GoalConceptProgressStats {
  final String conceptId;
  final int actionCount;
  final double avgCompletionRate;
  final int followupCount;
  final int continueCount;
  final int adjustCount;
  final int releaseCount;
  final int lastCompletedAtMs;

  const GoalConceptProgressStats({
    required this.conceptId,
    required this.actionCount,
    required this.avgCompletionRate,
    required this.followupCount,
    required this.continueCount,
    required this.adjustCount,
    required this.releaseCount,
    required this.lastCompletedAtMs,
  });

  const GoalConceptProgressStats.empty(this.conceptId)
      : actionCount = 0,
        avgCompletionRate = 0,
        followupCount = 0,
        continueCount = 0,
        adjustCount = 0,
        releaseCount = 0,
        lastCompletedAtMs = 0;

  int get avgCompletionPercent => (avgCompletionRate * 100).round();
  bool get hasData => actionCount > 0 || followupCount > 0;
}

class GoalActionTemplate {
  final String actionId;
  final String segmentId;
  final String conceptId;
  final String actionTitle;
  final String actionLevel;
  final String goalOfAction;
  final String stepsJson;
  final int durationMin;
  final String failurePlan;
  final String feedbackJson;

  GoalActionTemplate({
    required this.actionId,
    required this.segmentId,
    required this.conceptId,
    required this.actionTitle,
    required this.actionLevel,
    required this.goalOfAction,
    required this.stepsJson,
    required this.durationMin,
    required this.failurePlan,
    required this.feedbackJson,
  });

  List<String> get steps {
    try {
      final v = json.decode(stepsJson);
      if (v is List) return v.map((e) => e.toString()).toList();
    } catch (_) {}
    return const [];
  }

  List<String> get feedbackFields {
    try {
      final v = json.decode(feedbackJson);
      if (v is List) return v.map((e) => e.toString()).toList();
    } catch (_) {}
    return const [];
  }

  Map<String, Object?> toRow() => {
        'action_id': actionId,
        'segment_id': segmentId,
        'concept_id': conceptId,
        'action_title': actionTitle,
        'action_level': actionLevel,
        'goal_of_action': goalOfAction,
        'steps_json': stepsJson,
        'duration_min': durationMin,
        'failure_plan': failurePlan,
        'feedback_json': feedbackJson,
      };

  static GoalActionTemplate fromRow(Map<String, Object?> r) => GoalActionTemplate(
        actionId: (r['action_id'] ?? '').toString(),
        segmentId: (r['segment_id'] ?? '').toString(),
        conceptId: (r['concept_id'] ?? '').toString(),
        actionTitle: (r['action_title'] ?? '').toString(),
        actionLevel: (r['action_level'] ?? '').toString(),
        goalOfAction: (r['goal_of_action'] ?? '').toString(),
        stepsJson: (r['steps_json'] ?? '[]').toString(),
        durationMin: (r['duration_min'] as num?)?.toInt() ?? 0,
        failurePlan: (r['failure_plan'] ?? '').toString(),
        feedbackJson: (r['feedback_json'] ?? '[]').toString(),
      );
}


class GoalSceneActionSuggestion {
  final GoalActionTemplate action;
  final String conceptTitle;
  final String segmentTitle;
  final String sceneReason;

  GoalSceneActionSuggestion({
    required this.action,
    required this.conceptTitle,
    required this.segmentTitle,
    required this.sceneReason,
  });
}

class GoalActionRecord {
  final int id;
  final String actionId;
  final String conceptId;
  final String segmentId;
  final int startedAtMs;
  final int completedAtMs;
  final double completionRate;
  final String feedbackJson;
  final String reflectionText;

  GoalActionRecord({
    required this.id,
    required this.actionId,
    required this.conceptId,
    required this.segmentId,
    required this.startedAtMs,
    required this.completedAtMs,
    required this.completionRate,
    required this.feedbackJson,
    required this.reflectionText,
  });

  Map<String, String> get feedbackMap {
    try {
      final v = json.decode(feedbackJson);
      if (v is Map) {
        return v.map((key, value) => MapEntry(key.toString(), (value ?? '').toString()));
      }
    } catch (_) {}
    return const {};
  }

  static GoalActionRecord fromRow(Map<String, Object?> r) => GoalActionRecord(
        id: (r['id'] as num?)?.toInt() ?? 0,
        actionId: (r['action_id'] ?? '').toString(),
        conceptId: (r['concept_id'] ?? '').toString(),
        segmentId: (r['segment_id'] ?? '').toString(),
        startedAtMs: (r['started_at_ms'] as num?)?.toInt() ?? 0,
        completedAtMs: (r['completed_at_ms'] as num?)?.toInt() ?? 0,
        completionRate: (r['completion_rate'] as num?)?.toDouble() ?? 0,
        feedbackJson: (r['feedback_json'] ?? '{}').toString(),
        reflectionText: (r['reflection_text'] ?? '').toString(),
      );
}

class GoalActionRecordView {
  final GoalActionRecord record;
  final String actionTitle;
  final String conceptTitle;
  final String segmentTitle;
  final String followupDecision;
  final int followupUpdatedAtMs;

  GoalActionRecordView({
    required this.record,
    required this.actionTitle,
    required this.conceptTitle,
    required this.segmentTitle,
    this.followupDecision = '',
    this.followupUpdatedAtMs = 0,
  });

  bool get hasFollowup => followupDecision.trim().isNotEmpty;
}

class GoalActionFollowup {
  final int actionRecordId;
  final String decision;
  final String reflectionText;
  final String nextStep;
  final String weeklyFocus;
  final int updatedAtMs;

  const GoalActionFollowup({
    required this.actionRecordId,
    required this.decision,
    required this.reflectionText,
    required this.nextStep,
    required this.weeklyFocus,
    required this.updatedAtMs,
  });

  const GoalActionFollowup.empty(this.actionRecordId)
      : decision = '',
        reflectionText = '',
        nextStep = '',
        weeklyFocus = '',
        updatedAtMs = 0;

  bool get hasContent =>
      decision.trim().isNotEmpty ||
      reflectionText.trim().isNotEmpty ||
      nextStep.trim().isNotEmpty ||
      weeklyFocus.trim().isNotEmpty;

  Map<String, Object?> toRow() => {
        'action_record_id': actionRecordId,
        'decision': decision,
        'reflection_text': reflectionText,
        'next_step': nextStep,
        'weekly_focus': weeklyFocus,
        'updated_at_ms': updatedAtMs,
      };

  static GoalActionFollowup fromRow(Map<String, Object?> r) => GoalActionFollowup(
        actionRecordId: (r['action_record_id'] as num?)?.toInt() ?? 0,
        decision: (r['decision'] ?? '').toString(),
        reflectionText: (r['reflection_text'] ?? '').toString(),
        nextStep: (r['next_step'] ?? '').toString(),
        weeklyFocus: (r['weekly_focus'] ?? '').toString(),
        updatedAtMs: (r['updated_at_ms'] as num?)?.toInt() ?? 0,
      );
}

class GoalActionRecordBundle {
  final GoalActionRecordView view;
  final GoalActionFollowup followup;

  GoalActionRecordBundle({required this.view, required this.followup});
}

class GoalWorkshopDraft {
  final String identityStatement;
  final String vision;
  final String whyText;
  final String realityProblem;
  final String lifeline;
  final double stretchScore;
  final String weeklyGoal;
  final String firstStep;
  final String ifThenText;
  final int updatedAtMs;

  GoalWorkshopDraft({
    required this.identityStatement,
    required this.vision,
    required this.whyText,
    required this.realityProblem,
    required this.lifeline,
    required this.stretchScore,
    required this.weeklyGoal,
    required this.firstStep,
    required this.ifThenText,
    required this.updatedAtMs,
  });

  factory GoalWorkshopDraft.empty() => GoalWorkshopDraft(
        identityStatement: '',
        vision: '',
        whyText: '',
        realityProblem: '',
        lifeline: '',
        stretchScore: 5,
        weeklyGoal: '',
        firstStep: '',
        ifThenText: '',
        updatedAtMs: 0,
      );

  double get completionRate {
    final fields = [
      identityStatement,
      vision,
      whyText,
      realityProblem,
      lifeline,
      weeklyGoal,
      firstStep,
      ifThenText,
    ];
    final filled = fields.where((e) => e.trim().isNotEmpty).length;
    return filled / fields.length;
  }

  int get consistencyScore {
    double score = 0;
    if (vision.trim().isNotEmpty) score += 20;
    if (whyText.trim().isNotEmpty) score += 15;
    if (lifeline.trim().isNotEmpty) score += 10;
    if (weeklyGoal.trim().isNotEmpty) score += 15;
    if (firstStep.trim().isNotEmpty) score += 15;
    if (ifThenText.trim().isNotEmpty) score += 15;
    if (identityStatement.trim().isNotEmpty) score += 5;
    if (realityProblem.trim().isNotEmpty) score += 5;
    score += (stretchScore >= 4 && stretchScore <= 8) ? 10 : 5;
    return score.round().clamp(0, 100) as int;
  }

  Map<String, Object?> toRow() => {
        'id': 1,
        'identity_statement': identityStatement,
        'vision': vision,
        'why_text': whyText,
        'reality_problem': realityProblem,
        'lifeline': lifeline,
        'stretch_score': stretchScore,
        'weekly_goal': weeklyGoal,
        'first_step': firstStep,
        'if_then_text': ifThenText,
        'updated_at_ms': updatedAtMs,
      };

  static GoalWorkshopDraft fromRow(Map<String, Object?> r) => GoalWorkshopDraft(
        identityStatement: (r['identity_statement'] ?? '').toString(),
        vision: (r['vision'] ?? '').toString(),
        whyText: (r['why_text'] ?? '').toString(),
        realityProblem: (r['reality_problem'] ?? '').toString(),
        lifeline: (r['lifeline'] ?? '').toString(),
        stretchScore: (r['stretch_score'] as num?)?.toDouble() ?? 5,
        weeklyGoal: (r['weekly_goal'] ?? '').toString(),
        firstStep: (r['first_step'] ?? '').toString(),
        ifThenText: (r['if_then_text'] ?? '').toString(),
        updatedAtMs: (r['updated_at_ms'] as num?)?.toInt() ?? 0,
      );
}


class GoalWorldSceneProgress {
  final String sceneId;
  final String completedTaskIdsJson;
  final String realityNote;
  final bool rewardClaimed;
  final int updatedAtMs;

  const GoalWorldSceneProgress({
    required this.sceneId,
    required this.completedTaskIdsJson,
    required this.realityNote,
    required this.rewardClaimed,
    required this.updatedAtMs,
  });

  const GoalWorldSceneProgress.empty(this.sceneId)
      : completedTaskIdsJson = '[]',
        realityNote = '',
        rewardClaimed = false,
        updatedAtMs = 0;

  List<String> get completedTaskIds {
    try {
      final v = json.decode(completedTaskIdsJson);
      if (v is List) return v.map((e) => e.toString()).toList();
    } catch (_) {}
    return const [];
  }

  Map<String, Object?> toRow() => {
        'scene_id': sceneId,
        'completed_task_ids_json': completedTaskIdsJson,
        'reality_note': realityNote,
        'reward_claimed': rewardClaimed ? 1 : 0,
        'updated_at_ms': updatedAtMs,
      };

  static GoalWorldSceneProgress fromRow(Map<String, Object?> r) => GoalWorldSceneProgress(
        sceneId: (r['scene_id'] ?? '').toString(),
        completedTaskIdsJson: (r['completed_task_ids_json'] ?? '[]').toString(),
        realityNote: (r['reality_note'] ?? '').toString(),
        rewardClaimed: ((r['reward_claimed'] as num?)?.toInt() ?? 0) == 1,
        updatedAtMs: (r['updated_at_ms'] as num?)?.toInt() ?? 0,
      );
}
