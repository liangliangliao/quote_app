import 'dart:convert';

import 'package:quote_app/data/db.dart';
import 'package:sqflite/sqflite.dart';

import 'goal_concept_seed.dart';
import 'goal_models.dart';
import 'goal_seed.dart';
import 'goal_world_seed.dart';

class GoalDao {
  Future<Database> _db() => AppDatabase.instance();

  Future<void> _safeAddColumn(Database db, String table, String columnSql) async {
    try {
      await db.execute('ALTER TABLE $table ADD COLUMN $columnSql');
    } catch (_) {
      // ignore if column already exists
    }
  }

  Future<void> ensureTables() async {
    final db = await _db();
    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_course_segment (
        segment_id TEXT PRIMARY KEY,
        segment_no INTEGER NOT NULL,
        source_course TEXT NOT NULL,
        source_course_name TEXT NOT NULL,
        section_title TEXT NOT NULL,
        segment_text TEXT NOT NULL,
        module_group TEXT NOT NULL,
        tags_json TEXT NOT NULL DEFAULT '[]',
        is_locked INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_segment_review (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        segment_id TEXT NOT NULL,
        reviewed_at_ms INTEGER NOT NULL,
        is_favorited INTEGER NOT NULL DEFAULT 0,
        is_difficult INTEGER NOT NULL DEFAULT 0,
        is_key INTEGER NOT NULL DEFAULT 0,
        UNIQUE(segment_id) ON CONFLICT REPLACE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_workshop_draft (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        identity_statement TEXT NOT NULL DEFAULT '',
        vision TEXT NOT NULL DEFAULT '',
        why_text TEXT NOT NULL DEFAULT '',
        reality_problem TEXT NOT NULL DEFAULT '',
        lifeline TEXT NOT NULL DEFAULT '',
        stretch_score REAL NOT NULL DEFAULT 5,
        weekly_goal TEXT NOT NULL DEFAULT '',
        first_step TEXT NOT NULL DEFAULT '',
        if_then_text TEXT NOT NULL DEFAULT '',
        updated_at_ms INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await _safeAddColumn(db, 'goal_workshop_draft', "identity_statement TEXT NOT NULL DEFAULT ''");
    await _safeAddColumn(db, 'goal_workshop_draft', "reality_problem TEXT NOT NULL DEFAULT ''");
    await _safeAddColumn(db, 'goal_workshop_draft', "weekly_goal TEXT NOT NULL DEFAULT ''");

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_concept_card (
        concept_id TEXT PRIMARY KEY,
        segment_id TEXT NOT NULL,
        concept_title TEXT NOT NULL,
        one_line_definition TEXT NOT NULL,
        what_is_it TEXT NOT NULL,
        why_it_matters TEXT NOT NULL,
        interaction_type TEXT NOT NULL,
        interaction_description TEXT NOT NULL,
        reflection_json TEXT NOT NULL DEFAULT '[]'
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_action_template (
        action_id TEXT PRIMARY KEY,
        segment_id TEXT NOT NULL,
        concept_id TEXT NOT NULL,
        action_title TEXT NOT NULL,
        action_level TEXT NOT NULL,
        goal_of_action TEXT NOT NULL,
        steps_json TEXT NOT NULL DEFAULT '[]',
        duration_min INTEGER NOT NULL DEFAULT 15,
        failure_plan TEXT NOT NULL DEFAULT '',
        feedback_json TEXT NOT NULL DEFAULT '[]'
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_action_record (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action_id TEXT NOT NULL,
        concept_id TEXT NOT NULL,
        segment_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        completed_at_ms INTEGER NOT NULL,
        completion_rate REAL NOT NULL DEFAULT 0,
        feedback_json TEXT NOT NULL DEFAULT '{}',
        reflection_text TEXT NOT NULL DEFAULT '',
        action_title_snapshot TEXT NOT NULL DEFAULT '',
        concept_title_snapshot TEXT NOT NULL DEFAULT '',
        segment_title_snapshot TEXT NOT NULL DEFAULT '',
        action_level_snapshot TEXT NOT NULL DEFAULT ''
      )
    ''');
    await _safeAddColumn(db, 'goal_action_record', "action_title_snapshot TEXT NOT NULL DEFAULT ''");
    await _safeAddColumn(db, 'goal_action_record', "concept_title_snapshot TEXT NOT NULL DEFAULT ''");
    await _safeAddColumn(db, 'goal_action_record', "segment_title_snapshot TEXT NOT NULL DEFAULT ''");
    await _safeAddColumn(db, 'goal_action_record', "action_level_snapshot TEXT NOT NULL DEFAULT ''");

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_world_scene_progress (
        scene_id TEXT PRIMARY KEY,
        completed_task_ids_json TEXT NOT NULL DEFAULT '[]',
        reality_note TEXT NOT NULL DEFAULT '',
        reward_claimed INTEGER NOT NULL DEFAULT 0,
        updated_at_ms INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS goal_action_followup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action_record_id INTEGER NOT NULL,
        decision TEXT NOT NULL DEFAULT '',
        reflection_text TEXT NOT NULL DEFAULT '',
        next_step TEXT NOT NULL DEFAULT '',
        weekly_focus TEXT NOT NULL DEFAULT '',
        updated_at_ms INTEGER NOT NULL DEFAULT 0,
        UNIQUE(action_record_id) ON CONFLICT REPLACE
      )
    ''');
  }

  Future<void> seedIfNeeded() async {
    final db = await _db();
    await ensureTables();

    Future<void> ensureSeed(String table, List<Map<String, dynamic>> seed) async {
      final cnt = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(1) FROM $table')) ?? 0;
      if (cnt > 0) return;
      await db.transaction((txn) async {
        for (final m in seed) {
          await txn.insert(table, m, conflictAlgorithm: ConflictAlgorithm.replace);
        }
      });
    }

    await ensureSeed('goal_course_segment', goalCourseSeedSegments);
    await ensureSeed('goal_concept_card', goalConceptSeedCards);
    await ensureSeed('goal_action_template', goalActionSeedTemplates);
  }

  Future<List<GoalCourseSegment>> listSegments({String? sourceCourse, String? moduleGroup}) async {
    final db = await _db();
    await seedIfNeeded();
    final where = <String>[];
    final args = <Object?>[];
    if (sourceCourse != null && sourceCourse.isNotEmpty) {
      where.add('source_course=?');
      args.add(sourceCourse);
    }
    if (moduleGroup != null && moduleGroup.isNotEmpty) {
      where.add('module_group=?');
      args.add(moduleGroup);
    }
    final rows = await db.query(
      'goal_course_segment',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: where.isEmpty ? null : args,
      orderBy: 'source_course ASC, segment_no ASC',
    );
    return rows.map(GoalCourseSegment.fromRow).toList();
  }

  Future<List<String>> listModuleGroups() async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.rawQuery('SELECT DISTINCT module_group FROM goal_course_segment ORDER BY source_course ASC, segment_no ASC');
    return rows.map((e) => (e['module_group'] ?? '').toString()).where((e) => e.isNotEmpty).toList();
  }

  Future<Map<String, int>> getModuleSegmentCounts() async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.rawQuery('''
      SELECT module_group, COUNT(1) AS cnt
      FROM goal_course_segment
      GROUP BY module_group
      ORDER BY MIN(source_course), MIN(segment_no)
    ''');
    return {
      for (final r in rows) (r['module_group'] ?? '').toString(): (r['cnt'] as num?)?.toInt() ?? 0,
    };
  }

  Future<GoalCourseSegment?> getSegment(String segmentId) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.query('goal_course_segment', where: 'segment_id=?', whereArgs: [segmentId], limit: 1);
    if (rows.isEmpty) return null;
    return GoalCourseSegment.fromRow(rows.first);
  }

  Future<GoalSegmentReview> getSegmentReview(String segmentId) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.query('goal_segment_review', where: 'segment_id=?', whereArgs: [segmentId], limit: 1);
    if (rows.isEmpty) return GoalSegmentReview.empty(segmentId);
    return GoalSegmentReview.fromRow(rows.first);
  }

  Future<void> saveSegmentReview({
    required String segmentId,
    required bool isFavorited,
    required bool isDifficult,
    required bool isKey,
  }) async {
    final db = await _db();
    await ensureTables();
    await db.insert(
      'goal_segment_review',
      {
        'segment_id': segmentId,
        'reviewed_at_ms': DateTime.now().millisecondsSinceEpoch,
        'is_favorited': isFavorited ? 1 : 0,
        'is_difficult': isDifficult ? 1 : 0,
        'is_key': isKey ? 1 : 0,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }


  Future<void> touchSegmentReviewed(String segmentId) async {
    final current = await getSegmentReview(segmentId);
    await saveSegmentReview(
      segmentId: segmentId,
      isFavorited: current.isFavorited,
      isDifficult: current.isDifficult,
      isKey: current.isKey,
    );
  }

  Future<List<GoalReviewedSegment>> listRecentReviewedSegments({int limit = 8}) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.rawQuery('''
      SELECT s.*, r.segment_id AS review_segment_id, r.reviewed_at_ms, r.is_favorited, r.is_difficult, r.is_key
      FROM goal_segment_review r
      JOIN goal_course_segment s ON s.segment_id = r.segment_id
      WHERE r.reviewed_at_ms > 0
      ORDER BY r.reviewed_at_ms DESC
      LIMIT ?
    ''', [limit]);
    return rows.map((r) {
      final segment = GoalCourseSegment.fromRow(r);
      final review = GoalSegmentReview(
        segmentId: (r['review_segment_id'] ?? '').toString(),
        reviewedAtMs: (r['reviewed_at_ms'] as num?)?.toInt() ?? 0,
        isFavorited: ((r['is_favorited'] as num?)?.toInt() ?? 0) == 1,
        isDifficult: ((r['is_difficult'] as num?)?.toInt() ?? 0) == 1,
        isKey: ((r['is_key'] as num?)?.toInt() ?? 0) == 1,
      );
      return GoalReviewedSegment(segment: segment, review: review);
    }).toList();
  }

  Future<List<GoalCourseProgress>> listCourseProgress() async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.rawQuery('''
      SELECT s.source_course, s.source_course_name,
             COUNT(1) AS total_count,
             SUM(CASE WHEN r.reviewed_at_ms > 0 THEN 1 ELSE 0 END) AS reviewed_count,
             SUM(CASE WHEN COALESCE(r.is_favorited, 0) = 1 THEN 1 ELSE 0 END) AS favorite_count,
             SUM(CASE WHEN COALESCE(r.is_difficult, 0) = 1 THEN 1 ELSE 0 END) AS difficult_count,
             SUM(CASE WHEN COALESCE(r.is_key, 0) = 1 THEN 1 ELSE 0 END) AS key_count
      FROM goal_course_segment s
      LEFT JOIN goal_segment_review r ON r.segment_id = s.segment_id
      GROUP BY s.source_course, s.source_course_name
      ORDER BY MIN(CASE s.source_course WHEN 'PP12' THEN 1 ELSE 2 END), MIN(s.segment_no)
    ''');
    return rows.map((r) => GoalCourseProgress(
      sourceCourse: (r['source_course'] ?? '').toString(),
      sourceCourseName: (r['source_course_name'] ?? '').toString(),
      totalCount: (r['total_count'] as num?)?.toInt() ?? 0,
      reviewedCount: (r['reviewed_count'] as num?)?.toInt() ?? 0,
      favoriteCount: (r['favorite_count'] as num?)?.toInt() ?? 0,
      difficultCount: (r['difficult_count'] as num?)?.toInt() ?? 0,
      keyCount: (r['key_count'] as num?)?.toInt() ?? 0,
    )).toList();
  }

  Future<List<GoalModuleProgress>> listModuleProgress({String? sourceCourse}) async {
    final db = await _db();
    await seedIfNeeded();
    final where = <String>[];
    final args = <Object?>[];
    if (sourceCourse != null && sourceCourse.isNotEmpty) {
      where.add('s.source_course = ?');
      args.add(sourceCourse);
    }
    final whereSql = where.isEmpty ? '' : 'WHERE ' + where.join(' AND ');
    final rows = await db.rawQuery('''
      SELECT s.module_group, s.source_course,
             COUNT(1) AS total_count,
             SUM(CASE WHEN r.reviewed_at_ms > 0 THEN 1 ELSE 0 END) AS reviewed_count,
             SUM(CASE WHEN COALESCE(r.is_favorited, 0) = 1 THEN 1 ELSE 0 END) AS favorite_count,
             SUM(CASE WHEN COALESCE(r.is_difficult, 0) = 1 THEN 1 ELSE 0 END) AS difficult_count,
             SUM(CASE WHEN COALESCE(r.is_key, 0) = 1 THEN 1 ELSE 0 END) AS key_count,
             MIN(CASE s.source_course WHEN 'PP12' THEN 1 ELSE 2 END) AS source_sort,
             MIN(s.segment_no) AS segment_sort
      FROM goal_course_segment s
      LEFT JOIN goal_segment_review r ON r.segment_id = s.segment_id
      ''' + whereSql + '''
      GROUP BY s.module_group, s.source_course
      ORDER BY source_sort ASC, segment_sort ASC
    ''', args);
    return rows
        .map((r) => GoalModuleProgress(
              moduleGroup: (r['module_group'] ?? '').toString(),
              sourceCourse: (r['source_course'] ?? '').toString(),
              totalCount: (r['total_count'] as num?)?.toInt() ?? 0,
              reviewedCount: (r['reviewed_count'] as num?)?.toInt() ?? 0,
              favoriteCount: (r['favorite_count'] as num?)?.toInt() ?? 0,
              difficultCount: (r['difficult_count'] as num?)?.toInt() ?? 0,
              keyCount: (r['key_count'] as num?)?.toInt() ?? 0,
            ))
        .toList();
  }

  Future<List<GoalReviewedSegment>> listReviewedSegments(String filter) async {
    final db = await _db();
    await seedIfNeeded();
    String whereColumn;
    switch (filter) {
      case 'difficult':
        whereColumn = 'r.is_difficult';
        break;
      case 'key':
        whereColumn = 'r.is_key';
        break;
      default:
        whereColumn = 'r.is_favorited';
        break;
    }
    final rows = await db.rawQuery('''
      SELECT s.*, r.segment_id AS review_segment_id, r.reviewed_at_ms, r.is_favorited, r.is_difficult, r.is_key
      FROM goal_segment_review r
      JOIN goal_course_segment s ON s.segment_id = r.segment_id
      WHERE $whereColumn = 1
      ORDER BY r.reviewed_at_ms DESC
    ''');
    return rows.map((r) {
      final segment = GoalCourseSegment.fromRow(r);
      final review = GoalSegmentReview(
        segmentId: (r['review_segment_id'] ?? '').toString(),
        reviewedAtMs: (r['reviewed_at_ms'] as num?)?.toInt() ?? 0,
        isFavorited: ((r['is_favorited'] as num?)?.toInt() ?? 0) == 1,
        isDifficult: ((r['is_difficult'] as num?)?.toInt() ?? 0) == 1,
        isKey: ((r['is_key'] as num?)?.toInt() ?? 0) == 1,
      );
      return GoalReviewedSegment(segment: segment, review: review);
    }).toList();
  }

  Future<List<GoalConceptCard>> listConceptCards({String? sourceCourse}) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.rawQuery('''
      SELECT c.*
      FROM goal_concept_card c
      JOIN goal_course_segment s ON s.segment_id = c.segment_id
      ${sourceCourse == null || sourceCourse.isEmpty ? '' : 'WHERE s.source_course = ?'}
      ORDER BY s.source_course ASC, s.segment_no ASC
    ''', sourceCourse == null || sourceCourse.isEmpty ? const [] : [sourceCourse]);
    return rows.map(GoalConceptCard.fromRow).toList();
  }

  Future<List<GoalConceptCard>> listConceptCardsForSegment(String segmentId) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.query('goal_concept_card', where: 'segment_id=?', whereArgs: [segmentId], orderBy: 'concept_id ASC');
    return rows.map(GoalConceptCard.fromRow).toList();
  }

  Future<GoalConceptCard?> getConceptCard(String conceptId) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.query('goal_concept_card', where: 'concept_id=?', whereArgs: [conceptId], limit: 1);
    if (rows.isEmpty) return null;
    return GoalConceptCard.fromRow(rows.first);
  }

  Future<List<GoalActionTemplate>> listActionTemplatesForConcept(String conceptId) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.query('goal_action_template', where: 'concept_id=?', whereArgs: [conceptId], orderBy: 'action_id ASC');
    return rows.map(GoalActionTemplate.fromRow).toList();
  }


  Future<List<GoalSceneActionSuggestion>> listRecommendedActionsForScene(String sceneId, {int limit = 3}) async {
    final db = await _db();
    await seedIfNeeded();
    final scene = sceneById(sceneId);
    if (scene.relatedSegmentIds.isEmpty) return const <GoalSceneActionSuggestion>[];
    final placeholders = List.filled(scene.relatedSegmentIds.length, '?').join(',');
    final rows = await db.rawQuery('''
      SELECT a.*, c.concept_title, s.section_title, s.segment_id
      FROM goal_action_template a
      JOIN goal_concept_card c ON c.concept_id = a.concept_id
      JOIN goal_course_segment s ON s.segment_id = a.segment_id
      WHERE a.segment_id IN ($placeholders)
      ORDER BY s.source_course ASC, s.segment_no ASC, a.action_id ASC
    ''', scene.relatedSegmentIds);

    final sortMap = <String, int>{
      for (int i = 0; i < scene.relatedSegmentIds.length; i++) scene.relatedSegmentIds[i]: i,
    };
    rows.sort((a, b) {
      final aOrder = sortMap[(a['segment_id'] ?? '').toString()] ?? 999;
      final bOrder = sortMap[(b['segment_id'] ?? '').toString()] ?? 999;
      if (aOrder != bOrder) return aOrder.compareTo(bOrder);
      return ((a['action_id'] ?? '').toString()).compareTo((b['action_id'] ?? '').toString());
    });

    final suggestions = <GoalSceneActionSuggestion>[];
    final seenActionIds = <String>{};
    for (final row in rows) {
      final action = GoalActionTemplate.fromRow(row);
      if (!seenActionIds.add(action.actionId)) continue;
      suggestions.add(
        GoalSceneActionSuggestion(
          action: action,
          conceptTitle: (row['concept_title'] ?? '概念实践').toString(),
          segmentTitle: (row['section_title'] ?? '课程正文').toString(),
          sceneReason: _sceneActionReason(sceneId),
        ),
      );
      if (suggestions.length >= limit) break;
    }
    return suggestions;
  }

  String _sceneActionReason(String sceneId) {
    switch (sceneId) {
      case 'fog_plain':
        return '适合把“暂时方向”变成一条小而真实的行动线索。';
      case 'mirror_lake':
        return '适合继续校准“这个目标像不像我”，并把判断转成现实尝试。';
      case 'workshop_city':
        return '适合把本周推进和明天第一步真正执行起来。';
      default:
        return '适合把刚完成的场景收获继续推进到现实中。';
    }
  }

  Future<void> saveActionRecord({
    required String actionId,
    required String conceptId,
    required String segmentId,
    required int startedAtMs,
    required double completionRate,
    required Map<String, String> feedbackMap,
    required String reflectionText,
    String actionTitleSnapshot = '',
    String conceptTitleSnapshot = '',
    String segmentTitleSnapshot = '',
    String actionLevelSnapshot = '',
  }) async {
    final db = await _db();
    await ensureTables();
    await db.insert('goal_action_record', {
      'action_id': actionId,
      'concept_id': conceptId,
      'segment_id': segmentId,
      'started_at_ms': startedAtMs,
      'completed_at_ms': DateTime.now().millisecondsSinceEpoch,
      'completion_rate': completionRate,
      'feedback_json': json.encode(feedbackMap),
      'reflection_text': reflectionText,
      'action_title_snapshot': actionTitleSnapshot,
      'concept_title_snapshot': conceptTitleSnapshot,
      'segment_title_snapshot': segmentTitleSnapshot,
      'action_level_snapshot': actionLevelSnapshot,
    });
  }

  Future<List<GoalActionRecordView>> listActionRecordViews({int limit = 30, String period = 'all'}) async {
    final db = await _db();
    await seedIfNeeded();
    final where = <String>[];
    final args = <Object?>[];
    final now = DateTime.now();
    if (period == 'today') {
      final start = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
      where.add('r.completed_at_ms >= ?');
      args.add(start);
    } else if (period == 'week') {
      final weekdayOffset = now.weekday - DateTime.monday;
      final startDate = DateTime(now.year, now.month, now.day).subtract(Duration(days: weekdayOffset));
      where.add('r.completed_at_ms >= ?');
      args.add(startDate.millisecondsSinceEpoch);
    }
    final sql = '''
      SELECT r.*, 
             COALESCE(a.action_title, r.action_title_snapshot, '未命名行动') AS action_title,
             COALESCE(c.concept_title, r.concept_title_snapshot, '概念实践') AS concept_title,
             COALESCE(s.section_title, r.segment_title_snapshot, '课程正文') AS section_title,
             COALESCE(f.decision, '') AS followup_decision,
             COALESCE(f.updated_at_ms, 0) AS followup_updated_at_ms
      FROM goal_action_record r
      LEFT JOIN goal_action_template a ON a.action_id = r.action_id
      LEFT JOIN goal_concept_card c ON c.concept_id = r.concept_id
      LEFT JOIN goal_course_segment s ON s.segment_id = r.segment_id
      LEFT JOIN goal_action_followup f ON f.action_record_id = r.id
      ${where.isEmpty ? '' : 'WHERE ' + where.join(' AND ')}
      ORDER BY r.completed_at_ms DESC
      LIMIT ?
    ''';
    final rows = await db.rawQuery(sql, [...args, limit]);
    return rows.map(_recordViewFromRow).toList();
  }

  GoalActionRecordView _recordViewFromRow(Map<String, Object?> r) => GoalActionRecordView(
        record: GoalActionRecord.fromRow(r),
        actionTitle: (r['action_title'] ?? '未命名行动').toString(),
        conceptTitle: (r['concept_title'] ?? '概念实践').toString(),
        segmentTitle: (r['section_title'] ?? '课程正文').toString(),
        followupDecision: (r['followup_decision'] ?? '').toString(),
        followupUpdatedAtMs: (r['followup_updated_at_ms'] as num?)?.toInt() ?? 0,
      );


  Future<GoalConceptProgressStats> getConceptProgressStats(String conceptId) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.rawQuery('''
      SELECT r.concept_id,
             COUNT(r.id) AS action_count,
             COALESCE(AVG(r.completion_rate), 0) AS avg_completion_rate,
             COALESCE(MAX(r.completed_at_ms), 0) AS last_completed_at_ms,
             SUM(CASE WHEN (COALESCE(f.decision, '') <> '' OR COALESCE(f.reflection_text, '') <> '' OR COALESCE(f.next_step, '') <> '' OR COALESCE(f.weekly_focus, '') <> '') THEN 1 ELSE 0 END) AS followup_count,
             SUM(CASE WHEN COALESCE(f.decision, '') = '继续' THEN 1 ELSE 0 END) AS continue_count,
             SUM(CASE WHEN COALESCE(f.decision, '') = '调整' THEN 1 ELSE 0 END) AS adjust_count,
             SUM(CASE WHEN COALESCE(f.decision, '') = '放弃' THEN 1 ELSE 0 END) AS release_count
      FROM goal_action_record r
      LEFT JOIN goal_action_followup f ON f.action_record_id = r.id
      WHERE r.concept_id = ?
    ''', [conceptId]);
    if (rows.isEmpty) return GoalConceptProgressStats.empty(conceptId);
    final row = rows.first;
    return GoalConceptProgressStats(
      conceptId: conceptId,
      actionCount: (row['action_count'] as num?)?.toInt() ?? 0,
      avgCompletionRate: (row['avg_completion_rate'] as num?)?.toDouble() ?? 0,
      followupCount: (row['followup_count'] as num?)?.toInt() ?? 0,
      continueCount: (row['continue_count'] as num?)?.toInt() ?? 0,
      adjustCount: (row['adjust_count'] as num?)?.toInt() ?? 0,
      releaseCount: (row['release_count'] as num?)?.toInt() ?? 0,
      lastCompletedAtMs: (row['last_completed_at_ms'] as num?)?.toInt() ?? 0,
    );
  }

  Future<GoalActionFollowup> getActionFollowup(int actionRecordId) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('goal_action_followup', where: 'action_record_id=?', whereArgs: [actionRecordId], limit: 1);
    if (rows.isEmpty) return GoalActionFollowup.empty(actionRecordId);
    return GoalActionFollowup.fromRow(rows.first);
  }

  Future<void> saveActionFollowup({
    required int actionRecordId,
    required String decision,
    required String reflectionText,
    required String nextStep,
    required String weeklyFocus,
  }) async {
    final db = await _db();
    await ensureTables();
    await db.insert(
      'goal_action_followup',
      GoalActionFollowup(
        actionRecordId: actionRecordId,
        decision: decision,
        reflectionText: reflectionText,
        nextStep: nextStep,
        weeklyFocus: weeklyFocus,
        updatedAtMs: DateTime.now().millisecondsSinceEpoch,
      ).toRow(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<GoalActionRecordBundle?> getActionRecordBundle(int actionRecordId) async {
    final db = await _db();
    await seedIfNeeded();
    final rows = await db.rawQuery('''
      SELECT r.*, 
             COALESCE(a.action_title, r.action_title_snapshot, '未命名行动') AS action_title,
             COALESCE(c.concept_title, r.concept_title_snapshot, '概念实践') AS concept_title,
             COALESCE(s.section_title, r.segment_title_snapshot, '课程正文') AS section_title,
             COALESCE(f.decision, '') AS followup_decision,
             COALESCE(f.updated_at_ms, 0) AS followup_updated_at_ms
      FROM goal_action_record r
      LEFT JOIN goal_action_template a ON a.action_id = r.action_id
      LEFT JOIN goal_concept_card c ON c.concept_id = r.concept_id
      LEFT JOIN goal_course_segment s ON s.segment_id = r.segment_id
      LEFT JOIN goal_action_followup f ON f.action_record_id = r.id
      WHERE r.id = ?
      LIMIT 1
    ''', [actionRecordId]);
    if (rows.isEmpty) return null;
    final view = _recordViewFromRow(rows.first);
    final followup = await getActionFollowup(actionRecordId);
    return GoalActionRecordBundle(view: view, followup: followup);
  }

  Future<GoalWorkshopDraft> mergeFollowupIntoWorkshop({
    required int actionRecordId,
    required String decision,
    required String reflectionText,
    required String nextStep,
    required String weeklyFocus,
  }) async {
    final current = await getWorkshopDraft();
    final bundle = await getActionRecordBundle(actionRecordId);
    final view = bundle?.view;

    String appendUnique(String base, String line) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) return base;
      if (base.trim().isEmpty) return trimmed;
      if (base.contains(trimmed)) return base;
      return '${base.trim()}\n$trimmed';
    }

    final sourceLine = [view?.conceptTitle ?? '', view?.actionTitle ?? '']
        .where((e) => e.trim().isNotEmpty)
        .join('｜');

    final merged = GoalWorkshopDraft(
      identityStatement: current.identityStatement,
      vision: current.vision.trim().isNotEmpty
          ? current.vision
          : ((view?.segmentTitle ?? '').trim().isNotEmpty ? view!.segmentTitle : sourceLine),
      whyText: current.whyText.trim().isNotEmpty
          ? current.whyText
          : (view?.record.reflectionText.trim().isNotEmpty == true ? view!.record.reflectionText.trim() : ''),
      realityProblem: decision == '调整'
          ? appendUnique(current.realityProblem, reflectionText.trim().isNotEmpty ? '来自行动闭环：${reflectionText.trim()}' : '来自行动闭环：需要重新调整当前策略')
          : current.realityProblem,
      lifeline: current.lifeline,
      stretchScore: current.stretchScore,
      weeklyGoal: weeklyFocus.trim().isNotEmpty
          ? weeklyFocus.trim()
          : (decision == '继续' && current.weeklyGoal.trim().isEmpty ? sourceLine : current.weeklyGoal),
      firstStep: nextStep.trim().isNotEmpty ? nextStep.trim() : current.firstStep,
      ifThenText: decision == '调整' && nextStep.trim().isNotEmpty
          ? appendUnique(current.ifThenText, '如果再次遇到这次行动中的阻碍，那么我先：${nextStep.trim()}')
          : current.ifThenText,
      updatedAtMs: DateTime.now().millisecondsSinceEpoch,
    );

    await saveWorkshopDraft(
      identityStatement: merged.identityStatement,
      vision: merged.vision,
      whyText: merged.whyText,
      realityProblem: merged.realityProblem,
      lifeline: merged.lifeline,
      stretchScore: merged.stretchScore,
      weeklyGoal: merged.weeklyGoal,
      firstStep: merged.firstStep,
      ifThenText: merged.ifThenText,
    );
    return merged;
  }

  Future<GoalWorldSceneProgress> getWorldSceneProgress(String sceneId) async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('goal_world_scene_progress', where: 'scene_id=?', whereArgs: [sceneId], limit: 1);
    if (rows.isEmpty) return GoalWorldSceneProgress.empty(sceneId);
    return GoalWorldSceneProgress.fromRow(rows.first);
  }

  Future<List<GoalWorldSceneProgress>> listWorldSceneProgress() async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('goal_world_scene_progress', orderBy: 'updated_at_ms DESC');
    return rows.map(GoalWorldSceneProgress.fromRow).toList();
  }

  Future<void> saveWorldSceneProgress({
    required String sceneId,
    required List<String> completedTaskIds,
    required String realityNote,
    required bool rewardClaimed,
  }) async {
    final db = await _db();
    await ensureTables();
    final progress = GoalWorldSceneProgress(
      sceneId: sceneId,
      completedTaskIdsJson: json.encode(completedTaskIds),
      realityNote: realityNote,
      rewardClaimed: rewardClaimed,
      updatedAtMs: DateTime.now().millisecondsSinceEpoch,
    );
    await db.insert('goal_world_scene_progress', progress.toRow(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<GoalWorkshopDraft> mergeWorldSceneIntoWorkshop({
    required String sceneId,
    required String realityNote,
  }) async {
    final current = await getWorkshopDraft();
    final note = realityNote.trim();

    String appendUnique(String base, String line) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) return base;
      if (base.trim().isEmpty) return trimmed;
      if (base.contains(trimmed)) return base;
      return '${base.trim()}
$trimmed';
    }

    var identityStatement = current.identityStatement;
    var vision = current.vision;
    var whyText = current.whyText;
    var realityProblem = current.realityProblem;
    var lifeline = current.lifeline;
    var stretchScore = current.stretchScore;
    var weeklyGoal = current.weeklyGoal;
    var firstStep = current.firstStep;
    var ifThenText = current.ifThenText;

    switch (sceneId) {
      case 'fog_plain':
        if (note.isNotEmpty) {
          vision = vision.trim().isEmpty ? note : appendUnique(vision, note);
          identityStatement = appendUnique(identityStatement, '我现在想优先活出的方向：$note');
        }
        break;
      case 'mirror_lake':
        if (note.isNotEmpty) {
          whyText = appendUnique(whyText, '来自镜湖：$note');
          realityProblem = appendUnique(realityProblem, '需要继续校准这个目标是否真正属于我。');
        }
        break;
      case 'workshop_city':
        if (note.isNotEmpty) {
          weeklyGoal = weeklyGoal.trim().isEmpty ? note : appendUnique(weeklyGoal, note);
          firstStep = firstStep.trim().isEmpty ? note : firstStep;
          ifThenText = appendUnique(ifThenText, '如果今天开始拖延或分心，那么我先完成：$note');
        }
        break;
    }

    final merged = GoalWorkshopDraft(
      identityStatement: identityStatement,
      vision: vision,
      whyText: whyText,
      realityProblem: realityProblem,
      lifeline: lifeline,
      stretchScore: stretchScore,
      weeklyGoal: weeklyGoal,
      firstStep: firstStep,
      ifThenText: ifThenText,
      updatedAtMs: DateTime.now().millisecondsSinceEpoch,
    );

    await saveWorkshopDraft(
      identityStatement: merged.identityStatement,
      vision: merged.vision,
      whyText: merged.whyText,
      realityProblem: merged.realityProblem,
      lifeline: merged.lifeline,
      stretchScore: merged.stretchScore,
      weeklyGoal: merged.weeklyGoal,
      firstStep: merged.firstStep,
      ifThenText: merged.ifThenText,
    );
    return merged;
  }

  Future<Map<String, int>> getStatsSummary() async {
    final db = await _db();
    await seedIfNeeded();
    Future<int> count(String sql) async => Sqflite.firstIntValue(await db.rawQuery(sql)) ?? 0;
    return {
      'segments': await count('SELECT COUNT(1) FROM goal_course_segment'),
      'concepts': await count('SELECT COUNT(1) FROM goal_concept_card'),
      'reviewed': await count('SELECT COUNT(1) FROM goal_segment_review WHERE reviewed_at_ms > 0'),
      'favorites': await count('SELECT COUNT(1) FROM goal_segment_review WHERE is_favorited = 1'),
      'difficult': await count('SELECT COUNT(1) FROM goal_segment_review WHERE is_difficult = 1'),
      'keys': await count('SELECT COUNT(1) FROM goal_segment_review WHERE is_key = 1'),
      'actions': await count('SELECT COUNT(1) FROM goal_action_record'),
      'followups': await count("SELECT COUNT(1) FROM goal_action_followup WHERE decision <> '' OR reflection_text <> '' OR next_step <> '' OR weekly_focus <> ''"),
      'modules': await count('SELECT COUNT(DISTINCT module_group) FROM goal_course_segment'),
      'worldScenes': await count('SELECT COUNT(1) FROM goal_world_scene_progress'),
      'worldRewards': await count('SELECT COUNT(1) FROM goal_world_scene_progress WHERE reward_claimed = 1'),
    };
  }

  Future<GoalWorkshopDraft> getWorkshopDraft() async {
    final db = await _db();
    await ensureTables();
    final rows = await db.query('goal_workshop_draft', where: 'id=1', limit: 1);
    if (rows.isEmpty) return GoalWorkshopDraft.empty();
    return GoalWorkshopDraft.fromRow(rows.first);
  }

  Future<void> saveWorkshopDraft({
    required String identityStatement,
    required String vision,
    required String whyText,
    required String realityProblem,
    required String lifeline,
    required double stretchScore,
    required String weeklyGoal,
    required String firstStep,
    required String ifThenText,
  }) async {
    final db = await _db();
    await ensureTables();
    final draft = GoalWorkshopDraft(
      identityStatement: identityStatement,
      vision: vision,
      whyText: whyText,
      realityProblem: realityProblem,
      lifeline: lifeline,
      stretchScore: stretchScore,
      weeklyGoal: weeklyGoal,
      firstStep: firstStep,
      ifThenText: ifThenText,
      updatedAtMs: DateTime.now().millisecondsSinceEpoch,
    );
    await db.insert('goal_workshop_draft', draft.toRow(), conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
