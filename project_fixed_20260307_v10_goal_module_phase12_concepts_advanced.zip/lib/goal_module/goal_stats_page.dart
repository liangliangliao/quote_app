import 'package:flutter/material.dart';

import 'goal_dao.dart';
import 'goal_models.dart';

class GoalStatsPage extends StatefulWidget {
  const GoalStatsPage({super.key});

  @override
  State<GoalStatsPage> createState() => _GoalStatsPageState();
}

class _GoalStatsPageState extends State<GoalStatsPage> {
  final _dao = GoalDao();
  late Future<_StatsBundle> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_StatsBundle> _load() async {
    final stats = await _dao.getStatsSummary();
    final recent = await _dao.listActionRecordViews(limit: 5);
    return _StatsBundle(stats: stats, recent: recent);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('目标模块数据看板')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: FutureBuilder<_StatsBundle>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            return Center(child: Text(snap.error?.toString() ?? '加载失败'));
          }
          final s = snap.data!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            children: [
              _hero(),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                childAspectRatio: 1.45,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _statCard('课程正文', '${s.stats['segments'] ?? 0}', '36 段原文作为学习底座'),
                  _statCard('概念实践卡', '${s.stats['concepts'] ?? 0}', '每段课程外挂概念实践层'),
                  _statCard('已复习正文', '${s.stats['reviewed'] ?? 0}', '打开正文详情后会计入复习轨迹'),
                  _statCard('收藏/重点/难点', '${(s.stats['favorites'] ?? 0)}/${(s.stats['keys'] ?? 0)}/${(s.stats['difficult'] ?? 0)}', '便于回看与复习'),
                  _statCard('行动记录', '${s.stats['actions'] ?? 0}', '执行次数与复盘痕迹'),
                  _statCard('二次复盘', '${s.stats['followups'] ?? 0}', '继续 / 调整 / 放弃 的闭环决策'),
                  _statCard('场景任务 / 奖励', '${s.stats['worldScenes'] ?? 0}/${s.stats['worldRewards'] ?? 0}', '目标试验场完成数与已领奖励'),
                ],
              ),
              const SizedBox(height: 12),
              _card(
                title: '最近行动',
                child: s.recent.isEmpty
                    ? const Text('还没有行动记录。')
                    : Column(
                        children: [
                          for (final item in s.recent)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF9FAFB),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(child: Text(item.actionTitle, style: const TextStyle(fontWeight: FontWeight.w800))),
                                        if (item.hasFollowup) ...[
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF111827),
                                              borderRadius: BorderRadius.circular(999),
                                            ),
                                            child: Text(item.followupDecision, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                                          ),
                                          const SizedBox(width: 8),
                                        ],
                                        Text('${(item.record.completionRate * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w700)),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(item.conceptTitle, style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _hero() => _card(
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('成长不是只看页面数量', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
            SizedBox(height: 8),
            Text(
              '这个看板帮助你看到：课程原文、概念实践、收藏复习和现实行动是否真正形成闭环。',
              style: TextStyle(height: 1.6, color: Color(0xFF4B5563)),
            ),
          ],
        ),
      );

  Widget _statCard(String title, String value, String subtitle) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF374151))),
            const Spacer(),
            Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.45, color: Color(0xFF6B7280))),
          ],
        ),
      );

  Widget _card({String? title, required Widget child}) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (title != null) ...[
              Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
            ],
            child,
          ],
        ),
      );
}

class _StatsBundle {
  final Map<String, int> stats;
  final List<GoalActionRecordView> recent;
  _StatsBundle({required this.stats, required this.recent});
}
