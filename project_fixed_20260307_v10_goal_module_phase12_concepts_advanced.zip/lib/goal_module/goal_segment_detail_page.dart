import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'goal_concept_detail_page.dart';
import 'goal_dao.dart';
import 'goal_models.dart';

class GoalSegmentDetailPage extends StatefulWidget {
  final String segmentId;
  const GoalSegmentDetailPage({super.key, required this.segmentId});

  @override
  State<GoalSegmentDetailPage> createState() => _GoalSegmentDetailPageState();
}

class _GoalSegmentDetailPageState extends State<GoalSegmentDetailPage> {
  final _dao = GoalDao();
  late Future<_SegmentBundle> _future;

  @override
  void initState() {
    super.initState();
    _future = _load(markViewed: true);
  }

  Future<_SegmentBundle> _load({bool markViewed = false}) async {
    if (markViewed) {
      await _dao.touchSegmentReviewed(widget.segmentId);
    }
    final segment = await _dao.getSegment(widget.segmentId);
    if (segment == null) throw Exception('内容不存在');
    final review = await _dao.getSegmentReview(widget.segmentId);
    final concepts = await _dao.listConceptCardsForSegment(widget.segmentId);
    return _SegmentBundle(segment: segment, review: review, concepts: concepts);
  }

  Future<void> _toggleReview(_SegmentBundle bundle, {bool? favorite, bool? difficult, bool? key}) async {
    await _dao.saveSegmentReview(
      segmentId: bundle.segment.segmentId,
      isFavorited: favorite ?? bundle.review.isFavorited,
      isDifficult: difficult ?? bundle.review.isDifficult,
      isKey: key ?? bundle.review.isKey,
    );
    if (!mounted) return;
    setState(() => _future = _load());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('课程原文')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: FutureBuilder<_SegmentBundle>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            return Center(child: Text(snap.error?.toString() ?? '内容不存在'));
          }
          final bundle = snap.data!;
          final s = bundle.segment;
          final review = bundle.review;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _chip(s.sourceCourseName),
                        _chip('第${s.segmentNo}段'),
                        _chip(s.moduleGroup),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(s.sectionTitle, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    if (s.tags.isNotEmpty)
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [for (final t in s.tags) _chip(t, dark: false)],
                      ),
                    const SizedBox(height: 16),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _toggleChip(
                          label: review.isFavorited ? '已收藏' : '收藏',
                          selected: review.isFavorited,
                          icon: review.isFavorited ? Icons.favorite : Icons.favorite_border,
                          onTap: () => _toggleReview(bundle, favorite: !review.isFavorited),
                        ),
                        _toggleChip(
                          label: review.isDifficult ? '已标难点' : '标记难点',
                          selected: review.isDifficult,
                          icon: Icons.help_outline,
                          onTap: () => _toggleReview(bundle, difficult: !review.isDifficult),
                        ),
                        _toggleChip(
                          label: review.isKey ? '已标重点' : '标记重点',
                          selected: review.isKey,
                          icon: Icons.push_pin_outlined,
                          onTap: () => _toggleReview(bundle, key: !review.isKey),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    SelectableText(
                      s.segmentText,
                      style: const TextStyle(fontSize: 16, height: 1.75, color: Color(0xFF1F2937)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('关联概念实践', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    const Text('原课程正文保持原样，下面这些概念卡会围绕它做解释、互动和现实行动。', style: TextStyle(height: 1.6, color: Color(0xFF4B5563))),
                    const SizedBox(height: 12),
                    if (bundle.concepts.isEmpty)
                      const Text('暂未找到关联概念。')
                    else
                      ...bundle.concepts.map((c) => Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Material(
                              color: const Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.circular(14),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(14),
                                onTap: () => Navigator.of(context).push(
                                  CupertinoPageRoute(builder: (_) => GoalConceptDetailPage(conceptId: c.conceptId)),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.lightbulb_outline, color: Color(0xFF111827)),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(c.conceptTitle, style: const TextStyle(fontWeight: FontWeight.w800)),
                                            const SizedBox(height: 4),
                                            Text(c.oneLineDefinition, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF6B7280), height: 1.4)),
                                          ],
                                        ),
                                      ),
                                      const Icon(Icons.chevron_right, color: Color(0xFF9CA3AF)),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          )),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _chip(String text, {bool dark = true}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF111827) : const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: dark ? Colors.white : const Color(0xFF374151),
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _toggleChip({required String label, required bool selected, required IconData icon, required VoidCallback onTap}) {
    return Material(
      color: selected ? const Color(0xFF111827) : const Color(0xFFF3F4F6),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: selected ? Colors.white : const Color(0xFF374151)),
              const SizedBox(width: 6),
              Text(label, style: TextStyle(color: selected ? Colors.white : const Color(0xFF374151), fontWeight: FontWeight.w700, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SegmentBundle {
  final GoalCourseSegment segment;
  final GoalSegmentReview review;
  final List<GoalConceptCard> concepts;
  _SegmentBundle({required this.segment, required this.review, required this.concepts});
}
