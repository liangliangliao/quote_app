package com.example.quote_app.am;
import android.content.Context;
import java.io.File;
public final class DbPaths {
  private DbPaths(){}
  public static String quotesDbPath(Context ctx){
    File appFlutter = new File(ctx.getFilesDir(), "../app_flutter");
    return new File(appFlutter, "quotes.db").getAbsolutePath();
  }
}
