package com.example.quote_app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.util.Log
import java.lang.reflect.Method
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.abs

object BaiduLocator {

    private const val TAG = "BaiduLocator"

    /**
     * Try Baidu SDK via reflection. If not available, fall back to Android LocationManager.
     * Always returns a serializable Map for Flutter.
     */
    fun getBaiduLocationOnce(ctx: Context, timeoutMs: Long = 30_000L): Map<String, Any?> {
        // 1) Try Baidu SDK reflectively
        try {
            val clientCls = Class.forName("com.baidu.location.LocationClient")
            val optionCls = Class.forName("com.baidu.location.LocationClientOption")
            val listenerCls = Class.forName("com.baidu.location.BDLocationListener")
            val bdLocCls = Class.forName("com.baidu.location.BDLocation")

            @Suppress("UNCHECKED_CAST")
            val client = clientCls.getConstructor(Context::class.java).newInstance(ctx)

            // option
            val option = optionCls.newInstance()
            optionCls.getMethod("setOpenGps", Boolean::class.javaPrimitiveType).invoke(option, true)
            optionCls.getMethod("setLocationMode", optionCls.getMethod("getLocationMode").returnType).invoke(
                option,
                optionCls.getField("Hight_Accuracy").get(null)
            )
            optionCls.getMethod("setCoorType", String::class.java).invoke(option, "wgs84")
            optionCls.getMethod("setIsNeedAddress", Boolean::class.javaPrimitiveType).invoke(option, true)
            optionCls.getMethod("setScanSpan", Int::class.javaPrimitiveType).invoke(option, 0)
            clientCls.getMethod("setLocOption", optionCls).invoke(client, option)

            // single run synchronization
            var done = false
            var lat = 0.0
            var lon = 0.0
            var acc = 0.0
            var addr: String? = null
            val lock = java.lang.Object()

            // Build listener
            val listener = java.lang.reflect.Proxy.newProxyInstance(
                listenerCls.classLoader,
                arrayOf(listenerCls)
            ) { _, method, args ->
                if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
                    val bdLoc = args[0]
                    try {
                        lat = bdLocCls.getMethod("getLatitude").invoke(bdLoc) as Double
                        lon = bdLocCls.getMethod("getLongitude").invoke(bdLoc) as Double
                        acc = (bdLocCls.getMethod("getRadius").invoke(bdLoc) as Number).toDouble()
                        addr = bdLocCls.getMethod("getAddrStr").invoke(bdLoc) as String?
                    } catch (e: Throwable) {
                        Log.w(TAG, "read BD fields failed: ${e.message}")
                    }
                    synchronized(lock) {
                        done = true
                        lock.notifyAll()
                    }
                }
                null
            }

            clientCls.getMethod("registerLocationListener", listenerCls).invoke(client, listener)
            clientCls.getMethod("start").invoke(client)
            // Wait up to timeout
            val start = System.currentTimeMillis()
            synchronized(lock) {
                while (!done && System.currentTimeMillis() - start < timeoutMs) {
                    lock.wait(300L)
                }
            }
            // Stop client
            try { clientCls.getMethod("stop").invoke(client) } catch (_: Throwable) {}

            if (done && !(lat == 0.0 && lon == 0.0)) {
                val m = mutableMapOf<String, Any?>(
                    "provider" to "baidu",
                    "lat" to lat,
                    "lon" to lon,
                    "acc" to acc,
                    "address" to addr
                )
                return m
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Baidu SDK unavailable or failed: ${e.message}")
        }

        // 2) Fallback to Android system
        val sys = getSystemLocationOnce(ctx, timeoutMs)
        return sys
    }

    @SuppressLint("MissingPermission")
    private fun getSystemLocationOnce(ctx: Context, timeoutMs: Long): Map<String, Any?> {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null

        fun upd(l: Location?) {
            if (l == null) return
            if (best == null || (l.accuracy < best!!.accuracy)) best = l
        }

        // last known
        try { upd(lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)) } catch (_: Throwable) {}
        try { upd(lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)) } catch (_: Throwable) {}

        // actively request one update if lacking
        var received = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                upd(location)
                received = true
            }
            @Deprecated("deprecated") override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {}
            override fun onProviderEnabled(p0: String) {}
            override fun onProviderDisabled(p0: String) {}
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
        } catch (_: Throwable) {}

        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs && best == null) {
            try { Thread.sleep(200) } catch (_: InterruptedException) {}
        }
        try { lm.removeUpdates(listener) } catch (_: Throwable) {}

        val lat = best?.latitude ?: 0.0
        val lon = best?.longitude ?: 0.0
        val acc = best?.accuracy?.toDouble() ?: 0.0
        return mutableMapOf<String, Any?>(
            "provider" to "system",
            "lat" to lat,
            "lon" to lon,
            "acc" to acc,
            "address" to null
        )
    }

    fun reverseGeocodeBaidu(lat: Double, lon: Double, ak: String): Map<String, Any?> {
        if (ak.isBlank()) {
            return mapOf("ok" to false, "error" to "ak_empty")
        }
        val url = StringBuilder()
            .append("https://api.map.baidu.com/reverse_geocoding/v3/?")
            .append("ak=").append(URLEncoder.encode(ak, "UTF-8"))
            .append("&output=json")
            .append("&coordtype=wgs84ll")
            .append("&location=").append(lat).append(",").append(lon)
            .append("&radius=50&ret_coordtype=wgs84ll&extensions_poi=1&page_size=50&page_num=0")
            .toString()
        return try {
            val u = URL(url)
            val conn = u.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.instanceFollowRedirects = true
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(text)
            val status = json.optInt("status", -1)
            if (status == 0) {
                val result = json.getJSONObject("result")
                val addr = result.optString("formatted_address", "")
                val sema = result.optJSONObject("sematic_description")?.toString() ?: ""
                mapOf(
                    "ok" to true,
                    "address" to addr,
                    "raw" to json.toString()
                )
            } else {
                mapOf("ok" to false, "error" to "baidu_status_$status", "raw" to json.toString())
            }
        } catch (e: Throwable) {
            mapOf("ok" to false, "error" to (e.message ?: "network_error"))
        }
    }
}
