import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'notification_service.dart';
import '../data/db.dart';
import 'scheduler_service.dart';
import '../utils/run_context.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    RunContext.isBackground = true;  // 后台运行标记
    RunContext.isBackground = true;  // 后台运行标记
    try { WidgetsFlutterBinding.ensureInitialized(); ui.DartPluginRegistrant.ensureInitialized(); await DLog.i('WM','插件初始化完成'); }
    catch (e) { await DLog.e('WM','插件初始化失败: ' + e.toString()); }
    try { await NotificationService.init(); await DLog.i('WM','通知初始化完成'); }
    catch (e) { await DLog.e('WM','通知初始化失败: ' + e.toString()); }
    try { await AppDatabase.instance(); await DLog.i('WM','数据库初始化完成'); }
    catch (e) { await DLog.e('WM','数据库初始化失败: ' + e.toString()); }
    await DLog.i('WM', '后台任务启动（WorkManager）');
    await DLog.i('WM', 'workmanager dispatch');
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    await SchedulerService.callback();
    // 补发一次（当天漏发）
    try {
      await SchedulerService.catchupIfMissed();
    } catch (e, s) {
      DLog.e('services/wm_dispatcher.dart', 'catch: ' + e.toString());
    }
    return true;
  });
}