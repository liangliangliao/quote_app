package com.example.quote_app

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.app.Notification
import android.app.NotificationManager
import android.app.NotificationChannel
import android.os.Build
import androidx.core.app.NotificationCompat

class NativeNotifyService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    private fun inc(key: String) {
        val sp = getSharedPreferences("quote_diag", MODE_PRIVATE)
        sp.edit().putInt(key, sp.getInt(key, 0)+1).apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        android.util.Log.d("QuoteSvc", "onStartCommand nid=" + (intent?.getIntExtra("nid", -1) ?: -1))
        inc("svc_hits")

        val title = intent?.getStringExtra("title") ?: "提醒"
        val body = intent?.getStringExtra("body") ?: "到点啦"
        val nid = intent?.getIntExtra("nid", 1002) ?: 1002

        val channelId = NotificationUtils.DEFAULT_CHANNEL_ID
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(NotificationChannel(channelId, "General", NotificationManager.IMPORTANCE_HIGH))
            }
        }

        val fg: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("正在发送提醒…")
            .setContentText(title)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setOngoing(true)
            .build()
        startForeground(42, fg)

        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        nm.notify(nid, n)

        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
        return START_NOT_STICKY
    }
}
