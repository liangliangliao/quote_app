package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val req = OneTimeWorkRequestBuilder<NotifyWorker>()
                .addTag("boot_reschedule")
                .setInputData(workDataOf("job" to "selfcheck_boot"))
                .build()
            WorkManager.getInstance(context).enqueue(req)
        } catch (e: Exception) { /* ignore */ }
    }
}
