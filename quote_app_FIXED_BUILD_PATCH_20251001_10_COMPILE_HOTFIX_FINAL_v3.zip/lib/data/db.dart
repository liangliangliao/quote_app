
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 6,
      onCreate: _create,
      onUpgrade: _upgrade,
    );
    await _db!.execute('PRAGMA foreign_keys = ON');
    return _db!;
  }

  static Future<void> _create(Database db, int version) async {
    // Configs
    await db.execute('''
      CREATE TABLE configs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        api_key TEXT,
        model TEXT,
        endpoint TEXT
      )
    ''');
    await db.insert('configs', {
      'api_key': '',
      'model': 'gpt-5',
      'endpoint': 'https://api.openai.com/v1/responses'
    });

    // Meta key-value
    await db.execute('''
      CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');

    // Tasks
    await db.execute('''
      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT UNIQUE,
        name TEXT,
        type TEXT,          -- manual | auto | carousel
        status TEXT,        -- on | off
        prompt TEXT,        -- for auto
        avatar_path TEXT,   -- icon path
        start_time TEXT,    -- 'HH:mm' or 'YYYY-MM-DD HH:mm[:ss]'
        next_time TEXT,     -- absolute next run time ISO8601
        scheduled_run_key TEXT,  -- last scheduled run key (for precise cancel)
        freq_type TEXT,     -- daily | weekly | monthly | custom
        freq_weekday INTEGER,       -- 1-7 (Mon-Sun) when weekly
        freq_day_of_month INTEGER,  -- 1-31 when monthly
        freq_custom TEXT             -- reserved
      )
    ''');

    // Quotes
    await db.execute('''
      CREATE TABLE quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_uid TEXT UNIQUE,
        task_uid TEXT,
        content TEXT,
        notified INTEGER DEFAULT 0,
        created_at INTEGER,
        FOREIGN KEY(task_uid) REFERENCES tasks(task_uid) ON DELETE CASCADE
      )
    ''');

    // Logs
    await db.execute('''
      CREATE TABLE logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_uid TEXT UNIQUE,
        task_uid TEXT,
        detail TEXT,
        created_at INTEGER,
        task_name_snapshot TEXT,
        task_start_time_snapshot TEXT
      )
    ''');
  }

  static Future<void> _ensureMeta(Database db) async {
    // placeholder if future migrations need to alter meta schema
  }

  static Future<void> _upgrade(Database db, int oldV, int newV) async {
    if (oldV < 5) {
      // Best-effort ensure required tables/columns exist
      await db.execute("CREATE TABLE IF NOT EXISTS configs (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT, model TEXT, endpoint TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT UNIQUE, name TEXT, type TEXT, status TEXT, prompt TEXT, avatar_path TEXT, start_time TEXT, freq_type TEXT, freq_weekday INTEGER, freq_day_of_month INTEGER, freq_custom TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, quote_uid TEXT UNIQUE, task_uid TEXT, content TEXT, notified INTEGER DEFAULT 0, created_at INTEGER)");
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT, created_at INTEGER, task_name_snapshot TEXT, task_start_time_snapshot TEXT)");
      // Ensure snapshots columns
      final info = await db.rawQuery("PRAGMA table_info(logs)");
      final cols = info.map((e)=> e['name'] as String).toList();
      if (!cols.contains('task_name_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_name_snapshot TEXT");
      }
      if (!cols.contains('task_start_time_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_start_time_snapshot TEXT");
      }

    if (oldV < 6) {
      // Ensure new task columns exist
      final infoT = await db.rawQuery("PRAGMA table_info(tasks)");
      final colsT = infoT.map((e)=> e['name'] as String).toList();
      if (!colsT.contains('next_time')) {
        try { await db.execute("ALTER TABLE tasks ADD COLUMN next_time TEXT"); } catch (_) {}
      }
      if (!colsT.contains('scheduled_run_key')) {
        try { await db.execute("ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT"); } catch (_) {}
      }
    }
    }
  }
}
