package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 解锁广播入口：
 * 1) 优先检查配置表中的地点规则开关；若关闭，直接返回（不触发已有的解锁轻提醒链路）
 * 2) 若开启，立即启动前台服务 GeoForegroundService 执行地点规则通知（不进入 WorkManager）
 * 3) 额外启动一个线程执行“解锁轻提醒”逻辑
 * 4) 所有关键步骤写中文日志（DbRepo.log 内部已自动追加当前时间）
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    try {
      // ① 优先检查地点规则总开关
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
      var enabled = false
      if (cc != null && cc.dbPath != null) {
        val db = android.database.sqlite.SQLiteDatabase.openDatabase(
          cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY
        )
        try {
          db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c ->
            if (c.moveToFirst()) enabled = (c.getInt(0) == 1)
          }
        } finally {
          try { db.close() } catch (_: Throwable) {}
        }
      }
      if (!enabled) {
        try {
          DbRepo.log(context, null, "【解锁后台】地点规则开关=关闭，直接返回；不触发解锁轻提醒")
        } catch (_: Throwable) {}
        return
      }

      // ② 开关=开启：启动前台服务执行地点规则逻辑
      try {
        val svc = Intent(context, GeoForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
          context.startForegroundService(svc)
        } else {
          context.startService(svc)
        }
        try {
          DbRepo.log(context, null, "【解锁后台】已启动 GeoForegroundService 前台服务进行地点规则检查与提醒")
        } catch (_: Throwable) {}
        try {
          Toast.makeText(context.applicationContext, "正在后台执行地点提醒...", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {}
      } catch (t: Throwable) {
        try {
          DbRepo.log(context, null, "【解锁后台】启动 GeoForegroundService 失败：" + (t.message ?: "unknown"))
        } catch (_: Throwable) {}
      }

      // ③ 第二个线程：解锁轻提醒（保持原有业务逻辑，封装在线程中）
      try {
        Thread {
          try {
            DbRepo.log(context, null, "【解锁后台】解锁轻提醒线程启动")
            UnlockWorker.runInlineOnce(context.applicationContext)
            DbRepo.log(context, null, "【解锁后台】解锁轻提醒线程结束")
          } catch (t: Throwable) {
            try {
              DbRepo.log(context, null, "【解锁后台】解锁轻提醒线程异常：" + (t.message ?: "unknown"))
            } catch (_: Throwable) {}
          }
        }.start()
      } catch (_: Throwable) {
        // 忽略线程创建异常
      }
    } catch (t: Throwable) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 总入口异常：" + (t.message ?: "unknown"))
      } catch (_: Throwable) {}
    }
  }
}
