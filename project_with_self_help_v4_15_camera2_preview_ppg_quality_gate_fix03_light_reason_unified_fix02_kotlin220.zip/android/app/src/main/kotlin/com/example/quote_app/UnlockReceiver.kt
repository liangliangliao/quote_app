package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.os.Build
import android.widget.Toast
import kotlin.concurrent.thread
import android.os.Handler
import android.os.Looper
import com.example.quote_app.data.DbRepo

/**
 * 解锁广播入口（不使用前台服务）：
 * 1) 立刻记录解锁时间戳（供 App 启动兜底判断）
 * 2) 触发 UnlockWorker（解锁轻提醒 + 冷却逻辑）
 * 3) 触发 GeoWorker.triggerOnce（地点规则一次性检查）
 *
 * 说明：
 * - 所有耗时/IO 交给 WorkManager，onReceive 只做快速调度，减少“解锁广播延迟/被系统忽略”的概率。
 * - 不启用前台服务，因此不会出现常驻通知。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val appCtx = context.applicationContext

    // Record last unlock ts ASAP (used by App startup fallback logic).
    try {
      val sp = appCtx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
      sp.edit().putLong("last_user_present_ts", System.currentTimeMillis()).apply()
    } catch (_: Throwable) {}

    // Use goAsync so we can safely finish work off the main thread.
    val pending = goAsync()
    val act = intent?.action ?: "unknown"
    kotlin.concurrent.thread(name = "unlock-dispatch") {
      try {
        try { logWithTime(appCtx, "【解锁后台】收到解锁广播 action=$act，开始调度 WorkManager（回包：OK）") } catch (_: Throwable) {}

        // 解锁轻提醒（含开关 + 冷却 + 发通知）
        try { UnlockWorker.trigger(appCtx) } catch (_: Throwable) {
          try { logWithTime(appCtx, "【解锁后台】触发 UnlockWorker 失败（回包：FAIL）") } catch (_: Throwable) {}
        }

        // 地点规则一次性检查（不使用前台服务，不产生常驻通知）
        try { GeoWorker.triggerOnce(appCtx, reason = "unlock") } catch (_: Throwable) {
          try { logWithTime(appCtx, "【解锁后台】触发 GeoWorker.triggerOnce 失败（回包：FAIL）") } catch (_: Throwable) {}
        }
      } finally {
        try { pending.finish() } catch (_: Throwable) {}
      }
    }
  }

  /**
   * 写入包含时间戳的日志。
   */
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}
