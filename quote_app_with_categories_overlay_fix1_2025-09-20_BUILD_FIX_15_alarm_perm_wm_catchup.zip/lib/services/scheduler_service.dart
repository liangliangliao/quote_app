import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'wm_dispatcher.dart';
import 'package:workmanager/workmanager.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import '../platform/perm_helper.dart';

class SchedulerService {

  /// WorkManager 后台兜底：当用户未授予精确闹钟或被系统强限电时，
  /// 以 15 分钟粒度唤醒一次执行 callback()，保证后台也能收到通知（可能会有延迟）。
  );
  }

  static Future<void> init() async {
    // 初始化 Workmanager（一次即可）
    try {
      await Workmanager().initialize(workmanagerCallbackDispatcher, isInDebugMode: false);
    } catch (_) {}
    // 根据精确闹钟权限，决定是否启用后台兜底任务
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact) {
      try {
        await Workmanager().registerPeriodicTask(
          'due_check_periodic',
          'due_check_periodic',
          frequency: const Duration(minutes: 15),
          initialDelay: const Duration(minutes: 15),
          existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
          constraints: Constraints(
            networkType: NetworkType.notRequired,
            requiresBatteryNotLow: false,
            requiresCharging: false,
            requiresDeviceIdle: false,
          ),
        );
      } catch (_) {}
    } else {
      try { await Workmanager().cancelByUniqueName('due_check_periodic'); } catch (_) {}
    }

    await AndroidAlarmManager.initialize();
    // 记录精确闹钟权限状态（不弹任何引导）
    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (!ok) { await LogDao().add(taskUid: 'system', detail: '警告! 系统未授予精确闹钟权限(Alarms & reminders)。Android 14+ 默认关闭。'); }
    } catch (_) {}

    await scheduleNextForAll();
  }

  static int _alarmIdForTask(String taskUid) {
    // stable 31-bit hash
    int h = 0;
    for (int i=0;i<taskUid.length;i++) {
      h = (h * 131 + taskUid.codeUnitAt(i)) & 0x7fffffff;
    }
    return h;
  }

  static DateTime _computeNext(Map<String,dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    String freq = (t['freq_type'] ?? 'daily') as String;
    int? weekday = t['freq_weekday'] as int?;
    int? dayOfMonth = t['freq_day_of_month'] as int?;
    final startStr = (t['start_time'] ?? '') as String;
    int hh = 9, mm = 0;
    if (startStr.contains(' ')) {
      final hm = startStr.split(' ')[1].split(':');
      if (hm.length==2) {
        hh = int.tryParse(hm[0]) ?? 9;
        mm = int.tryParse(hm[1]) ?? 0;
      }
    }
    if (freq == 'weekly') {
      final wd = (weekday ?? 1);
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freq == 'monthly') {
      final d = (dayOfMonth ?? 1);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      final today = DateTime(now.year, now.month, now.day, hh, mm);
      if (today.isAfter(now)) return today;
      return today.add(const Duration(days: 1));
    }
  }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final next = _computeNext(t);
      // Persist next into tasks.start_time —— 1.1需求
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [t['task_uid']]);
      final id = _alarmIdForTask(t['task_uid'] as String);
      final canExact = await PermHelper.hasExactAlarmPermission();
      final ok = await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: canExact,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
      if (!ok) {
        try { await LogDao().add(taskUid: t['task_uid'] as String, detail: '⚠️闹钟注册失败: exact='+canExact.toString()); } catch (_) {}
      }
    }
  }

  static Future<void> callback() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nowStr = _fmt(now);
    final tasks = await db.query('tasks');
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final start = (t['start_time'] ?? '') as String;
      // fire if start_time <= now + 59s window
      if (start.isEmpty) continue;
      if (!_isDue(start, now)) continue;

      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        final content = (q?['content'] ?? '') as String;
        if (content.isNotEmpty) {
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          await LogDao().add(taskUid: taskUid, detail: '手动任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '手动任务没有可发送内容');
        }
      } else if (type == 'carousel') {
        var q = await QuoteDao().carouselNextSequential(taskUid);
if (q == null) {
  const def = '保持饥饿，保持愚蠢。—— 史蒂夫·乔布斯';
  final exists = await QuoteDao().existsSimilar(def, threshold: 0.9);
  if (!exists) {
    await QuoteDao().insertIfUnique(
      taskUid: taskUid,
      type: 'carousel',
      taskName: name,
      avatarPath: avatar,
      content: def,
    );
  }
  q = await QuoteDao().carouselNextSequential(taskUid);
  if (q == null) {
    // 仍为空，写日志并返回
    await LogDao().add(taskUid: taskUid, detail: '错误! 轮播无可用名言（兜底失败）');
    return;
  }
}

        if (q != null) {
          final content = (q['content'] ?? '') as String;
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          await QuoteDao().markNotified(q['id'] as int);
          await LogDao().add(taskUid: taskUid, detail: '轮播任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '轮播任务无可用名言');
        }
      } else {
        // auto
        final cfg = await ConfigDao().getOne();
        try {
          final openai = OpenAIService(
            endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
            apiKey: (cfg['api_key'] ?? '') as String,
            model: (cfg['model'] ?? 'gpt-5') as String,
          );
          final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;
          String? uid;
          for (int i=0; i<10; i++) {
            final quote = (await openai.generateQuote(prompt)).trim();
            if (quote.isEmpty) break;
            final exists = await QuoteDao().existsSimilar(quote, threshold: 0.9);
            if (exists) {
              if (i==9) {
                await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
              }
              continue;
            }
            uid = await QuoteDao().insertIfUnique(
              taskUid: taskUid,
              type: 'auto',
              taskName: name,
              avatarPath: avatar,
              content: quote,
            );
            break;
          }
          if (uid != null) {
            final q = await QuoteDao().latestForTask(taskUid);
            final content = (q?['content'] ?? '') as String;
            if (content.isNotEmpty) {
              await NotificationService.show(
                id: _alarmIdForTask(taskUid),
                title: name,
                body: content,
                largeIconPath: avatar.isEmpty ? null : avatar,
              );
              await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送');
              final db2 = await AppDatabase.instance();
              await db2.update('quotes', {'notified': 1}, where: 'id=?', whereArgs: [q?['id']]);
            }
          }
        } catch (e) {
          await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
        }
      }

      // After firing: compute next and persist + reschedule
      final next = _computeNext(t, from: now.add(const Duration(seconds: 1)));
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
      final id = _alarmIdForTask(taskUid);
      final canExact = await PermHelper.hasExactAlarmPermission();
      final ok = await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: canExact,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
      if (!ok) {
        try { await LogDao().add(taskUid: t['task_uid'] as String, detail: '⚠️闹钟注册失败: exact='+canExact.toString()); } catch (_) {}
      }
    }
  }

  static bool _isDue(String start, DateTime now) {
    // start format: YYYY-MM-DD HH:mm
    try {
      final dt = DateFormat('yyyy-MM-dd HH:mm').parse(start);
      return !dt.isAfter(now);
    } catch (_) {
      return false;
    }
  }
}

@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await AppDatabase.instance();
  await SchedulerService.callback();
}

String _fmt(DateTime dt) {
  final f = DateFormat('yyyy-MM-dd HH:mm');
  return f.format(dt);
}



Future<void> _catchupIfMissed() async {
  try {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final dayStart = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final dayEnd = DateTime(now.year, now.month, now.day, 23, 59, 59, 999).millisecondsSinceEpoch;

    final tasks = await TaskDao().all();
    for (final t in tasks) {
      final status = (t['status'] ?? '') as String;
      if (status != 'active') continue;

      final uid = (t['task_uid'] ?? '') as String? ?? '';
      if (uid.isEmpty) continue;

      final st = (t['start_time'] ?? '') as String? ?? '';
      if (st.isEmpty) continue;

      // parse time: 'HH:mm' or 'yyyy-MM-dd HH:mm'
      DateTime? planned;
      try {
        if (RegExp(r'^\d{2}:\d{2}$').hasMatch(st)) {
          final p = st.split(':');
          planned = DateTime(now.year, now.month, now.day, int.parse(p[0]), int.parse(p[1]));
        } else if (RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$').hasMatch(st)) {
          final yyyy = int.parse(st.substring(0,4));
          final mm = int.parse(st.substring(5,7));
          final dd = int.parse(st.substring(8,10));
          final HH = int.parse(st.substring(11,13));
          final MM = int.parse(st.substring(14,16));
          planned = DateTime(yyyy, mm, dd, HH, MM);
        }
      } catch (_) {}

      if (planned == null) continue;
      if (planned.isAfter(now)) continue; // not yet time

      // already sent today?
      final sent = await db.query('logs',
        where: 'task_uid=? AND created_at BETWEEN ? AND ?',
        whereArgs: [uid, dayStart, dayEnd],
        limit: 1);
      if (sent.isNotEmpty) continue;

      String title = (t['name'] ?? '提醒') as String? ?? '提醒';
      String body = '今日定时提醒已补发';
      String? largeIconPath;

      try {
        final type = (t['type'] ?? '') as String;
        if (type == 'carousel') {
          final q = await QuoteDao().carouselNextSequential(uid);
          if (q != null) {
            final content = q['content']?.toString() ?? '';
            final author = q['author']?.toString() ?? '';
            body = author.isNotEmpty ? '$content —— $author' : content;
            largeIconPath = (q['avatar'] ?? '') as String?;
          }
        }
      } catch (_) {}

      await NotificationService.show(
        id: uid.hashCode & 0x7fffffff,
        title: title,
        body: body,
        largeIconPath: largeIconPath ?? '',
      );
      await LogDao().add(taskUid: uid, detail: '补发：' + body);
    }
  } catch (_) {}
}
