import 'package:sqflite/sqflite.dart';
import 'db.dart';

class ConfigDao {
  Future<void> save({required String apiKey, required String model, required String endpoint}) async {
    final db = await AppDatabase.instance();
    await db.execute('CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY, value TEXT)');
    Future<void> put(String k, String v) async {
      await db.insert('config', {'key': k, 'value': v}, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await put('api_key', apiKey);
    await put('model', model);
    await put('endpoint', endpoint);
  }

  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('config', limit: 1);
    if (rows.isEmpty) {
      await db.insert('config', {'endpoint':'https://api.openai.com/v1', 'api_key':'', 'model':'gpt-5'});
      return {'endpoint':'https://api.openai.com/v1', 'api_key':'', 'model':'gpt-5'};
    }
    return rows.first;
  }

  Future<void> setAll({required String endpoint, required String apiKey, required String model}) async {
    final db = await AppDatabase.instance();
    await db.delete('config');
    await db.insert('config', {'endpoint': endpoint, 'api_key': apiKey, 'model': model});
  }
}

class NotifyConfigDao {
  Future<int> getSelfCheckMinutes() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_config', limit: 1);
    if (rows.isEmpty) return 30;
    final v = rows.first['self_check_minutes'];
    return (v is int) ? v : int.tryParse(v.toString()) ?? 30;
  }

  Future<void> setSelfCheckMinutes(int m) async {
    if (m < 1) m = 1;
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_config', limit: 1);
    if (rows.isEmpty) {
      await db.insert('notify_config', {'self_check_minutes': m});
    } else {
      await db.update('notify_config', {'self_check_minutes': m});
    }
  }
}

class TaskDao {
  Future<Map<String, dynamic>?> getByUid(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'uid=?', whereArgs: [uid], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return db.query('tasks', orderBy: 'trigger_at DESC');
  }

  Future<void> upsertScheduledRunKey(String uid, String runKey) async {
    final db = await AppDatabase.instance();
    try {
      await db.update('tasks', {'scheduled_run_key': runKey}, where: 'uid=?', whereArgs: [uid]);
    } catch (_) {
      await db.execute("ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
      await db.update('tasks', {'scheduled_run_key': runKey}, where: 'uid=?', whereArgs: [uid]);
    }
  }
Future<Map<String,Object?>> _filterToExistingColumns(String table, Map<String,Object?> values) async {
  final db = await AppDatabase.instance();
  final info = await db.rawQuery("PRAGMA table_info(" + table + ")");
  final cols = info.map((e) => e['name'] as String).toSet();
  final out = <String,Object?>{};
  values.forEach((k,v){ if (cols.contains(k)) out[k]=v; });
  return out;
}
Future<int> delete(String uid) async {
  final db = await AppDatabase.instance();
  return db.delete('tasks', where: 'uid=?', whereArgs: [uid]);
}

Future<int> update(String uid, Map<String,Object?> patch) async {
  final db = await AppDatabase.instance();
  final filtered = await _filterToExistingColumns('tasks', patch);
  if (filtered.isEmpty) return 0;
  return db.update('tasks', filtered, where: 'uid=?', whereArgs: [uid]);
}

Future<String> create({required String name, required String type, required String startTime, String? prompt, String? avatarPath, String? status, String? freqType, int? freqWeekday, int? freqDayOfMonth, String? freqCustom}) async {
  final db = await AppDatabase.instance();
  final uid = 'task_' + DateTime.now().millisecondsSinceEpoch.toString();
  final raw = <String,Object?>{
    'uid': uid,
    'title': name,
    'type': type,
    'prompt': prompt ?? '',
    'avatar_path': avatarPath,
    'status': status,
    'freq_type': freqType,
    'freq_weekday': freqWeekday,
    'freq_day_of_month': freqDayOfMonth,
    'freq_custom': freqCustom,
    'trigger_at': startTime,
  };
  final filtered = await _filterToExistingColumns('tasks', raw);
  await db.insert('tasks', filtered, conflictAlgorithm: ConflictAlgorithm.replace);
  return uid;
}
}

class QuoteDao {
  Future<Map<String, dynamic>?> latestForTask(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
      'SELECT * FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT 1', [uid]);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0, String? q}) async {
    final db = await AppDatabase.instance();
    if (q != null && q.isNotEmpty) {
      return db.rawQuery(
        "SELECT q.*, t.title as task_name FROM quotes q LEFT JOIN tasks t ON t.uid=q.task_uid "
        "WHERE q.content LIKE ? OR t.title LIKE ? ORDER BY q.id DESC LIMIT ? OFFSET ?",
        ['%'+q+'%', '%'+q+'%', limit, offset],
      );
    }
    return db.rawQuery(
      "SELECT q.*, t.title as task_name FROM quotes q LEFT JOIN tasks t ON t.uid=q.task_uid ORDER BY q.id DESC LIMIT ? OFFSET ?",
      [limit, offset],
    );
  }

  Future<List<Map<String,dynamic>>> all({int limit = 50, int offset = 0}) async {
    final db = await AppDatabase.instance();
    return db.rawQuery("SELECT q.*, t.title as task_name FROM quotes q LEFT JOIN tasks t ON t.uid=q.task_uid ORDER BY q.id DESC LIMIT ? OFFSET ?", [limit, offset]);
  }

  Future<void> markNotifiedByUid(String uid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'task_uid=?', whereArgs: [uid]);
  }

  Future<void> insertManual(String uid, String content) async {
    final db = await AppDatabase.instance();
    await db.insert('quotes', {'task_uid': uid, 'content': content});
  }
Future<bool> existsSimilar(String content) async {
  final db = await AppDatabase.instance();
  final rows = await db.rawQuery('SELECT id FROM quotes WHERE content=? LIMIT 1', [content]);
  return rows.isNotEmpty;
}

Future<void> insertIfUnique({required String taskUid, required String content}) async {
  final db = await AppDatabase.instance();
  final dup = await db.rawQuery('SELECT id FROM quotes WHERE task_uid=? AND content=? LIMIT 1', [taskUid, content]);
  if (dup.isEmpty) {
    await db.insert('quotes', {'task_uid': taskUid, 'content': content});
  }
}

Future<bool> updateLatestForTask(String uid, String content) async {
  final db = await AppDatabase.instance();
  final row = await latestForTask(uid);
  if (row == null) return false;
  final count = await db.update('quotes', {'content': content}, where: 'id=?', whereArgs: [row['id']]);
  return count > 0;
}
}

class LogDao {
  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0}) async {
    final db = await AppDatabase.instance();
    return db.rawQuery("SELECT * FROM logs ORDER BY id DESC LIMIT ? OFFSET ?", [limit, offset]);
  }
  Future<void> clearAll() async {
    final db = await AppDatabase.instance();
    await db.delete('logs');
  }

  Future<List<Map<String,dynamic>>> list({int limit = 50, int offset = 0}) async {
    final db = await AppDatabase.instance();
    return db.rawQuery("SELECT * FROM logs ORDER BY id DESC LIMIT ? OFFSET ?", [limit, offset]);
  }

  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {'task_uid': taskUid, 'message': detail, 'created_at': DateTime.now().millisecondsSinceEpoch ~/ 1000});
  }
}

class PayloadDao {
  Future<void> upsert({required String taskUid, required String runKey, String? title, String? content, String? avatarPath, String? actionsJson, String? payloadJson}) async {
    final db = await AppDatabase.instance();
    final values = {
      'task_uid': taskUid,
      'run_key': runKey,
      'title': title,
      'content': content,
      'avatar_path': avatarPath,
      'actions_json': actionsJson,
      'payload_json': payloadJson,
    };
    await db.insert('payloads', values, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
