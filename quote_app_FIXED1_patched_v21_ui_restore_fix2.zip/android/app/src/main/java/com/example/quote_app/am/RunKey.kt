package com.example.quote_app.am

import java.text.SimpleDateFormat
import java.util.*

object RunKey {
    private val fmt = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)

    fun windowBefore(runKey: String, minutes: Int): Pair<String,String> {
        return try {
            val t = fmt.parse(runKey)
            val cal = Calendar.getInstance().apply { time = t!! }
            val to = fmt.format(cal.time)
            cal.add(Calendar.MINUTE, -minutes)
            val from = fmt.format(cal.time)
            Pair(from, to)
        } catch (e: Throwable) {
            Pair(runKey, runKey)
        }
    }
}
