import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:quote_app/widgets/wood_frame_card.dart';

class _NoIndicatorScroll extends ScrollBehavior {
  @override
  Widget buildViewportChrome(BuildContext context, Widget child, AxisDirection axisDirection) => child;

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const ClampingScrollPhysics();
}

class OctagonClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final w = size.width, h = size.height;
    final c = 0.18;
    return Path()
      ..moveTo(c * w, 0)
      ..lineTo(w - c * w, 0)
      ..lineTo(w, c * h)
      ..lineTo(w, h - c * h)
      ..lineTo(w - c * w, h)
      ..lineTo(c * w, h)
      ..lineTo(0, h - c * h)
      ..lineTo(0, c * h)
      ..close();
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

ImageProvider _imageFrom(String? any, {String? fallbackAsset}) {
  if (any == null || any.isEmpty) return AssetImage(fallbackAsset ?? 'assets/bg-wood-upload.jpg');
  if (any.startsWith('data:')) {
    final b64 = any.substring(any.indexOf(',') + 1);
    return MemoryImage(base64.decode(b64));
  }
  if (any.startsWith('http')) return NetworkImage(any);
  if (any.startsWith('assets/')) return AssetImage(any);
  return AssetImage(fallbackAsset ?? 'assets/bg-wood-upload.jpg');
}

class PosterPureFlutter extends StatelessWidget {
  final String topic;
  final String quote;
  final String author;
  final String note;
  final String avatar;
  final String woodBgAsset;

  const PosterPureFlutter({
    super.key,
    required this.topic,
    required this.quote,
    required this.author,
    required this.note,
    required this.avatar,
    this.woodBgAsset = 'assets/bg-wood-upload.jpg',
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final short = (cons.maxWidth < cons.maxHeight) ? cons.maxWidth : cons.maxHeight;
      final tTitle = (short * 0.050).clamp(16.0, 26.0);
      final tQuote = (short * 0.085).clamp(22.0, 40.0);
      final tAuth = (short * 0.044).clamp(14.0, 22.0);
      final tNote = (short * 0.040).clamp(12.0, 18.0);
      final frameTop = (short * 0.035).clamp(14.0, 24.0);
      final frameBottom = (short * 0.035).clamp(14.0, 24.0);
      final canvasPad = 0.0;
      // 相框「边框宽度」：控制画布距离木纹内缘的距离，保持纵横一致，避免额外的空白缝隙
      // 适当加大边框厚度，避免画布视觉上“盖住”木纹相框
      final framePaddingH = 0.0;
      final framePaddingV = 0.0;
      final avatarSize = (short * 0.17).clamp(60.0, 110.0);
      const frameRadius = 12.0;
      const canvasRadius = 12.0; // 与 frameRadius 保持一致，避免画布与相框之间出现细缝

      return Container(
        color: Colors.transparent,
        alignment: Alignment.topCenter,
        // 让大相框更加贴近顶栏按钮，减小顶部留白
        padding: EdgeInsets.only(top: (short * 0.06).clamp(18.0, 30.0)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: AspectRatio(
            aspectRatio: 1024 / 1536, // match bg-wood-upload.jpg
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(frameRadius),
                // boxShadow removed per design: frame alone without outer card shadow
              ),
              child: ClipRRect(
borderRadius: BorderRadius.circular(frameRadius),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // 相框内部边距：左右 40dp，上下 50dp
                    Padding(
                      padding: EdgeInsets.fromLTRB(framePaddingH, framePaddingV, framePaddingH, framePaddingV),
                      child: ClipRRect(
          borderRadius: BorderRadius.circular(canvasRadius),
          clipBehavior: Clip.hardEdge,
 // 确保内部滚动不越界
                        child: Container(
                          color: Colors.white,
                          child: Padding(
                            padding: EdgeInsets.all(canvasPad),
                            child: ScrollConfiguration(
                              behavior: _NoIndicatorScroll(),
                              child: SingleChildScrollView(
                                physics: const ClampingScrollPhysics(),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Text(
                                            topic,
                                            style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: tTitle,
                                              height: 1.35,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 16),
                                        ClipPath(
                                          clipper: OctagonClipper(),
                                          child: Container(
                                            width: avatarSize,
                                            height: avatarSize,
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                image: _imageFrom(avatar, fallbackAsset: woodBgAsset),
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: canvasPad * 0.6),
                                    Text(
                                      quote,
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: tQuote,
                                        height: 1.4,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    SizedBox(height: canvasPad * 0.5),
                                    Text(
                                      author,
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: tAuth,
                                        height: 1.35,
                                        fontStyle: FontStyle.italic,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    SizedBox(height: canvasPad * 0.5),
                                    Text(
                                      note,
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: tNote,
                                        height: 1.55,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // 木纹相框背景：覆盖在画布内容之上，避免画布遮挡边框
                    IgnorePointer(
                      child: Image.asset(woodBgAsset, fit: BoxFit.cover),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
