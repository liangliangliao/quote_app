package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.Display
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * ScreenGatekeeperService
 *
 * A lightweight foreground service whose only responsibility is to
 * listen for screen-on / display-on events and trigger the same logic
 * that UnlockReceiver would run when the user unlocks the device.
 *
 * This improves reliability of unlock reminders and geo triggers on
 * devices / ROMs that aggressively restrict background broadcast
 * delivery when the app process is not already in memory.
 *
 * NOTE: The service does not show any custom UI. It simply delegates
 * to [UnlockReceiver] so that all business logic (DB queries, geo
 * worker scheduling, cooldown logic, etc.) stays in one place.
 */
class ScreenGatekeeperService : Service() {

    private val channelId = "vision_unlock_guard_service"

    private var screenReceiver: BroadcastReceiver? = null
    private var displayListener: DisplayManager.DisplayListener? = null

    @Volatile
    private var lastDisplayStateOn: Boolean = false

    @Volatile
    private var lastTriggerAt: Long = 0L

    private val MIN_TRIGGER_INTERVAL_MS = 1500L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        registerScreenOnReceiver()
        registerDisplayListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildServiceNotification()
        try {
            startForeground(1338, notification)
        } catch (_: Throwable) {
            // ignore failures to start foreground; service may still run briefly
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Throwable) {
        }
        screenReceiver = null
        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            displayListener?.let { dm.unregisterDisplayListener(it) }
        } catch (_: Throwable) {
        }
        displayListener = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerScreenOnReceiver() {
        val filter = IntentFilter().apply {
            // Listen for both screen-on and explicit user-present / user-unlocked
            // broadcasts. The actual business logic is funneled through
            // [triggerUnlockLogic] which in turn delegates to [UnlockReceiver].
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_USER_UNLOCKED)
        }
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_USER_PRESENT,
                    Intent.ACTION_USER_UNLOCKED -> {
                        // Primary path: user has just unlocked the device.
                        triggerUnlockLogic("user_present_broadcast")
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        // Fallback path: some ROMs may never deliver USER_PRESENT
                        // while still dispatching SCREEN_ON. Coarse rate limiting
                        // inside triggerUnlockLogic() prevents duplicate work.
                        triggerUnlockLogic("screen_on_broadcast")
                    }
                }
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(screenReceiver, filter)
            }
        } catch (_: Throwable) {
            // best effort; ignore registration failures
        }
    }


    private fun registerDisplayListener() {
        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            displayListener = object : DisplayManager.DisplayListener {
                override fun onDisplayChanged(displayId: Int) {
                    val d = dm.getDisplay(displayId) ?: return
                    val isOn = (d.displayId == Display.DEFAULT_DISPLAY && d.state == Display.STATE_ON)
                    if (isOn && !lastDisplayStateOn) {
                        triggerUnlockLogic("display_on")
                    }
                    lastDisplayStateOn = isOn
                }

                override fun onDisplayAdded(displayId: Int) {}
                override fun onDisplayRemoved(displayId: Int) {}
            }
            dm.registerDisplayListener(displayListener, null)
        } catch (_: Throwable) {
            // ignore; service still works partially via SCREEN_ON receiver
        }
    }

    private fun triggerUnlockLogic(reason: String) {
        val now = System.currentTimeMillis()
        // coarse rate limit to avoid duplicate work when both the broadcast
        // and display listener fire around the same time
        if (now - lastTriggerAt < MIN_TRIGGER_INTERVAL_MS) {
            return
        }
        lastTriggerAt = now
        try {
            // Delegate to UnlockReceiver so all unlock/geo business logic
            // stays centralized.
            val receiver = UnlockReceiver()
            val intent = Intent(Intent.ACTION_USER_PRESENT).apply {
                putExtra("from_service", reason)
            }
            receiver.onReceive(this, intent)
        } catch (_: Throwable) {
            // swallow errors; this service must never crash the app process
        }
    }

    private fun buildServiceNotification(): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        val pi = PendingIntent.getActivity(
            this,
            100,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("情景触发守护中")
            .setContentText("用于解锁提醒与地点提醒的后台守护服务。")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(channelId) == null) {
                    val ch = NotificationChannel(
                        channelId,
                        "解锁守护服务",
                        NotificationManager.IMPORTANCE_MIN
                    )
                    ch.setShowBadge(false)
                    nm.createNotificationChannel(ch)
                }
            } catch (_: Throwable) {
                // ignore
            }
        }
    }
}
