import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'notification_service.dart';
import '../data/db.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    await DLog.i('WM', 'dispatch task=$task data=$inputData');
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();

    final job = (inputData?['job'] ?? task).toString();
    if (job == 'wm_fallback' || job == 'wm_run') {
      final uid = (inputData?['task_uid'] ?? '').toString();
      final runKey = (inputData?['run_key'] ?? '').toString();
      if (uid.isNotEmpty && runKey.isNotEmpty) {
        await SchedulerService.wmRunTask(uid, runKey);
      }
    } else if (job == 'due_check_periodic') {
      // 兜底：无精确闹钟时的周期检查
      await SchedulerService.catchupIfMissed();
      await SchedulerService.callback();
      await SchedulerService.scheduleNextForAll();
    } else {
      // 默认：保守补偿
      await SchedulerService.catchupIfMissed();
    }
    return true;
  });
}
