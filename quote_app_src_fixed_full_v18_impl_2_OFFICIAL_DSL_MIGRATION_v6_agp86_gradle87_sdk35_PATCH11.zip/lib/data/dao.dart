
import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart' as tu;

String _uid(String prefix) {
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  return '$prefix-$ts-${r.nextInt(1<<32)}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {
        'api_key': '',
        'model': '',
        'endpoint': '',
        'background_image': null,
      });
      return {'api_key': '', 'model': '', 'endpoint': '', 'background_image': null};
    }
    return rows.first;
  }

  Future<void> save({required String apiKey, String? model, String? endpoint, String? backgroundImage}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    final data = {
      'api_key': apiKey,
      'model': model ?? '',
      'endpoint': endpoint ?? '',
      'background_image': backgroundImage,
    };
    if (rows.isEmpty) {
      await db.insert('configs', data);
    } else {
      await db.update('configs', data, where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }
}

class TaskDao {
  Future<List<Map<String, dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return db.query('tasks', orderBy: 'id DESC');
  }

  Future<String> create({
    required String name,
    required String type, // 'auto' | 'manual' | 'carousel'
    required DateTime startTime,
    required String prompt,
    required String avatarPath,
    required String status, // 'open' | 'closed'
    required String freqType, // 'daily' | 'weekly' | 'monthly' | 'custom'
    int? freqWeekday,
    int? freqDayOfMonth,
    String? freqCustom,
  }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'start_ts': startTime.millisecondsSinceEpoch,
      'next_run_ts': null,
      'prompt': prompt,
      'avatar_path': avatarPath,
      'status': status,
      'freq_type': freqType,
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': freqCustom ?? '',
    });
    return uid;
  }

  Future<void> update(String taskUid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [taskUid]);
  }

  Future<void> delete(String taskUid) async {
    final db = await AppDatabase.instance();
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [taskUid]);
  }
}

class QuoteDao {
  Future<int> count() async {
    final db = await AppDatabase.instance();
    final v = await db.rawQuery('SELECT COUNT(*) as c FROM quotes');
    return Sqflite.firstIntValue(v) ?? 0;
  }

  /// History page: query latest quotes with optional keyword and pagination.
  Future<List<Map<String, dynamic>>> latest({required int limit, required int offset, String? q}) async {
    final db = await AppDatabase.instance();
    final where = (q != null && q.trim().isNotEmpty)
        ? "content LIKE ? OR task_name LIKE ?"
        : null;
    final whereArgs = (q != null && q.trim().isNotEmpty)
        ? ['%$q%', '%$q%']
        : null;
    return db.query(
      'quotes',
      where: where,
      whereArgs: whereArgs,
      orderBy: 'id DESC',
      limit: limit,
      offset: offset,
    );
  }

  Future<String?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes',
        where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return rows.first['content'] as String?;
  }

  /// Carousel: fetch next (oldest un-notified). If none left, reset all to un-notified then fetch oldest.
  Future<Map<String, dynamic>?> nextCarouselForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    var rows = await db.query('quotes',
        where: 'task_uid=? AND notified=0', whereArgs: [taskUid],
        orderBy: 'id ASC', limit: 1);
    if (rows.isEmpty) {
      // reset and try again
      await db.update('quotes', {'notified': 0}, where: 'task_uid=?', whereArgs: [taskUid]);
      rows = await db.query('quotes',
          where: 'task_uid=? AND notified=0', whereArgs: [taskUid],
          orderBy: 'id ASC', limit: 1);
    }
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<void> markNotifiedById(int id) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'id=?', whereArgs: [id]);
  }

  /// We return inserted rowId as string; then markNotifiedByUid interprets as int id.
  Future<void> markNotifiedByUid(String quoteUid) async {
    final id = int.tryParse(quoteUid);
    if (id == null) return;
    await markNotifiedById(id);
  }

  Future<bool> existsSimilar(String content) async {
    final db = await AppDatabase.instance();
    // Fetch some recent quotes to compare
    final rows = await db.query('quotes', orderBy: 'id DESC', limit: 200);
    final normNew = normalizeText(content);
    for (final r in rows) {
      final c = (r['content'] as String?) ?? '';
      if (c.trim().isEmpty) continue;
      final sim = tu.jaroWinkler(normNew, normalizeText(c));
      if (sim >= 0.90) return true;
    }
    // Exact duplicate check as fallback
    final dup = await db.query('quotes', where: 'content=?', whereArgs: [content], limit: 1);
    return dup.isNotEmpty;
  }

  /// Insert quote if not duplicate; return inserted row id as string, or null if duplicate.
  Future<String?> insertIfUnique({
    required String taskUid,
    required String type,
    required String taskName,
    required String avatarPath,
    required String content,
  }) async {
    if (await existsSimilar(content)) return null;
    final db = await AppDatabase.instance();
    final id = await db.insert('quotes', {
      'task_uid': taskUid,
      'content': content,
      'type': type,
      'task_name': taskName,
      'avatar_path': avatarPath,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    return id.toString();
  }

  /// Update the latest quote row for a task (used when editing manual task): only update, do not insert.
  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes',
        where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return false;
    final id = rows.first['id'] as int;
    await db.update('quotes', {
      'content': content,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    }, where: 'id=?', whereArgs: [id]);
    return true;
  }
}

class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }
}

/// Normalize text (fallback if utils missing)
String normalizeText(String s) => (s.replaceAll(RegExp(r'\s+'), ' ').trim().toLowerCase());

/// Very simple similarity: Jaccard over word sets as fallback (unused when tu is present)
double textSimilarity(String a, String b) {
  final as = a.split(RegExp(r'\s+')).toSet();
  final bs = b.split(RegExp(r'\s+')).toSet();
  if (as.isEmpty && bs.isEmpty) return 1.0;
  final inter = as.intersection(bs).length.toDouble();
  final union = as.union(bs).length.toDouble();
  return union == 0 ? 0 : inter / union;
}

/// Compute next run time from now and a base time-of-day etc.
DateTime computeNextRunFrom(DateTime now,
    {required String freqType,
     required DateTime baseTime,
     int? freqWeekday,
     int? freqDayOfMonth}) {
  final hh = baseTime.hour;
  final mm = baseTime.minute;
  if (freqType == 'weekly') {
    final target = (freqWeekday ?? 1).clamp(1, 7);
    int delta = (target - now.weekday);
    if (delta < 0 || (delta == 0 && (now.hour > hh || (now.hour == hh && now.minute >= mm)))) {
      delta += 7;
    }
    final d = now.add(Duration(days: delta));
    return DateTime(d.year, d.month, d.day, hh, mm);
  } else if (freqType == 'monthly') {
    final day = (freqDayOfMonth ?? 1).clamp(1, 31);
    int year = now.year, month = now.month;
    int end = DateTime(year, month + 1, 0).day;
    var candidate = DateTime(year, month, day.clamp(1, end), hh, mm);
    if (!candidate.isAfter(now)) {
      if (month == 12) { month = 1; year += 1; } else { month += 1; }
      end = DateTime(year, month + 1, 0).day;
      candidate = DateTime(year, month, day.clamp(1, end), hh, mm);
    }
    return candidate;
  } else {
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    return today.isAfter(now) ? today : today.add(const Duration(days: 1));
  }
}
