
package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.Log

/**
 * Provides "native.scheduler" method channel to Flutter.
 * Methods:
 *  - canScheduleExact(): bool   -> whether exact alarms are supported/allowed.
 *  - scheduleOnce(msSinceEpoch, requestCode, payload): void  -> optional.
 *  - cancel(requestCode): void
 *
 * We implement canScheduleExact because Flutter checks this at startup.
 * Other methods are no-ops but present to avoid MissingPluginException.
 */
object SchedulerChannel : MethodChannel.MethodCallHandler {
    private const val CHANNEL = "native.scheduler"
    private var channel: MethodChannel? = null

    fun register(flutterEngine: FlutterEngine) {
        if (channel != null) return
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        channel!!.setMethodCallHandler(this)
        Log.i("SchedulerChannel", "registered")
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "canScheduleExact" -> {
                try {
                    val ctx = AppGlobals.appContext ?: throw IllegalStateException("app context null")
                    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val supported =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            am.canScheduleExactAlarms()
                        } else {
                            true
                        }
                    result.success(supported)
                } catch (e: Throwable) {
                    Log.w("SchedulerChannel", "canScheduleExact error", e)
                    result.success(false)
                }
            }
            "scheduleOnce" -> {
                // optional no-op to avoid crashes if called
                result.success(null)
            }
            "cancel" -> {
                result.success(null)
            }
            else -> result.notImplemented()
        }
    }
}

/** Simple holder to access application Context from anywhere. */
object AppGlobals {
    @JvmStatic var appContext: Context? = null
}
