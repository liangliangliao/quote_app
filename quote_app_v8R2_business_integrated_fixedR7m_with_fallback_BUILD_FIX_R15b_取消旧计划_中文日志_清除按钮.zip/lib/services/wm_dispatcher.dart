import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/debug_logger.dart';
import 'notification_service.dart';
import 'scheduler_service.dart';
import '../background_tasks.dart';
import '../utils/run_context.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      ui.DartPluginRegistrant.ensureInitialized();
      await NotificationService.init();
      // 标记：来自 WorkManager 的后台回调
      RunContext.isBackground = true;
      RunContext.isFromWM = true;

      if (task == 'bg_selfcheck') {
        await DLog.i('WM', "调度任务=bg_selfcheck data="+(inputData??{}).toString());
        await SchedulerService.catchupIfMissed();
        await SchedulerService.callback();
        await SchedulerService.scheduleNextForAll();
        await BackgroundTasks.registerSelfCheck();
        return Future.value(true);
      }

      if (task == 'due_check_periodic') {
        await DLog.i('WM', "调度任务=due_check_periodic");
        await SchedulerService.catchupIfMissed();
        await SchedulerService.scheduleNextForAll();
        return Future.value(true);
      }

      if (task == 'wm_run' || task == 'wm_fallback') {
        final uid = (inputData?['task_uid'] ?? '').toString();
        final runKey = (inputData?['run_key'] ?? '').toString();
        await DLog.i('WM', "调度任务="+task+" uid="+uid+" run="+runKey);
        await SchedulerService.wmRunTask(uid, runKey);
        return Future.value(true);
      }

      await DLog.i('WM', "调度任务=? "+task.toString());
      return Future.value(false);
    } catch (e) {
      await DLog.e('WM', 'callback error: '+e.toString());
      return Future.value(false);
    }
  });
}
