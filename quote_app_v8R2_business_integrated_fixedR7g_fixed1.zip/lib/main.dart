import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:workmanager/workmanager.dart';

import 'data/db.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'services/wm_dispatcher.dart';
import 'services/background_tasks.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';
import 'utils/debug_logger.dart';
import 'platform/perm_helper.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();

  await AppDatabase.instance();
  await NotificationService.init();
  await AndroidAlarmManager.initialize();
  await Workmanager().initialize(workmanagerCallbackDispatcher, isInDebugMode: true);

  await DLog.i('SCH', 'init start (from main)');
  await SchedulerService.init();
  await SchedulerService.scheduleNextForAll();
  await BackgroundTasks.registerSelfCheck();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const AppGate(),
    );
  }
}

class AppGate extends StatefulWidget {
  const AppGate({super.key});
  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    // 1) 通知权限：必须允许，否则退出
    final enabled = await NotificationService.isEnabled();
    if (!enabled && mounted) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('需要通知权限'),
          content: const Text('请允许通知权限，否则无法使用提醒功能。'),
          actions: [
            TextButton(
              onPressed: () { Navigator.of(ctx).pop(false); },
              child: const Text('不允许'),
            ),
            TextButton(
              onPressed: () async {
                await NotificationService.request();
                if (ctx.mounted) Navigator.of(ctx).pop(true);
              },
              child: const Text('允许'),
            ),
          ],
        ),
      );
      final after = await NotificationService.isEnabled();
      if (ok != true || !after) {
        await DLog.i('PERM', 'notification denied -> exit');
        SystemNavigator.pop();
        return;
      }
    }
    // 2) 精确闹钟：可选，自定义弹窗；不跳系统设置
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact && mounted) {
      await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('闹钟提醒授权'),
          content: const Text('建议允许“精确闹钟”以尽量准点提醒。该授权可稍后在系统设置中手动开启。'),
          actions: [
            TextButton(
              onPressed: () { Navigator.of(ctx).pop(false); },
              child: const Text('不允许'),
            ),
            TextButton(
              onPressed: () async {
                // 仅记录选择，不跳系统页面
                if (ctx.mounted) Navigator.of(ctx).pop(true);
              },
              child: const Text('允许'),
            ),
          ],
        ),
      );
      // 不做任何系统层更改，WM 兜底会确保不漏发
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const _Shell()));
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}

class _Shell extends StatefulWidget {
  const _Shell({super.key});
  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) => setState(() => _idx = i),
      ),
    );
  }
}
