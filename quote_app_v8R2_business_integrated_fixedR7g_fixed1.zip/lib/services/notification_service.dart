import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  /// Initialize plugin and ensure notification channels exist (Android).
  static Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: androidInit));

    final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl != null) {
      // Default channel (used by show/showSimple)
      const defaultChannel = AndroidNotificationChannel(
        'default',
        '默认通知',
        description: '默认通知渠道',
        importance: Importance.defaultImportance,
        playSound: true,
      );
      await androidImpl.createNotificationChannel(defaultChannel);

      // High-importance channel for scheduled reminders
      const highChannel = AndroidNotificationChannel(
        'quote_high',
        '定时提醒',
        description: 'Quote 定时提醒',
        importance: Importance.high,
        playSound: true,
      );
      await androidImpl.createNotificationChannel(highChannel);
    }
  }

  static Future<bool> isEnabled() async {
    final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl == null) return true;
    return await androidImpl.areNotificationsEnabled() ?? true;
  }

  static Future<void> request() async {
    final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl != null) {
      await androidImpl.requestNotificationsPermission();
    }
  }

  static Future<void> showSimple(String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'default',
        '默认通知',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
      ),
    );
    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    await _plugin.show(id, title, body, details);
  }

  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    final androidDetails = AndroidNotificationDetails(
      'default',
      '默认通知',
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails);
    final nid = id ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000);
    final t = title ?? '提醒';
    final b = body ?? '';
    await _plugin.show(nid, t, b, details);
  }
}
