using DistanceNoble.Save;
using UnityEngine;
using UnityEngine.UI;

namespace DistanceNoble.UI
{
    public class MainCityHUD : MonoBehaviour
    {
        public Text GoldText;
        public Text HonorText;
        public Text DistanceText;
        public Text ReverenceText;

        private void Start()
        {
            Refresh();
        }

        public void Refresh()
        {
            if (GoldText != null) GoldText.text = $"金币：{SaveService.Current.Resources.Gold}";
            if (HonorText != null) HonorText.text = $"荣誉：{SaveService.Current.Civilization.Honor}";
            if (DistanceText != null) DistanceText.text = $"距离：{SaveService.Current.Civilization.Distance}";
            if (ReverenceText != null) ReverenceText.text = $"敬意：{SaveService.Current.Civilization.Reverence}";
        }
    }
}
