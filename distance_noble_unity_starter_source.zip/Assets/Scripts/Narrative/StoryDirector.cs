using DistanceNoble.Meta;
using UnityEngine;

namespace DistanceNoble.Narrative
{
    public class StoryDirector : MonoBehaviour
    {
        public void ChooseHonorOption()
        {
            CityStateManager.ChangeCivilization(honor: 4, distance: 2);
            Debug.Log("你选择了：强调誓约与责任");
        }

        public void ChooseEqualityOption()
        {
            CityStateManager.ChangeCivilization(equality: 4, obedience: 1);
            Debug.Log("你选择了：强调人人发声");
        }
    }
}
