using System.Collections.Generic;

namespace DistanceNoble.Config
{
    public static class ConfigService
    {
        private static readonly Dictionary<string, CharacterConfig> CharacterConfigs = new();

        public static void Initialize()
        {
            CharacterConfigs.Clear();

            CharacterConfigs["arion"] = new CharacterConfig
            {
                Id = "arion",
                Name = "阿列翁·维尔卡",
                Faction = "高贵",
                Role = "统帅",
                Rarity = 4,
                PortraitAddress = "Characters/Arion/portrait",
                ModelAddress = "Characters/Arion/model",
                BaseStats = new BaseStatData { HP = 1200, Attack = 120, Defense = 60, MoveSpeed = 4.5f },
                SkillIds = new[] { "arion_skill_1", "arion_skill_2", "arion_skill_3" }
            };

            CharacterConfigs["mira"] = new CharacterConfig
            {
                Id = "mira",
                Name = "米拉·镜厅",
                Faction = "镜厅",
                Role = "演说家",
                Rarity = 3,
                PortraitAddress = "Characters/Mira/portrait",
                ModelAddress = "Characters/Mira/model",
                BaseStats = new BaseStatData { HP = 900, Attack = 105, Defense = 40, MoveSpeed = 4.8f },
                SkillIds = new[] { "mira_skill_1", "mira_skill_2", "mira_skill_3" }
            };

            CharacterConfigs["safer"] = new CharacterConfig
            {
                Id = "safer",
                Name = "赛弗·灰衣",
                Faction = "怨恨",
                Role = "传教者",
                Rarity = 4,
                PortraitAddress = "Characters/Safer/portrait",
                ModelAddress = "Characters/Safer/model",
                BaseStats = new BaseStatData { HP = 1000, Attack = 112, Defense = 50, MoveSpeed = 4.6f },
                SkillIds = new[] { "safer_skill_1", "safer_skill_2", "safer_skill_3" }
            };
        }

        public static CharacterConfig GetCharacter(string id)
        {
            return CharacterConfigs.TryGetValue(id, out var config) ? config : null;
        }
    }
}
