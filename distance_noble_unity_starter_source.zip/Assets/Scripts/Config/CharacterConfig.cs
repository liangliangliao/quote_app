using System;

namespace DistanceNoble.Config
{
    [Serializable]
    public class CharacterConfig
    {
        public string Id;
        public string Name;
        public string Faction;
        public string Role;
        public int Rarity;
        public string PortraitAddress;
        public string ModelAddress;
        public BaseStatData BaseStats;
        public string[] SkillIds;
    }

    [Serializable]
    public class BaseStatData
    {
        public int HP;
        public int Attack;
        public int Defense;
        public float MoveSpeed;
    }
}
