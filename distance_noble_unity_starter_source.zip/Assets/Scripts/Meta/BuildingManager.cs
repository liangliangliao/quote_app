using DistanceNoble.Save;
using UnityEngine;

namespace DistanceNoble.Meta
{
    public static class BuildingManager
    {
        public static int GetBuildingLevel(string buildingId)
        {
            var data = SaveService.Current.GetBuilding(buildingId);
            return data != null ? data.Level : 0;
        }

        public static bool UpgradeBuilding(string buildingId)
        {
            var building = SaveService.Current.GetBuilding(buildingId);
            if (building == null)
            {
                building = new BuildingRuntimeData { Id = buildingId, Level = 0 };
                SaveService.Current.Buildings.Add(building);
            }

            int nextLevel = building.Level + 1;
            int cost = 300 + building.Level * 200;

            if (SaveService.Current.Resources.Gold < cost)
            {
                Debug.Log("金币不足，无法升级建筑");
                return false;
            }

            SaveService.Current.Resources.Gold -= cost;
            building.Level = nextLevel;
            ApplyBuildingEffect(buildingId, nextLevel);
            SaveService.Save();
            return true;
        }

        private static void ApplyBuildingEffect(string buildingId, int level)
        {
            switch (buildingId)
            {
                case "council":
                    CityStateManager.ChangeCivilization(distance: 1, honor: 1);
                    break;
                case "mirrorHall":
                    CityStateManager.ChangeCivilization(vanity: 3);
                    break;
                case "quietRoom":
                    CityStateManager.ChangeCivilization(reverence: 3, vanity: -1);
                    break;
            }
        }
    }
}
