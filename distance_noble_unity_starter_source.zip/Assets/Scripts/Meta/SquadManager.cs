using System.Collections.Generic;
using DistanceNoble.Save;

namespace DistanceNoble.Meta
{
    public static class SquadManager
    {
        public static List<string> GetCurrentSquad()
        {
            return SaveService.Current.SquadCharacterIds;
        }

        public static void SetMember(int index, string characterId)
        {
            if (index < 0) return;

            while (SaveService.Current.SquadCharacterIds.Count <= index)
            {
                SaveService.Current.SquadCharacterIds.Add(string.Empty);
            }

            SaveService.Current.SquadCharacterIds[index] = characterId;
            SaveService.Save();
        }
    }
}
