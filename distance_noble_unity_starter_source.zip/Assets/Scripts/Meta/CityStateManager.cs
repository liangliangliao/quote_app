using DistanceNoble.Save;

namespace DistanceNoble.Meta
{
    public static class CityStateManager
    {
        public static ResourceData Resources => SaveService.Current.Resources;
        public static CivilizationData Civilization => SaveService.Current.Civilization;

        public static void AddGold(int amount)
        {
            Resources.Gold += amount;
            SaveService.Save();
        }

        public static void ChangeCivilization(
            int distance = 0,
            int honor = 0,
            int resentment = 0,
            int vanity = 0,
            int equality = 0,
            int creativity = 0,
            int obedience = 0,
            int reverence = 0)
        {
            Civilization.Distance += distance;
            Civilization.Honor += honor;
            Civilization.Resentment += resentment;
            Civilization.Vanity += vanity;
            Civilization.Equality += equality;
            Civilization.Creativity += creativity;
            Civilization.Obedience += obedience;
            Civilization.Reverence += reverence;

            SaveService.Save();
        }
    }
}
