using UnityEngine;

namespace DistanceNoble.Core
{
    public class GameBootstrap : MonoBehaviour
    {
        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            Debug.Log("GameBootstrap 初始化开始");
            Save.SaveService.Initialize();
            Config.ConfigService.Initialize();
            Debug.Log("GameBootstrap 初始化完成");
        }

        private void Start()
        {
            SceneRouter.LoadMainCity();
        }
    }
}
