using UnityEngine.SceneManagement;

namespace DistanceNoble.Core
{
    public static class SceneRouter
    {
        public const string BootScene = "Boot";
        public const string MainCityScene = "MainCity";
        public const string BattleScene = "Battle_TestArena";
        public const string StoryScene = "Story_Cutscene_01";

        public static void LoadMainCity()
        {
            SceneManager.LoadScene(MainCityScene);
        }

        public static void LoadBattle()
        {
            SceneManager.LoadScene(BattleScene);
        }

        public static void LoadStory()
        {
            SceneManager.LoadScene(StoryScene);
        }
    }
}
