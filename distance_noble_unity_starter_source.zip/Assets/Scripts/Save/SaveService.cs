using System.IO;
using UnityEngine;

namespace DistanceNoble.Save
{
    public static class SaveService
    {
        private static readonly string SavePath = Path.Combine(Application.persistentDataPath, "save.json");

        public static SaveData Current { get; private set; }

        public static void Initialize()
        {
            if (File.Exists(SavePath))
            {
                string json = File.ReadAllText(SavePath);
                Current = JsonUtility.FromJson<SaveData>(json);
            }
            else
            {
                Current = CreateDefaultSave();
                Save();
            }
        }

        public static void Save()
        {
            string json = JsonUtility.ToJson(Current, true);
            File.WriteAllText(SavePath, json);
            Debug.Log($"存档已保存到: {SavePath}");
        }

        public static void Reset()
        {
            Current = CreateDefaultSave();
            Save();
        }

        private static SaveData CreateDefaultSave()
        {
            var data = new SaveData();

            data.SquadCharacterIds.Add("arion");
            data.SquadCharacterIds.Add("mira");
            data.SquadCharacterIds.Add("safer");

            data.Characters.Add(new CharacterRuntimeData { Id = "arion", Level = 12, Exp = 0, Power = 640, Unlocked = true });
            data.Characters.Add(new CharacterRuntimeData { Id = "mira", Level = 10, Exp = 0, Power = 510, Unlocked = true });
            data.Characters.Add(new CharacterRuntimeData { Id = "safer", Level = 11, Exp = 0, Power = 560, Unlocked = true });

            data.Buildings.Add(new BuildingRuntimeData { Id = "council", Level = 1 });
            data.Buildings.Add(new BuildingRuntimeData { Id = "market", Level = 1 });

            data.Missions.Add(new MissionRuntimeData
            {
                Id = "chapter_1_main",
                Progress = 0,
                Completed = false,
                RewardClaimed = false
            });

            return data;
        }
    }
}
