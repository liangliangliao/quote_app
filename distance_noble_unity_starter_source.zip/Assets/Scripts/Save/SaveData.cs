using System;
using System.Collections.Generic;

namespace DistanceNoble.Save
{
    [Serializable]
    public class SaveData
    {
        public ResourceData Resources = new();
        public CivilizationData Civilization = new();
        public List<string> SquadCharacterIds = new();
        public List<CharacterRuntimeData> Characters = new();
        public List<BuildingRuntimeData> Buildings = new();
        public List<MissionRuntimeData> Missions = new();

        public CharacterRuntimeData GetCharacter(string id) => Characters.Find(c => c.Id == id);
        public BuildingRuntimeData GetBuilding(string id) => Buildings.Find(b => b.Id == id);
        public MissionRuntimeData GetMission(string id) => Missions.Find(m => m.Id == id);
    }

    [Serializable]
    public class ResourceData
    {
        public int Gold = 5000;
        public int Wood = 800;
        public int Stone = 600;
        public int Iron = 400;
        public int Mirror = 120;
        public int Honor = 80;
        public int PublicWill = 90;
    }

    [Serializable]
    public class CivilizationData
    {
        public int Distance = 40;
        public int Honor = 50;
        public int Resentment = 25;
        public int Vanity = 30;
        public int Equality = 35;
        public int Creativity = 35;
        public int Obedience = 40;
        public int Reverence = 28;
    }

    [Serializable]
    public class CharacterRuntimeData
    {
        public string Id;
        public int Level;
        public int Exp;
        public int Power;
        public bool Unlocked;
    }

    [Serializable]
    public class BuildingRuntimeData
    {
        public string Id;
        public int Level;
    }

    [Serializable]
    public class MissionRuntimeData
    {
        public string Id;
        public int Progress;
        public bool Completed;
        public bool RewardClaimed;
    }
}
