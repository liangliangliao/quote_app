using UnityEngine;

namespace DistanceNoble.Battle
{
    [RequireComponent(typeof(BattleUnit))]
    public class EnemyAIController : MonoBehaviour
    {
        public Transform Target;
        private BattleUnit _unit;

        private void Awake()
        {
            _unit = GetComponent<BattleUnit>();
        }

        private void Update()
        {
            if (Target == null || _unit.IsDead) return;

            Vector3 direction = Target.position - transform.position;
            direction.y = 0;

            if (direction.magnitude > 1.8f)
            {
                transform.position += direction.normalized * (_unit.MoveSpeed * Time.deltaTime);
                transform.forward = direction.normalized;
            }
        }
    }
}
