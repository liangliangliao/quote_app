using UnityEngine;

namespace DistanceNoble.Battle
{
    [RequireComponent(typeof(CharacterController))]
    [RequireComponent(typeof(BattleUnit))]
    public class PlayerController : MonoBehaviour
    {
        private CharacterController _controller;
        private BattleUnit _unit;

        private void Awake()
        {
            _controller = GetComponent<CharacterController>();
            _unit = GetComponent<BattleUnit>();
        }

        private void Update()
        {
            Vector3 input = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));

            if (input.sqrMagnitude > 0.01f)
            {
                _controller.Move(input.normalized * (_unit.MoveSpeed * Time.deltaTime));
                transform.forward = input.normalized;
            }
        }
    }
}
