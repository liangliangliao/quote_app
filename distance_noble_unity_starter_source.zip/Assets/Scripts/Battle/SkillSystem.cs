using UnityEngine;

namespace DistanceNoble.Battle
{
    public class SkillSystem : MonoBehaviour
    {
        public BattleUnit Owner;

        public void CastSkill1(BattleUnit target)
        {
            if (Owner == null || target == null || target.IsDead) return;
            int damage = Mathf.RoundToInt(Owner.Attack * 1.2f);
            target.TakeDamage(damage);
            Debug.Log($"{Owner.UnitId} 释放技能1，对 {target.UnitId} 造成 {damage} 伤害");
        }

        public void CastSkill2(BattleUnit target)
        {
            if (Owner == null || target == null || target.IsDead) return;
            int damage = Mathf.RoundToInt(Owner.Attack * 1.6f);
            target.TakeDamage(damage);
            Debug.Log($"{Owner.UnitId} 释放技能2，对 {target.UnitId} 造成 {damage} 伤害");
        }

        public void CastSkill3(BattleUnit target)
        {
            if (Owner == null || target == null || target.IsDead) return;
            int damage = Mathf.RoundToInt(Owner.Attack * 2.0f);
            target.TakeDamage(damage);
            Debug.Log($"{Owner.UnitId} 释放技能3，对 {target.UnitId} 造成 {damage} 伤害");
        }
    }
}
