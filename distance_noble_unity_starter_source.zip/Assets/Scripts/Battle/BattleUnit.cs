using UnityEngine;

namespace DistanceNoble.Battle
{
    public class BattleUnit : MonoBehaviour
    {
        public string UnitId;
        public bool IsPlayerSide;
        public int MaxHP;
        public int CurrentHP;
        public int Attack;
        public float MoveSpeed = 4f;

        public bool IsDead => CurrentHP <= 0;

        public void Initialize(string unitId, int hp, int attack, bool isPlayerSide)
        {
            UnitId = unitId;
            MaxHP = hp;
            CurrentHP = hp;
            Attack = attack;
            IsPlayerSide = isPlayerSide;
        }

        public void TakeDamage(int damage)
        {
            CurrentHP -= damage;
            if (CurrentHP < 0) CurrentHP = 0;
        }
    }
}
