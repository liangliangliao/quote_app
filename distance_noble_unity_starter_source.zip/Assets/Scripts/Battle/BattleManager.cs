using System.Collections.Generic;
using DistanceNoble.Meta;
using DistanceNoble.Save;
using UnityEngine;

namespace DistanceNoble.Battle
{
    public class BattleManager : MonoBehaviour
    {
        public List<BattleUnit> PlayerUnits = new();
        public List<BattleUnit> EnemyUnits = new();
        public bool BattleEnded { get; private set; }

        private void Update()
        {
            if (BattleEnded) return;

            bool allEnemiesDead = EnemyUnits.TrueForAll(x => x == null || x.IsDead);
            bool allPlayersDead = PlayerUnits.TrueForAll(x => x == null || x.IsDead);

            if (allEnemiesDead) OnBattleWin();
            else if (allPlayersDead) OnBattleLose();
        }

        private void OnBattleWin()
        {
            BattleEnded = true;
            CityStateManager.AddGold(800);
            CityStateManager.ChangeCivilization(honor: 2, distance: 1);

            var mission = SaveService.Current.GetMission("chapter_1_main");
            if (mission != null)
            {
                mission.Progress = 2;
                mission.Completed = true;
            }

            SaveService.Save();
            Debug.Log("战斗胜利");
        }

        private void OnBattleLose()
        {
            BattleEnded = true;
            Debug.Log("战斗失败");
        }
    }
}
