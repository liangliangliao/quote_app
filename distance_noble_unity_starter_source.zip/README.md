# 距离：高贵者 - Unity 起步源码包

这是一个 Unity 正式开发起步源码包，不是完整成品。

## 包含内容
- Unity 项目基础目录
- 首批 C# 脚本骨架
- 主城 / 编队 / 战斗 / 剧情 / 存档 的最小闭环代码结构
- 可作为正式 Unity 项目的起点

## 建议 Unity 版本
- Unity 2022.3 LTS

## 当前脚本模块
- Core
- Save
- Config
- Meta
- Battle
- Narrative
- UI

## 你接下来需要在 Unity 里做的事
1. 用 Unity Hub 打开本项目目录
2. 创建并加入这些场景到 Build Settings
   - Boot
   - MainCity
   - Battle_TestArena
   - Story_Cutscene_01
3. 在 Boot 场景挂载 GameBootstrap
4. 在 MainCity 场景挂载 MainCityHUD 并绑定 UI Text
5. 在 Battle_TestArena 放置玩家和敌人预制体，并挂载：
   - BattleUnit
   - PlayerController
   - EnemyAIController
   - SkillSystem
   - BattleManager

## 说明
这份源码包是“正式开发起步骨架”，重点是让项目真正进入 Unity 工程阶段。
它还不包含：
- 完整场景资源
- 3D 模型
- 动画
- UI 美术
- 完整任务链
- 完整剧情
- 商业化接入

## 推荐下一步
- 建立场景
- 接入角色 3D 模型占位
- 跑通第一章垂直切片
