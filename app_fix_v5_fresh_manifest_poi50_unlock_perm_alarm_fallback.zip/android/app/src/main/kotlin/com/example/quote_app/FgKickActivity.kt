package com.example.quote_app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import com.example.quote_app.data.DbRepo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * 透明 Activity：
 * - 由 UnlockReceiver 在解锁瞬间启动；
 * - 在一个后台线程中统一调度“地点规则提醒 + 解锁轻提醒”；
 * - 无论过程中是否出现异常，都会在 finally 中销毁 Activity，避免影响性能与电量。
 */
class FgKickActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val appCtx = applicationContext

        thread(name = "unlock-fg-activity") {
            try {
                logWithTime(appCtx, "【解锁前台Activity】已启动，准备执行地点规则提醒与解锁轻提醒逻辑")

                // 1）地点规则提醒：沿用现有 GeoForegroundService 的实现逻辑
                try {
                    val svc = Intent(appCtx, GeoForegroundService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) {
                        appCtx.startForegroundService(svc)
                    } else {
                        appCtx.startService(svc)
                    }
                    logWithTime(appCtx, "【解锁前台Activity】已请求启动 GeoForegroundService（地点规则提醒）")
                } catch (t: Throwable) {
                    logWithTime(appCtx, "【解锁前台Activity】启动 GeoForegroundService 异常：" + (t.message ?: "unknown"))
                }

                // 2）解锁轻提醒：沿用现有 UnlockWorker.trigger 的逻辑
                try {
                    logWithTime(appCtx, "【解锁前台Activity】准备触发解锁轻提醒（UnlockWorker.trigger）")
                    UnlockWorker.trigger(appCtx)
                    logWithTime(appCtx, "【解锁前台Activity】已触发解锁轻提醒（UnlockWorker.trigger 调用完成）")
                } catch (t: Throwable) {
                    logWithTime(appCtx, "【解锁前台Activity】触发解锁轻提醒异常：" + (t.message ?: "unknown"))
                }
            } finally {
                // 无论成功失败，最终都要销毁透明 Activity，避免泄露
                try {
                    logWithTime(appCtx, "【解锁前台Activity】所有解锁相关逻辑已调度完成，准备销毁透明 Activity（finally 保证执行）")
                } catch (_: Throwable) {
                }

                runOnUiThread {
                    try {
                        finish()
                    } catch (_: Throwable) {
                    }
                }
            }
        }
    }

    companion object {
        private fun logWithTime(ctx: Context, msg: String) {
            try {
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
                val now = fmt.format(Date())
                DbRepo.log(ctx, null, "[$now] $msg")
            } catch (_: Throwable) {
            }
        }
    }
}
