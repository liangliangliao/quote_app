import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:quote_app/widgets/wood_frame_card.dart';

class _NoIndicatorScroll extends ScrollBehavior {
  @override
  Widget buildViewportChrome(BuildContext context, Widget child, AxisDirection axisDirection) => child;

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const ClampingScrollPhysics();
}

class OctagonClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final w = size.width, h = size.height;
    final c = 0.18;
    return Path()
      ..moveTo(c * w, 0)
      ..lineTo(w - c * w, 0)
      ..lineTo(w, c * h)
      ..lineTo(w, h - c * h)
      ..lineTo(w - c * w, h)
      ..lineTo(c * w, h)
      ..lineTo(0, h - c * h)
      ..lineTo(0, c * h)
      ..close();
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

ImageProvider _imageFrom(String? any, {String? fallbackAsset}) {
  if (any == null || any.isEmpty) return AssetImage(fallbackAsset ?? 'assets/bg-wood-upload.jpg');
  if (any.startsWith('data:')) {
    final b64 = any.substring(any.indexOf(',') + 1);
    return MemoryImage(base64.decode(b64));
  }
  if (any.startsWith('http')) return NetworkImage(any);
  if (any.startsWith('assets/')) return AssetImage(any);
  return AssetImage(fallbackAsset ?? 'assets/bg-wood-upload.jpg');
}

class PosterPureFlutter extends StatelessWidget {
  final String topic;
  final String quote;
  final String author;
  final String note;
  final String avatar;
  final String woodBgAsset;

  const PosterPureFlutter({
    super.key,
    required this.topic,
    required this.quote,
    required this.author,
    required this.note,
    required this.avatar,
    this.woodBgAsset = 'assets/bg-wood-upload.jpg',
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final short = (cons.maxWidth < cons.maxHeight) ? cons.maxWidth : cons.maxHeight;
      final shortAdjusted = (short - 30.0).clamp(0.0, short);
      final tTitle = (shortAdjusted * 0.040).clamp(18.5, 24.0);
      final tQuote = (shortAdjusted * 0.065).clamp(19.0, 31.0);
      final tAuth = (shortAdjusted * 0.033).clamp(13.0, 16.0);
      final tNote = (shortAdjusted * 0.030).clamp(10.5, 12.4);
      final frameTop = (shortAdjusted * 0.035).clamp(14.0, 24.0);
      final frameBottom = (shortAdjusted * 0.035).clamp(14.0, 24.0);
      final canvasPad = (shortAdjusted * 0.130).clamp(44.0, 70.0);
      final framePaddingH = (shortAdjusted * 0.115).clamp(64.0, 88.0) - 15.0 - 15.0;
      final framePaddingV = (shortAdjusted * 0.160).clamp(92.0, 124.0) - 15.0 - 15.0;
      final avatarSize = (shortAdjusted * 0.212).clamp(88.0, 140.0);
      const frameRadius = 12.0;
      const canvasRadius = 6.0;

      return Container(
        color: Colors.transparent,
        alignment: Alignment.center,
        padding: EdgeInsets.only(top: (short * 0.10).clamp(30.0, 60.0)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: AspectRatio(
            aspectRatio: 1024 / 1536, // match bg-wood-upload.jpg
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(frameRadius),
                // boxShadow removed per design: frame alone without outer card shadow
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(frameRadius),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // 木纹相框背景（底层）
                    Image.asset(woodBgAsset, fit: BoxFit.cover),
                    // 相框内部边距：左右 40dp，上下 50dp
                    Padding(
                      padding: const EdgeInsets.fromLTRB(17.0, 30.0, 17.0, 25.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(canvasRadius),
                        clipBehavior: Clip.hardEdge, // 确保内部滚动不越界
                        child: Container(
                          color: Colors.transparent,
                          child: Padding(
                            padding: EdgeInsets.all(canvasPad),
                            child: ScrollConfiguration(
                              behavior: _NoIndicatorScroll(),
                              child: SingleChildScrollView(
                                physics: const ClampingScrollPhysics(),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 20),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Text(
                                            topic,
                                            style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: tTitle,
                                              letterSpacing: 0.3,
                                              height: 1.30,
                                              fontWeight: FontWeight.w300,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 16),
                                        ClipOval(
                                          child: Container(
                                            margin: const EdgeInsets.only(top: -2),
                                            width: avatarSize,
                                            height: avatarSize,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              border: Border.all(color: Colors.transparent, width: 0),
                                              image: DecorationImage(
                                                image: _imageFrom(avatar, fallbackAsset: woodBgAsset),
                                                fit: BoxFit.contain,
                                                alignment: Alignment.center,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: canvasPad * 0.3),
                                    Text(
                                      quote,
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: tQuote - 1,
                                        height: 1.45,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 2.0,
                                      ),
                                    ),
                                    SizedBox(height: canvasPad * 0.1),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        author,
                                        textAlign: TextAlign.right,
                                        style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: tAuth,
                                          height: 1.35,
                                          fontStyle: FontStyle.italic,
                                          fontWeight: FontWeight.w700,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: canvasPad * 0.5),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        note,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Colors.black87,
                                          fontSize: tNote - 1,
                                          height: 1.40,
                                          fontWeight: FontWeight.w300,
                                          letterSpacing: 0.2,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
