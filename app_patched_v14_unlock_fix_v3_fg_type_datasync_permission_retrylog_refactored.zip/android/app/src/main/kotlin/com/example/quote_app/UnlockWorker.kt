package com.example.quote_app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * UnlockWorker runs the unlock reminder business logic on a background thread.
 *
 * It is scheduled by [UnlockReceiver] whenever the system reports a screen
 * unlock / screen-on style broadcast. Running this work inside WorkManager
 * avoids doing heavy I/O in the broadcast receiver and removes the need
 * for a foreground "keep alive" service.
 */
class UnlockWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {

    override fun doWork(): Result {
        val ctx = applicationContext

        // 1) 记录入口日志，方便排查
        try {
            DbRepo.log(
                ctx,
                null,
                "[UnlockWorker] doWork: start handling unlock event"
            )
        } catch (_: Throwable) {
        }

        // 2) 每次解锁排一次 GeoWorker，用于地理相关情景触发
        try {
            val request = OneTimeWorkRequestBuilder<GeoWorker>().build()
            WorkManager.getInstance(ctx).enqueue(request)
        } catch (_: Throwable) {
            // ignore scheduling errors
        }

        // 3) 打开数据库，检查解锁提醒开关 / 触发器 / 冷却时间配置
        val contract = DbInspector.loadOrLightScan(ctx)
        if (contract == null || contract.dbPath == null) {
            // 无法读取配置时直接跳过，不中断整个 Worker
            try {
                DbRepo.log(
                    ctx,
                    null,
                    "【解锁提醒】UnlockWorker：DbInspector 返回空配置，跳过本次解锁提醒业务逻辑"
                )
            } catch (_: Throwable) {
            }
            return Result.success()
        }

        var db: SQLiteDatabase? = null
        var hasTrigger = false
        var configEnabled = false
        var cooldownMs = 30L * 60L * 1000L // 默认 30 分钟

        try {
            db = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)

            // 是否配置了解锁触发器
            try {
                val cursor = db.rawQuery(
                    "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                    null
                )
                hasTrigger = cursor.moveToFirst()
                cursor.close()
            } catch (_: Throwable) {
            }

            // 开关：unlock_switch_enabled
            try {
                val c = db.rawQuery(
                    "SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1",
                    null
                )
                if (c.moveToFirst()) {
                    val v = c.getString(0)
                    if (v != null) {
                        val s = v.trim().lowercase()
                        configEnabled = (s == "1" || s == "true")
                    }
                }
                c.close()
            } catch (_: Throwable) {
                // ignore DB errors
            }

            try {
                DbRepo.log(
                    ctx,
                    null,
                    "【解锁提醒】UnlockWorker：配置检查完成，hasTrigger=" + hasTrigger +
                        "，configEnabled=" + configEnabled +
                        "（是否存在解锁触发器 / 解锁提醒开关是否开启）"
                )
            } catch (_: Throwable) {
            }

            // 如果总开关关闭，则本次解锁直接跳过
            if (!configEnabled) {
                try {
                    DbRepo.log(
                        ctx,
                        null,
                        "【解锁提醒】UnlockWorker：解锁轻提醒开关已关闭，本次解锁不发送任何通知"
                    )
                } catch (_: Throwable) {
                }
                return Result.success()
            }

            // 冷却时间：优先读取 unlock_cooldown_days，其次 unlock_cooldown_minutes
            try {
                // 天级冷却
                try {
                    val cDay = db.rawQuery(
                        "SELECT value FROM notify_config WHERE key='unlock_cooldown_days' LIMIT 1",
                        null
                    )
                    if (cDay.moveToFirst()) {
                        val v = cDay.getString(0)
                        try {
                            val d = v?.toDouble()
                            if (d != null && d > 0.0) {
                                cooldownMs = (d * 24.0 * 60.0 * 60.0 * 1000.0).toLong()
                            }
                        } catch (_: Throwable) {
                        }
                    }
                    cDay.close()
                } catch (_: Throwable) {
                }

                // 分钟级冷却（仅当天级配置未覆盖时）
                if (cooldownMs == 30L * 60L * 1000L) {
                    try {
                        val cMin = db.rawQuery(
                            "SELECT value FROM notify_config WHERE key='unlock_cooldown_minutes' LIMIT 1",
                            null
                        )
                        if (cMin.moveToFirst()) {
                            val v2 = cMin.getString(0)
                            try {
                                val m = v2?.toInt()
                                if (m != null && m > 0) {
                                    cooldownMs = m.toLong() * 60L * 1000L
                                }
                            } catch (_: Throwable) {
                            }
                        }
                        cMin.close()
                    } catch (_: Throwable) {
                    }
                }
            } catch (_: Throwable) {
            }
        } catch (_: Throwable) {
            // 打开数据库失败，直接结束本次任务
            try {
                DbRepo.log(
                    ctx,
                    null,
                    "【解锁提醒】UnlockWorker：打开数据库失败，本次解锁提醒被跳过"
                )
            } catch (_: Throwable) {
            }
            return Result.success()
        } finally {
            try {
                db?.close()
            } catch (_: Throwable) {
            }
        }

        // 4) 根据冷却时间判断是否需要发送解锁提醒
        var inCooldown = false
        try {
            val prefs = ctx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val last = prefs.getLong("last_unlock_reminder_time", 0L)
            if (last > 0L && (now - last) < cooldownMs) {
                inCooldown = true
            }
        } catch (_: Throwable) {
        }

        if (inCooldown) {
            try {
                DbRepo.log(
                    ctx,
                    null,
                    "【解锁提醒】UnlockWorker：仍处于解锁提醒冷却期，跳过本次解锁通知，cooldownMs=" + cooldownMs
                )
            } catch (_: Throwable) {
            }
            return Result.success()
        }

        // 5) 满足条件时记录本次解锁时间并发送提醒
        if (hasTrigger || configEnabled) {
            try {
                val prefs = ctx.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                val ts = System.currentTimeMillis()
                prefs.edit().putLong("last_unlock_time", ts).apply()
                try {
                    DbRepo.log(
                        ctx,
                        null,
                        "【解锁提醒】UnlockWorker：记录本次解锁事件时间戳 last_unlock_time=" + ts
                    )
                } catch (_: Throwable) {
                }
            } catch (_: Throwable) {
                // ignore prefs errors
            }

            try {
                NotifyHelper.sendUnlockReminder(ctx, 2000, "愿景提醒", "别忘了你的一件事！")
            } catch (t: Throwable) {
                try {
                    DbRepo.log(
                        ctx,
                        null,
                        "【解锁提醒】UnlockWorker：调用 NotifyHelper.sendUnlockReminder 发送解锁提醒通知时发生异常，exception=" +
                            t.javaClass.simpleName + "，message=" + (t.message ?: "null")
                    )
                } catch (_: Throwable) {
                }
            }
        }

        return Result.success()
    }
}
