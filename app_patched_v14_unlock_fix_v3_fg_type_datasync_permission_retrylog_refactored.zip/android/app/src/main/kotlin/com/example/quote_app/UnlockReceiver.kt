package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver is a very thin BroadcastReceiver that simply reacts to
 * screen-on / unlock style broadcasts and schedules a WorkManager task
 * ([UnlockWorker]) to perform the heavy unlock‑reminder business logic
 * on a background thread.
 *
 * 这样可以避免在广播回调（通常运行在主线程）中执行耗时的数据库 / I/O 操作，
 * 同时不再依赖前台常驻服务来「保活」解锁提醒。
 */
class UnlockReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val act = intent?.action ?: "null"

        // 记录广播到达情况，方便线上排查
        try {
            DbRepo.log(
                context,
                null,
                "[UnlockReceiver] onReceive action=" + act
            )
            if (act == Intent.ACTION_SCREEN_ON ||
                act == Intent.ACTION_USER_PRESENT ||
                act == Intent.ACTION_USER_UNLOCKED) {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】收到系统解锁相关广播，准备调度 UnlockWorker 处理业务逻辑"
                )
            }
        } catch (_: Throwable) {
        }

        // 可选：在 debug 构建下弹出 Toast，帮助开发验证解锁广播是否到达
        try {
            showDebugToast(context, "UnlockReceiver 收到广播: $act，已调度 UnlockWorker")
        } catch (_: Throwable) {
        }

        // 将真正的业务逻辑交给 WorkManager 中的 UnlockWorker 处理
        try {
            val workRequest = OneTimeWorkRequestBuilder<UnlockWorker>()
                .build()
            WorkManager.getInstance(context.applicationContext)
                .enqueue(workRequest)
        } catch (_: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：调度 UnlockWorker 失败，本次解锁提醒被跳过"
                )
            } catch (_: Throwable) {
            }
        }
    }

    /**
     * 简单的调试 Toast 工具，仅在需要时调用。
     */
    private fun showDebugToast(context: Context, text: String) {
        // 这里不做 buildType 判断，避免依赖 BuildConfig；异常会被外层吞掉。
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
    }
}
