package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine

object Channels {
    fun register(engine: FlutterEngine, ctx: Context) {
        SysChannel.register(engine, ctx)
    }
}
