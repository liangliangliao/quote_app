import '../platform/perm_helper.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../data/dao.dart';


class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  // 三种通知通道（Android），与 iOS/macOS 的 Category 对应
  static const String chAlarmId = 'quote_alarm';
  static const String chAlarmName = '闹钟/重要提醒';
  static const String chAlarmDesc = '高优先级，关键任务提醒';

  static const String chReminderId = 'quote_reminder';
  static const String chReminderName = '日常提醒';
  static const String chReminderDesc = '常规提醒';

  static const String chInfoId = 'quote_info';
  static const String chInfoName = '资讯/静默';
  static const String chInfoDesc = '静默/低打扰的播报';

  static const AndroidNotificationChannel _channelAlarm = AndroidNotificationChannel(
    chAlarmId, chAlarmName,
    description: chAlarmDesc,
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );

  static const AndroidNotificationChannel _channelReminder = AndroidNotificationChannel(
    chReminderId, chReminderName,
    description: chReminderDesc,
    importance: Importance.high,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );

  static const AndroidNotificationChannel _channelInfo = AndroidNotificationChannel(
    chInfoId, chInfoName,
    description: chInfoDesc,
    importance: Importance.defaultImportance,
    playSound: false,
    enableVibration: false,
    showBadge: false,
  );

  // iOS/macOS 类别 ID
  static const String catAlarm = 'ALARM';
  static const String catReminder = 'REMINDER';
  static const String catInfo = 'INFO';

  static Future<void> init() async {
    if (_inited) return;
    try {
      await LogDao().add(taskUid: 'system', detail: '[NotificationService] init() start');
    } catch (_) {}

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    final darwinInit = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
      notificationCategories: <DarwinNotificationCategory>[
        DarwinNotificationCategory(
          catAlarm,
          actions: <DarwinNotificationAction>[
            DarwinNotificationAction.text('DONE', '完成', buttonTitle: '完成'),
            DarwinNotificationAction.plain('SNOOZE', '稍后提醒'),
          ],
        ),
        DarwinNotificationCategory(
          catReminder,
          actions: <DarwinNotificationAction>[
            DarwinNotificationAction.text('DONE', '完成', buttonTitle: '完成'),
          ],
        ),
        DarwinNotificationCategory(catInfo),
      ],
    );
    final settings = InitializationSettings(android: androidInit, iOS: darwinInit);
    await _plugin.initialize(settings);

    // 确保三条通道同时创建（Android 13+ 同时申请通知权限）
    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      try {
        await android?.requestNotificationsPermission();
        await LogDao().add(taskUid: 'system', detail: '[NotificationService] Android requestNotificationsPermission() called');
      } catch (e) {
        try { await LogDao().add(taskUid: 'system', detail: '[NotificationService] requestNotificationsPermission() error: $e'); } catch (_) {}
      }
      try {
        await android?.createNotificationChannel(_channelAlarm);
        await android?.createNotificationChannel(_channelReminder);
        await android?.createNotificationChannel(_channelInfo);
        await LogDao().add(taskUid: 'system', detail: '[NotificationService] Android channels ensured: alarm/reminder/info');
      } catch (e) {
        try { await LogDao().add(taskUid: 'system', detail: '[NotificationService] createNotificationChannel error: $e'); } catch (_) {}
      }
    } else if (Platform.isIOS || Platform.isMacOS) {
      final darwin = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      try {
        await darwin?.requestPermissions(alert: true, badge: true, sound: true);
        await LogDao().add(taskUid: 'system', detail: '[NotificationService] iOS/macOS permissions requested');
      } catch (e) {
        try { await LogDao().add(taskUid: 'system', detail: '[NotificationService] iOS requestPermissions error: $e'); } catch (_) {}
      }
    }

    _inited = true;
    try {
      await LogDao().add(taskUid: 'system', detail: '[NotificationService] init() done');
    } catch (_) {}
  }

  // 类别枚举：默认 info（静默）——调用方可显式指定
  static const int alarm = 1;
  static const int reminder = 2;
  static const int info = 3;

  static Future<void> show({
    required int id,
    required String title,
    required String body,
    int category = info,
    String? payload,
    BigPictureStyleInformation? style,
    Object? largeIcon,
    String? largeIconPath,
  }) async {
    await init();

    // 根据类别选择通道 / iOS category
    String channelId = chInfoId;
    String channelName = chInfoName;
    String channelDesc = chInfoDesc;
    String darwinCategory = catInfo;

    switch (category) {
      case alarm:
        channelId = chAlarmId; channelName = chAlarmName; channelDesc = chAlarmDesc; darwinCategory = catAlarm;
        break;
      case reminder:
        channelId = chReminderId; channelName = chReminderName; channelDesc = chReminderDesc; darwinCategory = catReminder;
        break;
      default:
        channelId = chInfoId; channelName = chInfoName; channelDesc = chInfoDesc; darwinCategory = catInfo;
    }

    try { await LogDao().add(taskUid: 'system', detail: '[NotificationService] show() id=$id category=$category title=$title'); } catch (_) {}

    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDesc,
      importance: (category == alarm) ? Importance.max : (category == reminder ? Importance.high : Importance.defaultImportance),
      priority: (category == alarm) ? Priority.max : (category == reminder ? Priority.high : Priority.defaultPriority),
      styleInformation: style,
      icon: '@mipmap/ic_launcher',
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : (largeIcon == null
              ? const DrawableResourceAndroidBitmap('@mipmap/ic_launcher')
              : largeIcon as dynamic),
      enableVibration: (category != info),
      playSound: (category != info),
      ticker: 'quote_ticker',
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(
        categoryIdentifier: darwinCategory,
        presentAlert: true,
        presentBadge: true,
        presentSound: category != info,
      ),
      macOS: DarwinNotificationDetails(
        categoryIdentifier: darwinCategory,
        presentAlert: true,
        presentBadge: true,
        presentSound: category != info,
      ),
    );

    await _plugin.show(id, title, body, details, payload: payload);
    try { await LogDao().add(taskUid: 'system', detail: '[NotificationService] show() done id=$id'); } catch (_) {}
  }

  // 便捷方法（不破坏调用方兼容性）
  static Future<void> showAlarm({required int id, required String title, required String body, String? payload, String? largeIconPath}) =>
      show(id: id, title: title, body: body, category: alarm, payload: payload, largeIconPath: largeIconPath);
  static Future<void> showReminder({required int id, required String title, required String body, String? payload, String? largeIconPath}) =>
      show(id: id, title: title, body: body, category: reminder, payload: payload, largeIconPath: largeIconPath);
  static Future<void> showInfo({required int id, required String title, required String body, String? payload, String? largeIconPath}) =>
      show(id: id, title: title, body: body, category: info, payload: payload, largeIconPath: largeIconPath);
}
