import 'platform/perm_helper.dart';


import 'package:workmanager/workmanager.dart';
import 'utils/notification_helper.dart';
import 'background/workmanager_callback.dart';
import 'package:flutter/material.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/settings_page.dart';
import 'pages/logs_page.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'data/db.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Start app immediately to avoid long splash hang; init async after first frame.
  runApp(const MyApp());
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try { await AndroidAlarmManager.initialize(); } catch (_) {}
    await AppDatabase.instance();
    await PermHelper.ensureExactAlarmPermission();
    // 某些机型需要直接主动请求一次以唤起授权页
    await PermHelper.requestExactAlarmPermission();
    await PermHelper.ensureBatteryOptExemption();
    await NotificationService.init();
    await SchedulerService.init();
    // ==== Background notifications wiring (added) ====
    await AppNotifications.initialize();
    await AppNotifications.ensurePermissions();
    try {
      await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
      // 注册 15 分钟周期任务，保持唯一避免重复
      await Workmanager().registerPeriodicTask(
        'periodic_task_unique',
        periodicTask,
        frequency: const Duration(minutes: 15),
        initialDelay: const Duration(minutes: 1),
        inputData: {'title': '计划提醒', 'body': '这是来自后台的定时通知'},
        existingWorkPolicy: ExistingWorkPolicy.keep,
        constraints: Constraints(
          networkType: NetworkType.not_required,
          requiresCharging: false,
          requiresDeviceIdle: false,
          requiresBatteryNotLow: false,
          requiresStorageNotLow: false,
        ),
      );
    } catch (_) {}
    // ==== End wiring ====

    await SchedulerService.scheduleNextForAll();
  });
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];
  // Titles removed per UI requirement
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        body: _pages[_idx],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _idx,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home), label: '首页'),
            NavigationDestination(icon: Icon(Icons.history), label: '历史'),
            NavigationDestination(icon: Icon(Icons.list), label: '日志'),
            NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
          ],
          onDestinationSelected: (i)=> setState(()=> _idx = i),
        ),
      ),
    );
  }
}
