// Re-export shim to avoid duplicate class definitions.
// The canonical SimpleBus lives in services/native_guard.dart
export '../services/native_guard.dart' show SimpleBus, NativeGuard;


import 'package:flutter/material.dart';

class SimpleBus {
  static final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

  static void navHome() {
    final nav = navKey.currentState;
    if (nav == null) return;
    // 清空并回到根（默认首页），避免底部导航还停留在其他Tab
    nav.pushNamedAndRemoveUntil('/', (route) => false);
  }

  static void pokeHome() {
    // 留空或发事件：兼容现有代码，调用方若已监听将收到刷新信号
  }
}
