package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.amap.api.location.AMapLocation
import com.amap.api.location.AMapLocationClient
import com.amap.api.location.AMapLocationClientOption
import com.amap.api.location.AMapLocationListener
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class AmapLocationStream(private val appCtx: Context) : EventChannel.StreamHandler, AMapLocationListener, MethodChannel.MethodCallHandler {

    private var eventSink: EventChannel.EventSink? = null
    private var client: AMapLocationClient? = null
    private var option: AMapLocationClientOption? = null

    private var configuredApiKey: String = ""
    private var intervalMs: Long = 1000L
    private var needAddress: Boolean = false
    private var bgEnabled: Boolean = false
    private var notifId: Int = 11023

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "configure" -> {
                    val key = (call.argument<String>("apiKey") ?: "").trim()
                    val interval = (call.argument<Number>("intervalMs")?.toLong() ?: 1000L).coerceAtLeast(1000L)
                    val needAddr = call.argument<Boolean>("needAddress") ?: false
                    val nid = (call.argument<Number>("notificationId")?.toInt() ?: notifId).coerceAtLeast(1)
                    configuredApiKey = key
                    intervalMs = interval
                    needAddress = needAddr
                    notifId = nid
                    ensureClient(recreate = true)
                    result.success(true)
                }
                "start" -> {
                    ensureClient(recreate = false)
                    client?.startLocation()
                    emitStatus("started")
                    result.success(true)
                }
                "stop" -> {
                    client?.stopLocation()
                    emitStatus("stopped")
                    result.success(true)
                }
                "enableBackground" -> {
                    val title = call.argument<String>("title") ?: "捉迷藏定位中"
                    val text = call.argument<String>("text") ?: "正在持续定位（严格5m到达判定）"
                    val id = (call.argument<Number>("notificationId")?.toInt() ?: notifId).coerceAtLeast(1)
                    notifId = id
                    ensureClient(recreate = false)
                    val n = buildNotification(title, text)
                    client?.enableBackgroundLocation(notifId, n)
                    bgEnabled = true
                    emitStatus("background_enabled")
                    result.success(true)
                }
                "disableBackground" -> {
                    val remove = call.argument<Boolean>("removeNotification") ?: true
                    try { client?.disableBackgroundLocation(remove) } catch (_: Throwable) {}
                    bgEnabled = false
                    emitStatus("background_disabled")
                    result.success(true)
                }
                "setApiKey" -> {
                    configuredApiKey = (call.argument<String>("apiKey") ?: "").trim()
                    applyApiKey(configuredApiKey)
                    result.success(true)
                }
                "dispose" -> {
                    try { client?.stopLocation() } catch (_: Throwable) {}
                    try { client?.onDestroy() } catch (_: Throwable) {}
                    client = null
                    option = null
                    bgEnabled = false
                    result.success(true)
                }
                "isBackgroundEnabled" -> result.success(bgEnabled)
                else -> result.notImplemented()
            }
        } catch (t: Throwable) {
            result.error("AMAP", t.message, null)
        }
    }

    private fun ensureClient(recreate: Boolean) {
        if (recreate) {
            try { client?.stopLocation() } catch (_: Throwable) {}
            try { client?.onDestroy() } catch (_: Throwable) {}
            client = null
            option = null
        }
        if (client != null && option != null) {
            applyOption(option!!)
            client?.setLocationOption(option)
            return
        }

        // 高德隐私合规：必须在创建Client前调用
        try { AMapLocationClient.updatePrivacyShow(appCtx, true, true) } catch (_: Throwable) {}
        try { AMapLocationClient.updatePrivacyAgree(appCtx, true) } catch (_: Throwable) {}
        applyApiKey(configuredApiKey)

        client = AMapLocationClient(appCtx.applicationContext)
        option = AMapLocationClientOption()
        applyOption(option!!)
        client?.setLocationOption(option)
        client?.setLocationListener(this)
    }

    private fun applyApiKey(key: String) {
        if (key.isBlank()) return
        try {
            // Some AMap SDK versions expose static setApiKey(String); use reflection for compatibility.
            val m = AMapLocationClient::class.java.getMethod("setApiKey", String::class.java)
            m.invoke(null, key)
        } catch (_: Throwable) {
            // Ignore; manifest meta-data may be used in some setups.
        }
    }

    private fun applyOption(opt: AMapLocationClientOption) {
        opt.locationMode = AMapLocationClientOption.AMapLocationMode.Hight_Accuracy
        opt.interval = intervalMs
        opt.isNeedAddress = needAddress
        opt.isMockEnable = false
        try { opt.setOnceLocationLatest(true) } catch (_: Throwable) {}
    }

    override fun onLocationChanged(loc: AMapLocation?) {
        if (loc == null) return
        val map = hashMapOf<String, Any?>()
        map["type"] = "location"
        map["errorCode"] = loc.errorCode
        map["errorInfo"] = loc.errorInfo
        map["lat"] = loc.latitude
        map["lng"] = loc.longitude
        map["accuracy"] = loc.accuracy.toDouble()
        map["bearing"] = loc.bearing.toDouble()
        map["speed"] = loc.speed.toDouble()
        map["altitude"] = loc.altitude
        map["provider"] = loc.provider
        map["locationType"] = loc.locationType
        map["coordType"] = try { loc.coordType } catch (_: Throwable) { null }
        map["time"] = loc.time
        try { map["isOffset"] = loc.isOffset } catch (_: Throwable) {}
        try { map["address"] = if (needAddress) loc.address else null } catch (_: Throwable) {}
        eventSink?.success(map)
    }

    private fun emitStatus(status: String) {
        eventSink?.success(hashMapOf<String, Any?>(
            "type" to "status",
            "status" to status,
            "background" to bgEnabled
        ))
    }

    private fun buildNotification(title: String, text: String): Notification {
        val channelId = "hide_seek_amap_location"
        val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "捉迷藏定位", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(appCtx, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .build()
    }
}
