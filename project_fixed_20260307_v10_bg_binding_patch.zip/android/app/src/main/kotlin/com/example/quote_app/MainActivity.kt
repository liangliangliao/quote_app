package com.example.quote_app

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.core.view.WindowCompat

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import android.content.Intent

import com.example.quote_app.ppg.PpgCamera2Channel

class MainActivity : FlutterActivity() {


    private fun maybeHandleNotificationIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra("from_notification", false)) {
            // Extract additional extras for navigation
            val notifType = intent.getStringExtra("notif_type")
            val payload = intent.getStringExtra("payload")
            // Record and emit the event with type/payload
            Channels.markNotificationTapped()
            Channels.emitNotificationTap(notifType, payload)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge: allow Flutter to draw behind the system status/navigation bars.
        // This is required for background images/colors to be visible under 3-button navigation.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Disable the Android 10+ contrast-enforcement scrim that would otherwise turn
            // the 3-button navigation area into a dark/opaque background.
            window.isNavigationBarContrastEnforced = false
        }
        maybeHandleNotificationIntent(intent)
        try {
            if (intent?.getBooleanExtra("from_notification", false) == true) {
                com.example.quote_app.data.DbRepo.log(
                    applicationContext,
                    null,
                    "[NotifTap] onCreate from_notification=true"
                )
            }
        } catch (_: Throwable) {}
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        maybeHandleNotificationIntent(intent)
        try {
            if (intent.getBooleanExtra("from_notification", false)) {
                com.example.quote_app.data.DbRepo.log(
                    applicationContext,
                    null,
                    "[NotifTap] onNewIntent from_notification=true"
                )
            }
        } catch (_: Throwable) {}
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 仅注册通道；不引入业务逻辑，避免后续维护成本
        Channels.register(flutterEngine, applicationContext)
		// 高精度 PPG：Android Camera2（含可选预览）
		try { PpgCamera2Channel.register(flutterEngine, applicationContext) } catch (_: Throwable) {}
	        // 注意：SysChannel 与 Channels 使用相同 MethodChannel 名称（com.example.quote_app/sys）。
	        // 为避免 handler 被覆盖导致系统/权限相关方法丢失，这里不再重复注册 SysChannel。
    }
}