package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.amap.api.location.AMapLocation
import com.amap.api.location.AMapLocationClient
import com.amap.api.location.AMapLocationClientOption
import com.amap.api.location.AMapLocationListener
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class AmapLocationStream(private val appCtx: Context) : EventChannel.StreamHandler, AMapLocationListener, MethodChannel.MethodCallHandler, SensorEventListener {

    private var eventSink: EventChannel.EventSink? = null
    private var client: AMapLocationClient? = null
    private var option: AMapLocationClientOption? = null

    private var configuredApiKey: String = ""
    private var intervalMs: Long = 1000L
    private var needAddress: Boolean = false
    private var bgEnabled: Boolean = false
    private var notifId: Int = 11023

    private val sensorManager: SensorManager? = appCtx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val rotationSensor: Sensor? by lazy {
        sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
    }
    @Volatile private var latestSensorHeadingDeg: Double? = null
    @Volatile private var latestSensorAccuracyLevel: Int = -1
    @Volatile private var latestScreenRotation: Int = 0
    private var sensorRegistered = false

    private val amapLocTypeSameReq: Int? by lazy(LazyThreadSafetyMode.NONE) { amapLocationConst("LOCATION_TYPE_SAME_REQ") }
    private val amapLocTypeFixCache: Int? by lazy(LazyThreadSafetyMode.NONE) { amapLocationConst("LOCATION_TYPE_FIX_CACHE") }
    private val amapLocTypeLastCache: Int? by lazy(LazyThreadSafetyMode.NONE) { amapLocationConst("LOCATION_TYPE_LAST_LOCATION_CACHE") }
    private val amapLocTypeOffline: Int? by lazy(LazyThreadSafetyMode.NONE) { amapLocationConst("LOCATION_TYPE_OFFLINE") }

    private fun amapLocationConst(name: String): Int? {
        return try {
            val f = AMapLocation::class.java.getField(name)
            f.getInt(null)
        } catch (_: Throwable) {
            null
        }
    }

    private fun isCacheLikeLocationType(type: Int): Boolean {
        return listOf(amapLocTypeSameReq, amapLocTypeFixCache, amapLocTypeLastCache, amapLocTypeOffline)
            .filterNotNull()
            .any { it == type }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
        stopSensorHeading()
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "configure" -> {
                    val key = (call.argument<String>("apiKey") ?: "").trim()
                    val interval = (call.argument<Number>("intervalMs")?.toLong() ?: 1000L).coerceAtLeast(1000L)
                    val needAddr = call.argument<Boolean>("needAddress") ?: false
                    val nid = (call.argument<Number>("notificationId")?.toInt() ?: notifId).coerceAtLeast(1)
                    configuredApiKey = key
                    intervalMs = interval
                    needAddress = needAddr
                    notifId = nid
                    ensureClient(recreate = true)
                    result.success(true)
                }
                "start" -> {
                    ensureClient(recreate = false)
                    client?.startLocation()
                    startSensorHeading()
                    emitStatus("started")
                    result.success(true)
                }
                "stop" -> {
                    client?.stopLocation()
                    stopSensorHeading()
                    emitStatus("stopped")
                    result.success(true)
                }
                "enableBackground" -> {
                    val title = call.argument<String>("title") ?: "捉迷藏定位中"
                    val text = call.argument<String>("text") ?: "正在持续定位（严格5m到达判定）"
                    val id = (call.argument<Number>("notificationId")?.toInt() ?: notifId).coerceAtLeast(1)
                    notifId = id
                    ensureClient(recreate = false)
                    val n = buildNotification(title, text)
                    client?.enableBackgroundLocation(notifId, n)
                    bgEnabled = true
                    emitStatus("background_enabled")
                    result.success(true)
                }
                "disableBackground" -> {
                    val remove = call.argument<Boolean>("removeNotification") ?: true
                    try { client?.disableBackgroundLocation(remove) } catch (_: Throwable) {}
                    bgEnabled = false
                    emitStatus("background_disabled")
                    result.success(true)
                }
                "setApiKey" -> {
                    configuredApiKey = (call.argument<String>("apiKey") ?: "").trim()
                    applyApiKey(configuredApiKey)
                    result.success(true)
                }
                "dispose" -> {
                    try { client?.stopLocation() } catch (_: Throwable) {}
                    stopSensorHeading()
                    try { client?.onDestroy() } catch (_: Throwable) {}
                    client = null
                    option = null
                    bgEnabled = false
                    result.success(true)
                }
                "isBackgroundEnabled" -> result.success(bgEnabled)
                else -> result.notImplemented()
            }
        } catch (t: Throwable) {
            result.error("AMAP", t.message, null)
        }
    }

    private fun ensureClient(recreate: Boolean) {
        if (recreate) {
            try { client?.stopLocation() } catch (_: Throwable) {}
            try { client?.onDestroy() } catch (_: Throwable) {}
            client = null
            option = null
        }
        if (client != null && option != null) {
            applyOption(option!!)
            client?.setLocationOption(option)
            return
        }

        // 高德隐私合规：必须在创建Client前调用
        try { AMapLocationClient.updatePrivacyShow(appCtx, true, true) } catch (_: Throwable) {}
        try { AMapLocationClient.updatePrivacyAgree(appCtx, true) } catch (_: Throwable) {}
        applyApiKey(configuredApiKey)

        client = AMapLocationClient(appCtx.applicationContext)
        option = AMapLocationClientOption()
        applyOption(option!!)
        client?.setLocationOption(option)
        client?.setLocationListener(this)
    }

    private fun applyApiKey(key: String) {
        if (key.isBlank()) return
        try {
            // Some AMap SDK versions expose static setApiKey(String); use reflection for compatibility.
            val m = AMapLocationClient::class.java.getMethod("setApiKey", String::class.java)
            m.invoke(null, key)
        } catch (_: Throwable) {
            // Ignore; manifest meta-data may be used in some setups.
        }
    }

    private fun applyOption(opt: AMapLocationClientOption) {
        opt.locationMode = AMapLocationClientOption.AMapLocationMode.Hight_Accuracy
        opt.interval = intervalMs
        opt.isNeedAddress = needAddress
        opt.isMockEnable = false
        try {
            val m = AMapLocationClientOption::class.java.getMethod("setLocationCacheEnable", Boolean::class.javaPrimitiveType)
            m.invoke(opt, false)
        } catch (_: Throwable) {}
        try { opt.setOnceLocationLatest(true) } catch (_: Throwable) {}
    }

    override fun onLocationChanged(loc: AMapLocation?) {
        if (loc == null) return
        val map = hashMapOf<String, Any?>()
        map["type"] = "location"
        map["errorCode"] = loc.errorCode
        map["errorInfo"] = loc.errorInfo
        map["lat"] = loc.latitude
        map["lng"] = loc.longitude
        map["accuracy"] = loc.accuracy.toDouble()
        map["bearing"] = normalizeDeg(loc.bearing.toDouble())
        map["speed"] = loc.speed.toDouble()
        map["altitude"] = loc.altitude
        map["provider"] = loc.provider
        map["locationType"] = loc.locationType
        map["isCacheLikeLocationType"] = try { isCacheLikeLocationType(loc.locationType) } catch (_: Throwable) { false }
        map["coordType"] = try { loc.coordType } catch (_: Throwable) { null }
        map["time"] = loc.time
        latestSensorHeadingDeg?.let { map["sensorHeading"] = normalizeDeg(it) }
        map["sensorAccuracyLevel"] = latestSensorAccuracyLevel
        map["screenRotation"] = latestScreenRotation
        try { map["isOffset"] = loc.isOffset } catch (_: Throwable) {}
        try { map["address"] = if (needAddress) loc.address else null } catch (_: Throwable) {}
        eventSink?.success(map)
    }

    private fun startSensorHeading() {
        if (sensorRegistered) return
        val sm = sensorManager ?: return
        val sensor = rotationSensor ?: return
        try {
            sensorRegistered = sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        } catch (_: Throwable) {
            sensorRegistered = false
        }
    }

    private fun stopSensorHeading() {
        if (!sensorRegistered) return
        try { sensorManager?.unregisterListener(this) } catch (_: Throwable) {}
        sensorRegistered = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        if (e.sensor?.type != Sensor.TYPE_ROTATION_VECTOR && e.sensor?.type != Sensor.TYPE_GAME_ROTATION_VECTOR) return
        try {
            val rot = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(rot, e.values)
            val remapped = FloatArray(9)
            val rotation = currentDisplayRotation()
            latestScreenRotation = rotation
            val ok = when (rotation) {
                Surface.ROTATION_90 -> SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, remapped)
                Surface.ROTATION_180 -> SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, remapped)
                Surface.ROTATION_270 -> SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, remapped)
                else -> {
                    rot.copyInto(remapped)
                    true
                }
            }
            val matrix = if (ok) remapped else rot
            val orient = FloatArray(3)
            SensorManager.getOrientation(matrix, orient)
            var deg = Math.toDegrees(orient[0].toDouble())
            if (!deg.isFinite()) return
            while (deg < 0.0) deg += 360.0
            while (deg >= 360.0) deg -= 360.0
            latestSensorHeadingDeg = deg
        } catch (_: Throwable) {}
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        latestSensorAccuracyLevel = accuracy
    }


    private fun currentDisplayRotation(): Int {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                appCtx.display?.rotation ?: Surface.ROTATION_0
            } else {
                @Suppress("DEPRECATION")
                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                @Suppress("DEPRECATION")
                wm?.defaultDisplay?.rotation ?: Surface.ROTATION_0
            }
        } catch (_: Throwable) {
            Surface.ROTATION_0
        }
    }

    private fun normalizeDeg(v: Double): Double {
        var x = v
        if (!x.isFinite()) return Double.NaN
        x %= 360.0
        if (x < 0.0) x += 360.0
        return x
    }

    private fun emitStatus(status: String) {
        eventSink?.success(hashMapOf<String, Any?>(
            "type" to "status",
            "status" to status,
            "background" to bgEnabled
        ))
    }

    private fun buildNotification(title: String, text: String): Notification {
        val channelId = "hide_seek_amap_location"
        val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "捉迷藏定位", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(appCtx, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .build()
    }
}
