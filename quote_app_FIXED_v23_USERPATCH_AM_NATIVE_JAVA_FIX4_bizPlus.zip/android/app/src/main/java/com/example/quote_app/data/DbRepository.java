
package com.example.quote_app.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class DbRepository {

    public static final class Task {
        public String uid;
        public String title;
        public String content;
        public long triggerAtMillis;
        public int enabled = 1;
    
        public String type;
        public String prompt;
        public String avatarPath;
    }

    private DbRepository() {}

    private static SQLiteDatabase openByPath(String path) {
        if (TextUtils.isEmpty(path)) return null;
        File f = new File(path);
        if (!f.exists()) return null;
        return SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
    }


    public static Task findTaskByUid(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.tasksSource)) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        try {
            String uidCol = or(cc.taskColMap.get("uid"), "uid");
            String titleCol = or(cc.taskColMap.get("title"), "title");
            String contentCol = or(cc.taskColMap.get("content"), "content");
            String whenCol = or(cc.taskColMap.get("trigger_at"), "trigger_at");
            String sql = "SELECT " + uidCol + "," + titleCol + "," + contentCol + "," + whenCol +
                         " FROM " + cc.tasksSource + " WHERE " + uidCol + "=? LIMIT 1";
            Cursor c = db.rawQuery(sql, new String[]{ uid });
            try {
                if (c.moveToFirst()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    return t;
                }
            } finally {
                c.close();
            }
        } catch (Throwable ignore) {
        } finally {
            db.close();
        }
        return null;
    }

    public static List<Task> listFutureTasks(Context ctx) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        List<Task> out = new ArrayList<>();
        if (cc == null || TextUtils.isEmpty(cc.tasksSource)) return out;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return out;
        try {
            long now = System.currentTimeMillis();
            String uidCol = or(cc.taskColMap.get("uid"), "uid");
            String titleCol = or(cc.taskColMap.get("title"), "title");
            String contentCol = or(cc.taskColMap.get("content"), "content");
            String whenCol = or(cc.taskColMap.get("trigger_at"), "trigger_at");
            String enabledCol = or(cc.taskColMap.get("enabled"), "enabled");
            // enabled 可能缺失，使用 1=1 兜底
            String where = (enabledCol != null ? (enabledCol + "=1 AND ") : "") + whenCol + ">?";
            String sql = "SELECT " + uidCol + "," + titleCol + "," + contentCol + "," + whenCol +
                         " FROM " + cc.tasksSource + " WHERE " + where;
            Cursor c = db.rawQuery(sql, new String[]{ String.valueOf(now) });
            try {
                while (c.moveToNext()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    out.add(t);
                }
            } finally {
                c.close();
            }
        } catch (Throwable ignore) {
        } finally {
            db.close();
        }
        return out;
    }

    public static String pickRandomQuote(Context ctx) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.quotesSource)) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        try {
            String textCol = or(cc.quoteColMap.get("text"), "text");
            String authorCol = cc.quoteColMap.get("author");
            String select = "SELECT " + textCol + (authorCol != null ? ("," + authorCol) : "") +
                            " FROM " + cc.quotesSource + " ORDER BY RANDOM() LIMIT 1";
            Cursor c = db.rawQuery(select, null);
            try {
                if (c.moveToFirst()) {
                    String text = c.getString(0);
                    String author = authorCol != null ? c.getString(1) : null;
                    return (author == null || author.isEmpty()) ? text : (text + " — " + author);
                }
            } finally {
                c.close();
            }
        } catch (Throwable ignore) {
        } finally {
            db.close();
        }
        return null;
    }

    
    // === Added business helpers ===

    public static final class Config {
        public String apiKey;
        public String model;
        public String endpoint;
        public String mode;
    }


    public static Config loadConfig(Context ctx) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        Config cfg = new Config();
        try {
            String[] keys = new String[]{"api_key","model","endpoint","mode"};
            for (String k: keys) {
                String v = tryKv(db, "configs", "key", "value", k);
                if (v == null) v = tryKv(db, "config", "key", "value", k);
                if ("api_key".equals(k)) cfg.apiKey = v;
                if ("model".equals(k)) cfg.model = v;
                if ("endpoint".equals(k)) cfg.endpoint = v;
                if ("mode".equals(k)) cfg.mode = v;
            }
            if (cfg.model == null || cfg.model.isEmpty()) cfg.model = "gpt-5";
            if (cfg.endpoint == null || cfg.endpoint.isEmpty()) cfg.endpoint = "https://api.openai.com/v1";
        } catch (Throwable ignore) {
        } finally { db.close(); }
        return cfg;
    }

    private static String tryKv(SQLiteDatabase db, String table, String keyCol, String valCol, String key) {
        try (Cursor c = db.rawQuery("SELECT "+valCol+" FROM "+table+" WHERE "+keyCol+"=? LIMIT 1", new String[]{key})) {
            if (c.moveToFirst()) return c.getString(0);
        } catch (Throwable ignore) {}
        return null;
    }

    public static Task getTaskFull(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.tasksSource)) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        try {
            String uidCol = or(cc.taskColMap.get("uid"), "uid");
            String titleCol = or(cc.taskColMap.get("title"), "title");
            String contentCol = or(cc.taskColMap.get("content"), "content");
            String whenCol = or(cc.taskColMap.get("trigger_at"), "trigger_at");
            String enabledCol = cc.taskColMap.get("enabled");
            String typeCol = cc.taskColMap.get("type");
            String promptCol = cc.taskColMap.get("prompt");
            String avatarCol = cc.taskColMap.get("avatar");

            StringBuilder sb = new StringBuilder();
            sb.append("SELECT ").append(uidCol).append(",").append(titleCol).append(",").append(contentCol).append(",").append(whenCol);
            if (enabledCol != null) sb.append(",").append(enabledCol);
            if (typeCol != null) sb.append(",").append(typeCol);
            if (promptCol != null) sb.append(",").append(promptCol);
            if (avatarCol != null) sb.append(",").append(avatarCol);
            sb.append(" FROM ").append(cc.tasksSource).append(" WHERE ").append(uidCol).append("=? LIMIT 1");
            Cursor c = db.rawQuery(sb.toString(), new String[]{ uid });
            try {
                if (c.moveToFirst()) {
                    Task t = new Task();
                    int idx = 0;
                    t.uid = c.getString(idx++); t.title = c.getString(idx++); t.content = c.getString(idx++); t.triggerAtMillis = c.getLong(idx++);
                    if (enabledCol != null) t.enabled = c.getInt(idx++) != 0;
                    if (typeCol != null) t.type = c.getString(idx++);
                    if (promptCol != null) t.prompt = c.getString(idx++);
                    if (avatarCol != null) t.avatarPath = c.getString(idx++);
                    return t;
                }
            } finally { c.close(); }
        } catch (Throwable ignore) {
        } finally { db.close(); }
        return null;
    }

    public static List<String> listQuoteTextsForTask(Context ctx, String taskUid, int limit) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        List<String> out = new ArrayList<>();
        if (cc == null || TextUtils.isEmpty(cc.quotesSource)) return out;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return out;
        String table = cc.quotesSource;
        try {
            String textCol = or(cc.quoteColMap.get("text"), "content");
            String taskCol = or(cc.quoteColMap.get("task_uid"), "task_uid");
            String sql;
            String[] args;
            if (taskCol != null) {
                sql = "SELECT "+textCol+" FROM "+table+" WHERE "+taskCol+"=? ORDER BY rowid DESC LIMIT "+limit;
                args = new String[]{ taskUid };
            } else {
                sql = "SELECT "+textCol+" FROM "+table+" ORDER BY rowid DESC LIMIT "+limit;
                args = null;
            }
            try (Cursor c = db.rawQuery(sql, args)) {
                while (c.moveToNext()) out.add(c.getString(0));
            }
        } catch (Throwable ignore) {
        } finally { db.close(); }
        return out;
    }

    public static long insertQuote(Context ctx, String taskUid, String content, String author) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return -1L;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return -1L;
        String table = cc.quotesSource != null ? cc.quotesSource : "quotes";
        // if it's a view, fallback to quotes table name
        if ("v_alarm_quotes".equals(table)) table = "quotes";
        try {
            db.execSQL("BEGIN");
            long now = System.currentTimeMillis();
            String taskCol = or(cc.quoteColMap.get("task_uid"), "task_uid");
            String textCol = or(cc.quoteColMap.get("text"), "content");
            String authorCol = cc.quoteColMap.get("author");
            String createdCol = or(cc.quoteColMap.get("created_at"), "created_at");
            String notifiedCol = or(cc.quoteColMap.get("notified"), "notified");

            String cols = "";
            String qs = "";
            java.util.List<Object> vals = new java.util.ArrayList<>();

            if (taskCol != null) { cols += taskCol; qs += "?"; vals.add(taskUid); }
            if (cols.length()>0) { cols += ","; qs += ","; }
            cols += textCol; qs += "?"; vals.add(content);
            if (authorCol != null) { cols += ","+authorCol; qs += ",?"; vals.add(author); }
            if (createdCol != null) { cols += ","+createdCol; qs += ",?"; vals.add(now); }
            if (notifiedCol != null) { cols += ","+notifiedCol; qs += ",?"; vals.add(0); }

            String sql = "INSERT INTO "+table+" ("+cols+") VALUES ("+qs+")";
            db.execSQL(sql, vals.toArray());

            // return last_insert_rowid when id col exists, else -2
            long id = -2L;
            try (Cursor c = db.rawQuery("SELECT last_insert_rowid()", null)) {
                if (c.moveToFirst()) id = c.getLong(0);
            } catch (Throwable ignore) {}
            db.execSQL("COMMIT");
            return id;
        } catch (Throwable e) {
            try { db.execSQL("ROLLBACK"); } catch (Throwable ignore2) {}
            return -1L;
        } finally { db.close(); }
    }

    public static void markQuoteNotified(Context ctx, long quoteId) {
        if (quoteId <= 0) return;
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return;
        String table = cc.quotesSource != null ? cc.quotesSource : "quotes";
        if ("v_alarm_quotes".equals(table)) table = "quotes";
        String idCol = or(cc.quoteColMap.get("id"), "id");
        String notifiedCol = or(cc.quoteColMap.get("notified"), "notified");
        if (idCol == null || notifiedCol == null) { db.close(); return; }
        try {
            db.execSQL("UPDATE "+table+" SET "+notifiedCol+"=1 WHERE "+idCol+"=?", new Object[]{ quoteId });
        } catch (Throwable ignore) {
        } finally { db.close(); }
    }

    public static String getManualQuote(Context ctx, String taskUid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        String table = cc.quotesSource != null ? cc.quotesSource : "quotes";
        try {
            String textCol = or(cc.quoteColMap.get("text"), "content");
            String taskCol = or(cc.quoteColMap.get("task_uid"), "task_uid");
            String sql;
            String[] args;
            if (taskCol != null) {
                sql = "SELECT "+textCol+" FROM "+table+" WHERE "+taskCol+"=? ORDER BY rowid DESC LIMIT 1";
                args = new String[]{ taskUid };
            } else {
                sql = "SELECT "+textCol+" FROM "+table+" ORDER BY rowid DESC LIMIT 1";
                args = null;
            }
            try (Cursor c = db.rawQuery(sql, args)) {
                if (c.moveToFirst()) return c.getString(0);
            }
        } catch (Throwable ignore) {
        } finally { db.close(); }
        return null;
    }

    public static String getCarouselNextQuote(Context ctx, String taskUid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return null;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return null;
        String table = cc.quotesSource != null ? cc.quotesSource : "quotes";
        String idCol = or(cc.quoteColMap.get("id"), "id");
        String textCol = or(cc.quoteColMap.get("text"), "content");
        String taskCol = or(cc.quoteColMap.get("task_uid"), "task_uid");
        android.content.SharedPreferences sp = android.preference.PreferenceManager.getDefaultSharedPreferences(ctx);
        long cursor = sp.getLong("carousel_"+taskUid, -1L);
        try {
            String sql;
            String[] args;
            if (idCol != null) {
                // find next id greater than cursor; if not found, wrap to min id
                if (cursor > 0) {
                    if (taskCol != null) {
                        sql = "SELECT "+idCol+","+textCol+" FROM "+table+" WHERE "+taskCol+"=? AND "+idCol+">? ORDER BY "+idCol+" ASC LIMIT 1";
                        args = new String[]{ taskUid, String.valueOf(cursor) };
                    } else {
                        sql = "SELECT "+idCol+","+textCol+" FROM "+table+" WHERE "+idCol+">? ORDER BY "+idCol+" ASC LIMIT 1";
                        args = new String[]{ String.valueOf(cursor) };
                    }
                    try (Cursor c = db.rawQuery(sql, args)) {
                        if (c.moveToFirst()) {
                            long nid = c.getLong(0); String text = c.getString(1);
                            sp.edit().putLong("carousel_"+taskUid, nid).apply();
                            return text;
                        }
                    }
                }
                // wrap to first
                if (taskCol != null) {
                    sql = "SELECT "+idCol+","+textCol+" FROM "+table+" WHERE "+taskCol+"=? ORDER BY "+idCol+" ASC LIMIT 1";
                    args = new String[]{ taskUid };
                } else {
                    sql = "SELECT "+idCol+","+textCol+" FROM "+table+" ORDER BY "+idCol+" ASC LIMIT 1";
                    args = null;
                }
                try (Cursor c = db.rawQuery(sql, args)) {
                    if (c.moveToFirst()) {
                        long nid = c.getLong(0); String text = c.getString(1);
                        sp.edit().putLong("carousel_"+taskUid, nid).apply();
                        return text;
                    }
                }
            } else {
                // fallback by created_at or rowid
                if (taskCol != null) {
                    sql = "SELECT "+textCol+" FROM "+table+" WHERE "+taskCol+"=? ORDER BY rowid ASC LIMIT 1 OFFSET 0";
                    args = new String[]{ taskUid };
                } else {
                    sql = "SELECT "+textCol+" FROM "+table+" ORDER BY rowid ASC LIMIT 1";
                    args = null;
                }
                try (Cursor c = db.rawQuery(sql, args)) {
                    if (c.moveToFirst()) return c.getString(0);
                }
            }
        } catch (Throwable ignore) {
        } finally { db.close(); }
        return null;
    }

    public static void log(Context ctx, String taskUid, String detail) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return;
        long now = System.currentTimeMillis();
        // best-effort into 'logs' table
        try {
            db.execSQL("INSERT INTO logs(task_uid, detail, created_at) VALUES(?,?,?)", new Object[]{ taskUid, detail, now });
        } catch (Throwable ignore) {}
        try { db.close(); } catch (Throwable ignore2) {}
    }

private static String or(String a, String b) {
        return a != null ? a : b;
    }
}
