package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver listens for the USER_PRESENT broadcast which fires
 * when the user unlocks the device. When triggered, it checks for
 * any enabled screen‑unlock vision triggers and, if present, sends a
 * gentle reminder notification encouraging the user to recall their
 * vision goal.
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            // Log the received broadcast action for debugging and analytics
            try {
                DbRepo.log(context, null, "[UnlockReceiver] onReceive action=" + (intent?.action ?: "null"))
            } catch (_: Throwable) {}
            // Open the SQLite database and query for enabled screen_unlock triggers.
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
            if (contract == null || contract.dbPath == null) {
                // If contract or db path is unavailable, assume triggers may exist
                try {
                    DbRepo.log(context, null, "[UnlockReceiver] contract or dbPath unavailable, fallback to send reminder")
                } catch (_: Throwable) {}
                sendReminder(context)
                return
            }
            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                null
            )
            val hasTrigger = cursor.moveToFirst()
            try {
                DbRepo.log(context, null, "[UnlockReceiver] hasTrigger=" + hasTrigger)
            } catch (_: Throwable) {}
            cursor.close()
            db.close()
            if (hasTrigger) {
                // Record the timestamp of this unlock event so the app can detect
                // recent unlocks when it starts. This value will be consumed
                // by App.maybeSendUnlockReminderOnAppStart to avoid sending
                // reminders when the app is opened long after unlocking.
                try {
                    val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                    try {
                        DbRepo.log(context, null, "[UnlockReceiver] recorded last_unlock_time")
                    } catch (_: Throwable) {}
                } catch (_: Throwable) { /* ignore errors */ }
                sendReminder(context)
            }
        } catch (_: Throwable) {
            // On any error, fallback to sending reminder. Record the unlock time
            try {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                try {
                    DbRepo.log(context, null, "[UnlockReceiver] exception occurred, fallback to send reminder")
                } catch (_: Throwable) {}
            } catch (_: Throwable) { /* ignore */ }
            sendReminder(context)
        }
    }

    /**
     * Sends a notification reminding the user about their vision goal.
     */
    private fun sendReminder(context: Context) {
        // 记录最近一次通过解锁事件发送提醒的时间，方便 App 在启动时
        // 避免立刻再补发一条重复通知。
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_unlock_reminder_time", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
            // ignore
        }

        // Use a deterministic ID to avoid flooding the notification drawer
        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        // Pass notifType so that tapping the notification opens the vision focus page
        try {
            DbRepo.log(context, null, "[UnlockReceiver] sending reminder notification")
        } catch (_: Throwable) {}
        NotifyHelper.send(context, id, title, body, null, "vision_focus", null)
    }
}