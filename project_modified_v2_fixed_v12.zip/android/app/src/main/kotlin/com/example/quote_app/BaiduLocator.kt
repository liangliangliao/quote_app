package com.example.quote_app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.baidu.location.BDAbstractLocationListener
import com.baidu.location.BDLocation
import com.baidu.location.LocationClient
import com.baidu.location.LocationClientOption
import java.util.concurrent.atomic.AtomicBoolean

object BaiduLocator {
    private const val TAG = "BaiduLocator"

    data class Simple(val latitude: Double, val longitude: Double, val accuracy: Float, val provider: String?)

    /**
     * 高精度“流式”定位：优先使用百度 Location SDK，持续接收多次回调并选择最优精度，
     * 一旦达到目标精度（默认 30m）即结束；超时后返回当前最优值。
     *
     * 说明：
     * - 该方法由 Flutter 侧通过 MethodChannel('com.example.quote_app/sys') 调用。
     * - 为兼容旧逻辑，若 Baidu SDK 无回调/异常，将回退到系统 LocationManager 单次定位。
     */
    @SuppressLint("MissingPermission")
    fun getOnce(ctx: Context, callback: (Simple?) -> Unit) {
        getOnceFromBaiduSdk(ctx, targetAccMeters = 30f, timeoutMs = 12_000L) { bd ->
            if (bd != null) {
                callback(bd)
            } else {
                // Baidu SDK 获取失败时，回退系统定位（保持兼容）。
                getOnceFromSystem(ctx, callback)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun getOnceFromBaiduSdk(
        ctx: Context,
        targetAccMeters: Float,
        timeoutMs: Long,
        callback: (Simple?) -> Unit
    ) {
        val appCtx = ctx.applicationContext
        val done = AtomicBoolean(false)
        val main = Handler(Looper.getMainLooper())

        val client: LocationClient = try {
            LocationClient(appCtx)
        } catch (t: Throwable) {
            Log.w(TAG, "Baidu LocationClient init failed: ${t.message}")
            callback(null)
            return
        }

        val option = LocationClientOption().apply {
            // 高精度模式 + GPS
            setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy)
            setOpenGps(true)
            // 持续回调（流）以获得更稳定精度
            setScanSpan(1000)
            // 不要一次性定位，否则很容易只收到一次粗略回调
            setOnceLocation(false)
            // 坐标系：与现有 Dart 侧 lastProvider==baidu 的处理保持一致
            setCoorType("bd09ll")
            // 降低缓存导致的“假精准”（disableCache 在部分版本标记为 deprecated，但仍可用）
            try { disableCache(true) } catch (_: Throwable) {}
            // 不需要地址，避免额外耗时
            setIsNeedAddress(false)
            // 让 GPS 在 1s 级别更频繁回调
            try { setLocationNotify(true) } catch (_: Throwable) {}
            // 关闭模拟定位（若 SDK 支持）
            try { setEnableSimulateGps(false) } catch (_: Throwable) {}
            // 避免 SDK 杀进程
            try { setIgnoreKillProcess(true) } catch (_: Throwable) {}
        }

        try {
            client.locOption = option
        } catch (t: Throwable) {
            Log.w(TAG, "Baidu locOption set failed: ${t.message}")
        }

        var best: BDLocation? = null
        val listener = object : BDAbstractLocationListener() {
            override fun onReceiveLocation(loc: BDLocation?) {
                if (loc == null) return
                // loc.radius 可能为 0 或负数，做保护
                val acc = (loc.radius.takeIf { it > 0f } ?: Float.MAX_VALUE)
                if (best == null || acc < (best?.radius ?: Float.MAX_VALUE)) {
                    best = loc
                }

                if (acc <= targetAccMeters) {
                    finish(best)
                }
            }

            private fun finish(loc: BDLocation?) {
                if (!done.compareAndSet(false, true)) return
                try { client.unRegisterLocationListener(this) } catch (_: Throwable) {}
                try { client.stop() } catch (_: Throwable) {}
                // 取消超时
                main.removeCallbacksAndMessages(null)
                if (loc == null) {
                    callback(null)
                } else {
                    callback(Simple(loc.latitude, loc.longitude, loc.radius, "baidu"))
                }
            }
        }

        try {
            client.registerLocationListener(listener)
        } catch (t: Throwable) {
            Log.w(TAG, "Baidu register listener failed: ${t.message}")
            callback(null)
            return
        }

        // 超时保护：超时后返回当前最优（若无则 null）
        main.postDelayed({
            if (!done.compareAndSet(false, true)) return@postDelayed
            try { client.unRegisterLocationListener(listener) } catch (_: Throwable) {}
            try { client.stop() } catch (_: Throwable) {}
            val b = best
            if (b == null) {
                callback(null)
            } else {
                callback(Simple(b.latitude, b.longitude, b.radius, "baidu"))
            }
        }, timeoutMs)

        try {
            client.start()
        } catch (t: Throwable) {
            Log.w(TAG, "Baidu client.start failed: ${t.message}")
            // 立即回调失败，避免悬挂
            try { client.unRegisterLocationListener(listener) } catch (_: Throwable) {}
            try { client.stop() } catch (_: Throwable) {}
            callback(null)
        }
    }

    @SuppressLint("MissingPermission")
    private fun getOnceFromSystem(ctx: Context, callback: (Simple?) -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            // Try lastKnown from both GPS and Network
            val candidates = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            var best: Location? = null
            for (p in candidates) {
                try {
                    val l = lm.getLastKnownLocation(p)
                    if (l != null && (best == null || l.accuracy < best!!.accuracy)) {
                        best = l
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "getLastKnownLocation($p) failed: ${e.message}")
                }
            }
            if (best != null) {
                callback(Simple(best!!.latitude, best!!.longitude, best!!.accuracy, best!!.provider))
                return
            }
        } catch (e: Exception) {
            Log.w(TAG, "lastKnown failed: ${e.message}")
        }

        // Request single fresh update
        try {
            val criteria = Criteria().apply {
                accuracy = Criteria.ACCURACY_FINE
                isAltitudeRequired = false
                isBearingRequired = false
                isSpeedRequired = false
                powerRequirement = Criteria.POWER_MEDIUM
            }
            val provider = lm.getBestProvider(criteria, true) ?: LocationManager.NETWORK_PROVIDER
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { lm.removeUpdates(this) } catch (_: Exception) {}
                    callback(Simple(location.latitude, location.longitude, location.accuracy, location.provider))
                }

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {}

                override fun onProviderEnabled(p0: String) {}
                override fun onProviderDisabled(p0: String) {}
            }
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            // Fallback timeout in case no callback in time
            Handler(Looper.getMainLooper()).postDelayed({
                try { lm.removeUpdates(listener) } catch (_: Exception) {}
                callback(null)
            }, 10_000L)
        } catch (e: Exception) {
            Log.e(TAG, "requestSingleUpdate failed: ${e.message}")
            callback(null)
        }
    }
}
