package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver：仅作为入口，接收屏幕点亮/解锁广播，然后触发后台 UnlockWorker。
 * 具体业务逻辑（查库、开关与冷却时间判断、发送通知、日志回包）全部在 UnlockWorker 中完成。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    try {
      val act = intent?.action ?: "null"
      DbRepo.log(context, null, "【解锁后台】UnlockReceiver 收到系统广播 action=$act，改为触发后台 UnlockWorker 处理")
    } catch (_: Throwable) {}
    try {
      UnlockWorker.trigger(context.applicationContext)
    } catch (_: Throwable) {}
  }
}
