// Minimal, non-breaking helper for checking native takeover
import 'dart:async';
import 'package:flutter/services.dart';

class NativeGuard {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> isNativeWM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeWmEnabled');
      return ok == true;
    } catch (_) {
      return false; // 若通道不存在，默认 Dart 继续注册
    }
  }

  static Future<bool> isNativeAM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeAmEnabled');
      return ok == true;
    } catch (_) {
      return false;
    }
  }
}


import 'package:flutter/foundation.dart';

class RefreshBus {
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static const MethodChannel _refreshCh = MethodChannel('com.example.quote_app/refresh');
  static bool _inited = false;
  static void init() {
    if (_inited) return;
    _inited = true;
    _refreshCh.setMethodCallHandler((call) async {
      if (call.method == 'dbChanged') {
        tick.value = tick.value + 1;
      }
      return null;
    });
  }
  static void poke() { tick.value = tick.value + 1; }
}
