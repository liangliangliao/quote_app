import 'dart:io';
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

const _DB_NAME = 'quotes.db';





class AppDatabase {
  static Future<void> _copyDbFile(String from, String to) async {
    try {
      await Directory(p.dirname(to)).create(recursive: true);
      final src = File(from);
      if (await src.exists()) {
        await src.copy(to);
      }
    } catch (e, st) { rethrow; }
  }


  static Future<void> _mergeFromExternalDb(Database targetDb, String externalPath) async {
    Database? extDb;
    try {
      if (!await databaseExists(externalPath)) return;
      extDb = await openDatabase(externalPath, readOnly: true);
      // Copy rows from each known table using INSERT OR IGNORE to avoid duplicates.
      Future<void> copyTable(String table) async {
        final rows = await extDb!.query(table);
        for (final row in rows) {
          try {
            await targetDb.insert(table, row, conflictAlgorithm: ConflictAlgorithm.ignore);
          } catch (_) {
            // Best-effort merge; ignore rows that don't match current schema.
           rethrow;}
        }
      }
      // Merge known tables. If a table doesn't exist in the external DB, just skip.
      for (final t in const ['tasks','quotes','logs','config','payloads']) {
        try { await copyTable(t); } catch (e, st) { rethrow; }
      }
    } catch (_) {
      // Swallow errors: merging is opportunistic, not fatal.
     rethrow;} finally {
      try { await extDb?.close(); } catch (e, st) { rethrow; }
    }
  }

  static Database? _db;

  static Future<Database> instance() async {
    // Fast path: already opened
    if (_db != null) {
      // Ensure newly added columns exist (idempotent)
      try {
        final info = await _db!.rawQuery("PRAGMA table_info(tasks)");
        bool has(String name) => info.any((row) => row["name"]?.toString() == name);
        if (!has("task_uid")) {
          await _db!.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
          await _db!.execute("UPDATE tasks SET task_uid = uid WHERE task_uid IS NULL OR task_uid=''");
        }
        if (!has("trigger_at")) {
          await _db!.execute("ALTER TABLE tasks ADD COLUMN trigger_at INTEGER");
          await _db!.execute("UPDATE tasks SET trigger_at = COALESCE(next_time, strftime('%s','now')*1000)");
        }
        if (!has("freq_type"))            await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT");
        if (!has("freq_weekday"))         await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
        if (!has("freq_day_of_month"))    await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
        if (!has("freq_custom"))          await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT");
      } catch (_) {}
      return _db!;
    }

    // Paths
    final dbDir = await getDatabasesPath();
    final legacyPath = p.join(dbDir, _DB_NAME); // 旧库路径
    final docDir = await getApplicationDocumentsDirectory();
    final newPath = p.join(docDir.path, _DB_NAME); // 可能存在的新库

    if (await databaseExists(legacyPath)) {
      _db = await openDatabase(
        legacyPath, version: 6,
        onCreate: (db, v) async => _migrate(db),
        onUpgrade: (db, ov, nv) async => _migrate(db),
      );
      if (await databaseExists(newPath)) {
        try { await _mergeFromExternalDb(_db!, newPath); } catch (_) {}
      }
    } else if (await databaseExists(newPath)) {
      // 只存在新库
      _db = await openDatabase(
        newPath, version: 6,
        onCreate: (db, v) async => _migrate(db),
        onUpgrade: (db, ov, nv) async => _migrate(db),
      );
    } else {
      // 两处都不存在 —— 新安装：在私有数据库目录创建
      _db = await openDatabase(
        legacyPath, version: 6,
        onCreate: (db, v) async => _migrate(db),
        onUpgrade: (db, ov, nv) async => _migrate(db),
      );
    }

    // Ensure compatibility columns once after opening
    try {
      final info = await _db!.rawQuery("PRAGMA table_info(tasks)");
      bool has(String name) => info.any((row) => row["name"]?.toString() == name);
      if (!has("task_uid")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
        await _db!.execute("UPDATE tasks SET task_uid = uid WHERE task_uid IS NULL OR task_uid=''");
      }
      if (!has("trigger_at")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN trigger_at INTEGER");
        await _db!.execute("UPDATE tasks SET trigger_at = COALESCE(next_time, strftime('%s','now')*1000)");
      }
      if (!has("freq_type"))            await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT");
      if (!has("freq_weekday"))         await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
      if (!has("freq_day_of_month"))    await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
      if (!has("freq_custom"))          await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT");
    } catch (_) {}

    return _db!;
  }
}

Future<void> ensureExtraTaskColumns() async {
  final db = await AppDatabase.instance();
  try {
    final info = await db.rawQuery("PRAGMA table_info(tasks)");
    bool has(String name) => info.any((row) => row["name"]?.toString() == name);
    Future<void> add(String sql) async { try { await db.execute(sql); } catch (_) {} }
    if (!has("start_time"))          await add("ALTER TABLE tasks ADD COLUMN start_time TEXT");
    if (!has("next_time"))           await add("ALTER TABLE tasks ADD COLUMN next_time INTEGER");
    if (!has("scheduled_run_key"))   await add("ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
    if (!has("prompt"))              await add("ALTER TABLE tasks ADD COLUMN prompt TEXT");
    if (!has("avatar_path"))         await add("ALTER TABLE tasks ADD COLUMN avatar_path TEXT");
    if (!has("type"))                await add("ALTER TABLE tasks ADD COLUMN type TEXT");
    if (!has("status"))              await add("ALTER TABLE tasks ADD COLUMN status TEXT");
    if (!has("task_uid"))            await add("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
    if (!has("trigger_at"))          await add("ALTER TABLE tasks ADD COLUMN trigger_at INTEGER");
    if (!has("freq_type"))           await add("ALTER TABLE tasks ADD COLUMN freq_type TEXT");
    if (!has("freq_weekday"))        await add("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
    if (!has("freq_day_of_month"))   await add("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
    if (!has("freq_custom"))         await add("ALTER TABLE tasks ADD COLUMN freq_custom TEXT");
  } catch (_) {}
}

