
package com.example.quote_app

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.widget.RemoteViews
import kotlin.math.ceil
import kotlin.math.min

/**
 * Build a custom RemoteViews for notifications that renders the first few lines of body
 * as a bitmap (for crisp, styled text) and the rest as a TextView below.
 *
 * This follows the layout and behavior of the user's provided reference.
 */
object NotifSystemHeader512_CustomBody {
    private fun dp(ctx: Context, v: Float) = v * ctx.resources.displayMetrics.density
    private fun sp(ctx: Context, v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, ctx.resources.displayMetrics)

    private fun bodyPaint(ctx: Context): TextPaint {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        p.textSize = sp(ctx, 18f)
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.letterSpacing = 0.03f
        return p
    }

    private fun renderTopBitmap(ctx: Context, text: String, widthPx: Int, maxLines: Int): Bitmap {
        val paint = bodyPaint(ctx)
        val sl = StaticLayout.Builder.obtain(text, 0, text.length, paint, widthPx)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.4f)
            .setMaxLines(maxLines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .build()
        val h = ceil(sl.height.toDouble()).toInt()
        val bmp = Bitmap.createBitmap(widthPx, max(1, h), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        // Slight background to improve readability on system surfaces
        val bg = Paint().apply { color = 0x22000000 }
        c.drawRect(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat(), bg)
        c.save()
        c.translate(0f, 0f)
        sl.draw(c)
        c.restore()
        return bmp
    }

    fun build(ctx: Context, layoutRes: Int, body: String, topLines: Int = 3, totalMaxLines: Int = 7): RemoteViews {
        val safeBody = body.trim()
        val fullWidth = (min(512f, 512f) * ctx.resources.displayMetrics.density / 1.5f).toInt()
        val rv = RemoteViews(ctx.packageName, layoutRes)

        if (safeBody.isEmpty()) {
            rv.setImageViewBitmap(R.id.body_top_bitmap, Bitmap.createBitmap(1,1, Bitmap.Config.ARGB_8888))
            rv.setTextViewText(R.id.body_bottom, "")
            return rv
        }

        // Split body into two sections
        val paint = bodyPaint(ctx)
        val sl = StaticLayout.Builder.obtain(safeBody, 0, safeBody.length, paint, fullWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.4f)
            .build()
        val totalLines = sl.lineCount
        val cutLine = min(topLines, totalLines - 1).coerceAtLeast(0)

        var cutIndex = safeBody.length
        if (totalLines > topLines) {
            cutIndex = sl.getLineStart(cutLine + 1)
        }
        val topText = safeBody.substring(0, cutIndex).trimEnd()
        val bottomText = if (totalLines > topLines) safeBody.substring(cutIndex).trimStart() else ""

        val bmp = renderTopBitmap(ctx, topText, fullWidth, topLines)
        rv.setImageViewBitmap(R.id.body_top_bitmap, bmp)
        rv.setTextViewText(R.id.body_bottom, bottomText)
        rv.setInt(R.id.body_bottom, "setMaxLines", (totalMaxLines - topLines).coerceAtLeast(0))

        return rv
    }
}
