
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Renders an HTML asset in a WebView and injects dynamic data.
/// Key fix: convert local app-internal file paths (e.g. /data/user/0/.../app_flutter/avatar_xxx.jpg)
/// into base64 data URLs so the WebView can display the avatar image reliably.
class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); },
        ),
      )
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  Future<String> _normalizeAvatar(dynamic raw) async {
    final v = (raw ?? '').toString().trim();
    if (v.isEmpty) return '';
    if (v.startsWith('http://') || v.startsWith('https://') || v.startsWith('data:image')) return v;

    // content:// URI can be passed to WebView directly only if served by a content loader;
    // to be robust, convert to data URL as well.
    if (v.startsWith('content://') || v.startsWith('file://') || v.startsWith('/')) {
      try {
        final String path = v.startsWith('file://') ? Uri.parse(v).toFilePath() : v;
        final file = File(path);
        if (await file.exists()) {
          final bytes = await file.readAsBytes();
          final b64 = base64Encode(bytes);
          final ext = p.extension(file.path).toLowerCase();
          final mime = (ext == '.png')
              ? 'image/png'
              : (ext == '.webp')
                  ? 'image/webp'
                  : 'image/jpeg';
          return 'data:$mime;base64,$b64';
        }
      } catch (_) {}
      // Fallback to file URI if conversion fails.
      try { return Uri.file(v).toString(); } catch (_) { return v; }
    }

    // Treat as a relative image name under assets/html/img/avatars
    return 'img/avatars/$v';
  }

  Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
    if (d == null || d.isEmpty) return;

    final avatarUrl = await _normalizeAvatar(
      d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
    );

    final payload = jsonEncode({
      'topic': (d['topic'] ?? d['topic_text'] ?? d['theme'] ?? ''),
      'quote': (d['content'] ?? d['quote'] ?? d['quote_text'] ?? ''),
      'author': (() {
        final a = (d['author'] ?? d['author_name'] ?? d['signature'] ?? d['署名']);
        final s = (d['source'] ?? d['source_from'] ?? d['出处']);
        if (a != null && a.toString().isNotEmpty) {
          return '---' + a.toString() + (s != null && s.toString().isNotEmpty ? '《' + s.toString() + '》' : '');
        }
        return (d['authorText'] ?? d['author_text'] ?? '');
      })(),
      'note': (d['explain'] ?? d['explanation'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? ''),
      'avatarUrl': avatarUrl,
      if (d.containsKey('focalX')) 'focalX': d['focalX'],
      if (d.containsKey('focalY')) 'focalY': d['focalY'],
    });

    try {
      await _controller.runJavaScriptReturningResult('window.setDynamicData && window.setDynamicData($payload)');
    } catch (_) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
