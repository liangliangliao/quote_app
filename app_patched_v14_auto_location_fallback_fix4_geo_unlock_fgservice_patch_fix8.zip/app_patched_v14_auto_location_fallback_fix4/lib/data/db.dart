import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// 轻量的数据库封装：只负责打开数据库并确保关键表存在。
class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 13,
      onCreate: (db, v) async {
        await _createTables(db);
      },
      onUpgrade: (db, from, to) async {
        await _createTables(db);
      },
    );
    return _db!;
  }

  static Future<void> _createTables(Database db) async {
    // 日志表
    await db.execute('''CREATE TABLE IF NOT EXISTS logs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at INTEGER,
      task_uid TEXT,
      detail TEXT
    )''');

    // 配置表（包含地点规则总开关、百度AK等）
    await db.execute('''CREATE TABLE IF NOT EXISTS configs(
      id INTEGER PRIMARY KEY CHECK (id=1),
      location_rules_enabled INTEGER DEFAULT 0,
      baidu_ak TEXT
    )''');

    // 情景触发（含地点规则等，自由 JSON）
    await db.execute('''CREATE TABLE IF NOT EXISTS vision_triggers(
      id TEXT PRIMARY KEY,
      type TEXT,
      enabled INTEGER DEFAULT 1,
      config TEXT,
      updated_at INTEGER
    )''');

    // 其他页面可能依赖的最小表：反思、会话（避免运行期查询失败）
    await db.execute('''CREATE TABLE IF NOT EXISTS vision_reflections(
      id TEXT PRIMARY KEY,
      date TEXT,
      presence INTEGER,
      mood TEXT,
      note TEXT
    )''');

    await db.execute('''CREATE TABLE IF NOT EXISTS vision_sessions(
      id TEXT PRIMARY KEY,
      start_ts INTEGER,
      end_ts INTEGER,
      focus_minutes INTEGER
    )''');

    // 确保有一行 configs（id=1）
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'id': 1, 'location_rules_enabled': 0, 'baidu_ak': null});
    }
  }
}
