import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import '../platform/native_scheduler.dart';
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import 'package:sqflite/sqflite.dart';

import '../utils/debug_logger.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import 'dart:async';
import '../platform/perm_helper.dart';

import '../utils/run_context.dart';
import 'run_guard.dart';
// === Scheduler constants ===
const Duration kExactGrace = Duration(minutes: 2); // 精准闹钟允许的过期容忍窗口
const Duration kFallbackDelay = Duration(minutes: 2); // WM兜底延迟


// ====== 日志辅助：统一中文上下文 ======
// ====== 日志辅助：统一中文上下文 ======
String _fmt(DateTime dt) => dt.toLocal().toString().split('.').first;
Future<void> _logEnter(String stage, {String? uid, String? title, DateTime? when, String extra = ''}) async {
  final ts = when != null ? _fmt(when) : '';
  final name = (title ?? '');
  final idPart = uid != null ? '(id='+uid+')' : '';
  final whenPart = ts.isNotEmpty ? (' @'+ts) : '';
  final base = '【进入】' + stage + (name.isNotEmpty?(' '+name):'') + idPart + whenPart + (extra.isNotEmpty?(' '+extra):'');
  await DLog.i('SCH', base);
  await LogDao().add(taskUid: uid ?? '', detail: base);
}
class SchedulerService
{
  static final Set<String> _schedulingInFlight = <String>{};
  // —— 单任务“仅保留下一次触发”的固定 ID ——
  static int _nextAlarmId(String uid, String runKey) => (uid.hashCode ^ (runKey.hashCode<<1)) & 0x7fffffff;


  static int _fallbackAlarmId(String uid, String runKey) => (uid.hashCode ^ 0x5F3759DF ^ (runKey.hashCode<<1)) & 0x7fffffff;

  static Future<void> cancelNextForTask(String uid, {String? runKey, bool includeFallback = true}) async {
    await _logEnter('取消环节', uid: uid);
    await DLog.i('SCH','开始取消先前计划：uid='+uid+(runKey!=null?(' run='+runKey!):''));
    // 若未传 runKey，推断当前下一次，并以其 runKey 精确取消
    if (runKey == null) {
      final db = await AppDatabase.instance();
      final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
      if (rows.isNotEmpty) {
        final next = _computeNext(rows.first);
        if (next != null) { runKey = _runKeyForPlanned(next); }
      }
    }
    try {
      await AndroidAlarmManager.cancel(_nextAlarmId(uid, runKey ?? ''));
      await DLog.i('SCH','已取消AM精确闹钟 id='+_nextAlarmId(uid, (runKey ?? '')).toString());
    } catch (e) { await DLog.w('SCH','取消AM精确闹钟异常 uid='+uid+' err='+e.toString()); }
    try {
      await Workmanager().cancelByUniqueName('wm_run_'+uid+'_'+(runKey ?? ''));
      await DLog.i('SCH','WM一次性取消提交完成 name='+'wm_run_'+uid+'_'+(runKey ?? ''));
    } catch (e) { await DLog.w('SCH','取消WM一次性异常 uid='+uid+' err='+e.toString()); }
    if (includeFallback) {
      try {
        await Workmanager().cancelByUniqueName('fb_next_'+uid+'_'+(runKey ?? ''));
        await DLog.i('SCH','WM兜底取消提交完成 name='+'fb_next_'+uid+'_'+(runKey ?? ''));
      } catch (e) { await DLog.w('SCH','取消WM兜底异常 uid='+uid+' err='+e.toString()); }
    }
    // 兼容旧命名（老版本可能还残留）
    try { await Workmanager().cancelByUniqueName('next_'+uid); } catch (_) {}
    try { await Workmanager().cancelByUniqueName('fb_next_'+uid); } catch (_) {}
    await DLog.i('SCH','已尝试取消完成 uid='+uid);
  }
/// 初始化调度：初始化 WorkManager，并在无精确闹钟权限时注册 15 分钟兜底任务。
  static Future<void> init() async {
    await DLog.i('SCH', 'init start');
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'hasExact(now)=$hasExact');
    if (!hasExact) { // no exact alarm permission: keep periodic fallback alive
      // (policy) do not open system settings here per product requirement
      await Workmanager().registerPeriodicTask(
          'due_check_periodic',
          'due_check_periodic',
          frequency: const Duration(minutes: 15),
          initialDelay: const Duration(minutes: 15),
          existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
        );
        await DLog.i('SCH', 'registered fallback periodic task');
        
    }
  }

  /// 扫描任务并为每个任务安排下一次触发（有精确闹钟权限时使用 AndroidAlarmManager）。
  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'hasExact(now)=$hasExact');
    final tasks = await TaskDao().all();
    final Map<String, DateTime> _nextChosen = {};

    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;
      final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) continue;

      final next = _computeNext(t);
      if (next == null) continue;
      // 去重：同一 uid 只保留最早 future 触发 
      if (_nextChosen.containsKey(uid)) {
        if (next.isBefore(_nextChosen[uid]!)) {
          _nextChosen[uid] = next;
        }
        continue;
      }
      else {
        _nextChosen[uid] = next;
      }

      final diffSecs = next.difference(DateTime.now()).inSeconds;
      if (diffSecs.abs() <= 5) {
        await DLog.i('SCH', 'instant fire $uid');
        await _sendForTask(t, runKey: _runKeyForPlanned(next), source: 'INSTANT');
        await LogDao().add(taskUid: uid, detail: '即时触发：${_fmt(DateTime.now())}');
        continue;
      }

      // 把“下一次”写回任务（保持你原有约定）
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [uid]);
        

      // 精确权限：优先走 AM，否则 WM
      if (await PermHelper.hasExactAlarmPermission()) {
        final runKey = _runKeyForPlanned(next);
        // 若已略过但在 2 分钟容忍窗口内，直接用 WM 立即执行；否则注册 AM
        if (next.isBefore(DateTime.now()) && DateTime.now().difference(next) <= kExactGrace) {
          await _scheduleWmOneOff('wm_run_'+uid+'_'+runKey, {'job':'wm_run','task_uid': uid, 'run_key': runKey}, Duration.zero);
          await DLog.w('SCH','已过期≤2分钟，用WM立即执行 uid='+uid+' runKey='+runKey);
        } else {
          final okNative = await NativeScheduler.scheduleExactAt(
            id: _nextAlarmId(uid, runKey),
            epochMs: next.millisecondsSinceEpoch,
            payload: {'uid': uid, 'runKey': runKey, 'title': '提醒', 'body': '到点了'},
          );
          await DLog.i('SCH', 'AM(Native)注册提交完成 uid='+uid+' ok='+okNative.toString());
          }
      } else {
        // 无精确权限：直接 WM one-off
        final runKey = _runKeyForPlanned(next);
        final uniq = 'wm_run_'+uid+'_'+runKey;
        await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, next.difference(DateTime.now()));
        await DLog.i('SCH', '已注册WM oneOff uid='+uid+' run='+runKey);
        // fallback via NativeScheduler handled natively; no extra WM fallback  // WM 基准 + 2 分钟兜底
      }
      }
    }

  /// 只为指定任务安排下一次触发；不影响其他任务。
  static Future<void> scheduleNextForTask(String uid) async {
    if (_schedulingInFlight.contains(uid)) { await DLog.w('SCH','忽略重复注册(进行中) uid='+uid); return; }
    _schedulingInFlight.add(uid);
    try {
    final db = await AppDatabase.instance();
    final trows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    if (trows.isEmpty) return;
    final t = trows.first;

    final status = (t['status'] ?? 'on').toString();
    if (status != 'on' && status != 'active') {
      await cancelNextForTask(uid);
      return;
    }

    final next = _computeNext(t);
    if (next == null) {
      await cancelNextForTask(uid);
      return;
    }

    // 即时窗口（±5 秒）直接发送
    final diffSecs = next.difference(DateTime.now()).inSeconds;
    if (diffSecs.abs() <= 5) {
      await _sendForTask(t, runKey: _runKeyForPlanned(next), source: 'INSTANT');
      await LogDao().add(taskUid: uid, detail: '即时触发：${_fmt(DateTime.now())}');
      return;
    }

    // 把“下一次”写回任务
    await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [uid]);

    // 精确权限优先走 AM，否则走 WM one‑off
      // 精确权限：优先走 AM，否则 WM
      if (await PermHelper.hasExactAlarmPermission()) {
        final runKey = _runKeyForPlanned(next);
        // 若已略过但在 2 分钟容忍窗口内，直接用 WM 立即执行；否则注册 AM
        if (next.isBefore(DateTime.now()) && DateTime.now().difference(next) <= kExactGrace) {
          await _scheduleWmOneOff('wm_run_'+uid+'_'+runKey, {'job':'wm_run','task_uid': uid, 'run_key': runKey}, Duration.zero);
          await DLog.w('SCH','已过期≤2分钟，用WM立即执行 uid='+uid+' runKey='+runKey);
        } else {
          final okNative = await NativeScheduler.scheduleExactAt(
            id: _nextAlarmId(uid, runKey),
            epochMs: next.millisecondsSinceEpoch,
            payload: {'uid': uid, 'runKey': runKey, 'title': '提醒', 'body': '到点了'},
          );
          await DLog.i('SCH', 'AM(Native)注册提交完成 uid='+uid+' ok='+okNative.toString());
          }
      } else {
        // 无精确权限：直接 WM one-off
        final runKey = _runKeyForPlanned(next);
        final uniq = 'wm_run_'+uid+'_'+runKey;
        await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, next.difference(DateTime.now()));
        await DLog.i('SCH', '已注册WM oneOff uid='+uid+' run='+runKey);
        // fallback via NativeScheduler handled natively; no extra WM fallback  // WM 基准 + 2 分钟兜底
      }
    } finally { _schedulingInFlight.remove(uid); }
  }



  /// 被闹钟或兜底调用：检查到期任务并发送通知。
  
  // 统一回调处理：AM/WM 共用的发送与续排、兜底取消、幂等控制

  // === AM/WM 统一回调扫描入口 ===
  static Future<void> callback() async {
    await _logEnter('回调环节');
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final tasks = await TaskDao().all();

    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;

      final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) continue;

      final st = (t['start_time'] ?? '').toString();
      await DLog.i('CP', '当天补发检查 task $uid st=$st');
      if (st.isEmpty) continue;

      final planned = _parseTimeOrToday(st);
      if (planned == null) continue;

      // 只在“计划时间已到或已过”的时候触发一次
      final delta = now.difference(planned).inSeconds;
      await DLog.i('CB', 'check task $uid st=$st delta=$delta');
      // 触发窗口：提前 10 秒 ~ 延迟 5 分钟
      if (delta >= -10 && delta <= 300) {
        // recent duplicate guard (5 min)
        final fiveMinAgo = now.subtract(const Duration(minutes: 5)).millisecondsSinceEpoch;
        final recent = await db.query('logs',
          where: 'task_uid=? AND detail LIKE ? AND created_at > ?',
          whereArgs: [uid, '触发:%', fiveMinAgo], limit: 1);
        if (recent.isNotEmpty) { await DLog.i('CB', 'skip recent uid=$uid'); continue; }
        try {
          final _rk = _runKeyForPlanned(planned);
          await _handleCallback(uid, _rk, source: (RunContext.isFromWM ? 'WM' : 'AM'));
        } catch (e) {
          await DLog.w('SCH', '异常（AM/WM回调内部），仅记录 uid='+uid+' err='+e.toString());
        }
    }
        await LogDao().add(taskUid: uid, detail: '触发：${_fmt(now)}');
      }
      else {
        await DLog.i('CB', '跳过：超出容忍窗口，uid=$uid delta=$delta');
      }
    
  // === 唯一运行键，分到分钟 ===
  }
  static String _runKeyForPlanned(DateTime planned) {
    return DateFormat('yyyyMMdd_HHmm').format(planned.toLocal());
  }

  // === 发送通知（内部）===
  static Future<void> _sendForTask(Map<String, dynamic> t, {String? runKey, DateTime? planned, String? source}) async {
    final uid = (t['task_uid'] ?? '').toString();
    final rk = runKey ?? (planned != null ? DateFormat('yyyyMMdd_HHmm').format(planned.toLocal()) : '');
    final src = source ?? 'AM';
    // 初始化通知环境（后台安全）
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    try {
      await NotificationService.show(t);
      await DLog.i('NOTI','已发 uid='+uid+' run='+rk+' src='+src);
      await LogDao().add(taskUid: uid, detail: '通知已发送（来源='+src+'） run='+rk);
    } catch (e) {
      await DLog.w('NOTI','发送失败 uid='+uid+' run='+rk+' err='+e.toString());
      await LogDao().add(taskUid: uid, detail: '通知发送失败 run='+rk+' err='+e.toString());
      rethrow;
    }
  }

  // === WM 兜底（定时/立即）===
  static Future<void> _scheduleWmFallbackAt(String uid, String runKey, DateTime due) async {
    final now = DateTime.now();
    final delay = (due.isAfter(now) ? due.difference(now) : Duration.zero) + const Duration(minutes: 2);
    await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid': uid, 'run_key': runKey}, delay);
  }
  static Future<void> _triggerWmFallbackNow(String uid, String runKey) async {
    await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid': uid, 'run_key': runKey}, Duration.zero);
    await DLog.w('SCH','闹钟回调失败，立即触发兜底WM：fb_next_'+uid);
  }

  // === 取消指定 runKey 的 WM 兜底 ===
  static Future<void> cancelWmFallbackForRun(String uid, String runKey) async {
    try {
      await Workmanager().cancelByUniqueName('fb_next_'+uid+'_'+runKey);
      await DLog.i('SCH','WM兜底取消提交完成 name=fb_next_'+uid+'_'+runKey);
    } catch (e) {
      await DLog.w('SCH','取消WM兜底异常 uid='+uid+' run='+runKey+' err='+e.toString());
    }
  }

  // === 取消任务（AM/WM/本地 pending_run）===
  static Future<void> cancelForTask(String uid) async {
    try { await AndroidAlarmManager.cancel(0); } catch (_) {} // 若有按 runKey 的 id，请在调用处传入精确 id
    try { await Workmanager().cancelByUniqueName('wm_run_'+uid+'_'); } catch (_) {}
    try { await Workmanager().cancelByUniqueName('fb_next_'+uid+'_'); } catch (_) {}
    try {
      final db = await AppDatabase.instance();
      await db.delete('pending_run', where: 'task_uid=?', whereArgs: [uid]);
    } catch (_) {}
    await DLog.i('SCH','已取消任务相关闹钟和WorkManager uid='+uid);
  }

  // === 统一回调处理（AM/WM 共用）===
  static Future<void> _handleCallback(String uid, String runKey, {required String source}) async {
    await DLog.i('SCH', '正常，已经进入回调环节啦！ src='+source+' uid='+uid+' run='+runKey);
    bool proceed = true;
    try {
      if (await RunGuard.begin(uid, runKey, source: source) == false) {
        await DLog.w('SCH', "[RunGuard] dup run suppressed uid="+uid+" run="+runKey+" src="+source);
        proceed = false;
      }
    } catch (_) {}
    if (!proceed) return;

    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
      if (rows.isEmpty) return;
      final t = rows.first;
      await _sendForTask(t, runKey: runKey, source: source);

      // 成功后：取消本次兜底 + 注册下一次
      try { await SchedulerService.cancelWmFallbackForRun(uid, runKey); } catch (_) {}
      await SchedulerService.scheduleNextForTask(uid);
      await DLog.i('SCH', '回调完成，已续排下一次 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.w('SCH', '异常，进入回调兜底环节！ uid='+uid+' run='+runKey+' err='+e.toString());
      try { await _triggerWmFallbackNow(uid, runKey); } catch (_) {}
    } finally {
      try { await RunGuard.end(uid, runKey, source: source); } catch (_) {}
    }
  }

  // === WM 回调入口 ===
  static Future<void> wmRunTask(String taskUid, String runKey) async {
    await _handleCallback(taskUid, runKey, source: 'WM');
  }

  // === 当天漏发补发（对外入口）===
  static Future<void> catchupIfMissed() async { await _catchupIfMissed(); }
}

DateTime? _computeNext(Map<String, dynamic> t) {
    final now = DateTime.now();
    final start = (t['start_time'] ?? '').toString().trim();
    if (start.isEmpty) return null;

    // 解析“时:分”
    int hh = 9, mm = 0;
    final reHm = RegExp(r'^\d{2}:\d{2}$');
    final reAbs = RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$');
    DateTime? absDt;
    if (reHm.hasMatch(start)) {
      hh = int.parse(start.substring(0,2));
      mm = int.parse(start.substring(3,5));
    } else if (reAbs.hasMatch(start)) {
      final yyyy = int.parse(start.substring(0,4));
        final MMm  = int.parse(start.substring(5,7));
        final dd   = int.parse(start.substring(8,10));
        hh = int.parse(start.substring(11,13));
        mm = int.parse(start.substring(14,16));
        absDt = DateTime(yyyy, MMm, dd, hh, mm);
        
    } else {
      // 尝试从任意字符串中提取 “HH:mm”
      final m2 = RegExp(r'(\d{2}):(\d{2})').firstMatch(start);
      if (m2 != null) {
        hh = int.parse(m2.group(1)!);
          mm = int.parse(m2.group(2)!);
          
      }
    }

    // 读取频率（新字段优先，兼容旧字段）
    final String freqType = (t['freq_type'] ?? t['freq'] ?? 'daily').toString();
    final int? weekDay = (t['freq_weekday'] ?? t['weekday']) as int?;
    final int? dayOfMonth = (t['freq_day_of_month'] ?? t['dayOfMonth']) as int?;

    // 如果 start 为绝对时间且在未来：直接使用它（作为“下一次”）
    if (absDt != null && absDt.isAfter(now)) {
      return absDt;
    }

    if (freqType == 'weekly' && weekDay != null) {
      final wd = weekDay;
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (cand.isBefore(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    }

    if (freqType == 'monthly' && dayOfMonth != null) {
      final d = dayOfMonth.clamp(1,31);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (cand.isBefore(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    }

    // 默认：每天
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    if (!today.isBefore(now)) return today;
    return today.add(const Duration(days: 1));
  }DateTime? _parseTimeOrToday(String st) {
    final now = DateTime.now();
    if (RegExp(r'^\d{2}:\d{2}$').hasMatch(st)) {
        final hh = int.parse(st.substring(0,2));
        final mm = int.parse(st.substring(3,5));
        return DateTime(now.year, now.month, now.day, hh, mm);
      } else if (RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$').hasMatch(st)) {
        final yyyy = int.parse(st.substring(0,4));
        final mm = int.parse(st.substring(5,7));
        final dd = int.parse(st.substring(8,10));
        final HH = int.parse(st.substring(11,13));
        final MM = int.parse(st.substring(14,16));
        return DateTime(yyyy, mm, dd, HH, MM);
      }
      
    return null;
  }
@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  // 标记后台环境（供日志前缀使用）
  RunContext.isBackground = true; 
  RunContext.isFromWM = false; 

  await DLog.i('ALARM', 'alarm hit');
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();
  await NotificationService.init();
  await AppDatabase.instance();
  await SchedulerService.callback();
  await SchedulerService.catchupIfMissed();
  
  // removed: per‑task reschedule now handled in callback()
}
Future<void> _catchupIfMissed() async {
  final db = await AppDatabase.instance();
    final now = DateTime.now();
    final dayStart = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final dayEnd = DateTime(now.year, now.month, now.day, 23, 59, 59, 999).millisecondsSinceEpoch;
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;
      final uid = (t['task_uid'] ?? '').toString();
            if (uid.isEmpty) continue;
      final st = (t['start_time'] ?? '').toString();
      await DLog.i('CP', '当天补发检查 task $uid st=$st');
      if (st.isEmpty) continue;
      final planned = _parseTimeOrToday(st);
      if (planned == null) continue;
      if (planned.isAfter(now)) continue;

      final sent = await db.query('logs',
          where: 'task_uid=? AND created_at BETWEEN ? AND ?',
          whereArgs: [uid, dayStart, dayEnd],
          limit: 1);
      if (sent.isNotEmpty) continue;

      await SchedulerService._sendForTask(t, runKey: SchedulerService._runKeyForPlanned(planned));
      await LogDao().add(taskUid: uid, detail: '补发：${_fmt(now)}');
    }
    
}Future<void> _scheduleWmOneOff(String uniqueName, Map<String, dynamic> input, Duration delay) async {
  try {
    await Workmanager().registerOneOffTask(
      uniqueName,
      'wm_task',
      initialDelay: delay,
      inputData: input,
      existingWorkPolicy: ExistingWorkPolicy.replace,
      tag: input['job']?.toString(),
    );
    await DLog.i('WM','registerOneOffTask unique='+uniqueName+' delay='+delay.inSeconds.toString()+'s');
  } catch (e) {
    await DLog.e('WM','registerOneOffTask error: '+e.toString());
    rethrow;
  }
}