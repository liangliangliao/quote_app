package com.example.quote_app

object Channels {
    // System/utility bridge to native
    const val SYS = "com.example.quote_app/sys"
    // Exact alarm capability checks etc.
    const val SCHED = "native.scheduler"
}
