import 'dart:math';
import 'package:sqflite/sqflite.dart';

import 'db.dart';

/// 单个情绪表情定义
class EmojiItem {
  final String char;
  final String name;
  final List<String> tags;
  const EmojiItem({
    required this.char,
    required this.name,
    required this.tags,
  });
}

/// 18 个情绪表情条目
final List<EmojiItem> unicornEmotions = [
  EmojiItem(
    char: "😄",
    name: "开心",
    tags: ["开心", "高兴", "快乐", "喜悦"],
  ),
  EmojiItem(
    char: "😣",
    name: "痛苦",
    tags: ["痛苦", "折磨", "难熬"],
  ),
  EmojiItem(
    char: "😩",
    name: "累",
    tags: ["疲惫", "累", "困", "疲劳"],
  ),
  EmojiItem(
    char: "😕",
    name: "迷茫",
    tags: ["迷茫", "困惑", "疑惑", "懵"],
  ),
  EmojiItem(
    char: "😎",
    name: "自信",
    tags: ["自信", "酷", "稳", "从容"],
  ),
  EmojiItem(
    char: "😔",
    name: "自卑",
    tags: ["自卑", "沮丧", "低落"],
  ),
  EmojiItem(
    char: "😰",
    name: "焦虑",
    tags: ["焦虑", "紧张", "担心", "不安"],
  ),
  EmojiItem(
    char: "😢",
    name: "难过",
    tags: ["难过", "伤心", "悲伤", "委屈"],
  ),
  EmojiItem(
    char: "😡",
    name: "愤怒",
    tags: ["愤怒", "生气", "怒火", "暴躁"],
  ),
  EmojiItem(
    char: "😐",
    name: "一般",
    tags: ["一般", "平淡", "还好", "普通"],
  ),
  EmojiItem(
    char: "😒",
    name: "无聊",
    tags: ["无聊", "烦躁", "厌倦"],
  ),
  EmojiItem(
    char: "❤️",
    name: "爱",
    tags: ["爱", "喜欢", "热爱", "心动"],
  ),
  EmojiItem(
    char: "💢",
    name: "恨",
    tags: ["恨", "憎恨", "怨", "怒"],
  ),
  EmojiItem(
    char: "😲",
    name: "惊讶",
    tags: ["惊讶", "吃惊", "震惊", "意外"],
  ),
  EmojiItem(
    char: "🤢",
    name: "厌恶",
    tags: ["厌恶", "恶心", "反感"],
  ),
  EmojiItem(
    char: "🤔",
    name: "好奇",
    tags: ["好奇", "思考", "疑问", "想法"],
  ),
  EmojiItem(
    char: "😳",
    name: "羞愧",
    tags: ["羞愧", "脸红", "害羞", "尴尬"],
  ),
  EmojiItem(
    char: "😱",
    name: "恐惧",
    tags: ["恐惧", "害怕", "惊恐", "恐慌"],
  ),

  // ===== 新增情绪 =====

  EmojiItem(
    char: "🤩",
    name: "钦佩",
    tags: ["钦佩", "佩服", "敬佩", "赞叹"],
  ),
  EmojiItem(
    char: "🙇‍♂️",
    name: "崇拜",
    tags: ["崇拜", "膜拜", "仰慕", "偶像"],
  ),
  EmojiItem(
    char: "🥰",
    name: "美学欣赏",
    tags: ["美学欣赏", "审美", "好看", "漂亮"],
  ),
  EmojiItem(
    char: "😂",
    name: "娱乐",
    tags: ["娱乐", "搞笑", "逗乐", "好玩"],
  ),
  EmojiItem(
    char: "😟",
    name: "焦虑感",
    tags: ["焦虑", "紧张", "担心", "不安"],
  ),
  EmojiItem(
    char: "🤯",
    name: "敬畏",
    tags: ["敬畏", "震撼", "肃然", "仰望"],
  ),
  EmojiItem(
    char: "😅",
    name: "尴尬",
    tags: ["尴尬", "不好意思", "窘迫", "社死"],
  ),
  EmojiItem(
    char: "🥱",
    name: "无聊感",
    tags: ["无聊", "犯困", "无趣", "打哈欠"],
  ),
  EmojiItem(
    char: "😑",
    name: "冷静",
    tags: ["冷静", "平静", "淡定", "镇定"],
  ),
  EmojiItem(
    char: "😕",
    name: "困惑",
    tags: ["困惑", "迷糊", "搞不懂", "问号"],
  ),
  EmojiItem(
    char: "😍",
    name: "渴望",
    tags: ["渴望", "想要", "盼望", "心动"],
  ),
  EmojiItem(
    char: "🤮",
    name: "强烈厌恶",
    tags: ["厌恶", "恶心", "反感", "想吐"],
  ),
  EmojiItem(
    char: "😢",
    name: "同情痛苦",
    tags: ["同情痛苦", "心疼", "可怜", "替他难过"],
  ),
  EmojiItem(
    char: "🤪",
    name: "狂喜忘我",
    tags: ["狂喜忘我", "嗨到飞起", "疯玩", "超开心"],
  ),
  EmojiItem(
    char: "🫤",
    name: "嫉妒",
    tags: ["嫉妒", "吃醋", "眼红", "羡慕"],
  ),
  EmojiItem(
    char: "😆",
    name: "兴奋",
    tags: ["兴奋", "激动", "嗨", "忍不住笑"],
  ),
  EmojiItem(
    char: "😨",
    name: "惶恐",
    tags: ["恐惧", "惶恐", "心慌", "打怵"],
  ),
  EmojiItem(
    char: "👻",
    name: "恐怖",
    tags: ["恐怖", "吓人", "惊悚", "灵异"],
  ),
  EmojiItem(
    char: "🙂",
    name: "兴致",
    tags: ["兴致", "有兴趣", "来劲", "想试试"],
  ),
  EmojiItem(
    char: "😁",
    name: "喜悦",
    tags: ["喜悦", "欢喜", "幸福", "高兴"],
  ),
  EmojiItem(
    char: "🥹",
    name: "怀旧",
    tags: ["怀旧", "怀念", "感慨", "回忆"],
  ),
  EmojiItem(
    char: "💕",
    name: "浪漫",
    tags: ["浪漫", "暧昧", "恋爱", "粉红泡泡"],
  ),
  EmojiItem(
    char: "😭",
    name: "悲伤",
    tags: ["悲伤", "心碎", "痛哭", "失落"],
  ),
  EmojiItem(
    char: "😌",
    name: "满足",
    tags: ["满足", "心满意足", "舒服", "惬意"],
  ),
  EmojiItem(
    char: "😘",
    name: "性欲",
    tags: ["性欲", "欲望", "色气", "荷尔蒙"],
  ),
  EmojiItem(
    char: "🤗",
    name: "同情",
    tags: ["同情", "安慰", "理解", "拥抱"],
  ),
  EmojiItem(
    char: "✌️",
    name: "胜利",
    tags: ["胜利", "成功", "赢了", "成就"],
  ),
];
String _two(int v) => v.toString().padLeft(2, '0');

String _nowString() {
  final now = DateTime.now();
  return "${now.year}-${_two(now.month)}-${_two(now.day)} "
         "${_two(now.hour)}:${_two(now.minute)}:${_two(now.second)}";
}

String _uid() {
  final rand = Random();
  final ts = DateTime.now().microsecondsSinceEpoch;
  final r = rand.nextInt(0xFFFFFF);
  return "emo_${ts.toRadixString(16)}_${r.toRadixString(16)}";
}

/// 情绪记录 DAO：负责 emotions 表的增删查
class EmotionDao {
  Future<int> insert({
    required String emojiChar,
    required String emojiName,
    required List<String> emojiTags,
    required String behavior,
    required String triggerEvent,
    required String thought,
  }) async {
    final db = await AppDatabase.instance();
    final tagsStr = emojiTags.join(',');
    final nowStr = _nowString();
    final uid = _uid();
    return db.insert('emotions', {
      'emotion_uid': uid,
      'emoji_char': emojiChar,
      'emoji_name': emojiName,
      'emoji_tags': tagsStr,
      'behavior': behavior,
      'trigger_event': triggerEvent,
      'thought': thought,
      'inserted_at': nowStr,
    });
  }

  /// 获取当天最近一条情绪记录（按 inserted_at 倒序）
  Future<Map<String, dynamic>?> latestToday() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final today = "${now.year}-${_two(now.month)}-${_two(now.day)}";
    final rows = await db.query(
      'emotions',
      where: "substr(inserted_at,1,10)=?",
      whereArgs: [today],
      orderBy: "inserted_at DESC",
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }

  /// 获取当天所有情绪记录，按时间先后顺序排列
  Future<List<Map<String, dynamic>>> listTodayOrdered() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final today = "${now.year}-${_two(now.month)}-${_two(now.day)}";
    final rows = await db.query(
      'emotions',
      where: "substr(inserted_at,1,10)=?",
      whereArgs: [today],
      orderBy: "inserted_at ASC",
    );
    return rows;
  }
}
