import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/services.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 13,
      onCreate: (db, v) async => _createTables(db),
      onUpgrade: (db, from, to) async => _createTables(db),
    );
    return _db!;
  }

  static Future<void> _createTables(Database db) async {
    // 统一日志表
    await db.execute('''CREATE TABLE IF NOT EXISTS logs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at INTEGER,
      task_uid TEXT,
      detail TEXT,
      task_name_snapshot TEXT,
      task_start_time_snapshot TEXT
    )''');

    // 运行时配置表（单行）
    await db.execute('''CREATE TABLE IF NOT EXISTS configs(
      id INTEGER PRIMARY KEY CHECK (id=1),
      name TEXT,
      api_key TEXT,
      model TEXT,
      endpoint TEXT,
      recent_hours INTEGER,
      overview_threshold INTEGER,
      auto_report_enabled INTEGER DEFAULT 0,
      ema_enabled INTEGER,
      esteem_scale INTEGER,
      sses_index INTEGER,
      start_time INTEGER,
      bg_image TEXT,
      location_rules_enabled INTEGER DEFAULT 0,
      baidu_ak TEXT
    )''');

    // 轻量的 notify_config（键值对）
    await db.execute('''CREATE TABLE IF NOT EXISTS notify_config(
      key TEXT PRIMARY KEY,
      value TEXT
    )''');

    // 情景触发表
    await db.execute('''CREATE TABLE IF NOT EXISTS vision_triggers(
      id TEXT PRIMARY KEY,
      type TEXT,
      enabled INTEGER DEFAULT 1,
      config TEXT,
      updated_at INTEGER
    )''');

    // 其他表（仅最小以避免运行期 NPE；保持兼容即可）
    await db.execute('''CREATE TABLE IF NOT EXISTS app_kv(
      key TEXT PRIMARY KEY,
      value TEXT
    )''');

    await db.execute("PRAGMA foreign_keys=ON");

    // 确保有一行 configs（id=1）
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {
        'id': 1,
        'model': 'gpt-5',
        'endpoint': 'https://api.openai.com/v1/responses',
        'recent_hours': 2,
        'overview_threshold': 500,
        'auto_report_enabled': 0,
        'location_rules_enabled': 0,
        'baidu_ak': null
      });
    }

    // 迁移：为可能缺失的列做补齐
    Future<void> ensureColumn(String table, String name, String type) async {
      final info = await db.rawQuery("PRAGMA table_info($table)");
      final cols = info.map((e) => e['name'] as String).toList();
      if (!cols.contains(name)) {
        await db.execute("ALTER TABLE $table ADD COLUMN $name $type");
      }
    }

    await ensureColumn('configs','bg_image','TEXT');
    await ensureColumn('configs','ema_enabled','INTEGER');
    await ensureColumn('configs','esteem_scale','INTEGER');
    await ensureColumn('configs','sses_index','INTEGER');
    await ensureColumn('configs','start_time','INTEGER');
    await ensureColumn('configs','location_rules_enabled','INTEGER');
    await ensureColumn('configs','baidu_ak','TEXT');
  }
}
