package com.example.quote_app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.Context
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ReminderForegroundService : Service() {

    private var worker: java.util.Timer? = null


    override fun onCreate() {
        super.onCreate()
        ensureServiceChannel()
        val notif = NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setContentTitle("提醒服务已运行")
            .setContentText("确保后台、锁屏、重启等场景稳定发送通知")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        try {
            // On Android 13+, this will fail if POST_NOTIFICATIONS wasn't granted.
            startForeground(SERVICE_NOTIF_ID, notif)
        } catch (e: Exception) {
            // Stop gracefully to avoid crashing the app process.
            stopSelf()
            return
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Start a periodic timer to scan due schedules saved by Dart
        if (worker == null) {
            worker = java.util.Timer("sched-poller", true).apply {
                scheduleAtFixedRate(object : java.util.TimerTask() {
                    override fun run() { checkDueAndNotify() }
                }, 5_000L, 30_000L)
            }
        }
        // Keep running; scheduling is handled by Dart or Alarm Receivers.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // If user removes the app from recents, keep service sticky
        startForeground(SERVICE_NOTIF_ID, NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setContentTitle("提醒服务持续运行")
            .setContentText("防止被系统回收导致提醒丢失")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .build())
        super.onTaskRemoved(rootIntent)
    }

    private fun ensureServiceChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(SERVICE_CHANNEL_ID, "提醒前台服务", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }

    private fun checkDueAndNotify() {
        try {
            val prefs = getSharedPreferences("sched_store", Context.MODE_PRIVATE)
            val json = prefs.getString("entries", "[]") ?: "[]"
            val arr = org.json.JSONArray(json)
            val now = System.currentTimeMillis()
            val keep = org.json.JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val whenMs = o.optLong("when", 0L)
                val id = o.optInt("id", 0)
                val title = o.optString("title", "到点提醒")
                val body = o.optString("body", "定时任务已到期")
                val fired = o.optBoolean("fired", false)
                if (!fired && whenMs > 0L && now >= whenMs) {
                    // fire notification
                    NotificationUtils.ensureDefaultChannel(this)
                    val n = NotificationCompat.Builder(this, NotificationUtils.DEFAULT_CHANNEL_ID)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .build()
                    val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(if (id != 0) id else (888000 + (now % 1000).toInt()), n)
                    // mark as fired (skip from keep)
                } else {
                    keep.put(o)
                }
            }
            if (keep.length() != arr.length()) {
                prefs.edit().putString("entries", keep.toString()).apply()
            }
        } catch (_: Exception) {}
    }

    companion object {
        const val SERVICE_CHANNEL_ID = "reminder_foreground_channel"
        const val SERVICE_NOTIF_ID = 424242
    }
}
