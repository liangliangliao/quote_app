import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  static const String chGeneralId = 'quote_general';
  static const String chGeneralName = '默认通知';
  static const String chGeneralDesc = '统一的应用通知通道';

  static Future<void> init() async {
    if (_inited) return;
    const InitializationSettings settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    );
    await _plugin.initialize(settings);

    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      try { await android?.requestNotificationsPermission(); } catch (_) {}
      const AndroidNotificationChannel channel = AndroidNotificationChannel(
        chGeneralId, chGeneralName,
        description: chGeneralDesc,
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
      );
      try { await android?.createNotificationChannel(channel); } catch (_) {}
    }
    _inited = true;
  }

  static Future<void> show(int id, String title, String body, {String? payload}) async {
    final NotificationDetails details = NotificationDetails(
      android: const AndroidNotificationDetails(
        chGeneralId, chGeneralName,
        channelDescription: chGeneralDesc,
        priority: Priority.high,
        importance: Importance.max,
        ticker: 'quote_ticker',
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );
    await _plugin.show(id, title, body, details, payload: payload);
  }
}
