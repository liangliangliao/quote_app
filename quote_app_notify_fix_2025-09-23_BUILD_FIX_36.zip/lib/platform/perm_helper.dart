import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> hasExactAlarmPermission({bool forBackground = false}) async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } catch (_) {}
  }

  static Future<void> ensureExactAlarmPermission() async {
    final ok = await hasExactAlarmPermission();
    if (!ok) {
      await requestExactAlarmPermission();
    }
  }

  static Future<bool> hasBatteryOptExemption() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestBatteryOptExemption() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {}
  }

  static Future<void> ensureBatteryOptExemption() async {
    final ok = await hasBatteryOptExemption();
    if (!ok) {
      await requestBatteryOptExemption();
    }
  }

  static Future<bool> isBackgroundRestricted() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('isBackgroundRestricted');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> openAppBatterySettings() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('openAppBatterySettings');
    } catch (_) {}
  }
}
