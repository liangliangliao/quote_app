package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver：仅作为轻量入口，接收解锁广播，然后触发后台 UnlockWorker。
 * 具体业务逻辑（查库、开关、冷却时间以及发送通知）全部在 UnlockWorker 中完成。
 */
class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val act = intent?.action ?: "null"
    // 只处理真正的解锁事件：USER_PRESENT / USER_UNLOCKED，其它广播直接略过，避免误触发
    if (act != Intent.ACTION_USER_PRESENT && act != Intent.ACTION_USER_UNLOCKED) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 收到非解锁广播 action=" + act + "，本次忽略（回包：SKIP_NOT_USER_PRESENT）")
      } catch (_: Throwable) {}
      return
    }

    // 记录收到解锁事件
    try {
      DbRepo.log(context, null, "【解锁后台】UnlockReceiver 收到解锁广播 action=" + act + "，准备触发后台 UnlockWorker（回包：OK）")
    } catch (_: Throwable) {}

    // 记录一次“最近解锁时间”，并做 3 秒去重
    try {
      val sp = context.applicationContext.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
      val now = System.currentTimeMillis()
      val lastTrig = sp.getLong("last_unlock_trigger_ts", 0L)
      if (lastTrig > 0 && (now - lastTrig) < 3000L) {
        try { DbRepo.log(context, null, "【解锁后台】3秒内已触发过解锁提醒，屏蔽本次重复（回包：SKIP_DUP）") } catch (_: Throwable) {}
        return
      }
      sp.edit().putLong("last_unlock_trigger_ts", now).putLong("last_user_present_ts", now).apply()
    } catch (_: Throwable) {}

    // 轻量 Toast 提示（仅在进程仍存活时可见）
    try {
      Toast.makeText(context.applicationContext, "已捕获解锁事件，后台正在准备解锁提醒", Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) {}

    // 把真正的业务处理交给后台 UnlockWorker
    try {
      UnlockWorker.trigger(context.applicationContext)
    } catch (_: Throwable) {
      try {
        DbRepo.log(context, null, "【解锁后台】UnlockReceiver 触发 UnlockWorker 失败（回包：FAIL）")
      } catch (_: Throwable) {}
    }
  }
}
