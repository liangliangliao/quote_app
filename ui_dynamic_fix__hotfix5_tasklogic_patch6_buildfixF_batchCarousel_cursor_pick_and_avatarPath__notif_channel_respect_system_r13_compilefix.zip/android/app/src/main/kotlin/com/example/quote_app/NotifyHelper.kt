package com.example.quote_app

import android.content.Intent

import android.app.PendingIntent

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import android.media.AudioAttributes
import com.example.quote_app.R


private fun ensureLoudChannel(ctx: android.content.Context): String {
    val CHANNEL_ID = "quotes_daily_v3_sound_on"
    if (android.os.Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(android.app.NotificationManager::class.java)
        val existing = nm.getNotificationChannel(CHANNEL_ID)
        if (existing == null) {
            val ch = android.app.NotificationChannel(
                CHANNEL_ID, "每日摘句", android.app.NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableVibration(false) // 依你要求：不要震动
                setSound(
                    android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION),
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
        // 如果渠道已存在，完全尊重系统/用户在设置里的开关（不删除、不重建）
    }
    return "quotes_daily_v3_sound_on"
}



object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val DEFAULT_CHANNEL_NAME = "Quotes"

  @JvmStatic
  fun send(ctx: Context, id: Int, title: String, body: String, avatarPath: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Android 13+ 需要 POST_NOTIFICATIONS 运行时权限；若缺失，静默失败。这里直接短路并记录。
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
        return
      }
    }

    // 系统级通知开关被关也会静默丢弃
    if (!nm.areNotificationsEnabled()) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: notifications disabled at system level") } catch (_: Throwable) {}
      return
    }

    // 8.0+ 必须先创建渠道
    if (Build.VERSION.SDK_INT >= 26) {
    // --- ensure HIGH-importance, with sound & vibration (new channel id to override any old silent settings) ---
    val CHANNEL_ID = "quotes_daily_v3_sound_on"
    val nm = ctx.getSystemService(NotificationManager::class.java)
    if (android.os.Build.VERSION.SDK_INT >= 26) {
        val ch = NotificationChannel(CHANNEL_ID, "每日摘句", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(false)
            setSound(
                android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            setShowBadge(true)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(ch)
    }

      val ch = NotificationChannel(
        DEFAULT_CHANNEL_ID,
        DEFAULT_CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      )
      nm.createNotificationChannel(ch)
    }

    val builder = NotificationCompat.Builder(ctx, ensureLoudChannel(ctx))

    // For pre-O devices, ensure high priority to keep notification visible
    if (Build.VERSION.SDK_INT < 26) {
      builder.setPriority(NotificationCompat.PRIORITY_HIGH)
    }
      .setOnlyAlertOnce(false)
      .setWhen(System.currentTimeMillis())
      .setCategory(Notification.CATEGORY_MESSAGE)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      

    
      // Custom body using 'notif_body_system_clarity_plus_size.xml' via NotifSystemClarityPlusSize
      try {
        val collapsed = NotifSystemClarityPlusSize.collapsed(ctx, body, deltaSp = 1f) // maxLines 5
        val expanded  = NotifSystemClarityPlusSize.expanded(ctx, body, deltaSp = 1f)  // maxLines 12
        builder.setCustomContentView(collapsed)
        builder.setCustomBigContentView(expanded)
      } catch (_: Throwable) {}
    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }

    // Ensure a contentIntent so the notification persists reliably on some OEMs
    try {
      val launchIntent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
          ?: Intent(Intent.ACTION_VIEW).setPackage(ctx.packageName)
      val contentPI = PendingIntent.getActivity(
          ctx, 1001, launchIntent,
          if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
      )
      builder.setContentIntent(contentPI)
    } catch (_: Throwable) {}

    nm.notify(id, builder.build())
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] posted id="+id+" chan="+DEFAULT_CHANNEL_ID) } catch (_: Throwable) {}
  }
}