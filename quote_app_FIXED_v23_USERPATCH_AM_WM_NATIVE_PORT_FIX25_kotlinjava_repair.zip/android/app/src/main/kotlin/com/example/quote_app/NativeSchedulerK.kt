package com.example.quote_app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*

object NativeSchedulerK {

  // ------------ helpers ------------
  private const val CHANNEL_ID = "am_exact_channel"
  private const val UNIQUE_WORK_PREFIX = "wm_once_"

  private fun ensureChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = ctx.getSystemService(NotificationManager::class.java)
      if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        val ch = NotificationChannel(CHANNEL_ID, "Exact Alarm", NotificationManager.IMPORTANCE_HIGH)
        nm.createNotificationChannel(ch)
      }
    }
  }

  private fun pendingIntent(ctx: Context, id: Int, payload: String?): PendingIntent {
    val intent = Intent(ctx, AlarmReceiver::class.java).apply {
      action = "ALARM_FIRE"
      putExtra("id", id)
      if (payload != null) putExtra("payload", payload)
    }
    return PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE)
  }

  private fun uidFromPayloadForLog(payload: String?): String? {
    if (payload == null) return null
    return try {
      // very light parsing
      val i = payload.indexOf("\"uid\"")
      if (i < 0) null else {
        val sub = payload.substring(i)
        val m = Regex("\"uid\"\s*:\s*\"([^\"]+)\"").find(sub)
        m?.groupValues?.get(1)
      }
    } catch (_: Throwable) { null }
  }

  // ------------ capability / permission ------------
  @JvmStatic fun canScheduleExact(ctx: Context): Boolean {
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
      } else true
    } catch (_: Throwable) { true }
  }

  @JvmStatic fun requestExactPermission(ctx: Context): Boolean {
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val it = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(it)
      } else {
        val it = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        it.data = android.net.Uri.parse("package:" + ctx.packageName)
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(it)
      }
      try { com.example.quote_app.data.DbRepository.log(ctx, null, "已发起精准闹钟授权请求") } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  // ------------ schedule ------------
  @JvmStatic fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    ensureChannel(ctx)
    val am = ctx.getSystemService(AlarmManager::class.java)
    val pi = pendingIntent(ctx, id, payload)
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
      }
      try { com.example.quote_app.data.DbRepository.log(ctx, uidFromPayloadForLog(payload), "AM 注册完成 id="+id+" when="+epochMs) } catch (_: Throwable) {}
      true
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepository.log(ctx, uidFromPayloadForLog(payload), "AM 注册失败 id="+id+" err="+t.message) } catch (_: Throwable) {}
      false
    }
  }

  private fun enqueueOnceWithWM(ctx: Context, id: Int, epochMs: Long, payloadJson: String) {
    val delay = kotlin.math.max(0L, epochMs - System.currentTimeMillis())
    val req = OneTimeWorkRequestBuilder<WmFallbackWorker>()
      .setInitialDelay(java.time.Duration.ofMillis(delay))
      .setInputData(workDataOf("id" to id, "payload" to payloadJson))
      .addTag("\${UNIQUE_WORK_PREFIX}\${id}")
      .addTag("wm_once")
      .build()
    try {
      WorkManager.getInstance(ctx).enqueueUniqueWork("\${UNIQUE_WORK_PREFIX}\${id}", ExistingWorkPolicy.REPLACE, req)
      try { com.example.quote_app.data.DbRepository.log(ctx, uidFromPayloadForLog(payloadJson), "WM 兜底注册完成 id="+id+" when="+epochMs) } catch (_: Throwable) {}
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepository.log(ctx, uidFromPayloadForLog(payloadJson), "WM 兜底注册失败 id="+id+" err="+t.message) } catch (_: Throwable) {}
    }
  }

  @JvmStatic fun scheduleWmFallback(ctx: Context, id: Int, epochMs: Long, payloadJson: String) {
    enqueueOnceWithWM(ctx, id, epochMs, payloadJson)
  }

  @JvmStatic fun scheduleExactWmCompat(ctx: Context, id: Int, epochMs: Long, payloadJson: String?) {
    val ok = scheduleExactAt(ctx, id, epochMs, payloadJson)
    if (!ok && payloadJson != null) {
      enqueueOnceWithWM(ctx, id, epochMs, payloadJson)
    } else if (payloadJson != null) {
      try { com.example.quote_app.data.DbRepository.log(ctx, uidFromPayloadForLog(payloadJson), "AM+WM 兼容注册完成 id="+id+" when="+epochMs) } catch (_: Throwable) {}
    }
  }

  // ------------ cancel ------------
  @JvmStatic fun cancel(ctx: Context, id: Int) {
    val am = ctx.getSystemService(AlarmManager::class.java)
    val pi = PendingIntent.getBroadcast(
      ctx, id, Intent(ctx, AlarmReceiver::class.java).apply { action = "ALARM_FIRE" },
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
    )
    if (pi != null) try { am.cancel(pi) } catch (_: Throwable) {}
    try { WorkManager.getInstance(ctx).cancelUniqueWork("\${UNIQUE_WORK_PREFIX}\${id}") } catch (_: Throwable) {}
    try { com.example.quote_app.data.DbRepository.log(ctx, null, "取消定时 id="+id) } catch (_: Throwable) {}
  }

  // ------------ self-check ------------
  @JvmStatic fun scheduleSelfCheck(ctx: Context, minutes: Int): Boolean {
    val mins = minutes.coerceAtLeast(15)
    val req = PeriodicWorkRequestBuilder<SelfCheckWorker>(java.time.Duration.ofMinutes(mins.toLong()))
      .addTag("wm_selfcheck_unique")
      .addTag("wm_once")
      .build()
    return try {
      WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("wm_selfcheck_unique", ExistingPeriodicWorkPolicy.UPDATE, req)
      try { com.example.quote_app.data.DbRepository.log(ctx, null, "自检已启用（native），频率="+mins+" 分钟") } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  // ------------ bulk cancel ------------
  @JvmStatic fun cancelAll(ctx: Context) {
    try { WorkManager.getInstance(ctx).cancelAllWorkByTag("wm_once") } catch (_: Throwable) {}
    try { WorkManager.getInstance(ctx).cancelUniqueWork("wm_selfcheck_unique") } catch (_: Throwable) {}
    try {
      val pairs = com.example.quote_app.data.DbRepository.listScheduledTasks(ctx)
      for (arr in pairs) {
        if (arr == null || arr.size < 2) continue
        val uid = arr[0] ?: continue
        val runKey = arr[1] ?: ""
        val id = (uid.hashCode() xor runKey.hashCode()) and 0x7fffffff
        try { cancel(ctx, id) } catch (_: Throwable) {}
      }
      try { com.example.quote_app.data.DbRepository.log(ctx, null, "取消所有定时任务已请求") } catch (_: Throwable) {}
    } catch (_: Throwable) { }
  }
}
