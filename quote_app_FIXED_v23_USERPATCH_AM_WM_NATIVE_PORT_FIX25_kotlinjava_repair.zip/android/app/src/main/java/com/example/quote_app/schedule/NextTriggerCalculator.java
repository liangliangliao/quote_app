package com.example.quote_app.schedule;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.example.quote_app.data.DbInspector;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Compute next trigger time from DB, tolerant to optional columns. */
public final class NextTriggerCalculator {
    private NextTriggerCalculator() {}

    /** @return next epoch millis, or -1 if cannot compute */
    public static long compute(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.dbPath) || TextUtils.isEmpty(cc.tasksSource)) return -1L;
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY);
            // Discover available columns
            Set<String> cols = listColumns(db, cc.tasksSource);
            String uidCol = pick(cols, cc.taskColMap.get("uid"), "uid","task_uid","id");
            String whenCol = pick(cols, cc.taskColMap.get("trigger_at"), "trigger_at","fire_at","scheduled_at","when","time","ts");
            String nextCol = pick(cols, "next_time","next_run","next");
            String startCol = pick(cols, "start_time","start");
            String freqCol  = pick(cols, "freq_type","frequency","repeat_type","repeat");
            String wdayCol  = pick(cols, "freq_weekday","weekday","wday");
            String domCol   = pick(cols, "freq_day_of_month","day_of_month","dom");

            if (uidCol == null) return -1L;

            StringBuilder sb = new StringBuilder("SELECT ");
            boolean first = true;
            for (String c : new String[]{ whenCol, nextCol, startCol, freqCol, wdayCol, domCol }) {
                if (c != null) {
                    if (!first) sb.append(","); first = false;
                    sb.append(c);
                }
            }
            sb.append(" FROM ").append(cc.tasksSource).append(" WHERE ").append(uidCol).append("=? LIMIT 1");
            Cursor c = db.rawQuery(sb.toString(), new String[]{ uid });
            if (!c.moveToFirst()) return -1L;

            int idx = 0;
            Long triggerAt = (whenCol != null) ? safeGetLong(c, idx++) : null;
            Long nextTime  = (nextCol != null) ? safeParseTime(c, idx++) : null;
            String start   = (startCol != null) ? safeGetString(c, idx++) : null;
            String freq    = (freqCol  != null) ? safeGetString(c, idx++) : null;
            Integer wday   = (wdayCol  != null) ? safeGetInt(c, idx++) : null;
            Integer dom    = (domCol   != null) ? safeGetInt(c, idx++) : null;

            long now = System.currentTimeMillis();
            // 1) next_time 优先
            if (nextTime != null && nextTime > now + 5000) return nextTime;

            // 2) start_time + freq
            if (!TextUtils.isEmpty(start)) {
                int[] hm = parseHHmm(start);
                if (hm != null) {
                    if ("weekly".equalsIgnoreCase(emptyTo(freq,"daily")) && wday != null) {
                        return alignWeekly(hm[0], hm[1], wday, now);
                    } else if ("monthly".equalsIgnoreCase(freq) && dom != null) {
                        return alignMonthly(hm[0], hm[1], dom, now);
                    } else {
                        return alignDaily(hm[0], hm[1], now);
                    }
                }
            }

            // 3) 兜底：trigger_at 仍在未来
            if (triggerAt != null && triggerAt > now + 5000) return triggerAt;

            // 4) 无法计算
            return -1L;
        } catch (Throwable t) {
            throw new RuntimeException(t);
        } finally {
            if (db != null) try { db.close(); } catch (Throwable ignored) {}
        }
    }

    private static Set<String> listColumns(SQLiteDatabase db, String table) {
        HashSet<String> s = new HashSet<>();
        Cursor c = db.rawQuery("PRAGMA table_info(" + table + ")", null);
        while (c.moveToNext()) {
            String name = c.getString(1);
            if (name != null) s.add(name.toLowerCase(Locale.US));
        }
        c.close();
        return s;
    }

    private static String pick(Set<String> cols, String prefer, String... candidates) {
        if (!TextUtils.isEmpty(prefer)) return prefer;
        for (String k: candidates) if (cols.contains(k.toLowerCase(Locale.US))) return k;
        return null;
    }

    private static String emptyTo(String v, String def) { return TextUtils.isEmpty(v) ? def : v; }

    private static Long safeGetLong(Cursor c, int idx) {
        if (idx >= c.getColumnCount()) return null;
        try { return c.getLong(idx); } catch (Throwable t) { return null; }
    }
    private static String safeGetString(Cursor c, int idx) {
        if (idx >= c.getColumnCount()) return null;
        try { return c.getString(idx); } catch (Throwable t) { return null; }
    }
    private static Integer safeGetInt(Cursor c, int idx) {
        if (idx >= c.getColumnCount()) return null;
        try { return c.getInt(idx); } catch (Throwable t) { return null; }
    }

    private static Long safeParseTime(Cursor c, int idx) {
        String s = safeGetString(c, idx);
        if (s == null) return null;
        // accept ISO-8601-like or epoch millis string
        try {
            if (s.matches("\\d{13,}")) return Long.parseLong(s);
        } catch (Throwable ignored) {}
        // very simple parser: HH:mm or yyyy-MM-ddTHH:mm:ss
        try {
            if (s.length() >= 5 && s.charAt(2) == ':') {
                int hh = Integer.parseInt(s.substring(0,2));
                int mm = Integer.parseInt(s.substring(3,5));
                return alignDaily(hh, mm, System.currentTimeMillis());
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static long alignDaily(int hh, int mm, long now) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.HOUR_OF_DAY, hh);
        cal.set(Calendar.MINUTE, mm);
        long cand = cal.getTimeInMillis();
        if (cand <= now + 5000) cand += 24L*60*60*1000L;
        return cand;
    }

    private static long alignWeekly(int hh, int mm, int weekday, long now) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.HOUR_OF_DAY, hh);
        cal.set(Calendar.MINUTE, mm);
        int today = cal.get(Calendar.DAY_OF_WEEK); // 1=Sunday..7=Saturday
        int target = weekday;
        int delta = (target - today + 7) % 7;
        cal.add(Calendar.DAY_OF_MONTH, delta);
        long cand = cal.getTimeInMillis();
        if (cand <= now + 5000) cal.add(Calendar.DAY_OF_MONTH, 7);
        return cal.getTimeInMillis();
    }

    private static long alignMonthly(int hh, int mm, int dom, long now) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.HOUR_OF_DAY, hh);
        cal.set(Calendar.MINUTE, mm);
        int todayDom = cal.get(Calendar.DAY_OF_MONTH);
        if (dom < todayDom || (dom == todayDom && cal.getTimeInMillis() <= now + 5000)) {
            cal.add(Calendar.MONTH, 1);
        }
        cal.set(Calendar.DAY_OF_MONTH, Math.min(dom, cal.getActualMaximum(Calendar.DAY_OF_MONTH)));
        return cal.getTimeInMillis();
    }
}