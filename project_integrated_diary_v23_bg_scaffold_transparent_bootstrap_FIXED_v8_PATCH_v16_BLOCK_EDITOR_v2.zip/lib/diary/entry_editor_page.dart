import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:audioplayers/audioplayers.dart';

import '../data/db.dart';
import 'diary_dao.dart';
import 'tag_picker_page.dart';
import 'weather.dart';
import 'diary_text_controller.dart';


// 编辑器内联块模型：文本块 / 图片块 / 语音块
abstract class _EditorBlock {}

class _TextEditorBlock extends _EditorBlock {
  final TextEditingController controller;
  final FocusNode focusNode;
  _TextEditorBlock(String text)
      : controller = TextEditingController(text: text),
        focusNode = FocusNode();
}

class _ImageEditorBlock extends _EditorBlock {
  final String path;
  _ImageEditorBlock(this.path);
}

class _AudioEditorBlock extends _EditorBlock {
  final String path;
  _AudioEditorBlock(this.path);
}

class EntryEditorPage extends StatefulWidget {
  final int notebookId;
  final int? entryId;
  const EntryEditorPage({super.key, required this.notebookId, this.entryId});

  @override
  State<EntryEditorPage> createState() => _EntryEditorPageState();
}

class _EntryEditorPageState extends State<EntryEditorPage> {
  // 富文本块列表：按顺序保存文本块、图片块、语音块
  final List<_EditorBlock> _blocks = <_EditorBlock>[];
  int _activeTextBlockIndex = -1;


  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy年MM月dd日 HH:mm');
  final _textCtrl = DiaryContentController();

  int _entryId = 0;
  DateTime _time = DateTime.now();
  int? _weatherCode;
  String? _moodName;
  String? _moodIcon;
  bool _starred = false;

  bool _dirty = false;

  String _lastText = '';
  TextSelection _lastSel = const TextSelection.collapsed(offset: 0);


  String? _bgPath;
  final FocusNode _focusNode = FocusNode();
  final ScrollController _contentScrollController = ScrollController();

  final GlobalKey _textBoxKey = GlobalKey();

  double _bgOpacity = 0.25;

  final List<int> _tagIds = [];
  final Map<int, String> _tagNameById = {};

  @override
  void initState() {
    super.initState();
    _rebuildBlocksFromRaw(_textCtrl.text);
    _textCtrl.addListener(() { if (mounted) setState(() {}); });
    _bootstrap();
    _textCtrl.addListener(() {
      if (!_dirty) setState(() => _dirty = true);
    });
  }

 @override
  @override
  void dispose() {
    _contentScrollController.dispose();
    for (final b in _blocks) {
      if (b is _TextEditorBlock) {
        b.controller.dispose();
        b.focusNode.dispose();
      }
    }
    _focusNode.dispose();
    _textCtrl.dispose();
    super.dispose();
  }

 Future<void> _bootstrap() async {
    // config: diary bg image & opacity
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        final img = rows.first['diary_bg_image'];
        _bgPath = img == null ? null : img.toString();
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
    } catch (_) {}

    // recent mood from emotions
    try {
      final rows = await db.query('emotions', orderBy: 'inserted_at DESC', limit: 1);
      if (rows.isNotEmpty) {
        _moodName = (rows.first['emoji_name'] ?? '').toString();
        _moodIcon = (rows.first['emoji_char'] ?? '').toString();
      }
    } catch (_) {}

    await _dao.ensureSchema();

    if (widget.entryId != null) {
      final e = await _dao.getEntry(widget.entryId!);
      if (e != null) {
        _entryId = e.id;
        _time = DateTime.fromMillisecondsSinceEpoch(e.entryTime);
        _weatherCode = e.weatherCode;
        _moodName = e.moodName ?? _moodName;
        _moodIcon = e.moodIcon ?? _moodIcon;
        _textCtrl.text = e.content;
        _rebuildBlocksFromRaw(_textCtrl.text);
        _starred = (e.starred == 1);

        final tags = await _dao.tagsForEntry(e.id);
        _tagIds
          ..clear()
          ..addAll(tags.map((t) => t.id));
        for (final t in tags) {
          _tagNameById[t.id] = t.name;
        }
      }
    }

    // If no entryId, keep defaults but build tag name map for future display
    await _refreshTagNameMap();

    _rebuildBlocksFromRaw(_textCtrl.text);

    if (mounted) setState(() {});
  }

  Future<void> _refreshTagNameMap() async {
    try {
      final all = await _dao.listTags();
      for (final t in all) {
        _tagNameById[t.id] = t.name;
      }
    } catch (_) {}
  }

  
  // 将原始content解析为块列表（文本 / 图片 / 语音），仅用于编辑器展示。
  void _rebuildBlocksFromRaw(String raw) {
    // 先清理旧的文本块资源
    for (final b in _blocks) {
      if (b is _TextEditorBlock) {
        b.controller.dispose();
        b.focusNode.dispose();
      }
    }
    _blocks.clear();

    final lines = raw.split(RegExp(r'\r?\n'));
    final imgReg = RegExp(r'^\[图片\]\s*(.+)\$');
    final audioReg = RegExp(r'^\[语音\]\s*(.+)\$');

    final buffer = StringBuffer();
    void flushText() {
      if (buffer.isEmpty) return;
      final text = buffer.toString();
      buffer.clear();
      _blocks.add(_TextEditorBlock(text));
    }

    for (final rawLine in lines) {
      final line = rawLine;
      final trimmedRight = line.trimRight();
      final mImg = imgReg.firstMatch(trimmedRight);
      final mAud = audioReg.firstMatch(trimmedRight);
      if (mImg != null) {
        flushText();
        final path = (mImg.group(1) ?? '').trim();
        if (path.isNotEmpty) {
          _blocks.add(_ImageEditorBlock(path));
        }
      } else if (mAud != null) {
        flushText();
        final path = (mAud.group(1) ?? '').trim();
        if (path.isNotEmpty) {
          _blocks.add(_AudioEditorBlock(path));
        }
      } else {
        buffer.write(line);
        buffer.write('\n');
      }
    }
    flushText();

    if (_blocks.isEmpty) {
      _blocks.add(_TextEditorBlock(''));
    }

    _activeTextBlockIndex = _blocks.indexWhere((b) => b is _TextEditorBlock);
    if (_activeTextBlockIndex < 0) _activeTextBlockIndex = 0;
    if (_activeTextBlockIndex >= _blocks.length) _activeTextBlockIndex = _blocks.length - 1;

    _syncRawFromBlocks();
  }

  // 根据块列表回写到_textCtrl.text，作为真正保存到数据库的内容。
  void _syncRawFromBlocks() {
    final buf = StringBuffer();
    for (final b in _blocks) {
      if (b is _TextEditorBlock) {
        final text = b.controller.text;
        if (text.isNotEmpty) {
          buf.write(text);
          if (!text.endsWith('\n')) {
            buf.write('\n');
          }
        }
      } else if (b is _ImageEditorBlock) {
        buf.write('[图片] ');
        buf.write(b.path);
        buf.write('\n');
      } else if (b is _AudioEditorBlock) {
        buf.write('[语音] ');
        buf.write(b.path);
        buf.write('\n');
      }
    }
    _textCtrl.text = buf.toString();
  }

  // 在当前激活的文本块插入媒体块（图片或语音），并在其后自动创建一个新的文本块以便继续输入。
  void _insertMediaBlock(_EditorBlock mediaBlock) {
    if (_blocks.isEmpty) {
      _blocks.add(_TextEditorBlock(''));
    }
    int idx = _activeTextBlockIndex;
    if (idx < 0 || idx >= _blocks.length || _blocks[idx] is! _TextEditorBlock) {
      idx = _blocks.indexWhere((b) => b is _TextEditorBlock);
      if (idx < 0) {
        _blocks.add(_TextEditorBlock(''));
        idx = _blocks.length - 1;
      }
    }
    final current = _blocks[idx] as _TextEditorBlock;
    final text = current.controller.text;
    final sel = current.controller.selection;
    int caret = sel.isValid ? sel.start : text.length;
    if (caret < 0 || caret > text.length) caret = text.length;

    final before = text.substring(0, caret);
    final after = text.substring(caret);

    final List<_EditorBlock> newBlocks = <_EditorBlock>[];
    newBlocks.addAll(_blocks.take(idx));
    newBlocks.add(_TextEditorBlock(before));
    newBlocks.add(mediaBlock);
    newBlocks.add(_TextEditorBlock(after));
    newBlocks.addAll(_blocks.skip(idx + 1));

    // 释放旧资源
    for (final b in _blocks) {
      if (b is _TextEditorBlock) {
        b.controller.dispose();
        b.focusNode.dispose();
      }
    }
    _blocks
      ..clear()
      ..addAll(newBlocks);

    // 规范化：合并连续文本块
    for (int i = 1; i < _blocks.length;) {
      final prev = _blocks[i - 1];
      final cur = _blocks[i];
      if (prev is _TextEditorBlock && cur is _TextEditorBlock) {
        final mergedText = prev.controller.text + cur.controller.text;
        final merged = _TextEditorBlock(mergedText);
        prev.controller.dispose();
        prev.focusNode.dispose();
        cur.controller.dispose();
        cur.focusNode.dispose();
        _blocks
          ..removeAt(i)
          ..removeAt(i - 1)
          ..insert(i - 1, merged);
      } else {
        i++;
      }
    }

    // 确保媒体块后面至少有一个文本块可以输入
    int mediaIndex = _blocks.indexOf(mediaBlock);
    if (mediaIndex == -1) {
      mediaIndex = _blocks.indexWhere((b) => identical(b, mediaBlock));
    }
    int targetTextIndex = mediaIndex + 1;
    if (targetTextIndex >= _blocks.length || _blocks[targetTextIndex] is! _TextEditorBlock) {
      _blocks.insert(targetTextIndex, _TextEditorBlock(''));
    }
    _activeTextBlockIndex = targetTextIndex;

    final active = _blocks[_activeTextBlockIndex] as _TextEditorBlock;
    active.controller.selection = const TextSelection.collapsed(offset: 0);

    _syncRawFromBlocks();

    // 在下一帧请求焦点，避免在setState期间操作焦点
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      active.focusNode.requestFocus();
    });
    setState(() {});
  }

  // 当在某个文本块的行首按下退格键时，如果前一个块是图片/语音，则删除该媒体块。
  void _deleteBlockBefore(int textBlockIndex) {
    if (textBlockIndex <= 0) return;
    final prev = _blocks[textBlockIndex - 1];
    if (prev is! _ImageEditorBlock && prev is! _AudioEditorBlock) return;

    if (prev is _ImageEditorBlock || prev is _AudioEditorBlock) {
      setState(() {
        _blocks.removeAt(textBlockIndex - 1);
        _syncRawFromBlocks();
      });
    }
  }

  // 构建块编辑器的Widget列表：文本块 + 图片块 + 语音块按顺序排布
  List<Widget> _buildBlockWidgets() {
    final List<Widget> children = <Widget>[];
    for (int i = 0; i < _blocks.length; i++) {
      final b = _blocks[i];
      if (b is _TextEditorBlock) {
        children.add(
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: RawKeyboardListener(
              focusNode: b.focusNode,
              onKey: (event) {
                if (event is RawKeyDownEvent && event.logicalKey == LogicalKeyboardKey.backspace) {
                  final selection = b.controller.selection;
                  if (selection.isCollapsed && selection.start == 0) {
                    _deleteBlockBefore(i);
                  }
                }
              },
              child: TextField(
                controller: b.controller,
                maxLines: null,
                autofocus: i == 0,
                textAlignVertical: TextAlignVertical.top,
                decoration: const InputDecoration.collapsed(hintText: '写点什么……'),
                onTap: () {
                  _activeTextBlockIndex = i;
                },
                onChanged: (value) {
                  _activeTextBlockIndex = i;
                  if (!_dirty) {
                    setState(() {
                      _dirty = true;
                    });
                  }
                  _syncRawFromBlocks();
                },
              ),
            ),
          ),
        );
      } else if (b is _ImageEditorBlock) {
        children.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: LayoutBuilder(
              builder: (ctx, cons) {
                final f = File(b.path);
                if (!f.existsSync()) return const SizedBox.shrink();
                final maxWidth = math.min(MediaQuery.of(ctx).size.width, cons.maxWidth);
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Image.file(
                    f,
                    width: maxWidth,
                    fit: BoxFit.contain,
                  ),
                );
              },
            ),
          ),
        );
      } else if (b is _AudioEditorBlock) {
        // 编辑态下的语音块：仅简单展示一个占位和播放按钮，不修改原有播放器业务逻辑。
        children.add(
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                const Icon(Icons.mic, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    b.path,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    }
    children.add(const SizedBox(height: 96));
    return children;
  }

String _preview(String content) {
    final lines = content.split(RegExp(r'\r?\n'));
    for (final raw in lines) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      if (line.startsWith('[图片]') || line.startsWith('[语音]')) continue;
      return line.length > 50 ? line.substring(0, 50) : line;
    }
    return '（空白日记）';
  }

  Future<void> _save() async {
    if (!_dirty) return;

    final w = weatherByCode(_weatherCode);
    final e = DiaryEntry(
      id: _entryId,
      notebookId: widget.notebookId,
      entryTime: _time.millisecondsSinceEpoch,
      weatherCode: _weatherCode,
      weatherName: _weatherCode == null ? null : w.name,
      moodName: _moodName,
      moodIcon: _moodIcon,
      content: _textCtrl.text,
      preview: _preview(_textCtrl.text),
      starred: _starred ? 1 : 0,
    );
    final id = await _dao.upsertEntry(e);
    await _dao.touchNotebook(widget.notebookId);
    await _dao.setTagsForEntry(id, _tagIds);

    if (!mounted) return;
    Navigator.pop(context, id);
  }

  Future<void> _cancel() async {
    if (!_dirty) {
      Navigator.pop(context);
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('放弃未保存内容？'),
        content: const Text('你有修改尚未保存，确定要退出吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('继续编辑')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('放弃')),
        ],
      ),
    );
    if (ok == true && mounted) Navigator.pop(context);
  }

  Future<void> _pickTime() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _time,
      firstDate: DateTime(2000, 1, 1),
      lastDate: DateTime(DateTime.now().year + 1),
    );
    if (d == null) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_time));
    if (t == null) return;
    setState(() {
      _time = DateTime(d.year, d.month, d.day, t.hour, t.minute);
      _dirty = true;
    });
  }

  Future<void> _pickTags() async {
    final res = await Navigator.push<List<int>?>(
      context,
      MaterialPageRoute(builder: (_) => TagPickerPage(dao: _dao, initialSelected: _tagIds)),
    );
    if (res == null) return;
    setState(() {
      _tagIds
        ..clear()
        ..addAll(res);
      _dirty = true;
    });
    await _refreshTagNameMap();
    if (mounted) setState(() {});
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.white),
        Opacity(opacity: (1.0 - _bgOpacity).clamp(0.0, 1.0), child: Image.file(f, fit: BoxFit.cover)),
        child,
      ],
    );
  }

  @override
  
  
  Future<void> _insertImage() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;

    _insertMediaBlock(_ImageEditorBlock(path));
  }


  Future<void> _insertAudio() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;

    _insertMediaBlock(_AudioEditorBlock(path));
  }



  void _onTextChanged(String s) {
    // 标记脏
    if (mounted && !_dirty) setState(() { _dirty = true; });
    // 检测是否是“退格一次”导致
    final curSel = _textCtrl.selection;
    final prevText = _lastText;
    final prevSel = _lastSel;
    _lastText = s;
    _lastSel = curSel;

    if (prevText.isEmpty) return;
    final deleted = prevText.length - s.length;
    if (deleted != 1) return; // 只处理一次退格
    if (!curSel.isCollapsed) return;

    // 找到当前光标所在行
    final idx = curSel.baseOffset;
    int lineStart = 0;
    int i = 0;
    for (i = 0; i < s.length && i < idx; i++) {
      if (s.codeUnitAt(i) == 10) { // '\n'
        lineStart = i + 1;
      }
    }
    int lineEnd = s.indexOf('\n', lineStart);
    if (lineEnd < 0) lineEnd = s.length;
    final line = s.substring(lineStart, lineEnd).trimLeft();
    final isMarker = line.startsWith('[图片]') || line.startsWith('[语音]');
    if (!isMarker) return;

    // 删除整行 marker
    final newText = (s.substring(0, lineStart) + s.substring(lineEnd + (lineEnd < s.length ? 1 : 0)));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _textCtrl.text = newText;
      _textCtrl.selection = TextSelection.collapsed(offset: lineStart);
      setState(() {});
    });
  }


  void _handleDoubleTapDown(TapDownDetails details) {
    final ctx = _textBoxKey.currentContext;
    if (ctx == null) return;
    final box = ctx.findRenderObject() as RenderBox?;
    if (box == null) return;
    // 计算相对于 TextField 容器的坐标
    final local = box.globalToLocal(details.globalPosition);
    final size = box.size;
    final defaultStyle = DefaultTextStyle.of(context).style;
    String workingText = _textCtrl.text;
    if (workingText.isEmpty) {
      FocusScope.of(context).requestFocus(_focusNode);
      _textCtrl.selection = const TextSelection.collapsed(offset: 0);
      return;
    }
    TextPainter _makePainter(String t) {
      final p = TextPainter(
        text: TextSpan(text: t, style: defaultStyle),
        textDirection: TextDirection.ltr,
        maxLines: null,
      );
      p.layout(maxWidth: size.width);
      return p;
    }
    var painter = _makePainter(workingText);
    final lineHeight = painter.preferredLineHeight;
    final endCaret = painter.getOffsetForCaret(
      TextPosition(offset: workingText.length),
      Rect.zero,
    );
    // 如果双击在文本末尾更下方的空白区域，则补齐换行，让该行存在（满足“任意位置双击在行首出现光标”）
    if (local.dy > endCaret.dy + lineHeight * 0.8) {
      final desiredLine = (local.dy / lineHeight).floor();
      final currentLines = '\n'.allMatches(workingText).length + 1;
      if (desiredLine >= currentLines) {
        final add = (desiredLine - currentLines + 1).clamp(0, 120);
        if (add > 0) {
          workingText = workingText + ('\n' * add);
          // 先更新文本，再设置光标位置
          _textCtrl.value = _textCtrl.value.copyWith(
            text: workingText,
            selection: TextSelection.collapsed(offset: workingText.length),
            composing: TextRange.empty,
          );
          painter = _makePainter(workingText);
        }
      }
    }
    final pos = painter.getPositionForOffset(Offset(0, local.dy));
    int off = pos.offset;
    // 移动到该行行首
    while (off > 0 && workingText.codeUnitAt(off - 1) != 10) {
      off--;
    }
    FocusScope.of(context).requestFocus(_focusNode);
    _textCtrl.selection = TextSelection.collapsed(offset: off);
  }

Widget _attachmentsPreview() {
    final content = _textCtrl.text;
    final lines = content.split(RegExp(r'\r?\n'));
    final widgets = <Widget>[];

    final imgReg = RegExp(r'^\[图片\]\s*(.+)$');
    final audioReg = RegExp(r'^\[语音\]\s*(.+)$');

    for (final raw in lines) {
      final line = raw.trimRight();
      if (line.isEmpty) continue;

      final mImg = imgReg.firstMatch(line);
      final mAud = audioReg.firstMatch(line);

      if (mImg != null) {
        final path = mImg.group(1)!;
        final f = File(path);
        if (!f.existsSync()) continue;

        widgets.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: LayoutBuilder(
              builder: (ctx, cons) {
                final double w = math.min(MediaQuery.of(ctx).size.width - 32, 560).toDouble();
                final double h = math.min(MediaQuery.of(ctx).size.height * 0.35, 320).toDouble();
                return SizedBox(
                  width: w,
                  height: h,
                  child: InteractiveViewer(
                    minScale: 0.5,
                    maxScale: 4,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(f, width: w, height: h, fit: BoxFit.contain),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      } else if (mAud != null) {
        final path = mAud.group(1)!;
        widgets.add(_AudioTile(path: path));
      }
    }

    if (widgets.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets),
    );
  }



Widget build(BuildContext context) {
    final w = weatherByCode(_weatherCode);

    return _bgWrap(Scaffold(extendBodyBehindAppBar: true,
      backgroundColor: (_bgPath == null || _bgPath!.isEmpty) ? Colors.white : Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0,
        title: const Text('写日记'),
        actions: [
          IconButton(onPressed: _dirty ? _cancel : null, icon: const Icon(Icons.close)),
          IconButton(onPressed: _dirty ? _save : null, icon: const Icon(Icons.check)),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Material(
                  color: Colors.transparent,
                  elevation: 0,
                  child: Padding(
                    padding: EdgeInsets.zero,
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: _pickTime,
                            child: Row(
                              children: [
                                const Icon(Icons.schedule, size: 18),
                                const SizedBox(width: 6),
                                Text(_fmt.format(_time)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: _weatherCode,
                          hint: const Text('天气'),
                          items: weatherOptions
                              .map((w) => DropdownMenuItem<int>(
                                    value: w.code,
                                    child: Row(
                                      children: [
                                        Icon(w.icon, size: 18),
                                        const SizedBox(width: 6),
                                        Text(w.name),
                                      ],
                                    ),
                                  ))
                              .toList(),
                          onChanged: (v) => setState(() {
                            _weatherCode = v;
                            _dirty = true;
                          }),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          tooltip: _starred ? '取消收藏' : '收藏',
                          onPressed: () => setState(() {
                            _starred = !_starred;
                            _dirty = true;
                          }),
                          icon: Icon(_starred ? Icons.star : Icons.star_border),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    controller: _contentScrollController,
                    padding: const EdgeInsets.only(bottom: 96),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          key: _textBoxKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: _buildBlockWidgets(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                top: false,
                minimum: EdgeInsets.zero,
                child: Row(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 6,
                          children: _tagIds
                              .map((id) => Chip(
                                    label: Text(_tagNameById[id] ?? '标签#$id'),
                                  ))
                              .toList(),
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: '插入语音',
                      onPressed: _insertAudio,
                      icon: const Icon(Icons.mic_none),
                    ),
                    IconButton(
                      tooltip: '插入图片',
                      onPressed: _insertImage,
                      icon: const Icon(Icons.image_outlined),
                    ),
                    OutlinedButton.icon(
                      onPressed: _pickTags,
                      icon: const Icon(Icons.label_outline),
                      label: const Text('标签'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      )),
    ));
  }
}


class _AudioTile extends StatefulWidget {
  final String path;
  const _AudioTile({required this.path});
  @override
  State<_AudioTile> createState() => _AudioTileState();
}

class _AudioTileState extends State<_AudioTile> {
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _player.pause();
    } else {
      await _player.play(DeviceFileSource(widget.path));
    }
    if (mounted) setState(() => _playing = !_playing);
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: IconButton(icon: Icon(_playing ? Icons.pause : Icons.play_arrow), onPressed: _toggle),
      title: const Text('语音'),
      subtitle: const Text('点击播放'),
      tileColor: Colors.black.withOpacity(0.05),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    );
  }
}
