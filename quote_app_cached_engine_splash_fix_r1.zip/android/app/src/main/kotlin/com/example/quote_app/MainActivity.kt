package com.example.quote_app

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.renderer.FlutterUiDisplayListener

class MainActivity : FlutterActivity() {
  private var blocker: View? = null
  @Volatile private var firstFrameShown = false

  override fun onCreate(savedInstanceState: Bundle?) {
    val splash = installSplashScreen()
    splash.setKeepOnScreenCondition { !firstFrameShown }
    super.onCreate(savedInstanceState)
    ensureBlocker()
    flutterEngine?.renderer?.addIsDisplayingListener(object : FlutterUiDisplayListener {
      override fun onFlutterUiDisplayed() {
        firstFrameShown = true
        removeBlocker()
      }
      override fun onFlutterUiNoLongerDisplayed() {
        firstFrameShown = false
      }
    })
  }

  override fun onResume() {
    super.onResume()
    if (!firstFrameShown) ensureBlocker()
  }

  override fun getCachedEngineId(): String? = "main_engine"
  override fun shouldDestroyEngineWithHost(): Boolean = false

  private fun ensureBlocker() {
    if (blocker != null) return
    blocker = View(this).apply { setBackgroundResource(R.drawable.launch_background) }
    addContentView(blocker,
      FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
  }

  private fun removeBlocker() {
    blocker?.let { v -> (v.parent as? ViewGroup)?.removeView(v) }
    blocker = null
  }
}
