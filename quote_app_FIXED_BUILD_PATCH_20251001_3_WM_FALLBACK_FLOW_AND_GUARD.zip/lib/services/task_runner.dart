
import '../data/dao.dart';
import '../services/openai_service.dart';
import '../services/notification_service.dart';

class TaskRunner {
  /// Run task by uid. This is the unified runner used by WM/AM.
  
static Future<bool> run(String uid) async {
  try {
    final task = await TaskDao().getByUid(uid);
    if (task == null) return false;
    final status = (task['status'] ?? 'on').toString();
    if (status != 'on') return false;
    final type = (task['type'] ?? 'manual').toString();
    if (type == 'auto') {
      return await _runAuto(task);
    } else if (type == 'carousel') {
      return await _runCarousel(task);
    } else {
      return await _runManual(task);
    }
  } catch (_) {
    return false;
  }
}


