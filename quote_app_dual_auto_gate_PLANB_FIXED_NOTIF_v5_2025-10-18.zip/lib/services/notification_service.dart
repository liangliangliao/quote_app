
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _homeVisible = false;
  static bool _initialized = false;
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sysperms');

  /// 初始化通知插件（main.dart 会在启动时调用）
  static Future<void> init() async {
    if (_initialized) return;
    try {
      const AndroidInitializationSettings aInit = AndroidInitializationSettings('@mipmap/ic_launcher');
      const DarwinInitializationSettings iInit = DarwinInitializationSettings();
      const InitializationSettings settings = InitializationSettings(android: aInit, iOS: iInit);
      await _plugin.initialize(settings);
      _initialized = true;
    } catch (e, s) {
      debugPrint('NotificationService.init error: $e\n$s');
    }
  }

  /// 标记首页已可见（首开门控的前置条件）
  static void markHomeVisible() { _homeVisible = true; }

  /// Android 13+ 申请通知权限；老版本尝试旧 API，失败则忽略
  static Future<void> request() async {
    if (!Platform.isAndroid) return;
    try {
      final AndroidFlutterLocalNotificationsPlugin? android =
          _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (android != null) {
        try {
          await android.requestNotificationsPermission();
        } catch (_) {
          try { await android.requestPermission(); } catch (_) {}
        }
      }
    } catch (e, s) {
      debugPrint('NotificationService.request error: $e\n$s');
    }
  }

  /// 查询系统是否允许本 App 的通知
  static Future<bool> areNotificationsEnabled() async {
    if (!Platform.isAndroid) return true;
    try {
      final AndroidFlutterLocalNotificationsPlugin? android =
          _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final bool? ok = await android?.areNotificationsEnabled();
      return ok ?? true;
    } catch (_) {
      return true;
    }
  }

  /// 向前兼容旧调用
  static Future<bool> isEnabled() async => await areNotificationsEnabled();

  /// 简单文本通知（旧调用保留）
  static Future<void> showSimple(String title, String body) async {
    await show(title: title, body: body);
  }

  /// 发送通知（支持大图标路径）
  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    id ??= 1000;
    try {
      final AndroidNotificationDetails android = AndroidNotificationDetails(
        'default_channel_id',
        'General',
        channelDescription: 'General notifications',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
        largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
            ? FilePathAndroidBitmap(largeIconPath)
            : null,
      );
      final NotificationDetails details = NotificationDetails(android: android);
      await _plugin.show(id, title ?? '', body ?? '', details);
    } catch (e, s) {
      debugPrint('NotificationService.show error: $e\n$s');
    }
  }

  /// 首次打开首页且通知已开 -> 才可能引导精准闹钟授权
  static Future<void> gateExactAlarmOnFirstOpen() async {
    if (!_homeVisible) return;
    if (!await areNotificationsEnabled()) return;
    try {
      final bool can = await _ch.invokeMethod<bool>('canScheduleExactAlarms') ?? true;
      if (!can) {
        await _ch.invokeMethod('requestExactAlarm');
      }
    } catch (e, s) {
      debugPrint('gateExactAlarmOnFirstOpen error: $e\n$s');
    }
  }
}
