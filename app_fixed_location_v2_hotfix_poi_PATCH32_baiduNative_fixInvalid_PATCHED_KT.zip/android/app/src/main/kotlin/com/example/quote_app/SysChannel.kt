package com.example.quote_app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * Single place to expose small native capabilities to Dart.
 * Channel name must match the one used on the Dart side:
 *   MethodChannel('com.example.quote_app/sys')
 */
object SysChannel {
    private const val CHANNEL = "com.example.quote_app/sys"
    private var channel: MethodChannel? = null
    private var appCtx: Context? = null

    fun register(engine: FlutterEngine, ctx: Context) {
        appCtx = ctx.applicationContext
        if (channel == null) {
            channel = MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
            channel?.setMethodCallHandler(::onMethodCall)
        }
    }

    private fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "getBaiduLocationOnce" -> {
                val timeoutMs = (call.argument<Number>("timeoutMs")?.toLong()) ?: 20_000L
                BaiduLocator.getLocationOnce(appCtx, timeoutMs) { ok, map, err ->
                    if (ok) result.success(map) else result.error("LOC_ERROR", err ?: "unknown", null)
                }
            }
            "showToast" -> {
                val msg = call.argument<String>("message") ?: ""
                showToast(msg)
                result.success(true)
            }
            else -> result.notImplemented()
        }
    }

    private fun showToast(msg: String) {
        val ctx = appCtx ?: return
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
        }
    }
}