import 'dart:async';
import 'dart:convert';

import 'package:crypto/crypto.dart';

import 'package:http/http.dart' as http;
import '../data/dao.dart';

/// Translation helper for the Space module.
///
/// IMPORTANT (per product requirement):
/// - Only DeepSeek is used for translation.
/// - If DeepSeek key/model is missing or invalid, we do NOT translate and
///   simply return the original text.
class TranslationService {
  TranslationService();

  // DeepSeek configuration loaded lazily from the configs table.
  String? _deepseekKey;
  String? _deepseekModel;
  bool _deepseekLoaded = false;

  final LogDao _logDao = LogDao();

  // Persistent translation cache (SQLite)
  final TranslationCacheDao _translationCacheDao = TranslationCacheDao();

  // In-memory cache: key = "<target>|<text>"
  final Map<String, String> _cache = <String, String>{};

  void clearCache() => _cache.clear();

  /// Read a cached translation without triggering any network call.
  ///
  /// Returns null when no cached translation exists (or when target is 'en').
  Future<String?> getCachedTranslation({required String text, required String target}) async {
    if (target == 'en' || text.trim().isEmpty) return null;

    final memKey = '$target|$text';
    final mem = _cache[memKey];
    if (mem != null && mem.trim().isNotEmpty && mem.trim() != text.trim()) {
      return mem;
    }

    await _ensureDeepseek();
    final model = _deepseekModel ?? 'deepseek-chat';
    final cacheKey = _hashKey(model: model, target: target, sourceText: text);
    try {
      final dbCached = await _translationCacheDao.getTranslatedText(cacheKey);
      if (dbCached != null && dbCached.trim().isNotEmpty && dbCached.trim() != text.trim()) {
        _cache[memKey] = dbCached;
        return dbCached;
      }
    } catch (_) {
      // ignore cache read errors
    }
    return null;
  }

  /// Ensure the DeepSeek API key and model are loaded from the database.
  Future<void> _ensureDeepseek() async {
    // If we already loaded and have a non-empty key, keep it.
    // If key was empty earlier, re-check so newly saved keys take effect.
    if (_deepseekLoaded && (_deepseekKey?.trim().isNotEmpty ?? false)) return;
    try {
      final cfg = await ConfigDao().getOne();
      final key = cfg['deepseek_key'] ?? '';
      final model = cfg['deepseek_model'] ?? 'deepseek-chat';
      _deepseekKey = key.toString().trim();
      final m = model.toString().trim();
      _deepseekModel = m.isEmpty ? 'deepseek-chat' : m;
    } catch (_) {
      _deepseekKey = '';
      _deepseekModel = 'deepseek-chat';
    }
    _deepseekLoaded = true;
  }

  /// Translate [text] into [target] using the DeepSeek API.
  ///
  /// Returns the original [text] when key/model is missing, invalid, or
  /// any error occurs.
  Future<String> _translateViaDeepseek({required String text, required String target}) async {
    await _ensureDeepseek();
    final key = _deepseekKey;
    final model = _deepseekModel ?? 'deepseek-chat';
    if (key == null || key.trim().isEmpty) return text;

    // Write Chinese logs into existing logs table.
    try {
      await _logDao.add(
        taskUid: 'system',
        detail: 'DeepSeek翻译开始：目标语言=$target，模型=$model，输入长度=${text.length}',
      );
    } catch (_) {}

    // Map UI language codes to language names expected by DeepSeek.
    String langName;
    switch (target) {
      case 'zh':
        langName = 'Chinese';
        break;
      case 'ja':
        langName = 'Japanese';
        break;
      case 'ko':
        langName = 'Korean';
        break;
      case 'es':
        langName = 'Spanish';
        break;
      case 'fr':
        langName = 'French';
        break;
      case 'de':
        langName = 'German';
        break;
      case 'ru':
        langName = 'Russian';
        break;
      case 'ar':
        langName = 'Arabic';
        break;
      case 'pt':
        langName = 'Portuguese';
        break;
      default:
        langName = target;
    }
    final prompt =
        'Translate the following text into $langName. Just return the translation without explanation: $text';
    final body = jsonEncode({
      'model': model,
      'messages': [
        {
          'role': 'user',
          'content': prompt,
        },
      ],
      'stream': false,
    });
    http.Response res;
    try {
      // DeepSeek is OpenAI-compatible; endpoints can be either:
      // - https://api.deepseek.com/chat/completions
      // - https://api.deepseek.com/v1/chat/completions
      final primary = Uri.parse('https://api.deepseek.com/chat/completions');
      res = await http
          .post(
            primary,
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $key',
            },
            body: body,
          )
          .timeout(const Duration(seconds: 30));
      if (res.statusCode == 404) {
        final fallback = Uri.parse('https://api.deepseek.com/v1/chat/completions');
        res = await http
            .post(
              fallback,
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $key',
              },
              body: body,
            )
            .timeout(const Duration(seconds: 30));
      }
    } catch (e) {
      try {
        await _logDao.add(taskUid: 'system', detail: 'DeepSeek翻译请求失败：网络/超时错误=$e');
      } catch (_) {}
      return text;
    }

    try {
      await _logDao.add(
        taskUid: 'system',
        detail: 'DeepSeek翻译HTTP返回：status=${res.statusCode}，响应长度=${res.body.length}',
      );
    } catch (_) {}

    if (res.statusCode != 200) {
      try {
        await _logDao.add(taskUid: 'system', detail: 'DeepSeek翻译失败：HTTP状态非200，status=${res.statusCode}');
      } catch (_) {}
      return text;
    }

    try {
      final data = jsonDecode(res.body);
      if (data is Map<String, dynamic>) {
        final choices = data['choices'];
        if (choices is List && choices.isNotEmpty) {
          final message = choices.first['message'];
          if (message is Map<String, dynamic>) {
            final content = (message['content'] ?? '').toString().trim();
            if (content.isNotEmpty) {
              try {
                await _logDao.add(taskUid: 'system', detail: 'DeepSeek翻译成功：输出长度=${content.length}');
              } catch (_) {}
              return content;
            }
          }
        }
      }
      try {
        await _logDao.add(taskUid: 'system', detail: 'DeepSeek翻译解析失败：无法从choices.message.content取到内容');
      } catch (_) {}
      return text;
    } catch (e) {
      try {
        await _logDao.add(taskUid: 'system', detail: 'DeepSeek翻译解析异常：$e');
      } catch (_) {}
      return text;
    }
  }

  /// Translate a single [text] from English to [target].
  /// Returns the original [text] if DeepSeek is not configured/invalid.
  Future<String> translateOne({
    required String text,
    required String target,
  }) async {
    if (target == 'en' || text.trim().isEmpty) return text;
    final memKey = '$target|$text';
    final cached = _cache[memKey];
    if (cached != null) return cached;

    // Ensure we know which model is currently configured before reading/writing
    // persistent cache.
    await _ensureDeepseek();

    // Check persistent cache first (only for successful translations).
    final model = _deepseekModel ?? 'deepseek-chat';
    final cacheKey = _hashKey(model: model, target: target, sourceText: text);
    try {
      final dbCached = await _translationCacheDao.getTranslatedText(cacheKey);
      if (dbCached != null && dbCached.trim().isNotEmpty) {
        _cache[memKey] = dbCached;
        return dbCached;
      }
    } catch (_) {
      // ignore cache read errors
    }

    final translated = await _translateViaDeepseek(text: text, target: target);
    // Only cache when it is actually different.
    if (translated.trim().isNotEmpty && translated.trim() != text.trim()) {
      _cache[memKey] = translated;
      // Persist the successful translation.
      try {
        await _translationCacheDao.put(
          cacheKey: cacheKey,
          model: model,
          target: target,
          sourceText: text,
          translatedText: translated,
        );
      } catch (_) {
        // ignore persistence failures
      }
      return translated;
    }
    return text;
  }

  String _hashKey({required String model, required String target, required String sourceText}) {
    final bytes = utf8.encode('$model|$target|$sourceText');
    return sha1.convert(bytes).toString();
  }

  /// Backward-compatible wrapper used by UI code.
  ///
  /// The Space module calls `translateTexts(texts, targetLang: ...)`.
  /// We keep this wrapper so the rest of the code can stay clean.
  Future<List<String>> translateTexts(
    List<String> texts, {
    required String targetLang,
  }) async {
    return translateMany(texts: texts, target: targetLang);
  }

  /// Best-effort batch translation.
  ///
  /// To avoid dozens of network calls, we join texts with a delimiter
  /// and translate once. If parsing fails, we fall back to per-item
  /// translation.
  Future<List<String>> translateMany({
    required List<String> texts,
    required String target,
  }) async {
    if (target == 'en' || texts.isEmpty) return texts;
    // Use cache as much as possible.
    final out = List<String>.filled(texts.length, '');
    final toTranslate = <int, String>{};
    for (var i = 0; i < texts.length; i++) {
      final t = texts[i];
      if (t.trim().isEmpty) {
        out[i] = t;
        continue;
      }
      final cacheKey = '$target|$t';
      final cached = _cache[cacheKey];
      if (cached != null) {
        out[i] = cached;
      } else {
        toTranslate[i] = t;
      }
    }
    if (toTranslate.isEmpty) return out;
    for (final entry in toTranslate.entries) {
      out[entry.key] = await translateOne(text: entry.value, target: target);
    }
    return out;
  }
}
