import 'package:flutter/material.dart';
import 'entry_editor_page.dart';
import 'diary_dao.dart';

class EntryEditorPagerPage extends StatefulWidget {
  final int notebookId;
  final int initialEntryId;
  const EntryEditorPagerPage({super.key, required this.notebookId, required this.initialEntryId});

  @override
  State<EntryEditorPagerPage> createState() => _EntryEditorPagerPageState();
}

class _EntryEditorPagerPageState extends State<EntryEditorPagerPage> {
  final _dao = DiaryDao();
  final PageController _controller = PageController(initialPage: 1);
  int _globalIndex = 0;
  int _total = 0;
  final List<DiaryEntry> _pages = []; // store entry ids
  int _index = 1;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _pages.clear();
    final e = await _dao.getEntry(widget.initialEntryId); if (e != null) _pages.add(e);
    _total = await _dao.countEntries(widget.notebookId);
    final pos = await _dao.positionOfEntry(widget.notebookId, widget.initialEntryId) ?? 0;
    setState(() { _globalIndex = pos; });
  }

  Future<bool> _ensureOlder() async {
    if (_pages.isEmpty) return false;
    final cur = _pages.last;
    final older = await _dao.neighbor(notebookId: widget.notebookId, cur: cur, newer: false);
    if (older == null) return false;
    setState(() { _pages.add(older); });
    return true;
  }

  Future<bool> _ensureNewer() async {
    if (_pages.isEmpty) return false;
    final cur = _pages.first;
    final newer = await _dao.neighbor(notebookId: widget.notebookId, cur: cur, newer: true);
    if (newer == null) return false;
    setState(() { _pages.insert(0, newer); _index++; });
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(children:[
          PageView.builder(
          allowImplicitScrolling: true,
          physics: EdgeLockPagePhysics(
            lockToStart: _total > 0 && _globalIndex <= 0,
            lockToEnd: _total > 0 && _globalIndex >= _total - 1,
          ),
          controller: _controller,
          itemCount: _pages.length + 2,
          onPageChanged: (i) async {
            if (i == _pages.length + 1) {
              final ok = await _ensureOlder();
              if (ok == true) {
                setState(() { _index = _pages.length; _globalIndex = (_globalIndex + 1).clamp(0, _total-1); });
                if (mounted) _controller.jumpToPage(_pages.length);
              } else {
                if (mounted) _controller.jumpToPage(_pages.length);
              }
              return;
            }
            if (i == 0) {
              final ok = await _ensureNewer();
              if (ok == true) {
                setState(() { _index = 1; _globalIndex = (_globalIndex - 1).clamp(0, _total-1); });
                if (mounted) _controller.jumpToPage(1);
              } else {
                if (mounted) _controller.jumpToPage(1);
              }
              return;
            }
            final prev = _index;
            setState(() { _index = i; _globalIndex = (_globalIndex + (i - prev)).clamp(0, _total-1); });
          },
          itemBuilder: (ctx, i) {
            if (i == 0 || i == _pages.length + 1) {
              return const SizedBox.shrink();
            }
            final e = _pages[i - 1];
            // IMPORTANT:
            // When swiping (especially from oldest -> newest), the PageView may
            // reuse element states at the same page index. Without a stable key,
            // the EntryEditorPage's State can keep showing the previous entry's
            // content even though the page counter has changed.
            return EntryEditorPage(
              key: ValueKey<int>(e.id),
              notebookId: widget.notebookId,
              entryId: e.id,
            );
          },
        ),
          Positioned(
            bottom: 0,
            left: 0,
            child: SafeArea(top: false, minimum: EdgeInsets.zero, child: DecoratedBox(
              decoration: const BoxDecoration(color: Colors.black54),
              child: Text('${_globalIndex + 1}/$_total', style: const TextStyle(color: Colors.white)),
            )),
          ),
        ]),
      ),
    );
  }
}

// Copied minimal physics from reader to keep UX identical
class EdgeLockPagePhysics extends ScrollPhysics {
  final bool lockToStart; // 锁定上一页（首条时）
  final bool lockToEnd;   // 锁定下一页（末条时）
  const EdgeLockPagePhysics({this.lockToStart=false, this.lockToEnd=false, ScrollPhysics? parent}) : super(parent: parent);

  @override
  EdgeLockPagePhysics applyTo(ScrollPhysics? ancestor) {
    return EdgeLockPagePhysics(lockToStart: lockToStart, lockToEnd: lockToEnd, parent: buildParent(ancestor));
  }

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) {
    if (lockToStart && offset < 0) return 0.0; // 首页禁止右滑
    if (lockToEnd && offset > 0) return 0.0;   // 末页禁止左滑
    return super.applyPhysicsToUserOffset(position, offset);
  }

  @override
  double applyBoundaryConditions(ScrollMetrics position, double value) {
    final delta = value - position.pixels;
    if (lockToStart && delta < 0) return delta; // 试图到上一页
    if (lockToEnd && delta > 0) return delta;   // 试图到下一页
    return super.applyBoundaryConditions(position, value);
  }
}