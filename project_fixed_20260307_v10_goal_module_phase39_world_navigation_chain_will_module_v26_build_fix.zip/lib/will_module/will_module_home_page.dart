import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'will_dao.dart';
import 'will_models.dart';
import 'will_seed.dart';
import 'will_unit_index_seed.dart';
import 'will_deep_content_seed.dart';
import 'will_route_link_seed.dart';
import 'will_route_resolver.dart';
import 'will_dashboard_support.dart';


class WillModuleHomePage extends StatelessWidget {
  const WillModuleHomePage({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(CupertinoPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final featured = kWillKnowledgeCards.take(3).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('意志实验室')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          const _HeroCard(
            title: '把“知道”变成“做到”',
            subtitle: '基于《心理学原理》第 26 章《意志》的独立模块：用知识库、问题诊断、微任务、复盘闭环与镜像城场景，帮助用户在真实生活里训练意志。',
            chips: ['209 个知识单元', '首批 30 张核心卡', '任务闭环', '镜像城', '知行合一'],
          ),
          const SizedBox(height: 14),
          _StatsCard(onOpenDashboard: () => _open(context, const WillDashboardPage())),
          const SizedBox(height: 14),
          const _SectionTitle('核心入口'),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.dashboard_outlined,
            title: '意志训练总览',
            subtitle: '查看计划、执行、复盘与任务链路，看到自己正在形成的训练历史。',
            onTap: () => _open(context, const WillDashboardPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.account_tree_outlined,
            title: '知识总览',
            subtitle: '查看章节结构、首批 30 张知识卡，并按问题回溯到概念。',
            onTap: () => _open(context, const WillKnowledgeMapPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.route_outlined,
            title: '课程学习路线',
            subtitle: '按“导论 83 段 → 观念—运动作用 19 段 → 其余模块”的顺序进入课程式学习。',
            onTap: () => _open(context, const WillStudyRoadmapPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.format_list_bulleted_outlined,
            title: '209 单元总表',
            subtitle: '按导论 / 观念—运动 / 审议 / 努力 / 爆发 / 阻塞 / 教育完整浏览本章知识索引。',
            onTap: () => _open(context, const WillUnitIndexPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.psychology_alt_outlined,
            title: '问题诊断',
            subtitle: '从拖延、冲动、犹豫、无力等问题出发，定位对应机制与任务。',
            onTap: () => _open(context, const WillProblemDiagnosisPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.task_alt_outlined,
            title: '现实任务中心',
            subtitle: '围绕“启动、延迟、锁定、复盘”执行最小行动，并形成 if-then 计划。',
            onTap: () => _open(context, const WillTaskHubPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.history_edu_outlined,
            title: '复盘中心',
            subtitle: '记录主导观念、对抗观念、努力点与明日计划，建立知行闭环。',
            onTap: () => _open(context, const WillReviewCenterPage()),
          ),
          const SizedBox(height: 10),
          _EntryCard(
            icon: Icons.landscape_outlined,
            title: '镜像城',
            subtitle: '起意场 / 努力坡 / 诱惑市集 / 阻塞谷，把现实难题先在虚拟世界里练一遍。',
            onTap: () => _open(context, const WillWorldPage()),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('首批核心知识卡'),
          const SizedBox(height: 10),
          ...featured.map((card) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _KnowledgeCardTile(
                  card: card,
                  onTap: () => _open(context, WillCardDetailPage(cardId: card.id)),
                ),
              )),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => _open(context, const WillCardLibraryPage()),
            icon: const Icon(Icons.library_books_outlined),
            label: const Text('查看首批 30 张知识卡'),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('落地方式'),
          const SizedBox(height: 10),
          const _InfoCard(
            lines: [
              '本模块作为独立入口接入现有 App 左侧菜单，不影响原有首页、发现之旅、日记与其他主题模块。',
              'MVP 阶段先落地知识总览、问题诊断、任务中心、复盘中心与镜像城四大场景。',
              '后续可继续扩展为完整 209 段知识卡数据库、个性化推荐、进度追踪与 AI 教练。',
            ],
          ),
        ],
      ),
    );
  }
}

class WillDashboardPage extends StatefulWidget {
  const WillDashboardPage({super.key});

  @override
  State<WillDashboardPage> createState() => _WillDashboardPageState();
}

class _WillDashboardPageState extends State<WillDashboardPage> {
  final WillDao dao = WillDao();
  late Future<DashboardBundle> _future;
  String? _shownStageTransitionToken;

  void _maybeCelebrateStageChange(DashboardBundle data, CoachStage coachStage) {
    final state = data.stageRuntimeState;
    if (!isRecentStageChange(state)) return;
    if (state == null) return;
    if (state.notifiedAtMs >= state.changedAtMs) return;
    final token = '${state.previousStageKey}->${state.currentStageKey}@${state.changedAtMs}';
    if (_shownStageTransitionToken == token) return;
    _shownStageTransitionToken = token;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: const Color(0xFF1F2937),
          content: Text('阶段升级：你已进入“${coachStage.stageLabel}”。接下来先完成这一步：${coachStage.actionLabel}'),
          action: SnackBarAction(
            label: '去完成',
            textColor: const Color(0xFF93C5FD),
            onPressed: () {
              _openCoachStage(coachStage);
            },
          ),
          duration: const Duration(seconds: 5),
        ),
      );
      await dao.markStageChangeNotified();
      if (mounted) {
        await _reload();
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<DashboardBundle> _load() async {
    final summary = await dao.getDashboardSummary();
    final chains = await dao.getTaskChainSummaries(limit: 20);
    final allReviews = await dao.getRecentReviews(limit: 200);
    final allExecutions = await dao.getRecentTaskExecutions(limit: 200);
    final allZoneVisits = await dao.getRecentZoneVisits(limit: 120);
    final zoneCounts = await dao.getZoneVisitCounts(limit: 8);
    final problemHits = problemHitsFromExecutions(allExecutions);
    final taskTypeCounts = taskTypeCountsFromExecutions(allExecutions);
    final weakestTaskTypes = weakestTaskTypesFromExecutions(allExecutions);
    final streak = currentTrainingStreak(
      executions: allExecutions,
      reviews: allReviews,
      zones: allZoneVisits,
    );
    final dailyActivity = lastNDayActivity(
      executions: allExecutions,
      reviews: allReviews,
      zones: allZoneVisits,
      days: 7,
    );
    final effortDistribution = effortDistribution(allExecutions);
    final tempBundle = DashboardBundle(
      summary: summary,
      chains: chains,
      reviews: allReviews.take(6).toList(),
      executions: allExecutions.take(20).toList(),
      allReviews: allReviews,
      allExecutions: allExecutions,
      zoneCounts: zoneCounts,
      recentZoneVisits: allZoneVisits.take(6).toList(),
      problemHits: problemHits,
      taskTypeCounts: taskTypeCounts,
      weakestTaskTypes: weakestTaskTypes,
      streak: streak,
      dailyActivity: dailyActivity,
      effortDistribution: effortDistribution,
      suggestionStates: const <String, WillSuggestionState>{},
      stageMilestones: const [],
      stageRuntimeState: null,
    );
    final stageStatuses = evaluateStageStatuses(tempBundle);
    for (final status in stageStatuses.where((s) => s.achieved)) {
      await dao.ensureStageMilestone(stageKey: status.key, stageLabel: status.label, detail: status.detail);
    }
    final suggestionStates = await dao.getSuggestionStates();
    final milestones = await dao.getStageMilestones(limit: 12);
    var bundle = DashboardBundle(
      summary: summary,
      chains: chains,
      reviews: allReviews.take(6).toList(),
      executions: allExecutions.take(20).toList(),
      allReviews: allReviews,
      allExecutions: allExecutions,
      zoneCounts: zoneCounts,
      recentZoneVisits: allZoneVisits.take(6).toList(),
      problemHits: problemHits,
      taskTypeCounts: taskTypeCounts,
      weakestTaskTypes: weakestTaskTypes,
      streak: streak,
      dailyActivity: dailyActivity,
      effortDistribution: effortDistribution,
      suggestionStates: { for (final s in suggestionStates) s.suggestionKey: s },
      stageMilestones: milestones,
      stageRuntimeState: null,
    );
    final coachStage = buildCoachStage(bundle);
    final stageRuntimeState = await dao.syncCurrentStage(currentStageKey: coachStage.key);
    bundle = DashboardBundle(
      summary: summary,
      chains: chains,
      reviews: allReviews.take(6).toList(),
      executions: allExecutions.take(20).toList(),
      allReviews: allReviews,
      allExecutions: allExecutions,
      zoneCounts: zoneCounts,
      recentZoneVisits: allZoneVisits.take(6).toList(),
      problemHits: problemHits,
      taskTypeCounts: taskTypeCounts,
      weakestTaskTypes: weakestTaskTypes,
      streak: streak,
      dailyActivity: dailyActivity,
      effortDistribution: effortDistribution,
      suggestionStates: { for (final s in suggestionStates) s.suggestionKey: s },
      stageMilestones: milestones,
      stageRuntimeState: stageRuntimeState,
    );
    return bundle;
  }

  Future<void> _reload() async {
    setState(() {
      _future = _load();
    });
  }

  Future<void> _openSuggestion(SmartSuggestion s) async {
    await dao.markSuggestionOpened(s.key);
    if (!mounted) return;
    if (s.kind == 'task') {
      final task = WillRouteResolver.taskByTitle(s.refTitle);
      if (task != null) {
        await Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillTaskDetailPage(task: task)));
      }
    } else if (s.kind == 'zone') {
      final matches = kWillWorldZones.where((z) => z.title == s.refTitle).toList();
      if (matches.isNotEmpty) {
        await Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillWorldZoneDetailPage(zone: matches.first)));
      }
    } else if (s.kind == 'problem') {
      final matches = kWillProblemPaths.where((p) => p.title == s.refTitle).toList();
      if (matches.isNotEmpty) {
        await Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillProblemDetailPage(problem: matches.first)));
      }
    } else if (s.kind == 'review') {
      final latestExecution = await dao.getLatestTaskExecutionForTask(s.refTitle);
      await Navigator.of(context).push(CupertinoPageRoute(
        builder: (_) => WillReviewCenterPage(
          initialTaskTitle: s.refTitle,
          initialExecution: latestExecution,
        ),
      ));
    }
    await _reload();
  }

  Future<void> _completeSuggestion(SmartSuggestion s) async {
    await dao.markSuggestionCompleted(s.key);
    await _reload();
  }

  Future<void> _openCoachStage(CoachStage stage) async {
    if (stage.kind == 'task') {
      final task = WillRouteResolver.taskByTitle(stage.refTitle);
      if (task != null) {
        await Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillTaskDetailPage(task: task)));
      }
    } else if (stage.kind == 'zone') {
      final matches = kWillWorldZones.where((z) => z.title == stage.refTitle).toList();
      if (matches.isNotEmpty) {
        await Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillWorldZoneDetailPage(zone: matches.first)));
      }
    } else if (stage.kind == 'review') {
      final latestExecution = await dao.getLatestTaskExecutionForTask(stage.refTitle);
      await Navigator.of(context).push(CupertinoPageRoute(
        builder: (_) => WillReviewCenterPage(
          initialTaskTitle: stage.refTitle,
          initialExecution: latestExecution,
        ),
      ));
    }
    await _reload();
  }

  String _fmt(int ms) {
    if (ms <= 0) return '—';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String two(int v) => v.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('意志训练总览')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: FutureBuilder<DashboardBundle>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!;
          final coachStage = buildCoachStage(data);
          _maybeCelebrateStageChange(data, coachStage);
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('训练历史概览', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(child: _MiniStat(label: '已保存计划', value: '${data.summary.planCount}')),
                        const SizedBox(width: 10),
                        Expanded(child: _MiniStat(label: '累计执行', value: '${data.summary.executionCount}')),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(child: _MiniStat(label: '复盘记录', value: '${data.summary.reviewCount}')),
                        const SizedBox(width: 10),
                        Expanded(child: _MiniStat(label: '任务链路', value: '${data.summary.taskCount}')),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(child: _MiniStat(label: '镜像城访问', value: '${data.summary.zoneVisitCount}')),
                        const SizedBox(width: 10),
                        Expanded(child: _MiniStat(label: '训练类型', value: '${data.taskTypeCounts.where((e) => e.count > 0).length}/4')),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              const _SectionTitle('当前训练阶段'),
              const SizedBox(height: 8),
              CoachStageCard(
                stage: coachStage,
                onTap: () => _openCoachStage(coachStage),
              ),
              if (isRecentStageChange(data.stageRuntimeState)) ...[
                const SizedBox(height: 10),
                _StageTransitionCard(
                  previousLabel: stageLabelFromKey(data.stageRuntimeState!.previousStageKey),
                  currentLabel: stageLabelFromKey(data.stageRuntimeState!.currentStageKey),
                  changedAtLabel: _fmt(data.stageRuntimeState!.changedAtMs),
                  nextActionLabel: coachStage.actionLabel,
                  onTakeNextStep: () => _openCoachStage(coachStage),
                ),
              ],
              const SizedBox(height: 14),
              const _SectionTitle('阶段徽章与里程碑'),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('已解锁阶段徽章', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (data.stageMilestones.isEmpty)
                      const Text('还没有完成阶段徽章。先完成当前阶段的 3 条条件，这里会点亮第一枚徽章。', style: TextStyle(color: Color(0xFF6B7280), height: 1.5))
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: data.stageMilestones.map((m) => _StageBadgeChip(milestone: m)).toList(),
                      ),
                    const SizedBox(height: 14),
                    const Text('阶段历史时间线', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (data.stageMilestones.isEmpty)
                      const Text('当一个阶段的 3 条条件全部满足后，这里会记录它被点亮的时间。', style: TextStyle(color: Color(0xFF6B7280), height: 1.5))
                    else ...[
                      ...data.stageMilestones.reversed.take(6).map((m) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: _StageTimelineItem(
                              milestone: m,
                              timeLabel: _fmt(m.achievedAtMs),
                            ),
                          )),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 14),
              const _SectionTitle('训练节奏'),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: _MiniStat(label: '连续训练', value: '${data.streak} 天')),
                        const SizedBox(width: 10),
                        Expanded(child: _MiniStat(label: '近7天活跃日', value: '${data.dailyActivity.where((e) => e.total > 0).length}/7')),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const Text('最近 7 天训练热力', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        for (final day in data.dailyActivity)
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 3),
                              child: _HeatDayCell(day: day),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const Text('每日 effort 分布', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (data.effortDistribution.every((e) => e.count == 0))
                      const Text('还没有执行记录，记录几次任务执行后，这里会显示你的 effort 分布。', style: TextStyle(color: Color(0xFF6B7280), height: 1.5))
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: data.effortDistribution.map((e) => _TagChip('${e.label} ×${e.count}')).toList(),
                      ),
                    const SizedBox(height: 14),
                    const Text('最近 7 天训练节奏', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    ...data.dailyActivity.map((day) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: _DayTrendRow(day: day),
                        )),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              const _SectionTitle('训练偏向'),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('最近最常命中的问题路径', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (data.problemHits.isEmpty)
                      const Text('暂无足够执行记录，先完成几次现实任务再看训练偏向。', style: TextStyle(color: Color(0xFF6B7280), height: 1.5))
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: data.problemHits.take(4).map((e) => _TagChip('${e.label} ×${e.count}')).toList(),
                      ),
                    const SizedBox(height: 14),
                    const Text('最近最常进入的镜像城区域', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (data.zoneCounts.isEmpty)
                      const Text('还没有镜像城访问记录。进入任一区域后，这里会开始显示你的偏好。', style: TextStyle(color: Color(0xFF6B7280), height: 1.5))
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: data.zoneCounts.take(4).map((e) => _TagChip('${e.label} ×${e.count}')).toList(),
                      ),
                    const SizedBox(height: 14),
                    const Text('当前较少训练的动作类型', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: data.weakestTaskTypes.take(4).map((e) => _TagChip('${e.label} ×${e.count}')).toList(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              const _SectionTitle('智能建议'),
              const SizedBox(height: 8),
              ...buildSmartSuggestions(data).map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: SmartSuggestionCard(
                      suggestion: s,
                      onTap: () => _openSuggestion(s),
                      onComplete: () => _completeSuggestion(s),
                    ),
                  )),
              const SizedBox(height: 14),
              const _SectionTitle('按任务查看链路'),
              const SizedBox(height: 8),
              if (data.chains.isEmpty)
                const _InfoCard(lines: ['还没有链路数据。先在“现实任务中心”里保存一条 if-then 计划，并记录一次执行或复盘。'])
              else
                ...data.chains.map((item) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 6))],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.taskTitle, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _TagChip('计划 ${item.planCount}'),
                                _TagChip('执行 ${item.executionCount}'),
                                _TagChip('复盘 ${item.reviewCount}'),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text('最近执行：${_fmt(item.latestExecutionAtMs)}', style: const TextStyle(color: Color(0xFF6B7280))),
                            const SizedBox(height: 4),
                            Text('最近复盘：${_fmt(item.latestReviewAtMs)}', style: const TextStyle(color: Color(0xFF6B7280))),
                          ],
                        ),
                      ),
                    )),
              const SizedBox(height: 14),
              const _SectionTitle('最近执行'),
              const SizedBox(height: 8),
              if (data.executions.isEmpty)
                const _InfoCard(lines: ['还没有执行记录。去“现实任务中心”完成一次微行动即可在这里看到历史。'])
              else
                ...data.executions.map((e) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _SimpleRowCard(
                        title: e.taskTitle,
                        subtitle: '努力等级 ${e.effortLevel}｜${_fmt(e.completedAtMs)}\n${e.note.isEmpty ? '无备注' : e.note}',
                      ),
                    )),
              const SizedBox(height: 14),
              const _SectionTitle('最近进入的镜像城区域'),
              const SizedBox(height: 8),
              if (data.recentZoneVisits.isEmpty)
                const _InfoCard(lines: ['还没有镜像城访问记录。进入任一镜像城场景后，这里会显示你的最近访问历史。'])
              else
                ...data.recentZoneVisits.map((z) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _SimpleRowCard(
                        title: z.zoneTitle,
                        subtitle: _fmt(z.visitedAtMs),
                      ),
                    )),
              const SizedBox(height: 14),
              const _SectionTitle('最近复盘'),
              const SizedBox(height: 8),
              if (data.reviews.isEmpty)
                const _InfoCard(lines: ['还没有复盘记录。一次复盘就能让模块开始生成真正的“知—行—思”历史。'])
              else
                ...data.reviews.map((r) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _SimpleRowCard(
                        title: r.taskTitle.isEmpty ? '未绑定任务的复盘' : r.taskTitle,
                        subtitle: '${_fmt(r.updatedAtMs)}\n主导观念：${r.dominantIdea.isEmpty ? '（未填写）' : r.dominantIdea}\n动作：${r.actionTaken.isEmpty ? '（未填写）' : r.actionTaken}',
                      ),
                    )),
            ],
          );
        },
      ),
    );
  }
}



class _StatsCard extends StatelessWidget {
  final VoidCallback? onOpenDashboard;
  const _StatsCard({this.onOpenDashboard});

  @override
  Widget build(BuildContext context) {
    final dao = WillDao();
    return FutureBuilder<WillDashboardSummary>(
      future: dao.getDashboardSummary(),
      builder: (context, snapshot) {
        final summary = snapshot.data;
        final loading = snapshot.connectionState != ConnectionState.done && summary == null;
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text('意志训练总览', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                  if (onOpenDashboard != null)
                    TextButton.icon(
                      onPressed: onOpenDashboard,
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('查看全部'),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _MiniStat(label: '计划', value: loading ? '...' : '${summary?.planCount ?? 0}')),
                  const SizedBox(width: 10),
                  Expanded(child: _MiniStat(label: '执行', value: loading ? '...' : '${summary?.executionCount ?? 0}')),
                  const SizedBox(width: 10),
                  Expanded(child: _MiniStat(label: '复盘', value: loading ? '...' : '${summary?.reviewCount ?? 0}')),
                  const SizedBox(width: 10),
                  Expanded(child: _MiniStat(label: '链路', value: loading ? '...' : '${summary?.taskCount ?? 0}')),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                loading
                    ? '正在读取本地训练数据…'
                    : '你已经留下了 ${summary?.planCount ?? 0} 条计划、${summary?.executionCount ?? 0} 次执行、${summary?.reviewCount ?? 0} 条复盘，形成了 ${summary?.taskCount ?? 0} 条任务链路。',
                style: const TextStyle(color: Color(0xFF6B7280), height: 1.45),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SimpleRowCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SimpleRowCard({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 10, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: Color(0xFF6B7280), height: 1.4)),
        ],
      ),
    );
  }
}



class _StageTransitionCard extends StatelessWidget {
  final String previousLabel;
  final String currentLabel;
  final String changedAtLabel;
  final String nextActionLabel;
  final VoidCallback onTakeNextStep;

  const _StageTransitionCard({
    required this.previousLabel,
    required this.currentLabel,
    required this.changedAtLabel,
    required this.nextActionLabel,
    required this.onTakeNextStep,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFEEF2FF), Color(0xFFF5F3FF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFC7D2FE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.celebration_outlined, color: Color(0xFF4F46E5), size: 18),
              SizedBox(width: 8),
              Text('阶段切换提示', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFF312E81))),
            ],
          ),
          const SizedBox(height: 8),
          Text('你已从“$previousLabel”进入“$currentLabel”。', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
          const SizedBox(height: 6),
          Text('记录时间：$changedAtLabel\n这说明你的训练状态已经跨过了上一个阶段。现在最值得做的，是顺着当前阶段的重点继续推进，而不是回头把所有事重做一遍。', style: const TextStyle(color: Color(0xFF4B5563), height: 1.5)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFFFF),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFC7D2FE)),
            ),
            child: Row(
              children: [
                const Icon(Icons.flag_outlined, color: Color(0xFF4F46E5), size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('进入新阶段后的第一步：$nextActionLabel', style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF312E81))),
                ),
                const SizedBox(width: 8),
                FilledButton.tonal(
                  onPressed: onTakeNextStep,
                  child: const Text('现在去做'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StageTimelineItem extends StatelessWidget {
  final WillStageMilestoneEntry milestone;
  final String timeLabel;

  const _StageTimelineItem({required this.milestone, required this.timeLabel});

  @override
  Widget build(BuildContext context) {
    final color = _stageColor(milestone.stageKey);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            Container(width: 2, height: 52, color: color.withOpacity(0.22)),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text('${milestone.stageLabel} 已点亮', style: const TextStyle(fontWeight: FontWeight.w800))),
                    Text(timeLabel, style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
                  ],
                ),
                const SizedBox(height: 6),
                Text(milestone.detail, style: const TextStyle(color: Color(0xFF4B5563), height: 1.45)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class CoachStageCard extends StatelessWidget {
  final CoachStage stage;
  final VoidCallback? onTap;

  const CoachStageCard({required this.stage, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: _stageColor(stage.key).withOpacity(0.10),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(stage.stageLabel, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: _stageColor(stage.key))),
              ),
              const SizedBox(width: 8),
              if (stage.completed)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFECFDF5),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: const Color(0xFFA7F3D0)),
                  ),
                  child: const Text('阶段已点亮', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFF047857))),
                ),
              const Spacer(),
              Icon(_stageIcon(stage.key), color: _stageColor(stage.key), size: 18),
            ],
          ),
          const SizedBox(height: 12),
          Text(stage.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(stage.subtitle, style: const TextStyle(color: Color(0xFF4B5563), height: 1.55)),
          const SizedBox(height: 12),
          const Text('这个阶段先抓 3 件事', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          ...stage.focusPoints.map((e) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(top: 3),
                      child: Icon(Icons.check_circle_outline, size: 16, color: Color(0xFF2563EB)),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(e, style: const TextStyle(color: Color(0xFF374151), height: 1.45))),
                  ],
                ),
              )),
          if (stage.unitIds.isNotEmpty) ...[
            const SizedBox(height: 10),
            const Text('这一阶段建议先学', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: stage.unitIds
                  .map((id) => WillRouteResolver.unitById(id))
                  .whereType<WillUnitIndex>()
                  .map((unit) => InkWell(
                        borderRadius: BorderRadius.circular(999),
                        onTap: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillUnitIndexDetailPage(unit: unit))),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8FAFC),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: const Color(0xFFE5E7EB)),
                          ),
                          child: Text('${unit.id} · ${unit.title}', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                        ),
                      ))
                  .toList(),
            ),
          ],
          const SizedBox(height: 12),
          const Text('阶段完成条件', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(stage.progressLabel, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF2563EB))),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: progressValue(stage.checkpoints),
                    minHeight: 8,
                    backgroundColor: const Color(0xFFE5E7EB),
                    valueColor: const AlwaysStoppedAnimation(Color(0xFF2563EB)),
                  ),
                ),
                const SizedBox(height: 10),
                ...stage.checkpoints.map((c) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(
                        children: [
                          Icon(
                            c.done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                            size: 18,
                            color: c.done ? const Color(0xFF10B981) : const Color(0xFF9CA3AF),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              c.label,
                              style: TextStyle(
                                color: c.done ? const Color(0xFF111827) : const Color(0xFF6B7280),
                                fontWeight: c.done ? FontWeight.w600 : FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
            ),
          ),
          if (stage.completed) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFECFDF5),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFA7F3D0)),
              ),
              child: const Text('当前阶段已达成，继续完成下一个动作，就会更自然地进入下一阶段。', style: TextStyle(color: Color(0xFF065F46), height: 1.5, fontWeight: FontWeight.w700)),
            ),
          ],
          const SizedBox(height: 12),
          const Text('下一阶段预告', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFBEB),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFFDE68A)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(stage.nextStageLabel, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: Color(0xFF92400E))),
                const SizedBox(height: 6),
                Text(stage.nextStageHint, style: const TextStyle(color: Color(0xFF6B7280), height: 1.5)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: onTap,
            icon: const Icon(Icons.trending_up_outlined),
            label: Text(stage.actionLabel),
          ),
        ],
      ),
    );
  }
}

class SmartSuggestionCard extends StatelessWidget {
  final SmartSuggestion suggestion;
  final VoidCallback? onTap;
  final VoidCallback? onComplete;
  const SmartSuggestionCard({required this.suggestion, this.onTap, this.onComplete});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF2FF),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.tips_and_updates_outlined, color: Color(0xFF2563EB), size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(suggestion.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _Badge(suggestion.priorityLabel),
              _Badge(suggestion.horizonLabel),
            ],
          ),
          const SizedBox(height: 10),
          Text(suggestion.subtitle, style: const TextStyle(color: Color(0xFF4B5563), height: 1.55)),
          if (suggestion.unitIds.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('推荐先学', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: suggestion.unitIds
                  .map((id) => WillRouteResolver.unitById(id))
                  .whereType<WillUnitIndex>()
                  .map((unit) => InkWell(
                        borderRadius: BorderRadius.circular(999),
                        onTap: () {
                          Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillUnitIndexDetailPage(unit: unit)));
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8FAFC),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: const Color(0xFFE5E7EB)),
                          ),
                          child: Text(
                            '${unit.id} · ${unit.title}',
                            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ))
                  .toList(),
            ),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              TextButton.icon(
                onPressed: onTap,
                icon: const Icon(Icons.arrow_forward_rounded, size: 18),
                label: Text(suggestion.actionLabel),
              ),
              OutlinedButton.icon(
                onPressed: onComplete,
                icon: const Icon(Icons.check_circle_outline_rounded, size: 18),
                label: const Text('已处理并刷新'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeatDayCell extends StatelessWidget {
  final DayActivitySummary day;
  const _HeatDayCell({required this.day});

  @override
  Widget build(BuildContext context) {
    final level = day.total >= 5 ? 1.0 : day.total >= 3 ? 0.75 : day.total >= 1 ? 0.45 : 0.12;
    return Column(
      children: [
        Container(
          height: 54,
          decoration: BoxDecoration(
            color: Color.lerp(const Color(0xFFE5E7EB), const Color(0xFF2563EB), level),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Center(
            child: Text(
              '${day.total}',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: level > 0.5 ? Colors.white : const Color(0xFF374151),
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text('${day.day.month}/${day.day.day}', style: const TextStyle(fontSize: 11, color: Color(0xFF6B7280))),
        const SizedBox(height: 2),
        Text('周${weekdayZh(day.day.weekday)}', style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF))),
      ],
    );
  }
}

class _DayTrendRow extends StatelessWidget {
  final DayActivitySummary day;
  const _DayTrendRow({required this.day});

  @override
  Widget build(BuildContext context) {
    final barWidth = (day.total * 28.0).clamp(12.0, 160.0);
    return Row(
      children: [
        SizedBox(
          width: 72,
          child: Text('${day.day.month}/${day.day.day} 周${weekdayZh(day.day.weekday)}', style: const TextStyle(color: Color(0xFF6B7280))),
        ),
        Expanded(
          child: Stack(
            children: [
              Container(
                height: 16,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
              Container(
                width: barWidth,
                height: 16,
                decoration: BoxDecoration(
                  color: day.total == 0 ? const Color(0xFFE5E7EB) : const Color(0xFF111827),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 84,
          child: Text(
            '执${day.executionCount} 复${day.reviewCount} 城${day.zoneCount}',
            textAlign: TextAlign.right,
            style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
          ),
        ),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));
  }
}

class _TagChip extends StatelessWidget {
  final String text;
  final bool dark;
  const _TagChip(this.text, {this.dark = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF111827) : const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: dark ? Colors.white : const Color(0xFF374151),
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  const _Badge(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFEEF2FF),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF3730A3))),
    );
  }
}

class _BulletLine extends StatelessWidget {
  final String text;
  const _BulletLine(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Text('• '),
          ),
          Expanded(child: Text(text, style: const TextStyle(height: 1.45))),
        ],
      ),
    );
  }
}


class WillStudyRoadmapPage extends StatelessWidget {
  const WillStudyRoadmapPage({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(CupertinoPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('课程学习路线')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _InfoCard(lines: [
            '建议先学导论，再进入观念—运动作用，之后再转到努力、爆发、阻塞与意志教育。',
            '这样学习的好处是：先理解意志如何发生，再进入现实中的拖延、冲动、决策与训练。',
          ]),
          const SizedBox(height: 12),
          _RoadmapStepCard(
            step: 'Step 1',
            title: '导论 83 段',
            subtitle: '欲望 / 愿望 / 意志、动作观念、动觉、神经支配感批判、动作线索',
            onTap: () => _open(context, const WillModuleUnitLibraryPage(moduleCode: 'D')),
          ),
          const SizedBox(height: 10),
          _RoadmapStepCard(
            step: 'Step 2',
            title: '观念—运动作用 19 段',
            subtitle: '想到就做、冲突观念、赖床案例、fiat 与阻滞解除',
            onTap: () => _open(context, const WillModuleUnitLibraryPage(moduleCode: 'I')),
          ),
          const SizedBox(height: 10),
          _RoadmapStepCard(
            step: 'Step 3',
            title: '审议 → 决断 → 努力',
            subtitle: '先看自己如何犹豫，再看自己如何决定，再看 effort 落在什么地方',
            onTap: () => _open(context, const WillUnitIndexPage(initialModuleCode: 'A')),
          ),
          const SizedBox(height: 10),
          _RoadmapStepCard(
            step: 'Step 4',
            title: '爆发、阻塞与快乐痛苦动力',
            subtitle: '把现实中的冲动失控、明白却做不到、即时舒服牵引放回机制里理解',
            onTap: () => _open(context, const WillUnitIndexPage(initialModuleCode: 'X')),
          ),
          const SizedBox(height: 10),
          _RoadmapStepCard(
            step: 'Step 5',
            title: '意志与观念 / 自由意志 / 意志教育',
            subtitle: '最后再进入“同意”“努力变量”与“新通路形成”的训练视角',
            onTap: () => _open(context, const WillUnitIndexPage(initialModuleCode: 'R')),
          ),
        ],
      ),
    );
  }
}

class WillUnitIndexPage extends StatefulWidget {
  final String? initialModuleCode;
  const WillUnitIndexPage({super.key, this.initialModuleCode});

  @override
  State<WillUnitIndexPage> createState() => _WillUnitIndexPageState();
}

class _WillUnitIndexPageState extends State<WillUnitIndexPage> {
  late String _selectedModule;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _selectedModule = widget.initialModuleCode ?? 'ALL';
  }

  @override
  Widget build(BuildContext context) {
    final moduleCodes = ['ALL', ...{for (final e in kWillUnitIndexes) e.moduleCode}.toList()];
    final filtered = kWillUnitIndexes.where((u) {
      final m = _selectedModule == 'ALL' || u.moduleCode == _selectedModule;
      final q = _query.trim().isEmpty || u.title.contains(_query.trim()) || u.oneLiner.contains(_query.trim()) || u.tags.any((t) => t.contains(_query.trim()));
      return m && q;
    }).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('209 单元总表')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: '搜索标题、定义或标签',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Row(
              children: moduleCodes.map((code) {
                final active = code == _selectedModule;
                final label = code == 'ALL' ? '全部' : _moduleTabLabel(code);
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(label),
                    selected: active,
                    onSelected: (_) => setState(() => _selectedModule = code),
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                final unit = filtered[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _UnitIndexTile(
                    unit: unit,
                    onTap: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillUnitIndexDetailPage(unit: unit))),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class WillModuleUnitLibraryPage extends StatelessWidget {
  final String moduleCode;
  const WillModuleUnitLibraryPage({super.key, required this.moduleCode});

  @override
  Widget build(BuildContext context) {
    final units = kWillUnitIndexes.where((e) => e.moduleCode == moduleCode).toList();
    final moduleTitle = units.isEmpty ? moduleCode : units.first.moduleTitle;
    final intro = kWillModuleLongIntro[moduleCode] ?? '这一模块正在持续扩充中。';
    final goals = kWillModuleStudyGoals[moduleCode] ?? const <String>[];
    return Scaffold(
      appBar: AppBar(title: Text('$moduleTitle · 标准库')),
      backgroundColor: const Color(0xFFF5F6FA),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(moduleTitle, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
                    _Badge('${units.length} 单元'),
                  ],
                ),
                const SizedBox(height: 8),
                Text(intro, style: const TextStyle(color: Color(0xFF4B5563), height: 1.5)),
                if (goals.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  const Text('学习目标', style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  ...goals.map((g) => _BulletLine(g)),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          const _SectionTitle('标准知识单元'),
          const SizedBox(height: 8),
          ...units.map((unit) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _UnitIndexTile(
                  unit: unit,
                  onTap: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillUnitIndexDetailPage(unit: unit))),
                ),
              )),
        ],
      ),
    );
  }
}

class WillUnitIndexDetailPage extends StatelessWidget {
  final WillUnitIndex unit;
  const WillUnitIndexDetailPage({super.key, required this.unit});

  @override
  Widget build(BuildContext context) {
    final deep = getWillDeepLessonContent(unit);
    final recommendedProblems = WillRouteResolver.recommendedProblemsForUnit(unit);
    final recommendedTasks = WillRouteResolver.recommendedTasksForUnit(unit);
    final recommendedZones = WillRouteResolver.recommendedZonesForUnit(unit);
    return Scaffold(
      appBar: AppBar(title: Text(unit.id)),
      backgroundColor: const Color(0xFFF5F6FA),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 16, offset: Offset(0, 8))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(unit.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                    _Badge(unit.moduleCode),
                  ],
                ),
                const SizedBox(height: 8),
                Text(unit.oneLiner, style: const TextStyle(fontSize: 15, height: 1.5, color: Color(0xFF374151))),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: unit.tags.map((e) => _TagChip(e)).toList()),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _DetailBlock(title: '原著要点', body: deep.originalKeyPoint),
          const SizedBox(height: 10),
          _DetailBlock(title: '核心含义', body: deep.coreMeaning),
          const SizedBox(height: 10),
          _DetailBlock(title: '外延与适用范围', body: deep.extension),
          const SizedBox(height: 10),
          _DetailBlock(title: '现实场景', body: deep.realCase),
          const SizedBox(height: 10),
          _DetailBlock(title: '最小实践动作', body: deep.practiceAction),
          const SizedBox(height: 10),
          _DetailBlock(title: 'if-then 模板', body: deep.ifThen),
          const SizedBox(height: 10),
          _DetailBlock(title: '镜像城映射', body: '推荐在「${deep.mirrorZone}」练习这个概念：先在虚拟场景里识别它，再回到现实中做一次最小动作。'),
          const SizedBox(height: 10),
          _DetailBlock(title: '复盘问题', body: deep.reviewPrompt),
          if (recommendedProblems.isNotEmpty) ...[
            const SizedBox(height: 12),
            const _SectionTitle('推荐问题路径'),
            const SizedBox(height: 8),
            ...recommendedProblems.map((problem) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ActionLinkCard(
                    title: problem.title,
                    subtitle: problem.summary,
                    onTap: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillProblemDetailPage(problem: problem))),
                  ),
                )),
          ],
          if (recommendedTasks.isNotEmpty) ...[
            const SizedBox(height: 12),
            const _SectionTitle('推荐现实任务'),
            const SizedBox(height: 8),
            ...recommendedTasks.map((task) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ActionLinkCard(
                    title: task.title,
                    subtitle: task.action,
                    onTap: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillTaskDetailPage(task: task))),
                  ),
                )),
          ],
          if (recommendedZones.isNotEmpty) ...[
            const SizedBox(height: 12),
            const _SectionTitle('推荐镜像城练习'),
            const SizedBox(height: 8),
            ...recommendedZones.map((zone) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ActionLinkCard(
                    title: zone.title,
                    subtitle: zone.missionTitle,
                    onTap: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => WillWorldZoneDetailPage(zone: zone))),
                  ),
                )),
          ],
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).push(
              CupertinoPageRoute(
                builder: (_) => WillReviewCenterPage(
                  initialTaskTitle: '${unit.id}｜${unit.title}',
                ),
              ),
            ),
            icon: const Icon(Icons.edit_note_outlined),
            label: const Text('用这个单元开始复盘'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).push(
              CupertinoPageRoute(builder: (_) => const WillTaskHubPage()),
            ),
            icon: const Icon(Icons.task_alt_outlined),
            label: const Text('前往现实任务中心'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).push(
              CupertinoPageRoute(builder: (_) => const WillDashboardPage()),
            ),
            icon: const Icon(Icons.dashboard_outlined),
            label: const Text('查看训练总览'),
          ),
        ],
      ),
    );
  }
}

class _RoadmapStepCard extends StatelessWidget {
  final String step;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _RoadmapStepCard({required this.step, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: const Color(0xFFEEF2FF),
                  borderRadius: BorderRadius.circular(18),
                ),
                alignment: Alignment.center,
                child: Text(step, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF3730A3))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text(subtitle, style: const TextStyle(color: Color(0xFF6B7280), height: 1.45)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}


class _ActionLinkCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionLinkCard({required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 2),
                child: Icon(Icons.chevron_right_rounded),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text(subtitle, style: const TextStyle(color: Color(0xFF6B7280), height: 1.45)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UnitIndexTile extends StatelessWidget {
  final WillUnitIndex unit;
  final VoidCallback onTap;
  const _UnitIndexTile({required this.unit, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _Badge(unit.id),
                  const SizedBox(width: 8),
                  Expanded(child: Text(unit.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
                ],
              ),
              const SizedBox(height: 8),
              Text(unit.oneLiner, style: const TextStyle(color: Color(0xFF4B5563), height: 1.45)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: unit.tags.map((e) => _TagChip(e)).toList()),
            ],
          ),
        ),
      ),
    );
  }
}

String _moduleTabLabel(String code) {
  switch (code) {
    case 'D': return '导论';
    case 'I': return '观念—运动';
    case 'A': return '审议';
    case 'T': return '决定类型';
    case 'E': return '努力';
    case 'X': return '爆发';
    case 'O': return '阻塞';
    case 'P': return '快痛动力';
    case 'R': return '意志与观念';
    case 'F': return '自由意志';
    case 'W': return '意志教育';
    default: return code;
  }
}


class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280))),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<String> chips;
  const _HeroCard({required this.title, required this.subtitle, required this.chips});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFEEF2FF), Color(0xFFF8FAFC)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(subtitle, style: const TextStyle(color: Color(0xFF4B5563), height: 1.5)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: chips.map((e) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Text(e, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            )).toList(),
          ),
        ],
      ),
    );
  }
}

class _EntryCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _EntryCard({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 6))],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFF3F4F6), borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: const Color(0xFF374151)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(subtitle, style: const TextStyle(color: Color(0xFF6B7280), height: 1.45)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Color(0xFF9CA3AF)),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<String> lines;
  const _InfoCard({required this.lines});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: lines.map((e) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 5),
                child: Icon(Icons.circle, size: 7, color: Color(0xFF6B7280)),
              ),
              const SizedBox(width: 8),
              Expanded(child: Text(e, style: const TextStyle(color: Color(0xFF4B5563), height: 1.5))),
            ],
          ),
        )).toList(),
      ),
    );
  }
}

class _KnowledgeCardTile extends StatelessWidget {
  final WillKnowledgeCard card;
  final VoidCallback onTap;
  const _KnowledgeCardTile({required this.card, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 6))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${card.label} · ${card.title}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(card.oneLiner, style: const TextStyle(color: Color(0xFF4B5563), height: 1.45)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: card.tags.take(3).map((e) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                ),
                child: Text(e, style: const TextStyle(fontSize: 12, color: Color(0xFF374151))),
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
