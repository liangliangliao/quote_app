import 'dart:convert';

import '../data/db.dart';

/// BeliefForge (信念工坊) persistence helpers.
///
/// This app already ships with a SQLite database via [AppDatabase].
/// We keep the module lightweight by using a few dedicated tables.
class BeliefForgeDao {
  Future<void> ensureSchema() async {
    // Tables are created idempotently in AppDatabase.instance().
    await AppDatabase.instance();
  }

  Future<int> addBelief({
    required String domain,
    required String beliefType,
    required String limitingBelief,
    required String targetBelief,
    int strength1to10 = 5,
  }) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    return db.insert('belief_forge_beliefs', {
      'domain': domain,
      'belief_type': beliefType,
      'limiting_belief': limitingBelief,
      'target_belief': targetBelief,
      'strength_1_10': strength1to10.clamp(1, 10),
      'created_at_ms': now,
      'updated_at_ms': now,
    });
  }

  Future<List<Map<String, dynamic>>> listBeliefs({int limit = 200}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query(
      'belief_forge_beliefs',
      orderBy: 'updated_at_ms DESC',
      limit: limit,
    );
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<void> updateBelief({
    required int id,
    String? domain,
    String? beliefType,
    String? limitingBelief,
    String? targetBelief,
    int? strength1to10,
  }) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    final data = <String, Object?>{'updated_at_ms': now};
    if (domain != null) data['domain'] = domain;
    if (beliefType != null) data['belief_type'] = beliefType;
    if (limitingBelief != null) data['limiting_belief'] = limitingBelief;
    if (targetBelief != null) data['target_belief'] = targetBelief;
    if (strength1to10 != null) {
      data['strength_1_10'] = strength1to10.clamp(1, 10);
    }
    await db.update('belief_forge_beliefs', data, where: 'id=?', whereArgs: [id]);
  }

  Future<void> deleteBelief(int id) async {
    final db = await AppDatabase.instance();
    await db.delete('belief_forge_beliefs', where: 'id=?', whereArgs: [id]);
  }

  Future<int> addRun({
    required String conceptId,
    required String conceptTitle,
    required String runType,
    int? durationSec,
    double? score,
    String? note,
    Map<String, dynamic>? extra,
  }) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    return db.insert('belief_forge_runs', {
      'ts_ms': now,
      'concept_id': conceptId,
      'concept_title': conceptTitle,
      'run_type': runType,
      'duration_sec': durationSec,
      'score': score,
      'note': note,
      'extra_json': extra == null ? null : jsonEncode(extra),
    });
  }

  Future<int> addJournal({
    double? mood0to10,
    String? emotion,
    required String line1,
    required String line2,
    required String line3,
    String? reframe,
  }) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    return db.insert('belief_forge_journals', {
      'ts_ms': now,
      'mood_0_10': mood0to10,
      'emotion': emotion,
      'line1': line1,
      'line2': line2,
      'line3': line3,
      'reframe': reframe,
    });
  }

  Future<List<Map<String, dynamic>>> listRuns({
    int limit = 200,
  }) async {
    final db = await AppDatabase.instance();
    final rows = await db.query(
      'belief_forge_runs',
      orderBy: 'ts_ms DESC',
      limit: limit,
    );
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> listRunsByRunType(
    String runType, {
    int limit = 2000,
  }) async {
    final db = await AppDatabase.instance();
    final rows = await db.query(
      'belief_forge_runs',
      where: 'run_type=?',
      whereArgs: [runType],
      orderBy: 'ts_ms DESC',
      limit: limit,
    );
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> listRunsForConcept(
    String conceptId, {
    String? runType,
    int limit = 400,
  }) async {
    final db = await AppDatabase.instance();
    final where = <String>['concept_id=?'];
    final args = <Object?>[conceptId];
    if (runType != null && runType.isNotEmpty) {
      where.add('run_type=?');
      args.add(runType);
    }
    final rows = await db.query(
      'belief_forge_runs',
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: 'ts_ms DESC',
      limit: limit,
    );
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }
}
