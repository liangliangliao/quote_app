import 'dart:math';

import 'package:flutter/material.dart';

import '../belief_game_service.dart';
import '../model/belief_concepts.dart';
import '../model/belief_game.dart';
import '../widgets/game_feedback.dart';
import 'belief_lab_page.dart';
import 'belief_map_page.dart';
import 'belief_review_page.dart';
import 'permission_space_page.dart';
import 'will_gym_page.dart';

class BeliefForgeHomePage extends StatefulWidget {
  const BeliefForgeHomePage({super.key});

  @override
  State<BeliefForgeHomePage> createState() => _BeliefForgeHomePageState();
}

class _BeliefForgeHomePageState extends State<BeliefForgeHomePage> {
  bool _loading = true;
  Map<String, int> _counts = const {};
  Map<String, bool> _claimed = const {};
  bool _chestClaimed = false;
  Set<String> _badges = const {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await BeliefGameService.instance.init();

    final counts = await BeliefGameService.instance.getTodayCounts();
    final claimed = <String, bool>{};
    for (final q in kDailyQuests) {
      claimed[q.id] = await BeliefGameService.instance.isQuestClaimed(q.id);
    }
    final chestClaimed = await BeliefGameService.instance.isChestClaimed();
    final all = await BeliefGameService.instance.listBadges(limit: 200);
    final badges = all
        .map((e) => (e['key'] as String?) ?? '')
        .where((k) => k.startsWith('badge_'))
        .toSet();

    if (!mounted) return;
    setState(() {
      _counts = counts;
      _claimed = claimed;
      _chestClaimed = chestClaimed;
      _badges = badges;
      _loading = false;
    });
  }

  int _progressForQuest(DailyQuestDef q) {
    switch (q.id) {
      case 'q_action_card':
        return _counts['action_card'] ?? 0;
      case 'q_will':
        return _counts['will'] ?? 0;
      case 'q_space':
        return _counts['space'] ?? 0;
      case 'q_map':
        return _counts['map'] ?? 0;
      default:
        return 0;
    }
  }

  Widget _jumpTo(String jump, {String? titleOverride}) {
    switch (jump) {
      case 'lab':
        return const BeliefLabPage();
      case 'map':
        return const BeliefMapPage();
      case 'will':
        return const WillGymPage();
      case 'space':
        return const PermissionSpacePage();
      default:
        return const BeliefReviewPage();
    }
  }

  Future<void> _openJump(String jump, String title) async {
    final body = _jumpTo(jump);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(
            title: Text(title),
            backgroundColor: Colors.white,
            surfaceTintColor: Colors.transparent,
          ),
          backgroundColor: Colors.white,
          body: body,
        ),
      ),
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ValueListenableBuilder<BeliefProfile>(
        valueListenable: BeliefGameService.instance.profileListenable,
        builder: (context, profile, _) {
          final nextUnlock = _nextUnlock(profile.level);
          final allQuestClaimed = kDailyQuests.every((q) => _claimed[q.id] == true);
          final canClaimChest = allQuestClaimed && !_chestClaimed;

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
            children: [
              _PlayerProgressCard(profile: profile, nextUnlock: nextUnlock),
              const SizedBox(height: 12),
              _DailyQuestCard(
                loading: _loading,
                quests: kDailyQuests,
                progressOf: _progressForQuest,
                claimed: _claimed,
                canClaimChest: canClaimChest,
                chestClaimed: _chestClaimed,
                onGo: (q) => _openJump(q.jump, q.title),
                onClaim: (q, progress) async {
                  final award = await BeliefGameService.instance.claimQuestIfEligible(quest: q, progress: progress);
                  if (!mounted) return;
                  if (award != null) {
                    await showXpFeedback(context, award: award, title: '任务奖励到账');
                  }
                  await _load();
                },
                onClaimChest: () async {
                  await BeliefGameService.instance.claimChest(coins: 5);
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('宝箱开启：+5 金币')));
                  await _load();
                },
              ),
              const SizedBox(height: 12),
              _BadgesCard(badges: _badges),
              const SizedBox(height: 12),
              const _HeroCard(),
              const SizedBox(height: 12),
              const Text(
                '今日推荐：选 1 个概念，先做“体验”，再读解释，然后把它落到一个 1% 行动。',
                style: TextStyle(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 12),
              _ConceptQuickPick(playerLevel: profile.level),
              const SizedBox(height: 16),
              const Text('你可以从这里开始', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              _EntryGrid(onOpen: _openJump),
              const SizedBox(height: 16),
              const Text('为什么它能改变生活', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              const _WhyItWorks(),
            ],
          );
        },
      ),
    );
  }

  _NextUnlock _nextUnlock(int level) {
    final locked = kBeliefForgeConcepts
        .where((c) => (kConceptRequiredLevel[c.id] ?? 1) > level)
        .toList()
      ..sort((a, b) => (kConceptRequiredLevel[a.id] ?? 1).compareTo(kConceptRequiredLevel[b.id] ?? 1));

    if (locked.isEmpty) {
      return const _NextUnlock(title: '已解锁全部概念', level: null);
    }
    final c = locked.first;
    return _NextUnlock(title: c.title, level: kConceptRequiredLevel[c.id] ?? (level + 1));
  }
}

class _NextUnlock {
  final String title;
  final int? level;
  const _NextUnlock({required this.title, required this.level});
}

class _PlayerProgressCard extends StatelessWidget {
  final BeliefProfile profile;
  final _NextUnlock nextUnlock;
  const _PlayerProgressCard({required this.profile, required this.nextUnlock});

  @override
  Widget build(BuildContext context) {
    final cur = profile.xp;
    final start = profile.levelStartXp;
    final next = profile.nextLevelXp;
    final need = max(1, next - start);
    final inLevel = (cur - start).clamp(0, need);
    final pct = (inLevel / need).clamp(0.0, 1.0);

    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('Lv ${profile.level}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
                _MiniPill(icon: Icons.local_fire_department_outlined, text: '连击 ${profile.streak}'),
                const SizedBox(width: 8),
                _MiniPill(icon: Icons.monetization_on_outlined, text: '金币 ${profile.coins}'),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(value: pct, minHeight: 10),
            ),
            const SizedBox(height: 6),
            Text('经验：$cur（本级 ${inLevel.toInt()}/$need）', style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.lock_open_outlined, size: 18),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    nextUnlock.level == null ? nextUnlock.title : '下一解锁：${nextUnlock.title}（Lv ${nextUnlock.level}）',
                    style: const TextStyle(fontSize: 12, color: Colors.black87),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              '玩法：做任务→拿 XP→升级→解锁概念→把概念变成行动卡。',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniPill extends StatelessWidget {
  final IconData icon;
  final String text;
  const _MiniPill({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _DailyQuestCard extends StatelessWidget {
  final bool loading;
  final List<DailyQuestDef> quests;
  final int Function(DailyQuestDef) progressOf;
  final Map<String, bool> claimed;
  final bool canClaimChest;
  final bool chestClaimed;
  final void Function(DailyQuestDef) onGo;
  final Future<void> Function(DailyQuestDef, int) onClaim;
  final Future<void> Function() onClaimChest;

  const _DailyQuestCard({
    required this.loading,
    required this.quests,
    required this.progressOf,
    required this.claimed,
    required this.canClaimChest,
    required this.chestClaimed,
    required this.onGo,
    required this.onClaim,
    required this.onClaimChest,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('今日任务', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                ),
                if (loading)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            const Text('完成后记得“领取奖励”。全部领取后可开宝箱。', style: TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 12),
            ...quests.map((q) {
              final progress = progressOf(q);
              final done = progress >= q.target;
              final isClaimed = claimed[q.id] == true;

              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(q.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                          ),
                          Text('${min(progress, q.target)}/${q.target}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(q.desc, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: Wrap(
                              spacing: 8,
                              children: [
                                _RewardChip(text: '+${q.xp} XP'),
                                if (q.coins > 0) _RewardChip(text: '+${q.coins} 金币'),
                              ],
                            ),
                          ),
                          if (isClaimed)
                            const Icon(Icons.verified, color: Colors.green)
                          else if (done)
                            FilledButton(
                              onPressed: () => onClaim(q, progress),
                              child: const Text('领取'),
                            )
                          else
                            OutlinedButton(
                              onPressed: () => onGo(q),
                              child: const Text('去完成'),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.card_giftcard_outlined),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text('每日宝箱：全部任务奖励领取后可开', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  if (chestClaimed)
                    const Icon(Icons.check_circle, color: Colors.green)
                  else
                    FilledButton(
                      onPressed: canClaimChest ? onClaimChest : null,
                      child: const Text('开宝箱'),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RewardChip extends StatelessWidget {
  final String text;
  const _RewardChip({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black12),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

class _BadgesCard extends StatelessWidget {
  final Set<String> badges;
  const _BadgesCard({required this.badges});

  static const _defs = [
    _BadgeDef('badge_first_action_card', '第一张行动卡', Icons.style_outlined),
    _BadgeDef('badge_first_lesson', '第一次通关', Icons.school_outlined),
    _BadgeDef('badge_first_will', '第一次意志训练', Icons.fitness_center_outlined),
    _BadgeDef('badge_first_space', '第一次允许区记录', Icons.self_improvement_outlined),
    _BadgeDef('badge_first_belief', '第一张信念卡', Icons.map_outlined),
    _BadgeDef('badge_streak3', '三日连击', Icons.local_fire_department_outlined),
    _BadgeDef('badge_level3', '到达 Lv3', Icons.emoji_events_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    final unlocked = _defs.where((d) => badges.contains(d.key)).length;

    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('徽章（$unlocked/${_defs.length}）', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('像收集一样：每个徽章对应一个“行为证据”。', style: TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: _defs.map((d) {
                final ok = badges.contains(d.key);
                return _BadgePill(def: d, unlocked: ok);
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _BadgeDef {
  final String key;
  final String name;
  final IconData icon;
  const _BadgeDef(this.key, this.name, this.icon);
}

class _BadgePill extends StatelessWidget {
  final _BadgeDef def;
  final bool unlocked;
  const _BadgePill({required this.def, required this.unlocked});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: unlocked ? Colors.white : Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(def.icon, size: 18, color: unlocked ? Colors.black87 : Colors.black26),
          const SizedBox(width: 6),
          Text(def.name, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: unlocked ? Colors.black87 : Colors.black26)),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('信念工坊 BeliefForge', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Text(
              '把“信念”从抽象观点变成可执行的日常系统：\n'
              '信念 → 注意力/意志 → 行动 → 反馈 → 信念更新。',
              style: TextStyle(fontSize: 13, color: Colors.black87, height: 1.35),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConceptQuickPick extends StatelessWidget {
  final int playerLevel;
  const _ConceptQuickPick({required this.playerLevel});

  @override
  Widget build(BuildContext context) {
    final picks = kBeliefForgeConcepts.where((c) => (kConceptRequiredLevel[c.id] ?? 1) <= playerLevel).take(3).toList();
    final fallback = kBeliefForgeConcepts.take(3).toList();
    final list = picks.isEmpty ? fallback : picks;

    return Column(
      children: list
          .map(
            (c) => ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              tileColor: const Color(0xFFF7F7F7),
              leading: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(c.icon, color: Colors.black87),
              ),
              title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(c.subtitle),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => BeliefLabPage(initialConceptId: c.id)),
              ),
            ),
          )
          .toList(),
    );
  }
}

class _EntryGrid extends StatelessWidget {
  final Future<void> Function(String jump, String title) onOpen;
  const _EntryGrid({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final items = <_EntryItem>[
      _EntryItem('信念实验室', '概念关卡 + 体验 + 解释', Icons.school_outlined, 'lab'),
      _EntryItem('信念图谱', '记录你的限制信念与替代信念', Icons.map_outlined, 'map'),
      _EntryItem('意志训练', 'fiat 决断 + 注意力拉回', Icons.fitness_center_outlined, 'will'),
      _EntryItem('允许区', '情绪容纳 + 三句日记', Icons.self_improvement_outlined, 'space'),
      _EntryItem('复盘', '洞察与下一步', Icons.insights_outlined, 'review'),
    ];

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: items
          .map(
            (it) => SizedBox(
              width: (MediaQuery.of(context).size.width - 16 * 2 - 12) / 2,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => onOpen(it.jump, it.title),
                child: Card(
                  elevation: 0,
                  color: const Color(0xFFF7F7F7),
                  surfaceTintColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(it.icon, color: Colors.black87),
                        const SizedBox(height: 10),
                        Text(it.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        Text(it.subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.2)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}

class _EntryItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final String jump;
  _EntryItem(this.title, this.subtitle, this.icon, this.jump);
}

class _WhyItWorks extends StatelessWidget {
  const _WhyItWorks();

  @override
  Widget build(BuildContext context) {
    const bullets = [
      '用“微实验”让你亲自体验：环境/期待/情绪如何影响行为。',
      '每个概念都给“解释 + 为什么 + 怎么做 + 案例”，让你知其然且知其所以然。',
      '用 1% 行动制造证据：证据会反过来改写信念，让改变可持续。',
      '用游戏化（任务/奖励/解锁）把“知道”变成“做到”。',
    ];
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: bullets
              .map(
                (b) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('• ', style: TextStyle(fontSize: 16, height: 1.3)),
                      Expanded(child: Text(b, style: const TextStyle(height: 1.3))),
                    ],
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
