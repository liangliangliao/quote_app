import 'package:flutter/material.dart';

/// A single learnable concept in BeliefForge.
///
/// Each concept must include:
/// - an interactive micro-experience (handled by UI)
/// - explanation text
/// - why/mechanism text
/// - how-to steps
/// - a concrete daily-life case
class BeliefConcept {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final String explanation;
  final String why;
  final List<String> howTo;
  final String caseStudy;
  final String interactionHint;

  const BeliefConcept({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.explanation,
    required this.why,
    required this.howTo,
    required this.caseStudy,
    required this.interactionHint,
  });
}

/// Curated MVP concept set mapped from:
/// - Harvard Positive Psychology lecture 5/6
/// - William James: The Principles of Psychology (Will)
///
/// Note: Text is written in a user-friendly manner for in-app learning.
const List<BeliefConcept> kBeliefForgeConcepts = [
  BeliefConcept(
    id: 'broaden_build',
    title: '积极情绪：拓展—建构（Broaden & Build）',
    subtitle: '积极情绪会“加宽带宽”，并在时间里建造资源',
    icon: Icons.wb_sunny,
    interactionHint: '选择你此刻的情绪天气，并完成一个 2 分钟“拓展动作”。',
    explanation:
        '积极情绪不是锦上添花，而是改变系统的杠杆。\n'
        '它会拓展你的思维与行动选项，让你更愿意探索、连接、学习；\n'
        '长期看，它还会帮你建造资源：韧性、社交支持、创造力与健康习惯。',
    why:
        '当你处在负面情绪里，注意力会变窄（只盯住威胁/问题），这对短期生存有用。\n'
        '但如果长期被“窄带宽”困住，就更容易陷入向下螺旋。\n'
        '积极情绪能让你短暂“抬头看路”，从而发现新的解法与机会。',
    howTo: [
      '不是强迫自己快乐，而是做一个小小的“拓展动作”。',
      '拓展动作清单：给一个人发感谢/关心；出门走 5 分钟；看 3 个你以前没注意到的细节。',
      '做完立刻记录：我看到了什么新可能？我下一步要试什么？',
    ],
    caseStudy:
        '失恋后你反复想“我不够好”，越想越难过。\n'
        '你先做一个拓展动作：给朋友发一句“我想聊聊”。\n'
        '连接出现后，你的带宽变宽，就更容易从反刍转向反思与行动。',
  ),
  BeliefConcept(
    id: 'priming',
    title: '启动效应（Priming）',
    subtitle: '环境里一个词/图像，会悄悄改变你的行为',
    icon: Icons.spa,
    interactionHint: '先选一个“启动词”，再做 20 秒点按挑战，感受投入变化。',
    explanation:
        '你以为你在完全“自由选择”，但很多时候，你是在被环境悄悄“推着走”。\n'
        '一个词、一张图、一段音乐、一个房间的氛围，都可能改变你后续的速度、专注与判断。',
    why:
        '大脑会把“最近被激活的线索”当作省力的导航。\n'
        '当某个概念被激活（比如“坚持”或“放松”），你更容易注意到与之相关的信息，也更容易做出匹配的动作。',
    howTo: [
      '把你最重要的任务物品放到视线第一位置（把“做事”变成默认线索）。',
      '给手机锁屏设置一句行动信念：例如“先开始 2 分钟”。',
      '开工前 10 秒读一张“启动卡”（坚持/专注/勇气），然后立刻开始最小动作。',
    ],
    caseStudy:
        '你总是忍不住刷手机。与其骂自己自控差，不如改线索：\n'
        '把手机放到另一个房间；桌面只留电脑和待办；开工前播放一段“专注音乐”。\n'
        '你会发现“启动线索”改变后，开始变得容易很多。',
  ),
  BeliefConcept(
    id: 'situation_power',
    title: '情境的力量（角色/环境塑形）',
    subtitle: '先换情境，再谈努力',
    icon: Icons.theater_comedy,
    interactionHint: '选择一个“角色”，用它的语气写一句话并完成一个微行动。',
    explanation:
        '有时候你不是“做不到”，你只是没进入一个能让你做到的情境。\n'
        '当环境给你脚本（身份、规则、氛围），你的行为会很自然地沿脚本走。',
    why:
        '情境会改变你对“我是谁/我能做什么”的默认预期，从而改变投入程度、坚持时间与行动选择。\n'
        '与其把改变当成“单挑自己”，不如让情境成为队友。',
    howTo: [
      '给目标行为配一个“专用场景”：固定位置、固定时间、固定工具。',
      '把干扰物移出 2 米之外（增加摩擦）。',
      '用“角色脚本”进入状态：例如“我今天扮演执行者，只做一件最小推进”。',
    ],
    caseStudy:
        '你一到办公室就拖延。你把桌面改成“执行情境”：\n'
        '只开一个窗口；计时 10 分钟；桌面放“下一步清单”。\n'
        '不需要等动力来，情境会先把你推到可行动状态。',
  ),
  BeliefConcept(
    id: 'pygmalion',
    title: '自证预言（Pygmalion/期待效应）',
    subtitle: '你对自己/他人的默认期待，会塑造结果',
    icon: Icons.psychology,
    interactionHint: '为一个人设定“高期待=高支持”行动计划，并设置提醒。',
    explanation:
        '你对自己或别人“默认认为会怎样”，会悄悄改变你的投入、反馈方式与机会分配。\n'
        '久而久之，结果会反过来证明当初的期待——这就是自证预言。',
    why:
        '期待会驱动很多“微行为”：更耐心、更愿意解释、更常提供练习机会。\n'
        '这些微行为累计成练习量与反馈质量，最终变成真实差距。',
    howTo: [
      '把“期待”翻译成“支持”：清晰标准 + 小步练习 + 过程反馈。',
      '避免空洞夸奖（你真聪明），改为过程语言（你用了什么策略/坚持了多久）。',
      '每周一次复盘：这周我给了对方哪些机会？我如何反馈？',
    ],
    caseStudy:
        '你觉得新人不行，于是只给杂活，他就真的成长慢。\n'
        '你把期待改成“能成长”，给一个小但关键任务 + 过程反馈，\n'
        '对方很快进入正循环，你的期待也被新的证据更新。',
  ),
  BeliefConcept(
    id: 'belief_gears',
    title: '信念双齿轮：动机 × 自洽',
    subtitle: '信念不是口号，是行为概率的调参器',
    icon: Icons.settings_suggest,
    interactionHint: '输入一句信念，选择昨天的行为，得到“自洽雷达”与最小动作。',
    explanation:
        '信念至少通过两条路改变结果：\n'
        '① 动机：相信能行 → 更愿投入与坚持；\n'
        '② 自洽：人会倾向让行为与自我叙事一致（“我就是这样的人”）。',
    why:
        '当你认定“我不行”，你更可能减少尝试、降低标准、早早退出，结果就更像“不行”。\n'
        '反过来，用最小证据让自己“像那种人”，信念就会被重写。',
    howTo: [
      '把信念拆成 1% 动作：越小越好（30 秒也算）。',
      '先追求“可重复”，再追求“更好”。',
      '每天记录一条证据：我做了什么？这说明了什么？',
    ],
    caseStudy:
        '你说“我重视健康”，但经常熬夜。\n'
        '别急着改变人生：先做 1 次“23:30 放下手机”当作证据。\n'
        '有了证据，你更容易相信“我能做到”，也更愿意继续。',
  ),
  BeliefConcept(
    id: 'placebo',
    title: '身心信念回路（Placebo 视角）',
    subtitle: '期待会影响体验，但不等于否认外部因素',
    icon: Icons.favorite,
    interactionHint: '做一次 60 秒放松前后打分，观察体验变化。',
    explanation:
        '你的身体体验（紧张、疼痛、疲惫）会被“你相信会发生什么”影响。\n'
        '这不等于外部不重要，而是：心智也是现实的一部分。',
    why:
        '期待会改变注意力、紧张度与解释方式，从而影响主观体验。\n'
        '在安全范围内观察这条链，你会更会“用信念帮助自己”。',
    howTo: [
      '先命名感受：我现在紧张/胸闷/心跳快。',
      '做 60 秒放松（呼吸/渐进放松）。',
      '用一句可相信的解释替代恐慌：紧张=身体在准备应对。',
    ],
    caseStudy:
        '你一想到上台就胃痛。\n'
        '你先承认“我在紧张”，做 60 秒呼吸，再说一句“紧张不等于我会失败”。\n'
        '胃痛强度可能下降，你就更能行动。若有医疗问题请就医。',
  ),
  BeliefConcept(
    id: 'growth_mindset',
    title: '成长型心态（Dweck）',
    subtitle: '夸努力/策略，比夸聪明更能带来坚持',
    icon: Icons.trending_up,
    interactionHint: '把一句“固定心态台词”翻译成“成长心态台词”。',
    explanation:
        '固定心态：我聪明/我不行（把价值绑在结果）。\n'
        '成长心态：我在学习/我能练出来（把注意力放到可控变量）。',
    why:
        '当你把价值绑在“天赋”，遇到困难就像被判刑，于是更想回避。\n'
        '当你把价值绑在“练习与策略”，困难变成信息，你更敢继续。',
    howTo: [
      '把“我不行”改成“我还没掌握这个策略”。',
      '把“必须一次成功”改成“今天收集 1 个改进点”。',
      '每次失败写一句：这次我学到了什么？下次试什么？',
    ],
    caseStudy:
        '学口语不敢开口：固定心态=“我发音差=我不行”。\n'
        '成长心态=“我今天练 3 句就算赢”。\n'
        '当目标变成“练习”，你就更容易持续。',
  ),
  BeliefConcept(
    id: 'relationship_cultivate',
    title: '关系：寻找心态 vs 经营心态',
    subtitle: '把冲突从“找错人”改成“练技能”',
    icon: Icons.handshake_outlined,
    interactionHint: '选择一个最近矛盾，把“指责解释”改写成“技能解释”。',
    explanation:
        '很多人把关系理解成“找到对的人就会顺利”。\n'
        '这会让冲突被解释为“我找错人/我不被爱”。\n'
        '更有效的信念是：关系是一种可以经营与练习的技能。',
    why:
        '当你相信“应该天然契合”，现实冲突会被当成关系失败的证据。\n'
        '当你相信“可以经营”，冲突就变成训练：表达需求、修复对话、建立规则。',
    howTo: [
      '用三段式修复对话：我感到___ / 我在意___ / 我们能否试___。',
      '把“你总是…”改成“当___发生时，我会___，我希望___”。',
      '每周一次 10 分钟复盘：本周我们做对了什么？下周想练什么？',
    ],
    caseStudy:
        '对方忘记纪念日：\n'
        '寻找心态：你不重视我 → 关系没救。\n'
        '经营心态：我们建立提醒机制 + 我说清楚我在意的方式。\n'
        '同一件事，解释不同，结果就不同。',
  ),
  BeliefConcept(
    id: 'permission_human',
    title: '允许自己是人（Permission to be Human）',
    subtitle: '不需要永远积极，你需要一个允许区',
    icon: Icons.self_improvement,
    interactionHint: '用三句话写下“感受-信息-照顾”，完成一次允许区练习。',
    explanation:
        '真正健康的人生包含痛苦情绪。\n'
        '压抑与否认会消耗能量，让你更难恢复、更难创造、更难成功。',
    why:
        '情绪不是敌人，它是信息。\n'
        '允许自己先感受，再回到行动，才是更可持续的心理方式。',
    howTo: [
      '说出：我正在感到___（不评判）。',
      '允许 90 秒：这很正常，我先让它存在。',
      '回到一个最小行动：喝水/走 2 分钟/整理桌面 1 分钟。',
    ],
    caseStudy:
        '你因为嫉妒/内疚而自责。\n'
        '允许区做法：先承认情绪存在，再选择一个小行动，而不是陷入“我怎么这样”的二次伤害。',
  ),
  BeliefConcept(
    id: 'active_agent',
    title: '主动者（Active Agent）',
    subtitle: '不是不痛苦，而是痛苦后仍能选择行动',
    icon: Icons.directions_run,
    interactionHint: '选择一个卡点情境，挑一个 30 秒/2 分钟/5 分钟行动。',
    explanation:
        '主动者不是“硬扛”。\n'
        '主动者是：我允许痛苦存在，但我不把人生交给痛苦决定。',
    why:
        '行动会产生证据与掌控感，证据会反过来增强信心与希望。\n'
        '哪怕是 30 秒的行动，也能开启正循环。',
    howTo: [
      '给痛苦一个时间盒：允许 5-10 分钟难过。',
      '立刻做一个最小主动行为（30 秒也可以）。',
      '记录：我完成了什么？它说明了什么？',
    ],
    caseStudy:
        '面试失败后反复内耗。\n'
        '允许难过 10 分钟，然后做 2 分钟动作：简历改 1 行/投 1 家/约 1 次模拟面试。\n'
        '你会更快回到掌控感。',
  ),
  BeliefConcept(
    id: 'correct_expectations',
    title: '正确期待 vs 错误期待',
    subtitle: '幸福更多来自内在状态，而非外物承诺',
    icon: Icons.explore,
    interactionHint: '做一次“幸福承诺审计”，把外物期待翻译成今天的内在等价动作。',
    explanation:
        '外部目标可以追，但“它会让我永久幸福”的承诺常常不靠谱。\n'
        '更稳的是：从内在改变——改变关注点、解释方式与习惯。',
    why:
        '外部变化往往带来短期波动；长期体验更依赖注意力与日常系统。\n'
        '把目标翻译成今天可做的状态练习，改变才会发生。',
    howTo: [
      '写下：我以为___会让我幸福。',
      '追问：我真正想要的感受是什么？（自由/被爱/掌控/成就）',
      '做一个内在等价动作：今天就做 5 分钟。',
    ],
    caseStudy:
        '你以为“买到某物就开心”。审计后发现你要的是“奖励与掌控”。\n'
        '那今天就做：完成一个小任务→给自己一个小奖励。你会更稳定。',
  ),
  BeliefConcept(
    id: 'emotion_to_motion',
    title: '情绪驱动行动（Emotion → Motion）',
    subtitle: '把目标变成能看见、能感觉到的画面',
    icon: Icons.movie,
    interactionHint: '写一个 60 秒“目标预告片”：看见/听见/感受到什么。',
    explanation:
        '没有情绪就没有动作。\n'
        '把目标从抽象口号变成具体画面，你会更容易开始与坚持。',
    why:
        '画面更容易被大脑当成“真实线索”，从而驱动动机与执行。\n'
        '这不是幻想，而是给行动提供燃料与方向。',
    howTo: [
      '写出地点/动作/感官：我在哪里？做什么？身体感觉如何？',
      '把目标缩成一句“可执行镜头”：例如“打开文档写第一句”。',
      '开工前快速读一遍预告片，立刻做 2 分钟最小动作。',
    ],
    caseStudy:
        '“我要自律”很空；\n'
        '“我今晚 10:30 关灯躺下，呼吸变慢，明天醒来更轻松”更可执行。',
  ),
];
