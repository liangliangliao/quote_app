import 'lecture56_playgrounds.dart';

/// A structured module mapped to Harvard Positive Psychology Lecture 5/6.
///
/// This is *not* the same as the “Belief Lab concept list”. It is an ordered
/// course-path where every module contains:
/// - original quote/case hook (short)
/// - explanation / mechanism / how-to / daily case
/// - an interactive wizard (preset option space) that outputs an Action Card
class Lecture56Module {
  final int index; // 1..15
  final String id;
  final String title;
  final String lecture; // 'Lecture 5' or 'Lecture 6'

  /// Short original quote or line from the subtitle.
  final String hookQuote;

  /// Short original case reminder (1-3 lines), from the lecture examples.
  final String hookCase;

  /// User-friendly explanation.
  final String explanation;
  /// Mechanism / why it works.
  final String why;
  /// Concrete steps.
  final List<String> howTo;
  /// A concrete daily-life case.
  final String caseStudy;

  const Lecture56Module({
    required this.index,
    required this.id,
    required this.title,
    required this.lecture,
    required this.hookQuote,
    required this.hookCase,
    required this.explanation,
    required this.why,
    required this.howTo,
    required this.caseStudy,
  });
}

final List<Lecture56Module> kLecture56Modules = [
  Lecture56Module(
    index: 1,
    id: 'm01_contagious',
    title: '幸福是正和且会传染',
    lecture: 'Lecture 5',
    hookQuote: "\"happiness is contagious\"; \"Being happy... is also a moral state\"",
    hookCase: '讲义强调：你幸福，不是别人就少；你的情绪会通过互动质量“扩散”到身边人。',
    explanation: '''你更幸福，不是自私的事。

在这节课里，幸福被描述为“正和游戏”：你状态更好，往往会让身边人更好（而不是竞争）。''',
    why: '''情绪会影响你的语气、耐心、注意力与慷慨行为；这些“微行为”会改变别人当天的体验与选择，形成传染链。''',
    howTo: [
      '选择一个对象（家人/同事/陌生人/自己）。',
      '做一个“非常小”的正向行为（1 句话/1 个小帮忙/1 个微关怀）。',
      '观察并记录：对方反应 + 自己情绪变化（0-10）。',
    ],
    caseStudy: '''地铁/便利店场景：对店员说一句具体感谢（不是泛泛“辛苦了”，而是“谢谢你把这里整理得这么干净”）。

你会更容易感到连接感，对方也更可能用更好的态度对下一个人——这就是“传染”。''',
  ),
  Lecture56Module(
    index: 2,
    id: 'm02_broaden_build',
    title: '正向情绪：拓展—建构（Broaden & Build）',
    lecture: 'Lecture 5',
    hookQuote: '"broaden... thought-action repertoire and build... resources"',
    hookCase: '课上讲“上升/下降螺旋”：负面让注意力变窄，正向让你更容易看到选项并建资源。',
    explanation: '''正向情绪不是“锦上添花”，它是改变系统的杠杆。

它会让你短暂“抬头看路”，从而看到更多可能，然后在时间里建出资源：韧性、社交支持、创造力、健康习惯。''',
    why: '''负面情绪会让大脑收窄到“威胁/问题”，短期有用，但长期会把你困在反刍。

正向情绪会拓宽注意力，让你更愿意探索、连接、学习，于是更可能找到可行动路径。''',
    howTo: [
      '不要强迫开心：只做一个“拓展动作”（30 秒也算）。',
      '拓展动作例：走 5 分钟看 3 个细节；给一个人发一句连接消息；写 3 个具体小感恩。',
      '做完立刻写一句：我看到的新选项是___；下一步我愿意试___。',
    ],
    caseStudy: '''你被项目卡住，脑子里只剩“完了”。

你先做 2 分钟“找 3 个可能性”（换顺序/找同事 10 分钟/把任务拆成 3 步），这不是解决一切，但会把你从“窄带宽”切回“可行动”。''',
  ),
  Lecture56Module(
    index: 3,
    id: 'm03_appreciation',
    title: '欣赏让“好”增值（Appreciation Spiral）',
    lecture: 'Lecture 5',
    hookQuote: '"when we appreciate the good, the good appreciates"',
    hookCase: '课上用“上升/下降螺旋”对比：你关注什么，就会让它在关系/团队里变得更常见。',
    explanation: '''你注意什么，它就更“存在”。

欣赏不是客套话，而是一种注意力训练：把注意力放到“做得对的部分”，那部分就更容易被重复。''',
    why: '''注意力是强化器：你经常指出/看见的行为，会得到更多练习与反馈，从而更容易变成稳定习惯。

反过来，如果你只盯问题，系统会进入下降螺旋。''',
    howTo: [
      '用“具体”替代“泛泛”：指出一个行为细节，而不是一句空夸。',
      '把欣赏聚焦在可复制的东西：努力、策略、进步、体贴、勇气。',
      '每周给一个人 1 次“可执行的欣赏”（对方知道下次怎么做得更好）。',
    ],
    caseStudy: '''把“你真棒”升级为：“我注意到你今天很累还把碗洗了，这让我感到被支持。”

这句欣赏不仅更真诚，还告诉对方“什么行为”带来“什么价值”。''',
  ),
  Lecture56Module(
    index: 4,
    id: 'm04_modeling',
    title: '以身作则：人更会做你做的',
    lecture: 'Lecture 5',
    hookQuote: '"People mostly do what you do, rather than what you say."',
    hookCase: '课上用“cheek vs chin”小实验：老师嘴上说 cheek，但动作像 chin，多数人会跟着做。',
    explanation: '''想影响别人，最有效的方式往往不是讲道理，而是把自己变成可被模仿的线索。''',
    why: '''行为示范会改变群体规范与默认值：别人看到你持续做，就会降低他们开始的门槛，并形成“这在这里是正常的”期待。''',
    howTo: [
      '选一个你想影响的主题（早睡/运动/少刷手机/学习/友善）。',
      '把它变成可见的、可重复的示范动作（3 天即可）。',
      '在适当时机再说规则/建议：先做出证据，再谈道理。',
    ],
    caseStudy: '''你想孩子少刷手机：先把自己“睡前手机放门口充电”坚持一周；

当你自己成为情境线索，后面谈规则就不再是对抗，而是“我们家就是这样”。''',
  ),
  Lecture56Module(
    index: 5,
    id: 'm05_situation',
    title: '情境的力量：先换情境，再谈努力',
    lecture: 'Lecture 5',
    hookQuote: '"The power of the situation"',
    hookCase: '课上串联 Asch/Milgram/Zimbardo：普通人在从众/权威/角色制度下会做出极端行为。',
    explanation: '''很多时候你不是“自控差”，而是“情境默认值”在推着你走。

与其只教育自己“要更努力”，不如先把环境设计成队友。''',
    why: '''情境会改变你的身份感、预期与线索：

当环境把“拖延/刷手机/回避”设成默认选项，你就需要用更大意志力对抗；反过来，换情境能显著降低阻力。''',
    howTo: [
      '把目标行为配一个“专用场景”（固定位置/固定时间/固定工具）。',
      '增加坏习惯的摩擦：距离、步骤、延迟、限制入口。',
      '降低好习惯的摩擦：把工具放到第一视线；只保留下一步。',
    ],
    caseStudy: '''你一到办公室就拖延：

把桌面改成执行情境：只开一个窗口、计时 10 分钟、把“下一步清单”贴在第一视线。

你会发现开始变容易，因为情境在替你做决定。''',
  ),
  Lecture56Module(
    index: 6,
    id: 'm06_priming',
    title: '启动效应：在心里“种种子”',
    lecture: 'Lecture 5 → 6',
    hookQuote: '"priming is planting a seed... consciously or subconsciously"',
    hookCase: '课上给 Bargh “Florida/old”词汇启动：被启动后人走得更慢；也提到“成就/坚持”启动能提高表现。',
    explanation: '''你以为你在自由选择，但很多时候你是在被环境的词、图像、音乐、仪式悄悄“引导”。

启动效应的关键是：改变线索，就能改变默认行为概率。''',
    why: '''当某个概念被激活（如“坚持/平静/成就”），你更容易注意到相关信息，也更容易做出匹配动作。

这不是魔法，而是注意力与联想网络的省力机制。''',
    howTo: [
      '为一个状态建立固定启动：一张启动词卡/一首开工曲/一个固定动作。',
      '同时移除反线索：把手机远离、关通知、减少多窗口。',
      '启动后立刻做“最小动作”（2 分钟），让启动落到现实。',
    ],
    caseStudy: '''你总拖延：把桌面最显眼位置换成“persistence / start small / one step”。

每次打开电脑先读 10 秒，然后立刻做 2 分钟“最小推进”。启动就会从“感觉”变成“行动”。''',
  ),
  Lecture56Module(
    index: 7,
    id: 'm07_placebo',
    title: '信念—体验回路（Placebo 视角）',
    lecture: 'Lecture 6',
    hookQuote: '（案例）告诉孕妇糖丸是止吐药 → 有效；甚至把催吐药解释为止吐药 → 仍止吐',
    hookCase: '课上用 Benson 的孕吐研究说明：期待会影响体验（但不等于否认外部）。',
    explanation: '''信念不等于万能，但它确实会参与结果。

你对身体/情绪的解释，会影响紧张度、注意力与行为，从而改变体验强度。''',
    why: '''期待会改变你对感受的解读与关注点：当你把紧张解释为“准备”，而不是“完蛋”，你更可能稳住呼吸、继续行动。''',
    howTo: [
      '先命名感受：我现在紧张/胸闷/心跳快。',
      '做 60 秒安全放松（呼吸/放松肌群）。',
      '给一个“可信”的新解释：紧张=身体在准备应对；我能先做下一步。',
    ],
    caseStudy: '''上台前胃痛：

你不否认它，而是承认“我在紧张”，做 60 秒呼吸，再说一句“紧张不等于失败”。

体验强度往往会下降，你就能把注意力放回行动。''',
  ),
  Lecture56Module(
    index: 8,
    id: 'm08_motivation',
    title: '机制一：动机（信念 → 更愿意投入）',
    lecture: 'Lecture 6',
    hookQuote: '"if I believe that I can do well... much more likely to be motivated"',
    hookCase: '课上把“信念变现实”的第一条路归为 motivation：相信能行 → 更愿意练习与坚持。',
    explanation: '''信念不会凭空变成绩，但它会先改变你“愿不愿意投入”。

当你相信“我能通过练习变好”，你更可能开始、坚持、寻求反馈。''',
    why: '''投入量与坚持时间，是多数技能的关键变量。

动机提升后，你的练习次数/复盘次数会增加，于是结果更好，信念被反过来强化。''',
    howTo: [
      '把目标拆到“今天 5 分钟可完成”。',
      '用 10 秒倒计时或“只做 2 分钟”降低开始门槛。',
      '完成后立刻记录一次证据：我做了___，这说明___。',
    ],
    caseStudy: '''学口语不敢开口：别把目标设成“流利”，先设成“今天说 3 句”。

当你完成 3 句，你的动机会因为“我做到了”而上升，明天更容易继续。''',
  ),
  Lecture56Module(
    index: 9,
    id: 'm09_schema',
    title: '机制二：自洽/图式（Schema）',
    lecture: 'Lecture 6',
    hookQuote: '"the mind does not like discrepancy... likes consistency"',
    hookCase: '课上讲：当外部与内部图式不一致，人会更新图式/忽略信息/寻找证据/创造现实来恢复一致。',
    explanation: '''你一旦有了某个“我是谁/世界怎样”的图式，大脑会自动让现实更像它。

这也是为什么信念会越滚越大：你会选择性注意、选择性解释。''',
    why: '''不一致会让人不舒服（认知失调）。为了省力，大脑会优先用“已有图式”解释新信息，于是你看到的证据越来越“支持你原本的信念”。''',
    howTo: [
      '把隐形图式写出来：我在这个领域的默认信念是___。',
      '收集双向证据：支持它的证据 3 条 + 反证 3 条。',
      '把图式从“判决”改成“假设”：我先用一个更可行动的版本试一周。',
    ],
    caseStudy: '''图式：我不擅长社交。

你会自动忽略别人对你点头微笑的证据。

本周你做一次实验：每天主动问候 1 人，并记录对方反应（真实数据会开始松动旧图式）。''',
  ),
  Lecture56Module(
    index: 10,
    id: 'm10_alignment',
    title: '四种“拉齐”策略：更新/忽略/找证据/创造现实',
    lecture: 'Lecture 6',
    hookQuote: '"Questions create reality"（你问什么，就更容易看见什么）',
    hookCase: '课上用班尼斯特四分钟一英里说明“创造新现实”；也提醒我们会忽略不匹配信息并找确认性证据。',
    explanation: '''当现实与信念冲突时，你通常会选择一种方式“恢复一致”。

关键不是否认这个机制，而是把它用在好的方向：用更好的问题、更好的行动去创造新证据。''',
    why: '''问题会引导注意力与证据收集：你问“哪里不行”，就会找失败证据；你问“我能试哪一步”，就会找到可行动证据。''',
    howTo: [
      '先选你现在用的是哪种策略：更新/忽略/找证据/创造现实。',
      '把问题从“评判”改成“行动”：我下一步最小能做什么？',
      '用 1 个现实行动生成新证据（哪怕 2 分钟）。',
    ],
    caseStudy: '''你觉得自己不可能坚持运动。

你不再问“我为什么这么懒”，而问“我能做哪一个最小运动？”

答案可能是“走 5 分钟”。当你完成它，你就在创造新现实证据。''',
  ),
  Lecture56Module(
    index: 11,
    id: 'm11_reality',
    title: '反对“只靠想”：现实校准（The Secret 的边界）',
    lecture: 'Lecture 6',
    hookQuote: '"draws on a truth... blows it out of proportion" + “guilt/责任归因风险”',
    hookCase: '课上提醒：把一切都归因于“你吸引来的”会导致对受害者的伤害与羞耻，也会让人忽视努力与现实限制。',
    explanation: '''信念重要，但它不是“魔法按钮”。

正确的版本是：信念改变你的行动概率；而现实结果还取决于努力、环境、他人、偶然。''',
    why: '''如果把结果全部归咎于“想对/想错”，你会忽略可控行动，也可能对自己或他人产生不必要的羞耻与责备。''',
    howTo: [
      '把事情分成三圈：我能控制/我能影响/我不能控制。',
      '在“控制圈”里选 1 个最小行动；在“不能控制圈”里写一句允许/接纳。',
      '遇到挫折时，先回到行动，而不是回到自责。',
    ],
    caseStudy: '''你想升职但没成功。

控制圈：提升作品、沟通、争取反馈；影响圈：找导师、争取曝光；不能控制：组织调整。

你不再自责“我没想对”，而是做一个可控行动：改一页成果总结并约一次反馈。''',
  ),
  Lecture56Module(
    index: 12,
    id: 'm12_stockdale',
    title: '现实乐观：Stockdale 悖论',
    lecture: 'Lecture 6',
    hookQuote: '"never confuse faith... with the discipline to confront the most brutal facts"',
    hookCase: '课上把它作为“成熟积极心理学”：保持终会胜利的信念，同时不逃避残酷事实。',
    explanation: '''真正的积极不是否认，而是“双手抓”：

一手抓信念（我会走出来），一手抓事实（我现在确实很难/这里确实需要改）。''',
    why: '''只有信念没有事实，会变成空想；只有事实没有信念，会变成绝望。

把两者放在一起，你才能既不崩溃，也不自欺。''',
    howTo: [
      '写下你的“信念句”：我终会___。',
      '写下你的“残酷事实”：目前最难的是___。',
      '写下“纪律行动”：今天我能做的最小一步是___。',
    ],
    caseStudy: '''求职被拒：信念=我会找到合适岗位；事实=简历某段不清晰；行动=今天只改一段经历并找 1 人点评。

你既不逃避，也不崩。''',
  ),
  Lecture56Module(
    index: 13,
    id: 'm13_selfeff',
    title: '自我效能：行动先于自信',
    lecture: 'Lecture 6',
    hookQuote: '"People... highly efficacious... produce their own future" + "Talk is no substitute for action"',
    hookCase: '课上强调自我效能是可培养的：通过小成功与应对经验，信念会被证据改写。',
    explanation: '''自我效能不是“自我鼓励”，而是“我做过”的证据感。

最有效的路径是：做一个可承担风险的小行动 → 得到结果/反馈 → 信念更新。''',
    why: '''当你积累小成功，你会更愿意挑战；当你更愿意挑战，你会获得更多能力证据。

所以关键不在于“想通”，而在于“做一点点”。''',
    howTo: [
      '选一个技能（表达/运动/学习/社交）。',
      '选一个“可承担风险”的最小行动（60 秒也行）。',
      '完成后写一句证据：我做了___，这说明我能___。',
    ],
    caseStudy: '''你害怕当众说话：今天只做 60 秒——在会议里提 1 个问题。

做完你就有证据：我能开口。

证据会比鸡汤更快建立自我效能。''',
  ),
  Lecture56Module(
    index: 14,
    id: 'm14_simulator',
    title: '内部模拟器：预演 + 立刻真做',
    lecture: 'Lecture 6',
    hookQuote: '（讲义）internal simulator：想象/预演能帮助进入状态，但必须接上行动',
    hookCase: '课上强调“行动不能被谈论替代（talk is no substitute for action）”：预演的正确位置是行动前奏。',
    explanation: '''想象/预演确实能降低恐惧、提高准备度。

但如果停在想象里，会变成拖延。

正确用法是：短预演 → 立刻做一个现实动作。''',
    why: '''预演能提前激活相关线索与策略；立即行动能把预演变成真实证据，从而更新信念与自我效能。''',
    howTo: [
      '选一个场景（发言/跑步/沟通/学习）。',
      '做 2 分钟预演（第一人称/第三人称/成功/失败预案）。',
      '预演后立刻做 1 个 60 秒现实动作（发一条消息/读一段/走两分钟）。',
    ],
    caseStudy: '''你要做一次重要沟通：先预演“我如何开头、对方可能怎么说、我怎么稳住呼吸”。

预演结束立刻发出那条开场消息（哪怕一句）。

你把想象变成现实证据。''',
  ),
  Lecture56Module(
    index: 15,
    id: 'm15_failure',
    title: '失败被低估：把失败当训练数据',
    lecture: 'Lecture 6',
    hookQuote: '"failure is underrated" / "I wish you fail more"',
    hookCase: '课上把失败比作“心理免疫系统”：让你更能应对、更能学习（learn to fail or fail to learn）。',
    explanation: '''失败不是你“价值不够”的证据，而是你正在训练的证据。

只要你能把失败复盘成下一步，你就在把失败变成增长。''',
    why: '''失败带来信息与免疫力。把解释从“我不行”改成“我还在学/方法要调”，你会更愿意继续尝试，长期能力增长更快。''',
    howTo: [
      '把失败写成事实：发生了什么？（不评价）',
      '选择一种更可行动的解释（成长/过程/策略）。',
      '做一个最小改进动作（5 分钟也算）。',
    ],
    caseStudy: '''你被拒绝：

解释从“我不配”换成“我还在学/方法不对”，然后做 5 分钟改进：改一段简历/练一段开场。

你把失败变成下一次成功的材料。''',
  ),
];

Lecture56Module? findLecture56Module(String id) {
  for (final m in kLecture56Modules) {
    if (m.id == id) return m;
  }
  return null;
}
