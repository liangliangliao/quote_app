import 'concept_playgrounds.dart';

/// Interactive wizards for the “Lecture 5–6 Belief Path (15 modules)”.
///
/// These wizards are fully preset (no AI generation) and reuse the same
/// meta-groups (scene/obstacle/boosters/reward) via [wrapWithMeta] so every
/// module ends with a concrete, everyday action card.

// ----- small helpers (duplicated from concept_playgrounds.dart; kept local) -----

PlaygroundOption _one(Map<String, List<PlaygroundOption>> picks, String key, PlaygroundOption fallback) {
  final list = picks[key];
  if (list == null || list.isEmpty) return fallback;
  return list.first;
}

List<PlaygroundOption> _many(Map<String, List<PlaygroundOption>> picks, String key) {
  return List<PlaygroundOption>.from(picks[key] ?? const []);
}

String _joinLabels(List<PlaygroundOption> opts, {String empty = '（未选择）'}) {
  if (opts.isEmpty) return empty;
  return opts.map((e) => e.label).join('、');
}

String _hintOrLabel(PlaygroundOption o) => o.hint == null || o.hint!.isEmpty ? o.label : '${o.label}（${o.hint}）';

// ----- advanced branch (unlocked after 3★ in module page) -----

const PlaygroundGroup _advancedBranchGroup = PlaygroundGroup(
  key: 'adv_branch',
  title: '进阶分支：在更难的真实条件下怎么做',
  description: '只有当你已经拿到 3★ 后，才建议打开进阶。选一个分支，行动卡会自动“降阻/加 buff”。',
  mode: SelectionMode.single,
  options: [
    PlaygroundOption(id: 'none', label: '不启用', hint: '保持基础版本'),
    PlaygroundOption(id: 'low_time', label: '时间很少', hint: '把下一步压缩到 30 秒'),
    PlaygroundOption(id: 'high_stress', label: '高压力/很焦虑', hint: '先稳住身体再行动'),
    PlaygroundOption(id: 'social_pressure', label: '社交压力', hint: '低暴露版本先开始'),
    PlaygroundOption(id: 'after_failure', label: '刚失败过', hint: '先做一次最小复盘再推进'),
    PlaygroundOption(id: 'low_energy', label: '能量很低', hint: '只做最小可完成'),
  ],
);

ConceptPlaygroundConfig _wrapWithAdvanced(ConceptPlaygroundConfig base) {
  return ConceptPlaygroundConfig(
    conceptId: base.conceptId,
    intro: '${base.intro}\n\n（进阶可选）如果你已经完成本关 3★，可以打开“进阶分支”，让行动卡更贴近真实困难。',
    groups: [...base.groups, _advancedBranchGroup],
    generator: (picks) {
      final card = base.generator(picks);
      const fb = PlaygroundOption(id: 'none', label: '不启用');
      final adv = _one(picks, 'adv_branch', fb);
      if (adv.id == 'none') return card;

      String advLine;
      final extraSteps = <String>[];
      switch (adv.id) {
        case 'low_time':
          advLine = '进阶分支：时间很少 → 把下一步压缩到 30 秒版本。';
          extraSteps.add('只做 30 秒版本：把“下一步”缩到一句话/一个动作（例如只写 1 行、只发 1 句）。');
          break;
        case 'high_stress':
          advLine = '进阶分支：高压力/焦虑 → 先稳住身体，再推进。';
          extraSteps.add('先做 3 轮呼吸（吸 4 秒/呼 6 秒），再做最小下一步（2 分钟也算）。');
          break;
        case 'social_pressure':
          advLine = '进阶分支：社交压力 → 用“低暴露版本”先开始。';
          extraSteps.add('把动作降为低暴露：先私下练 1 次/先发文字/先问 1 个问题，而不是直接“全场输出”。');
          break;
        case 'after_failure':
          advLine = '进阶分支：刚失败过 → 先做最小复盘，再推进。';
          extraSteps.add('用 60 秒写：事实=发生了什么；可行动解释=我还能怎么试；下一步=最小改进动作。');
          break;
        case 'low_energy':
          advLine = '进阶分支：能量很低 → 只做最小可完成。';
          extraSteps.add('把目标降到“可完成”：只做 1 次/1 分钟/1 句。完成后立刻停，不追加负担。');
          break;
        default:
          advLine = '进阶分支：${adv.label}。';
      }

      final summary = '${card.summary}\n\n$advLine';
      final steps = <String>[...extraSteps, ...card.steps];
      final why = '${card.whyShort}（进阶的目的不是更难，而是让你在真实条件下也能开始。）';
      final example = '${card.example}\n\n进阶提示：${advLine} 你不需要做到完美，只要做到“可开始”。';
      return ActionCard(title: card.title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  );
}

// ----- module configs -----

final Map<String, ConceptPlaygroundConfig> kLecture56Playgrounds = {
  // 01 Happiness contagion / positive-sum
  'm01_contagious': ConceptPlaygroundConfig(
    conceptId: 'm01_contagious',
    intro: '用 30 秒到 10 分钟，做一次“幸福传染”的微行为。你会得到一张可执行行动卡。',
    groups: const [
      PlaygroundGroup(
        key: 'target',
        title: '你想把“好状态”传给谁',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'self', label: '自己', hint: '把自己先稳住'),
          PlaygroundOption(id: 'partner', label: '伴侣/亲密关系'),
          PlaygroundOption(id: 'family', label: '家人', hint: '父母/孩子'),
          PlaygroundOption(id: 'colleague', label: '同事/同学'),
          PlaygroundOption(id: 'friend', label: '朋友'),
          PlaygroundOption(id: 'stranger', label: '陌生人', hint: '门卫/店员/路人'),
        ],
      ),
      PlaygroundGroup(
        key: 'act',
        title: '选择一种“传染方式”',
        description: '越具体越有效：不要说“加油”，而是说“我看见你做了___”。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'thanks', label: '具体感谢', hint: '点名一个具体行为'),
          PlaygroundOption(id: 'praise', label: '具体肯定', hint: '指出努力/策略/勇气'),
          PlaygroundOption(id: 'help', label: '一个小帮忙', hint: '30 秒可完成'),
          PlaygroundOption(id: 'checkin', label: '一句关心', hint: '“你现在还好吗？”'),
          PlaygroundOption(id: 'smile', label: '微笑/礼貌互动', hint: '抬眼+点头'),
          PlaygroundOption(id: 'share', label: '分享一条好消息', hint: '小而真'),
        ],
      ),
      PlaygroundGroup(
        key: 'time',
        title: '你愿意花多久',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '30s', label: '30 秒'),
          PlaygroundOption(id: '3m', label: '3 分钟'),
          PlaygroundOption(id: '10m', label: '10 分钟'),
        ],
      ),
    ],
    generator: (picks) {
      const fbTarget = PlaygroundOption(id: 'self', label: '自己');
      const fbAct = PlaygroundOption(id: 'thanks', label: '具体感谢');
      const fbTime = PlaygroundOption(id: '3m', label: '3 分钟');

      final target = _one(picks, 'target', fbTarget);
      final act = _one(picks, 'act', fbAct);
      final time = _one(picks, 'time', fbTime);

      final title = '幸福传染：对${target.label}做一次“${act.label}”';
      final summary = '在 ${time.label} 内，对「${target.label}」做一次：${_hintOrLabel(act)}。\n重点：具体、当下、可完成。';

      final steps = <String>[
        '先选一个具体对象：${target.label}（真实存在、今天能接触到）。',
        '用 ${time.label} 完成：${_hintOrLabel(act)}（越具体越好）。',
        '做完记录 1 句：对方反应是___；我的情绪从___到___。',
      ];

      final why = '幸福/积极情绪通常是“正和”的：当你给出具体感谢与支持，你们的关系质量会变好，你自己的情绪也更稳。';

      final example = '例子：你选择「同事/同学 + 具体肯定 + 30 秒」。\n把“你真厉害”换成“我注意到你刚才把报告结构讲得很清晰，这帮我省了很多时间”。\n对方更容易接住，你也更容易进入正向循环。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 02 Broaden & Build
  'm02_broaden_build': ConceptPlaygroundConfig(
    conceptId: 'm02_broaden_build',
    intro: '选择你现在的状态与时间，我们生成一个“拓展动作”，把带宽加宽一点点。',
    groups: const [
      PlaygroundGroup(
        key: 'mood',
        title: '你现在的情绪天气',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'storm', label: '暴风雨', hint: '很烦/很乱/撑不住'),
          PlaygroundOption(id: 'cloudy', label: '阴天', hint: '低落/没劲'),
          PlaygroundOption(id: 'windy', label: '大风', hint: '焦虑/紧张'),
          PlaygroundOption(id: 'fog', label: '大雾', hint: '迷茫/脑雾'),
          PlaygroundOption(id: 'clear', label: '晴天', hint: '还不错'),
          PlaygroundOption(id: 'sunny', label: '大晴', hint: '轻松/有能量'),
        ],
      ),
      PlaygroundGroup(
        key: 'goal',
        title: '你想拓展到什么方向',
        description: '拓展不是“强迫开心”，而是给大脑更多选项。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'connect', label: '连接', hint: '找回支持感'),
          PlaygroundOption(id: 'explore', label: '探索', hint: '走出去/换视角'),
          PlaygroundOption(id: 'learn', label: '学习', hint: '获得新策略'),
          PlaygroundOption(id: 'move', label: '运动', hint: '身体带动心情'),
          PlaygroundOption(id: 'gratitude', label: '感恩', hint: '看见已有的'),
          PlaygroundOption(id: 'create', label: '创造', hint: '做点小作品'),
        ],
      ),
      PlaygroundGroup(
        key: 'time',
        title: '你现在有多少时间',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '30s', label: '30 秒'),
          PlaygroundOption(id: '2m', label: '2 分钟'),
          PlaygroundOption(id: '5m', label: '5 分钟'),
          PlaygroundOption(id: '10m', label: '10 分钟'),
        ],
      ),
      PlaygroundGroup(
        key: 'action',
        title: '选择一个“拓展动作”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'msg', label: '发一句连接消息', hint: '“我想聊聊/你在吗”'),
          PlaygroundOption(id: 'walk', label: '走 5 分钟看 3 个细节', hint: '换场景'),
          PlaygroundOption(id: 'breath', label: '呼吸 6 轮 + 扫描身体', hint: '先稳住'),
          PlaygroundOption(id: 'grat', label: '写 3 个小感恩', hint: '越具体越好'),
          PlaygroundOption(id: 'learn1', label: '学 1 个小技巧', hint: '看 1 段教程/1 页书'),
          PlaygroundOption(id: 'create1', label: '做 1 个小创作', hint: '写 4 句/画 1 个图标'),
        ],
      ),
    ],
    generator: (picks) {
      const fallbackMood = PlaygroundOption(id: 'cloudy', label: '阴天');
      const fallbackGoal = PlaygroundOption(id: 'connect', label: '连接');
      const fallbackTime = PlaygroundOption(id: '2m', label: '2 分钟');
      const fallbackAction = PlaygroundOption(id: 'msg', label: '发一句连接消息');

      final mood = _one(picks, 'mood', fallbackMood);
      final goal = _one(picks, 'goal', fallbackGoal);
      final time = _one(picks, 'time', fallbackTime);
      final action = _one(picks, 'action', fallbackAction);

      final title = '拓展动作：${action.label}';
      final summary = '你现在是「${mood.label}」→ 目标是「${goal.label}」。\n用 ${time.label} 做：${_hintOrLabel(action)}。';

      final steps = <String>[
        '先说一句：我现在是「${mood.label}」，这很正常（不评判）。',
        '计时 ${time.label}，只做一件事：${_hintOrLabel(action)}。',
        '做完写一句：我看到的新可能是___；我下一步愿意试___。',
      ];

      final why = '积极体验会“加宽带宽”，让你更容易看到选项；拓展动作是最低成本的带宽恢复。';

      final example = '例子：你处在「${mood.label}」时容易反刍。\n你不强迫自己开心，只做 ${time.label} 的「${action.label}」。\n当你完成一次小连接/小移动，你会更容易从“钻牛角尖”切回“可行动”。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 03 Appreciation (two meanings)
  'm03_appreciation': ConceptPlaygroundConfig(
    conceptId: 'm03_appreciation',
    intro: '把“欣赏”做成可操作的行为：选对象→选具体点→选表达方式→马上做。',
    groups: const [
      PlaygroundGroup(
        key: 'who',
        title: '你要欣赏谁（或什么）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'self', label: '自己', hint: '给自己具体肯定'),
          PlaygroundOption(id: 'partner', label: '伴侣/亲密关系'),
          PlaygroundOption(id: 'family', label: '家人'),
          PlaygroundOption(id: 'team', label: '团队/同事'),
          PlaygroundOption(id: 'friend', label: '朋友'),
        ],
      ),
      PlaygroundGroup(
        key: 'focus',
        title: '你欣赏的“具体点”',
        description: '欣赏=表达感谢 + 让好“增值”。越具体越容易发生。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'effort', label: '努力', hint: '坚持/投入'),
          PlaygroundOption(id: 'progress', label: '进步', hint: '比昨天好一点'),
          PlaygroundOption(id: 'strategy', label: '策略', hint: '用对方法'),
          PlaygroundOption(id: 'value', label: '价值观', hint: '善良/诚实/负责'),
          PlaygroundOption(id: 'care', label: '体贴', hint: '照顾到细节'),
          PlaygroundOption(id: 'courage', label: '勇气', hint: '敢开口/敢尝试'),
        ],
      ),
      PlaygroundGroup(
        key: 'channel',
        title: '你用什么方式表达',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'say', label: '当面说', hint: '10 秒也算'),
          PlaygroundOption(id: 'text', label: '发消息', hint: '一句话即可'),
          PlaygroundOption(id: 'note', label: '写便签/小卡片', hint: '贴在可见处'),
          PlaygroundOption(id: 'public', label: '公开肯定', hint: '在群里/会议里'),
        ],
      ),
      PlaygroundGroup(
        key: 'detail',
        title: '具体到什么程度',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '1', label: '1 个细节', hint: '最容易开始'),
          PlaygroundOption(id: '2', label: '2 个细节', hint: '更可信'),
          PlaygroundOption(id: '3', label: '3 个细节', hint: '更有力量'),
        ],
      ),
    ],
    generator: (picks) {
      const fbWho = PlaygroundOption(id: 'self', label: '自己');
      const fbFocus = PlaygroundOption(id: 'effort', label: '努力');
      const fbChannel = PlaygroundOption(id: 'text', label: '发消息');
      const fbDetail = PlaygroundOption(id: '1', label: '1 个细节');

      final who = _one(picks, 'who', fbWho);
      final focus = _one(picks, 'focus', fbFocus);
      final channel = _one(picks, 'channel', fbChannel);
      final detail = _one(picks, 'detail', fbDetail);

      final title = '欣赏让好增值：对${who.label}做一次具体欣赏';
      final summary = '用「${channel.label}」对「${who.label}」表达一次欣赏，聚焦「${focus.label}」，至少提到 ${detail.label}。';

      final steps = <String>[
        '先写一句模板：我注意到你在___（具体行为）。',
        '补一句“意义”：这让我感到___ / 这对我意味着___。',
        '立刻用「${channel.label}」发出/说出（不等完美）。',
        '最后记录：对方反应___；我自己的状态___。',
      ];

      final why = '当你把注意力放在“做对的部分”，你会更愿意重复它、也更愿意看到它；系统会进入上升螺旋。';

      final example = '例子：你选「团队 + 策略 + 公开肯定」。\n把“你很棒”换成“我注意到你把风险点提前列出来并给了备选方案，这让整个团队更安心”。\n具体欣赏会强化可复制的行为，而不是空泛情绪。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 04 Modeling (do what you do)
  'm04_modeling': ConceptPlaygroundConfig(
    conceptId: 'm04_modeling',
    intro: '选一个你想影响的习惯，把“说教”翻译成“示范动作”。',
    groups: const [
      PlaygroundGroup(
        key: 'influence',
        title: '你想影响谁',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'self', label: '自己'),
          PlaygroundOption(id: 'child', label: '孩子'),
          PlaygroundOption(id: 'partner', label: '伴侣'),
          PlaygroundOption(id: 'team', label: '团队/同事'),
          PlaygroundOption(id: 'friend', label: '朋友'),
        ],
      ),
      PlaygroundGroup(
        key: 'habit',
        title: '你想影响的主题',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'sleep', label: '早睡', hint: '睡前不刷手机'),
          PlaygroundOption(id: 'move', label: '运动', hint: '每天 10 分钟'),
          PlaygroundOption(id: 'learn', label: '学习', hint: '固定时间'),
          PlaygroundOption(id: 'phone', label: '少刷手机', hint: '增加阻力'),
          PlaygroundOption(id: 'kind', label: '更友善', hint: '具体表达'),
          PlaygroundOption(id: 'focus', label: '更专注', hint: '开工仪式'),
        ],
      ),
      PlaygroundGroup(
        key: 'visibility',
        title: '示范的“被看见程度”',
        description: '被看见不等于表演；它是给别人一个可复制的线索。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'low', label: '低', hint: '先默默坚持 3 天'),
          PlaygroundOption(id: 'mid', label: '中', hint: '让对方知道你在做'),
          PlaygroundOption(id: 'high', label: '高', hint: '公开打卡/邀请一起'),
        ],
      ),
      PlaygroundGroup(
        key: 'duration',
        title: '你愿意先示范多久',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '3d', label: '3 天'),
          PlaygroundOption(id: '7d', label: '7 天'),
          PlaygroundOption(id: '14d', label: '14 天'),
        ],
      ),
    ],
    generator: (picks) {
      const fbInfluence = PlaygroundOption(id: 'self', label: '自己');
      const fbHabit = PlaygroundOption(id: 'sleep', label: '早睡');
      const fbVis = PlaygroundOption(id: 'mid', label: '中');
      const fbDur = PlaygroundOption(id: '7d', label: '7 天');

      final who = _one(picks, 'influence', fbInfluence);
      final habit = _one(picks, 'habit', fbHabit);
      final vis = _one(picks, 'visibility', fbVis);
      final dur = _one(picks, 'duration', fbDur);

      final title = '以身作则：先示范「${habit.label}」';
      final summary = '对「${who.label}」的影响策略：少说教，多示范。\n用「${vis.label}」方式，坚持 ${dur.label}。';

      final steps = <String>[
        '把示范动作具体化：今天我会做的第一步是___（越小越好）。',
        '让线索可被看见：把工具/规则/时间放到显眼位置。',
        '坚持 ${dur.label} 只追求“可重复”，不追求完美。',
        '如果对方问起，用一句话邀请：我在练___，你想不想一起试 1 次？',
      ];

      final why = '人更容易跟随“看到的行为线索”，而不是被说服的道理；示范会改变群体的默认规范。';

      final example = '例子：你想让孩子少刷手机。\n你把自己的手机睡前放门口充电，坚持 7 天；同时把一本书放在床边第一视线。\n你示范的是“替代行为 + 环境线索”，比“别玩手机”更有效。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 05 Power of situation / design environment
  'm05_situation': ConceptPlaygroundConfig(
    conceptId: 'm05_situation',
    intro: '与其靠意志硬扛，不如改情境：选一个杠杆，做一次最小环境改造。',
    groups: const [
      PlaygroundGroup(
        key: 'goal',
        title: '你想让哪个行为更容易发生',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'focus', label: '更专注'),
          PlaygroundOption(id: 'start', label: '更容易开始'),
          PlaygroundOption(id: 'calm', label: '更稳定'),
          PlaygroundOption(id: 'health', label: '更健康'),
          PlaygroundOption(id: 'kind', label: '更友善'),
          PlaygroundOption(id: 'learn', label: '更持续学习'),
        ],
      ),
      PlaygroundGroup(
        key: 'lever',
        title: '你要用哪种“情境杠杆”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'physical', label: '物理环境', hint: '距离/摆放/第一视线'),
          PlaygroundOption(id: 'digital', label: '数字环境', hint: '通知/APP 排序'),
          PlaygroundOption(id: 'social', label: '社交环境', hint: '同伴/公开承诺'),
          PlaygroundOption(id: 'role', label: '角色脚本', hint: '今天我是谁'),
        ],
      ),
      PlaygroundGroup(
        key: 'change',
        title: '选一个最小改造动作',
        description: '改造要小到“今天就能做”，越小越有效。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'phone_far', label: '手机远离 2 米', hint: '放到另一个房间'),
          PlaygroundOption(id: 'one_window', label: '只开 1 个窗口', hint: '关掉其它标签'),
          PlaygroundOption(id: 'tools_first', label: '工具放第一视线', hint: '文档/器材先打开'),
          PlaygroundOption(id: 'timer10', label: '先 10 分钟计时', hint: '只做最小步'),
          PlaygroundOption(id: 'buddy', label: '找同伴一句话互盯', hint: '“我开始了”'),
          PlaygroundOption(id: 'role_exec', label: '写角色一句话', hint: '“今天我只推进一件事”'),
          PlaygroundOption(id: 'remove_snack', label: '把诱惑移走', hint: '零食放高处'),
        ],
      ),
      PlaygroundGroup(
        key: 'commit',
        title: '你愿意先坚持多久',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'today', label: '今天一次'),
          PlaygroundOption(id: '3d', label: '3 天'),
          PlaygroundOption(id: '7d', label: '7 天'),
        ],
      ),
    ],
    generator: (picks) {
      const fbGoal = PlaygroundOption(id: 'start', label: '更容易开始');
      const fbLever = PlaygroundOption(id: 'physical', label: '物理环境');
      const fbChange = PlaygroundOption(id: 'timer10', label: '先 10 分钟计时');
      const fbCommit = PlaygroundOption(id: 'today', label: '今天一次');

      final goal = _one(picks, 'goal', fbGoal);
      final lever = _one(picks, 'lever', fbLever);
      final change = _one(picks, 'change', fbChange);
      final commit = _one(picks, 'commit', fbCommit);

      final title = '情境设计：让「${goal.label}」更容易';
      final summary = '用「${lever.label}」做一次最小改造：${_hintOrLabel(change)}。\n先承诺：${commit.label}。';

      final steps = <String>[
        '现在就做：${_hintOrLabel(change)}（不等心情）。',
        '写一句情境脚本：当我进入这个场景，我就做第一步___。',
        '只追求“发生”，不追求“做得好”。',
        '结束时记录：今天这个情境让开始难度从___降到___（0-10）。',
      ];

      final why = '情境与角色会强力塑形：把正确行为变成默认线索，比靠意志对抗诱惑更可靠。';

      final example = '例子：你想更专注。\n你把手机放到另一个房间（物理杠杆）+ 只开 1 个窗口（数字杠杆）+ 先做 10 分钟（时间杠杆）。\n同样的你，在不同情境里会表现得像“不同的人”。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 06 Priming (seed)
  'm06_priming': ConceptPlaygroundConfig(
    conceptId: 'm06_priming',
    intro: '选择你想进入的状态与启动通道，并移除反线索。我们生成一张“启动行动卡”。',
    groups: const [
      PlaygroundGroup(
        key: 'state',
        title: '你想进入的状态',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'focus', label: '专注'),
          PlaygroundOption(id: 'start', label: '开始'),
          PlaygroundOption(id: 'calm', label: '平静'),
          PlaygroundOption(id: 'confidence', label: '自信'),
          PlaygroundOption(id: 'persistence', label: '坚持'),
          PlaygroundOption(id: 'kindness', label: '友善'),
        ],
      ),
      PlaygroundGroup(
        key: 'channel',
        title: '你的启动通道',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'words', label: '词语启动', hint: '10 秒读启动词'),
          PlaygroundOption(id: 'music', label: '音乐启动', hint: '一首固定开工曲'),
          PlaygroundOption(id: 'image', label: '图片启动', hint: '锁屏/壁纸'),
          PlaygroundOption(id: 'object', label: '物品启动', hint: '工具放第一视线'),
          PlaygroundOption(id: 'ritual', label: '仪式启动', hint: '同一动作=开工'),
          PlaygroundOption(id: 'buddy', label: '同伴启动', hint: '一句话互相提醒'),
        ],
      ),
      PlaygroundGroup(
        key: 'pack',
        title: '选择一个启动词包',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'ach', label: '成就包', hint: '坚持·推进·完成'),
          PlaygroundOption(id: 'calm', label: '平静包', hint: '呼吸·放松·允许'),
          PlaygroundOption(id: 'courage', label: '勇气包', hint: '开口·尝试·不必完美'),
          PlaygroundOption(id: 'focus', label: '专注包', hint: '只做这一件·先 2 分钟'),
          PlaygroundOption(id: 'gentle', label: '温柔包', hint: '慢一点也可以·照顾自己'),
        ],
      ),
      PlaygroundGroup(
        key: 'remove',
        title: '移除反线索（最多选 2 个）',
        mode: SelectionMode.multi,
        maxSelect: 2,
        options: [
          PlaygroundOption(id: 'phone_far', label: '手机放远', hint: '至少 2 米'),
          PlaygroundOption(id: 'notify_off', label: '关通知', hint: '30 分钟'),
          PlaygroundOption(id: 'one_window', label: '只开 1 个窗口'),
          PlaygroundOption(id: 'clean_desk', label: '桌面只留任务物'),
          PlaygroundOption(id: 'block_app', label: '加一层阻力', hint: '短视频延迟'),
        ],
      ),
    ],
    generator: (picks) {
      const fbState = PlaygroundOption(id: 'start', label: '开始');
      const fbChannel = PlaygroundOption(id: 'words', label: '词语启动');
      const fbPack = PlaygroundOption(id: 'ach', label: '成就包');

      final state = _one(picks, 'state', fbState);
      final channel = _one(picks, 'channel', fbChannel);
      final pack = _one(picks, 'pack', fbPack);
      final remove = _many(picks, 'remove');

      final removeTxt = _joinLabels(remove, empty: '无');

      final title = '启动卡：进入「${state.label}」';
      final summary = '用「${channel.label}」启动你想要的状态：${state.label}。\n启动词包：${pack.label}。反线索移除：${removeTxt}。';

      final steps = <String>[
        '开始前 10 秒：用「${channel.label}」做启动（读词/放音乐/看图/摆好工具）。',
        '立刻做“第一步”：只开始 2 分钟（不要等动力）。',
        if (remove.isNotEmpty) '把反线索处理掉：${removeTxt}（减少竞争线索）。',
        '结束后记录：开始难度从___降到___（0-10）。',
      ];

      final why = '启动效应像“种子”：最近被激活的线索会成为行为导航；你可以反过来设计线索，让正确行为更像默认值。';

      final example = '例子：你总拖延。\n你用“专注包”做开工启动（只做这一件·先 2 分钟）+ 手机放远。\n你不是靠意志赢，而是让环境线索帮你赢。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 07 Placebo / belief → experience
  'm07_placebo': ConceptPlaygroundConfig(
    conceptId: 'm07_placebo',
    intro: '用安全的方式体验：不同信念，会如何改变你的投入与感受（不是玄学）。',
    groups: const [
      PlaygroundGroup(
        key: 'domain',
        title: '你要在哪个领域做一次“信念-结果小实验”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'learn', label: '学习/考试'),
          PlaygroundOption(id: 'work', label: '工作/项目'),
          PlaygroundOption(id: 'sport', label: '运动/体能'),
          PlaygroundOption(id: 'social', label: '社交/开口'),
          PlaygroundOption(id: 'sleep', label: '睡眠/放松'),
        ],
      ),
      PlaygroundGroup(
        key: 'expect',
        title: '你选择哪种“预期版本”',
        description: '不是假装，而是选择一个你“愿意试试看”的解释。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'a', label: '我不行', hint: '容易放弃'),
          PlaygroundOption(id: 'b', label: '我也许行', hint: '愿意试一次'),
          PlaygroundOption(id: 'c', label: '我能通过练习变好', hint: '把结果交给过程'),
        ],
      ),
      PlaygroundGroup(
        key: 'task',
        title: '选一个 2 分钟以内的小任务',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '2m', label: '只开始 2 分钟', hint: '计时器'),
          PlaygroundOption(id: 'breath', label: '呼吸 6 轮', hint: '4 吸 6 呼'),
          PlaygroundOption(id: 'read', label: '朗读/复述 1 段', hint: '30 秒'),
          PlaygroundOption(id: 'practice', label: '练 1 次关键动作', hint: '一遍也算'),
          PlaygroundOption(id: 'msg', label: '发 1 条消息', hint: '开口/求助/感谢'),
        ],
      ),
    ],
    generator: (picks) {
      const fbDomain = PlaygroundOption(id: 'work', label: '工作/项目');
      const fbExpect = PlaygroundOption(id: 'b', label: '我也许行');
      const fbTask = PlaygroundOption(id: '2m', label: '只开始 2 分钟');

      final domain = _one(picks, 'domain', fbDomain);
      final expect = _one(picks, 'expect', fbExpect);
      final task = _one(picks, 'task', fbTask);

      final title = '信念小实验：在「${domain.label}」里试 ${task.label}';
      final summary = '用信念版本「${expect.label}」进入任务，然后做：${_hintOrLabel(task)}。\n记录前后差异（投入/紧张/继续意愿）。';

      final steps = <String>[
        '开始前打分：紧张/阻力 0-10 = ___。',
        '对自己说一句：${expect.label}（只要求“可相信”，不求宏大）。',
        '立刻做：${_hintOrLabel(task)}。',
        '结束后再打分：紧张/阻力 0-10 = ___；继续意愿 0-10 = ___。',
      ];

      final why = '信念会通过“期待 + 注意力 + 身体紧张度 + 行为投入”影响体验与结果；小实验让你看到这条链。';

      final example = '例子：你选「社交/开口」+ 信念「我也许行」+ 任务「发 1 条消息」。\n你会发现：当你允许“也许”，你更可能去做；做了之后，信念会被新的证据更新。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 08 Motivation (belief → persistence)
  'm08_motivation': ConceptPlaygroundConfig(
    conceptId: 'm08_motivation',
    intro: '把“我能不能”翻译成“我愿不愿意投入”。动机来自可开始的设计。',
    groups: const [
      PlaygroundGroup(
        key: 'goal',
        title: '你要推进的目标',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'study', label: '学习/备考'),
          PlaygroundOption(id: 'work', label: '工作推进'),
          PlaygroundOption(id: 'health', label: '健康/运动'),
          PlaygroundOption(id: 'social', label: '社交/表达'),
          PlaygroundOption(id: 'life', label: '生活整理'),
        ],
      ),
      PlaygroundGroup(
        key: 'ignite',
        title: '选择你的“点火方式”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'tiny', label: '小胜利', hint: '1 分钟也算'),
          PlaygroundOption(id: 'countdown', label: '10 秒倒计时', hint: '到 0 就做第一步'),
          PlaygroundOption(id: 'buddy', label: '同伴见证', hint: '发一句“我开始了”'),
          PlaygroundOption(id: 'schedule', label: '固定时间', hint: '每天同一时刻'),
          PlaygroundOption(id: 'reward', label: '立即奖励', hint: '完成就奖励'),
        ],
      ),
      PlaygroundGroup(
        key: 'first',
        title: '你的第一步要小到什么程度',
        description: '第一步越小，动机越容易启动。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '30s', label: '30 秒', hint: '打开材料/写标题'),
          PlaygroundOption(id: '2m', label: '2 分钟', hint: '只做最小推进'),
          PlaygroundOption(id: '10m', label: '10 分钟', hint: '番茄开始'),
        ],
      ),
    ],
    generator: (picks) {
      const fbGoal = PlaygroundOption(id: 'work', label: '工作推进');
      const fbIgnite = PlaygroundOption(id: 'tiny', label: '小胜利');
      const fbFirst = PlaygroundOption(id: '2m', label: '2 分钟');

      final goal = _one(picks, 'goal', fbGoal);
      final ignite = _one(picks, 'ignite', fbIgnite);
      final first = _one(picks, 'first', fbFirst);

      final title = '动机点火：让「${goal.label}」先发生';
      final summary = '用「${ignite.label}」点火，把第一步缩小到 ${first.label}，让行动比犹豫更快。';

      final steps = <String>[
        '把任务拆成一个“可开始”的动作：只做 ${first.label} 的第一步。',
        '用点火方式：${_hintOrLabel(ignite)}。',
        '做完立刻给自己一个微反馈：我完成了___，下一步是___。',
      ];

      final why = '当你相信“能做出一点点”，你更可能投入；投入带来证据，证据反过来强化信念与动机。';

      final example = '例子：你要写报告。\n第一步不是“写完”，而是“打开文档写标题 30 秒”。\n只要开始，动机就会被行为证据点燃。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 09 Consistency / schema
  'm09_schema': ConceptPlaygroundConfig(
    conceptId: 'm09_schema',
    intro: '识别你正在运行的“图式/默认信念”，并选择一种更有用的更新方式。',
    groups: const [
      PlaygroundGroup(
        key: 'domain',
        title: '你的图式发生在哪个领域',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'ability', label: '能力/工作表现'),
          PlaygroundOption(id: 'relationship', label: '关系/被爱'),
          PlaygroundOption(id: 'body', label: '身体/外貌/健康'),
          PlaygroundOption(id: 'money', label: '金钱/价值'),
          PlaygroundOption(id: 'emotion', label: '情绪/稳定'),
        ],
      ),
      PlaygroundGroup(
        key: 'schema',
        title: '你更像在运行哪条图式（最多选 2 条）',
        mode: SelectionMode.multi,
        maxSelect: 2,
        options: [
          PlaygroundOption(id: 'perfect', label: '我必须完美才值得'),
          PlaygroundOption(id: 'judge', label: '别人都在评判我'),
          PlaygroundOption(id: 'never', label: '我总是做不好'),
          PlaygroundOption(id: 'avoid', label: '做不好就别开始'),
          PlaygroundOption(id: 'control', label: '我必须掌控一切'),
          PlaygroundOption(id: 'not_enough', label: '我不够好/不配'),
        ],
      ),
      PlaygroundGroup(
        key: 'move',
        title: '你今天要用哪种“自洽动作”',
        description: '自洽不是骗自己，而是用证据更新脑内模型。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'update', label: '更新图式', hint: '写一个更真实的版本'),
          PlaygroundOption(id: 'counter', label: '找反证', hint: '列 2 条反证'),
          PlaygroundOption(id: 'question', label: '换问题', hint: '用新问题收集证据'),
          PlaygroundOption(id: 'micro', label: '做 1% 行动', hint: '用行为改叙事'),
        ],
      ),
      PlaygroundGroup(
        key: 'q',
        title: '选一个“新问题”去收集证据',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'what_worked', label: '今天哪里做对了？'),
          PlaygroundOption(id: 'next_step', label: '下一步最小动作是什么？'),
          PlaygroundOption(id: 'support', label: '我能向谁求助？'),
          PlaygroundOption(id: 'learn', label: '我从这件事学到什么？'),
        ],
      ),
    ],
    generator: (picks) {
      const fbDomain = PlaygroundOption(id: 'ability', label: '能力/工作表现');
      final schemas = _many(picks, 'schema');
      const fbMove = PlaygroundOption(id: 'micro', label: '做 1% 行动');
      const fbQ = PlaygroundOption(id: 'next_step', label: '下一步最小动作是什么？');

      final domain = _one(picks, 'domain', fbDomain);
      final move = _one(picks, 'move', fbMove);
      final q = _one(picks, 'q', fbQ);

      final schemaTxt = _joinLabels(schemas, empty: '（我还没想清楚）');

      final title = '图式扫描：在「${domain.label}」里更新自洽';
      final summary = '你可能在运行：${schemaTxt}。\n今天用「${move.label}」+ 问题「${q.label}」去收集新证据。';

      final steps = <String>[
        '写下：我现在的默认想法是___（不评判，只记录）。',
        '选择动作：${_hintOrLabel(move)}。',
        '用新问题去找证据：${q.label}（至少写 2 条）。',
        '把旧图式改成“更可执行”的版本：我愿意先___。',
      ];

      final why = '大脑偏好一致性：会自动筛选信息来证明旧信念。用“新问题 + 新证据”，你可以更新图式。';

      final example = '例子：你觉得“我总是做不好”。\n你用问题“下一步最小动作是什么？”去找证据：写 2 条可做的动作。\n当你做了 1% 行动，你就制造了反证：我不是“总做不好”，我能推进一点点。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 10 Four alignment strategies / questions create reality
  'm10_alignment': ConceptPlaygroundConfig(
    conceptId: 'm10_alignment',
    intro: '当现实与信念不一致时，你会怎么“拉齐”？选一种更有益的策略。',
    groups: const [
      PlaygroundGroup(
        key: 'strategy',
        title: '你要用哪种拉齐策略',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'update', label: '更新信念', hint: '让模型更真实'),
          PlaygroundOption(id: 'ignore', label: '减少接触噪音', hint: '别喂垃圾信息'),
          PlaygroundOption(id: 'seek', label: '主动找证据', hint: '收集支持/反证'),
          PlaygroundOption(id: 'create', label: '创造新现实', hint: '用行动造证据'),
        ],
      ),
      PlaygroundGroup(
        key: 'lens',
        title: '你用什么“提问镜头”看这件事',
        description: '问题会决定你看见什么证据。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'blame', label: '哪里错了？', hint: '容易陷入指责'),
          PlaygroundOption(id: 'strength', label: '哪里做对了？', hint: '放大可复制'),
          PlaygroundOption(id: 'learn', label: '我学到了什么？', hint: '转成训练'),
          PlaygroundOption(id: 'next', label: '下一步最小动作？', hint: '直接可执行'),
        ],
      ),
      PlaygroundGroup(
        key: 'act',
        title: '选一个“证据动作”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '1pct', label: '做 1% 推进', hint: '2 分钟'),
          PlaygroundOption(id: 'ask', label: '问一个问题', hint: '向人求信息/反馈'),
          PlaygroundOption(id: 'practice', label: '练 1 次关键技能', hint: '一遍也算'),
          PlaygroundOption(id: 'remove', label: '移除一个干扰', hint: '让选择更容易'),
          PlaygroundOption(id: 'schedule', label: '预约一次练习时间', hint: '写进日历'),
        ],
      ),
    ],
    generator: (picks) {
      const fbStr = PlaygroundOption(id: 'create', label: '创造新现实');
      const fbLens = PlaygroundOption(id: 'next', label: '下一步最小动作？');
      const fbAct = PlaygroundOption(id: '1pct', label: '做 1% 推进');

      final s = _one(picks, 'strategy', fbStr);
      final lens = _one(picks, 'lens', fbLens);
      final act = _one(picks, 'act', fbAct);

      final title = '拉齐策略：${s.label}';
      final summary = '用「${s.label}」处理不一致，并用问题「${lens.label}」收集证据；今天做：${_hintOrLabel(act)}。';

      final steps = <String>[
        '写下冲突点：我相信___，但现实显示___。',
        '选策略：${_hintOrLabel(s)}。',
        '用镜头提问：${lens.label}（至少写 2 条答案）。',
        '做证据动作：${_hintOrLabel(act)}，把答案变成行动。',
      ];

      final why = '一致性需求会让你自动选择性注意。把“问题”换成更有用的镜头，并用行动制造证据，你就能把现实拉向更好的版本。';

      final example = '例子：你觉得自己“没毅力”。\n你选策略“创造新现实”+ 镜头“下一步最小动作？”+ 动作“2 分钟推进”。\n当你做完 2 分钟，你就制造了反证：我可以开始。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 11 Reality calibrator (anti overclaim)
  'm11_reality': ConceptPlaygroundConfig(
    conceptId: 'm11_reality',
    intro: '信念很重要，但“只靠想”会伤人。把目标拆成：可控/可影响/不可控。',
    groups: const [
      PlaygroundGroup(
        key: 'topic',
        title: '你要校准的情境',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'health', label: '健康/身体'),
          PlaygroundOption(id: 'work', label: '工作/经济'),
          PlaygroundOption(id: 'relationship', label: '关系/家庭'),
          PlaygroundOption(id: 'study', label: '学习/考试'),
          PlaygroundOption(id: 'life', label: '生活事件/变故'),
        ],
      ),
      PlaygroundGroup(
        key: 'bias',
        title: '你可能在哪一块“过度背锅/过度控制”',
        description: '选一个最符合的倾向，不是为了自责，而是为了更有用。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'all_me', label: '把一切都归咎自己', hint: '容易内疚'),
          PlaygroundOption(id: 'all_control', label: '以为一切都能控制', hint: '容易崩溃'),
          PlaygroundOption(id: 'avoid', label: '干脆不想', hint: '回避现实'),
          PlaygroundOption(id: 'blame_other', label: '都怪别人/环境', hint: '失去行动感'),
        ],
      ),
      PlaygroundGroup(
        key: 'step',
        title: '选一个“可控的一步行动”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'ask_help', label: '求助/咨询一次', hint: '找人/找专业'),
          PlaygroundOption(id: 'routine', label: '建立一个小例行', hint: '10 分钟'),
          PlaygroundOption(id: 'info', label: '收集 1 条信息', hint: '减少未知'),
          PlaygroundOption(id: 'boundary', label: '设一个边界', hint: '拒绝/限制'),
          PlaygroundOption(id: 'rest', label: '休息与照顾', hint: '把身体先稳住'),
        ],
      ),
    ],
    generator: (picks) {
      const fbTopic = PlaygroundOption(id: 'work', label: '工作/经济');
      const fbBias = PlaygroundOption(id: 'all_control', label: '以为一切都能控制');
      const fbStep = PlaygroundOption(id: 'info', label: '收集 1 条信息');

      final topic = _one(picks, 'topic', fbTopic);
      final bias = _one(picks, 'bias', fbBias);
      final step = _one(picks, 'step', fbStep);

      final title = '现实校准：在「${topic.label}」里回到可控区';
      final summary = '识别倾向：${_hintOrLabel(bias)}。\n把问题拆成可控/可影响/不可控，并先做：${_hintOrLabel(step)}。';

      final steps = <String>[
        '写三栏：我能控制的___；我能影响的___；我不能控制的___。',
        '对“不可控”写一句允许：这部分我先允许存在。',
        '对“可控”选择一步：${_hintOrLabel(step)}。',
        '做完记录：我今天向前移动了 1% 的证据是___。',
      ];

      final why = '把一切都归咎于“想得不够好”会制造羞耻与二次伤害。现实校准让信念与行动重新对齐：在可控区用力。';

      final example = '例子：求职被拒。\n可控：优化简历/练面试；可影响：找内推/扩展信息；不可控：用人方偏好。\n你不再把结果当“我不配”，而是把注意力放回可控行动。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 12 Stockdale paradox
  'm12_stockdale': ConceptPlaygroundConfig(
    conceptId: 'm12_stockdale',
    intro: '现实主义乐观：保留信念，同时直面事实。把它写成“左右两栏”。',
    groups: const [
      PlaygroundGroup(
        key: 'faith',
        title: '你的“信念句”（不夸张、可相信）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'win', label: '我最终会走出来', hint: '但不是今天就解决'),
          PlaygroundOption(id: 'learn', label: '我会变得更强', hint: '通过训练'),
          PlaygroundOption(id: 'find', label: '我会找到办法', hint: '一步步来'),
          PlaygroundOption(id: 'support', label: '我不是一个人', hint: '我会求助'),
        ],
      ),
      PlaygroundGroup(
        key: 'fact',
        title: '你要直面的“残酷事实”是哪类',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'gap', label: '能力差距', hint: '还没掌握技能'),
          PlaygroundOption(id: 'time', label: '需要时间', hint: '不能急'),
          PlaygroundOption(id: 'resource', label: '资源不足', hint: '信息/钱/人'),
          PlaygroundOption(id: 'emotion', label: '情绪很难', hint: '会反复'),
          PlaygroundOption(id: 'external', label: '外部限制', hint: '制度/他人'),
        ],
      ),
      PlaygroundGroup(
        key: 'act',
        title: '选一个“纪律性行动”',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'practice', label: '练 10 分钟', hint: '技能/体能'),
          PlaygroundOption(id: 'plan', label: '写 3 步计划', hint: '拆解任务'),
          PlaygroundOption(id: 'feedback', label: '求一次反馈', hint: '找人点评'),
          PlaygroundOption(id: 'sleep', label: '先睡一觉', hint: '恢复系统'),
          PlaygroundOption(id: 'boundary', label: '设一个边界', hint: '减少消耗'),
        ],
      ),
    ],
    generator: (picks) {
      const fbFaith = PlaygroundOption(id: 'find', label: '我会找到办法');
      const fbFact = PlaygroundOption(id: 'time', label: '需要时间');
      const fbAct = PlaygroundOption(id: 'practice', label: '练 10 分钟');

      final faith = _one(picks, 'faith', fbFaith);
      final fact = _one(picks, 'fact', fbFact);
      final act = _one(picks, 'act', fbAct);

      final title = '现实主义乐观：信念 + 事实 + 行动';
      final summary = '信念（左栏）：${_hintOrLabel(faith)}。\n事实（右栏）：${_hintOrLabel(fact)}。\n今天做：${_hintOrLabel(act)}。';

      final steps = <String>[
        '左栏写信念：${faith.label}（保持希望）。',
        '右栏写事实：${fact.label}（不逃避）。',
        '把事实翻译成行动：${_hintOrLabel(act)}。',
        '做完写一句：我面对事实的证据是___；我保留信念的证据是___。',
      ];

      final why = '纯乐观会否认现实，纯现实会失去动力；把两者并存，信念才会变成可持续行动。';

      final example = '例子：考试失利。\n信念：我最终会掌握；事实：我还没掌握某类题；行动：每天练 10 分钟并求一次反馈。\n你不是“装乐观”，而是在建系统。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 13 Self-efficacy + action
  'm13_selfeff': ConceptPlaygroundConfig(
    conceptId: 'm13_selfeff',
    intro: '自我效能来自证据：做过→做到一点点→更敢做。',
    groups: const [
      PlaygroundGroup(
        key: 'skill',
        title: '你要增强哪种效能感',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'speak', label: '表达/开口'),
          PlaygroundOption(id: 'focus', label: '专注/执行'),
          PlaygroundOption(id: 'learn', label: '学习/掌握'),
          PlaygroundOption(id: 'health', label: '运动/健康'),
          PlaygroundOption(id: 'relate', label: '关系修复'),
        ],
      ),
      PlaygroundGroup(
        key: 'risk',
        title: '你愿意承担多小的风险（越小越好）',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'tiny', label: '极小', hint: '30 秒/一句话'),
          PlaygroundOption(id: 'small', label: '小', hint: '2-5 分钟'),
          PlaygroundOption(id: 'mid', label: '中', hint: '10 分钟'),
        ],
      ),
      PlaygroundGroup(
        key: 'measure',
        title: '今天用什么作为“证据”',
        description: '证据越具体，效能感越稳。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'done', label: '完成一次', hint: '发生就算'),
          PlaygroundOption(id: 'time', label: '投入分钟数', hint: '计时'),
          PlaygroundOption(id: 'streak', label: '连续天数', hint: '打卡'),
          PlaygroundOption(id: 'feedback', label: '收到一次反馈', hint: '别人说了什么'),
        ],
      ),
    ],
    generator: (picks) {
      const fbSkill = PlaygroundOption(id: 'focus', label: '专注/执行');
      const fbRisk = PlaygroundOption(id: 'small', label: '小');
      const fbMeasure = PlaygroundOption(id: 'done', label: '完成一次');

      final skill = _one(picks, 'skill', fbSkill);
      final risk = _one(picks, 'risk', fbRisk);
      final measure = _one(picks, 'measure', fbMeasure);

      final title = '效能闭环：在「${skill.label}」里制造证据';
      final summary = '选择风险等级「${risk.label}」，今天只做一次，让证据发生。\n证据口径：${_hintOrLabel(measure)}。';

      final steps = <String>[
        '把目标缩小到风险等级：${risk.label}（越小越好）。',
        '立刻行动一次（发生=胜利）。',
        '按证据口径记录：${measure.label} = ___。',
        '写一句自我叙事：这说明我在成为一个会___的人。',
      ];

      final why = '自我效能不是“想出来的”，而是“做出来的”。当你持续制造证据，信念会自动更新。';

      final example = '例子：你怕开口。\n风险=极小：问一个问题；证据=完成一次。\n当你完成一次，你就从“我不敢”走向“我能做到一点”。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 14 Internal simulator / visualization + action
  'm14_simulator': ConceptPlaygroundConfig(
    conceptId: 'm14_simulator',
    intro: '想象可以启动，但不能替代行动：先 2 分钟预演，再 1 分钟真做。',
    groups: const [
      PlaygroundGroup(
        key: 'scene',
        title: '你要预演的场景',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'meeting', label: '会议发言'),
          PlaygroundOption(id: 'sport', label: '运动开始'),
          PlaygroundOption(id: 'social', label: '社交开口'),
          PlaygroundOption(id: 'study', label: '学习开始'),
          PlaygroundOption(id: 'talk', label: '一次关键对话'),
        ],
      ),
      PlaygroundGroup(
        key: 'style',
        title: '你用哪种预演方式',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'first', label: '第一人称', hint: '像真的一样'),
          PlaygroundOption(id: 'third', label: '第三人称', hint: '像看电影'),
          PlaygroundOption(id: 'fail', label: '失败预演', hint: '练应对'),
          PlaygroundOption(id: 'success', label: '成功预演', hint: '练路径'),
        ],
      ),
      PlaygroundGroup(
        key: 'real',
        title: '预演后你要做的“现实一步”',
        description: '哪怕 60 秒，也要把想象接到现实。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '60s', label: '做 60 秒', hint: '开口/写一句/动一下'),
          PlaygroundOption(id: '2m', label: '做 2 分钟', hint: '开始就赢'),
          PlaygroundOption(id: 'msg', label: '发一条消息', hint: '邀请/求助/确认'),
          PlaygroundOption(id: 'prep', label: '准备材料', hint: '打开文档/摆好器材'),
        ],
      ),
    ],
    generator: (picks) {
      const fbScene = PlaygroundOption(id: 'study', label: '学习开始');
      const fbStyle = PlaygroundOption(id: 'first', label: '第一人称');
      const fbReal = PlaygroundOption(id: '2m', label: '做 2 分钟');

      final scene = _one(picks, 'scene', fbScene);
      final style = _one(picks, 'style', fbStyle);
      final real = _one(picks, 'real', fbReal);

      final title = '预演→行动：把「${scene.label}」接到现实';
      final summary = '先用「${style.label}」预演 2 分钟，然后立刻做现实一步：${_hintOrLabel(real)}。';

      final steps = <String>[
        '计时 2 分钟预演：想象你正在做「${scene.label}」，把关键动作走一遍。',
        '立刻落地：${_hintOrLabel(real)}（不等心情）。',
        '记录一句：预演让我更容易开始的点是___。',
      ];

      final why = '预演能降低未知与焦虑，但只有行动证据才能真正更新信念；所以必须“预演后立刻做一步”。';

      final example = '例子：你害怕会议发言。\n先预演自己开口第一句，再在现实里做 60 秒：写出第一句/对同事说一句。\n你会发现“开始”比“完美”更重要。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),

  // 15 Failure underrated
  'm15_failure': ConceptPlaygroundConfig(
    conceptId: 'm15_failure',
    intro: '把失败当作训练：选一种失败→换一种解释→做一个更小的下一步。',
    groups: const [
      PlaygroundGroup(
        key: 'type',
        title: '你经历的失败类型',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'rejected', label: '被拒绝/被否定'),
          PlaygroundOption(id: 'quit', label: '没坚持/中途放弃'),
          PlaygroundOption(id: 'mess', label: '搞砸/出错'),
          PlaygroundOption(id: 'critic', label: '被批评/被指责'),
          PlaygroundOption(id: 'conflict', label: '关系冲突'),
        ],
      ),
      PlaygroundGroup(
        key: 'story',
        title: '你要选择哪种解释风格',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: 'fixed', label: '固定型', hint: '我就是不行'),
          PlaygroundOption(id: 'growth', label: '成长型', hint: '我还在学'),
          PlaygroundOption(id: 'process', label: '过程型', hint: '这次方法不对'),
          PlaygroundOption(id: 'immune', label: '免疫型', hint: '我在训练抗挫力'),
        ],
      ),
      PlaygroundGroup(
        key: 'next',
        title: '下一步要小到什么程度',
        description: '越小越能重启循环。',
        mode: SelectionMode.single,
        options: [
          PlaygroundOption(id: '1m', label: '1 分钟', hint: '写一句/动一下'),
          PlaygroundOption(id: '5m', label: '5 分钟', hint: '最小练习'),
          PlaygroundOption(id: 'ask', label: '求一次反馈', hint: '向人请教'),
          PlaygroundOption(id: 'retry', label: '重试一次', hint: '只重试最小部分'),
        ],
      ),
    ],
    generator: (picks) {
      const fbType = PlaygroundOption(id: 'mess', label: '搞砸/出错');
      const fbStory = PlaygroundOption(id: 'process', label: '过程型');
      const fbNext = PlaygroundOption(id: '5m', label: '5 分钟');

      final type = _one(picks, 'type', fbType);
      final story = _one(picks, 'story', fbStory);
      final next = _one(picks, 'next', fbNext);

      final title = '失败复盘：把「${type.label}」变成训练';
      final summary = '选择解释：${_hintOrLabel(story)}。\n下一步：${_hintOrLabel(next)}，让你重新进入可行动状态。';

      final steps = <String>[
        '写一句事实：发生了什么（不评价）？',
        '写一句新解释：${story.hint ?? story.label}。',
        '做下一步：${_hintOrLabel(next)}（越小越好）。',
        '记录：我学到的 1 个点是___；我会在下次试___。',
      ];

      final why = '失败会提供信息与免疫力。把失败从“羞耻”改成“训练数据”，你更容易继续，也更容易成长。';

      final example = '例子：你被拒绝。\n解释从“我不配”换成“我还在学/方法不对”，然后做 5 分钟改进：改一段简历/练一段开场。\n你把失败变成下一次成功的材料。';

      return ActionCard(title: title, summary: summary, whyShort: why, steps: steps, example: example);
    },
  ),
};

ConceptPlaygroundConfig? getLecture56PlaygroundConfig(String moduleId, {bool advanced = false}) {
  final base = kLecture56Playgrounds[moduleId];
  if (base == null) return null;
  final withAdv = advanced ? _wrapWithAdvanced(base) : base;
  return wrapWithMeta(withAdv);
}
