import 'package:flutter/material.dart';

import '../model/belief_game.dart';
import '../model/belief_concepts.dart';

/// Show a short, game-like feedback for XP gain / level up.
Future<void> showXpFeedback(
  BuildContext context, {
  required XpAward award,
  String? title,
}) async {
  if (!context.mounted) return;
  final msg = award.coinsGained > 0
      ? '获得 +${award.xpGained} XP  ·  +${award.coinsGained} 金币'
      : '获得 +${award.xpGained} XP';

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(msg),
      duration: const Duration(seconds: 2),
    ),
  );

  if (!award.leveledUp) return;

  final newlyUnlocked = kBeliefForgeConcepts
      .where((c) => (kConceptRequiredLevel[c.id] ?? 1) == award.newLevel)
      .toList();

  await showDialog<void>(
    context: context,
    builder: (_) {
      return AlertDialog(
        title: Text(title ?? '升级啦！Lv ${award.newLevel}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('你从 Lv ${award.oldLevel} 升到 Lv ${award.newLevel}。'),
            const SizedBox(height: 10),
            if (newlyUnlocked.isNotEmpty) ...[
              const Text('新解锁概念：', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              ...newlyUnlocked.map((c) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('•  '),
                        Expanded(child: Text(c.title)),
                      ],
                    ),
                  )),
            ] else ...[
              const Text('继续做每日任务，会解锁更高阶概念。'),
            ],
          ],
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(_), child: const Text('继续')),
        ],
      );
    },
  );
}
