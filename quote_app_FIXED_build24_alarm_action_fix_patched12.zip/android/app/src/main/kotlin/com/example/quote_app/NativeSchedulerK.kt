package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*
import java.util.concurrent.TimeUnit
object NativeSchedulerK {

  private const val UNIQUE_WORK_PREFIX = "wm_once_"

  private fun buildPi(ctx: Context, id: Int, payload: String?): PendingIntent {
    val i = Intent(ctx, com.example.quote_app.am.AlarmReceiver::class.java)
      .setAction("com.example.quote_app.ALARM."+id.toString())
      .setPackage(ctx.packageName)
    .putExtra("id", id)
      .putExtra("payload", payload ?: "{}")
    val flags = if (Build.VERSION.SDK_INT >= 23)
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    else
      PendingIntent.FLAG_UPDATE_CURRENT
    return PendingIntent.getBroadcast(ctx, id, i, flags)
  }

  @JvmStatic fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    return try {
      val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
      val pi = buildPi(ctx, id, payload)
      if (Build.VERSION.SDK_INT >= 23) {
        try {
          am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
        } catch (_: Throwable) {
          am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
        }
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
      }
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】AM 计划 id="+id+" at="+epochMs); } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  @JvmStatic fun cancel(ctx: Context, id: Int): Boolean {
    return try {
      val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
      val pi = buildPi(ctx, id, null)
      am.cancel(pi)
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】AM 取消 id="+id); } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  @JvmStatic fun cancelAll(ctx: Context): Boolean {
    return try {
      // 仅能可靠取消 WM 的任务；AM 需提供具体 id 才能取消
      WorkManager.getInstance(ctx).cancelAllWork()
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】WM 全部取消"); } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  @JvmStatic fun scheduleExactWmCompat(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    val delayMs = kotlin.math.max(0L, epochMs - System.currentTimeMillis())
    val data = Data.Builder()
      .putInt("id", id)
      .putString("payload", payload ?: "{}")
      .putString("job", "wm_run")
      .build()
    val req = OneTimeWorkRequestBuilder<NotifyWorker>()
      .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
      .addTag(UNIQUE_WORK_PREFIX + id.toString())
      .setInputData(data)
      .build()
    return try {
      WorkManager.getInstance(ctx).enqueueUniqueWork(
        UNIQUE_WORK_PREFIX + id.toString(),
        ExistingWorkPolicy.REPLACE,
        req
      )
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】WM 兜底注册完成 id="+id+" delay="+delayMs+"ms"); } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  @JvmStatic fun scheduleSelfCheck(ctx: Context, minutes: Int): Boolean {
    val data = Data.Builder().putString("job","selfcheck").build()
    val req = OneTimeWorkRequestBuilder<SelfCheckWorker>()
      .setInitialDelay(minutes.toLong(), TimeUnit.MINUTES)
      .setInputData(data)
      .build()
    return try {
      WorkManager.getInstance(ctx).enqueue(req)
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "【原生】WM 自检计划 +"+minutes+"min"); } catch (_: Throwable) {}
      true
    } catch (_: Throwable) { false }
  }

  @JvmStatic fun hasExactAlarmPermission(ctx: Context): Boolean {
    return try {
      val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
    } catch (_: Throwable) { true }
  }

  @JvmStatic fun cancelByIdCard(ctx: Context, idCard: String) {
    try {
      val src = Regex("src=([^_]+)").find(idCard)?.groupValues?.get(1) ?: ""
      val runKey = Regex("runkey=([^_]+)").find(idCard)?.groupValues?.get(1) ?: ""
      val uid = Regex("uid=([^_]+)").find(idCard)?.groupValues?.get(1) ?: ""
      if (src.isEmpty() || uid.isEmpty()) return
      if (src == "am") {
        val id = com.example.quote_app.compat.DartParity.alarmId(uid, runKey)
        cancel(ctx, id)
      } else {
        try { com.example.quote_app.wm.WmScheduler.cancelByUid(ctx, uid) } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {}
  }

  @JvmStatic fun scheduleNextForUid(ctx: Context, uid: String) {
    try {
      val next = com.example.quote_app.schedule.NextTriggerCalculator.compute(ctx, uid)
      val runKey = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(java.util.Date(next))
      if (hasExactAlarmPermission(ctx)) {
        // AM 精准 + WM 兜底(+2min)
        val payload = org.json.JSONObject()
        payload.put("job","am_run")
        payload.put("task_uid", uid)
        payload.put("run_key", runKey)
        payload.put("id_card", "src=am_runkey="+runKey+"_uid="+uid)
        val id = com.example.quote_app.compat.DartParity.alarmId(uid, runKey)
        val pi = buildPi(ctx, id, payload.toString())
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        else am.setExact(AlarmManager.RTC_WAKEUP, next, pi)
        try { com.example.quote_app.data.DbRepository.log(ctx, uid, "【原生】AM 注册完成 uid="+uid+" run="+runKey) } catch (_: Throwable) {}
        // 兜底 WM 延时 +2min
        com.example.quote_app.wm.WmScheduler.schedulePair(ctx.applicationContext, next + 2L*60L*1000L, uid, runKey)
      } else {
        // 无精准权限：主WM + 兜底WM
        com.example.quote_app.wm.WmScheduler.schedulePair(ctx.applicationContext, next, uid, runKey)
      }
      try { updateNextTime(ctx, uid, next) } catch (_: Throwable) {}
    } catch (_: Throwable) {}
  }

  private fun updateNextTime(ctx: Context, uid: String, next: Long) {
    try {
      val c = com.example.quote_app.data.DbInspector.loadFromPrefs(ctx)
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(c.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READWRITE)
      try {
        var col = c.taskColMap["next"] ?: c.taskColMap["next_time"] ?: "next_time"
        try {
          val cur = db.rawQuery("PRAGMA table_info("+c.tasksSource+")", null)
          var found = ""
          while (cur.moveToNext()) {
            val cc = cur.getString(1)
            if (cc != null && cc.lowercase().contains("next")) { found = cc; break }
          }
          cur.close()
          if (found.isNotEmpty()) col = found
        } catch (_: Throwable) {}
        val cv = android.content.ContentValues()
        cv.put(col, next)
        db.update(c.tasksSource, cv, (c.taskColMap["uid"]?:"uid")+"=?", arrayOf(uid))
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) {}
  }

}
