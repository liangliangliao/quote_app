package com.example.quote_app

import android.app.Application

/**
 * Application entry without direct plugin references.
 * Flutter v2 embedding handles plugin registration automatically.
 * Workmanager is initialised from Dart (Workmanager().initialize(...)).
 */
class App : Application()
