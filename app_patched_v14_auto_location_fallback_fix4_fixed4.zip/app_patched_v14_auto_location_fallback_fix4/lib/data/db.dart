
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/services.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      // Bump the database version to trigger onUpgrade for recent migrations.
      // Increasing this version number ensures that any device with an older
      // schema (missing columns or tables) will run the upgrade logic below.
      // Without bumping, onUpgrade would not be invoked on devices that have
      // already migrated, and thus they would not receive fixes such as
      // idempotent creation of the logs table.  We bump the version to 13 here
      // so that devices upgrading from version 12 will still execute the
      // _upgrade logic which ensures the logs table exists.  Future changes
      // should increment this value accordingly.
      version: 13,
      onCreate: _create,
      onUpgrade: _upgrade,
    );
    // Debug: print DB absolute path and notify native
    try {
      // ignore: avoid_print
      print('[DBG] AppDatabase opened at: ' + path);

    // --- enumerate db schema
    final db = _db!;  // assert non-null: we just opened it above (all user tables & columns) ---
    final List<Map<String, Object?>> _tables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
    final Map<String, List<String>> _schema = {};
    for (final t in _tables) {
      final name = (t['name'] ?? '') as String;
      if (name.isEmpty) continue;
      final cols = await db.rawQuery('PRAGMA table_info(' + name + ')');
      final List<String> colNames = [];
      for (final c in cols) {
        final cn = (c['name'] ?? '') as String;
        if (cn.isNotEmpty) colNames.add(cn);
      }
      _schema[name] = colNames;
    }

      // Notify native side about database info. When running in background isolates (e.g. WorkManager),
      // the native.scheduler channel may not be registered, which would cause an unhandled
      // MissingPluginException if the future is not awaited and caught.  To avoid crashing,
      // await the call and catch any exception.
      try {
        const _ch = MethodChannel('native.scheduler');
        await _ch.invokeMethod('dbInfo', {'dbPath': path, 'version': 5, 'schema': _schema});
      } catch (_) {
        // ignore missing plugin errors when background isolate is missing native channel
      }
    } catch (t) { /* ignore */ }

    await _db!.execute('PRAGMA foreign_keys = ON');

    // Ensure critical columns exist in quotes and tasks tables.  Some devices may
    // have upgraded to a newer database version without running onUpgrade (for
    // example, if the version number did not change), leaving columns such
    // as task_type/task_name missing.  To avoid "no column named task_type"
    // errors during inserts, we detect missing columns here and add them on
    // first open.  Each ALTER TABLE is wrapped in a try/catch to be idempotent.
    try {
      final db = _db!;
      // Quotes table columns to ensure (avoid duplicate-column logs)
final infoQuotes = await db.rawQuery("PRAGMA table_info(quotes)");
final colsQuotes = infoQuotes.map((e) => e['name'] as String).toList();
if (!colsQuotes.contains('task_type'))        await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT");
if (!colsQuotes.contains('task_name'))        await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT");
if (!colsQuotes.contains('theme'))            await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT");
if (!colsQuotes.contains('author_name'))      await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT");
if (!colsQuotes.contains('source_from'))      await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT");
if (!colsQuotes.contains('explanation'))      await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT");
if (!colsQuotes.contains('inserted_at'))      await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT");
if (!colsQuotes.contains('last_notified_at')) await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT");
if (!colsQuotes.contains('avatar'))           await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT");
// Legacy camelCase columns for backward-compat with older builds
if (!colsQuotes.contains('taskType'))         await db.execute("ALTER TABLE quotes ADD COLUMN taskType TEXT");
if (!colsQuotes.contains('taskName'))         await db.execute("ALTER TABLE quotes ADD COLUMN taskName TEXT");

// Configs table columns to ensure
final infoConfigs = await db.rawQuery("PRAGMA table_info(configs)");
final colsConfigs = infoConfigs.map((e) => e['name'] as String).toList();
if (!colsConfigs.contains('recent_hours'))        await db.execute("ALTER TABLE configs ADD COLUMN recent_hours INTEGER DEFAULT 2");
if (!colsConfigs.contains('overview_threshold')) await db.execute("ALTER TABLE configs ADD COLUMN overview_threshold INTEGER DEFAULT 500");
if (!colsConfigs.contains('ema_enabled'))     await db.execute("ALTER TABLE configs ADD COLUMN ema_enabled INTEGER DEFAULT 0");
if (!colsConfigs.contains('esteem_scale'))   await db.execute("ALTER TABLE configs ADD COLUMN esteem_scale INTEGER DEFAULT 100");
if (!colsConfigs.contains('sses_index'))     await db.execute("ALTER TABLE configs ADD COLUMN sses_index INTEGER DEFAULT 0");

// Emotions table columns to ensure
final infoEmotions = await db.rawQuery("PRAGMA table_info(emotions)");
final colsEmotions = infoEmotions.map((e) => e['name'] as String).toList();
if (!colsEmotions.contains('type'))           await db.execute("ALTER TABLE emotions ADD COLUMN type TEXT");

// Tasks table columns to ensure

      final infoTasks = await db.rawQuery("PRAGMA table_info(tasks)");
      final colsTasks = infoTasks.map((e) => e['name'] as String).toList();
      if (!colsTasks.contains('task_uid'))   await db.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
      if (!colsTasks.contains('name'))       await db.execute("ALTER TABLE tasks ADD COLUMN name TEXT");
      if (!colsTasks.contains('task_type'))  await db.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT");
      if (!colsTasks.contains('start_time')) await db.execute("ALTER TABLE tasks ADD COLUMN start_time TEXT");
      if (!colsTasks.contains('prompt'))     await db.execute("ALTER TABLE tasks ADD COLUMN prompt TEXT");
      if (!colsTasks.contains('avatar'))     await db.execute("ALTER TABLE tasks ADD COLUMN avatar TEXT");
      if (!colsTasks.contains('status'))     await db.execute("ALTER TABLE tasks ADD COLUMN status TEXT");
      // Ensure cursor column exists; used by bulk import tasks for quote navigation
      if (!colsTasks.contains('cursor'))     await db.execute("ALTER TABLE tasks ADD COLUMN cursor INTEGER DEFAULT 0");
      // Ensure carousel_order column exists; used by carousel tasks to store play order
      if (!colsTasks.contains('carousel_order')) await db.execute("ALTER TABLE tasks ADD COLUMN carousel_order TEXT DEFAULT 'desc'");
    } catch (_) {
      // ignore any errors; missing columns will raise on next upgrade
    }
    return _db!;
  }

  static Future<void> _create(Database db, int version) async {
    // Configs
    await db.execute('''
      CREATE TABLE configs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        api_key TEXT,
        model TEXT,
        endpoint TEXT,
        recent_hours INTEGER DEFAULT 2,
        overview_threshold INTEGER DEFAULT 500,
        -- 开关：是否启用量表自动报告功能，0=关闭，1=开启
        auto_report_enabled INTEGER DEFAULT 0,
        -- EMA 开关：是否启用即时自尊问答（EMA/SSES），0=关闭，1=开启
        ema_enabled INTEGER DEFAULT 0,
        -- 自尊评分尺度：100 或 30
        esteem_scale INTEGER DEFAULT 100,
        -- SSES 轮换问卷索引（0-5），默认 0
        sses_index INTEGER DEFAULT 0
      )
    ''');

    // Backup table for restoring original order (方案B)
    await db.execute('''
      CREATE TABLE IF NOT EXISTS quotes_id_backup (
        quote_uid TEXT PRIMARY KEY,
        original_id INTEGER,
        original_pos INTEGER
      )
    ''');
    await db.insert('configs', {
      'api_key': '',
      'model': 'gpt-5',
      'endpoint': 'https://api.openai.com/v1/responses',
      'recent_hours': 2,
      'overview_threshold': 500,
      'auto_report_enabled': 0
    });

    // Meta key-value
    await db.execute('''
      CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');

    // Tasks
    // Additional columns `next_time` and `scheduled_run_key` are included by
    // default in the schema.  They will be used to store the next scheduled
    // run time and the last registered runKey respectively.  Older database
    // versions will be migrated via ensureExtraTaskColumns().
    await db.execute('''
      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT UNIQUE,
        name TEXT,
        type TEXT,          -- manual | auto | carousel | 批量导入任务
        status TEXT,        -- on | off
        prompt TEXT,        -- for auto
        avatar_path TEXT,   -- icon path
        start_time TEXT,    -- 'HH:mm' or 'YYYY-MM-DD HH:mm[:ss]'
        freq_type TEXT,     -- daily | weekly | monthly | custom
        freq_weekday INTEGER,       -- 1-7 (Mon-Sun) when weekly
        freq_day_of_month INTEGER,  -- 1-31 when monthly
        freq_custom TEXT,            -- reserved
        next_time TEXT,              -- ISO8601 next run time
        scheduled_run_key TEXT,      -- last scheduled runKey for cancellation
        cursor INTEGER DEFAULT 0,     -- index into quotes for bulk import tasks
        carousel_order TEXT DEFAULT 'desc'    -- order for carousel tasks: desc | asc | random
      )
    ''');

    // Quotes
    await db.execute('''
      CREATE TABLE quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_uid TEXT UNIQUE,
        task_uid TEXT,
        content TEXT,
        notified INTEGER DEFAULT 0,
        created_at INTEGER,
        
        theme TEXT,
        author_name TEXT,
        source_from TEXT,
        explanation TEXT,
        avatar TEXT,
        inserted_at TEXT,
        last_notified_at TEXT,
        taskType TEXT,
        taskName TEXT,
        FOREIGN KEY(task_uid) REFERENCES tasks(task_uid) ON DELETE CASCADE
      )
    ''' );

    // Table for fixed quotes.  Each record stores a snapshot of quote data
    // for the "名人名言固定表" feature.  This table references the quotes
    // table via quote_id (nullable, on delete set null) and enforces
    // uniqueness on content to prevent duplicate pins.  Fields mirror the
    // primary quote fields (theme/topic, author_name, source_from, explanation,
    // avatar) so that pinned items remain intact even if the original quote
    // record is edited.  A separate fixed_uid is used as a stable primary key.
    await db.execute('''
      CREATE TABLE quotes_fixed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fixed_uid TEXT UNIQUE,
        quote_id INTEGER,
        content TEXT UNIQUE,
        theme TEXT,
        author_name TEXT,
        source_from TEXT,
        explanation TEXT,
        avatar TEXT,
        FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE SET NULL
      )
    ''');

    // Logs table.  Using IF NOT EXISTS here makes creation idempotent in
    // case the table already exists when onCreate is triggered.  Without
    // IF NOT EXISTS the CREATE TABLE statement would throw "table ... already exists"
    // which propagates as a DatabaseException and blocks subsequent
    // database operations.  See bug reports around 2025-11-23.
    await db.execute('''
      CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_uid TEXT UNIQUE,
        task_uid TEXT,
        detail TEXT,
        created_at INTEGER,
        task_name_snapshot TEXT,
        task_start_time_snapshot TEXT
      )
    ''');
  

    // Emotions: user mood records
    await db.execute('''
      CREATE TABLE emotions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        emotion_uid TEXT UNIQUE,
        emoji_char TEXT,
        emoji_name TEXT,
        emoji_tags TEXT,
        behavior TEXT,
        trigger_event TEXT,
        thought TEXT,
        type TEXT,
        inserted_at TEXT
      )
    ''');

    // 量表相关表：用于存储量表元数据、题目配置、选项、评分规则以及测评记录。
    // 这些表与原有功能相互独立，通过 scale_id 与 assessment 外键关联。
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_code TEXT UNIQUE,
        version TEXT,
        name TEXT,
        language TEXT,
        description TEXT,
        author TEXT,
        copyright TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_dimensions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_id INTEGER,
        dimension_code TEXT,
        name TEXT,
        description TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_id INTEGER,
        item_code TEXT,
        item_no INTEGER,
        content TEXT,
        item_type TEXT,
        dimension_code TEXT,
        is_reverse INTEGER,
        scoring_type TEXT,
        remark TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_item_options (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_item_id INTEGER,
        option_code TEXT,
        label TEXT,
        option_value TEXT,
        base_score REAL,
        extra_rule TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_report_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_id INTEGER,
        dimension_code TEXT,
        min_score REAL,
        max_score REAL,
        level TEXT,
        template TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        scale_id INTEGER,
        total_score REAL,
        level TEXT,
        report_text TEXT,
        created_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_assessment_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assessment_id INTEGER,
        scale_item_id INTEGER,
        option_id INTEGER,
        option_value TEXT,
        score REAL
      )
    ''');
    // Safe: seed backup mapping AFTER quotes table exists
    try {
      await db.execute("INSERT OR IGNORE INTO quotes_id_backup(quote_uid, original_id, original_pos) SELECT quote_uid, id, rowid FROM quotes");
    } catch (_) {}
}

  static Future<void> _ensureMeta(Database db) async {
    // placeholder if future migrations need to alter meta schema
  }

  

/// Adds a column only if it does not already exist.
/// This avoids noisy "duplicate column name" errors in SQLiteLog.
static Future<void> _addColumnIfMissing(
    Database db, String table, String column, String definition) async {
  final info = await db.rawQuery("PRAGMA table_info($table)");
  final cols = info.map((e) => e['name'] as String).toList();
  if (!cols.contains(column)) {
    await db.execute("ALTER TABLE $table ADD COLUMN $column $definition");
  }
}

static Future<void> _upgrade(Database db, int oldV, int newV) async {

// Add missing columns safely (no duplicate-column logs).
await _addColumnIfMissing(db, 'quotes', 'task_type', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'task_name', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'theme', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'author_name', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'source_from', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'explanation', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'inserted_at', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'last_notified_at', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'avatar', 'TEXT');
// Legacy camelCase columns for older builds
await _addColumnIfMissing(db, 'quotes', 'taskType', 'TEXT');
await _addColumnIfMissing(db, 'quotes', 'taskName', 'TEXT');

await _addColumnIfMissing(db, 'configs', 'recent_hours', 'INTEGER DEFAULT 2');

    // Ensure measurement related schema exists and new config column is present.
    // 自动报告开关列
    await _addColumnIfMissing(db, 'configs', 'auto_report_enabled', 'INTEGER DEFAULT 0');

    // === 自定义新增列 ===
    // 是否启用 EMA / SSES 自尊题问答（0 关闭, 1 开启）
    await _addColumnIfMissing(db, 'configs', 'ema_enabled', 'INTEGER DEFAULT 0');
    // 自尊评分尺度（100 或 30），默认为 100
    await _addColumnIfMissing(db, 'configs', 'esteem_scale', 'INTEGER DEFAULT 100');
    // SSES 轮换问卷索引（0-5），记录用户上次答题进度，默认 0
    await _addColumnIfMissing(db, 'configs', 'sses_index', 'INTEGER DEFAULT 0');

    // 创建 SSES 答案表，用于存储生态瞬时评估自尊题的历史答题记录
    await db.execute('''
      CREATE TABLE IF NOT EXISTS sses_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id TEXT,
        dimension TEXT,
        score INTEGER,
        created_at TEXT
      )
    ''');
    // Create tables for questionnaire scales if they do not already exist. These are idempotent.
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_code TEXT UNIQUE,
        version TEXT,
        name TEXT,
        language TEXT,
        description TEXT,
        author TEXT,
        copyright TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_dimensions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_id INTEGER,
        dimension_code TEXT,
        name TEXT,
        description TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_id INTEGER,
        item_code TEXT,
        item_no INTEGER,
        content TEXT,
        item_type TEXT,
        dimension_code TEXT,
        is_reverse INTEGER,
        scoring_type TEXT,
        remark TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_item_options (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_item_id INTEGER,
        option_code TEXT,
        label TEXT,
        option_value TEXT,
        base_score REAL,
        extra_rule TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_report_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scale_id INTEGER,
        dimension_code TEXT,
        min_score REAL,
        max_score REAL,
        level TEXT,
        template TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        scale_id INTEGER,
        total_score REAL,
        level TEXT,
        report_text TEXT,
        created_at TEXT
      )
    ''');

    // Ensure the logs table exists when upgrading from older versions.  Some
    // devices created the database before the logs table was introduced.
    // Without this, calls to LogDao.add() will fail with "no such table: logs".
    await db.execute('''
      CREATE TABLE IF NOT EXISTS scale_assessment_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assessment_id INTEGER,
        scale_item_id INTEGER,
        option_id INTEGER,
        option_value TEXT,
        score REAL
      )
    ''');

await _addColumnIfMissing(db, 'tasks', 'task_uid', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'name', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'task_type', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'start_time', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'prompt', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'avatar', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'status', 'TEXT');
await _addColumnIfMissing(db, 'tasks', 'cursor', 'INTEGER DEFAULT 0');
await _addColumnIfMissing(db, 'tasks', 'carousel_order', "TEXT DEFAULT 'desc'");


    // Ensure the quotes_fixed table exists.  On upgrades from versions prior
    // to 9, the fixed quotes table may not yet exist.  Using IF NOT EXISTS
    // makes this operation idempotent and safe to call repeatedly.
    try {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS quotes_fixed (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fixed_uid TEXT UNIQUE,
          quote_id INTEGER,
          content TEXT UNIQUE,
          theme TEXT,
          author_name TEXT,
          source_from TEXT,
          explanation TEXT,
          avatar TEXT,
          FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE SET NULL
        )
      ''');
    } catch (_) {}


    // Ensure emotions table exists for mood records
    try {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS emotions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          emotion_uid TEXT UNIQUE,
          emoji_char TEXT,
          emoji_name TEXT,
          emoji_tags TEXT,
          behavior TEXT,
          trigger_event TEXT,
          thought TEXT,
          type TEXT,
          inserted_at TEXT
        )
      ''');
    } catch (_) {}

    // Continue with legacy upgrade logic for very old versions.
    if (oldV < 5) {
      // Best-effort ensure required tables/columns exist
      await db.execute("CREATE TABLE IF NOT EXISTS configs (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT, model TEXT, endpoint TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT UNIQUE, name TEXT, type TEXT, status TEXT, prompt TEXT, avatar_path TEXT, start_time TEXT, freq_type TEXT, freq_weekday INTEGER, freq_day_of_month INTEGER, freq_custom TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, quote_uid TEXT UNIQUE, task_uid TEXT, content TEXT, notified INTEGER DEFAULT 0, created_at INTEGER)");
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT, created_at INTEGER, task_name_snapshot TEXT, task_start_time_snapshot TEXT)");

      // === Ensure standardized schema (backward compatible) ===
      // Logs: id AUTOINCREMENT, log_uid PRIMARY KEY, task_uid (FK, nullable, ON DELETE SET NULL), detail
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT)");
      // Ensure required columns exist
      // quotes: add required columns if missing
      var infoQuotes = await db.rawQuery("PRAGMA table_info(quotes)");
      var colsQuotes = infoQuotes.map((e)=> e['name'] as String).toList();
      


if (!colsQuotes.contains('task_type')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT"); }
if (!colsQuotes.contains('task_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT"); }
if (!colsQuotes.contains('theme')) { await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT"); }
if (!colsQuotes.contains('author_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT"); }
if (!colsQuotes.contains('source_from')) { await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT"); }
if (!colsQuotes.contains('explanation')) { await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT"); }
if (!colsQuotes.contains('inserted_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT"); }
if (!colsQuotes.contains('last_notified_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT"); }
if (!colsQuotes.contains('avatar')) { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
if (!colsQuotes.contains('theme')) { await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT"); }
if (!colsQuotes.contains('author_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT"); }
if (!colsQuotes.contains('source_from')) { await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT"); }
if (!colsQuotes.contains('explanation')) { await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT"); }
if (!colsQuotes.contains('inserted_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT"); }
if (!colsQuotes.contains('last_notified_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT"); }
if (!colsQuotes.contains('avatar')) { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
if (!colsQuotes.contains('quote_uid')) { await db.execute("ALTER TABLE quotes ADD COLUMN quote_uid TEXT"); }
      if (!colsQuotes.contains('task_uid'))  { await db.execute("ALTER TABLE quotes ADD COLUMN task_uid TEXT"); }
      if (!colsQuotes.contains('task_type')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT"); }
      if (!colsQuotes.contains('task_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT"); }
      if (!colsQuotes.contains('avatar'))    { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
      if (!colsQuotes.contains('notified'))  { await db.execute("ALTER TABLE quotes ADD COLUMN notified INTEGER DEFAULT 0"); }
      // unique for content
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_content ON quotes(content)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_uid ON quotes(quote_uid)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_tasks_uid ON tasks(task_uid)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_logs_uid ON logs(log_uid)");

      // tasks: ensure required columns
      var infoTasks = await db.rawQuery("PRAGMA table_info(tasks)");
      var colsTasks = infoTasks.map((e)=> e['name'] as String).toList();
      if (!colsTasks.contains('task_uid'))   { await db.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT"); }
      if (!colsTasks.contains('name'))       { await db.execute("ALTER TABLE tasks ADD COLUMN name TEXT"); }
      if (!colsTasks.contains('task_type'))  { await db.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT"); }
      if (!colsTasks.contains('start_time')) { await db.execute("ALTER TABLE tasks ADD COLUMN start_time TEXT"); }
      if (!colsTasks.contains('prompt'))     { await db.execute("ALTER TABLE tasks ADD COLUMN prompt TEXT"); }
      if (!colsTasks.contains('avatar'))     { await db.execute("ALTER TABLE tasks ADD COLUMN avatar TEXT"); }
      if (!colsTasks.contains('status'))     { await db.execute("ALTER TABLE tasks ADD COLUMN status TEXT"); }
      if (!colsTasks.contains('cursor'))     { await db.execute("ALTER TABLE tasks ADD COLUMN cursor INTEGER DEFAULT 0"); }
      // configs: ensure required columns (notice_id aka id, api_key, bg_image, model, endpoint)
      var infoCfg = await db.rawQuery("PRAGMA table_info(configs)");
      var colsCfg = infoCfg.map((e)=> e['name'] as String).toList();
      if (!colsCfg.contains('bg_image'))     { await db.execute("ALTER TABLE configs ADD COLUMN bg_image TEXT"); }
      // Foreign key relationships (best-effort: create views/triggers if needed)
      await db.execute("PRAGMA foreign_keys=ON");
      // Ensure snapshots columns
      final info = await db.rawQuery("PRAGMA table_info(logs)");
      final cols = info.map((e)=> e['name'] as String).toList();
      if (!cols.contains('task_name_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_name_snapshot TEXT");
      }
      if (!cols.contains('task_start_time_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_start_time_snapshot TEXT");
      }
    }
  }
}
