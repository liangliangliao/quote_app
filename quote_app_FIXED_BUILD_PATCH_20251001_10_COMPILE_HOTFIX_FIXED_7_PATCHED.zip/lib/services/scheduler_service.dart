import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../data/db.dart';
import '../platform/native_scheduler.dart';
import '../platform/perm_helper.dart';
import 'task_runner.dart';

class SchedulerService {
  static Future<void> init() async { /* 初始化已在 main.dart 完成 */ }

  /// 计算下一次运行时间：优先 next_time；否则使用 start_time(HH:mm) 今日/明日
  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final now = DateTime.now();
    const grace = Duration(seconds: 10);
    try {
      final raw = (t['next_time'] ?? '').toString();
      if (raw.isNotEmpty) {
        final dt = DateTime.tryParse(raw);
        if (dt != null && dt.isAfter(now.subtract(grace))) return dt;
      }
    } catch (_) {}
    final start = (t['start_time'] ?? '09:00').toString();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (next.isBefore(now.subtract(grace))) next = next.add(const Duration(days: 1));
    return next;
  }

  static String _runKeyFromTime(DateTime dt) => DateFormat('yyyyMMdd_HHmm').format(dt);

  static int _alarmId(String uid, String runKey) {
    // 稳定哈希，转正数
    final v = uid.hashCode ^ runKey.hashCode;
    return (v & 0x7fffffff);
  }

  static String _wmUniqueNormal(String uid, String runKey) => 'wm_run_${uid}_${runKey}_N';
  static String _wmUniqueFallback(String uid, String runKey, int attempt) => 'wm_run_${uid}_${runKey}_FB_${attempt}';

  /// 取消 WM 正常/兜底（按唯一名）
  static Future<void> _cancelWmNormal(String uid, String runKey) async {
    try { await Workmanager().cancelByUniqueName(_wmUniqueNormal(uid, runKey)); } catch (_) {}
  }
  static Future<void> _cancelWmFallback(String uid, String runKey, int attempt) async {
    try { await Workmanager().cancelByUniqueName(_wmUniqueFallback(uid, runKey, attempt)); } catch (_) {}
  }

  /// 注册下一次（按权限分支：有精准=仅AM+兜底WM；无精准=仅WM正常+兜底WM）
  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);
    final now = DateTime.now();
    final diff = next.difference(now);
    final normalDelay = diff.isNegative ? Duration.zero : diff;

    // 保存精准取消用 runKey
    try { await TaskDao().setScheduledRunKey(uid, runKey); } catch (_) {}

    bool hasExact = false;
    try { hasExact = await PermHelper.hasExactAlarmPermission(); } catch (_) {}

    if (hasExact) {
      // ✅ 仅 AM + WM 兜底(+2 分钟)
      try {
        await NativeScheduler.scheduleExactAt(
          id: _alarmId(uid, runKey),
          epochMs: next.millisecondsSinceEpoch,
          payload: {'uid': uid, 'runKey': runKey, 'chan': 'am', 'attempt': 1},
        );
        await DLog.i('SCH', 'AM 注册完成 uid='+uid+' am_id='+_alarmId(uid, runKey).toString()+' run='+runKey);
      } catch (e) {
        await DLog.w('SCH', 'AM 注册失败，忽略: '+e.toString());
      }
      try {
        final u = _wmUniqueFallback(uid, runKey, 1);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay + const Duration(minutes: 2),
          inputData: {'job':'wm_run', 'task_uid': uid, 'run_key': runKey, 'chan': 'fallback', 'attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+u+' run='+runKey);
      } catch (e) {
        await DLog.e('SCH', 'WM 兜底注册失败: '+e.toString());
      }
    } else {
      // ❌ 无精准：WM 正常 + 兜底
      try {
        final u = _wmUniqueNormal(uid, runKey);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay,
          inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'normal','attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH','WM 正常注册完成 uid='+uid+' wm_unique='+u+' run='+runKey+' delay='+normalDelay.inSeconds.toString()+'s');
      } catch (e) {
        await DLog.e('SCH','WM 正常注册失败: '+e.toString());
      }
      try {
        final u = _wmUniqueFallback(uid, runKey, 1);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay + const Duration(minutes: 2),
          inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'fallback','attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH','WM 兜底注册完成 uid='+uid+' wm_unique='+u+' run='+runKey);
      } catch (e) {
        await DLog.e('SCH','WM 兜底注册失败: '+e.toString());
      }
    }
  }

  /// 精准取消（根据保存的 scheduled_run_key）
  static Future<void> cancelNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    final runKey = (t['scheduled_run_key'] ?? '').toString();
    if (runKey.isEmpty) {
      await DLog.w('SCH','取消下一次：没有保存的 runKey，uid='+uid);
      return;
    }
    try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
    await _cancelWmNormal(uid, runKey);
    await _cancelWmFallback(uid, runKey, 1);
    await _cancelWmFallback(uid, runKey, 2);
    await DLog.i('SCH','已取消下一次计划 uid='+uid+' run='+runKey);
  }

  /// 为全部任务安排下一次
  static Future<void> scheduleNextForAll() async {
    final list = await TaskDao().all();
    for (final t in list) {
      final uid = (t['task_uid'] ?? '').toString();
      if (uid.isEmpty) continue;
      await scheduleNextForTask(uid);
    }
  }

  /// 保存 next_time 并重新安排
  static Future<void> _updateNextAndReschedule(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    final next = _nextTimeForTask(t);
    final db = await AppDatabase.instance();
    try {
      await db.update('tasks', {'next_time': next.toIso8601String()}, where: 'task_uid=?', whereArgs: [uid]);
      await DLog.i('SCH','更新下一次时间 uid='+uid+' next='+_runKeyFromTime(next));
    } catch (e) {
      await DLog.e('SCH','更新下一次时间失败 uid='+uid+' err='+e.toString());
    }
    await scheduleNextForTask(uid);
  }

  /// 后台 WM 回调执行：统一走 TaskRunner
  static Future<void> wmRunTask(String uid, String? runKey) async {
    try {
      await TaskRunner.run(uid);
      // 成功后：取消兜底并刷新下一次
      if (runKey != null && runKey.isNotEmpty) {
        await _cancelWmFallback(uid, runKey, 1);
        await _cancelWmFallback(uid, runKey, 2);
        try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
      }
      await _updateNextAndReschedule(uid);
    } catch (e) {
      await DLog.e('SCH','wmRunTask 失败 uid='+uid+' err='+e.toString());
      // 失败时仅取消“自己”，保留兜底由 WM 自行触发
    }
  }

  /// 兼容旧入口
  static Future<void> callback() async {}

  /// 注册/刷新自检周期任务（最小 15 分钟）
  static Future<void> scheduleSelfCheck() async {
    final minutes = await NotifyConfigDao().getSelfCheckMinutes();
    final freq = Duration(minutes: minutes < 15 ? 15 : minutes);
    try {
      await Workmanager().registerPeriodicTask(
        'wm_selfcheck_unique',
        'wm_task',
        frequency: freq,
        initialDelay: const Duration(minutes: 1),
        inputData: {'job':'wm_selfcheck'},
        existingWorkPolicy: ExistingPeriodicWorkPolicy.update,
        constraints: Constraints(networkType: NetworkType.notRequired),
      );
      await DLog.i('SCH','自检任务已注册，频率='+minutes.toString()+'分钟');
    } catch (e) {
      await DLog.e('SCH','自检任务注册失败: '+e.toString());
    }
  }

  /// 每日自检：扫描当天失败记录并立刻补发
  static Future<void> selfCheckTodayFailures() async {
    try {
      final fails = await FailureStatDao().failsOfToday();
      if (fails.isEmpty) {
        await DLog.i('SCH','自检：今日无失败记录');
        return;
      }
      for (final row in fails) {
        final uid = (row['task_uid'] ?? '').toString();
        if (uid.isEmpty) continue;
        final runKey = _runKeyFromTime(DateTime.now());
        try {
          final u = _wmUniqueNormal(uid, runKey);
          await Workmanager().registerOneOffTask(
            u, 'wm_task',
            initialDelay: Duration.zero,
            inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'normal','attempt': 1},
            existingWorkPolicy: ExistingWorkPolicy.replace,
            tag: uid,
          );
          await DLog.i('SCH','自检补发：已注册 WM 正常 uid='+uid+' run='+runKey);
        } catch (e) {
          await DLog.e('SCH','自检补发注册失败 uid='+uid+' err='+e.toString());
        }
      }
    } catch (e) {
      await DLog.e('SCH','自检执行失败: '+e.toString());
    }
  }
}