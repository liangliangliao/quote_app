package com.example.quote_app.am

import android.util.Log


import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

object SqliteReader {
    private const val TAG = "quote_app/native"
    private fun logAndThrow(where: String, e: Throwable): Nothing {
        Log.e(TAG, "$where: ${e.message}", e)
        throw RuntimeException(e)
    }


    data class Payload(
        val title: String?, val content: String?,
        val bigPicture: String?, val actionsJson: String?, val payloadJson: String?
    )

    private fun readPayload(c: Cursor): Payload {
        fun s(name: String) = c.getColumnIndex(name).let { if (it >= 0) c.getString(it) else null }
        return Payload(s("title"), s("content"), s("big_picture"), s("actions_json"), s("payload_json"))
    }

    private fun tableExists(db: SQLiteDatabase, name: String): Boolean =
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(name))
            .use { it.moveToFirst() }

    @JvmStatic
    fun queryExact(dbPath: String, taskUid: String, runKey: String): Payload? {
        val db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            if (tableExists(it, "payloads")) {
                it.rawQuery(
                    "SELECT title,content,big_picture,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key=? LIMIT 1",
                    arrayOf(taskUid, runKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            return null
        }
    }

    @JvmStatic
    fun queryNear(dbPath: String, taskUid: String, fromKey: String, toKey: String): Payload? {
        val db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            if (tableExists(it, "payloads")) {
                it.rawQuery(
                    "SELECT title,content,big_picture,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key BETWEEN ? AND ? ORDER BY run_key DESC LIMIT 1",
                    arrayOf(taskUid, fromKey, toKey)
                ).use { c -> if (c.moveToFirst()) return readPayload(c) }
            }
            return null
        }
    }
}
