// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#import "AppDelegate.h"
#import <Flutter/Flutter.h>
#import <CoreLocation/CoreLocation.h>
#import "GeneratedPluginRegistrant.h"

@interface AppDelegate () <FlutterPluginRegistrant, CLLocationManagerDelegate>
#pragma mark - Sport Native Tracking (iOS)

- (NSString*)_sportSnapshotKey:(int)recordId {
  return [NSString stringWithFormat:@"quoteapp_sport_fg_%d", recordId];
}

- (NSDictionary*)_loadSportSnapshot:(int)recordId {
  NSString* key = [self _sportSnapshotKey:recordId];
  NSDictionary* d = [[NSUserDefaults standardUserDefaults] objectForKey:key];
  if (![d isKindOfClass:[NSDictionary class]]) return nil;
  return d;
}

- (void)_saveSportSnapshot:(NSDictionary*)snapshot recordId:(int)recordId {
  NSString* key = [self _sportSnapshotKey:recordId];
  [[NSUserDefaults standardUserDefaults] setObject:snapshot forKey:key];
  [[NSUserDefaults standardUserDefaults] synchronize];
}

- (int)_currentDurationSec {
  if (!_sportRunning) return _baseDurationSec;
  NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
  int inc = (int)MAX(0, floor(now - _startTs));
  return _baseDurationSec + inc;
}

- (NSDictionary*)_sportSnapshot {
  int dur = [self _currentDurationSec];
  double dist = _baseDistanceM + _sessionDistanceM;
  int steps = _baseSteps + (int)llround(dist / 0.75); // rough step length
  double avg = (dur > 0) ? (dist / (double)dur) * 3.6 : 0.0;
  return @{
    @"status": (_sportRunning ? @"in_progress" : @"paused"),
    @"total_duration": @(dur),
    @"total_distance": @(dist),
    @"total_steps": @(steps),
    @"current_speed": @(_currentSpeedKmh),
    @"avg_speed": @(avg),
  };
}

- (BOOL)_sportIsRunning {
  return _sportRunning;
}

- (void)_sportStart:(int)recordId {
  if (recordId <= 0) return;

  // Load previous snapshot as base (so leaving page / relaunch won't lose data).
  NSDictionary* snap = [self _loadSportSnapshot:recordId];
  _baseDurationSec = [snap[@"total_duration"] respondsToSelector:@selector(intValue)] ? [snap[@"total_duration"] intValue] : 0;
  _baseDistanceM = [snap[@"total_distance"] respondsToSelector:@selector(doubleValue)] ? [snap[@"total_distance"] doubleValue] : 0.0;
  _baseSteps = [snap[@"total_steps"] respondsToSelector:@selector(intValue)] ? [snap[@"total_steps"] intValue] : 0;

  _sportRecordId = recordId;
  _sessionDistanceM = 0.0;
  _currentSpeedKmh = 0.0;
  _lastLoc = nil;
  _lastLocTs = 0;
  _startTs = [[NSDate date] timeIntervalSince1970];
  _sportRunning = YES;

  if (_locMgr == nil) {
    _locMgr = [[CLLocationManager alloc] init];
    _locMgr.delegate = self;
    _locMgr.desiredAccuracy = kCLLocationAccuracyBest;
    _locMgr.distanceFilter = 1.0;
    _locMgr.pausesLocationUpdatesAutomatically = NO;
    if ([_locMgr respondsToSelector:@selector(setAllowsBackgroundLocationUpdates:)]) {
      _locMgr.allowsBackgroundLocationUpdates = YES;
    }
  }

  // Try request authorization. (User still needs to grant in Settings.)
  if ([_locMgr respondsToSelector:@selector(requestAlwaysAuthorization)]) {
    [_locMgr requestAlwaysAuthorization];
  } else if ([_locMgr respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
    [_locMgr requestWhenInUseAuthorization];
  }

  [_locMgr startUpdatingLocation];

  [_sportTimer invalidate];
  _sportTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                 target:self
                                               selector:@selector(_sportTick)
                                               userInfo:nil
                                                repeats:YES];

  // Persist immediately.
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

- (void)_sportStop {
  _sportRunning = NO;
  if (_locMgr != nil) {
    [_locMgr stopUpdatingLocation];
  }
  [_sportTimer invalidate];
  _sportTimer = nil;

  // Persist paused snapshot.
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

- (void)_sportTick {
  if (!_sportRunning) return;
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateLocations:(NSArray<CLLocation*>*)locations {
  if (!_sportRunning || locations.count == 0) return;
  CLLocation* loc = [locations lastObject];

  // Ignore poor accuracy fixes.
  if (loc.horizontalAccuracy < 0 || loc.horizontalAccuracy > 80) return;

  NSTimeInterval ts = [loc.timestamp timeIntervalSince1970];
  if (_lastLoc != nil) {
    double d = [loc distanceFromLocation:_lastLoc];
    if (d >= 0 && d < 2000) {
      _sessionDistanceM += d;
      double dt = ts - _lastLocTs;
      if (loc.speed >= 0) {
        _currentSpeedKmh = loc.speed * 3.6;
      } else if (dt > 0.2) {
        _currentSpeedKmh = (d / dt) * 3.6;
      }
    }
  }

  _lastLoc = loc;
  _lastLocTs = ts;

  // Persist after each location update as well.
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

@end

@implementation AppDelegate {
  FlutterEventSink _eventSink;

  // Sport native tracking (iOS)
  CLLocationManager* _locMgr;
  CLLocation* _lastLoc;
  NSTimeInterval _lastLocTs;
  NSTimer* _sportTimer;
  BOOL _sportRunning;
  int _sportRecordId;
  NSTimeInterval _startTs;
  int _baseDurationSec;
  double _baseDistanceM;
  int _baseSteps;
  double _sessionDistanceM;
  double _currentSpeedKmh;
}

- (BOOL)application:(UIApplication*)application
    didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {
  self.pluginRegistrant = self;
  return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

- (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [GeneratedPluginRegistrant registerWithRegistry:registry];
  NSObject<FlutterPluginRegistrar>* registrar = [registry registrarForPlugin:@"samples.flutter.io"];
  FlutterMethodChannel* batteryChannel = [FlutterMethodChannel
      methodChannelWithName:@"samples.flutter.io/battery"
            binaryMessenger:registrar.messenger];
  __weak typeof(self) weakSelf = self;
  [batteryChannel setMethodCallHandler:^(FlutterMethodCall* call,
                                         FlutterResult result) {
    if ([@"getBatteryLevel" isEqualToString:call.method]) {
      int batteryLevel = [weakSelf getBatteryLevel];
      if (batteryLevel == -1) {
        result([FlutterError errorWithCode:@"UNAVAILABLE"
                                   message:@"Battery info unavailable"
                                   details:nil]);
      } else {
        result(@(batteryLevel));
      }
    } else {
      result(FlutterMethodNotImplemented);
    }
  }];

  FlutterEventChannel* chargingChannel = [FlutterEventChannel
      eventChannelWithName:@"samples.flutter.io/charging"
           binaryMessenger:registrar.messenger];
  [chargingChannel setStreamHandler:self];

  // QuoteApp sport native tracking channel (shared with Android).
  NSObject<FlutterPluginRegistrar>* sysRegistrar = [registry registrarForPlugin:@"com.example.quote_app.sys"];
  FlutterMethodChannel* sysChannel =
      [FlutterMethodChannel methodChannelWithName:@"com.example.quote_app/sys"
                                  binaryMessenger:sysRegistrar.messenger];
  __weak typeof(self) weakSelf2 = self;
  [sysChannel setMethodCallHandler:^(FlutterMethodCall* call, FlutterResult result) {
    __strong typeof(weakSelf2) strongSelf = weakSelf2;
    if (!strongSelf) {
      result(@(NO));
      return;
    }

    if ([call.method isEqualToString:@"startSportForeground"]) {
      NSDictionary* args = (NSDictionary*)call.arguments;
      NSNumber* rid = args[@"recordId"];
      if (rid == nil) {
        result([FlutterError errorWithCode:@"INVALID_ARGS" message:@"recordId missing" details:nil]);
        return;
      }
      [strongSelf _sportStart:[rid intValue]];
      result(@(YES));
      return;
    }
    if ([call.method isEqualToString:@"stopSportForeground"]) {
      [strongSelf _sportStop];
      result(@(YES));
      return;
    }
    if ([call.method isEqualToString:@"isSportForegroundRunning"]) {
      result(@([strongSelf _sportIsRunning]));
      return;
    }
    if ([call.method isEqualToString:@"getSportSnapshot"]) {
      NSDictionary* args = (NSDictionary*)call.arguments;
      NSNumber* rid = args[@"recordId"];
      int reqId = (rid != nil) ? [rid intValue] : strongSelf->_sportRecordId;

      if (strongSelf->_sportRunning && reqId == strongSelf->_sportRecordId) {
        result([strongSelf _sportSnapshot]);
        return;
      }

      NSDictionary* stored = [strongSelf _loadSportSnapshot:reqId];
      if (stored != nil) {
        result(stored);
      } else {
        result([NSNull null]);
      }
      return;
    }

    result(FlutterMethodNotImplemented);
  }];
}


- (int)getBatteryLevel {
  UIDevice* device = UIDevice.currentDevice;
  device.batteryMonitoringEnabled = YES;
  if (device.batteryState == UIDeviceBatteryStateUnknown) {
    return -1;
  } else {
    return ((int)(device.batteryLevel * 100));
  }
}

- (FlutterError*)onListenWithArguments:(id)arguments
                             eventSink:(FlutterEventSink)eventSink {
  _eventSink = eventSink;
  [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
  [self sendBatteryStateEvent];
  [[NSNotificationCenter defaultCenter]
   addObserver:self
      selector:@selector(onBatteryStateDidChange:)
          name:UIDeviceBatteryStateDidChangeNotification
        object:nil];
  return nil;
}

- (void)onBatteryStateDidChange:(NSNotification*)notification {
  [self sendBatteryStateEvent];
}

- (void)sendBatteryStateEvent {
  if (!_eventSink) return;
  UIDeviceBatteryState state = [[UIDevice currentDevice] batteryState];
  switch (state) {
    case UIDeviceBatteryStateFull:
    case UIDeviceBatteryStateCharging:
      _eventSink(@"charging");
      break;
    case UIDeviceBatteryStateUnplugged:
      _eventSink(@"discharging");
      break;
    default:
      _eventSink([FlutterError errorWithCode:@"UNAVAILABLE"
                                     message:@"Charging status unavailable"
                                     details:nil]);
      break;
  }
}

- (FlutterError*)onCancelWithArguments:(id)arguments {
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  _eventSink = nil;
  return nil;
}

#pragma mark - Sport Native Tracking (iOS)

- (NSString*)_sportSnapshotKey:(int)recordId {
  return [NSString stringWithFormat:@"quoteapp_sport_fg_%d", recordId];
}

- (NSDictionary*)_loadSportSnapshot:(int)recordId {
  NSString* key = [self _sportSnapshotKey:recordId];
  NSDictionary* d = [[NSUserDefaults standardUserDefaults] objectForKey:key];
  if (![d isKindOfClass:[NSDictionary class]]) return nil;
  return d;
}

- (void)_saveSportSnapshot:(NSDictionary*)snapshot recordId:(int)recordId {
  NSString* key = [self _sportSnapshotKey:recordId];
  [[NSUserDefaults standardUserDefaults] setObject:snapshot forKey:key];
  [[NSUserDefaults standardUserDefaults] synchronize];
}

- (int)_currentDurationSec {
  if (!_sportRunning) return _baseDurationSec;
  NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
  int inc = (int)MAX(0, floor(now - _startTs));
  return _baseDurationSec + inc;
}

- (NSDictionary*)_sportSnapshot {
  int dur = [self _currentDurationSec];
  double dist = _baseDistanceM + _sessionDistanceM;
  int steps = _baseSteps + (int)llround(dist / 0.75); // rough step length
  double avg = (dur > 0) ? (dist / (double)dur) * 3.6 : 0.0;
  return @{
    @"status": (_sportRunning ? @"in_progress" : @"paused"),
    @"total_duration": @(dur),
    @"total_distance": @(dist),
    @"total_steps": @(steps),
    @"current_speed": @(_currentSpeedKmh),
    @"avg_speed": @(avg),
  };
}

- (BOOL)_sportIsRunning {
  return _sportRunning;
}

- (void)_sportStart:(int)recordId {
  if (recordId <= 0) return;

  // Load previous snapshot as base (so leaving page / relaunch won't lose data).
  NSDictionary* snap = [self _loadSportSnapshot:recordId];
  _baseDurationSec = [snap[@"total_duration"] respondsToSelector:@selector(intValue)] ? [snap[@"total_duration"] intValue] : 0;
  _baseDistanceM = [snap[@"total_distance"] respondsToSelector:@selector(doubleValue)] ? [snap[@"total_distance"] doubleValue] : 0.0;
  _baseSteps = [snap[@"total_steps"] respondsToSelector:@selector(intValue)] ? [snap[@"total_steps"] intValue] : 0;

  _sportRecordId = recordId;
  _sessionDistanceM = 0.0;
  _currentSpeedKmh = 0.0;
  _lastLoc = nil;
  _lastLocTs = 0;
  _startTs = [[NSDate date] timeIntervalSince1970];
  _sportRunning = YES;

  if (_locMgr == nil) {
    _locMgr = [[CLLocationManager alloc] init];
    _locMgr.delegate = self;
    _locMgr.desiredAccuracy = kCLLocationAccuracyBest;
    _locMgr.distanceFilter = 1.0;
    _locMgr.pausesLocationUpdatesAutomatically = NO;
    if ([_locMgr respondsToSelector:@selector(setAllowsBackgroundLocationUpdates:)]) {
      _locMgr.allowsBackgroundLocationUpdates = YES;
    }
  }

  // Try request authorization. (User still needs to grant in Settings.)
  if ([_locMgr respondsToSelector:@selector(requestAlwaysAuthorization)]) {
    [_locMgr requestAlwaysAuthorization];
  } else if ([_locMgr respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
    [_locMgr requestWhenInUseAuthorization];
  }

  [_locMgr startUpdatingLocation];

  [_sportTimer invalidate];
  _sportTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                 target:self
                                               selector:@selector(_sportTick)
                                               userInfo:nil
                                                repeats:YES];

  // Persist immediately.
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

- (void)_sportStop {
  _sportRunning = NO;
  if (_locMgr != nil) {
    [_locMgr stopUpdatingLocation];
  }
  [_sportTimer invalidate];
  _sportTimer = nil;

  // Persist paused snapshot.
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

- (void)_sportTick {
  if (!_sportRunning) return;
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateLocations:(NSArray<CLLocation*>*)locations {
  if (!_sportRunning || locations.count == 0) return;
  CLLocation* loc = [locations lastObject];

  // Ignore poor accuracy fixes.
  if (loc.horizontalAccuracy < 0 || loc.horizontalAccuracy > 80) return;

  NSTimeInterval ts = [loc.timestamp timeIntervalSince1970];
  if (_lastLoc != nil) {
    double d = [loc distanceFromLocation:_lastLoc];
    if (d >= 0 && d < 2000) {
      _sessionDistanceM += d;
      double dt = ts - _lastLocTs;
      if (loc.speed >= 0) {
        _currentSpeedKmh = loc.speed * 3.6;
      } else if (dt > 0.2) {
        _currentSpeedKmh = (d / dt) * 3.6;
      }
    }
  }

  _lastLoc = loc;
  _lastLocTs = ts;

  // Persist after each location update as well.
  NSDictionary* out = [self _sportSnapshot];
  [self _saveSportSnapshot:out recordId:_sportRecordId];
}

@end
