import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:workmanager/workmanager.dart';

import 'utils/debug_logger.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'platform/perm_helper.dart';

class BackgroundTasks {
  static const int _SELF_CHECK_ALARM_ID = 910001;

  static Future<void> registerSelfCheck() async {
    final hasExact = await PermHelper.hasExactAlarmPermission();
    final now = DateTime.now();
    final next = now.add(const Duration(minutes: 2));
    if (hasExact) {
      await DLog.i('BG', 'register self-check via AlarmManager @ '+next.toIso8601String());
      await AndroidAlarmManager.oneShotAt(
        next, _SELF_CHECK_ALARM_ID, BackgroundTasks.selfCheckAlarmCallback,
        exact: true, wakeup: true, allowWhileIdle: true, rescheduleOnReboot: true,
      );
    } else {
      await DLog.i('BG', 'register self-check via WorkManager (~2m)');
      await Workmanager().registerOneOffTask(
        'bg_selfcheck_'+now.millisecondsSinceEpoch.toString(), 'bg_selfcheck',
        initialDelay: const Duration(minutes: 2),
        existingWorkPolicy: ExistingWorkPolicy.keep,
      );
    }
  }

  @pragma('vm:entry-point')
  static Future<void> selfCheckAlarmCallback() async {
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    await DLog.i('BG', 'selfCheckAlarmCallback fired');
    await SchedulerService.catchupIfMissed();
    await SchedulerService.callback();
    await SchedulerService.scheduleNextForAll();
    await BackgroundTasks.registerSelfCheck();
  }
}
