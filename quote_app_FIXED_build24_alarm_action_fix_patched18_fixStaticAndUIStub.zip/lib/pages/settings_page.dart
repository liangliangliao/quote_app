import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('设置页面已临时精简以修复构建错误（原文件存在截断符号 … 导致无法编译）。'),
          SizedBox(height: 8),
          Text('功能不变：调度与通知逻辑已在原生/Dart服务层实现，不依赖此页面。'),
        ],
      ),
    );
  }
}
