import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:path/path.dart' as p;

import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {

Future<void> _showImportDialog(BuildContext context) async {
  // TODO: 将原先 onPressed 里的复杂导入对话框 UI 迁移到这里。
  // 先给出一个可编译的占位弹窗，功能保持：可以触发导入逻辑（后续替换为你的实现）。
  await showDialog(
    context: context,
    builder: (ctx) {
      return AlertDialog(
        title: const Text('批量导入'),
        content: const Text('这里是临时弹窗占位。稍后把原有复杂 UI 迁移到此方法即可。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () {
              // 预留：调用你的导入逻辑（例如选择文件/解析/入库）
              Navigator.pop(ctx);
            },
            child: const Text('确定'),
          ),
        ],
      );
    },
  );
}

        
  Future<String?> _saveAvatarTemp(File file) async {
    final docs = await getApplicationDocumentsDirectory();
    final ext = p.extension(file.path);
    final dst = File(p.join(docs.path, 'avatar_${DateTime.now().millisecondsSinceEpoch}${ext}'));
    await dst.writeAsBytes(await file.readAsBytes());
    return dst.path;
  }

  Future<void> _reload() async {
    _items.clear();
    _offset = 0;
    _done = false;
    await _loadMore();
    if (mounted) setState((){});
  }

  final _dao = QuoteDao();
  final _scroll = ScrollController();
  String _q = '';
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && !_done) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 100, offset: _offset, q: _q.isEmpty ? null : _q);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 100) _done = true;
  }

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;
    // Wrap entire page in SafeArea with top/bottom disabled so that list content touches edges
    return Scaffold(backgroundColor: Colors.white, body: SafeArea(
      top: false,
      bottom: false,
      child: Column(
        children: [
          // Header row containing search bar and upload button. Place within safe area padding manually
          Container(
            color: Colors.white,
            padding: EdgeInsets.only(top: topPad, left: 8, right: 8),
            height: topPad + kToolbarHeight,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: '搜索',
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      isDense: true,
                    ),
                    onChanged: (v) {
                      _q = v;
                      _items.clear();
                      _offset = 0;
                      _done = false;
                      _loadMore();
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Material(
                    color: Colors.white,
                    elevation: 6,
                    shape: const CircleBorder(),
                    child: IconButton(
                      tooltip: '导入',
                      icon: const Icon(Icons.upload_file, color: Colors.black87),
                      onPressed: () async { await _showImportDialog(context); },
                    ),
                  ),
                ),
              ],
            ),
          ),
          // List content with zero top/bottom padding
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: EdgeInsets.zero,
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final e = _items[i];
                return ListTile(
                  title: Text((e['task_name'] ?? '') as String),
                  subtitle: Text((e['content'] ?? '') as String, maxLines: 3, overflow: TextOverflow.ellipsis),
                );
              },
            ),
          ),
        ],
      ),
    ));
  }
}