import 'dart:io';
import 'package:flutter/services.dart';
import '../utils/debug_logger.dart';

class PermHelper {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');
  static bool? _lastHasExact;
  static DateTime? _lastExactCheckedAt;

  /// 是否拥有“精确闹钟”权限（带缓存与容错，避免偶发抖动）
  static Future<bool> hasExactAlarmPermission({bool assumeIfMissing = true, bool forBackground = false}) async {
    if (!Platform.isAndroid) return true;
    // 10 秒内重复查询直接使用缓存
    if (_lastExactCheckedAt != null &&
        DateTime.now().difference(_lastExactCheckedAt!) < const Duration(seconds: 10) &&
        _lastHasExact != null) {
      return _lastHasExact!;
    }
    // 后台/回调隔离中不要通过 MethodChannel 触发原生（避免 MissingPluginException）
    if (forBackground) {
      _lastHasExact ??= true;
      _lastExactCheckedAt = DateTime.now();
      return _lastHasExact!;
    }
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      _lastHasExact = ok ?? _lastHasExact ?? true;
      _lastExactCheckedAt = DateTime.now();
      return _lastHasExact!;
    } on MissingPluginException {
      // 后台/未注册引擎场景：按 assumeIfMissing 兜底
      _lastHasExact ??= assumeIfMissing;
      _lastExactCheckedAt = DateTime.now();
      return _lastHasExact!;
    } catch (e) {
      // Channel 抖动或异常：返回上次成功结果；若无则使用 assumeIfMissing
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
      _lastHasExact ??= assumeIfMissing;
      _lastExactCheckedAt = DateTime.now();
      return _lastHasExact!;
    }
  }
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      _lastHasExact = ok ?? _lastHasExact ?? true;
      _lastExactCheckedAt = DateTime.now();
      return _lastHasExact!;
    } catch (e) {
      // Channel 抖动或异常：返回上次成功结果；若无则乐观 true
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
      return _lastHasExact ?? true;
    }
  }

  /// 确保忽略电池优化（如未忽略或被后台限制，则引导到设置页）
  static Future<void> ensureBatteryOptExemption() async {
    if (!Platform.isAndroid) return;
    try {
      final ignored = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations') ?? true;
      final restricted = await _ch.invokeMethod<bool>('isBackgroundRestricted') ?? false;
      if (!ignored || restricted) {
        await _ch.invokeMethod('openAppBatterySettings');
      }
    } catch (e) {
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
    }
  }

  static Future<bool> isIgnoringBatteryOptimizations() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return ok ?? true;
    } catch (e) {
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
      return true;
    }
  }

  static Future<bool> isBackgroundRestricted() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('isBackgroundRestricted');
      return ok ?? false;
    } catch (e) {
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
      return false;
    }
  }

  static Future<void> openAppBatterySettings() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('openAppBatterySettings');
    } catch (e) {
      DLog.e('platform/perm_helper.dart', 'catch: ' + e.toString());
    }
  }
}
