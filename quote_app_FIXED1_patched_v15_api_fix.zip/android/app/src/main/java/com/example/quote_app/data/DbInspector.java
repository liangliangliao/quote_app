package com.example.quote_app.data;

import android.content.Context;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class DbInspector {
    private DbInspector() {}

    public static final class Contract {
        public String dbPath;
        public String tasksSource;
        public Map<String,String> taskColMap = new HashMap<>();
    }

    public static Contract loadOrLightScan(Context ctx) {
        Contract c = new Contract();
        File appFlutter = new File(ctx.getFilesDir(), "../app_flutter");
        c.dbPath = new File(appFlutter, "quotes.db").getAbsolutePath();
        c.tasksSource = "tasks";
        c.taskColMap.put("uid", "uid");
        c.taskColMap.put("title", "title");
        c.taskColMap.put("content", "content");
        c.taskColMap.put("trigger_at", "trigger_at");
        c.taskColMap.put("enabled", "enabled");
        c.taskColMap.put("type", "type");
        c.taskColMap.put("prompt", "prompt");
        c.taskColMap.put("avatar", "avatar_path");
        return c;
    }
}
