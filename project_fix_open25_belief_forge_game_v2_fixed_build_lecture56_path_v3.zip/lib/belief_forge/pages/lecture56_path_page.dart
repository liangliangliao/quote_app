import 'dart:convert';

import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../model/lecture56_modules.dart';
import 'lecture56_module_page.dart';

/// An ordered path that follows Harvard Positive Psychology Lecture 5 + Lecture 6.
///
/// This path is designed to preserve the original logic flow:
/// situation/positive loop (L5) → belief-to-reality mechanisms (L6).
class Lecture56PathPage extends StatefulWidget {
  const Lecture56PathPage({super.key});

  @override
  State<Lecture56PathPage> createState() => _Lecture56PathPageState();
}

class _Lecture56PathPageState extends State<Lecture56PathPage> {
  final _dao = BeliefForgeDao();
  bool _loading = true;
  final Set<String> _completed = <String>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await _dao.ensureSchema();
    final rows = await _dao.listRuns(limit: 600);
    final completed = <String>{};

    for (final r in rows) {
      final type = (r['run_type'] ?? '').toString();
      if (type != 'module') continue;
      final cid = (r['concept_id'] ?? '').toString();
      if (cid.isEmpty) continue;
      completed.add(cid);

      final extraRaw = (r['extra_json'] ?? '').toString();
      if (extraRaw.isEmpty) continue;
      try {
        final decoded = jsonDecode(extraRaw);
        if (decoded is Map<String, dynamic>) {
          final mid = (decoded['module_id'] ?? '').toString();
          if (mid.isNotEmpty) completed.add(mid);
        }
      } catch (_) {
        // ignore
      }
    }

    if (!mounted) return;
    setState(() {
      _completed
        ..clear()
        ..addAll(completed);
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    final completedCount = kLecture56Modules.where((m) => _completed.contains(m.id)).length;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Lecture 5–6 信念路径（15关）'),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
          children: [
            Card(
              elevation: 0,
              color: const Color(0xFFF7F7F7),
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('按原课逻辑串起来', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text(
                      '你已完成 $completedCount/15 关。\n'
                      '每一关都是：原文钩子 → 解释/为什么 → 互动选择 → 行动卡 → 生活落地。\n'
                      '建议顺序做，但你也可以任意选择。',
                      style: const TextStyle(color: Colors.black54, height: 1.25),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () async {
                              final next = kLecture56Modules.firstWhere(
                                (m) => !_completed.contains(m.id),
                                orElse: () => kLecture56Modules.last,
                              );
                              await Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => Lecture56ModulePage(moduleId: next.id)),
                              );
                              await _load();
                            },
                            icon: const Icon(Icons.play_arrow),
                            label: const Text('继续下一关'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            ...kLecture56Modules.map((m) {
              final done = _completed.contains(m.id);
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  tileColor: const Color(0xFFF7F7F7),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  leading: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: Text(
                      m.index.toString().padLeft(2, '0'),
                      style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.black87),
                    ),
                  ),
                  title: Text(m.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${m.lecture}${done ? ' · 已完成' : ''}'),
                  trailing: done ? const Icon(Icons.check_circle, color: Colors.green) : const Icon(Icons.chevron_right),
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => Lecture56ModulePage(moduleId: m.id)),
                    );
                    await _load();
                  },
                ),
              );
            }),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: () async {
                final award = await BeliefGameService.instance.awardXp(xp: 5, reason: 'path_checkin');
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已记录：今天来过路径（+5 XP）')));
                // keep the path page lightweight: no modal feedback
              },
              icon: const Icon(Icons.auto_awesome),
              label: const Text('今日来过（小奖励）'),
            ),
          ],
        ),
      ),
    );
  }
}
