import 'package:flutter/material.dart';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../model/lecture56_modules.dart';
import '../model/lecture56_playgrounds.dart';
import '../widgets/concept_playground_wizard.dart';
import '../widgets/game_feedback.dart';

/// A single module page in the Lecture 5–6 belief path.
class Lecture56ModulePage extends StatefulWidget {
  final String moduleId;
  const Lecture56ModulePage({super.key, required this.moduleId});

  @override
  State<Lecture56ModulePage> createState() => _Lecture56ModulePageState();
}

class _Lecture56ModulePageState extends State<Lecture56ModulePage> {
  final _dao = BeliefForgeDao();

  @override
  void initState() {
    super.initState();
    _dao.ensureSchema();
  }

  @override
  Widget build(BuildContext context) {
    final m = findLecture56Module(widget.moduleId);
    if (m == null) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text('课程关卡'),
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
        ),
        body: const Center(child: Text('找不到该关卡（moduleId 不存在）')),
      );
    }

    final cfg = getLecture56PlaygroundConfig(m.id);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('${m.index.toString().padLeft(2, '0')} · ${m.title}'),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
        children: [
          Text(m.lecture, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 10),
          _InfoCard(
            title: '原课钩子（原文/原例）',
            body: '${m.hookQuote}\n\n${m.hookCase}',
          ),
          const SizedBox(height: 12),
          if (cfg != null)
            _InteractionCard(
              title: '互动：做选择，生成你的行动卡',
              subtitle: cfg.intro,
              child: ConceptPlaygroundWizard(
                conceptId: m.id,
                conceptTitle: '第${m.index}关·${m.title}',
                config: cfg,
                dao: _dao,
                runType: 'module',
              ),
            )
          else
            _InfoCard(
              title: '互动',
              body: '（该关尚未配置互动向导）',
            ),
          const SizedBox(height: 12),
          _InfoCard(title: '你刚刚经历了什么（解释）', body: m.explanation),
          const SizedBox(height: 12),
          _InfoCard(title: '为什么会这样（机制）', body: m.why),
          const SizedBox(height: 12),
          _ChecklistCard(title: '你可以怎么做（步骤）', items: m.howTo),
          const SizedBox(height: 12),
          _InfoCard(title: '日常案例（照着做）', body: m.caseStudy),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () async {
              await _dao.addRun(
                conceptId: m.id,
                conceptTitle: '第${m.index}关·${m.title}',
                runType: 'module',
                note: 'module_complete',
                extra: {
                  'type': 'module_complete',
                  'module_id': m.id,
                  'module_index': m.index,
                },
              );
              final award = await BeliefGameService.instance.awardXp(xp: 10, reason: 'module_complete');
              await BeliefGameService.instance.unlockBadge(
                'badge_path_lecture56_${m.index}',
                extra: {
                  'title': '通关：${m.title}',
                  'desc': '你完成了 Lecture 5–6 路径的第${m.index}关。',
                },
              );
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已记录：本关完成')));
              await showXpFeedback(context, award: award);
            },
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('完成本关（记录 +10 XP）'),
          ),
        ],
      ),
    );
  }
}

class _InteractionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  const _InteractionCard({required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF7F7F7),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String body;
  const _InfoCard({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Text(body, style: const TextStyle(height: 1.4)),
          ],
        ),
      ),
    );
  }
}

class _ChecklistCard extends StatelessWidget {
  final String title;
  final List<String> items;
  const _ChecklistCard({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            ...items.map(
              (it) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.check_circle_outline, size: 18),
                    const SizedBox(width: 8),
                    Expanded(child: Text(it, style: const TextStyle(height: 1.35))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
