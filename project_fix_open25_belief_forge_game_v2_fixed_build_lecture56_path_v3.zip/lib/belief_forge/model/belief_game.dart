import 'dart:math';

/// Lightweight gamification model for BeliefForge.
///
/// XP curve (quadratic):
///   xpToReach(level) = 50 * (level - 1) * level
/// Examples:
///   L1: 0
///   L2: 100
///   L3: 300
///   L4: 600
///   L5: 1000
class BeliefGameMath {
  static int xpToReachLevel(int level) {
    final l = max(1, level);
    return 50 * (l - 1) * l;
  }

  /// Returns 1-based level for a given total XP.
  static int levelForXp(int xp) {
    final x = max(0, xp);
    // Solve: 50*(l^2 - l) <= x
    // l^2 - l - x/50 <= 0
    // l = (1 + sqrt(1 + 4*x/50)) / 2
    final disc = 1.0 + 4.0 * (x / 50.0);
    final l = ((1.0 + sqrt(disc)) / 2.0).floor();
    return max(1, l);
  }

  static int currentLevelStartXp(int xp) {
    final l = levelForXp(xp);
    return xpToReachLevel(l);
  }

  static int nextLevelXp(int xp) {
    final l = levelForXp(xp);
    return xpToReachLevel(l + 1);
  }

  static double progressToNextLevel(int xp) {
    final start = currentLevelStartXp(xp);
    final next = nextLevelXp(xp);
    if (next <= start) return 1.0;
    return (xp - start) / (next - start);
  }
}

class BeliefProfile {
  final int xp;
  final int coins;
  final int streak;
  final String lastActiveDay; // YYYY-MM-DD
  final String lastChestClaimDay; // YYYY-MM-DD

  const BeliefProfile({
    required this.xp,
    required this.coins,
    required this.streak,
    required this.lastActiveDay,
    required this.lastChestClaimDay,
  });

  int get level => BeliefGameMath.levelForXp(xp);
  int get levelStartXp => BeliefGameMath.currentLevelStartXp(xp);
  int get nextLevelXp => BeliefGameMath.nextLevelXp(xp);
  double get levelProgress => BeliefGameMath.progressToNextLevel(xp).clamp(0.0, 1.0);

  BeliefProfile copyWith({
    int? xp,
    int? coins,
    int? streak,
    String? lastActiveDay,
    String? lastChestClaimDay,
  }) {
    return BeliefProfile(
      xp: xp ?? this.xp,
      coins: coins ?? this.coins,
      streak: streak ?? this.streak,
      lastActiveDay: lastActiveDay ?? this.lastActiveDay,
      lastChestClaimDay: lastChestClaimDay ?? this.lastChestClaimDay,
    );
  }

  static BeliefProfile defaultProfile() {
    return const BeliefProfile(
      xp: 0,
      coins: 0,
      streak: 0,
      lastActiveDay: '',
      lastChestClaimDay: '',
    );
  }

  static BeliefProfile fromRow(Map<String, dynamic> row) {
    return BeliefProfile(
      xp: (row['xp'] as num?)?.toInt() ?? 0,
      coins: (row['coins'] as num?)?.toInt() ?? 0,
      streak: (row['streak'] as num?)?.toInt() ?? 0,
      lastActiveDay: (row['last_active_day'] ?? '').toString(),
      lastChestClaimDay: (row['last_chest_claim_day'] ?? '').toString(),
    );
  }
}

class XpAward {
  final int xpGained;
  final int coinsGained;
  final int oldLevel;
  final int newLevel;

  const XpAward({
    required this.xpGained,
    required this.coinsGained,
    required this.oldLevel,
    required this.newLevel,
  });

  bool get leveledUp => newLevel > oldLevel;
}

String ymd(DateTime dt) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${dt.year.toString().padLeft(4, '0')}-${two(dt.month)}-${two(dt.day)}';
}

String ymdYesterday(DateTime dt) => ymd(dt.subtract(const Duration(days: 1)));

/// Concept unlock gates (game-like progression).
/// Level 1 concepts are always available.
const Map<String, int> kConceptRequiredLevel = {
  // Level 1: onboarding / fast wins
  'broaden_build': 1,
  'priming': 1,
  'permission_human': 1,

  // Level 2: social + mindset
  'belief_gears': 2,
  'growth_mindset': 2,
  'pygmalion': 2,

  // Level 3: relationships + expectations
  'relationship_cultivate': 3,
  'correct_expectations': 3,

  // Level 4: deeper body/mind + situation
  'placebo': 4,
  'situation_power': 4,

  // Level 5: mastery
  'emotion_to_motion': 5,
  'active_agent': 5,
};

class DailyQuestDef {
  final String id;
  final String title;
  final String desc;
  final int target;
  final int xp;
  final int coins;
  /// which module to jump to: lab / will / space / map
  final String jump;

  const DailyQuestDef({
    required this.id,
    required this.title,
    required this.desc,
    required this.target,
    required this.xp,
    this.coins = 0,
    required this.jump,
  });
}

/// Daily quests are pre-defined (within preset concept range) to create
/// repeatable gameplay loops.
const List<DailyQuestDef> kDailyQuests = [
  DailyQuestDef(
    id: 'q_action_card',
    title: '生成并保存 1 张行动卡',
    desc: '在任意概念里完成选择，并点击“保存”。',
    target: 1,
    xp: 20,
    jump: 'lab',
  ),
  DailyQuestDef(
    id: 'q_will',
    title: '完成 1 次意志训练',
    desc: '完成 fiat 或 “注意力拉回” 任意一个。',
    target: 1,
    xp: 15,
    jump: 'will',
  ),
  DailyQuestDef(
    id: 'q_space',
    title: '写 1 次允许区记录',
    desc: '完成“三句话练习”，给情绪一个容器。',
    target: 1,
    xp: 15,
    jump: 'space',
  ),
  DailyQuestDef(
    id: 'q_map',
    title: '新增/更新 1 张信念卡',
    desc: '写出限制信念 → 替代信念，并设一个 1% 行动。',
    target: 1,
    xp: 15,
    jump: 'map',
  ),
];
