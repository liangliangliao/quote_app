import 'package:flutter/material.dart';
import 'dart:math';

import '../belief_forge_dao.dart';
import '../belief_game_service.dart';
import '../model/concept_playgrounds.dart';
import 'game_feedback.dart';

/// A step-by-step wizard that turns concept learning into interaction.
///
/// Users select within preset options, then the wizard generates a concrete
/// Action Card (summary + steps + case) that can be saved to Review.
class ConceptPlaygroundWizard extends StatefulWidget {
  final String conceptId;
  final String conceptTitle;
  final ConceptPlaygroundConfig config;
  final BeliefForgeDao dao;
  /// Persistence label for this wizard run.
  ///
  /// Default is 'lab' (used by Belief Lab). Course/path pages can override it
  /// (e.g. 'module') so Review can distinguish the practice source.
  final String runType;
  final void Function(Map<String, List<String>> selections)? onSelectionChanged;

  const ConceptPlaygroundWizard({
    super.key,
    required this.conceptId,
    required this.conceptTitle,
    required this.config,
    required this.dao,
    this.runType = 'lab',
    this.onSelectionChanged,
  });

  @override
  State<ConceptPlaygroundWizard> createState() => _ConceptPlaygroundWizardState();
}

class _ConceptPlaygroundWizardState extends State<ConceptPlaygroundWizard> {
  int _step = 0;
  final Map<String, Set<String>> _selected = {};

  // group key -> expanded (to show more chip options)
  final Map<String, bool> _expanded = {};

  static const int _maxChipsBeforeMore = 7;

  bool get _complete {
    for (final g in widget.config.groups) {
      if ((_selected[g.key] ?? const {}).isEmpty) return false;
    }
    return true;
  }

  Map<String, List<String>> _selectedIds() {
    final out = <String, List<String>>{};
    for (final g in widget.config.groups) {
      out[g.key] = (_selected[g.key] ?? {}).toList();
    }
    return out;
  }

  Map<String, List<PlaygroundOption>> _selectedOptions() {
    final out = <String, List<PlaygroundOption>>{};
    for (final g in widget.config.groups) {
      final ids = _selected[g.key] ?? {};
      out[g.key] = g.options.where((o) => ids.contains(o.id)).toList();
    }
    return out;
  }

  void _notifySelectionChanged() {
    widget.onSelectionChanged?.call(_selectedIds());
  }

  // Randomly pick within the preset option space (kept deterministic & testable).
  Map<String, List<PlaygroundOption>> randomPresetSelections(ConceptPlaygroundConfig config) {
    final rnd = Random();
    final picks = <String, List<PlaygroundOption>>{};
    for (final g in config.groups) {
      if (g.options.isEmpty) {
        picks[g.key] = const [];
        continue;
      }
      if (g.mode == SelectionMode.single) {
        picks[g.key] = [g.options[rnd.nextInt(g.options.length)]];
      } else {
        final max = g.maxSelect.clamp(1, g.options.length);
        final count = 1 + rnd.nextInt(max);
        final shuffled = List<PlaygroundOption>.from(g.options)..shuffle(rnd);
        picks[g.key] = shuffled.take(count).toList();
      }
    }
    return picks;
  }


  void _randomize() {
    final picks = randomPresetSelections(widget.config);
    setState(() {
      _selected.clear();
      for (final e in picks.entries) {
        _selected[e.key] = e.value.map((o) => o.id).toSet();
      }
      _step = 0;
    });
    _notifySelectionChanged();
  }

  void _selectSingle(PlaygroundGroup g, PlaygroundOption o) {
    setState(() {
      _selected[g.key] = {o.id};
    });
    _notifySelectionChanged();
  }

  void _toggleMulti(PlaygroundGroup g, PlaygroundOption o) {
    final set = _selected[g.key] ?? <String>{};
    final already = set.contains(o.id);
    if (already) {
      set.remove(o.id);
      setState(() => _selected[g.key] = set);
      _notifySelectionChanged();
      return;
    }
    if (set.length >= g.maxSelect) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('最多选择 ${g.maxSelect} 个选项')),
      );
      return;
    }
    set.add(o.id);
    setState(() => _selected[g.key] = set);
    _notifySelectionChanged();
  }

  Future<void> _saveActionCard(ActionCard card) async {
    final extra = {
      'type': 'action_card',
      'concept_id': widget.conceptId,
      'concept_title': widget.conceptTitle,
      'selections': _selectedIds(),
      'action_card': card.toJson(),
    };
    await widget.dao.addRun(
      conceptId: widget.conceptId,
      conceptTitle: widget.conceptTitle,
      runType: widget.runType,
      note: card.title,
      extra: extra,
    );

    // Gamification: saving an action card is the core loop.
    final award = await BeliefGameService.instance.awardXp(xp: 15, reason: 'action_card');
    await BeliefGameService.instance.unlockBadge(
      'badge_first_action_card',
      extra: const {
        'title': '第一张行动卡',
        'desc': '你把一个概念变成了可执行的行动卡。',
      },
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已保存：行动卡已加入“复盘”')),
    );
    await showXpFeedback(context, award: award);
  }

  @override
  Widget build(BuildContext context) {
    final groups = widget.config.groups;
    final g = groups[_step.clamp(0, groups.length - 1)];

    final expanded = _expanded[g.key] ?? false;
    final showMoreToggle = g.options.length > _maxChipsBeforeMore;
    final visibleOptions = (!expanded && showMoreToggle)
        ? g.options.take(_maxChipsBeforeMore).toList()
        : g.options;
    final selectedCount = (_selected[g.key] ?? const {}).length;

    final card = _complete ? widget.config.generator(_selectedOptions()) : null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                '互动选择（${_step + 1}/${groups.length}）',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            TextButton.icon(
              onPressed: _randomize,
              icon: const Icon(Icons.casino_outlined, size: 18),
              label: const Text('随机推荐'),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          g.mode == SelectionMode.multi ? '${g.title}（已选 $selectedCount/${g.maxSelect}）' : g.title,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
        if ((g.description ?? '').isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(
            g.description!,
            style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25),
          ),
        ],
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            ...visibleOptions.map((o) {
            final selected = (_selected[g.key] ?? const {}).contains(o.id);
            final label = o.hint == null || o.hint!.isEmpty ? o.label : '${o.label} · ${o.hint}';

            if (g.mode == SelectionMode.single) {
              return ChoiceChip(
                label: Text(label),
                selected: selected,
                onSelected: (_) => _selectSingle(g, o),
              );
            }
            return FilterChip(
              label: Text(label),
              selected: selected,
              onSelected: (_) => _toggleMulti(g, o),
            );
          }).toList(),
            if (showMoreToggle)
              ActionChip(
                label: Text(expanded ? '收起' : '更多 +${g.options.length - _maxChipsBeforeMore}'),
                avatar: Icon(expanded ? Icons.expand_less : Icons.expand_more, size: 18),
                onPressed: () => setState(() => _expanded[g.key] = !expanded),
              ),
          ],
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            OutlinedButton.icon(
              onPressed: _step == 0
                  ? null
                  : () {
                      setState(() => _step = (_step - 1).clamp(0, groups.length - 1));
                    },
              icon: const Icon(Icons.chevron_left),
              label: const Text('上一步'),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                onPressed: () {
                  if ((_selected[g.key] ?? const {}).isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('先选一个选项，再继续')),
                    );
                    return;
                  }
                  if (_step >= groups.length - 1) {
                    // stay
                    return;
                  }
                  setState(() => _step++);
                },
                icon: Icon(_step >= groups.length - 1 ? Icons.check : Icons.chevron_right),
                label: Text(_step >= groups.length - 1 ? '已完成选择' : '下一步'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),

        if (card == null)
          _HintBox(text: widget.config.intro)
        else
          _ActionCardPreview(
            card: card,
            onSave: () => _saveActionCard(card),
          ),
      ],
    );
  }
}

class _HintBox extends StatelessWidget {
  final String text;
  const _HintBox({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE7E7E7)),
      ),
      child: Text(
        text,
        style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.3),
      ),
    );
  }
}

class _ActionCardPreview extends StatelessWidget {
  final ActionCard card;
  final VoidCallback onSave;
  const _ActionCardPreview({required this.card, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE7E7E7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(card.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
              ),
              TextButton.icon(
                onPressed: onSave,
                icon: const Icon(Icons.save_outlined, size: 18),
                label: const Text('保存'),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(card.summary, style: const TextStyle(height: 1.28)),
          const SizedBox(height: 10),
          const Text('为什么有效', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(card.whyShort, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
          const SizedBox(height: 10),
          const Text('具体怎么做', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          ...card.steps.map((s) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('•  '),
                    Expanded(child: Text(s, style: const TextStyle(height: 1.25))),
                  ],
                ),
              )),
          const SizedBox(height: 10),
          const Text('一个日常案例', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(card.example, style: const TextStyle(fontSize: 12, color: Colors.black54, height: 1.25)),
        ],
      ),
    );
  }
}
