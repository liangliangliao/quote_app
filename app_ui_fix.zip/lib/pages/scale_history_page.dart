import 'package:flutter/material.dart';

import '../data/scale_dao.dart';
import '../data/dao.dart';

/// 历史测评记录页面
///
/// 展示指定量表的所有历史测评结果列表。
class ScaleHistoryPage extends StatefulWidget {
  final int scaleId;
  final String userId;
  final String scaleName;
  const ScaleHistoryPage({super.key, required this.scaleId, required this.userId, required this.scaleName});

  @override
  State<ScaleHistoryPage> createState() => _ScaleHistoryPageState();
}

class _ScaleHistoryPageState extends State<ScaleHistoryPage> {
  final ScaleDao _scaleDao = ScaleDao();
  final LogDao _logDao = LogDao();
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _logDao.add(taskUid: 'scale_${widget.scaleId}', detail: '查看历史记录');
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    return await _scaleDao.getAssessments(
      scaleId: widget.scaleId,
      userId: widget.userId,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.scaleName} - 历史记录'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('加载失败: ${snapshot.error}'));
          }
          final records = snapshot.data ?? [];
          if (records.isEmpty) {
            return const Center(child: Text('暂无历史记录'));
          }
          return ListView.separated(
            itemCount: records.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final r = records[index];
              final double score = (r['total_score'] ?? 0) as double;
              final String level = (r['level'] ?? '').toString();
              final String report = (r['report_text'] ?? '').toString();
              final rawCreatedAt = r['created_at'];
              DateTime? dt;
              try {
                if (rawCreatedAt is int) {
                  dt = DateTime.fromMillisecondsSinceEpoch(rawCreatedAt);
                } else {
                  dt = DateTime.parse(rawCreatedAt.toString());
                }
              } catch (_) {}
              String createdAt;
              if (dt != null) {
                final yyyy = dt!.year.toString().padLeft(4, '0');
                final mm = dt!.month.toString().padLeft(2, '0');
                final dd = dt!.day.toString().padLeft(2, '0');
                final hh = dt!.hour.toString().padLeft(2, '0');
                final mi = dt!.minute.toString().padLeft(2, '0');
                createdAt = '$yyyy-$mm-$dd $hh:$mi';
              } else {
                createdAt = rawCreatedAt?.toString() ?? '';
              }
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                color: Colors.white,
                child: ListTile(
                  title: Text('得分: $score, 等级: $level'),
                  subtitle: Text('时间: $createdAt
报告: $report'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}