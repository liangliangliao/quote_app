import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import '../platform/perm_helper.dart';

class SchedulerService {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<void> init() async {
    WidgetsFlutterBinding.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    try { await AndroidAlarmManager.initialize(); } catch (_) {}
  }

  /// Schedule next alarm for all active tasks.
  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    final List<Map<String, dynamic>> toNative = [];

    // Whether we can schedule exact alarms
    final canExact = await PermHelper.hasExactAlarmPermission();

    for (final t in tasks) {
      final status = (t['status'] ?? 'on') as String;
      if (status != 'on') continue;

      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '到点提醒') as String;
      final start = (t['start_time'] ?? '') as String;
      final id = _alarmIdForTask(taskUid);

      DateTime when;
      if (start.isNotEmpty) {
        when = _parseDateTime(start) ?? DateTime.now().add(const Duration(minutes: 2));
      } else {
        when = DateTime.now().add(const Duration(minutes: 2));
      }

      if (canExact) {
        try {
          await AndroidAlarmManager.oneShotAt(
            when,
            id,
            alarmCallback,
            exact: true,
            wakeup: true,
            allowWhileIdle: true,
            rescheduleOnReboot: true,
          );
        } catch (_) {}
      } else {
        // Fallback to native foreground-service polling
        toNative.add({'id': id, 'when': when.millisecondsSinceEpoch, 'title': name, 'body': '定时任务已到期'});
      }

      // Persist next trigger time回写，方便 UI 展示
      try { await db.update('tasks', {'start_time': _fmt(when)}, where: 'task_uid=?', whereArgs: [taskUid]); } catch (_) {}
    }

    if (toNative.isNotEmpty) {
      try { await _ch.invokeMethod('saveSchedules', {'list': toNative}); } catch (_) {}
    }
  }

  /// Called from alarm isolate
  static Future<void> callback() async {
    final db = await AppDatabase.instance();
    // 仅记录日志，实际通知由 alarmCallback 直接触发
    try {
      await LogDao().add(taskUid: 'alarm', detail: '定时回调触发');
    } catch (_) {}
  }

  static int _alarmIdForTask(String uid) {
    if (uid.isEmpty) return 9973;
    return uid.hashCode & 0x7fffffff;
  }

  static DateTime? _parseDateTime(String s) {
    // Try common formats: 'yyyy-MM-dd HH:mm' or ISO
    try {
      if (s.contains('T')) return DateTime.parse(s);
      final f = DateFormat('yyyy-MM-dd HH:mm');
      return f.parse(s);
    } catch (_) { return null; }
  }
}

@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  try {
    // 显示一个通用通知；若需按任务内容展示，可在 DB 里查任务细节
    await NotificationService.show(
      id: Random().nextInt(1 << 20),
      title: '到点提醒',
      body: '定时任务已触发',
    );
  } catch (_) {}
  await AppDatabase.instance();
  await SchedulerService.callback();
}

String _fmt(DateTime dt) {
  final f = DateFormat('yyyy-MM-dd HH:mm');
  return f.format(dt);
}
