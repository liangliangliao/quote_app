package com.example.quote_app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_POST_NOTIFICATIONS) {
            // If notifications are now enabled, start the foreground service safely.
            try {
                if (NotificationUtils.areNotificationsEnabled(this)) {
                    val svc = Intent(this, ReminderForegroundService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
                }
            } catch (_: Exception) {}
        }
    }


    companion object {
        private const val REQ_POST_NOTIFICATIONS = 1001
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "hasExactAlarmPermission" -> {
                    val can = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        am.canScheduleExactAlarms()
                    } else { true }
                    result.success(can)
                }
                else -> result.notImplemented()
            }
        }

        val channelSched = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
        channelSched.setMethodCallHandler { call, result ->
            when (call.method) {
                "saveSchedules" -> {
                    try {
                        val list = call.argument<List<Map<String, Any>>>("list")
                        val arr = org.json.JSONArray()
                        if (list != null) {
                            for (m in list) {
                                val o = org.json.JSONObject(m as Map<*, *>)
                                arr.put(o)
                            }
                        }
                        getSharedPreferences("sched_store", Context.MODE_PRIVATE)
                            .edit().putString("entries", arr.toString()).apply()
                        result.success(true)
                    } catch (e: Exception) { result.error("ERR", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }

        // Extra handler to schedule AlarmClock when exact not granted
        val channel2 = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
        channel2.setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleAlarmClock" -> {
                    try {
                        val whenMs = (call.argument<Number>("when")?.toLong()) ?: 0L
                        val id = call.argument<Int>("id") ?: 0
                        val title = call.argument<String>("title") ?: "到点提醒"
                        val body = call.argument<String>("body") ?: "定时任务已到期"
                        val ctx = this
                        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                        val showIntent = Intent(ctx, MainActivity::class.java)
                        val showPi = android.app.PendingIntent.getActivity(
                            ctx, id,
                            showIntent,
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        val bcIntent = Intent(ctx, AlarmClockReceiver::class.java).apply {
                            putExtra("id", id)
                            putExtra("title", title)
                            putExtra("body", body)
                        }
                        val bcPi = android.app.PendingIntent.getBroadcast(
                            ctx, id,
                            bcIntent,
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        val info = android.app.AlarmManager.AlarmClockInfo(whenMs, showPi)
                        am.setAlarmClock(info, bcPi)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("ERR", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }

        val channelSched = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
        channelSched.setMethodCallHandler { call, result ->
            when (call.method) {
                "saveSchedules" -> {
                    try {
                        val list = call.argument<List<Map<String, Any>>>("list")
                        val arr = org.json.JSONArray()
                        if (list != null) {
                            for (m in list) {
                                val o = org.json.JSONObject(m as Map<*, *>)
                                arr.put(o)
                            }
                        }
                        getSharedPreferences("sched_store", Context.MODE_PRIVATE)
                            .edit().putString("entries", arr.toString()).apply()
                        result.success(true)
                    } catch (e: Exception) { result.error("ERR", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ensure default notification channel exists
        NotificationUtils.ensureDefaultChannel(this)

        // Android 13+ notification runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationUtils.areNotificationsEnabled(this)) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQ_POST_NOTIFICATIONS
                )
            }
        }

        // NOTE: Per product decision, DO NOT auto-navigate to exact-alarm settings.
        // Users can open system Settings manually to enable Alarms & reminders for this app.

        
        // Start the foreground service to improve background delivery reliability (only if we can post notifications)
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || NotificationUtils.areNotificationsEnabled(this)) {
                val svc = Intent(this, ReminderForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
            }
        } catch (_: Exception) {}
    
        // One-off diagnostic exact alarm in ~60s (only if permission already granted)
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val can = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
            if (can) {
                val prefs = getSharedPreferences("diag_prefs", Context.MODE_PRIVATE)
                if (!prefs.getBoolean("diag_alarm_scheduled", false)) {
                    val t = System.currentTimeMillis() + 60_000L
                    ExactAlarmTestReceiver.scheduleOnce(this, t)
                    prefs.edit().putBoolean("diag_alarm_scheduled", true).apply()
                }
            }
        } catch (_: Exception) {}
    }
}
