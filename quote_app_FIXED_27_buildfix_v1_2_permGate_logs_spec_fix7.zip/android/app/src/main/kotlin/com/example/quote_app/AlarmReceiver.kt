package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import androidx.work.*

class AlarmReceiver : BroadcastReceiver() {
  private fun cancelWmForRun(ctx: Context, uid: String, runKey: String) {
    try { androidx.work.WorkManager.getInstance(ctx).cancelUniqueWork("fb_next_${'$'}uid_${'$'}runKey") } catch (_: Exception) {}
    try { androidx.work.WorkManager.getInstance(ctx).cancelUniqueWork("wm_run_${'$'}uid_${'$'}runKey") } catch (_: Exception) {}
    try { androidx.work.WorkManager.getInstance(ctx).cancelUniqueWork("wm_after_am_${'$'}uid_${'$'}runKey") } catch (_: Exception) {}
  }
  private fun cancelWmFallback(ctx: Context, uid: String, runKey: String) {
    try {
      androidx.work.WorkManager.getInstance(ctx).cancelUniqueWork("fb_next_${'$'}uid_${'$'}runKey")
    } catch (_: Exception) {}
  }

  override fun onReceive(ctx: Context, intent: Intent) {
    val id = intent.getIntExtra("id", 0)
    val payload = intent.getStringExtra("payload") ?: "{}"
    val o = JSONObject(payload)
    val notify = o.optBoolean("notify", true)
    val uid = o.optString("task_uid", "")
    val runKey = o.optString("run_key", "")
    if (uid.isNotEmpty() && runKey.isNotEmpty()) cancelWmForRun(ctx, uid, runKey)
    if (!notify) return
    val title = o.optString("title", "提醒")
    val body  = o.optString("body",  "到点了")

    val notif = NotificationCompat.Builder(ctx, "quote_notify")
      .setSmallIcon(ctx.applicationInfo.icon)
      .setContentTitle(title)
      .setContentText(body)
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .build()
    NotificationManagerCompat.from(ctx).notify(id, notif)
    // Cancel fallback for this run to避免重复
    cancelWmForRun(ctx, uid, runKey)
    try {
      // 回执与续排：入队一个轻量 WM 任务（wm_after_am）
      val data = Data.Builder()
        .putString("job", "wm_after_am")
        .putString("task_uid", uid)
        .putString("run_key", runKey)
        .putString("q_uid", qUid)
        .build()
      val req = OneTimeWorkRequestBuilder<WmBridgeWorker>()
        .setInputData(data)
        .addTag("run:"+uid)
        .build()
      val uniq = "wm_after_am_${'$'}uid_${'$'}runKey"
      WorkManager.getInstance(ctx)
        .enqueueUniqueWork(uniq, ExistingWorkPolicy.REPLACE, req)
    } catch (_: Exception) {}
  }
}

