import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import '../services/nasa_api_service.dart';
import 'apod_detail_page.dart';
import 'nasa_media_detail_page.dart';
import 'mars_photo_detail_page.dart';
import 'epic_image_detail_page.dart';

/// The main page for exploring various NASA datasets including APOD,
/// Image and Video Library search, Mars rover photos, EPIC Earth
/// images and Earth imagery. A tab bar organizes these distinct
/// sections. Each tab lazily loads data and provides basic interactivity
/// such as refreshing or date selection.
class SpaceExplorerPage extends StatefulWidget {
  const SpaceExplorerPage({super.key});

  @override
  State<SpaceExplorerPage> createState() => _SpaceExplorerPageState();
}

class _SpaceExplorerPageState extends State<SpaceExplorerPage>
    with SingleTickerProviderStateMixin {
  // Use the provided NASA API key. Replace with your own key as needed.
  static const String _nasaApiKey =
      'yl0Zwzo2DiDT6BvM3ITCieFjuiGhhgjFvak56sRS';

  late final NasaApiService _service;
  late final TabController _tabController;

  // APOD state
  List<Apod> _apods = [];
  bool _loadingApod = true;
  String? _errorApod;

  // NASA Image search state
  final TextEditingController _searchController = TextEditingController();
  List<NasaMediaItem> _searchResults = [];
  bool _searchLoading = false;
  String? _errorSearch;

  // Mars rover photos state
  late DateTime _marsDate;
  List<MarsPhoto> _marsPhotos = [];
  bool _marsLoading = false;
  String? _errorMars;

  // EPIC Earth images state
  List<EpicImage> _epicImages = [];
  bool _epicLoading = false;
  String? _errorEpic;
  bool _epicLoaded = false;

  // Earth imagery state
  final TextEditingController _latController = TextEditingController();
  final TextEditingController _lonController = TextEditingController();
  DateTime? _earthDate;
  EarthImage? _earthImage;
  bool _earthLoading = false;
  String? _errorEarth;

  @override
  void initState() {
    super.initState();
    _service = NasaApiService(apiKey: _nasaApiKey);
    _tabController = TabController(length: 5, vsync: this);
    _marsDate = DateTime.now().subtract(const Duration(days: 1));
    _loadApods();
    _loadMarsPhotos();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _latController.dispose();
    _lonController.dispose();
    super.dispose();
  }

  /// Formats a [DateTime] into a yyyy-MM-dd string for display.
  String _formatDateDisplay(DateTime date) {
    final y = date.year.toString().padLeft(4, '0');
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  /// Loads the Astronomy Picture of the Day entries for the last 30 days.
  Future<void> _loadApods() async {
    setState(() {
      _loadingApod = true;
      _errorApod = null;
    });
    try {
      final now = DateTime.now();
      final start = now.subtract(const Duration(days: 29));
      final results = await _service.fetchApods(startDate: start, endDate: now);
      results.sort((a, b) => b.date.compareTo(a.date));
      if (mounted) {
        setState(() {
          _apods = results;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorApod = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _loadingApod = false;
        });
      }
    }
  }

  /// Performs a search against the NASA Image and Video Library.
  Future<void> _performMediaSearch(String query) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) {
      setState(() {
        _searchResults = [];
        _errorSearch = null;
      });
      return;
    }
    setState(() {
      _searchLoading = true;
      _errorSearch = null;
    });
    try {
      final results = await _service.searchMedia(query: trimmed, mediaType: 'image', page: 1);
      if (mounted) {
        setState(() {
          _searchResults = results;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorSearch = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _searchLoading = false;
        });
      }
    }
  }

  /// Loads Mars rover photos for the current [_marsDate].
  Future<void> _loadMarsPhotos() async {
    setState(() {
      _marsLoading = true;
      _errorMars = null;
    });
    try {
      final results = await _service.fetchMarsPhotos(rover: 'curiosity', earthDate: _marsDate);
      if (mounted) {
        setState(() {
          _marsPhotos = results;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMars = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _marsLoading = false;
        });
      }
    }
  }

  /// Fetches EPIC Earth images if they haven't been loaded yet.
  Future<void> _fetchEpicImages() async {
    if (_epicLoaded) return;
    setState(() {
      _epicLoading = true;
      _errorEpic = null;
    });
    try {
      final results = await _service.fetchEpicImages(natural: true);
      if (mounted) {
        setState(() {
          _epicImages = results;
          _epicLoaded = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorEpic = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _epicLoading = false;
        });
      }
    }
  }

  /// Fetches the Earth imagery for the provided latitude, longitude and
  /// optional date. Shows an error message if the coordinates are
  /// invalid.
  Future<void> _fetchEarthImage() async {
    final latStr = _latController.text.trim();
    final lonStr = _lonController.text.trim();
    final double? lat = double.tryParse(latStr);
    final double? lon = double.tryParse(lonStr);
    if (lat == null || lon == null) {
      setState(() {
        _errorEarth = '请输入有效的经纬度';
      });
      return;
    }
    setState(() {
      _earthLoading = true;
      _errorEarth = null;
    });
    try {
      final result = await _service.fetchEarthImagery(lat: lat, lon: lon, date: _earthDate);
      if (mounted) {
        setState(() {
          _earthImage = result;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorEarth = e.toString();
          _earthImage = null;
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _earthLoading = false;
        });
      }
    }
  }

  /// Prompts the user to pick a new Mars Earth date.
  Future<void> _pickMarsDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _marsDate,
      firstDate: DateTime(2012, 8, 6), // Curiosity landing date
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _marsDate) {
      setState(() {
        _marsDate = picked;
      });
      _loadMarsPhotos();
    }
  }

  /// Prompts the user to pick a date for Earth imagery. The selected
  /// date is stored in [_earthDate].
  Future<void> _pickEarthDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _earthDate ?? DateTime.now(),
      firstDate: DateTime(2000, 1, 1),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _earthDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Trigger EPIC load when the EPIC tab is selected.
    if (_tabController.index == 3 && !_epicLoaded && !_epicLoading) {
      // Delay fetch to next frame to avoid triggering setState during
      // build.
      WidgetsBinding.instance.addPostFrameCallback((_) => _fetchEpicImages());
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('看宇宙', style: TextStyle(color: Colors.black87)),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: Colors.blueAccent,
          labelColor: Colors.blueAccent,
          unselectedLabelColor: Colors.black54,
          tabs: const [
            Tab(text: '每日APOD'),
            Tab(text: '图像搜索'),
            Tab(text: '火星照片'),
            Tab(text: 'EPIC地球'),
            Tab(text: '地球影像'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildApodTab(),
          _buildSearchTab(),
          _buildMarsTab(),
          _buildEpicTab(),
          _buildEarthTab(),
        ],
      ),
    );
  }

  /// Builds the APOD tab. Displays a list of recent astronomy pictures.
  Widget _buildApodTab() {
    if (_loadingApod) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorApod != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '加载天文图失败\n$_errorApod',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _loadApods,
                child: const Text('重试'),
              ),
            ],
          ),
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _loadApods,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: _apods.length,
        separatorBuilder: (context, index) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final apod = _apods[index];
          final bool isImage = apod.mediaType == 'image';
          return ListTile(
            leading: isImage
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      apod.url,
                      width: 64,
                      height: 64,
                      fit: BoxFit.cover,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return const SizedBox(
                          width: 64,
                          height: 64,
                          child: Center(
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return const SizedBox(
                          width: 64,
                          height: 64,
                          child: Center(child: Icon(Icons.broken_image)),
                        );
                      },
                    ),
                  )
                : const Icon(Icons.videocam_outlined, size: 32),
            title: Text(apod.title),
            subtitle: Text(apod.date),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (_) => ApodDetailPage(apod: apod),
                ),
              );
            },
          );
        },
      ),
    );
  }

  /// Builds the NASA Image search tab. Provides a search field and
  /// displays results from the media library.
  Widget _buildSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: '搜索 NASA 图像',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        setState(() {
                          _searchResults = [];
                          _errorSearch = null;
                        });
                      },
                    )
                  : null,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onSubmitted: _performMediaSearch,
          ),
        ),
        Expanded(
          child: _searchLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorSearch != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '搜索失败\n$_errorSearch',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 16),
                            ),
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: () =>
                                  _performMediaSearch(_searchController.text),
                              child: const Text('重试'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : _searchResults.isEmpty
                      ? const Center(
                          child: Text('请输入关键字进行搜索'),
                        )
                      : ListView.separated(
                          itemCount: _searchResults.length,
                          separatorBuilder: (context, index) =>
                              const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final item = _searchResults[index];
                            return ListTile(
                              leading: item.thumbUrl.isNotEmpty
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: Image.network(
                                        item.thumbUrl,
                                        width: 64,
                                        height: 64,
                                        fit: BoxFit.cover,
                                        loadingBuilder:
                                            (context, child, loadingProgress) {
                                          if (loadingProgress == null) return child;
                                          return const SizedBox(
                                            width: 64,
                                            height: 64,
                                            child: Center(
                                              child: CircularProgressIndicator(
                                                  strokeWidth: 2),
                                            ),
                                          );
                                        },
                                        errorBuilder:
                                            (context, error, stackTrace) {
                                          return const SizedBox(
                                            width: 64,
                                            height: 64,
                                            child: Center(
                                                child: Icon(Icons.broken_image)),
                                          );
                                        },
                                      ),
                                    )
                                  : const Icon(Icons.image_outlined, size: 32),
                              title: Text(item.title),
                              subtitle: Text(item.date),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () {
                                Navigator.of(context).push(
                                  CupertinoPageRoute(
                                    builder: (_) =>
                                        NasaMediaDetailPage(item: item),
                                  ),
                                );
                              },
                            );
                          },
                        ),
        ),
      ],
    );
  }

  /// Builds the Mars rover photos tab. Allows date selection and shows
  /// photos taken on the selected day.
  Widget _buildMarsTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Text('日期: ${_formatDateDisplay(_marsDate)}'),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.calendar_today),
                onPressed: _pickMarsDate,
              ),
            ],
          ),
        ),
        Expanded(
          child: _marsLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMars != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '加载火星照片失败\n$_errorMars',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 16),
                            ),
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: _loadMarsPhotos,
                              child: const Text('重试'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : _marsPhotos.isEmpty
                      ? const Center(
                          child: Text('该日期没有火星照片'),
                        )
                      : ListView.separated(
                          itemCount: _marsPhotos.length,
                          separatorBuilder: (context, index) =>
                              const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final photo = _marsPhotos[index];
                            return ListTile(
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  photo.imageUrl,
                                  width: 64,
                                  height: 64,
                                  fit: BoxFit.cover,
                                  loadingBuilder:
                                      (context, child, loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return const SizedBox(
                                      width: 64,
                                      height: 64,
                                      child: Center(
                                        child: CircularProgressIndicator(
                                            strokeWidth: 2),
                                      ),
                                    );
                                  },
                                  errorBuilder:
                                      (context, error, stackTrace) {
                                    return const SizedBox(
                                      width: 64,
                                      height: 64,
                                      child: Center(
                                          child: Icon(Icons.broken_image)),
                                    );
                                  },
                                ),
                              ),
                              title: Text(photo.camera),
                              subtitle: Text('${photo.rover} · ${photo.earthDate}'),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () {
                                Navigator.of(context).push(
                                  CupertinoPageRoute(
                                    builder: (_) =>
                                        MarsPhotoDetailPage(photo: photo),
                                  ),
                                );
                              },
                            );
                          },
                        ),
        ),
      ],
    );
  }

  /// Builds the EPIC Earth images tab. Displays a list of images with
  /// date and caption. Supports pull-to-refresh.
  Widget _buildEpicTab() {
    if (_epicLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorEpic != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '加载 EPIC 图像失败\n$_errorEpic',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _epicLoaded = false;
                  });
                  _fetchEpicImages();
                },
                child: const Text('重试'),
              ),
            ],
          ),
        ),
      );
    }
    if (_epicImages.isEmpty) {
      return const Center(child: Text('没有 EPIC 图像')); // This should rarely happen after load.
    }
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
          _epicLoaded = false;
        });
        await _fetchEpicImages();
      },
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: _epicImages.length,
        separatorBuilder: (context, index) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final epi = _epicImages[index];
          return ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                epi.url,
                width: 64,
                height: 64,
                fit: BoxFit.cover,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return const SizedBox(
                    width: 64,
                    height: 64,
                    child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                  );
                },
                errorBuilder: (context, error, stackTrace) {
                  return const SizedBox(
                    width: 64,
                    height: 64,
                    child: Center(child: Icon(Icons.broken_image)),
                  );
                },
              ),
            ),
            title: Text(epi.date),
            subtitle: Text(epi.caption.isNotEmpty ? epi.caption : '无描述'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (_) => EpicImageDetailPage(image: epi),
                ),
              );
            },
          );
        },
      ),
    );
  }

  /// Builds the Earth imagery tab. Allows entering coordinates and date
  /// to retrieve a satellite image. Displays the returned image and
  /// metadata.
  Widget _buildEarthTab() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '获取地球卫星影像',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _latController,
              keyboardType: TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: const InputDecoration(
                labelText: '纬度 (lat)',
                hintText: '例如 23.3',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _lonController,
              keyboardType: TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: const InputDecoration(
                labelText: '经度 (lon)',
                hintText: '例如 120.9',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    _earthDate != null
                        ? '日期: ${_formatDateDisplay(_earthDate!)}'
                        : '日期: 最近',
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: _pickEarthDate,
                ),
              ],
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _fetchEarthImage,
              child: const Text('获取图片'),
            ),
            const SizedBox(height: 16),
            if (_earthLoading)
              const Center(child: CircularProgressIndicator())
            else if (_errorEarth != null)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  _errorEarth!,
                  style: const TextStyle(color: Colors.red),
                ),
              )
            else if (_earthImage != null)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.network(
                    _earthImage!.url,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return SizedBox(
                        height: 200,
                        child: Center(
                          child: CircularProgressIndicator(
                            value: loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded /
                                    (loadingProgress.expectedTotalBytes ?? 1)
                                : null,
                          ),
                        ),
                      );
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return const SizedBox(
                        height: 200,
                        child: Center(child: Icon(Icons.broken_image)),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  Text('日期: ${_earthImage!.date}'),
                  Text('ID: ${_earthImage!.id}'),
                ],
              ),
          ],
        ),
      ),
    );
  }
}