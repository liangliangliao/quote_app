import 'dart:convert';
import 'dart:async';

import 'package:http/http.dart' as http;
import '../data/dao.dart';

/// Lightweight translation helper.
///
/// Uses LibreTranslate-compatible endpoints. For stability, this class
/// tries multiple public endpoints. For production apps, it is strongly
/// recommended to deploy your own LibreTranslate instance or proxy.
class TranslationService {
  TranslationService({List<String>? endpoints})
      : _endpoints = endpoints ??
            const <String>[
              // Public endpoints (best effort). You can override by passing
              // your own endpoints when constructing this service.
              'https://libretranslate.com/translate',
              'https://translate.argosopentech.com/translate',
            ];

  final List<String> _endpoints;

  // DeepSeek configuration loaded lazily from the configs table.  When
  // performing translations, the service will attempt to use DeepSeek if a
  // valid API key is configured.  These fields cache the loaded key/model
  // to avoid repeatedly querying the database on every translation call.
  String? _deepseekKey;
  String? _deepseekModel;
  bool _deepseekLoaded = false;

  /// Ensure the DeepSeek API key and model are loaded from the database.
  Future<void> _ensureDeepseek() async {
    if (_deepseekLoaded) return;
    try {
      final cfg = await ConfigDao().getOne();
      final key = cfg['deepseek_key'] ?? '';
      final model = cfg['deepseek_model'] ?? 'deepseek-chat';
      _deepseekKey = key.toString().trim();
      final m = model.toString().trim();
      _deepseekModel = m.isEmpty ? 'deepseek-chat' : m;
    } catch (_) {
      _deepseekKey = '';
      _deepseekModel = 'deepseek-chat';
    }
    _deepseekLoaded = true;
  }

  /// Attempt to translate [text] into the target language using the
  /// DeepSeek API.  Throws on error or when no key is configured.  If
  /// translation fails, the caller should fall back to other providers.
  Future<String> _translateViaDeepseek({required String text, required String target}) async {
    await _ensureDeepseek();
    final key = _deepseekKey;
    final model = _deepseekModel ?? 'deepseek-chat';
    if (key == null || key.isEmpty) {
      throw Exception('DeepSeek key is not configured');
    }
    // Map UI language codes to language names expected by DeepSeek.
    String langName;
    switch (target) {
      case 'zh':
        langName = 'Chinese';
        break;
      case 'ja':
        langName = 'Japanese';
        break;
      case 'ko':
        langName = 'Korean';
        break;
      case 'es':
        langName = 'Spanish';
        break;
      case 'fr':
        langName = 'French';
        break;
      case 'de':
        langName = 'German';
        break;
      case 'ru':
        langName = 'Russian';
        break;
      case 'ar':
        langName = 'Arabic';
        break;
      case 'pt':
        langName = 'Portuguese';
        break;
      default:
        langName = target;
    }
    final prompt =
        'Translate the following text into $langName. Just return the translation without explanation: $text';
    final body = jsonEncode({
      'model': model,
      'messages': [
        {
          'role': 'user',
          'content': prompt,
        },
      ],
      'stream': false,
    });
    final res = await http
        .post(
          Uri.parse('https://api.deepseek.com/chat/completions'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $key',
          },
          body: body,
        )
        .timeout(const Duration(seconds: 30));
    if (res.statusCode != 200) {
      throw Exception('DeepSeek error: ${res.statusCode}');
    }
    final data = jsonDecode(res.body);
    if (data is Map<String, dynamic>) {
      final choices = data['choices'];
      if (choices is List && choices.isNotEmpty) {
        final message = choices.first['message'];
        if (message is Map<String, dynamic>) {
          final content = (message['content'] ?? '').toString();
          return content.trim();
        }
      }
    }
    return text;
  }

  /// MyMemory is a free, no-key translation endpoint.
  ///
  /// Public LibreTranslate instances may be rate-limited or intermittently
  /// unreachable. We try MyMemory first for better real-world reliability.
  static const String _myMemoryEndpoint = 'https://api.mymemory.translated.net/get';

  String _toMyMemoryLangCode(String code) {
    // UI uses: zh, en, ja, ko, es, fr, de, ru, ar, pt
    if (code == 'zh') return 'zh-CN';
    if (code == 'pt') return 'pt-PT';
    return code;
  }

  /// In-memory cache: key = "<target>|<text>"
  final Map<String, String> _cache = <String, String>{};

  void clearCache() => _cache.clear();

  /// Translate a single [text] from English to [target].
  /// Returns the original [text] if translation fails.
  Future<String> translateOne({
    required String text,
    required String target,
  }) async {
    if (target == 'en' || text.trim().isEmpty) return text;
    final key = '$target|$text';
    final cached = _cache[key];
    if (cached != null) return cached;

    // Try DeepSeek translation first if configured.
    try {
      final ds = await _translateViaDeepseek(text: text, target: target);
      if (ds.trim().isNotEmpty && ds.trim() != text.trim()) {
        _cache[key] = ds;
        return ds;
      }
    } catch (_) {
      // Ignore DeepSeek errors and fall back to other providers.
    }

    // 1) Try MyMemory (GET) first.
    try {
      final translated = await _translateViaMyMemory(text: text, target: target);
      if (translated.trim().isNotEmpty && translated.trim() != text.trim()) {
        _cache[key] = translated;
        return translated;
      }
    } catch (_) {
      // fallthrough
    }

    // 2) Fallback to LibreTranslate instances in order.
    for (final endpoint in _endpoints) {
      try {
        final res = await http
            .post(
              Uri.parse(endpoint),
              headers: const {'Content-Type': 'application/json'},
              body: jsonEncode({
                'q': text,
                'source': 'en',
                'target': target,
                'format': 'text',
              }),
            )
            .timeout(const Duration(seconds: 18));
        if (res.statusCode != 200) continue;
        final data = jsonDecode(res.body);
        final translated = (data is Map<String, dynamic>)
            ? (data['translatedText'] ?? '').toString()
            : '';
        if (translated.trim().isEmpty) continue;
        _cache[key] = translated;
        return translated;
      } catch (_) {
        // try next endpoint
      }
    }

    return text;
  }

  Future<String> _translateViaMyMemory({
    required String text,
    required String target,
  }) async {
    if (target == 'en' || text.trim().isEmpty) return text;
    final targetCode = _toMyMemoryLangCode(target);
    final uri = Uri.parse(_myMemoryEndpoint).replace(queryParameters: {
      'q': text,
      'langpair': 'en|$targetCode',
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return text;
    final data = jsonDecode(res.body);
    if (data is Map<String, dynamic>) {
      final responseData = data['responseData'];
      if (responseData is Map<String, dynamic>) {
        final t = (responseData['translatedText'] ?? '').toString();
        return t.trim().isEmpty ? text : t;
      }
    }
    return text;
  }

  /// Backward-compatible wrapper used by UI code.
  ///
  /// The Space module calls `translateTexts(texts, targetLang: ...)`.
  /// We keep this wrapper so the rest of the code can stay clean.
  Future<List<String>> translateTexts(
    List<String> texts, {
    required String targetLang,
  }) async {
    return translateMany(texts: texts, target: targetLang);
  }

  /// Best-effort batch translation.
  ///
  /// To avoid dozens of network calls, we join texts with a delimiter
  /// and translate once. If parsing fails, we fall back to per-item
  /// translation.
  Future<List<String>> translateMany({
    required List<String> texts,
    required String target,
  }) async {
    if (target == 'en' || texts.isEmpty) return texts;
    // Use cache as much as possible.
    final out = List<String>.filled(texts.length, '');
    final toTranslate = <int, String>{};
    for (var i = 0; i < texts.length; i++) {
      final t = texts[i];
      if (t.trim().isEmpty) {
        out[i] = t;
        continue;
      }
      final cacheKey = '$target|$t';
      final cached = _cache[cacheKey];
      if (cached != null) {
        out[i] = cached;
      } else {
        toTranslate[i] = t;
      }
    }
    if (toTranslate.isEmpty) return out;
    // For DeepSeek-enabled translation, translate each item individually via
    // translateOne.  This ensures DeepSeek is used when configured.  If
    // DeepSeek is not configured or fails, translateOne falls back to
    // MyMemory/LibreTranslate.
    for (final entry in toTranslate.entries) {
      out[entry.key] = await translateOne(text: entry.value, target: target);
    }
    return out;
  }
}
