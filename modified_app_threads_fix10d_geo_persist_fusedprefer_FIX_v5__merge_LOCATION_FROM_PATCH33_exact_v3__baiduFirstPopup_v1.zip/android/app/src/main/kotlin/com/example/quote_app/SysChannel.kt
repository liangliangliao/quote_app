
package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.example.quote_app.data.DbRepo
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import com.google.android.gms.location.*

object SysChannel {
  private const val CHANNEL = "com.example.quote_app/sys"

  fun register(engine: FlutterEngine, appContext: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
      when (call.method) {
        "getBaiduLocationOnce" -> {
          try {
            val ak = try { readBaiduAk(appContext) } catch (_: Throwable) { "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" }
            val loc = obtainBaiduLocation(appContext, ak, 30.0, 10_000L)
            if (loc != null) {
              val map = mapOf("lat" to loc.latitude, "lng" to loc.longitude, "acc" to loc.accuracy, "provider" to (loc.provider ?: "baidu"))
              logWithTime(appContext, "【LocationService】【定位】Baidu SDK 成功 acc=${loc.accuracy}")
              result.success(map)
            } else {
              logWithTime(appContext, "【LocationService】【定位】Baidu SDK 失败")
              result.error("NO_LOC", "baidu failed", null)
            }
          } catch (t: Throwable) {
            logWithTime(appContext, "【LocationService】【定位】Baidu SDK 异常：" + (t.message ?: "unknown"))
            result.error("EX", t.message, null)
          }
        }
        "getSystemLocationOnce" -> {
          try {
            var loc: Location? = run { logWithTime(appContext, "【LocationService】【定位】优先使用 Fused 高精度流"); obtainFusedHighAcc(appContext, 30.0, 12_000L) }
            if (loc == null) loc = obtainHighAccuracyLocation(appContext, 30.0, 10_000L)
            if (loc == null) { result.error("NO_LOC", "system failed", null); return@setMethodCallHandler }
            val map = mapOf("lat" to loc.latitude, "lng" to loc.longitude, "acc" to loc.accuracy, "provider" to (loc.provider ?: "system"))
            logWithTime(appContext, "【LocationService】【定位】System 成功 acc=${loc.accuracy}")
            result.success(map)
          } catch (t: Throwable) {
            logWithTime(appContext, "【LocationService】【定位】System 异常：" + (t.message ?: "unknown"))
            result.error("EX", t.message, null)
          }
        }
        else -> result.notImplemented()
      }
    }
  }

  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) { try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {} }
  }

  private fun readBaiduAk(ctx: Context): String {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx)
      val path = cc?.dbPath
      if (path.isNullOrEmpty()) return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try {
        var v: String? = null
        try {
          val c = db.rawQuery("SELECT baidu_ak FROM configs LIMIT 1", null)
          c.use { cursor -> if (cursor.moveToFirst()) v = cursor.getString(0) }
        } catch (_: Throwable) { /* 表/列不存在时忽略 */ }
        if (v==null || v!!.trim().isEmpty()) "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" else v!!.trim()
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) {
      "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
    }
  }

  private fun obtainFusedHighAcc(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val client = LocationServices.getFusedLocationProviderClient(ctx)
      val latch = java.util.concurrent.CountDownLatch(1)
      var best: Location? = null
      val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
        .setWaitForAccurateLocation(true).setMaxUpdates(6).build()
      val cb = object: LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
          for (l in result.locations) { if (best == null || l.accuracy < best!!.accuracy) best = l }
          if (best != null && best!!.accuracy <= targetAccMeters) { try { latch.countDown() } catch (_: Throwable) {} }
        }
      }
      try { client.requestLocationUpdates(req, cb, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { client.removeLocationUpdates(cb) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) { null }
  }

  private fun obtainHighAccuracyLocation(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val latch = java.util.concurrent.CountDownLatch(1)
      var best: Location? = null
      val listener = object: LocationListener {
        override fun onLocationChanged(loc: Location) {
          if (best == null || loc.accuracy < best!!.accuracy) best = loc
          if (best != null && best!!.accuracy <= targetAccMeters) { try { latch.countDown() } catch (_: Throwable) {} }
        }
        @Deprecated("deprecated") override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
      }
      try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) { null }
  }

  private fun obtainBaiduLocation(ctx: Context, ak: String, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val clazz = Class.forName("com.baidu.location.LocationClient")
      val optionClazz = Class.forName("com.baidu.location.LocationClientOption")
      val locClient = clazz.getConstructor(Context::class.java).newInstance(ctx)
      val opt = optionClazz.getConstructor().newInstance()
      try { optionClazz.getMethod("setLocationCacheEnable", java.lang.Boolean.TYPE).invoke(opt, false) } catch (_: Throwable) {}
      try { optionClazz.getMethod("setOnceLocation", java.lang.Boolean.TYPE).invoke(opt, true) } catch (_: Throwable) {}
      optionClazz.getMethod("setOpenGps", Boolean::class.javaPrimitiveType).invoke(opt, true)
      optionClazz.getMethod("setCoorType", String::class.java).invoke(opt, "bd09ll")
      optionClazz.getMethod("setScanSpan", Int::class.javaPrimitiveType).invoke(opt, 0)
      optionClazz.getMethod("setIsNeedAddress", Boolean::class.javaPrimitiveType).invoke(opt, false)
      clazz.getMethod("setLocOption", optionClazz).invoke(locClient, opt)

      val listenerClazz = Class.forName("com.baidu.location.BDAbstractLocationListener")
      val latch = java.util.concurrent.CountDownLatch(1)
      var best: Location? = null

      val proxy = java.lang.reflect.Proxy.newProxyInstance(listenerClazz.classLoader, arrayOf(listenerClazz)) { _, method, args ->
        if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
          val bdLoc = args[0]
          try {
            val la = bdLoc.javaClass.getMethod("getLatitude").invoke(bdLoc) as Double
            val lo = bdLoc.javaClass.getMethod("getLongitude").invoke(bdLoc) as Double
            val acc = (bdLoc.javaClass.getMethod("getRadius").invoke(bdLoc) as Number).toFloat()
            val l = Location("baidu"); l.latitude = la; l.longitude = lo; l.accuracy = acc
            if (best == null || l.accuracy < best!!.accuracy) best = l
            if (best != null && best!!.accuracy <= targetAccMeters) { try { latch.countDown() } catch (_: Throwable) {} }
          } catch (_: Throwable) {}
        }
        null
      }
      clazz.getMethod("registerLocationListener", listenerClazz).invoke(locClient, proxy)
      clazz.getMethod("start").invoke(locClient)
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { clazz.getMethod("stop").invoke(locClient) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) { null }
  }
}
