
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/debug_logger.dart';
import '../services/notification_service.dart';
import '../services/scheduler_service.dart';
import '../services/self_check_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();

    try { await DLog.i('WM', '调度任务=? ' + task); } catch (_) {}

    final job = (inputData?['job'] ?? '').toString();
    final uid = (inputData?['task_uid'] ?? '').toString();
    final runKey = (inputData?['run_key'] ?? '').toString();
    final chan = (inputData?['chan'] ?? 'normal').toString();
    final attempt = int.tryParse((inputData?['attempt'] ?? '1').toString()) ?? 1;

    try { await NotificationService.init(); } catch (_) {}

    if (job == 'self_check') {
      await SelfCheckService.run();
      return Future.value(true);
    }

    if (job == 'wm_run' && uid.isNotEmpty) {
      await SchedulerService.wmRunTask(uid, runKey.isEmpty ? null : runKey, chan: chan, attempt: attempt);
      return Future.value(true);
    }

    try { await SchedulerService.callback(); } catch (_) {}
    return Future.value(true);
  });
}
