
import 'package:sqflite/sqflite.dart';
import 'db.dart';

/// 统一落库的补丁迁移，保证表存在（幂等执行）。
class PatchMigration20251001 {
  static Future<void> ensure() async {
    final db = await AppDatabase.instance();
    // 失败统计表
    await db.execute('''
      CREATE TABLE IF NOT EXISTS notify_failures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT,
        run_key TEXT,
        source TEXT,               -- AM | WM | MANUAL
        status TEXT,               -- 失败 | 成功
        fail_date TEXT,            -- 2025-09-25
        created_at INTEGER
      )
    ''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_nf_task_run ON notify_failures(task_uid, run_key)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_nf_date_status ON notify_failures(fail_date, status)');
    // 自检频率配置表（通用 key/value）
    await db.execute('''
      CREATE TABLE IF NOT EXISTS notify_params (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        k TEXT UNIQUE,
        v TEXT
      )
    ''');
    // 幂等已发送表：同一任务 + 同一 run_key 只能发送一次
    await db.execute('''
      CREATE TABLE IF NOT EXISTS notify_once (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT,
        run_key TEXT,
        sent_at INTEGER,
        UNIQUE(task_uid, run_key) ON CONFLICT IGNORE
      )
    ''');
  }
}

class NotifyParamsDao {
  static const String _kSelfCheckFreq = 'selfcheck_freq_minutes';

  /// 读取分钟数，默认 15（并对 WorkManager 的最小 15 分钟做下限保护）
  static Future<int> getSelfCheckFrequencyMinutes() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_params', where: 'k=?', whereArgs: [_kSelfCheckFreq], limit: 1);
    if (rows.isEmpty) return 15;
    final v = int.tryParse((rows.first['v'] ?? '15').toString()) ?? 15;
    return v < 15 ? 15 : v;
  }

  static Future<void> setSelfCheckFrequencyMinutes(int minutes) async {
    final db = await AppDatabase.instance();
    await db.insert('notify_params', {'k': _kSelfCheckFreq, 'v': minutes.toString()},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

class NotifyFailureDao {
  static Future<void> insertFailure({
    required String taskUid,
    required String runKey,
    required String source, // AM | WM | MANUAL
  }) async {
    final db = await AppDatabase.instance();
    final date = DateTime.now();
    final dateStr = "${date.year.toString().padLeft(4,'0')}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}";
    await db.insert('notify_failures', {
      'task_uid': taskUid,
      'run_key': runKey,
      'source': source,
      'status': '失败',
      'fail_date': dateStr,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  static Future<void> markLatestSuccess({
    required String taskUid,
    required String runKey,
  }) async {
    final db = await AppDatabase.instance();
    await db.rawUpdate(
      '''
      UPDATE notify_failures
      SET status='成功'
      WHERE id = (
        SELECT id FROM notify_failures
        WHERE task_uid = ? AND run_key = ?
        ORDER BY id DESC
        LIMIT 1
      )
      ''',
      [taskUid, runKey],
    );
  }

  /// 取当天失败的所有记录（可能含重复 taskUid/runKey，调用端自行去重）
  static Future<List<Map<String, dynamic>>> failuresToday() async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final dateStr = "${now.year.toString().padLeft(4,'0')}-${now.month.toString().padLeft(2,'0')}-${now.day.toString().padLeft(2,'0')}";
    return await db.query('notify_failures', where: 'fail_date=? AND status=?', whereArgs: [dateStr, '失败']);
  }
}

class NotifyOnceDao {
  /// 返回 true 表示可以发送（首次），false 表示已发送过。
  static Future<bool> ensureOnce(String taskUid, String runKey) async {
    final db = await AppDatabase.instance();
    final cnt = await db.insert('notify_once', {
      'task_uid': taskUid,
      'run_key': runKey,
      'sent_at': DateTime.now().millisecondsSinceEpoch,
    });
    return cnt > 0;
  }
}
