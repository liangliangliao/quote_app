package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.provider.Settings
import android.app.NotificationManager
import androidx.core.app.AlarmManagerCompat
import androidx.work.WorkManager

class MainActivity: FlutterActivity() {

    private val sysChannel = "com.example.quote_app/sys"
    private val schChannel = "native.scheduler"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, sysChannel).setMethodCallHandler { call, result ->
            when (call.method) {
                "areNotificationsEnabled" -> {
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    result.success(nm.areNotificationsEnabled())
                }
                "openNotificationSettings" -> {
                    val intent = Intent()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        intent.action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                        intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    } else {
                        intent.action = "android.settings.APP_NOTIFICATION_SETTINGS"
                        intent.putExtra("app_package", packageName)
                        intent.putExtra("app_uid", applicationInfo.uid)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    result.success(null)
                }
                "hasExactAlarmPermission" -> {
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        am.canScheduleExactAlarms()
                    } else true
                    result.success(ok)
                }
                "requestExactAlarmPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    }
                    result.success(null)
                }
                else if (call.method == "cancelFallbackWM") {
                    val uid = call.argument<String>("uid") ?: ""
                    val runKey = call.argument<String>("runKey") ?: ""
                    if (uid.isNotEmpty() && runKey.isNotEmpty()) {
                        val base = "wm_run_${'$'}uid_${'$'}runKey"
                        try { WorkManager.getInstance(this).cancelUniqueWork(base + "_FB_1") } catch (_: Exception) {}
                        try { WorkManager.getInstance(this).cancelUniqueWork(base + "_FB_2") } catch (_: Exception) {}
                    }
                    result.success(null)
                } else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, schChannel).setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleExactAt" -> {
                    val id = call.argument<Int>("id") ?: 0
                    val epochMs = call.argument<Long>("epochMs") ?: 0L
                    val payload = call.argument<String>("payload") ?: "{}"
                    val intent = Intent(this, AlarmReceiver::class.java).apply {
                        action = "com.example.quote_app.ALARM"
                        putExtra("payload", payload)
                    }
                    val pi = PendingIntent.getBroadcast(this, id, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        AlarmManagerCompat.setExactAndAllowWhileIdle(am, AlarmManager.RTC_WAKEUP, epochMs, pi)
                    } else {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
                    }
                    result.success(true)
                }
                "cancel" -> {
                    val id = call.argument<Int>("id") ?: 0
                    val intent = Intent(this, AlarmReceiver::class.java).apply {
                        action = "com.example.quote_app.ALARM"
                    }
                    val pi = PendingIntent.getBroadcast(this, id, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    am.cancel(pi)
                    result.success(null)
                }
                else if (call.method == "cancelFallbackWM") {
                    val uid = call.argument<String>("uid") ?: ""
                    val runKey = call.argument<String>("runKey") ?: ""
                    if (uid.isNotEmpty() && runKey.isNotEmpty()) {
                        val base = "wm_run_${'$'}uid_${'$'}runKey"
                        try { WorkManager.getInstance(this).cancelUniqueWork(base + "_FB_1") } catch (_: Exception) {}
                        try { WorkManager.getInstance(this).cancelUniqueWork(base + "_FB_2") } catch (_: Exception) {}
                    }
                    result.success(null)
                } else -> result.notImplemented()
            }
        }
    }
}