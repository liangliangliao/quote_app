
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PermHelper {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  // ---- Exact Alarm (Android 12+) ----
  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openExactAlarmSettings() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('requestExactAlarm');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  // ---- Battery optimization ----
  static Future<bool> isIgnoringBatteryOptimizations() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> requestIgnoreBatteryOptimizations() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('requestIgnoreBatteryOptimizations');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  // ---- Native fallback scheduling ----
  static Future<bool> scheduleNativeNotification({
    required int whenMs,
    required String title,
    required String body,
    required int nid,
    String? handshakeKey,
  }) async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('scheduleNativeNotification', {
        'whenMs': whenMs,
        'title': title,
        'body': body,
        'nid': nid,
        if (avatarPath != null) 'avatarPath': avatarPath,
        if (taskUid != null) 'taskUid': taskUid,
        if (quoteId != null) 'quoteId': quoteId,

        if (handshakeKey != null) 'handshakeKey': handshakeKey,
      });
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> cancelNativeNotification({
    required int nid,
    String? handshakeKey,
  }) async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('cancelNativeNotification', {
        'nid': nid,
        if (avatarPath != null) 'avatarPath': avatarPath,
        if (taskUid != null) 'taskUid': taskUid,
        if (quoteId != null) 'quoteId': quoteId,

        if (handshakeKey != null) 'handshakeKey': handshakeKey,
      });
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  // ---- Handshake helpers (strict if-else) ----
  static Future<void> saveHandshakeKey(int nid, String hkey) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('hkey_$nid', hkey);
    } catch (_) {}
  }

  static Future<String?> loadHandshakeKey(int nid) async {
    try {
      final sp = await SharedPreferences.getInstance();
      return sp.getString('hkey_$nid');
    } catch (_) { return null; }
  }
}
