package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONObject

class NotifyWorker(appContext: Context, params: WorkerParameters)
  : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val id = inputData.getInt("id", 0)
    val payload = inputData.getString("payload") ?: "{}"
    val o = JSONObject(payload)
    val title = o.optString("title", "提醒")
    val body  = o.optString("body",  "到点了")

    // Use the unified native notifier
    val ok = NotifyHelper.send(applicationContext, id, title, body, null)
    return if (ok) Result.success() else Result.failure()
  }
}
