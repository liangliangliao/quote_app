package com.example.quote_app   // ← 如你的包名不同，请改成你的包名

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    companion object {
        private const val CHANNEL = "quote.app/native"
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    // 系统通知是否开启
                    "isNotificationEnabled" -> {
                        val enabled = NotificationManagerCompat.from(this).areNotificationsEnabled()
                        result.success(enabled)
                    }

                    // 精准闹钟是否允许
                    "isExactAlarmAllowed" -> {
                        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        val allowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            am.canScheduleExactAlarms()
                        } else {
                            true
                        }
                        result.success(allowed)
                    }

                    // 打开精准闹钟授权页，并把本 App 任务移出最近任务（用户点系统返回不会回到 App）
                    "openExactAlarmSettings" -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            try {
                                startActivity(
                                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                        data = Uri.parse("package:$packageName")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                )
                            } catch (_: Throwable) { /* ignore */ }
                            BackCloser.finishAndRemoveTask(this)   // ★ 关键：用工具类关闭本 App
                        }
                        result.success(true)
                    }

                    else -> result.notImplemented()
                }
            }
    }
}