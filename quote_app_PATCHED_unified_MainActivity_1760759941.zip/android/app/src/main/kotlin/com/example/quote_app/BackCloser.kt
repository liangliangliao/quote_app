package com.example.quote_app

import android.app.Activity
import android.os.Build

object BackCloser {
    @JvmStatic
    fun finishAndRemoveTask(activity: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                activity.finishAndRemoveTask()
            } else {
                activity.finish()
            }
        } catch (_: Throwable) {
            activity.finish()
        }
    }
}