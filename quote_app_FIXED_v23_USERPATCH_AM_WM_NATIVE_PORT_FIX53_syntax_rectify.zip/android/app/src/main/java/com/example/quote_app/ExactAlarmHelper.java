package com.example.quote_app;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

public final class ExactAlarmHelper {
    private ExactAlarmHelper() {}

    /** Android 12(S)+ 判断是否拥有精准闹钟权限；低版本恒为 true */
    public static boolean hasExactAlarmPermission(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return true; // 尽量不阻塞
            return am.canScheduleExactAlarms();
        } catch (Throwable t) {
            // 出错时默认放行，避免 UI 卡死；原生日志交给上层打印
            return true;
        }
    }

    /** Android 12(S)+ 跳转系统设置申请精准闹钟；低版本直接返回 */
    public static void requestExactAlarmPermission(Activity activity) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            i.setData(android.net.Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(i);
        } catch (Throwable t) {
            // 某些厂商设备可能不支持该 Action，忽略即可，由 UI 引导用户手动前往设置
        }
    }
}
