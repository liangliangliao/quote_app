package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import androidx.work.WorkManager;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.wm.WmScheduler;
import com.example.quote_app.schedule.NextTriggerCalculator;

import org.json.JSONObject;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int id = intent != null ? intent.getIntExtra("id", 0) : 0;
        String payload = intent != null ? intent.getStringExtra("payload") : "{}";
        String uid = null;
        String runKey = "";

        try {
            DbRepository.log(app, uid==null?"":uid, "【原生】AM 触发 uid="+(uid==null?"":uid)+" run="+runKey);
            JSONObject obj = new JSONObject(payload == null ? "{}" : payload);
            uid = obj.optString("uid", null);
            runKey = obj.optString("runKey", "");
        } catch (Throwable ignore) {}

        if (TextUtils.isEmpty(uid)) {
            // 兜底：没有 uid 仍然发一个到点提醒
            String title = "提醒";
            String body = "到点了";
            try { NotifyHelper.send(context.getApplicationContext(), id, title, body, null); } catch (Throwable ignore) {}
            return;
        }

        final Context app = context.getApplicationContext();
        boolean entered = false;
        try {
            entered = DbRepository.runGuardBegin(app, uid, runKey, "am");
            if (!entered) return;

            boolean handled = Biz.run(app, uid);
            if (handled) {
                DbRepository.log(app, uid, "【原生】AM 发送成功 uid="+uid+" run="+runKey);
                // 成功：取消兜底WM
                DbRepository.markLatestSuccess(app, uid);
                long next = NextTriggerCalculator.compute(app, uid);
                if (next > 0) {
                    NativeSchedulerK.scheduleExactWmCompat(app, id, next, payload);
                    WmScheduler.schedulePair(app, next, uid, "ts_"+next);
                }
                try { WmScheduler.cancelFallback(app, uid, runKey); } catch (Throwable ignore) {}
            } else {
                DbRepository.log(app, uid, "【原生】AM 发送失败 uid="+uid+" run="+runKey);
                DbRepository.log(app, uid, "AM通道：业务未处理");
            }
        } catch (Throwable t) {
            DbRepository.log(app, uid, "AM异常: " + (t.getMessage()==null?"未知错误":t.getMessage()));
        } finally {
            try { DbRepository.runGuardEnd(app, uid, runKey, "am"); } catch (Throwable ignore) {}
        }
    }
}
