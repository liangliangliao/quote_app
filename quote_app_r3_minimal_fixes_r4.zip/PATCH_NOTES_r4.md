# Patch Notes (r4)

- Align with requirement: **only after the Home page is visible** do we present the system notification permission.
- Removed a leftover fallback that would jump to system Notification Settings during startup.
- Keep the r3 behavior: the app first renders `RootShell`/`HomePage`, then after the **first frame** we show our **custom prompt**; only when the user taps **允许** do we call `NotificationService.request()` to trigger the **system** dialog.

## main.dart (aggregate diff vs r2)
--- a/lib/main.dart
+++ b/lib/main.dart
@@ -90,26 +90,51 @@
 }
 
 class _GateKeeperState extends State<GateKeeper> {
+  bool _askedNotiOnce = false;
+
+  void _scheduleAskNotiAfterFirstFrame() {
+    if (_askedNotiOnce) return;
+    _askedNotiOnce = true;
+    WidgetsBinding.instance.addPostFrameCallback((_) async {
+      await _askNotificationIfNeeded();
+    });
+  }
+
+  Future<void> _askNotificationIfNeeded() async {
+    final hasNoti = await _areNotificationsEnabled();
+    if (!hasNoti && mounted) {
+      final allow = await showDialog<bool>(
+        context: context,
+        barrierDismissible: true,
+        builder: (ctx)=> AlertDialog(
+          title: const Text('开启通知'),
+          content: const Text('为了按时提醒，请允许应用发送通知。你可以稍后在设置中更改。'),
+          actions: [
+            TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('稍后')),
+            FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('允许')),
+          ],
+        ),
+      );
+      if (allow == true) {
+        try { await NotificationService.request(); } catch (_) {}
+      }
+    }
+  }
+
   bool _ready = false;
 
   @override
   void initState() {
     super.initState();
+    // 先进入首页，再在首帧之后按需询问权限
+    setState(()=> _ready = true);
+    _scheduleAskNotiAfterFirstFrame();
     _checkPerms();
   }
 
   Future<void> _checkPerms() async {
-    // 第一道门卡：系统通知权限
-    final hasNoti = await _areNotificationsEnabled();
-    if (!hasNoti) {
-      // 直接触发系统通知授权弹框，无自定义弹框
-      try {
-        NotificationService.request(); // 非阻塞，避免按Home后恢复黑屏/卡顿
-      } catch (_) {}
-      // 再次检查，如果仍未授权，则尝试打开系统设置界面
-      final stillNo = !(await _areNotificationsEnabled());
-      if (stillNo) {
-        try { await _openNotificationSettings(); } catch (_) {}
+    // 第一道门卡：系统通知权限（延后到首帧后触发，不在此处阻塞）
+catch (_) {}
       }
     }
 

