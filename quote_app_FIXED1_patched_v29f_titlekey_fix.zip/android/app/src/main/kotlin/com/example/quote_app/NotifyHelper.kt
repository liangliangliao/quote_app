package com.example.quote_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"

  fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    largeIconPath: String?
  ): Boolean {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (android.os.Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(DEFAULT_CHANNEL_ID, "名人名言", NotificationManager.IMPORTANCE_DEFAULT)
      nm.createNotificationChannel(ch)
    }
    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      .setStyle(NotificationCompat.BigTextStyle().bigText(body))

    if (!largeIconPath.isNullOrEmpty()) {
      val bmp = BitmapFactory.decodeFile(largeIconPath)
      if (bmp != null) builder.setLargeIcon(bmp)
    }
    nm.notify(id, builder.build())
    return true
  }
}
