package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * Fires on device unlock to display a Toast immediately even if app is in background.
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_USER_PRESENT || action == Intent.ACTION_USER_UNLOCKED) {
            // 1) 记录日志（带时间）
            try { DbRepo.log(context.applicationContext, null, "【解锁后台】收到系统解锁广播：" + action) } catch (_: Throwable) {}
            // 2) 立即触发 UnlockWorker（后台轻提醒 & 地点规则）
            try { UnlockWorker.trigger(context.applicationContext) } catch (_: Throwable) {}
            // 3) 背景 Toast（便于肉眼确认）
            try { Toast.makeText(context.applicationContext, "已解锁：触发轻提醒", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
        }
    }
}