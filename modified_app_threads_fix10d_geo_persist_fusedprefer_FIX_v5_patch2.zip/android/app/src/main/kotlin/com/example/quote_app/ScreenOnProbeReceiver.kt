package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 仅用于兜底：监听 SCREEN_ON，延迟检查是否已解锁（无锁屏/智能解锁等）。
 * 只有确认“已解锁”时，才触发 UnlockWorker；否则不做任何业务。
 * 同时做 3 秒去重，避免与 USER_PRESENT 双触发。
 */
class ScreenOnProbeReceiver : BroadcastReceiver() {
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[" + now + "] " + msg)
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  override fun onReceive(context: Context, intent: Intent?) {
    if (intent?.action != Intent.ACTION_SCREEN_ON) return
    try { logWithTime(context, "【解锁后台-探测】收到 SCREEN_ON，开始延迟检查是否已解锁（回包：PROBE）") } catch (_: Throwable) {}

    val app = context.applicationContext
    val km = app.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

    Handler(Looper.getMainLooper()).postDelayed({
      val isLocked = try { km.isKeyguardLocked } catch (_: Throwable) { true }
      if (!isLocked) {
        // 去重：3 秒窗口内若已触发过解锁提醒，则跳过
        val now = System.currentTimeMillis()
        val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        val lastTrig = sp.getLong("last_unlock_trigger_ts", 0L)
        if (lastTrig > 0 && (now - lastTrig) < 3000L) {
          try { logWithTime(app, "【解锁后台-探测】3秒内已触发过解锁提醒，屏蔽本次重复（回包：SKIP_DUP）") } catch (_: Throwable) {}
          return@postDelayed
        }
        sp.edit().putLong("last_unlock_trigger_ts", now)
          .putLong("last_user_present_ts", now)  // 也记录最近“解锁时间”
          .apply()

        try { logWithTime(app, "【解锁后台-探测】检测到未上锁，判定为已解锁并触发 UnlockWorker（回包：OK）") } catch (_: Throwable) {}
        try { Toast.makeText(app, "已捕获解锁事件（探测），后台正在准备解锁提醒", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
        
        // ---- 解锁后并发启动两个线程（地点规则 + 轻提醒[仍然触发WorkManager]） ----
        try { logWithTime(app, "【解锁后台-探测】即将创建地点提醒线程与解锁轻提醒线程（轻提醒仍使用WorkManager加速模式）") } catch (_: Throwable) {}
        // 线程1：地点规则（前台服务）
        kotlin.concurrent.thread(name = "unlock-geo-thread") {
          try {
            try { logWithTime(app, "【解锁后台】地点提醒线程启动，准备注册并启动前台服务") } catch (_: Throwable) {}
            val svc = Intent(app, GeoForegroundService::class.java)
            try {
              if (android.os.Build.VERSION.SDK_INT >= 26) app.startForegroundService(svc) else app.startService(svc)
            } catch (t: Throwable) {
              try { logWithTime(app, "【解锁后台】直接启动前台服务失败，将通过透明Activity兜底：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
              try {
                val kick = Intent(app, FgKickActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                app.startActivity(kick)
              } catch (_: Throwable) {}
            }
          } catch (t: Throwable) {
            try { logWithTime(app, "【解锁后台】地点提醒线程异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
          }
        }
        // 线程2：解锁轻提醒（仍走已有 WorkManager 逻辑）
        kotlin.concurrent.thread(name = "unlock-light-thread") {
          try {
            try { logWithTime(app, "【解锁后台】解锁轻提醒线程启动（将触发 UnlockWorker）") } catch (_: Throwable) {}
            try { UnlockWorker.trigger(app) } catch (t: Throwable) {
              try { logWithTime(app, "【解锁后台】解锁轻提醒线程触发 UnlockWorker 异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
            }
            try {
              // 等待 UnlockWorker 最长 5 秒写入 last_unlock_reminder_time，避免在线程结束日志先于通知发送
              val prefs = app.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
              val before = prefs.getLong("last_unlock_reminder_time", 0L)
              val deadline = System.currentTimeMillis() + 5000L
              var done = false
              while (System.currentTimeMillis() < deadline) {
                val cur = prefs.getLong("last_unlock_reminder_time", 0L)
                if (cur > before) { done = true; break }
                try { Thread.sleep(200) } catch (_: Throwable) {}
              }
              if (done) logWithTime(app, "【解锁后台】解锁轻提醒已发送完成，线程结束")
              else logWithTime(app, "【解锁后台】解锁轻提醒已交给 Worker 处理，等待结果超时，线程结束")
            } catch (_: Throwable) {}
          } catch (_: Throwable) {}
        }
    
      } else {
        try { logWithTime(app, "【解锁后台-探测】SCREEN_ON 后仍处于上锁状态，等待系统 USER_PRESENT 广播（回包：WAIT）") } catch (_: Throwable) {}
      }
    }, 600)
  }
}
