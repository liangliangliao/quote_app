package com.example.quote_app.wm;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;
import com.example.quote_app.data.DbRepository;

public final class WmScheduler {
    private WmScheduler() {}

    public static void schedulePair(Context ctx, long triggerAt, String uid, String runKey) {
        long now = System.currentTimeMillis();
        long delay = Math.max(0L, triggerAt - now);
        long fbDelay = delay + 2 * 60 * 1000L; // +2min fallback

        WorkManager wm = WorkManager.getInstance(ctx.getApplicationContext());

        Data normal = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("chan", "normal")
                .putInt("attempt", 1)
                .build();

        Data fallback = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("chan", "wm_fallback")
                .putInt("attempt", 1)
                .build();

        OneTimeWorkRequest normalReq = new OneTimeWorkRequest.Builder(NormalWorker.class)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .addTag("wm_normal").addTag(uid)
                .setInputData(normal)
                .build();

        OneTimeWorkRequest fbReq = new OneTimeWorkRequest.Builder(FallbackWorker.class)
                .setInitialDelay(fbDelay, TimeUnit.MILLISECONDS)
                .addTag("wm_fallback")
                .setInputData(fallback)
                .build();

        DbRepository.log(ctx, uid, "【原生】WM 正常通道注册 uid="+uid+" run="+runKey+" ts="+triggerAt);
        wm.enqueueUniqueWork(WmNames.normUnique(uid, runKey), ExistingWorkPolicy.REPLACE, normalReq);
        DbRepository.log(ctx, uid, "【原生】WM 兜底通道注册 uid="+uid+" run="+runKey+" ts="+(triggerAt+120000));
        wm.enqueueUniqueWork(WmNames.fbUnique(uid, runKey), ExistingWorkPolicy.REPLACE, fbReq);
    }

    public static void cancelFallback(Context ctx, String uid, String runKey) {
        DbRepository.log(ctx, uid, "【原生】WM 取消兜底 uid="+uid+" run="+runKey);
        WorkManager.getInstance(ctx.getApplicationContext())
                .cancelUniqueWork(WmNames.fbUnique(uid, runKey));
    }


    public static void cancelByUid(Context ctx, String uid) {
        try {
            DbRepository.log(ctx, uid, "【原生】WM 取消(按uid) uid="+uid);
            WorkManager.getInstance(ctx.getApplicationContext()).cancelAllWorkByTag(uid);
        } catch (Throwable ignore) {}
    }
}
