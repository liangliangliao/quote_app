package com.example.quote_app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

    private val requestPostNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* grantedOrNot -> no-op; user can re-trigger from app UI if needed */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ensure notification channel exists before any notifications are posted
        NotificationUtils.ensureDefaultChannel(this)

        // Request Android 13+ notification runtime permission if not granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Only request if notifications are currently disabled for the app
            // (avoids re-prompting if user already granted)
            if (!NotificationUtils.areNotificationsEnabled(this)) {
                requestPostNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // On Android 12+ make sure user has allowed exact alarms (Android 14 defaults to denied)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                // Send user to the Alarms & Reminders settings page for this app
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                // Best-effort show settings; if OEM blocks this intent, fail silently.
                try { startActivity(intent) } catch (_: Exception) {}
            }
        }
    }
}
