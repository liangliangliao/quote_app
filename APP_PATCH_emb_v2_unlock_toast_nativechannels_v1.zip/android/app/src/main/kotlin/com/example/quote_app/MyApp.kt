package com.example.quote_app

import android.app.Application

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // keep minimal; channels are registered in MainActivity.configureFlutterEngine
    }
}
