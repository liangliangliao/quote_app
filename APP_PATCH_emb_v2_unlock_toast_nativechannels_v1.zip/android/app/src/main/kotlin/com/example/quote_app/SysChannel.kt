package com.example.quote_app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import com.google.android.gms.location.*
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class SysChannel {
    companion object {
        private const val CHANNEL = "com.example.quote_app/sys"

        fun register(engine: FlutterEngine) {
            MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
                .setMethodCallHandler { call, result ->
                    when (call.method) {
                        "getBaiduLocationOnce" -> getCurrentPositionCompat(engine.applicationContext, result)
                        else -> result.notImplemented()
                    }
                }
        }

        @SuppressLint("MissingPermission")
        private fun getCurrentPositionCompat(ctx: Context, result: MethodChannel.Result) {
            // Try FusedLocation first, then fallback to LocationManager lastKnown
            val fused = LocationServices.getFusedLocationProviderClient(ctx)
            try {
                val pri = Priority.PRIORITY_HIGH_ACCURACY
                fused.getCurrentLocation(pri, CancellationTokenSource().token)
                    .addOnSuccessListener { loc: Location? ->
                        if (loc != null) {
                            result.success(mapOf(
                                "provider" to (loc.provider ?: "fused"),
                                "lat" to loc.latitude,
                                "lon" to loc.longitude,
                                "acc" to loc.accuracy
                            ))
                        } else {
                            // fallback
                            deliverLastKnown(ctx, result)
                        }
                    }
                    .addOnFailureListener {
                        deliverLastKnown(ctx, result)
                    }
            } catch (t: Throwable) {
                deliverLastKnown(ctx, result)
            }
        }

        @SuppressLint("MissingPermission")
        private fun deliverLastKnown(ctx: Context, result: MethodChannel.Result) {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var best: Location? = null
            for (p in providers) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.accuracy < best!!.accuracy) best = l
            }
            if (best != null) {
                result.success(mapOf(
                    "provider" to (best!!.provider ?: "system"),
                    "lat" to best!!.latitude,
                    "lon" to best!!.longitude,
                    "acc" to best!!.accuracy
                ))
            } else {
                result.error("NO_LOCATION", "No location available", null)
            }
        }
    }
}
