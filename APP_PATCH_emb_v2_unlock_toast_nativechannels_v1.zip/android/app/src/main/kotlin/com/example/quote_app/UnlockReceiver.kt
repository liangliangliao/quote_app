package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Immediately show a toast on unlock
        Toast.makeText(context, "解锁成功：后台已捕获并触发提醒", Toast.LENGTH_SHORT).show()
    }
}
