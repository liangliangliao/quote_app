package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

class MainActivity: FlutterActivity() {
    private val SYS = "com.example.quote_app/sys"
    private val SCHED = "com.example.quote_app/sched"

    private fun alarmPendingIntent(context: Context, taskUid: String, flags: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply { putExtra("taskUid", taskUid) }
        val req = taskUid.hashCode()
        return PendingIntent.getBroadcast(context, req, intent, flags)
    }

    private fun scheduleExact(context: Context, taskUid: String, whenMs: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val flags = if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = alarmPendingIntent(context, taskUid, flags)
        am.cancel(pi)
        val typ = AlarmManager.RTC_WAKEUP
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(typ, whenMs, pi)
        } else {
            am.setExact(typ, whenMs, pi)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SYS).setMethodCallHandler { call, result ->
            when (call.method) {
                "hasExactAlarmPermission" -> {
                    val ok = ExactAlarmHelper.hasExactAlarmPermission(this@MainActivity)
                    result.success(ok)
                }
                "isBackgroundRestricted" -> {
                    result.success(false)
                }
                "openAppBatterySettings" -> {
                    try {
                        val intent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    } catch (_: Exception) {}
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SCHED).setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleExact" -> {
                    val args = call.arguments as Map<*, *>
                    val uid = args["taskUid"] as String
                    val whenMs = (args["when"] as Number).toLong()
                    scheduleExact(this@MainActivity, uid, whenMs)
                    result.success(null)
                }
                "cancel" -> {
                    val args = call.arguments as Map<*, *>
                    val uid = args["taskUid"] as String
                    val flags = if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE else PendingIntent.FLAG_UPDATE_CURRENT
                    val pi = alarmPendingIntent(this@MainActivity, uid, flags)
                    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    am.cancel(pi)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}
