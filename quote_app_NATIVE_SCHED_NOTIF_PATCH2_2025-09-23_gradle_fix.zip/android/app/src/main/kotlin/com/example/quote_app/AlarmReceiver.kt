package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val uid = intent?.getStringExtra("taskUid") ?: return
        BgRunner.invokeDart(context.applicationContext, "onAlarm", hashMapOf("taskUid" to uid))
    }
}
