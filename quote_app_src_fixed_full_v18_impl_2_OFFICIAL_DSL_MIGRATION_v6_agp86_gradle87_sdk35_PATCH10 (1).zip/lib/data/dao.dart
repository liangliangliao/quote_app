import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  return '$prefix-$ts-${r.nextInt(1<<32)}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    final id = await db.insert('configs', {
      'api_key': '',
      'model': 'gpt-5',
      'endpoint': 'https://api.openai.com/v1/responses',
    });
    return (await db.query('configs', where: 'id=?', whereArgs: [id], limit: 1)).first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint});
    } else {
      final id = rows.first['id'] as int;
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint}, where: 'id=?', whereArgs: [id]);
    }
  }
}

class TaskDao {
  Future<List<Map<String,dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return db.query('tasks', orderBy: 'id DESC');
  }

  Future<Map<String,dynamic>?> getByUid(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [taskUid], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<String> create({
    required String name,
    required String type,
    required DateTime startTime,
    required String prompt,
    required String? avatarPath,
    required String status,
    required String freqType,
    int? freqWeekday,
    int? freqDayOfMonth,
    String? freqCustom,
  }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'start_time': '${startTime.year.toString().padLeft(4,'0')}-${startTime.month.toString().padLeft(2,'0')}-${startTime.day.toString().padLeft(2,'0')} ${startTime.hour.toString().padLeft(2,'0')}:${startTime.minute.toString().padLeft(2,'0')}',
      'prompt': prompt,
      'avatar_path': avatarPath ?? '',
      'status': status,
      'freq_type': freqType,
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': freqCustom ?? '',
    });
    return uid;
  }

  Future<void> update(String taskUid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [taskUid]);
  }

  Future<void> delete(String taskUid) async {
    final db = await AppDatabase.instance();
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [taskUid]);
  }
}

class QuoteDao {
  Future<Map<String,dynamic>?> latestOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<int> count() async {
    final db = await AppDatabase.instance();
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM quotes')) ?? 0;
  }

  Future<List<Map<String,dynamic>>> latest({int limit=100, int offset=0, String? q}) async {
    final db = await AppDatabase.instance();
    if (q!=null && q.trim().isNotEmpty) {
      return db.query('quotes', where: 'content LIKE ?', whereArgs: ['%$q%'], orderBy: 'id DESC', limit: limit, offset: offset);
    }
    return db.query('quotes', orderBy: 'id DESC', limit: limit, offset: offset);
  }

  Future<String?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }

  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return false;
    final id = rows.first['id'] as int;
    await db.update('quotes', {
      'content': content,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch
    }, where: 'id=?', whereArgs: [id]);
    return true;
  }

  Future<bool> existsSimilar(String content, {double threshold=0.9}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content'], limit: 500, orderBy: 'id DESC');
    final n1 = normalizeText(content);
    for (final r in rows) {
      final n2 = normalizeText((r['content'] ?? '') as String);
      if (n2.isEmpty) continue;
      final sim = jaroWinkler(n1, n2);
      if (sim >= threshold) return true;
    }
    return false;
  }

  Future<String?> insertIfUnique({
    required String taskUid,
    required String content,
    required String taskName,
    String? taskType,
    String? type,
    String? avatarPath,
    double threshold=0.9,
  }) async {
    if (await existsSimilar(content, threshold: threshold)) return null;
    final t = taskType ?? type ?? 'manual';
    return insert(taskUid: taskUid, content: content, taskName: taskName, taskType: t, avatarPath: avatarPath);
  }

  Future<String> insert({
    required String taskUid,
    required String content,
    required String taskName,
    required String taskType,
    String? avatarPath,
  }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'content': content,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
    await LogDao().add(taskUid: taskUid, detail: '成功!');
    return uid;
  }

  Future<Map<String,dynamic>?> getByUid(String quoteUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'quote_uid=?', whereArgs: [quoteUid], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<void> markNotifiedByUid(String quoteUid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
  }
}

class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {
      'log_uid': _uid('log'),
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
  }
}