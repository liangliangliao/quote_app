import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 获取位置时希望的最大精度（半径）阈值，单位：米。
  /// 当精度大于此阈值时，将视为不满足高精度要求而继续回退到下一方案。
  /// 系统优先 -> 失败回退百度 -> 再失败回退最近已知位置（≤30m）。
  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1) 系统定位（高精度）
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null && sys.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'system';
        try { await DLog.i('LocationService', '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}'); } catch (_){}
        unawaited(_logNearbyLandmarkIfPossible(sys));
        return sys;
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_){}
    }
    // 2) 百度定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null && bd.accuracy <= _desiredAccuracyMeters) {
        lastProvider = 'baidu';
        try { await DLog.i('LocationService', '【定位】Baidu SDK成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}'); } catch (_){}
        unawaited(_logNearbyLandmarkIfPossible(bd));
        return bd;
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_){}
    }
    // 3) 最近已知位置
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        lastProvider = 'system';
        try { await DLog.i('LocationService', '【定位】采用最近已知位置 acc=${last.accuracy}m'); } catch (_){}
        return last;
      }
    } catch (_){}
    lastProvider = null;
    try { await DLog.w('LocationService', '【定位】无法获取位置（系统/百度/最近已知均失败）'); } catch (_){}
    return null;
  }
/// 最近一次成功定位所采用的提供者名称（baidu 或 system）。
  /// 如果定位失败或尚未调用，则为 null。
  static String? lastProvider;

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 优先尝试百度定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        // 检查精度：仅当满足阈值时才认为成功
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i('LocationService', '【定位】Baidu SDK成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w('LocationService', '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，回退系统定位');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_) {}
    }
    // 回退系统定位
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i('LocationService', '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}');
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w('LocationService', '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)');
          } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：$e'); } catch (_) {}
    }
    // 都失败
    lastProvider = null;
    try { await DLog.w('LocationService', '【定位】无法获取符合精度要求的位置'); } catch (_) {}
    return null;
  }

  static Future<Position?> _getCurrentPositionHighAccuracy() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      try { await DLog.w('LocationService', '【定位】系统定位服务未开启'); } catch (_) {}
      return null;
    }
    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      try { await DLog.w('LocationService', '【定位】未授予定位权限'); } catch (_) {}
      return null;
    }
    // 使用最高精度
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
  }

  /// 通过原生（Baidu SDK）获取一次坐标，失败返回 null。
  static Future<Position?> _baiduSdkLocationOnce() async {
    try {
      final ret = await _sysCh.invokeMethod('getBaiduLocationOnce');
      if (ret is Map) {
        final lat = (ret['lat'] as num?)?.toDouble();
        final lng = (ret['lng'] as num?)?.toDouble();
        final acc = (ret['acc'] as num?)?.toDouble() ?? 0.0;
        if (lat != null && lng != null) {
          final pos = Position(
            latitude: lat,
            longitude: lng,
            timestamp: DateTime.now(),
            accuracy: acc,
            altitude: 0,
            heading: 0,
            speed: 0,
            speedAccuracy: 0,
            altitudeAccuracy: 0,
            headingAccuracy: 0,
          );
          return pos;
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 调用失败：$e'); } catch (_) {}
    }
    return null;
  }

  /// 记录附近地标（百度逆地理），仅写日志，失败不抛出。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2';
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?ak=${Uri.encodeComponent(effectiveAk)}&coordtype=wgs84ll&extensions_poi=1&radius=600&location=${pos.latitude},${pos.longitude}'
      );
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && (data['status'] == 0 || data['status'] == '0')) {
          final result = data['result'];
          if (result is Map) {
            final pois = result['pois'];
            if (pois is List && pois.isNotEmpty) {
              final first = pois.first;
              String? name; int? distance;
              if (first is Map) {
                final n = first['name']; final d = first['distance'];
                if (n is String) name = n; if (d is int) distance = d;
              }
              if (name != null) {
                final suffix = distance != null ? '（约' + distance.toString() + '米）' : '';
                try { await DLog.i('LocationService', '附近地标：' + name + suffix); } catch (_) {}
              }
            }
          }
        }
      }
    } catch (_) {}
  }

  /// 通过系统逆地理服务获取附近标记。若反向地理编码失败，则返回空列表。
  ///
  /// 由于系统 API 无法提供与百度接口类似的 POI 列表，故此方法仅返回当前位置的名称
  ///（如果能够解析），并将距离字段设为 0。
  static Future<List<PoiItem>> fetchNearbyPoisSystem({
    required double latitude,
    required double longitude,
    int radiusMeters = 100,
    String keyword = '',
    int page = 1,
    int pageSize = 5,
  }) async {
    try {
      final placemarks = await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isEmpty) return <PoiItem>[];
      final pm = placemarks.first;
      // 组合地点名称
      final name = ((pm.name ?? '') + ' ' + (pm.street ?? '')).trim();
      final resolvedName = name.isNotEmpty ? name : '当前位置';
      final poi = PoiItem(name: resolvedName, address: null, latitude: latitude, longitude: longitude, distance: 0);
      return [poi];
    } catch (_) {
      return <PoiItem>[];
    }
  }

  /// 页面“新增地点规则”需要的 POI 拉取（默认100米，百度逆地理接口，同步到UI分页）；
  /// 签名保持与页面一致。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    int radiusMeters = 100,
    String keyword = '',
    int page = 1,
    int pageSize = 5,
  }) async {
    try {
      String ak = '';
      try { ak = await NotifyConfigDao().getBaiduAk(); } catch (_) { ak = ''; }
      final effectiveAk = ak.trim().isNotEmpty ? ak.trim() : 'kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2';
      // 百度逆地理接口支持 extensions_poi，page_num 从 0 开始
      final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?'
        'ak=${Uri.encodeComponent(effectiveAk)}&coordtype=wgs84ll&radius=${radiusMeters.toString()}'
        '&extensions_poi=1&page_num=${(page-1).clamp(0, 50)}&location=$latitude,$longitude'
      );
      final res = await http.get(url);
      if (res.statusCode != 200) return <PoiItem>[];
      final m = jsonDecode(res.body);
      final result = (m is Map) ? m['result'] : null;
      final pois = (result is Map) ? result['pois'] : null;
      if (pois is! List) return <PoiItem>[];

      final out = <PoiItem>[];
      for (final e in pois) {
        if (e is! Map) continue;
        final name = (e['name'] ?? '').toString();
        if (name.isEmpty) continue;
        if (keyword.isNotEmpty && !name.contains(keyword)) continue;
        final point = e['point'];
        final x = (point is Map) ? point['x'] : null;
        final y = (point is Map) ? point['y'] : null;
        final lng = (x is num) ? x.toDouble() : null;
        final lat = (y is num) ? y.toDouble() : null;
        if (lat == null || lng == null) continue;
        final dis = (e['distance'] is num) ? (e['distance'] as num).toInt() : null;
        out.add(PoiItem(name: name, address: e['addr']?.toString(), latitude: lat, longitude: lng, distance: dis));
      }
      // 简单分页：客户端再截断
      final start = (page-1) * pageSize;
      final end = (start + pageSize);
      return start >= out.length ? <PoiItem>[] : out.sublist(start, end.clamp(0, out.length));
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】拉取附近POI失败：$e'); } catch (_) {}
      return <PoiItem>[];
    }
  }
}