import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static bool? _lastHasExact;
  static DateTime? _lastExactCheckedAt;

  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return true;
    // 短时间内重复查询直接复用缓存，避免抖动
    if (_lastExactCheckedAt != null &&
        DateTime.now().difference(_lastExactCheckedAt!) < const Duration(seconds: 10) &&
        _lastHasExact != null) {
      return _lastHasExact!;
    }
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      _lastHasExact = ok ?? _lastHasExact ?? true; // 失败时保持上次值，默认乐观为 true
      _lastExactCheckedAt = DateTime.now();
      return _lastHasExact!;
    } catch (_) {
      // MethodChannel 偶发异常（Activity 重建/切换），返回上次成功结果；若无则默认 true
      return _lastHasExact ?? true;
    }
  } catch (_) {
      return false;
    }
  }

  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } catch (_) {}
  }

  static Future<void> ensureExactAlarmPermission() async {
    final ok = await hasExactAlarmPermission();
    if (!ok) {
      await requestExactAlarmPermission();
    }
  }

  static Future<bool> hasBatteryOptExemption() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestBatteryOptExemption() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {}
  }

  static Future<void> ensureBatteryOptExemption() async {
    final ok = await hasBatteryOptExemption();
    if (!ok) {
      await requestBatteryOptExemption();
    }
  }

  static Future<bool> isBackgroundRestricted() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('isBackgroundRestricted');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> openAppBatterySettings() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('openAppBatterySettings');
    } catch (_) {}
  }
}
