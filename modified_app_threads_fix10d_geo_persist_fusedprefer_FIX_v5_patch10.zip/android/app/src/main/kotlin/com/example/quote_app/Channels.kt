package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Minimal, safe native channel used by Dart to query simple flags.
 * Keep surface area tiny to avoid build errors.
 */
object Channels {
    private const val CHANNEL = "native.scheduler"

    fun register(engine: FlutterEngine, appCtx: Context) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isNativeWM" -> result.success(true)
                    else -> result.notImplemented()
                }
            }
    }
}