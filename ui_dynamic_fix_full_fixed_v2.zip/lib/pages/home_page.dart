import 'dart:async';
import 'package:flutter/material.dart';
import 'package:quote_app/widgets/home_html_view.dart';
import '../data/dao.dart';
import '../utils/debug_logger.dart';
import 'package:quote_app/services/native_guard.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  bool _fav = false;
  Map<String, dynamic>? _todayData;
  bool _firstLoaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // 后台任务通过 SimpleBus.pokeHome() 触发刷新
    SimpleBus.homeTick.addListener(_onBus);
    _load();
  }

  void _onBus() { _load(); }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SimpleBus.homeTick.removeListener(_onBus);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _load();
    }
  }

  Future<void> _load() async {
    setState(() { _todayData = null; _firstLoaded = true; }); // 进入“空白→兜底”
    try {
      final dao = QuoteDao();
      final latest = await dao.latestNotifiedToday();
      if (!mounted) return;
      if (latest == null) {
        await DLog.i('HOME', '今日未检索到已通知记录：显示兜底 HTML');
        setState(() { _todayData = null; });
      } else {
        // 组装 payload，兼容字段名
        final payload = <String, dynamic>{
          'topic': (latest['topic'] ?? latest['theme'] ?? '').toString(),
          'quote': (latest['quote'] ?? latest['content'] ?? '').toString(),
          'author': (latest['author'] ?? latest['author_name'] ?? '').toString(),
          'source': (latest['source'] ?? latest['source_from'] ?? '').toString(),
          'note': (latest['note'] ?? '').toString(),
          'avatarUrl': (latest['avatarUrl'] ?? latest['avatar_url'] ?? '').toString(),
          'authorText': '一一${(latest['author'] ?? latest['author_name'] ?? '').toString().trim()} ${(latest['source'] ?? latest['source_from'] ?? '').toString().trim()}',
        };
        await DLog.i('HOME', '已检索到今日最新已通知记录：准备注入');
        setState(() { _todayData = payload; });
      }
    } catch (e) {
      await DLog.e('HOME', '查询异常：将显示兜底；err=$e');
      if (mounted) setState(() { _todayData = null; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final assetPath = 'assets/html/poster-wall-only-frame-v23-1.html';
    final content = (!_firstLoaded)
        ? const {'__blank__': true}
        : _todayData;

    return SafeArea(
      child: Stack(
        children: [
          Center(child: HomeHtmlView(assetPath: assetPath, data: content)),
          Positioned(
            top: 8,
            right: 8,
            child: Row(
              children: [
                _floatingBtn(icon: Icons.share, onTap: () async {
                  final text = (_todayData?['quote'] ?? '') as String?;
                  if (text==null || text.isEmpty) return;
                  await Clipboard.setData(ClipboardData(text: text));
                  if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制，可自行分享'))); }
                }),
                const SizedBox(width: 8),
                _floatingBtn(icon: Icons.copy, onTap: () async {
                  final text = (_todayData?['quote'] ?? '') as String?;
                  if (text==null || text.isEmpty) return;
                  await Clipboard.setData(ClipboardData(text: text));
                  if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'))); }
                }),
                const SizedBox(width: 8),
                _floatingBtn(icon: _fav ? Icons.favorite : Icons.favorite_border, onTap: (){ setState(()=> _fav = !_fav); }),
              ],
            ),
          ),
        ],
      ),
    );
  }
}