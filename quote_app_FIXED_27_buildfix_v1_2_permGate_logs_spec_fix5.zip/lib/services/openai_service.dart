
import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIService {
  static Future<String> generateQuote({
    required String prompt,
    String? model,
    String? apiKey,
    String? baseUrl,
  }) async {
    final useModel = (model == null || model.trim().isEmpty) ? 'gpt-5' : model.trim();
    final url = Uri.parse((baseUrl == null || baseUrl.trim().isEmpty)
        ? 'https://api.openai.com/v1/chat/completions'
        : baseUrl.trim());
    final headers = <String, String>{
      'Content-Type': 'application/json',
      if (apiKey != null && apiKey.isNotEmpty) 'Authorization': 'Bearer $apiKey',
    };
    final payload = {
      'model': useModel,
      'messages': [
        {'role': 'system', 'content': 'You are a concise quote generator.'},
        {'role': 'user', 'content': prompt}
      ],
      'temperature': 0.7,
      'max_tokens': 80,
    };
    final resp = await http.post(url, headers: headers, body: jsonEncode(payload));
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('OpenAI HTTP ${resp.statusCode}: ${resp.body}');
    }
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final choices = (data['choices'] as List?) ?? [];
    if (choices.isEmpty) throw Exception('No choices from OpenAI');
    final msg = choices.first['message'] as Map<String, dynamic>?;
    final content = (msg?['content'] ?? '').toString().trim();
    if (content.isEmpty) throw Exception('Empty content from OpenAI');
    return content;
  }
}
