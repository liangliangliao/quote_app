import 'dart:async';
import 'dart:math';

import 'package:workmanager/workmanager.dart';

import 'package:quote_app/data/dao.dart';
import 'package:quote_app/services/notification_service.dart';
import 'package:quote_app/services/openai_service.dart';
import 'package:quote_app/platform/native_scheduler.dart';
import 'package:quote_app/utils/run_context.dart';
import 'package:quote_app/utils/debug_logger.dart';

/// Backward-compat shim: some older branches may miss QuoteDao.peekCarouselNext.
/// Provide it via an extension that maps to carouselNextSequential.
extension QuoteDaoCompat on QuoteDao {
  Future<Map<String,dynamic>> peekForTask(String uid, String type) async {
    if (type == 'carousel') {
      return (await peekCarouselNext(uid)) ?? {};
    } else {
      final row = await latestForTask(uid);
      return row ?? {};
    }
  }

  Future<Map<String,dynamic>?> peekCarouselNext(String taskUid) {
    return carouselNextSequential(taskUid);
  }
}

class SchedulerService {
  static const int _kMaxFallbackAttempts = 3;
  static const int _kFallbackBackoffMin = 3;

  static Future<int> _cfgTtlMinutes() async {
    try { return await ConfigDao().getInt('ttl_minutes', 10); } catch (_){ return 10; }
  }
  static Future<int> _cfgFbMaxAttempts() async {
    try { return await ConfigDao().getInt('fb_max_attempts', _kMaxFallbackAttempts); } catch (_){ return _kMaxFallbackAttempts; }
  }
  static Future<int> _cfgFbBackoffMin() async {
    try { return await ConfigDao().getInt('fb_backoff_min', _kFallbackBackoffMin); } catch (_){ return _kFallbackBackoffMin; }
  }

  static Future<void> init() async {
    await NotificationService().initialize();
    // Workmanager is initialized in main.dart; nothing else to do.
  }

  /// Build a stable alarm id by hashing uid+runKey to int32 range
  static int _alarmId(String uid, String runKey) {
    final s = '$uid/$runKey';
    var h = 0;
    for (final c in s.codeUnits) { h = 0x1fffffff & (h * 131 + c); }
    return (h & 0x7fffffff);
  }

  static String _runKeyForPlanned(DateTime planned) {
    // e.g. 2025-09-29T15:30:00.000Z -> 20250929T153000000
    return planned.toIso8601String().replaceAll(':', '').replaceAll('-', '').replaceAll('.', '');
  }

  static Future<void> _scheduleWmOneOff(String uniqueName, Map<String,dynamic> data, Duration delay) async {
    try {
            await Workmanager().cancelByUniqueName(uniqueName);
      await Workmanager().registerOneOffTask(
        uniqueName,
        uniqueName,
        inputData: data.map((k,v) => MapEntry(k, v is String ? v : v.toString())),
        initialDelay: delay,
        constraints: Constraints(),
        backoffPolicy: BackoffPolicy.linear,
        backoffPolicyDelay: const Duration(minutes: 5),
      );
    } catch (_){}
  }

  static DateTime? _computeNext(Map<String,dynamic> t) {
    // Very defensive, simple scheduler:
    final now = DateTime.now();
    final start = (t['start_time'] ?? '').toString(); // "HH:mm"
    final freqType = (t['freq_type'] ?? 'daily').toString(); // daily/hourly/weekly/monthly
    DateTime base;
    try {
      if (start.contains(':')) {
        final hh = int.parse(start.split(':')[0]);
        final mm = int.parse(start.split(':')[1]);
        base = DateTime(now.year, now.month, now.day, hh, mm);
      } else {
        base = now;
      }

DateTime? _computeNextAfter(Map<String,dynamic> t, DateTime after) {
  // Same logic as _computeNext but using provided 'after' as now
  final start = (t['start_time'] ?? '').toString(); // "HH:mm"
  final freqType = (t['freq_type'] ?? 'daily').toString(); // daily/hourly/weekly/monthly
  DateTime base;
  try {
    if (start.contains(':')) {
      final hh = int.parse(start.split(':')[0]);
      final mm = int.parse(start.split(':')[1]);
      base = DateTime(after.year, after.month, after.day, hh, mm);
    } else {
      base = after;
    }
  } catch (_){ base = after; }
  if (base.isAfter(after) || base.isAtSameMomentAs(after)) {
    return base;
  }
  switch (freqType) {
    case 'hourly': return base.add(const Duration(hours: 1));
    case 'weekly': return base.add(const Duration(days: 7));
    case 'monthly': return DateTime(base.year, base.month+1, base.day, base.hour, base.minute);
    default: return base.add(const Duration(days: 1));
  }
}
    } catch (_){
      base = now;
    }
    if (!base.isAfter(now)) {
      switch (freqType) {
        case 'hourly': base = base.add(const Duration(hours: 1)); break;
        case 'weekly': base = base.add(const Duration(days: 7)); break;
        case 'monthly': base = DateTime(base.year, base.month+1, base.day, base.hour, base.minute); break;
        default: base = base.add(const Duration(days: 1));
      }
    }
    return base;
  }

  static Future<bool> sendForTask(Map<String, dynamic> t, {String? runKey, DateTime? planned, String? source}) async {
    final uid = (t['task_uid'] ?? '').toString();
    final type = (t['type'] ?? 'manual').toString(); // 'manual'|'auto'|'carousel'
    final name = (t['name'] ?? '任务').toString();
    final avatar = (t['avatar'] ?? '').toString();

    Future<void> _notify({required String title, required String? body, required String? iconPath}) async {
      await NotificationService().show(title, body ?? '', androidSmallIcon: (iconPath?.isEmpty ?? true) ? null : iconPath);
    }

    if (type == 'manual') {
      final row = await QuoteDao().latestForTask(uid);
      final content = (row?['content'] ?? '').toString();
      if (content.isEmpty) return false;
      await _notify(title: name, body: content, iconPath: avatar);
      if (row?['uid'] != null) await QuoteDao().markNotifiedByUid(row!['uid'].toString());
      return false;
    }

    if (type == 'carousel') {
      final row = await QuoteDao().peekCarouselNext(uid);
      if (row == null) return false;
      await _notify(title: name, body: (row['content'] ?? '').toString(), iconPath: (row['avatar'] ?? avatar).toString());
      if (row['uid'] != null) await QuoteDao().markNotifiedByUid(row['uid'].toString());
      return false;
    }

    // auto
    final prompt = (t['prompt'] ?? '').toString();
    final model = await ConfigDao().getString('model', 'gpt-5');
    final apiKey = await ConfigDao().getString('api_key', '');
    final baseUrl = await ConfigDao().getString('endpoint', '');
    final int MAX_TRIES = await ConfigDao().getInt('max_auto_tries', 10);
    for (int i = 0; i < MAX_TRIES; i++) {
      String text;
      try {
        text = await OpenAIService.generateQuote(prompt: prompt, model: model, apiKey: apiKey, baseUrl: baseUrl);
      } catch (e) {
        await LogDao().add(taskUid: uid, detail: '错误! ${e.toString()}');
        return false;
      }
      final dup = await QuoteDao().existsSimilar(text, threshold: 0.90);
      if (dup) continue;
      final qUid = await QuoteDao().insertQuote(taskUid: uid, content: text, avatar: avatar, taskType: type);
      await LogDao().add(taskUid: uid, detail: '成功!');
      await _notify(title: name, body: text, iconPath: avatar);
      await QuoteDao().markNotifiedByUid(qUid);
      return false;
    }
    await LogDao().add(taskUid: uid, detail: '错误! 连续调用api10次去重检验未通过！');
    return false;
  }

  static Future<void> _handleCallback(String uid, String runKey, {required String source}) async {
    final t = await TaskDao().findByUid(uid);
    if (t == null) return;
    await sendForTask(t, runKey: runKey, source: source);
    try { await cancelWmFallbackForRun(uid, runKey); } catch (_){}
  }

  static Future<void> wmRunTask(String taskUid, String runKey) async {
    await _handleCallback(taskUid, runKey, source: 'WM');
    // After delivering via WM, schedule the next occurrence when task is still ON.
    try {
      final t = await TaskDao().findByUid(taskUid);
      final status = (t?['status'] ?? 'on').toString();
      if (status == 'on') {
        await SchedulerService.scheduleNextForTask(taskUid);
      }
    } catch (_){}
  }

  static Future<void> wmAfterAmTask(String taskUid, String runKey, {String? qUid}) async {
    try {
      await DLog.i('SCH', '【回执】AM 已发 => WM 回执 begin uid='+taskUid+', runKey='+runKey);
      if (qUid != null && qUid.isNotEmpty) {
        try { await QuoteDao().markNotifiedByUid(qUid); } catch (_) {}
      } else {
        try {
          final row = await QuoteDao().latestForTask(taskUid);
          if (row?['uid'] != null) await QuoteDao().markNotifiedByUid(row!['uid'].toString());
        } catch (_) {}
      }
      await LogDao().add(taskUid: taskUid, detail: '成功! 通知已由AM发出（WM回执）');
      try { await SchedulerService.cancelWmFallbackForRun(taskUid, runKey); } catch (_){}
      // Only reschedule when the task remains enabled
      try {
        final t = await TaskDao().findByUid(taskUid);
        final status = (t?['status'] ?? 'on').toString();
        if (status == 'on') {
          await SchedulerService.scheduleNextForTask(taskUid);
        }
      } catch (_){}
      await DLog.i('SCH', '【回执】AM 已发 => WM 回执 done');
    } catch (e) {
      await DLog.e('SCH', 'WM 回执错误: '+e.toString());
    }
  }

  
  static Future<int> _getFbAttempt(String uid, String runKey) async {
    try { final v = await MetaDao().get('fb_attempt:'+uid+':'+runKey); return v==null?0:int.tryParse(v)??0; } catch (_){ return 0; }
  }
  static Future<void> _setFbAttempt(String uid, String runKey, int n) async {
    try { await MetaDao().set('fb_attempt:'+uid+':'+runKey, n.toString()); } catch (_){}
  }
  static Future<void> _clearFbAttempt(String uid, String runKey) async {
    try { await MetaDao().delete('fb_attempt:'+uid+':'+runKey); } catch (_){}
  }
static Future<void> cancelWmFallbackForRun(String uid, String runKey) async {
    try { await Workmanager().cancelByUniqueName('fb_next_${uid}_$runKey'); } catch (_){ } finally { try { await MetaDao().delete('fb_attempt:'+uid+':'+runKey); } catch (_){}}
  }

  static Future<void> cancelNextForTask(String uid, {String? runKey, bool includeFallback = true}) async {
    final rk = (runKey ?? '');
    String? effRunKey = rk.isNotEmpty ? rk : await _getLastRunKey(uid);
    // Cancel AM exact alarm for this run if we can resolve a runKey
    if (effRunKey != null && effRunKey.isNotEmpty) {
      try { await NativeScheduler.cancel(_alarmId(uid, effRunKey)); } catch (_){}
      if (includeFallback) {
        try { await Workmanager().cancelByUniqueName('fb_next_${uid}_'+effRunKey); } catch (_){}
        try { await Workmanager().cancelByUniqueName('wm_run_${uid}_'+effRunKey); } catch (_){}
        try { await Workmanager().cancelByUniqueName('wm_after_am_${uid}_'+effRunKey); } catch (_){}
      }
    } else {
      // No known runKey; best-effort: cancel any fb/wm unique names we know for this uid in current minute
      final nowKey = _runKeyForPlanned(DateTime.now());
      try { await NativeScheduler.cancel(_alarmId(uid, nowKey)); } catch (_){}
      if (includeFallback) {
        try { await Workmanager().cancelByUniqueName('fb_next_${uid}_'+nowKey); } catch (_){}
        try { await Workmanager().cancelByUniqueName('wm_run_${uid}_'+nowKey); } catch (_){}
        try { await Workmanager().cancelByUniqueName('wm_after_am_${uid}_'+nowKey); } catch (_){}
      }
    }
  
    // Also cancel pre-scheduled next run if exists
    try {
      final nextKey = await MetaDao().get('next_run_key:'+uid);
      if (nextKey != null && nextKey.toString().isNotEmpty) {
        try { await Workmanager().cancelByUniqueName('fb_next_'+uid+'_'+nextKey); } catch (_){}
        try { await Workmanager().cancelByUniqueName('wm_run_'+uid+'_'+nextKey); } catch (_){}
        try { await Workmanager().cancelByUniqueName('wm_after_am_'+uid+'_'+nextKey); } catch (_){}
        try { await NativeScheduler.cancel(_alarmId(uid, nextKey)); } catch (_){}
      }
      await MetaDao().delete('next_run_key:'+uid);
    } catch (_){}
}

  static Future<void> cancelForTask(String uid) async {
    await cancelNextForTask(uid, includeFallback: true);
  }

  static Future<void> scheduleNextForTask(String uid) async {
    try {
      final t = await TaskDao().findByUid(uid);
      if (t == null) return;
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on') return;

      final planned = _computeNext(t);
      if (planned == null) return;
      final runKey = _runKeyForPlanned(planned);
      await _setLastRunKey(uid, runKey);

      final type = (t['type'] ?? 'manual').toString();
      final name = (t['name'] ?? '任务').toString();

      if (type == 'manual' || type == 'carousel') {
        Map<String,dynamic>? row;
        if (type == 'manual') { row = await QuoteDao().latestForTask(uid); }
        else { row = await QuoteDao().peekCarouselNext(uid); }
        final qUid = (row?['uid'] ?? '').toString();
        final body = (row?['content'] ?? '').toString();
        final payload = {
          'notify': true,
          'title': name,
          'body': body,
          'task_uid': uid,
          'run_key': runKey,
          'q_uid': qUid,
          'type': type,
        };
        final canExact = await NativeScheduler.hasExactAlarmPermission();
        if (canExact) {
          try {
            final amId = _alarmId(uid, runKey);
            final epochMs = planned.millisecondsSinceEpoch;
            await DLog.i('SCH', '【调度】使用 AM 精确闹钟，id='+amId.toString()+', 时间='+planned.toIso8601String());
            await NativeScheduler.scheduleExactAt(id: amId, epochMs: epochMs, payload: payload);
          } catch (e) {
            await DLog.e('SCH', '【错误】AM 注册失败: '+e.toString());
          }
          final backoffMin = await _cfgFbBackoffMin();
          final fbDelay = planned.difference(DateTime.now()) + Duration(minutes: backoffMin);
          await DLog.i('SCH', '【调度】挂载 VM 兜底（fallback），唯一键 fb_next_'+uid+'_'+runKey+'，延迟 '+backoffMin.toString()+' 分钟');
          await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid':uid,'run_key':runKey}, fbDelay);
          await LogDao().add(taskUid: uid, detail: '【安排-当前轮】兜底已注册 | 计划=' + planned.toIso8601String() + '+3min | runKey=' + runKey + ' | unique=fb_next_' + uid + '_' + runKey);
        } else {
          final diff = planned.difference(DateTime.now());
          final primaryDelay = diff.inSeconds <= 5 ? const Duration(seconds: 5) : diff;
          await DLog.i('SCH', '【调度】无精确闹钟权限，改用 VM 正常为主；唯一键 wm_run_'+uid+'_'+runKey+'，延迟 '+primaryDelay.inSeconds.toString()+' 秒');
          await _scheduleWmOneOff('wm_run_'+uid+'_'+runKey, {'job':'wm_run','task_uid':uid,'run_key':runKey}, primaryDelay);
          await LogDao().add(taskUid: uid, detail: '【安排-当前轮】VM 已注册 | 时间=' + planned.toIso8601String() + ' | runKey=' + runKey + ' | unique=wm_run_' + uid + '_' + runKey);
          final backoffMin = await _cfgFbBackoffMin();
          final fbDelay = planned.difference(DateTime.now()) + Duration(minutes: backoffMin);
          await DLog.i('SCH', '【调度】再挂 VM 兜底（fallback） fb_next_'+uid+'_'+runKey+'，延迟 '+backoffMin.toString()+' 分钟');
          await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid':uid,'run_key':runKey}, fbDelay);
          await LogDao().add(taskUid: uid, detail: '【安排-当前轮】兜底已注册 | 计划=' + planned.toIso8601String() + '+3min | runKey=' + runKey + ' | unique=fb_next_' + uid + '_' + runKey);
        }
      } else {
        // auto：不预拉内容，AM 到点后生成；仅安排触发载荷
        final payload = {
          'notify': true,
          'title': name,
          'body': '到点了',
          'task_uid': uid,
          'run_key': runKey,
          'type': type,
        };
        final canExact = await NativeScheduler.hasExactAlarmPermission();
        if (canExact) {
          try {
            final amId = _alarmId(uid, runKey);
            final epochMs = planned.millisecondsSinceEpoch;
            await DLog.i('SCH', '【调度】使用 AM 精确闹钟(auto)，id='+amId.toString()+', 时间='+planned.toIso8601String());
            await NativeScheduler.scheduleExactAt(id: amId, epochMs: epochMs, payload: payload);
          } catch (e) {
            await DLog.e('SCH', '【错误】AM 注册失败(auto): '+e.toString());
          }
          final backoffMin = await _cfgFbBackoffMin();
          final fbDelay = planned.difference(DateTime.now()) + Duration(minutes: backoffMin);
          await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid':uid,'run_key':runKey}, fbDelay);
          await LogDao().add(taskUid: uid, detail: '【安排-当前轮】兜底已注册 | 计划=' + planned.toIso8601String() + '+3min | runKey=' + runKey + ' | unique=fb_next_' + uid + '_' + runKey);
        } else {
          final diff = planned.difference(DateTime.now());
          final primaryDelay = diff.inSeconds <= 5 ? const Duration(seconds: 5) : diff;
          await _scheduleWmOneOff('wm_run_'+uid+'_'+runKey, {'job':'wm_run','task_uid':uid,'run_key':runKey}, primaryDelay);
          await LogDao().add(taskUid: uid, detail: '【安排-当前轮】VM 已注册 | 时间=' + planned.toIso8601String() + ' | runKey=' + runKey + ' | unique=wm_run_' + uid + '_' + runKey);
          final backoffMin = await _cfgFbBackoffMin();
          final fbDelay = planned.difference(DateTime.now()) + Duration(minutes: backoffMin);
          await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid':uid,'run_key':runKey}, fbDelay);
          await LogDao().add(taskUid: uid, detail: '【安排-当前轮】兜底已注册 | 计划=' + planned.toIso8601String() + '+3min | runKey=' + runKey + ' | unique=fb_next_' + uid + '_' + runKey);
        }
      }
    
      // 预先为下一次也安排（等效于“秒续排”）：使用 planned2 = next after planned
      try {
        final planned2 = _computeNextAfter(t, planned);
        if (planned2 != null) {
          final runKey2 = _runKeyForPlanned(planned2);
          try { await MetaDao().set('next_run_key:'+uid, runKey2); } catch (_){ }
          final type2 = (t['type'] ?? 'manual').toString();
          final name2 = (t['name'] ?? '任务').toString();
          Map<String,dynamic> row2;
          if (type2 == 'manual') {
            row2 = (await QuoteDao().latestForTask(uid)) ?? {};
          } else if (type2 == 'carousel') {
            row2 = (await QuoteDao().peekCarouselNext(uid)) ?? {};
          } else {
            row2 = {};
          }
          final qUid2 = (row2['uid'] ?? '').toString();
          final body2 = (row2['content'] ?? '').toString();
          final payload2 = {
            'notify': true,
            'title': name2,
            'body': body2,
            'task_uid': uid,
            'run_key': runKey2,
            'q_uid': qUid2,
            'type': type2,
          };
          final canExact2 = await NativeScheduler.hasExactAlarmPermission();
          if (canExact2) {
            try {
              final amId2 = _alarmId(uid, runKey2);
              await NativeScheduler.scheduleExactAt(id: amId2, epochMs: planned2.millisecondsSinceEpoch, payload: payload2);
              await LogDao().add(taskUid: uid, detail: '【预安排-下一轮】AM 已注册 | 时间=' + planned2.toIso8601String() + ' | runKey=' + runKey2 + ' | alarmId=' + amId2.toString());
            } catch (_){ }
          } else {
            final diff2 = planned2.difference(DateTime.now());
            final primaryDelay2 = diff2.inSeconds <= 5 ? const Duration(seconds: 5) : diff2;
            await _scheduleWmOneOff('wm_run_'+uid+'_'+runKey2, {'job':'wm_run','task_uid':uid,'run_key':runKey2}, primaryDelay2);
            await LogDao().add(taskUid: uid, detail: '【预安排-下一轮】VM 已注册 | 时间=' + planned2.toIso8601String() + ' | runKey=' + runKey2 + ' | unique=wm_run_' + uid + '_' + runKey2);
          }
          // 也挂下一次的 fallback（3分钟后）
          final backoffMin2 = await _cfgFbBackoffMin();
          final fbDelay2 = planned2.difference(DateTime.now()) + Duration(minutes: backoffMin2);
          await _scheduleWmOneOff('fb_next_'+uid+'_'+runKey2, {'job':'wm_fallback','task_uid':uid,'run_key':runKey2}, fbDelay2);
          await LogDao().add(taskUid: uid, detail: '【预安排-下一轮】兜底已注册 | 计划=' + planned2.toIso8601String() + '+3min | runKey=' + runKey2 + ' | unique=fb_next_' + uid + '_' + runKey2);
        }
      } catch (_){ }
}

static Future<void> catchupIfMissed() async {
    try {
      final tasks = await TaskDao().all();
      for (final t in tasks) {
        final uid = (t['task_uid'] ?? '').toString();
        if (uid.isEmpty) continue;
        await DLog.i('SCH', 'schedule next for '+uid);
        await scheduleNextForTask(uid);
      }
    } catch (e) {
      try { await LogDao().add(taskUid: '', detail: 'catchupIfMissed error: ${e.toString()}'); } catch (_){ }
    }
  }

  static Future<void> wmFallbackTask(String taskUid, String runKey) async {
    // Attempt send; if fails and attempts < max, schedule another fallback after 3 min
    final t = await TaskDao().findByUid(taskUid);
    if (t == null) return;
    final success = await sendForTask(t, runKey: runKey, source: 'WM_FALLBACK');
    // Update attempts
    final maxAtt = await _cfgFbMaxAttempts();
    final cur = await _getFbAttempt(taskUid, runKey);
    if (!success && cur < maxAtt) {
      await _setFbAttempt(taskUid, runKey, cur+1);
      final delay = const Duration(seconds: 30);
      await _scheduleWmOneOff('fb_next_'+taskUid+'_'+runKey, {'job':'wm_fallback','task_uid':taskUid,'run_key':runKey}, delay);
    } else {
      await _clearFbAttempt(taskUid, runKey);
    }
    // Regardless of success, schedule next normal occurrence if task is on
    try {
      final status = (t['status'] ?? 'on').toString();
      if (status == 'on') {
        await SchedulerService.scheduleNextForTask(taskUid);
      }
    } catch (_) {}
  }
static Future<void> scheduleNextForAll() async {
    await DLog.i('SCH', 'schedule all start');
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      final uid = (t['task_uid'] ?? '').toString();
      if (uid.isEmpty) continue;
      await DLog.i('SCH', 'schedule next for '+uid);
      await scheduleNextForTask(uid);
    }
  }

  static Future<void> _setLastRunKey(String uid, String runKey) async {
    try { await MetaDao().set('last_run_key:'+uid, runKey); } catch (_){}
  }
  static Future<String?> _getLastRunKey(String uid) async {
    try { return await MetaDao().get('last_run_key:'+uid); } catch (_){ return null; }
  }

  
}