
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 5,
      onCreate: _create,
      onUpgrade: _upgrade,
    );
    await _db!.execute('PRAGMA foreign_keys = ON');
    return _db!;
  }

  static Future<void> _create(Database db, int version) async {
    // Configs
    await db.execute('''
      CREATE TABLE configs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        api_key TEXT,
        model TEXT,
        endpoint TEXT
      )
    ''');
    await db.insert('configs', {
      'api_key': '',
      'model': 'gpt-5',
      'endpoint': 'https://api.openai.com/v1/responses'
    });

    // Meta key-value
    await db.execute('''
      CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');

    // Tasks
    // Additional columns `next_time` and `scheduled_run_key` are included by
    // default in the schema.  They will be used to store the next scheduled
    // run time and the last registered runKey respectively.  Older database
    // versions will be migrated via ensureExtraTaskColumns().
    await db.execute('''
      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT UNIQUE,
        name TEXT,
        type TEXT,          -- manual | auto | carousel
        status TEXT,        -- on | off
        prompt TEXT,        -- for auto
        avatar_path TEXT,   -- icon path
        start_time TEXT,    -- 'HH:mm' or 'YYYY-MM-DD HH:mm[:ss]'
        freq_type TEXT,     -- daily | weekly | monthly | custom
        freq_weekday INTEGER,       -- 1-7 (Mon-Sun) when weekly
        freq_day_of_month INTEGER,  -- 1-31 when monthly
        freq_custom TEXT,            -- reserved
        next_time TEXT,              -- ISO8601 next run time
        scheduled_run_key TEXT       -- last scheduled runKey for cancellation
      )
    ''');

    // Quotes
    await db.execute('''
      CREATE TABLE quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_uid TEXT UNIQUE,
        task_uid TEXT,
        content TEXT,
        notified INTEGER DEFAULT 0,
        created_at INTEGER,
        FOREIGN KEY(task_uid) REFERENCES tasks(task_uid) ON DELETE CASCADE
      )
    ''');

    // Logs
    await db.execute('''
      CREATE TABLE logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_uid TEXT UNIQUE,
        task_uid TEXT,
        detail TEXT,
        created_at INTEGER,
        task_name_snapshot TEXT,
        task_start_time_snapshot TEXT
      )
    ''');
  }

  static Future<void> _ensureMeta(Database db) async {
    // placeholder if future migrations need to alter meta schema
  }

  static Future<void> _upgrade(Database db, int oldV, int newV) async {
    if (oldV < 5) {
      // Best-effort ensure required tables/columns exist
      await db.execute("CREATE TABLE IF NOT EXISTS configs (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT, model TEXT, endpoint TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT UNIQUE, name TEXT, type TEXT, status TEXT, prompt TEXT, avatar_path TEXT, start_time TEXT, freq_type TEXT, freq_weekday INTEGER, freq_day_of_month INTEGER, freq_custom TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, quote_uid TEXT UNIQUE, task_uid TEXT, content TEXT, notified INTEGER DEFAULT 0, created_at INTEGER)");
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT, created_at INTEGER, task_name_snapshot TEXT, task_start_time_snapshot TEXT)");

      // === Ensure standardized schema (backward compatible) ===
      // Logs: id AUTOINCREMENT, log_uid PRIMARY KEY, task_uid (FK, nullable, ON DELETE SET NULL), detail
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT)");
      // Ensure required columns exist
      BEGIN TRANSACTION;
      CREATE TABLE IF NOT EXISTS _tmp_check (x INTEGER);
      COMMIT;
      // quotes: add required columns if missing
      var infoQuotes = await db.rawQuery("PRAGMA table_info(quotes)");
      var colsQuotes = infoQuotes.map((e)=> e['name'] as String).toList();
      if (!colsQuotes.contains('quote_uid')) { await db.execute("ALTER TABLE quotes ADD COLUMN quote_uid TEXT"); }
      if (!colsQuotes.contains('task_uid'))  { await db.execute("ALTER TABLE quotes ADD COLUMN task_uid TEXT"); }
      if (!colsQuotes.contains('task_type')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT"); }
      if (!colsQuotes.contains('task_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT"); }
      if (!colsQuotes.contains('avatar'))    { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
      if (!colsQuotes.contains('notified'))  { await db.execute("ALTER TABLE quotes ADD COLUMN notified INTEGER DEFAULT 0"); }
      // unique for content
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_content ON quotes(content)";
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_uid ON quotes(quote_uid)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_tasks_uid ON tasks(task_uid)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_logs_uid ON logs(log_uid)"));
      // tasks: ensure required columns
      var infoTasks = await db.rawQuery("PRAGMA table_info(tasks)");
      var colsTasks = infoTasks.map((e)=> e['name'] as String).toList();
      if (!colsTasks.contains('task_uid'))   { await db.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT"); }
      if (!colsTasks.contains('name'))       { await db.execute("ALTER TABLE tasks ADD COLUMN name TEXT"); }
      if (!colsTasks.contains('task_type'))  { await db.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT"); }
      if (!colsTasks.contains('start_time')) { await db.execute("ALTER TABLE tasks ADD COLUMN start_time TEXT"); }
      if (!colsTasks.contains('prompt'))     { await db.execute("ALTER TABLE tasks ADD COLUMN prompt TEXT"); }
      if (!colsTasks.contains('avatar'))     { await db.execute("ALTER TABLE tasks ADD COLUMN avatar TEXT"); }
      if (!colsTasks.contains('status'))     { await db.execute("ALTER TABLE tasks ADD COLUMN status TEXT"); }
      // configs: ensure required columns (notice_id aka id, api_key, bg_image, model, endpoint)
      var infoCfg = await db.rawQuery("PRAGMA table_info(configs)");
      var colsCfg = infoCfg.map((e)=> e['name'] as String).toList();
      if (!colsCfg.contains('bg_image'))     { await db.execute("ALTER TABLE configs ADD COLUMN bg_image TEXT"); }
      // Foreign key relationships (best-effort: create views/triggers if needed)
      await db.execute("PRAGMA foreign_keys=ON");
      // Ensure snapshots columns
      final info = await db.rawQuery("PRAGMA table_info(logs)");
      final cols = info.map((e)=> e['name'] as String).toList();
      if (!cols.contains('task_name_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_name_snapshot TEXT");
      }
      if (!cols.contains('task_start_time_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_start_time_snapshot TEXT");
      }
    }
  }
}
