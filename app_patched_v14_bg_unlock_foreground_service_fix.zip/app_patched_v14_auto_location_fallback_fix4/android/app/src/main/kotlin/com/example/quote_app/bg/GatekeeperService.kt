package com.example.quote_app.bg

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.GeoWorker
import com.example.quote_app.data.DbRepo

class GatekeeperService : Service() {
    private val channelId = "gatekeeper_fg"
    private val channelName = "Gatekeeper Service"
    private var screenReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(11, buildKeepAliveNotification())

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_USER_UNLOCKED)
        }
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                try {
                    val act = intent.action
                    if (act == Intent.ACTION_SCREEN_ON ||
                        act == Intent.ACTION_USER_PRESENT ||
                        act == Intent.ACTION_USER_UNLOCKED) {
                        try { DbRepo.log(context, null, "正在解锁屏幕将触发通知发送") } catch (_: Throwable) {}
                        try {
                            val req = OneTimeWorkRequestBuilder<GeoWorker>()
                                .setInputData(androidx.work.Data.Builder().putBoolean("force_unlock_geo", true).build())
                                .build()
                            WorkManager.getInstance(context).enqueue(req)
                        } catch (_: Throwable) {}
                    }
                } catch (_: Throwable) {}
            }
        }
        try { registerReceiver(screenReceiver, f) } catch (_: Throwable) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildKeepAliveNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            packageManager.getLaunchIntentForPackage(packageName),
            if (Build.VERSION.SDK_INT >= 23)
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else
                PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("后台守护已开启")
            .setContentText("用于提升锁屏/解锁/位置比对提醒的稳定性")
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }
}
