import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

class LocationService {
  static Future<void> showFailureToast(String msg) async {
    try {
      await _sysCh.invokeMethod('showToast', {'message': msg});
    } catch (_){}
  }

  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 百度SDK优先 -> 失败回退系统定位（高精度）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    try { await DLog.i('LocationService', '【定位】优先使用百度SDK定位（目标≤30m），失败回退系统定位'); } catch (_){}
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        unawaited(_logNearbyLandmarkIfPossible(bd));
        if (bd.accuracy <= 30) return bd;
        // 如果百度返回但精度>30m，则继续等待系统高精度流至≤30m
        try { await DLog.w('LocationService', '【定位】Baidu返回但精度 ' + bd.accuracy.toString() + 'm，大于30m，回退系统流继续获取'); } catch (_){}
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：' + e.toString()); } catch (_){}
    }
    final sys = await _systemLocationOnce();
    if (sys != null) {
      unawaited(_logNearbyLandmarkIfPossible(sys));
      return sys;
    }
    try {
      await DLog.e('LocationService', '【定位】两种方式均失败');
    } catch (_){}
    return null;
  }
