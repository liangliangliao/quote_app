import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/kv_dao.dart';

class HideSeekPage extends StatefulWidget {
  const HideSeekPage({super.key});

  @override
  State<HideSeekPage> createState() => _HideSeekPageState();
}

enum _ArrivalState { notArrived, cannotConfirm, confirming, strictArrived }

enum _GuideMode { routeGuide, finalGuide, arrived }

enum _RadarOrientationMode { northUp, headingUp }

class _PoiCandidate {
  final String name;
  final String address;
  final double lat;
  final double lon;
  final double? entranceLat;
  final double? entranceLon;

  const _PoiCandidate({
    required this.name,
    required this.address,
    required this.lat,
    required this.lon,
    this.entranceLat,
    this.entranceLon,
  });

  double get targetLat => entranceLat ?? lat;
  double get targetLon => entranceLon ?? lon;

  String get targetSource => (entranceLat != null && entranceLon != null) ? '入口点' : 'POI点';

  static _PoiCandidate? fromAmap(Map<String, dynamic> m) {
    final loc = (m['location'] ?? '').toString();
    final entr = (m['entr_location'] ?? '').toString();
    final ll = _parseLonLat(loc);
    if (ll == null) return null;
    final ent = _parseLonLat(entr);
    return _PoiCandidate(
      name: (m['name'] ?? '').toString().trim(),
      address: ((m['address'] ?? '').toString().trim().isNotEmpty)
          ? (m['address'] ?? '').toString().trim()
          : (m['pname'] ?? '').toString().trim(),
      lon: ll.$1,
      lat: ll.$2,
      entranceLon: ent?.$1,
      entranceLat: ent?.$2,
    );
  }

  static (double, double)? _parseLonLat(String s) {
    if (s.isEmpty) return null;
    final parts = s.split(',');
    if (parts.length != 2) return null;
    final lon = double.tryParse(parts[0]);
    final lat = double.tryParse(parts[1]);
    if (lon == null || lat == null) return null;
    return (lon, lat);
  }
}

class _SavedTargetItem {
  final _PoiCandidate poi;
  final int savedAtMs;
  final String kind; // calibration / recent

  const _SavedTargetItem({required this.poi, required this.savedAtMs, required this.kind});

  Map<String, dynamic> toJson() => {
        'kind': kind,
        'savedAtMs': savedAtMs,
        'name': poi.name,
        'address': poi.address,
        'lat': poi.lat,
        'lon': poi.lon,
        'entranceLat': poi.entranceLat,
        'entranceLon': poi.entranceLon,
      };

  static _SavedTargetItem? fromJson(Map<String, dynamic> m) {
    final lat = _NativeAmapFix._toDouble(m['lat']);
    final lon = _NativeAmapFix._toDouble(m['lon']);
    if (lat == null || lon == null) return null;
    return _SavedTargetItem(
      kind: (m['kind'] ?? 'recent').toString(),
      savedAtMs: _NativeAmapFix._toInt(m['savedAtMs']) ?? DateTime.now().millisecondsSinceEpoch,
      poi: _PoiCandidate(
        name: (m['name'] ?? '').toString(),
        address: (m['address'] ?? '').toString(),
        lat: lat,
        lon: lon,
        entranceLat: _NativeAmapFix._toDouble(m['entranceLat']),
        entranceLon: _NativeAmapFix._toDouble(m['entranceLon']),
      ),
    );
  }

  String get labelTime {
    final dt = DateTime.fromMillisecondsSinceEpoch(savedAtMs);
    String two(int v) => v.toString().padLeft(2, '0');
    return '${dt.month}-${dt.day} ${two(dt.hour)}:${two(dt.minute)}';
  }
}

class _NativeAmapFix {
  final double lat;
  final double lon;
  final double accuracy;
  final double bearing;
  final double speed;
  final int errorCode;
  final String errorInfo;
  final String coordType;
  final int? locationType;
  final int? timeMs;
  final double? sensorHeading;
  final int? sensorAccuracyLevel;
  final int? screenRotation;

  const _NativeAmapFix({
    required this.lat,
    required this.lon,
    required this.accuracy,
    required this.bearing,
    required this.speed,
    required this.errorCode,
    required this.errorInfo,
    required this.coordType,
    this.locationType,
    this.timeMs,
    this.sensorHeading,
    this.sensorAccuracyLevel,
    this.screenRotation,
  });

  static _NativeAmapFix? fromEvent(dynamic e) {
    if (e is! Map) return null;
    final m = Map<String, dynamic>.from(e);
    if ((m['type'] ?? 'location').toString() != 'location') return null;
    final lat = _toDouble(m['lat']);
    final lon = _toDouble(m['lng']);
    if (lat == null || lon == null) return null;
    return _NativeAmapFix(
      lat: lat,
      lon: lon,
      accuracy: _toDouble(m['accuracy']) ?? double.nan,
      bearing: _normHeading(_toDouble(m['bearing'])),
      speed: _toDouble(m['speed']) ?? double.nan,
      errorCode: _toInt(m['errorCode']) ?? 0,
      errorInfo: (m['errorInfo'] ?? '').toString(),
      coordType: (m['coordType'] ?? '').toString(),
      locationType: _toInt(m['locationType']),
      timeMs: _toInt(m['time']),
      sensorHeading: _normHeadingNullable(_toDouble(m['sensorHeading'])),
      sensorAccuracyLevel: _toInt(m['sensorAccuracyLevel']),
      screenRotation: _toInt(m['screenRotation']),
    );
  }

  static double? _toDouble(Object? v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }

  static int? _toInt(Object? v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString());
  }

  static double _normHeading(double? v) {
    if (v == null || !v.isFinite) return double.nan;
    var x = v % 360.0;
    if (x < 0) x += 360.0;
    return x;
  }

  static double? _normHeadingNullable(double? v) {
    if (v == null || !v.isFinite) return null;
    var x = v % 360.0;
    if (x < 0) x += 360.0;
    return x;
  }
}

class _HideSeekPageState extends State<HideSeekPage> {
  final _kv = KeyValueDao();
  final _queryCtrl = TextEditingController();
  final _webKeyOverrideCtrl = TextEditingController();

  static const _amapLocEvent = EventChannel('com.example.quote_app/amap_location');
  static const _amapControl = MethodChannel('com.example.quote_app/amap_control');

  String _savedAmapWebKey = '';
  String _savedAmapAndroidKey = '';
  bool _loadingKeys = true;
  bool _searching = false;
  String? _error;

  List<_PoiCandidate> _candidates = const [];
  _PoiCandidate? _target;

  StreamSubscription<Position>? _posSub;
  StreamSubscription<dynamic>? _amapSub;
  Position? _position;
  _NativeAmapFix? _amapFix;
  bool _useAmapNative = false;
  bool _amapConfigured = false;
  bool _amapBgEnabled = false;
  String _lastNativeStatus = '--';

  // 显示稳定化：原地抖动抑制 + 平滑（不影响严格5m判定的原始样本）
  double? _uiLatF;
  double? _uiLonF;
  double? _uiAccF;
  double? _uiHeadingF;
  String _uiHeadingSource = '--';
  int? _sensorAccuracyLevel;
  int? _sensorScreenRotation;
  bool _showRawDebugValues = false;
  DateTime? _lastSensorCalibHintAt;
  bool _uiStillHold = false;
  int _uiStillTicks = 0;

  // 显示冻结：原地不动时锁定“用户看到”的坐标/距离/方向（原始样本仍持续接收）
  bool _displayFrozen = false;
  int _freezeCandidateTicks = 0;
  int _unfreezeCandidateTicks = 0;
  double? _frozenLat;
  double? _frozenLon;
  double? _frozenAcc;
  double? _frozenHeading;
  DateTime? _displayFrozenAt;

  // 雷达显示平滑与自动量程滞回
  ({double dE, double dN})? _radarDeltaSmoothed;
  double _radarAutoRangeSticky = 60.0;

  bool _locating = false;
  int _strictOkStreak = 0;
  static const int _strictNeedStreak = 5;
  String _stableDir = '--';
  String _pendingDir = '--';
  int _pendingDirCount = 0;

  bool _enteredOuter150 = false;
  bool _enteredInner30 = false;
  bool _strictArrivedNotified = false;
  DateTime? _lastGuideToastAt;
  _GuideMode _guideMode = _GuideMode.routeGuide;

  // 语音播报（TTS）+ 最后20m微调策略
  final FlutterTts _tts = FlutterTts();
  bool _ttsEnabled = true;
  bool _ttsReady = false;
  DateTime? _lastTtsAt;
  String _lastSpokenGuide = '';
  String _fineStableDir = '--';
  String _finePendingDir = '--';
  int _finePendingDirCount = 0;
  String _microHint = '--';
  DateTime? _lastLowAccuracyHintAt;

  // 雷达显示增强：真北/朝向锁定 + 自动缩放；到点振动反馈
  _RadarOrientationMode _radarOrientation = _RadarOrientationMode.northUp;
  bool _radarAutoScale = true;
  double _radarManualRangeMeters = 60;
  bool _vibrationEnabled = true;
  DateTime? _lastVibrateAt;

  // 本地历史与弱网兜底缓存
  static const String _kHsTargetHistory = 'hide_seek_target_history_v1';
  static const String _kHsLastSearchCache = 'hide_seek_last_search_cache_v1';
  static const String _kHsLastTarget = 'hide_seek_last_target_v1';
  List<_SavedTargetItem> _savedTargetHistory = const [];
  _SavedTargetItem? _lastTargetCache;
  String _cacheInfo = '--';
  bool _buzzingPattern = false;

  @override
  void initState() {
    super.initState();
    _initTts();
    _loadKeys();
    _loadLocalHideSeekCache();
    _startLocation();
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _amapSub?.cancel();
    if (_useAmapNative) {
      try {
        _amapControl.invokeMethod('stop');
      } catch (_) {}
    }
    try { _tts.stop(); } catch (_) {}
    _queryCtrl.dispose();
    _webKeyOverrideCtrl.dispose();
    super.dispose();
  }

  bool get _isAndroid => !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  Future<void> _initTts() async {
    try {
      await _tts.setLanguage('zh-CN');
      await _tts.setSpeechRate(0.48);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
      _tts.setStartHandler(() {
        _ttsReady = true;
      });
      _tts.setCompletionHandler(() {});
      _tts.setErrorHandler((_) {});
      _ttsReady = true;
    } catch (_) {
      _ttsReady = false;
    }
  }

  Future<void> _loadLocalHideSeekCache() async {
    try {
      final histRaw = await _kv.getString(_kHsTargetHistory);
      final lastTargetRaw = await _kv.getString(_kHsLastTarget);
      final searchCacheRaw = await _kv.getString(_kHsLastSearchCache);
      final hist = <_SavedTargetItem>[];
      if (histRaw != null && histRaw.isNotEmpty) {
        final obj = jsonDecode(histRaw);
        if (obj is List) {
          for (final e in obj) {
            if (e is Map) {
              final item = _SavedTargetItem.fromJson(Map<String, dynamic>.from(e));
              if (item != null) hist.add(item);
            }
          }
        }
      }
      _SavedTargetItem? last;
      if (lastTargetRaw != null && lastTargetRaw.isNotEmpty) {
        final obj = jsonDecode(lastTargetRaw);
        if (obj is Map) {
          last = _SavedTargetItem.fromJson(Map<String, dynamic>.from(obj));
        }
      }
      String cacheInfo = '--';
      if (searchCacheRaw != null && searchCacheRaw.isNotEmpty) {
        final obj = jsonDecode(searchCacheRaw);
        if (obj is Map) {
          final q = (obj['query'] ?? '').toString();
          final ts = _NativeAmapFix._toInt(obj['savedAtMs']);
          if (q.isNotEmpty && ts != null) {
            final dt = DateTime.fromMillisecondsSinceEpoch(ts);
            cacheInfo = '最近搜索缓存：$q（${dt.month}-${dt.day} ${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}）';
          }
        }
      }
      if (!mounted) return;
      setState(() {
        _savedTargetHistory = hist;
        _lastTargetCache = last;
        _cacheInfo = cacheInfo;
      });
    } catch (_) {}
  }

  Future<void> _persistTargetHistory() async {
    try {
      final raw = jsonEncode(_savedTargetHistory.map((e) => e.toJson()).toList(growable: false));
      await _kv.setString(_kHsTargetHistory, raw);
    } catch (_) {}
  }

  Future<void> _cacheLastTarget(_PoiCandidate poi, {String kind = 'recent'}) async {
    try {
      final item = _SavedTargetItem(
        poi: poi,
        savedAtMs: DateTime.now().millisecondsSinceEpoch,
        kind: kind,
      );
      await _kv.setString(_kHsLastTarget, jsonEncode(item.toJson()));
      if (mounted) {
        setState(() {
          _lastTargetCache = item;
        });
      }
    } catch (_) {}
  }

  Future<void> _cacheSearchResults(String query, List<_PoiCandidate> items) async {
    try {
      final payload = {
        'query': query,
        'savedAtMs': DateTime.now().millisecondsSinceEpoch,
        'pois': items.take(12).map((e) => {
          'name': e.name,
          'address': e.address,
          'lat': e.lat,
          'lon': e.lon,
          'entranceLat': e.entranceLat,
          'entranceLon': e.entranceLon,
        }).toList(growable: false),
      };
      await _kv.setString(_kHsLastSearchCache, jsonEncode(payload));
      if (mounted) {
        setState(() {
          _cacheInfo = '最近搜索缓存：$query（刚刚）';
        });
      }
    } catch (_) {}
  }

  Future<List<_PoiCandidate>> _loadSearchCacheFallback(String query) async {
    try {
      final raw = await _kv.getString(_kHsLastSearchCache);
      if (raw == null || raw.isEmpty) return const [];
      final obj = jsonDecode(raw);
      if (obj is! Map) return const [];
      final cachedQ = (obj['query'] ?? '').toString().trim();
      final q = query.trim();
      if (q.isNotEmpty && cachedQ.isNotEmpty) {
        final a = q.toLowerCase();
        final b = cachedQ.toLowerCase();
        if (!(a.contains(b) || b.contains(a))) {
          // query不相近时，仍允许继续兜底，但优先级降低
        }
      }
      final pois = (obj['pois'] as List?) ?? const [];
      final out = <_PoiCandidate>[];
      for (final e in pois) {
        if (e is Map) {
          final item = _SavedTargetItem.fromJson(Map<String, dynamic>.from({...e, 'savedAtMs': 0, 'kind': 'recent'}));
          if (item != null) out.add(item.poi);
        }
      }
      return out;
    } catch (_) {
      return const [];
    }
  }

  Future<void> _saveCalibrationPointFromCurrentLocation() async {
    final lat = _curLat;
    final lon = _curLon;
    if (lat == null || lon == null) {
      _toast('还没有当前位置，无法保存门口校准点');
      return;
    }
    final base = _target;
    final poi = _PoiCandidate(
      name: ((base?.name ?? '').trim().isEmpty ? '门口校准点' : '${base!.name}（门口校准）'),
      address: base == null ? '用户手动保存' : '${base.address} · 门口校准',
      lat: lat,
      lon: lon,
    );
    final item = _SavedTargetItem(
      poi: poi,
      savedAtMs: DateTime.now().millisecondsSinceEpoch,
      kind: 'calibration',
    );
    final next = <_SavedTargetItem>[item];
    for (final e in _savedTargetHistory) {
      final near = Geolocator.distanceBetween(e.poi.targetLat, e.poi.targetLon, poi.targetLat, poi.targetLon) <= 8;
      final sameName = e.poi.name == poi.name;
      if (!(near && sameName)) next.add(e);
    }
    if (next.length > 20) next.removeRange(20, next.length);
    if (mounted) {
      setState(() {
        _savedTargetHistory = next;
      });
    }
    await _persistTargetHistory();
    await _cacheLastTarget(poi, kind: 'calibration');
    _toast('已保存门口校准点（可在历史中直接复用）');
  }

  Future<void> _useLastCachedTarget() async {
    final item = _lastTargetCache;
    if (item == null) {
      _toast('暂无最近目标缓存');
      return;
    }
    if (!mounted) return;
    setState(() {
      _setTarget(item.poi);
    });
    _toast('已使用最近目标缓存');
  }

  Future<void> _loadKeys() async {
    try {
      final web = await _kv.getString('amap_key_web');
      final androidKey = await _kv.getString('amap_key_android');
      if (!mounted) return;
      setState(() {
        _savedAmapWebKey = (web ?? '').trim();
        _savedAmapAndroidKey = (androidKey ?? '').trim();
        _loadingKeys = false;
      });
      await _maybeSwitchToAmapNative();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingKeys = false;
        _error = '读取高德Key失败：$e';
      });
    }
  }

  Future<void> _maybeSwitchToAmapNative() async {
    if (!_isAndroid) return;
    if (_savedAmapAndroidKey.isEmpty) return;
    if (_useAmapNative) {
      await _configureAmapNative();
      return;
    }
    final ok = await _startAmapNative();
    if (ok) {
      await _posSub?.cancel();
      _posSub = null;
      if (mounted) {
        _toast('已切换到高德原生定位 SDK');
      }
    }
  }

  Future<void> _startLocation() async {
    if (_isAndroid && _savedAmapAndroidKey.isNotEmpty) {
      final ok = await _startAmapNative();
      if (ok) return;
    }
    await _startSystemLocation();
  }

  Future<void> _startSystemLocation() async {
    setState(() {
      _locating = true;
      _error = null;
      _useAmapNative = false;
    });
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        throw Exception('定位服务未开启');
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw Exception('未授予定位权限');
      }

      await _posSub?.cancel();
      final settings = const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 0,
      );
      _posSub = Geolocator.getPositionStream(locationSettings: settings).listen((p) {
        _handleLocationSample(
          lat: p.latitude,
          lon: p.longitude,
          accuracy: p.accuracy,
          heading: p.heading,
          coordType: 'WGS84(?)',
          source: '系统定位',
          speed: p.speed,
        );
        if (!mounted) return;
        setState(() {
          _position = p;
          _locating = false;
          if (!_useAmapNative) _error = null;
        });
      }, onError: (e) {
        if (!mounted) return;
        setState(() {
          _error = '定位流异常：$e';
          _locating = false;
        });
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _locating = false;
      });
    }
  }

  Future<bool> _startAmapNative() async {
    if (!_isAndroid) return false;
    if (_savedAmapAndroidKey.trim().isEmpty) return false;
    setState(() {
      _locating = true;
      _error = null;
    });
    try {
      if (_amapSub == null) {
        _amapSub = _amapLocEvent.receiveBroadcastStream().listen(_onAmapEvent, onError: (e) {
          if (!mounted) return;
          setState(() {
            _error = '高德定位事件异常：$e';
            _locating = false;
          });
        });
      }
      await _configureAmapNative();
      await _amapControl.invokeMethod('start');
      if (!mounted) return true;
      setState(() {
        _useAmapNative = true;
        _amapConfigured = true;
      });
      return true;
    } on PlatformException catch (e) {
      if (!mounted) return false;
      setState(() {
        _error = '高德原生定位启动失败：${e.message ?? e.code}';
        _locating = false;
      });
      return false;
    } catch (e) {
      if (!mounted) return false;
      setState(() {
        _error = '高德原生定位启动失败：$e';
        _locating = false;
      });
      return false;
    }
  }

  Future<void> _configureAmapNative() async {
    if (!_isAndroid || _savedAmapAndroidKey.trim().isEmpty) return;
    await _amapControl.invokeMethod('configure', {
      'apiKey': _savedAmapAndroidKey.trim(),
      'intervalMs': 1000,
      'needAddress': false,
      'notificationId': 11023,
    });
    _amapConfigured = true;
  }

  void _onAmapEvent(dynamic event) {
    if (event is! Map) return;
    final m = Map<String, dynamic>.from(event);
    final type = (m['type'] ?? 'location').toString();
    if (type == 'status') {
      if (!mounted) return;
      setState(() {
        _lastNativeStatus = (m['status'] ?? '--').toString();
        final bg = m['background'];
        if (bg is bool) _amapBgEnabled = bg;
      });
      return;
    }

    final fix = _NativeAmapFix.fromEvent(m);
    if (fix == null) return;
    if (fix.errorCode != 0) {
      if (!mounted) return;
      setState(() {
        _error = '高德定位错误(${fix.errorCode})：${fix.errorInfo}';
        _locating = false;
      });
      return;
    }

    _handleLocationSample(
      lat: fix.lat,
      lon: fix.lon,
      accuracy: fix.accuracy,
      heading: fix.bearing,
      sensorHeading: fix.sensorHeading,
      coordType: fix.coordType.isEmpty ? 'GCJ02(?)' : fix.coordType,
      source: '高德原生定位',
      speed: fix.speed,
    );

    _maybeShowSensorCalibrationHint(fix);
    if (!mounted) return;
    setState(() {
      _amapFix = fix;
      _sensorAccuracyLevel = fix.sensorAccuracyLevel;
      _sensorScreenRotation = fix.screenRotation;
      _useAmapNative = true;
      _locating = false;
      _error = null;
    });
  }

  Future<void> _toggleAmapBackground() async {
    if (!_isAndroid || !_useAmapNative) {
      _toast('仅高德原生定位模式支持后台定位通知');
      return;
    }
    try {
      if (_amapBgEnabled) {
        await _amapControl.invokeMethod('disableBackground', {'removeNotification': true});
        if (mounted) setState(() => _amapBgEnabled = false);
        _toast('已关闭后台定位通知');
      } else {
        await _amapControl.invokeMethod('enableBackground', {
          'title': '捉迷藏定位进行中',
          'text': '持续定位中（用于严格5m到达判定）',
          'notificationId': 11023,
        });
        if (mounted) setState(() => _amapBgEnabled = true);
        _toast('已开启后台定位通知');
      }
    } on PlatformException catch (e) {
      _toast('后台定位切换失败：${e.message ?? e.code}');
    } catch (e) {
      _toast('后台定位切换失败：$e');
    }
  }

  void _handleLocationSample({
    required double lat,
    required double lon,
    required double accuracy,
    required double heading,
    double? sensorHeading,
    required String coordType,
    required String source,
    double? speed,
  }) {
    final d = _distanceToTargetMetersFrom(lat: lat, lon: lon);
    final okNow = d != null && d <= 5.0 && accuracy <= 10.0;
    if (okNow) {
      _strictOkStreak += 1;
    } else {
      _strictOkStreak = 0;
    }

    final headingResolved = _resolveDisplayHeading(
      courseHeading: heading,
      sensorHeading: sensorHeading,
      speed: speed,
    );
    final fusedHeading = headingResolved.$1;
    _uiHeadingSource = headingResolved.$2;

    _updateUiStabilizedPosition(
      rawLat: lat,
      rawLon: lon,
      rawAccuracy: accuracy,
      heading: fusedHeading,
      speed: speed,
    );
    _updateDisplayFreezeState(
      rawLat: lat,
      rawLon: lon,
      rawAccuracy: accuracy,
      rawHeading: fusedHeading,
      speed: speed,
    );
    _updateRadarDisplaySmoothing();
    _updateRadarAutoRange(d: _distanceToTargetMeters(), acc: _uiAccuracy ?? accuracy);

    _updateStableDirectionValues(
      lat: _uiLat ?? lat,
      lon: _uiLon ?? lon,
      heading: _uiHeading ?? fusedHeading,
    );
    _updateGuidePhaseAndReminders(
      lat: lat,
      lon: lon,
      accuracy: accuracy,
      heading: fusedHeading,
      source: source,
      coordType: coordType,
      speed: speed,
    );
  }

  void _updateGuidePhaseAndReminders({
    required double lat,
    required double lon,
    required double accuracy,
    required double heading,
    required String source,
    required String coordType,
    double? speed,
  }) {
    final uiLat = _uiLat ?? lat;
    final uiLon = _uiLon ?? lon;
    final uiAcc = _uiAccuracy ?? accuracy;
    final uiHeading = _uiHeading ?? heading;
    final d = _distanceToTargetMetersFrom(lat: uiLat, lon: uiLon);
    if (d == null) {
      _guideMode = _GuideMode.routeGuide;
      return;
    }

    if (d <= 150 && !_enteredOuter150) {
      _enteredOuter150 = true;
      _toast('已进入 150m 范围：准备进入最后引导');
      _buzzPatternStage('outer150');
    }
    if (d <= 30 && !_enteredInner30) {
      _enteredInner30 = true;
      _toast('已进入 30m 范围：开始最后引导（左/右/前/后）');
      _buzzPatternStage('inner30');
    }

    final arrival = _arrivalStateWith(d: d, accuracy: uiAcc);
    var justStrictArrived = false;
    if (arrival == _ArrivalState.strictArrived && !_strictArrivedNotified) {
      _strictArrivedNotified = true;
      justStrictArrived = true;
      _toast('✅ 已严格到达目标（5m）');
      _buzzPatternStage('strict5', force: true);
    }

    if (arrival == _ArrivalState.strictArrived) {
      _guideMode = _GuideMode.arrived;
      _microHint = '已满足严格到达条件（5m，且精度达标并稳定）';
      if (justStrictArrived) {
        _speakGuide('已严格到达目标点', force: true);
      }
    } else if (d <= 50) {
      _guideMode = _GuideMode.finalGuide;
      _microHint = _buildMicroHint(
        d: d,
        accuracy: uiAcc,
        heading: uiHeading,
        lat: uiLat,
        lon: uiLon,
        speed: speed,
      );
      if ((uiAcc > 12 || !uiAcc.isFinite)) {
        final now = DateTime.now();
        if (_lastLowAccuracyHintAt == null || now.difference(_lastLowAccuracyHintAt!) >= const Duration(seconds: 10)) {
          _lastLowAccuracyHintAt = now;
          _toast('最后引导中：当前定位精度±${uiAcc.toStringAsFixed(0)}m，建议稍等收敛再做微调');
        }
      }
      final now = DateTime.now();
      final canToast = _lastGuideToastAt == null || now.difference(_lastGuideToastAt!) >= const Duration(seconds: 5);
      if (canToast && _target != null) {
        _lastGuideToastAt = now;
        final dir = _fineStableDir != '--'
            ? _fineStableDir
            : (_stableDir == '--' ? '前方/右侧请缓慢移动观察' : _stableDir);
        final hint = '最后引导：目标在$dir，约 ${d.toStringAsFixed(0)}m（$source, $coordType, ±${uiAcc.toStringAsFixed(0)}m）';
        _toast(hint);
      }
      if (d <= 20 && uiAcc <= 12) { _buzzPatternStage('final20'); }
      _speakGuide(_buildVoiceHint(d: d, accuracy: uiAcc, speed: speed));
    } else {
      _guideMode = _GuideMode.routeGuide;
      _microHint = '--';
    }
  }

  String get _effectiveWebKey {
    final manual = _webKeyOverrideCtrl.text.trim();
    return manual.isNotEmpty ? manual : _savedAmapWebKey;
  }

  Future<void> _searchPoi() async {
    final q = _queryCtrl.text.trim();
    final key = _effectiveWebKey;
    if (q.isEmpty) {
      _toast('请输入超市名或地址');
      return;
    }
    if (key.isEmpty) {
      _toast('请先在设置页填写高德 Web Key');
      return;
    }
    setState(() {
      _searching = true;
      _error = null;
      _candidates = const [];
    });
    try {
      final uri = Uri.https('restapi.amap.com', '/v3/place/text', {
        'key': key,
        'keywords': q,
        'offset': '8',
        'page': '1',
        'extensions': 'all',
      });
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}');
      }
      final data = jsonDecode(res.body);
      if (data is! Map<String, dynamic>) throw Exception('响应格式错误');
      final status = (data['status'] ?? '').toString();
      if (status != '1') {
        throw Exception((data['info'] ?? '高德接口失败').toString());
      }
      final pois = (data['pois'] as List?) ?? const [];
      final items = <_PoiCandidate>[];
      for (final e in pois) {
        if (e is Map<String, dynamic>) {
          final p = _PoiCandidate.fromAmap(e);
          if (p != null) items.add(p);
        } else if (e is Map) {
          final p = _PoiCandidate.fromAmap(Map<String, dynamic>.from(e));
          if (p != null) items.add(p);
        }
      }
      if (items.isNotEmpty) {
        await _cacheSearchResults(q, items);
      }
      if (!mounted) return;
      setState(() {
        _candidates = items;
        if (items.isNotEmpty) {
          _setTarget(items.first);
        }
        _searching = false;
      });
      if (items.isEmpty) _toast('没有找到结果');
    } catch (e) {
      final cached = await _loadSearchCacheFallback(q);
      if (!mounted) return;
      if (cached.isNotEmpty) {
        setState(() {
          _searching = false;
          _error = '搜索失败，已切换到本地缓存结果：$e';
          _candidates = cached;
          _setTarget(cached.first);
        });
        _toast('弱网/无网兜底：已使用最近缓存目标');
        return;
      }
      setState(() {
        _searching = false;
        _error = '搜索失败：$e';
      });
    }
  }

  void _setTarget(_PoiCandidate c) {
    _target = c;
    _strictOkStreak = 0;
    _stableDir = '--';
    _pendingDir = '--';
    _pendingDirCount = 0;
    _fineStableDir = '--';
    _finePendingDir = '--';
    _finePendingDirCount = 0;
    _microHint = '--';
    _enteredOuter150 = false;
    _enteredInner30 = false;
    _strictArrivedNotified = false;
    _lastGuideToastAt = null;
    _guideMode = _GuideMode.routeGuide;
    _radarDeltaSmoothed = null;
    _radarAutoRangeSticky = 60.0;
    unawaited(_cacheLastTarget(c, kind: 'recent'));
  }

  static bool _isValidHeading(double? h) => h != null && h.isFinite && h >= 0;

  static double _normDeg(double v) {
    var x = v % 360.0;
    if (x < 0) x += 360.0;
    return x;
  }

  static double _lerpNum(double a, double b, double t) => a + (b - a) * t;

  static double _lerpAngleDeg(double from, double to, double t) {
    final f = _normDeg(from);
    final tt = _normDeg(to);
    var delta = tt - f;
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;
    return _normDeg(f + delta * t);
  }

  bool _isSensorCalibPoor([int? level]) {
    final v = level ?? _sensorAccuracyLevel;
    if (v == null) return false;
    return v <= 1;
  }

  String _sensorAccuracyLabel([int? level]) {
    final v = level ?? _sensorAccuracyLevel;
    switch (v) {
      case 3:
        return '高（罗盘稳定）';
      case 2:
        return '中（可用）';
      case 1:
        return '低（建议校准）';
      case 0:
        return '不可靠（请校准/远离磁干扰）';
      case -1:
        return '未上报';
      default:
        return v == null ? '--' : '级别$v';
    }
  }

  String _screenRotationLabel([int? rotation]) {
    switch (rotation ?? _sensorScreenRotation) {
      case 0:
        return '竖屏(0°)';
      case 1:
        return '横屏右(90°)';
      case 2:
        return '倒置(180°)';
      case 3:
        return '横屏左(270°)';
      default:
        return '--';
    }
  }

  String _compassCalibrationHintText() {
    final l = _sensorAccuracyLevel;
    if (l == null) return '正在读取设备朝向传感器状态…';
    if (l <= 0) {
      return '指南针状态不可靠：请手持手机做“8”字校准，远离磁吸壳/金属桌面。';
    }
    if (l == 1) {
      return '指南针精度较低：建议做“8”字校准，最后20m找点会更稳。';
    }
    if (l == 2) {
      return '指南针精度中等：可用；若方向偶尔飘，可做“8”字校准提升稳定性。';
    }
    return '指南针精度良好。';
  }

  void _maybeShowSensorCalibrationHint(_NativeAmapFix fix) {
    final level = fix.sensorAccuracyLevel;
    if (level == null) return;
    _sensorAccuracyLevel = level;
    _sensorScreenRotation = fix.screenRotation;
    if (level <= 1 && _isValidHeading(fix.sensorHeading)) {
      final now = DateTime.now();
      if (_lastSensorCalibHintAt == null || now.difference(_lastSensorCalibHintAt!) >= const Duration(seconds: 20)) {
        _lastSensorCalibHintAt = now;
        _toast('指南针精度${_sensorAccuracyLabel(level)}：可做“8”字校准并远离磁干扰');
      }
    }
  }

  (double, String) _resolveDisplayHeading({
    required double courseHeading,
    double? sensorHeading,
    double? speed,
  }) {
    final movingFast = speed != null && speed.isFinite && speed >= 1.0;
    final movingSlow = speed == null || !speed.isFinite || speed < 0.8;
    if (_isValidHeading(sensorHeading) && movingSlow) {
      return (_normDeg(sensorHeading!), '设备朝向(传感器)');
    }
    if (_isValidHeading(courseHeading)) {
      final label = movingFast ? '行进方向(GPS/定位)' : '行进方向(低速)';
      return (_normDeg(courseHeading), label);
    }
    if (_isValidHeading(sensorHeading)) {
      return (_normDeg(sensorHeading!), '设备朝向(传感器兜底)');
    }
    if (_isValidHeading(_uiHeadingF)) {
      return (_uiHeadingF!, '上一帧朝向保持');
    }
    return (double.nan, '无有效朝向');
  }

  void _updateUiStabilizedPosition({
    required double rawLat,
    required double rawLon,
    required double rawAccuracy,
    required double heading,
    double? speed,
  }) {
    final acc = (rawAccuracy.isFinite ? rawAccuracy.clamp(0.0, 99.0) : 30.0).toDouble();
    if (_uiLatF == null || _uiLonF == null) {
      _uiLatF = rawLat;
      _uiLonF = rawLon;
      _uiAccF = rawAccuracy;
      if (_isValidHeading(heading)) _uiHeadingF = _normDeg(heading);
      _uiStillHold = false;
      _uiStillTicks = 0;
      return;
    }

    final prevLat = _uiLatF!;
    final prevLon = _uiLonF!;
    final distToUi = Geolocator.distanceBetween(prevLat, prevLon, rawLat, rawLon);
    final slow = speed == null || !speed.isFinite || speed < 0.7;
    final stillThreshold = math.max(1.8, math.min(6.5, acc * 0.35));
    final maybeStill = slow && distToUi <= stillThreshold;

    if (maybeStill) {
      _uiStillTicks += 1;
    } else {
      _uiStillTicks = 0;
    }
    _uiStillHold = _uiStillTicks >= 2;

    final posAlpha = _uiStillHold
        ? 0.04
        : (slow ? ((acc <= 8) ? 0.16 : 0.10) : ((speed != null && speed.isFinite && speed > 2.0) ? 0.42 : 0.28));
    _uiLatF = _lerpNum(prevLat, rawLat, posAlpha);
    _uiLonF = _lerpNum(prevLon, rawLon, posAlpha);

    final prevAcc = _uiAccF;
    _uiAccF = prevAcc == null || !prevAcc.isFinite ? rawAccuracy : _lerpNum(prevAcc, rawAccuracy, _uiStillHold ? 0.12 : 0.25);

    if (_isValidHeading(heading)) {
      final prevH = _uiHeadingF;
      _uiHeadingF = prevH == null || !prevH.isFinite
          ? _normDeg(heading)
          : _lerpAngleDeg(prevH, heading, _uiStillHold ? 0.30 : 0.42);
    }
  }

  void _updateDisplayFreezeState({
    required double rawLat,
    required double rawLon,
    required double rawAccuracy,
    required double rawHeading,
    double? speed,
  }) {
    final candLat = _uiLatF ?? rawLat;
    final candLon = _uiLonF ?? rawLon;
    final candAcc = (_uiAccF?.isFinite == true ? _uiAccF! : rawAccuracy);
    final candHeading = _isValidHeading(_uiHeadingF) ? _uiHeadingF! : rawHeading;

    if (!_displayFrozen && (_frozenLat == null || _frozenLon == null)) {
      _frozenLat = candLat;
      _frozenLon = candLon;
      _frozenAcc = candAcc;
      _frozenHeading = _isValidHeading(candHeading) ? _normDeg(candHeading) : null;
    }

    final refLat = (_displayFrozen ? _frozenLat : _uiLatF) ?? candLat;
    final refLon = (_displayFrozen ? _frozenLon : _uiLonF) ?? candLon;
    final moveFromRef = Geolocator.distanceBetween(refLat, refLon, rawLat, rawLon);

    final acc = (rawAccuracy.isFinite ? rawAccuracy : candAcc).clamp(1.0, 60.0).toDouble();
    final speedV = (speed != null && speed.isFinite) ? speed : 0.0;
    final likelyStill = speedV < 0.35 && moveFromRef <= math.max(2.0, math.min(6.0, acc * 0.25));
    final likelyMoving = speedV > 1.0 || moveFromRef >= math.max(5.0, math.min(12.0, acc * 0.60));

    if (_displayFrozen) {
      if (likelyMoving) {
        _unfreezeCandidateTicks += 1;
      } else {
        _unfreezeCandidateTicks = 0;
      }
      if (_unfreezeCandidateTicks >= 2) {
        _displayFrozen = false;
        _freezeCandidateTicks = 0;
        _unfreezeCandidateTicks = 0;
        _displayFrozenAt = null;
        // 解锁后将冻结值追上当前稳定值，避免突然跳回更旧状态
        _frozenLat = candLat;
        _frozenLon = candLon;
        _frozenAcc = candAcc;
        _frozenHeading = _isValidHeading(candHeading) ? _normDeg(candHeading) : _frozenHeading;
      }
      return;
    }

    if (likelyStill) {
      _freezeCandidateTicks += 1;
    } else {
      _freezeCandidateTicks = 0;
    }
    if (_freezeCandidateTicks >= 4) {
      _displayFrozen = true;
      _unfreezeCandidateTicks = 0;
      _displayFrozenAt = DateTime.now();
      _frozenLat = candLat;
      _frozenLon = candLon;
      _frozenAcc = candAcc;
      _frozenHeading = _isValidHeading(candHeading) ? _normDeg(candHeading) : null;
    } else {
      // 未冻结时，让“冻结快照”平滑跟随当前稳定值，为下一次冻结做准备（不用于展示）
      _frozenLat = candLat;
      _frozenLon = candLon;
      _frozenAcc = candAcc;
      _frozenHeading = _isValidHeading(candHeading) ? _normDeg(candHeading) : _frozenHeading;
    }
  }

  ({double dE, double dN})? _deltaENMetersFrom({required double lat, required double lon}) {
    final t = _target;
    if (t == null) return null;
    final latAvg = (lat + t.targetLat) / 2;
    const metersPerDegLat = 111320.0;
    final metersPerDegLon = 111320.0 * math.cos(latAvg * math.pi / 180.0);
    final dN = (t.targetLat - lat) * metersPerDegLat;
    final dE = (t.targetLon - lon) * metersPerDegLon;
    return (dE: dE, dN: dN);
  }

  void _updateRadarDisplaySmoothing() {
    final lat = _uiLat;
    final lon = _uiLon;
    if (lat == null || lon == null || _target == null) {
      _radarDeltaSmoothed = null;
      return;
    }
    final raw = _deltaENMetersFrom(lat: lat, lon: lon);
    if (raw == null) {
      _radarDeltaSmoothed = null;
      return;
    }
    final d = math.sqrt(raw.dE * raw.dE + raw.dN * raw.dN);
    final alpha = d <= 12 ? 0.18 : (d <= 50 ? 0.24 : 0.32);
    final prev = _radarDeltaSmoothed;
    if (prev == null) {
      _radarDeltaSmoothed = raw;
      return;
    }
    _radarDeltaSmoothed = (
      dE: _lerpNum(prev.dE, raw.dE, alpha),
      dN: _lerpNum(prev.dN, raw.dN, alpha),
    );
  }

  void _updateRadarAutoRange({double? d, double? acc}) {
    if (!_radarAutoScale) return;
    final dd = d ?? _distanceToTargetMeters();
    if (dd != null && dd <= 50) {
      // 最后引导阶段固定量程，减少边界跳档视觉抖动
      _radarAutoRangeSticky = dd <= 12 ? 10.0 : 30.0;
      return;
    }
    final need = math.max<double>(10.0, math.max(dd ?? 0.0, ((acc ?? _curAccuracy) ?? 0.0) * 2.2) + 4.0);
    var cur = _radarAutoRangeSticky;
    if (![10.0, 30.0, 60.0, 120.0].contains(cur)) cur = 60.0;
    if (cur == 10.0) {
      if (need > 12.0) cur = 30.0;
    } else if (cur == 30.0) {
      if (need > 36.0) cur = 60.0;
      else if (need < 8.0) cur = 10.0;
    } else if (cur == 60.0) {
      if (need > 72.0) cur = 120.0;
      else if (need < 24.0) cur = 30.0;
    } else {
      if (need < 48.0) cur = 60.0;
    }
    _radarAutoRangeSticky = cur;
  }

  void _updateStableDirectionValues({required double lat, required double lon, required double heading}) {
    if (_target == null) {
      _stableDir = '--';
      return;
    }
    if (!heading.isFinite || heading < 0) {
      return;
    }
    final bt = Geolocator.bearingBetween(lat, lon, _target!.targetLat, _target!.targetLon);
    final delta = (bt - heading + 360.0) % 360.0;
    final dir = _deltaToDir(delta);
    final fineDir = _deltaToFineDir(delta);

    if (dir == _stableDir) {
      _pendingDir = dir;
      _pendingDirCount = 0;
    } else if (dir == _pendingDir) {
      _pendingDirCount += 1;
      if (_pendingDirCount >= 2) {
        _stableDir = dir;
        _pendingDirCount = 0;
      }
    } else {
      _pendingDir = dir;
      _pendingDirCount = 1;
    }

    if (fineDir == _fineStableDir) {
      _finePendingDir = fineDir;
      _finePendingDirCount = 0;
    } else if (fineDir == _finePendingDir) {
      _finePendingDirCount += 1;
      if (_finePendingDirCount >= 2) {
        _fineStableDir = fineDir;
        _finePendingDirCount = 0;
      }
    } else {
      _finePendingDir = fineDir;
      _finePendingDirCount = 1;
    }
  }

  String _deltaToDir(double delta) {
    if (delta <= 45 || delta >= 315) return '前方';
    if (delta <= 135) return '右侧';
    if (delta <= 225) return '后方';
    return '左侧';
  }

  String _deltaToFineDir(double delta) {
    if (delta <= 22.5 || delta >= 337.5) return '前方';
    if (delta <= 67.5) return '右前方';
    if (delta <= 112.5) return '右侧';
    if (delta <= 157.5) return '右后方';
    if (delta <= 202.5) return '后方';
    if (delta <= 247.5) return '左后方';
    if (delta <= 292.5) return '左侧';
    return '左前方';
  }

  String _buildMicroHint({
    required double d,
    required double accuracy,
    required double heading,
    required double lat,
    required double lon,
    double? speed,
  }) {
    if (_target == null) return '--';
    final deltaEN = _deltaENMeters();
    final accBad = !accuracy.isFinite || accuracy > 12;
    if (accBad) {
      return '定位精度不足（±${accuracy.toStringAsFixed(0)}m），请到开阔处或稍等收敛，再做最后微调';
    }

    final movingSlow = speed == null || !speed.isFinite || speed < 0.6;
    final fineDir = _fineStableDir == '--' ? _stableDir : _fineStableDir;
    final dText = d.toStringAsFixed(d < 10 ? 1 : 0);

    if (d <= 3) {
      if (deltaEN == null) return '非常接近目标（${dText}m），请观察门牌/招牌';
      final ew = deltaEN.dE.abs() >= 0.8
          ? (deltaEN.dE > 0 ? '向东微调 ${deltaEN.dE.abs().toStringAsFixed(1)}m' : '向西微调 ${deltaEN.dE.abs().toStringAsFixed(1)}m')
          : '东西方向已基本对齐';
      final ns = deltaEN.dN.abs() >= 0.8
          ? (deltaEN.dN > 0 ? '向北微调 ${deltaEN.dN.abs().toStringAsFixed(1)}m' : '向南微调 ${deltaEN.dN.abs().toStringAsFixed(1)}m')
          : '南北方向已基本对齐';
      return '已进入 3m 微调区：$ew；$ns。注意入口/门牌';
    }
    if (d <= 8) {
      return '最后 8m：目标在$fineDir，约 ${dText}m。建议慢速移动并观察入口';
    }
    if (d <= 20) {
      final slowTip = movingSlow ? '（建议保持直线慢走 2-3 秒再看方向变化）' : '';
      return '最后 20m：目标在$fineDir，约 ${dText}m$slowTip';
    }
    return '最后引导：目标在$fineDir，约 ${dText}m';
  }

  String _buildVoiceHint({required double d, required double accuracy, double? speed}) {
    if (!_ttsEnabled) return '';
    if (accuracy > 15 || !accuracy.isFinite) return '定位精度不足，请到开阔处稍等';
    final dir = _fineStableDir != '--' ? _fineStableDir : (_stableDir != '--' ? _stableDir : '前方');
    final m = d < 10 ? d.toStringAsFixed(1) : d.toStringAsFixed(0);
    if (d <= 3) return '非常接近目标，注意查看左右门牌和入口';
    if (d <= 8) return '目标在$dir，约$m米，慢速前进';
    if (d <= 20) return '目标在$dir，约$m米';
    if (d <= 50) return '进入最后引导，目标在$dir，约$m米';
    return '';
  }

  Future<void> _speakGuide(String text, {bool force = false}) async {
    final msg = text.trim();
    if (msg.isEmpty || !_ttsEnabled || !_ttsReady) return;
    final now = DateTime.now();
    if (!force) {
      if (_lastTtsAt != null && now.difference(_lastTtsAt!) < const Duration(seconds: 3)) return;
      if (msg == _lastSpokenGuide && _lastTtsAt != null && now.difference(_lastTtsAt!) < const Duration(seconds: 8)) return;
    }
    try {
      await _tts.stop();
      await _tts.speak(msg);
      _lastTtsAt = now;
      _lastSpokenGuide = msg;
    } catch (_) {}
  }

  double? get _curLat => _useAmapNative ? _amapFix?.lat : _position?.latitude;
  double? get _curLon => _useAmapNative ? _amapFix?.lon : _position?.longitude;
  double? get _curAccuracy => _useAmapNative ? _amapFix?.accuracy : _position?.accuracy;
  double? get _curHeading {
    final h = _useAmapNative ? _amapFix?.bearing : _position?.heading;
    return _isValidHeading(h) ? _normDeg(h!) : h;
  }

  double? get _uiLat => _displayFrozen ? (_frozenLat ?? _uiLatF ?? _curLat) : (_uiLatF ?? _curLat);
  double? get _uiLon => _displayFrozen ? (_frozenLon ?? _uiLonF ?? _curLon) : (_uiLonF ?? _curLon);
  double? get _uiAccuracy => _displayFrozen ? (_frozenAcc ?? _uiAccF ?? _curAccuracy) : (_uiAccF ?? _curAccuracy);
  double? get _uiHeading {
    final h = _displayFrozen ? (_frozenHeading ?? _uiHeadingF ?? _curHeading) : (_uiHeadingF ?? _curHeading);
    return _isValidHeading(h) ? _normDeg(h!) : h;
  }
  String get _coordTypeLabel {
    if (_useAmapNative) {
      final c = _amapFix?.coordType.trim();
      return (c == null || c.isEmpty) ? 'GCJ02(?)' : c;
    }
    return '系统定位（可能WGS84）';
  }
  String get _locSourceLabel => _useAmapNative ? '高德原生定位SDK' : '系统定位（Geolocator）';

  double? _distanceToTargetMeters() {
    final lat = _uiLat;
    final lon = _uiLon;
    if (lat == null || lon == null) return null;
    return _distanceToTargetMetersFrom(lat: lat, lon: lon);
  }

  double? _distanceToTargetMetersFrom({required double lat, required double lon}) {
    final t = _target;
    if (t == null) return null;
    return Geolocator.distanceBetween(lat, lon, t.targetLat, t.targetLon);
  }

  ({double dE, double dN})? _deltaENMeters() {
    final lat = _uiLat;
    final lon = _uiLon;
    if (lat == null || lon == null) return null;
    return _deltaENMetersFrom(lat: lat, lon: lon);
  }

  _ArrivalState _arrivalState() {
    final lat = _curLat;
    final lon = _curLon;
    final acc = _curAccuracy;
    if (lat == null || lon == null || _target == null || acc == null) return _ArrivalState.notArrived;
    final d = _distanceToTargetMetersFrom(lat: lat, lon: lon);
    if (d == null) return _ArrivalState.notArrived;
    return _arrivalStateWith(d: d, accuracy: acc);
  }

  _ArrivalState _arrivalStateWith({required double d, required double accuracy}) {
    if (d > 5.0) return _ArrivalState.notArrived;
    if (accuracy > 10.0 || !accuracy.isFinite) return _ArrivalState.cannotConfirm;
    if (_strictOkStreak >= _strictNeedStreak) return _ArrivalState.strictArrived;
    return _ArrivalState.confirming;
  }

  String _arrivalText(_ArrivalState s) {
    switch (s) {
      case _ArrivalState.notArrived:
        return '未到达';
      case _ArrivalState.cannotConfirm:
        return '无法确认（精度不足）';
      case _ArrivalState.confirming:
        return '确认中（稳定判定）';
      case _ArrivalState.strictArrived:
        return '✅ 严格到达（5m）';
    }
  }

  Color _arrivalColor(_ArrivalState s, BuildContext context) {
    switch (s) {
      case _ArrivalState.strictArrived:
        return Colors.green;
      case _ArrivalState.cannotConfirm:
        return Colors.orange;
      case _ArrivalState.confirming:
        return Colors.blue;
      case _ArrivalState.notArrived:
        return Theme.of(context).colorScheme.onSurface;
    }
  }

  String _guideModeText() {
    switch (_guideMode) {
      case _GuideMode.routeGuide:
        return '普通引导';
      case _GuideMode.finalGuide:
        return '最后引导（50m内）';
      case _GuideMode.arrived:
        return '已严格到达';
    }
  }

  String _radarOrientationText() {
    switch (_radarOrientation) {
      case _RadarOrientationMode.northUp:
        return '真北朝上';
      case _RadarOrientationMode.headingUp:
        return '朝向锁定';
    }
  }

  double _effectiveRadarRangeMeters(double? d, double? acc) {
    if (!_radarAutoScale) return _radarManualRangeMeters;
    if (d != null && d <= 50) {
      return d <= 12 ? 10.0 : 30.0;
    }
    return _radarAutoRangeSticky;
  }

  Future<void> _buzz({bool strong = false, bool force = false}) async {
    if (!_vibrationEnabled) return;
    final now = DateTime.now();
    if (!force && _lastVibrateAt != null && now.difference(_lastVibrateAt!) < const Duration(milliseconds: 900)) {
      return;
    }
    _lastVibrateAt = now;
    try {
      if (strong) {
        await HapticFeedback.heavyImpact();
      } else {
        await HapticFeedback.mediumImpact();
      }
    } catch (_) {
      try {
        await HapticFeedback.vibrate();
      } catch (_) {}
    }
  }

  Future<void> _buzzPatternStage(String stage, {bool force = false}) async {
    if (!_vibrationEnabled) return;
    if (_buzzingPattern && !force) return;
    final now = DateTime.now();
    // 分阶段节奏节流：避免一直震
    final minGap = switch (stage) {
      'outer150' => const Duration(seconds: 8),
      'inner30' => const Duration(seconds: 10),
      'strict5' => const Duration(seconds: 15),
      'final20' => const Duration(seconds: 6),
      _ => const Duration(seconds: 5),
    };
    if (!force && _lastVibrateAt != null && now.difference(_lastVibrateAt!) < minGap) {
      return;
    }
    _lastVibrateAt = now;
    _buzzingPattern = true;
    Future<void> pulse(Future<void> Function() f) async {
      try { await f(); } catch (_) {
        try { await HapticFeedback.vibrate(); } catch (_) {}
      }
    }
    try {
      switch (stage) {
        case 'outer150':
          await pulse(() => HapticFeedback.mediumImpact());
          break;
        case 'inner30':
          await pulse(() => HapticFeedback.heavyImpact());
          await Future.delayed(const Duration(milliseconds: 180));
          await pulse(() => HapticFeedback.mediumImpact());
          break;
        case 'strict5':
          await pulse(() => HapticFeedback.heavyImpact());
          await Future.delayed(const Duration(milliseconds: 140));
          await pulse(() => HapticFeedback.heavyImpact());
          await Future.delayed(const Duration(milliseconds: 140));
          await pulse(() => HapticFeedback.heavyImpact());
          break;
        case 'final20':
          await pulse(() => HapticFeedback.selectionClick());
          break;
        default:
          await pulse(() => HapticFeedback.mediumImpact());
      }
    } finally {
      _buzzingPattern = false;
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  Widget _kvRow(String k, String v, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 128, child: Text(k, style: const TextStyle(color: Colors.black54))),
          Expanded(child: Text(v, style: TextStyle(color: valueColor))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = _target;
    final d = _distanceToTargetMeters();
    final deltaEN = _deltaENMeters();
    final radarDeltaEN = _radarDeltaSmoothed ?? deltaEN;
    final arrival = _arrivalState();
    final lat = _uiLat;
    final lon = _uiLon;
    final acc = _uiAccuracy;
    final heading = _uiHeading;

    return Scaffold(
      appBar: AppBar(
        title: const Text('捉迷藏'),
        actions: [
          IconButton(
            tooltip: '刷新定位',
            onPressed: _startLocation,
            icon: const Icon(Icons.gps_fixed),
          ),
          IconButton(
            tooltip: '重新读取设置页高德Key',
            onPressed: _loadKeys,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('目标搜索（高德 Web 接口）', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _queryCtrl,
                    decoration: const InputDecoration(
                      labelText: '输入超市名或地址',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _searchPoi(),
                  ),
                  const SizedBox(height: 8),
                  ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    title: const Text('临时覆盖高德 Web Key（可选）'),
                    subtitle: Text(_loadingKeys
                        ? '读取设置中...'
                        : (_savedAmapWebKey.isEmpty ? '设置页未填写 Web Key' : '已从设置页读取 Web Key')),
                    children: [
                      TextField(
                        controller: _webKeyOverrideCtrl,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: '留空则使用设置页保存的高德 Web Key',
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Android Key（设置页保存）: ${_savedAmapAndroidKey.isEmpty ? '未填写' : '已填写（${_useAmapNative ? '原生定位已启用' : '可用于高德原生定位'}）'}',
                          style: const TextStyle(fontSize: 12, color: Colors.black54),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ElevatedButton.icon(
                        onPressed: _searching ? null : _searchPoi,
                        icon: _searching
                            ? const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.search),
                        label: const Text('搜索目标'),
                      ),
                      OutlinedButton.icon(
                        onPressed: (lat == null || lon == null)
                            ? null
                            : () {
                                setState(() {
                                  _setTarget(_PoiCandidate(
                                    name: '当前位置（校准点）',
                                    address: '用户手动校准',
                                    lat: lat,
                                    lon: lon,
                                  ));
                                });
                              },
                        icon: const Icon(Icons.place),
                        label: const Text('设当前位置为目标'),
                      ),
                      if (_isAndroid && _savedAmapAndroidKey.isNotEmpty)
                        OutlinedButton.icon(
                          onPressed: () async {
                            final ok = await _startAmapNative();
                            if (!ok) {
                              if (mounted) _toast('切换高德原生定位失败，仍使用系统定位');
                              return;
                            }
                            await _posSub?.cancel();
                            _posSub = null;
                          },
                          icon: const Icon(Icons.my_location),
                          label: const Text('启用高德原生定位'),
                        ),
                      OutlinedButton.icon(
                        onPressed: _startSystemLocation,
                        icon: const Icon(Icons.phone_android),
                        label: const Text('用系统定位'),
                      ),
                      OutlinedButton.icon(
                        onPressed: _lastTargetCache == null ? null : _useLastCachedTarget,
                        icon: const Icon(Icons.history),
                        label: const Text('使用最近目标缓存'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(_cacheInfo, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Text(_error!, style: const TextStyle(color: Colors.red)),
                  ],
                ],
              ),
            ),
          ),
          if (_candidates.isNotEmpty) ...[
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: [
                  const ListTile(
                    dense: true,
                    title: Text('候选目标（点击设为目标）'),
                  ),
                  const Divider(height: 1),
                  ..._candidates.map((c) => ListTile(
                        dense: true,
                        selected: identical(c, _target),
                        title: Text(c.name.isEmpty ? '未命名地点' : c.name),
                        subtitle: Text('${c.address} · ${c.targetSource}'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          setState(() {
                            _setTarget(c);
                          });
                        },
                      )),
                ],
              ),
            ),
          ],
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('门口校准点历史（本地）', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ElevatedButton.icon(
                        onPressed: (lat == null || lon == null) ? null : _saveCalibrationPointFromCurrentLocation,
                        icon: const Icon(Icons.bookmark_add),
                        label: const Text('保存当前位置为门口校准点'),
                      ),
                      OutlinedButton.icon(
                        onPressed: _savedTargetHistory.isEmpty
                            ? null
                            : () async {
                                await _kv.setString(_kHsTargetHistory, '[]');
                                if (!mounted) return;
                                setState(() => _savedTargetHistory = const []);
                                _toast('已清空门口校准点历史');
                              },
                        icon: const Icon(Icons.delete_outline),
                        label: const Text('清空历史'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_savedTargetHistory.isEmpty)
                    const Text('暂无保存的门口校准点。到店门口后点击上方按钮保存，下次可离线直接使用。', style: TextStyle(color: Colors.black54))
                  else
                    Column(
                      children: _savedTargetHistory.take(6).map((e) {
                        final p = e.poi;
                        return ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(e.kind == 'calibration' ? Icons.storefront : Icons.history),
                          title: Text(p.name.isEmpty ? '未命名地点' : p.name),
                          subtitle: Text('${p.address} · ${e.labelTime} · ${e.kind == 'calibration' ? '门口校准' : '最近目标'}'),
                          trailing: Wrap(
                            spacing: 2,
                            children: [
                              IconButton(
                                tooltip: '使用',
                                icon: const Icon(Icons.check_circle_outline),
                                onPressed: () {
                                  setState(() => _setTarget(p));
                                  _toast('已切换到本地历史目标');
                                },
                              ),
                              IconButton(
                                tooltip: '删除',
                                icon: const Icon(Icons.close),
                                onPressed: () async {
                                  final next = _savedTargetHistory.where((x) => x.savedAtMs != e.savedAtMs).toList();
                                  setState(() => _savedTargetHistory = next);
                                  await _persistTargetHistory();
                                },
                              ),
                            ],
                          ),
                        );
                      }).toList(growable: false),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('误差圈可视化（雷达）', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      ChoiceChip(
                        label: Text(_radarOrientationText()),
                        selected: true,
                        onSelected: (_) {
                          setState(() {
                            _radarOrientation = _radarOrientation == _RadarOrientationMode.northUp
                                ? _RadarOrientationMode.headingUp
                                : _RadarOrientationMode.northUp;
                          });
                        },
                      ),
                      FilterChip(
                        label: Text(_radarAutoScale ? '自动缩放' : '手动量程'),
                        selected: _radarAutoScale,
                        onSelected: (v) => setState(() => _radarAutoScale = v),
                      ),
                      if (!_radarAutoScale)
                        OutlinedButton.icon(
                          onPressed: () {
                            setState(() {
                              const opts = [120.0, 60.0, 30.0, 10.0];
                              final idx = opts.indexOf(_radarManualRangeMeters);
                              _radarManualRangeMeters = opts[(idx + 1) % opts.length];
                            });
                          },
                          icon: const Icon(Icons.zoom_out_map, size: 18),
                          label: Text('量程 ${_radarManualRangeMeters.toStringAsFixed(0)}m'),
                        ),
                      FilterChip(
                        label: Text(_vibrationEnabled ? '到点振动：开' : '到点振动：关'),
                        selected: _vibrationEnabled,
                        onSelected: (v) => setState(() => _vibrationEnabled = v),
                      ),
                      FilterChip(
                        label: Text(_showRawDebugValues ? '调试原始值：开' : '调试原始值：关'),
                        selected: _showRawDebugValues,
                        onSelected: (v) => setState(() => _showRawDebugValues = v),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_useAmapNative && _isValidHeading(_amapFix?.sensorHeading))
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _isSensorCalibPoor() ? Colors.amber.shade50 : Colors.green.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: _isSensorCalibPoor() ? Colors.amber.shade300 : Colors.green.shade200,
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            _isSensorCalibPoor() ? Icons.explore_off : Icons.explore,
                            size: 18,
                            color: _isSensorCalibPoor() ? Colors.orange.shade800 : Colors.green.shade700,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              '指南针状态：${_sensorAccuracyLabel()}（已做横竖屏旋转补偿：${_screenRotationLabel()}）\n${_compassCalibrationHintText()}',
                              style: TextStyle(
                                fontSize: 12,
                                color: _isSensorCalibPoor() ? Colors.orange.shade900 : Colors.green.shade900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  SizedBox(
                    height: 230,
                    child: _RadarErrorView(
                      distanceMeters: d,
                      deltaEN: radarDeltaEN,
                      accuracyMeters: acc,
                      headingDeg: heading,
                      targetLabel: t?.name,
                      orientationMode: _radarOrientation,
                      rangeMeters: _effectiveRadarRangeMeters(d, acc),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('实时差距面板', style: TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      if (_locating)
                        const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _kvRow('定位来源', _locSourceLabel),
                  _kvRow('定位状态', lat == null ? (_locating ? '启动中...' : '未获取到位置') : '已定位'),
                  _kvRow('坐标系', _coordTypeLabel),
                  if (_useAmapNative) _kvRow('高德状态', _lastNativeStatus),
                  _kvRow('当前坐标', lat == null || lon == null ? '--' : '${lat.toStringAsFixed(6)}, ${lon.toStringAsFixed(6)}'),
                  _kvRow('目标坐标', t == null ? '--' : '${t.targetLat.toStringAsFixed(6)}, ${t.targetLon.toStringAsFixed(6)}'),
                  _kvRow('目标名称', t == null ? '--' : '${t.name.isEmpty ? '未命名地点' : t.name} (${t.targetSource})'),
                  _kvRow('直线距离 D', d == null ? '--' : '${d.toStringAsFixed(1)} m'),
                  _kvRow('ΔE / ΔN', deltaEN == null ? '--' : '${deltaEN.dE.toStringAsFixed(1)} m / ${deltaEN.dN.toStringAsFixed(1)} m'),
                  _kvRow('accuracy', acc == null ? '--' : '±${acc.toStringAsFixed(1)} m'),
                  _kvRow('heading', heading == null ? '--' : '${heading.toStringAsFixed(1)}°'),
                  _kvRow('heading来源', _uiHeadingSource),
                  _kvRow('显示冻结', _displayFrozen ? '是（原地静止锁定）' : '否'),
                  if (_useAmapNative) _kvRow('指南针精度', _sensorAccuracyLabel()),
                  if (_useAmapNative && _sensorScreenRotation != null) _kvRow('屏幕旋转补偿', _screenRotationLabel()),
                  _kvRow('坐标稳定化', _uiStillHold ? '静止锁定中（抑制原地抖动）' : '动态更新'),
                  if (_showRawDebugValues) ...[
                    const SizedBox(height: 6),
                    const Text('调试视图（原始值 vs 稳定值）', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                    _kvRow(
                      '原始当前坐标',
                      (_curLat == null || _curLon == null) ? '--' : '${_curLat!.toStringAsFixed(6)}, ${_curLon!.toStringAsFixed(6)}',
                    ),
                    _kvRow(
                      '稳定当前坐标',
                      (_uiLat == null || _uiLon == null) ? '--' : '${_uiLat!.toStringAsFixed(6)}, ${_uiLon!.toStringAsFixed(6)}',
                    ),
                    _kvRow('原始accuracy', _curAccuracy == null ? '--' : '±${_curAccuracy!.toStringAsFixed(1)} m'),
                    _kvRow('稳定accuracy', _uiAccuracy == null ? '--' : '±${_uiAccuracy!.toStringAsFixed(1)} m'),
                    _kvRow('原始heading', _curHeading == null ? '--' : '${_curHeading!.toStringAsFixed(1)}°'),
                    _kvRow('稳定heading', _uiHeading == null ? '--' : '${_uiHeading!.toStringAsFixed(1)}°'),
                  ],
                  _kvRow('相对方位', (lat == null || t == null) ? '--' : '目标在$_stableDir'),
                  _kvRow('精细方位', (lat == null || t == null) ? '--' : '目标在$_fineStableDir'),
                  _kvRow('20m微调建议', _microHint),
                  _kvRow('两级提醒', '150m:${_enteredOuter150 ? '已进入' : '未进入'} / 30m:${_enteredInner30 ? '已进入' : '未进入'}'),
                  _kvRow('引导模式', _guideModeText()),
                  _kvRow('雷达朝向', _radarOrientationText()),
                  _kvRow('雷达量程', '${_effectiveRadarRangeMeters(d, acc).toStringAsFixed(0)} m (${_radarAutoScale ? '自动' : '手动'})'),
                  if (_isAndroid && _useAmapNative)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _toggleAmapBackground,
                              icon: Icon(_amapBgEnabled ? Icons.notifications_off : Icons.notifications_active),
                              label: Text(_amapBgEnabled ? '关闭后台定位通知' : '开启后台定位通知'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      children: [
                        Expanded(
                          child: SwitchListTile.adaptive(
                            contentPadding: EdgeInsets.zero,
                            dense: true,
                            title: const Text('语音播报（TTS）'),
                            subtitle: Text(_ttsReady ? '每3秒节流播报，最后20m更频繁提示' : 'TTS不可用或未初始化完成'),
                            value: _ttsEnabled,
                            onChanged: (v) async {
                              setState(() => _ttsEnabled = v);
                              if (!v) { try { await _tts.stop(); } catch (_) {} }
                            },
                          ),
                        ),
                        IconButton(
                          tooltip: '试播报',
                          onPressed: () => _speakGuide('捉迷藏语音引导已开启', force: true),
                          icon: const Icon(Icons.volume_up),
                        ),
                      ],
                    ),
                  ),
                  _kvRow(
                    '严格5m到达',
                    _arrivalText(arrival),
                    valueColor: _arrivalColor(arrival, context),
                  ),
                  if (arrival == _ArrivalState.cannotConfirm && acc != null)
                    const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Text(
                        '提示：距离已接近目标，但当前精度不足以确认到达 5m。请到开阔处、稍等定位收敛。',
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ),
                  if (arrival == _ArrivalState.confirming)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        '确认中：连续满足 ${_strictOkStreak}/$_strictNeedStreak 秒',
                        style: const TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('说明', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('• Android 且设置页填写高德 Android Key 后，会优先尝试高德原生定位 SDK（高精度 + 1Hz）。'),
                  const Text('• 进入 150m / 30m 会弹提示并触发分阶段振动节奏；50m 内进入最后引导模式，显示前/右/后/左，并启用20m微调策略。'),
                  const Text('• “严格到达 5m”判定条件：D≤5m 且 accuracy≤10m 且连续满足 5 次采样。支持语音播报、到点振动、雷达真北/朝向锁定与自动缩放。'),
                  const Text('• 门口校准点可保存到本地历史，弱网/无网时可直接使用最近缓存目标或门口校准点。'),
                  const Text('• 若未填写 Android Key，则回退为系统定位（Geolocator）；目标搜索仍使用高德 Web Key。'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _RadarErrorView extends StatelessWidget {
  final double? distanceMeters;
  final ({double dE, double dN})? deltaEN;
  final double? accuracyMeters;
  final double? headingDeg;
  final String? targetLabel;
  final _RadarOrientationMode orientationMode;
  final double rangeMeters;

  const _RadarErrorView({
    required this.distanceMeters,
    required this.deltaEN,
    required this.accuracyMeters,
    required this.headingDeg,
    required this.targetLabel,
    required this.orientationMode,
    required this.rangeMeters,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _RadarErrorPainter(
        distanceMeters: distanceMeters,
        deltaEN: deltaEN,
        accuracyMeters: accuracyMeters,
        headingDeg: headingDeg,
        targetLabel: targetLabel ?? '目标',
        orientationMode: orientationMode,
        rangeMeters: rangeMeters,
        textColor: Theme.of(context).colorScheme.onSurface,
      ),
      child: const SizedBox.expand(),
    );
  }
}

class _RadarErrorPainter extends CustomPainter {
  final double? distanceMeters;
  final ({double dE, double dN})? deltaEN;
  final double? accuracyMeters;
  final double? headingDeg;
  final String targetLabel;
  final _RadarOrientationMode orientationMode;
  final double rangeMeters;
  final Color textColor;

  _RadarErrorPainter({
    required this.distanceMeters,
    required this.deltaEN,
    required this.accuracyMeters,
    required this.headingDeg,
    required this.targetLabel,
    required this.orientationMode,
    required this.rangeMeters,
    required this.textColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2 + 8);
    final radius = math.min(size.width, size.height) * 0.36;
    final grid = Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.grey.shade400;
    final axis = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.2..color = Colors.grey.shade500;
    final userPaint = Paint()..color = Colors.blue;
    final targetPaint = Paint()..color = Colors.red;
    final accPaint = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.blue.withOpacity(0.35);
    final linePaint = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.teal;

    for (final r in [radius / 3, radius * 2 / 3, radius]) {
      canvas.drawCircle(center, r, grid);
    }
    canvas.drawLine(Offset(center.dx - radius, center.dy), Offset(center.dx + radius, center.dy), axis);
    canvas.drawLine(Offset(center.dx, center.dy - radius), Offset(center.dx, center.dy + radius), axis);

    final maxMeters = rangeMeters <= 0 ? 60.0 : rangeMeters;
    if (accuracyMeters != null && accuracyMeters!.isFinite) {
      final accR = (accuracyMeters!.clamp(0, maxMeters) / maxMeters) * radius;
      canvas.drawCircle(center, accR, accPaint);
    }

    if (headingDeg != null && headingDeg!.isFinite && headingDeg! >= 0) {
      final isHeadingUp = orientationMode == _RadarOrientationMode.headingUp;
      final hd = isHeadingUp ? 0.0 : headingDeg! * math.pi / 180.0;
      final tip = Offset(center.dx + math.sin(hd) * radius * 0.9, center.dy - math.cos(hd) * radius * 0.9);
      final left = Offset(center.dx + math.sin(hd - 0.22) * radius * 0.72, center.dy - math.cos(hd - 0.22) * radius * 0.72);
      final right = Offset(center.dx + math.sin(hd + 0.22) * radius * 0.72, center.dy - math.cos(hd + 0.22) * radius * 0.72);
      final path = Path()..moveTo(tip.dx, tip.dy)..lineTo(left.dx, left.dy)..lineTo(right.dx, right.dy)..close();
      canvas.drawPath(path, Paint()..color = Colors.green.withOpacity(0.7));
    }

    canvas.drawCircle(center, 6, userPaint);

    if (deltaEN != null) {
      final scale = radius / maxMeters;
      var dE = deltaEN!.dE;
      var dN = deltaEN!.dN;
      if (orientationMode == _RadarOrientationMode.headingUp && headingDeg != null && headingDeg!.isFinite && headingDeg! >= 0) {
        final th = -headingDeg! * math.pi / 180.0; // 世界转到“朝向锁定”
        final x = dE * math.cos(th) - dN * math.sin(th);
        final y = dE * math.sin(th) + dN * math.cos(th);
        dE = x;
        dN = y;
      }
      final dx = (dE * scale).clamp(-radius, radius).toDouble();
      final dy = (-dN * scale).clamp(-radius, radius).toDouble();
      final target = Offset(center.dx + dx, center.dy + dy);
      canvas.drawLine(center, target, linePaint);
      canvas.drawCircle(target, 6, targetPaint);
      final label = TextPainter(
        text: TextSpan(
          text: targetLabel.length > 10 ? '${targetLabel.substring(0, 10)}…' : targetLabel,
          style: TextStyle(fontSize: 11, color: textColor),
        ),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.width - 12);
      label.paint(canvas, Offset(target.dx + 8, target.dy - 10));
    }

    final caption = TextPainter(
      textDirection: TextDirection.ltr,
      text: TextSpan(
        text: '中心=你，红点=目标，蓝圈=定位误差；外圈量程≈${maxMeters.toStringAsFixed(0)}m',
        style: TextStyle(color: textColor, fontSize: 11),
      ),
    )..layout(maxWidth: size.width - 8);
    caption.paint(canvas, const Offset(4, 2));

    final labels = orientationMode == _RadarOrientationMode.headingUp
        ? <String, Offset>{
            '前': Offset(center.dx - 6, center.dy - radius - 18),
            '右': Offset(center.dx + radius + 6, center.dy - 6),
            '后': Offset(center.dx - 6, center.dy + radius + 4),
            '左': Offset(center.dx - radius - 18, center.dy - 6),
          }
        : <String, Offset>{
            '北': Offset(center.dx - 6, center.dy - radius - 18),
            '东': Offset(center.dx + radius + 6, center.dy - 6),
            '南': Offset(center.dx - 6, center.dy + radius + 4),
            '西': Offset(center.dx - radius - 18, center.dy - 6),
          };
    for (final e in labels.entries) {
      final tp = TextPainter(
        text: TextSpan(text: e.key, style: TextStyle(fontSize: 11, color: textColor.withOpacity(0.75))),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, e.value);
    }
  }

  @override
  bool shouldRepaint(covariant _RadarErrorPainter old) {
    return old.distanceMeters != distanceMeters ||
        old.accuracyMeters != accuracyMeters ||
        old.headingDeg != headingDeg ||
        old.deltaEN != deltaEN ||
        old.targetLabel != targetLabel ||
        old.orientationMode != orientationMode ||
        old.rangeMeters != rangeMeters ||
        old.textColor != textColor;
  }
}

