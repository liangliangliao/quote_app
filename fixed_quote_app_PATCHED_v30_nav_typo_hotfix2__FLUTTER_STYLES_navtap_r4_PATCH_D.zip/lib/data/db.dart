
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/services.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      // Bump the database version to trigger onUpgrade for recent migrations.
      // Increasing this version number ensures that any device with an older
      // schema (missing columns like task_type/task_name in quotes) will run
      // the upgrade logic below.  Without this bump, onUpgrade would not be
      // invoked on devices that have already migrated to version 7 and thus
      // would never receive the new columns, which manifested as
      // "no column named task_type" errors during inserts.
      // Bump database version to 9 to create the new quotes_fixed table.  Any
      // increase in version triggers onUpgrade, which will also recreate
      // missing tables (see _upgrade below).  Without this bump, devices
      // previously running version 8 would not receive the new quotes_fixed
      // table.  See patch requirements for a fixed quotes feature.
      version: 9,
      onCreate: _create,
      onUpgrade: _upgrade,
    );
    // Debug: print DB absolute path and notify native
    try {
      // ignore: avoid_print
      print('[DBG] AppDatabase opened at: ' + path);

    // --- enumerate db schema
    final db = _db!;  // assert non-null: we just opened it above (all user tables & columns) ---
    final List<Map<String, Object?>> _tables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
    final Map<String, List<String>> _schema = {};
    for (final t in _tables) {
      final name = (t['name'] ?? '') as String;
      if (name.isEmpty) continue;
      final cols = await db.rawQuery('PRAGMA table_info(' + name + ')');
      final List<String> colNames = [];
      for (final c in cols) {
        final cn = (c['name'] ?? '') as String;
        if (cn.isNotEmpty) colNames.add(cn);
      }
      _schema[name] = colNames;
    }

      // Notify native side about database info. When running in background isolates (e.g. WorkManager),
      // the native.scheduler channel may not be registered, which would cause an unhandled
      // MissingPluginException if the future is not awaited and caught.  To avoid crashing,
      // await the call and catch any exception.
      try {
        const _ch = MethodChannel('native.scheduler');
        await _ch.invokeMethod('dbInfo', {'dbPath': path, 'version': 5, 'schema': _schema});
      } catch (_) {
        // ignore missing plugin errors when background isolate is missing native channel
      }
    } catch (t) { /* ignore */ }

    await _db!.execute('PRAGMA foreign_keys = ON');

    // Ensure critical columns exist in quotes and tasks tables.  Some devices may
    // have upgraded to a newer database version without running onUpgrade (for
    // example, if the version number did not change), leaving columns such
    // as task_type/task_name missing.  To avoid "no column named task_type"
    // errors during inserts, we detect missing columns here and add them on
    // first open.  Each ALTER TABLE is wrapped in a try/catch to be idempotent.
    try {
      final db = _db!;
      // Quotes table columns to ensure
      final infoQuotes = await db.rawQuery("PRAGMA table_info(quotes)");
      final colsQuotes = infoQuotes.map((e) => e['name'] as String).toList();
      if (!colsQuotes.contains('task_type'))        await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT");
    // Ensure new quote columns (compat)
    try { await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE configs ADD COLUMN recent_hours INTEGER DEFAULT 2"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN taskType TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN taskName TEXT"); } catch (_) {}
      if (!colsQuotes.contains('task_name'))        await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT");
      if (!colsQuotes.contains('theme'))            await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT");
      if (!colsQuotes.contains('author_name'))      await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT");
      if (!colsQuotes.contains('source_from'))      await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT");
      if (!colsQuotes.contains('explanation'))      await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT");
      if (!colsQuotes.contains('inserted_at'))      await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT");
      if (!colsQuotes.contains('last_notified_at')) await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT");
      if (!colsQuotes.contains('avatar'))           await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT");
      // Tasks table columns to ensure
      final infoTasks = await db.rawQuery("PRAGMA table_info(tasks)");
      final colsTasks = infoTasks.map((e) => e['name'] as String).toList();
      if (!colsTasks.contains('task_uid'))   await db.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
      if (!colsTasks.contains('name'))       await db.execute("ALTER TABLE tasks ADD COLUMN name TEXT");
      if (!colsTasks.contains('task_type'))  await db.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT");
      if (!colsTasks.contains('start_time')) await db.execute("ALTER TABLE tasks ADD COLUMN start_time TEXT");
      if (!colsTasks.contains('prompt'))     await db.execute("ALTER TABLE tasks ADD COLUMN prompt TEXT");
      if (!colsTasks.contains('avatar'))     await db.execute("ALTER TABLE tasks ADD COLUMN avatar TEXT");
      if (!colsTasks.contains('status'))     await db.execute("ALTER TABLE tasks ADD COLUMN status TEXT");
      // Ensure cursor column exists; used by bulk import tasks for quote navigation
      if (!colsTasks.contains('cursor'))     await db.execute("ALTER TABLE tasks ADD COLUMN cursor INTEGER DEFAULT 0");
      // Ensure carousel_order column exists; used by carousel tasks to store play order
      if (!colsTasks.contains('carousel_order')) await db.execute("ALTER TABLE tasks ADD COLUMN carousel_order TEXT DEFAULT 'desc'");
    } catch (_) {
      // ignore any errors; missing columns will raise on next upgrade
    }
    return _db!;
  }

  static Future<void> _create(Database db, int version) async {
    // Configs
    await db.execute('''
      CREATE TABLE configs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        api_key TEXT,
        model TEXT,
        endpoint TEXT,
        recent_hours INTEGER DEFAULT 2
      )
    ''');

    // Backup table for restoring original order (方案B)
    await db.execute('''
      CREATE TABLE IF NOT EXISTS quotes_id_backup (
        quote_uid TEXT PRIMARY KEY,
        original_id INTEGER,
        original_pos INTEGER
      )
    ''');
await db.insert('configs', {'api_key': '', 'model': 'gpt-5', 'endpoint': 'https://api.openai.com/v1/responses', 'recent_hours': 2});

    // Meta key-value
    await db.execute('''
      CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');

    // Tasks
    // Additional columns `next_time` and `scheduled_run_key` are included by
    // default in the schema.  They will be used to store the next scheduled
    // run time and the last registered runKey respectively.  Older database
    // versions will be migrated via ensureExtraTaskColumns().
    await db.execute('''
      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT UNIQUE,
        name TEXT,
        type TEXT,          -- manual | auto | carousel | 批量导入任务
        status TEXT,        -- on | off
        prompt TEXT,        -- for auto
        avatar_path TEXT,   -- icon path
        start_time TEXT,    -- 'HH:mm' or 'YYYY-MM-DD HH:mm[:ss]'
        freq_type TEXT,     -- daily | weekly | monthly | custom
        freq_weekday INTEGER,       -- 1-7 (Mon-Sun) when weekly
        freq_day_of_month INTEGER,  -- 1-31 when monthly
        freq_custom TEXT,            -- reserved
        next_time TEXT,              -- ISO8601 next run time
        scheduled_run_key TEXT,      -- last scheduled runKey for cancellation
        cursor INTEGER DEFAULT 0,     -- index into quotes for bulk import tasks
        carousel_order TEXT DEFAULT 'desc'    -- order for carousel tasks: desc | asc | random
      )
    ''');

    // Quotes
    await db.execute('''
      CREATE TABLE quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_uid TEXT UNIQUE,
        task_uid TEXT,
        content TEXT,
        notified INTEGER DEFAULT 0,
        created_at INTEGER,
        
        theme TEXT,
        author_name TEXT,
        source_from TEXT,
        explanation TEXT,
        avatar TEXT,
        inserted_at TEXT,
        last_notified_at TEXT,
        taskType TEXT,
        taskName TEXT,
        FOREIGN KEY(task_uid) REFERENCES tasks(task_uid) ON DELETE CASCADE
      )
    ''' );

    // Table for fixed quotes.  Each record stores a snapshot of quote data
    // for the "名人名言固定表" feature.  This table references the quotes
    // table via quote_id (nullable, on delete set null) and enforces
    // uniqueness on content to prevent duplicate pins.  Fields mirror the
    // primary quote fields (theme/topic, author_name, source_from, explanation,
    // avatar) so that pinned items remain intact even if the original quote
    // record is edited.  A separate fixed_uid is used as a stable primary key.
    await db.execute('''
      CREATE TABLE quotes_fixed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fixed_uid TEXT UNIQUE,
        quote_id INTEGER,
        content TEXT UNIQUE,
        theme TEXT,
        author_name TEXT,
        source_from TEXT,
        explanation TEXT,
        avatar TEXT,
        FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE SET NULL
      )
    ''');

    // Logs
    await db.execute('''
      CREATE TABLE logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_uid TEXT UNIQUE,
        task_uid TEXT,
        detail TEXT,
        created_at INTEGER,
        task_name_snapshot TEXT,
        task_start_time_snapshot TEXT
      )
    ''');
  
    // Safe: seed backup mapping AFTER quotes table exists
    try {
      await db.execute("INSERT OR IGNORE INTO quotes_id_backup(quote_uid, original_id, original_pos) SELECT quote_uid, id, rowid FROM quotes");
    } catch (_) {}
}

  static Future<void> _ensureMeta(Database db) async {
    // placeholder if future migrations need to alter meta schema
  }

  static Future<void> _upgrade(Database db, int oldV, int newV) async {
    // Always attempt to add any missing columns regardless of the old
    // version.  Each ALTER TABLE is wrapped in a try/catch so that
    // attempting to add an existing column will simply fail silently.  This
    // makes the upgrade idempotent and ensures that devices upgrading from
    // any prior version will have the expected schema.  See issue where
    // `task_type` column was missing on some devices even after a version
    // bump; running these ALTERs unconditionally prevents that.
    try { await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE configs ADD COLUMN recent_hours INTEGER DEFAULT 2"); } catch (_) {}
    // Ensure tasks table has necessary columns for new features.  These
    // columns may already exist; wrapping in try/catch makes the addition
    // safe to repeat.
    try { await db.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN name TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN start_time TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN prompt TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN avatar TEXT"); } catch (_) {}
    try { await db.execute("ALTER TABLE tasks ADD COLUMN status TEXT"); } catch (_) {}
    // New cursor column for tasks; used by bulk import tasks to point to current quote index
    try { await db.execute("ALTER TABLE tasks ADD COLUMN cursor INTEGER DEFAULT 0"); } catch (_) {}
    // New carousel_order column for tasks; used by carousel tasks to control ordering
    try { await db.execute("ALTER TABLE tasks ADD COLUMN carousel_order TEXT DEFAULT 'desc'"); } catch (_) {}

    // Ensure the quotes_fixed table exists.  On upgrades from versions prior
    // to 9, the fixed quotes table may not yet exist.  Using IF NOT EXISTS
    // makes this operation idempotent and safe to call repeatedly.
    try {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS quotes_fixed (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fixed_uid TEXT UNIQUE,
          quote_id INTEGER,
          content TEXT UNIQUE,
          theme TEXT,
          author_name TEXT,
          source_from TEXT,
          explanation TEXT,
          avatar TEXT,
          FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE SET NULL
        )
      ''');
    } catch (_) {}

    // Continue with legacy upgrade logic for very old versions.
    if (oldV < 5) {
      // Best-effort ensure required tables/columns exist
      await db.execute("CREATE TABLE IF NOT EXISTS configs (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT, model TEXT, endpoint TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT UNIQUE, name TEXT, type TEXT, status TEXT, prompt TEXT, avatar_path TEXT, start_time TEXT, freq_type TEXT, freq_weekday INTEGER, freq_day_of_month INTEGER, freq_custom TEXT)");
      await db.execute("CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, quote_uid TEXT UNIQUE, task_uid TEXT, content TEXT, notified INTEGER DEFAULT 0, created_at INTEGER)");
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT, created_at INTEGER, task_name_snapshot TEXT, task_start_time_snapshot TEXT)");

      // === Ensure standardized schema (backward compatible) ===
      // Logs: id AUTOINCREMENT, log_uid PRIMARY KEY, task_uid (FK, nullable, ON DELETE SET NULL), detail
      await db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_uid TEXT UNIQUE, task_uid TEXT, detail TEXT)");
      // Ensure required columns exist
      // quotes: add required columns if missing
      var infoQuotes = await db.rawQuery("PRAGMA table_info(quotes)");
      var colsQuotes = infoQuotes.map((e)=> e['name'] as String).toList();
      


if (!colsQuotes.contains('task_type')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT"); }
if (!colsQuotes.contains('task_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT"); }
if (!colsQuotes.contains('theme')) { await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT"); }
if (!colsQuotes.contains('author_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT"); }
if (!colsQuotes.contains('source_from')) { await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT"); }
if (!colsQuotes.contains('explanation')) { await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT"); }
if (!colsQuotes.contains('inserted_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT"); }
if (!colsQuotes.contains('last_notified_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT"); }
if (!colsQuotes.contains('avatar')) { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
if (!colsQuotes.contains('theme')) { await db.execute("ALTER TABLE quotes ADD COLUMN theme TEXT"); }
if (!colsQuotes.contains('author_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN author_name TEXT"); }
if (!colsQuotes.contains('source_from')) { await db.execute("ALTER TABLE quotes ADD COLUMN source_from TEXT"); }
if (!colsQuotes.contains('explanation')) { await db.execute("ALTER TABLE quotes ADD COLUMN explanation TEXT"); }
if (!colsQuotes.contains('inserted_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN inserted_at TEXT"); }
if (!colsQuotes.contains('last_notified_at')) { await db.execute("ALTER TABLE quotes ADD COLUMN last_notified_at TEXT"); }
if (!colsQuotes.contains('avatar')) { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
if (!colsQuotes.contains('quote_uid')) { await db.execute("ALTER TABLE quotes ADD COLUMN quote_uid TEXT"); }
      if (!colsQuotes.contains('task_uid'))  { await db.execute("ALTER TABLE quotes ADD COLUMN task_uid TEXT"); }
      if (!colsQuotes.contains('task_type')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_type TEXT"); }
      if (!colsQuotes.contains('task_name')) { await db.execute("ALTER TABLE quotes ADD COLUMN task_name TEXT"); }
      if (!colsQuotes.contains('avatar'))    { await db.execute("ALTER TABLE quotes ADD COLUMN avatar TEXT"); }
      if (!colsQuotes.contains('notified'))  { await db.execute("ALTER TABLE quotes ADD COLUMN notified INTEGER DEFAULT 0"); }
      // unique for content
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_content ON quotes(content)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_uid ON quotes(quote_uid)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_tasks_uid ON tasks(task_uid)");
      await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_logs_uid ON logs(log_uid)");

      // tasks: ensure required columns
      var infoTasks = await db.rawQuery("PRAGMA table_info(tasks)");
      var colsTasks = infoTasks.map((e)=> e['name'] as String).toList();
      if (!colsTasks.contains('task_uid'))   { await db.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT"); }
      if (!colsTasks.contains('name'))       { await db.execute("ALTER TABLE tasks ADD COLUMN name TEXT"); }
      if (!colsTasks.contains('task_type'))  { await db.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT"); }
      if (!colsTasks.contains('start_time')) { await db.execute("ALTER TABLE tasks ADD COLUMN start_time TEXT"); }
      if (!colsTasks.contains('prompt'))     { await db.execute("ALTER TABLE tasks ADD COLUMN prompt TEXT"); }
      if (!colsTasks.contains('avatar'))     { await db.execute("ALTER TABLE tasks ADD COLUMN avatar TEXT"); }
      if (!colsTasks.contains('status'))     { await db.execute("ALTER TABLE tasks ADD COLUMN status TEXT"); }
      if (!colsTasks.contains('cursor'))     { await db.execute("ALTER TABLE tasks ADD COLUMN cursor INTEGER DEFAULT 0"); }
      // configs: ensure required columns (notice_id aka id, api_key, bg_image, model, endpoint)
      var infoCfg = await db.rawQuery("PRAGMA table_info(configs)");
      var colsCfg = infoCfg.map((e)=> e['name'] as String).toList();
      if (!colsCfg.contains('bg_image'))     { await db.execute("ALTER TABLE configs ADD COLUMN bg_image TEXT"); }
      // Foreign key relationships (best-effort: create views/triggers if needed)
      await db.execute("PRAGMA foreign_keys=ON");
      // Ensure snapshots columns
      final info = await db.rawQuery("PRAGMA table_info(logs)");
      final cols = info.map((e)=> e['name'] as String).toList();
      if (!cols.contains('task_name_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_name_snapshot TEXT");
      }
      if (!cols.contains('task_start_time_snapshot')) {
        await db.execute("ALTER TABLE logs ADD COLUMN task_start_time_snapshot TEXT");
      }
    }
  }
}
