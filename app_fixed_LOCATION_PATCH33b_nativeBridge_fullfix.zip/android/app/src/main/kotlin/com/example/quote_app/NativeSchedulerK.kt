package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.os.Build
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import android.os.Handler
import android.os.Looper

object NativeSchedulerK {

    fun register(engine: FlutterEngine, ctx: Context) {
        val channel = MethodChannel(engine.dartExecutor.binaryMessenger, Channels.SCHED)
        channel.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            when (call.method) {
                "canScheduleExact" -> {
                    val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        am.canScheduleExactAlarms()
                    } else {
                        true
                    }
                    result.success(ok)
                }
                else -> result.notImplemented()
            }
        }
    }
}
