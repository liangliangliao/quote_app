package com.example.quote_app

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

object SysChannel {

    fun register(engine: FlutterEngine, ctx: Context) {
        val ch = MethodChannel(engine.dartExecutor.binaryMessenger, Channels.SYS)
        ch.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            when (call.method) {
                "getBaiduLocationOnce" -> {
                    // Run on background thread to avoid blocking platform thread
                    Thread {
                        val map = BaiduLocator.getBaiduLocationOnce(ctx, 30_000L)
                        Handler(Looper.getMainLooper()).post {
                            result.success(map)
                        }
                    }.start()
                }
                "reverseGeocodeBaidu" -> {
                    val lat = (call.argument<Double>("lat") ?: 0.0)
                    val lon = (call.argument<Double>("lon") ?: 0.0)
                    val ak  = call.argument<String>("ak") ?: ""
                    Thread {
                        val map = BaiduLocator.reverseGeocodeBaidu(lat, lon, ak)
                        Handler(Looper.getMainLooper()).post {
                            result.success(map)
                        }
                    }.start()
                }
                else -> result.notImplemented()
            }
        }
    }
}
