package com.example.quote_app

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class AlarmProxyWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
  override fun doWork(): Result = Result.success()
}