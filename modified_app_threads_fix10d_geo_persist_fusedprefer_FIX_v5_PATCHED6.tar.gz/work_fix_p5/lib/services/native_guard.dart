import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/services.dart';

// Pages
import '../pages/home_page.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../pages/discover_page.dart';
import 'package:flutter/material.dart';

/// Native capability guard (kept minimal and backwards-compatible)
class NativeGuard {
  static const _ch = MethodChannel('com.example.quote_app/sys');

static Future<bool> isNativeAM() async {
  // Some pages call this legacy probe; keep it as an alias/fallback.
  try {
    final ok = await _ch.invokeMethod('isNativeAmEnabled');
    return ok == true;
  } catch (_) {
    // Fallback to WM probe if the native side doesn't implement AM.
    try {
      return await isNativeWM();
    } catch (_) {
      return false;
    }
  }
}


  static Future<bool> isNativeWM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeWmEnabled');
      return ok == true;
    } catch (_) {
      return false;
    }
  }

  static bool _notifHandlerInstalled = false;

  /// 确保原生通知点击事件能推送到 Flutter（事件驱动，避免轮询）
  static void ensureNotificationTapHandler() {
    if (_notifHandlerInstalled) return;
    _notifHandlerInstalled = true;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'onNativeNotificationTap') {
        // call.arguments may be null or a map containing type/payload
        final args = call.arguments;
        String? type;
        String? payload;
        if (args is Map) {
          final dynamic t = args['type'];
          final dynamic p = args['payload'];
          if (t is String) type = t;
          if (p is String) payload = p;
        }
        try {
          await DLog.i('NotifTap', 'NativeGuard handler: onNativeNotificationTap type='+ (type ?? 'null'));
        } catch (_) {}
        // Handle vision focus notifications by navigating to VisionFocusPreparePage
        if (type == 'vision_focus') {
          try {
            // Load current vision goal
            final dao = VisionDao();
            final goal = await dao.loadGoal();
            if (goal != null) {
              final nav = SimpleBus.navigatorKey.currentState;
              if (nav != null) {
                nav.push(
                  MaterialPageRoute(
                    builder: (_) => VisionFocusPreparePage(goal: goal),
                  ),
                );
                return null;
              }
            }
          } catch (_) {}
          // Fallback: navigate home
          try {
            SimpleBus.navHome();
            SimpleBus.pokeHome();
          } catch (_) {}
        } else {
          try {
            SimpleBus.navHome();
            SimpleBus.pokeHome();
          } catch (_) {}
        }
      }
      return null;
    });
  }

  /// 由 Dart 主页面查询：是否有一次原生通知点击待消费（冷启动兜底）
  static Future<bool> consumeLaunchFromNotificationFlag() async {
    try {
      final v = await _ch.invokeMethod<bool>('consumeLaunchFromNotificationFlag');
      return v ?? false;
    } catch (_) {
      return false;
    }
  }
}

/// App-wide simple event bus & navigation utilities.
/// Many pages rely on these static members; keep names unchanged.
class SimpleBus {
  // Global navigator for out-of-context navigation (e.g., from notification callbacks)
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  // Bottom nav index (if used by the app)
  static final ValueNotifier<int> navIndex = ValueNotifier<int>(0);

  // Page refresh ticks
  static final ValueNotifier<int> homeTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> logsTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> settingsTick = ValueNotifier<int>(0);

  static bool _inited = false;

  static void init() {
    if (_inited) return;
    _inited = true;
  }

  /// Navigate to Home by replacing the whole stack.
  static void navHome() {
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    // 回到根路由（RootShell），保持底部导航栏不消失
    nav.popUntil((route) => route.isFirst);
    // 切到首页 Tab
    try { navIndex.value = 0; } catch (_) {}
    try { pokeHome(); } catch (_) {}
  }

  /// Notify home to refresh
  static void pokeHome() { homeTick.value = homeTick.value + 1; }

  /// Notify logs page to refresh
  static void pokeLogs() { logsTick.value = logsTick.value + 1; }

  /// Notify settings page to refresh
  static void pokeSettings() { settingsTick.value = settingsTick.value + 1; }
}