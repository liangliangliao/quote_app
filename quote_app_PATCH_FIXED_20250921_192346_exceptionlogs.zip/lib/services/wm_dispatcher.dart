import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'notification_service.dart';
import '../data/db.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    await DLog.i('WM', 'workmanager dispatch');
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    await AppDatabase.instance();
    await SchedulerService.callback();
    // 补发一次（当天漏发）
    try { await SchedulerService.catchupIfMissed(); } catch (e, s) {
      await DLog.e('wm_dispatcher.dart', 'catch: ' + e.toString());
    }
    return Future.value(true);
  });
}
