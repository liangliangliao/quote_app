package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.os.Environment
import java.io.File

object Channels {
  private lateinit var appContext: Context
    fun areNotificationsEnabled(): Boolean {
        return try {
            val nm = androidx.core.app.NotificationManagerCompat.from(appContext)
            nm.areNotificationsEnabled()
        } catch (_: Throwable) { true }
    }

  private const val CH = "native.scheduler"

  
    fun register(engine: FlutterEngine, appCtx: Context) {
        appContext = appCtx.applicationContext
        val channel = MethodChannel(engine.dartExecutor.binaryMessenger, "quote.app/native")
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "areNotificationsEnabled" -> {
                    result.success(areNotificationsEnabled())
                    return@setMethodCallHandler
                }
                "shouldAskExactAlarm" -> {
                    val firstLaunch = (call.argument<Boolean>("firstLaunch") ?: false)
                    result.success(shouldAskExactAlarm(firstLaunch))
                    return@setMethodCallHandler
                }
                else -> {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
            }
        }
    }


    fun shouldAskExactAlarm(firstLaunch: Boolean): Boolean {
        if (!firstLaunch) return false
        return areNotificationsEnabled()
    }
