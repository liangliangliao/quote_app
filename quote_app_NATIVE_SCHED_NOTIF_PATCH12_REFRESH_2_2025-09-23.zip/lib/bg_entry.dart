import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'services/scheduler_service.dart';

@pragma('vm:entry-point')
void bgMain() {
  WidgetsFlutterBinding.ensureInitialized();
  const MethodChannel ch = MethodChannel('com.example.quote_app/bg');
  ch.setMethodCallHandler((call) async {
    if (call.method == 'onAlarm') {
      final uid = (call.arguments as Map)['taskUid']?.toString() ?? '';
      if (uid.isNotEmpty) {
        await SchedulerService.onAlarmFired(uid);
      }
      return null;
    } else if (call.method == 'onBoot') {
      await SchedulerService.rescheduleAllActiveTasks();
      return null;
    }
    throw PlatformException(code: 'unimplemented', message: 'Unknown method ${call.method}');
  });
}
