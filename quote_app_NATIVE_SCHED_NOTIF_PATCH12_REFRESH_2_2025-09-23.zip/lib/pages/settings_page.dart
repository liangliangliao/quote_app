import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _apiKey = TextEditingController();
  final _model = TextEditingController(text: 'gpt-5');
  final _endpoint = TextEditingController(text: 'https://api.openai.com/v1/responses');
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await ConfigDao().getOne();
    _apiKey.text = (cfg['api_key'] ?? '').toString();
    _model.text = (cfg['model'] ?? 'gpt-5').toString();
    _endpoint.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses').toString();
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    await ConfigDao().save(
      apiKey: _apiKey.text.trim(),
      model: _model.text.trim(),
      endpoint: _endpoint.text.trim(),
    );
    await SchedulerService.rescheduleAllActiveTasks();
    if (!mounted) return;
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('保存成功，已重新安排任务')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('OpenAI API Key'),
          TextField(controller: _apiKey, decoration: const InputDecoration(hintText: 'sk-...')),
          const SizedBox(height: 12),
          const Text('模型（为空则默认 gpt-5）'),
          TextField(controller: _model, decoration: const InputDecoration(hintText: 'gpt-5 / gpt-4o-mini / ...')),
          const SizedBox(height: 12),
          const Text('接口地址（/v1/responses 或 /v1/chat/completions 或 /v1/embeddings）'),
          TextField(controller: _endpoint, decoration: const InputDecoration(hintText: 'https://api.openai.com/v1/responses')),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: const Icon(Icons.save),
            label: Text(_saving ? '保存中...' : '保存并重新安排'),
          ),
        ],
      ),
    );
  }
}
