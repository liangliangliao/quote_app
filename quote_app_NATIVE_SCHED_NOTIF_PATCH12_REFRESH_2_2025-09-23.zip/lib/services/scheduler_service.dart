import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../data/dao.dart';
import '../data/dao_helpers.dart';
import '../data/db.dart';
import '../utils/text_utils.dart';
import 'notification_service.dart';
import 'openai_service.dart';

/// 统一调度服务
class SchedulerService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');
  static const MethodChannel _schedCh = MethodChannel('com.example.quote_app/sched');

  static Future<void> init() async {
    await AppDatabase.instance();
    await NotificationService.init();
  }

  /// App 启动或开机重启后重新安排所有开启任务
  static Future<void> rescheduleAllActiveTasks() async {
    final tasks = await TaskDao().listActive();
    for (final t in tasks) {
      await scheduleNextForTask(t);
    }
  }

  /// 安排某任务的下一次触发点（每天固定时间）
  static Future<void> scheduleNextForTask(Map<String, dynamic> task) async {
    final when = _nextPlannedDateTime(task);
    if (when == null) return;
    final uid = (task['task_uid'] ?? '').toString();
    final ms = when.millisecondsSinceEpoch;
    try {
      await _schedCh.invokeMethod('scheduleExact', {'taskUid': uid, 'when': ms});
    } catch (_) {}
  }

  static DateTime? _parseTimeOrToday(String hhmm) {
    final now = DateTime.now();
    try {
      final dt = DateFormat('HH:mm').parseStrict(hhmm);
      return DateTime(now.year, now.month, now.day, dt.hour, dt.minute);
    } catch (_) {
      return null;
    }
  }

  static DateTime? _nextPlannedDateTime(Map<String, dynamic> task) {
    final startStr = (task['start_time'] ?? '').toString();
    final base = _parseTimeOrToday(startStr);
    if (base == null) return null;
    final now = DateTime.now();
    return now.isAfter(base) ? base.add(const Duration(days: 1)) : base;
  }

  /// 原生 AlarmReceiver 触达后由 Dart 侧处理
  static Future<void> onAlarmFired(String taskUid) async {
    final t = await TaskDao().getByUid(taskUid);
    if (t == null) return;
    final enabled = (t['enabled'] ?? 0) == 1;
    if (!enabled) return; // 2.1.2 关闭则不继续

    await _sendForTask(t);
    // 下次
    await scheduleNextForTask(t);
  }

  /// 业务派发（自动/手动/轮播）
  static Future<void> _sendForTask(Map<String, dynamic> t) async {
    final type = (t['type'] ?? 'manual').toString();

    if (type == 'carousel') {
      // 轮播：正序循环取不同名言
      final row = await QuoteDao().carouselNextSequential(t['task_uid'].toString());
      if (row == null) return;
      final title = (t['name'] ?? '').toString();
      final avatar = (t['avatar_path'] ?? '').toString();
      final body = (row['content'] ?? '').toString();
      await NotificationService.show(
        title: title,
        body: body,
        payload: t['task_uid'].toString(),
        avatarPath: avatar.isEmpty ? null : avatar,
      );
      await QuoteDao().markNotified(row['quote_uid'].toString());
      return;
    }

    if (type == 'manual') {
      // 手动任务：直接取对应名言内容
      final row = await QuoteDao().latestForTask(t['task_uid'].toString());
      if (row == null) return;
      final title = (t['name'] ?? '').toString();
      final avatar = (t['avatar_path'] ?? '').toString();
      final body = (row['content'] ?? '').toString();
      await NotificationService.show(
        title: title,
        body: body,
        payload: t['task_uid'].toString(),
        avatarPath: avatar.isEmpty ? null : avatar,
      );
      await QuoteDao().markNotified(row['quote_uid'].toString());
      return;
    }

    // 自动任务
    await _handleAutoTask(t);
  }

  static Future<void> _handleAutoTask(Map<String, dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    final prompt = (t['prompt'] ?? '').toString();

    final cfg = await ConfigDao().getOne();
    final model = (cfg['model'] ?? 'gpt-5').toString().trim().isEmpty ? 'gpt-5' : (cfg['model'] ?? 'gpt-5').toString();
    final key = (cfg['api_key'] ?? '').toString();
    final endpoint = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses').toString();

    if (key.isEmpty) {
      await LogDao().add(taskUid: uid, detail: '调用openai api发生错误或失败!(缺少api key)');
      return;
    }

    // 最多重试去重 10 次
    int tries = 0;
    String? accepted;
    while (tries < 10 && accepted == null) {
      tries++;
      try {
        final api = OpenAIService(endpoint: endpoint, apiKey: key, model: model);
        final content = (await api.generateQuote(prompt)).trim();
        if (content.isEmpty) throw Exception('空返回');

        final ok = await _dedupCheck(uid, content, key); // 语义>0.9 判定
        if (ok) {
          accepted = content;
          break;
        } else {
          await LogDao().add(taskUid: uid, detail: '去重未通过，重试第$tries次');
        }
      } catch (e) {
        await LogDao().add(taskUid: uid, detail: '调用openai api发生错误或失败!');
        return;
      }
    }

    if (accepted == null) {
      // 连续10次失败
      await LogDao().add(taskUid: uid, detail: '错误!连续调用api10次去重检验未通过！');
      return;
    }

    // 去重通过：插入数据+日志+通知
    final qUid = await QuoteDao().insert(
      taskUid: uid,
      taskName: (t['name'] ?? '').toString(),
      avatar: (t['avatar_path'] ?? '').toString(),
      content: accepted,
      taskType: (t['type'] ?? '').toString(),
    );
    await LogDao().add(taskUid: uid, detail: '成功!');

    final title = (t['name'] ?? '').toString();
    final avatar = (t['avatar_path'] ?? '').toString();
    await NotificationService.show(
      title: title,
      body: accepted,
      payload: uid,
      avatarPath: avatar.isEmpty ? null : avatar,
    );
    await QuoteDao().markNotified(qUid);
  }

  /// 语义去重：如有 embeddings 配置则调用，否则回退到 Jaro-Winkler 文本相似度
  static Future<bool> _dedupCheck(String taskUid, String candidate, String apiKey) async {
    final rows = await QuoteDao().allContentsForTask(taskUid);
    if (rows.isEmpty) return true;

    final corpus = rows.map((e) => (e['content'] ?? '').toString()).toList();
    final cand = normalizeText(candidate);

    // 优先 embeddings
    try {
      final cfg = await ConfigDao().getOne();
      final model = (cfg['model'] ?? '').toString();
      final endpoint = (cfg['endpoint'] ?? '').toString();
      if (apiKey.isNotEmpty) {
        final api = OpenAIService(endpoint: endpoint.isEmpty ? 'https://api.openai.com/v1/embeddings' : endpoint, apiKey: apiKey, model: model);
        final sims = await api.cosineSimilarities(cand, corpus.map(normalizeText).toList());
        if (sims.isNotEmpty && sims.reduce((a,b)=> a>b? a:b) >= 0.9) return false;
      }
    } catch (_) {}

    // 回退本地相似度
    double mx = 0;
    for (final s in corpus.map(normalizeText)) {
      final v = jaroWinkler(cand, s);
      if (v > mx) mx = v;
      if (mx >= 0.9) break;
    }
    return mx < 0.9;
  }
}
