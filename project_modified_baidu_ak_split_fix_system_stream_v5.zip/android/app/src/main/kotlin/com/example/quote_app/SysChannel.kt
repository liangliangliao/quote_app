
package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.example.quote_app.data.DbRepo
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import com.google.android.gms.location.*
import android.os.Handler
import java.util.concurrent.atomic.AtomicBoolean
import com.baidu.mapapi.model.LatLng
import com.baidu.mapapi.search.core.SearchResult
import com.baidu.mapapi.search.geocode.GeoCoder
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult
import com.baidu.mapapi.search.geocode.GeoCodeResult

object SysChannel {
  private const val CHANNEL = "com.example.quote_app/sys"

  fun register(engine: FlutterEngine, appContext: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
      when (call.method) {
        "getBaiduLocationOnce" -> {
          // IMPORTANT: Do NOT block the platform (main) thread here.
          // Location acquisition uses CountDownLatch.await internally; running it on the
          // main thread will cause ANR and freeze Flutter loading spinners.
          Thread {
            try {
              val ak = try { readBaiduAk(appContext) } catch (_: Throwable) { "oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh" }
              // Accept <= 31m (inclusive) per product requirement.
              val loc = obtainBaiduLocation(appContext, ak, 40.0, 12_000L)
              Handler(Looper.getMainLooper()).post {
                if (loc != null) {
                  val map = mapOf(
                    "lat" to loc.latitude,
                    "lng" to loc.longitude,
                    "acc" to loc.accuracy,
                    "provider" to (loc.provider ?: "baidu")
                  )
                  logWithTime(appContext, "【LocationService】【定位】Baidu SDK 成功 acc=${loc.accuracy}")
                  result.success(map)
                } else {
                  logWithTime(appContext, "【LocationService】【定位】Baidu SDK 失败")
                  result.error("NO_LOC", "baidu failed", null)
                }
              }
            } catch (t: Throwable) {
              Handler(Looper.getMainLooper()).post {
                logWithTime(appContext, "【LocationService】【定位】Baidu SDK 异常：" + (t.message ?: "unknown"))
                result.error("EX", t.message, null)
              }
            }
          }.start()
        }
        
        "reverseGeocodePoisBaiduSdk" -> {
          try {
            val lat = (call.argument<Number>("lat") ?: 0).toDouble()
            val lng = (call.argument<Number>("lng") ?: 0).toDouble()
            val radius = (call.argument<Number>("radius") ?: 50).toInt()
            reverseGeocodeBaiduSdk(appContext, lat, lng, radius, result)
          } catch (e: Throwable) {
            logWithTime(appContext, "【LocationService】【逆地理】Baidu SDK 逆地理异常: ${'$'}e")
            result.success(mapOf("pois" to emptyList<Map<String, Any?>>(), "address" to ""))
          }
        }

        "getSystemLocationOnce" -> {
          // IMPORTANT: Do NOT block the platform (main) thread here.
          // The internal implementation awaits on a latch while receiving updates on the
          // main looper; awaiting on the main thread itself will deadlock/ANR.
          Thread {
            try {
              logWithTime(appContext, "【LocationService】【定位】优先使用 Fused 高精度流")
              // Accept <= 31m (inclusive)
              var loc: Location? = obtainFusedHighAcc(appContext, 40.0, 12_000L)
              if (loc == null) loc = obtainHighAccuracyLocation(appContext, 40.0, 10_000L)
              Handler(Looper.getMainLooper()).post {
                if (loc == null) {
                  result.error("NO_LOC", "system failed", null)
                } else {
                  val map = mapOf(
                    "lat" to loc!!.latitude,
                    "lng" to loc!!.longitude,
                    "acc" to loc!!.accuracy,
                    "provider" to (loc!!.provider ?: "system")
                  )
                  logWithTime(appContext, "【LocationService】【定位】System 成功 acc=${loc!!.accuracy}")
                  result.success(map)
                }
              }
            } catch (t: Throwable) {
              Handler(Looper.getMainLooper()).post {
                logWithTime(appContext, "【LocationService】【定位】System 异常：" + (t.message ?: "unknown"))
                result.error("EX", t.message, null)
              }
            }
          }.start()
        }
        else -> result.notImplemented()
      }
    }
  }

  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) { try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {} }
  }

  private fun readBaiduAk(ctx: Context): String {
    val defAndroid = "oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh"
    val defWeb = "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx)
      val path = cc?.dbPath
      if (path.isNullOrEmpty()) return defAndroid
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try {
        var v: String? = null
        try {
          db.rawQuery("SELECT baidu_ak_android FROM configs LIMIT 1", null).use { c ->
            if (c.moveToFirst()) v = c.getString(0)
          }
        } catch (_: Throwable) { /* 表/列不存在时忽略 */ }

        if (v == null || v!!.trim().isEmpty()) {
          // 兼容旧列：只有当旧列不是默认 Web AK 时才沿用（避免误用 Web AK 触发 505）
          var oldV: String? = null
          try {
            db.rawQuery("SELECT baidu_ak FROM configs LIMIT 1", null).use { c ->
              if (c.moveToFirst()) oldV = c.getString(0)
            }
          } catch (_: Throwable) {}
          if (oldV != null) {
            val vv = oldV!!.trim()
            if (vv.isNotEmpty() && vv != defWeb) v = vv
          }
        }

        val out = v?.trim() ?: ""
        if (out.isEmpty()) defAndroid else out
      } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) {
      defAndroid
    }
  }
  private fun obtainFusedHighAcc(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
  return try {
    val client = LocationServices.getFusedLocationProviderClient(ctx)
    val latch = java.util.concurrent.CountDownLatch(1)
    var best: Location? = null
    var prev: Location? = null
    var count = 0
    val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
      .setWaitForAccurateLocation(true)
      .setMaxUpdates(8)
      .build()
    val cb = object: LocationCallback() {
      override fun onLocationResult(result: LocationResult) {
        for (l in result.locations) {
          count++
          if (best == null || l.accuracy < best!!.accuracy) best = l
        }
        // 要求至少 2 次更新；若是 GPS 且达标可提前返回；否则需要两次结果收敛
        val b = best
        if (b != null) {
          val isGps = "gps".equals(b.provider, true)
          val accOk = b.accuracy <= targetAccMeters
          val enough = count >= 2
          var converge = false
          if (prev != null && b != null) {
            try {
              val results = FloatArray(1)
              android.location.Location.distanceBetween(prev!!.latitude, prev!!.longitude, b.latitude, b.longitude, results)
              converge = results[0] <= 80f
            } catch (_: Throwable) {}
          }
          if ((isGps && accOk) || (accOk && enough && converge)) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
          prev = b
        }
      }
    }
    client.requestLocationUpdates(req, cb, Looper.getMainLooper())
    try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
    try { client.removeLocationUpdates(cb) } catch (_: Throwable) {}
    best
  } catch (_: Throwable) { null }
}