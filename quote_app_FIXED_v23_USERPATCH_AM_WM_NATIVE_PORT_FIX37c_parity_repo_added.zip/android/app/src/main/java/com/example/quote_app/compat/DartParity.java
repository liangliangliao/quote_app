package com.example.quote_app.compat;

import android.content.Context;
import android.text.TextUtils;

import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.data.DbRepository;

import org.json.JSONObject;

public final class DartParity {
    private DartParity() {}

    public static int alarmId(String uid, String runKey) {
        String k = (uid == null ? "" : uid) + "#" + (runKey == null ? "" : runKey);
        return k.hashCode();
    }

    public static boolean canScheduleExact(Context ctx) {
        try {
            return com.example.quote_app.ExactAlarmHelper.INSTANCE.hasExactAlarmPermission(ctx);
        } catch (Throwable ignored) { return true; }
    }

    public static boolean requestExactPermission(Context ctx) { return true; }

    public static boolean scheduleExactAt(Context ctx, long epochMs, String uid, String runKey, String payloadJson) {
        if (epochMs <= 0L || TextUtils.isEmpty(uid)) return false;
        final int id = alarmId(uid, runKey);
        String p;
        try {
            if (TextUtils.isEmpty(payloadJson)) {
                p = new JSONObject().put("uid", uid).put("runKey", runKey).put("chan","am").toString();
            } else {
                p = payloadJson;
            }
        } catch (Throwable e) { p = "{"uid":""+uid+"","runKey":""+(runKey==null?"":runKey)+"","chan":"am"}"; }
        boolean ok = false;
        try { ok = NativeSchedulerK.scheduleExactWmCompat(ctx, id, epochMs, p); } catch (Throwable ignored) {}
        try { DbRepository.setScheduledRunKey(ctx, uid, TextUtils.isEmpty(runKey) ? String.valueOf(epochMs) : runKey); } catch (Throwable ignored) {}
        return ok;
    }

    public static void cancel(Context ctx, String uid, String runKey) {
        int id = alarmId(uid, runKey);
        try { NativeSchedulerK.cancel(ctx, id); } catch (Throwable ignored) {}
    }

    public static void cancelAll(Context ctx) {
        try { NativeSchedulerK.cancelAll(ctx); } catch (Throwable ignored) {}
    }

    public static boolean alreadySent(Context ctx, String uid, String runKey, String chan, int attempt) {
        try { return DbRepository.alreadySent(ctx, uid, runKey, chan, attempt); }
        catch (Throwable ignored) { return false; }
    }

    public static void markAlreadySent(Context ctx, String uid, String runKey, String chan, int attempt) {
        try { DbRepository.markAlreadySent(ctx, uid, runKey, chan, attempt); } catch (Throwable ignored) {}
    }
}