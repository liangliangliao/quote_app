import 'package:flutter/material.dart';
import '../platform/native_scheduler.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _ctrl = TextEditingController(text: '15');

  Future<void> _save() async {
    final v = int.tryParse(_ctrl.text) ?? 15;
    await NativeScheduler.scheduleSelfCheck(v);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已保存并启用自检'), duration: Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('自检频率（分钟）', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: _ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: '>=15')),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: _save, child: const Text('保存并生效')),
          ],
        ),
      ),
    );
  }
}
