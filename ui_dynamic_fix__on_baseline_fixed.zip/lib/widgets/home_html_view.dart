
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
    if (d == null || d.isEmpty) return;
    final payload = jsonEncode({
      'topic': (d['topic'] ?? d['topic_text'] ?? d['theme'] ?? ''),
      'quote': (d['content'] ?? d['quote'] ?? d['quote_text'] ?? ''),
      'author': (() { final a=(d['author'] ?? d['signature'] ?? d['署名']); final s=(d['source'] ?? d['出处']); if (a!=null && a.toString().isNotEmpty) {return '---' + a.toString() + (s!=null && s.toString().isNotEmpty ? '《' + s.toString() + '》' : ''); } return (d['authorText'] ?? d['author_text'] ?? ''); })(),
      'note': (d['explain'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? ''),
      'avatarUrl': (d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['portrait_url'] ?? ''),
      if (d.containsKey('focalX')) 'focalX': d['focalX'],
      if (d.containsKey('focalY')) 'focalY': d['focalY'],
    });
    try { await _controller.runJavaScript('window.setDynamicData($payload);'); } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
