package com.example.quote_app.schedule;

import android.content.Context;
import android.text.TextUtils;

import com.example.quote_app.data.DbRepository;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public final class NextTriggerCalculator {
    private NextTriggerCalculator() {}

    /** 精准计算：读取 next_time；若无或已过期，则基于 start_time(HH:mm) 计算今日/次日；最后更新 DB 并返回 */
    public static long compute(Context ctx, String uid) {
        long now = System.currentTimeMillis();
        try {
            Map<String,String> t = DbRepository.getTaskTimeInfo(ctx, uid);
            if (t == null || t.isEmpty()) {
                return fallbackPlusOneDay(now);
            }
            // 检查是否启用
            String enabled = safe(t.get("enabled"));
            if ("0".equals(enabled) || "off".equalsIgnoreCase(enabled)) {
                return fallbackPlusOneDay(now);
            }
            // 优先 next_time（支持 INTEGER/TEXT）
            Long next = parseEpochOrNull(t.get("next_time"));
            if (next != null && next > now) {
                return next;
            }
            // 解析 start_time：支持 "HH:mm" 或 "yyyy-MM-dd HH:mm[:ss]"
            String st = safe(t.get("start_time"));
            long calculated = calcFromStartTime(st, now);
            if (calculated <= now) calculated = addDays(calculated, 1);
            // 更新 DB
            try { DbRepository.updateNextTime(ctx, uid, calculated); } catch (Throwable ignore) {}
            return calculated;
        } catch (Throwable e) {
            return fallbackPlusOneDay(now);
        }
    }

    private static long fallbackPlusOneDay(long now) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTimeInMillis();
    }

    private static String safe(String s) { return s == null ? "" : s; }

    private static Long parseEpochOrNull(String s) {
        if (TextUtils.isEmpty(s)) return null;
        try {
            // integer epoch ms or seconds
            if (s.matches("^\\d{10,}$")) {
                long v = Long.parseLong(s);
                if (v < 1000_000_000_000L) v = v * 1000L; // seconds -> millis
                return v;
            }
        } catch (Throwable ignore) {}
        // try date string
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date d = sdf.parse(s);
            if (d != null) return d.getTime();
        } catch (Throwable ignore) {}
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Date d = sdf.parse(s);
            if (d != null) return d.getTime();
        } catch (Throwable ignore) {}
        return null;
    }

    private static long calcFromStartTime(String start, long now) {
        Calendar nowCal = Calendar.getInstance();
        nowCal.setTimeInMillis(now);
        int yyyy = nowCal.get(Calendar.YEAR);
        int MM = nowCal.get(Calendar.MONTH);
        int dd = nowCal.get(Calendar.DAY_OF_MONTH);

        if (TextUtils.isEmpty(start)) start = "09:00";

        // absolute: yyyy-MM-dd HH:mm[:ss]
        if (start.matches("^\\d{4}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}(:\\d{2})?$")) {
            try {
                String pattern = (start.trim().length() == 16) ? "yyyy-MM-dd HH:mm" : "yyyy-MM-dd HH:mm:ss";
                SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
                sdf.setLenient(false);
                Date d = sdf.parse(start);
                if (d != null) return d.getTime();
            } catch (Throwable ignore) { /* fallback to HH:mm */ }
        }

        // HH:mm
        int hh = 9, mm = 0;
        try {
            String[] sp = start.trim().split(":");
            hh = Integer.parseInt(sp[0]);
            mm = Integer.parseInt(sp[1]);
        } catch (Throwable ignore) {}
        Calendar cal = Calendar.getInstance();
        cal.set(yyyy, MM, dd, hh, mm, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    private static long addDays(long ts, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(ts);
        cal.add(Calendar.DAY_OF_YEAR, days);
        return cal.getTimeInMillis();
    }
}
