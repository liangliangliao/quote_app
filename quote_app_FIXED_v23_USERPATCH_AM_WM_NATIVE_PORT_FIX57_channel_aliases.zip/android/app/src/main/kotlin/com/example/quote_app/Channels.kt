package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

object Channels {
  private const val CH = "native.scheduler"

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
          "canScheduleExact" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(if (appCtx is android.app.Activity) appCtx else return@setMethodCallHandler result.success(false)))
          "scheduleExactAt" -> {
            val id = call.argument<Int>("id") ?: 0
            val whenMs = call.argument<Long>("when") ?: 0L
            val payload = call.argument<String>("payload")
            val ok = NativeSchedulerK.scheduleExactWmCompat(appCtx, id, whenMs, payload)
            result.success(ok)
          }
          "cancel" -> {
            val id = call.argument<Int>("id") ?: 0
            NativeSchedulerK.cancel(appCtx, id)
            result.success(null)
          }
          "cancelAll" -> { NativeSchedulerK.cancelAll(appCtx); result.success(null) }
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
  }
}