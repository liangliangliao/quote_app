package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.os.Build
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.app.Activity

object ExactAlarmHelper {
    fun hasExactAlarmPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
            val am = context.applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.canScheduleExactAlarms()
        } catch (e: Exception) {
            true // 乐观：偶发异常时按 true 处理，避免抖动
        }
        } else {
            true
        }
    
    fun requestExactAlarmPermission(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${ctx.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
                true
            } catch (t: Throwable) {
                false
            }
        } else {
            true
        }
    }
                activity.startActivity(intent)
                true
            } catch (t: Throwable) {
                false
            }
        } else {
            true
        }
    }

}
