
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    try { controller.runJavaScript(\"window.setBackground('file:///android_asset/flutter_assets/assets/html/bg-wood-upload.jpg')\"); } catch (e) {} super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
    if (d == null || d.isEmpty) return;
    // Normalize avatar before injecting: convert relative file names into image directory under assets/html
    String _normalizeAvatar(dynamic raw) {
      final v = (raw ?? '').toString().trim();
      if (v.isEmpty) return '';
      if (v.startsWith('http://') || v.startsWith('https://') || v.startsWith('data:image')) return v;
      // If this is an absolute or relative file path (contains '/'), prefix with file:// to be loaded by WebView
      if (v.contains('/')) {
        // Use file URI for local paths
        return Uri.file(v).toString();
      }
      // Otherwise map to img/avatars/<name> relative to html; fallback to remote images if placed there
      final onlyName = v;
      return 'img/avatars/$onlyName';
    }
    final payload = jsonEncode({
      // Use multiple fallbacks for each field to support different DB schemas
      'topic': (d['topic'] ?? d['topic_text'] ?? d['theme'] ?? ''),
      'quote': (d['content'] ?? d['quote'] ?? d['quote_text'] ?? ''),
      // For author, prefer author / author_name / signature / 署名 then build with source/source_from/出处
      'author': (() {
        final a = (d['author'] ?? d['author_name'] ?? d['signature'] ?? d['署名']);
        final s = (d['source'] ?? d['source_from'] ?? d['出处']);
        if (a != null && a.toString().isNotEmpty) {
          return '---' + a.toString() + (s != null && s.toString().isNotEmpty ? '《' + s.toString() + '》' : '');
        }
        return (d['authorText'] ?? d['author_text'] ?? '');
      })(),
      // For note/explanation use multiple fallbacks
      'note': (d['explain'] ?? d['explanation'] ?? d['note'] ?? d['comment'] ?? d['memo'] ?? ''),
      // For avatar use various fallback keys
      'avatarUrl': _normalizeAvatar(
        d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
      ),
      if (d.containsKey('focalX')) 'focalX': d['focalX'],
      if (d.containsKey('focalY')) 'focalY': d['focalY'],
    });
    try { await _controller.runJavaScript('window.setDynamicData($payload);'); } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
