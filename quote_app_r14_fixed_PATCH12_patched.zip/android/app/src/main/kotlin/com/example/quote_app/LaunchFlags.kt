package com.example.quote_app

/**
 * Simple process-wide flags used to bridge native events (such as tapping a
 * notification) to Dart.  They are consumed via a MethodChannel on the Dart
 * side and kept intentionally minimal.
 */
object LaunchFlags {
  @Volatile
  var tappedNotification: Boolean = false

  fun markNotificationTapped() {
    tappedNotification = true
  }

  fun consumeNotificationTappedFlag(): Boolean {
    val v = tappedNotification
    tappedNotification = false
    return v
  }
}
