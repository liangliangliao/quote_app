package com.example.quote_app

import android.os.Bundle
import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 仅注册通道；不引入业务逻辑，避免后续维护成本
        Channels.register(flutterEngine, applicationContext) // Context 在前，Engine 在后
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent?.let { maybeMarkFromNotification(it) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        maybeMarkFromNotification(intent)
    }

    private fun maybeMarkFromNotification(intent: Intent) {
        if (intent.getBooleanExtra("from_notification", false)) {
            LaunchFlags.markNotificationTapped()
        }
    }

}
