import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/services.dart';

// Pages
import '../pages/home_page.dart';

/// Native capability guard (kept minimal and backwards-compatible)
class NativeGuard {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  /// Consume and clear the native "launched from notification" flag.
  /// Returns true exactly once per tap on a native notification.
  static Future<bool> consumeLaunchFromNotificationFlag() async {
    try {
      final v = await _ch.invokeMethod<bool>('consumeLaunchFromNotificationFlag');
      return v ?? false;
    } catch (_) {
      return false;
    }
  }


static Future<bool> isNativeAM() async {
  // Some pages call this legacy probe; keep it as an alias/fallback.
  try {
    final ok = await _ch.invokeMethod('isNativeAmEnabled');
    return ok == true;
  } catch (_) {
    // Fallback to WM probe if the native side doesn't implement AM.
    try {
      return await isNativeWM();
    } catch (_) {
      return false;
    }
  }
}


  static Future<bool> isNativeWM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeWmEnabled');
      return ok == true;
    } catch (_) {
      return false;
    }
  }
}

/// App-wide simple event bus & navigation utilities.
/// Many pages rely on these static members; keep names unchanged.
class SimpleBus {
  // Global navigator for out-of-context navigation (e.g., from notification callbacks)
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  // Bottom nav index (if used by the app)
  static final ValueNotifier<int> navIndex = ValueNotifier<int>(0);

  // Page refresh ticks
  static final ValueNotifier<int> homeTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> logsTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> settingsTick = ValueNotifier<int>(0);

  static bool _inited = false;

  static void init() {
    if (_inited) return;
    _inited = true;
  }

  /// Navigate to Home by replacing the whole stack.
  static void navHome() {
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    nav.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomePage()),
      (route) => false,
    );
    // Align bottom nav & trigger refresh if the app uses these
    try { navIndex.value = 0; } catch (_) {}
    try { pokeHome(); } catch (_) {}
  }

  /// Notify home to refresh
  static void pokeHome() { homeTick.value = homeTick.value + 1; }

  /// Notify logs page to refresh
  static void pokeLogs() { logsTick.value = logsTick.value + 1; }

  /// Notify settings page to refresh
  static void pokeSettings() { settingsTick.value = settingsTick.value + 1; }
}
