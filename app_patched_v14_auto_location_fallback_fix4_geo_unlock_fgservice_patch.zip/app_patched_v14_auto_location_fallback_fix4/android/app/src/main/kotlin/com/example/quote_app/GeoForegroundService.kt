package com.example.quote_app

import android.app.*
import android.content.*
import android.location.*
import android.os.*
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import com.example.quote_app.data.DbRepo
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread
import kotlin.math.*

class GeoForegroundService : Service() {

  private val CHANNEL_ID = "geo_fg_channel"
  private val NOTIF_ID = 7771001

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    try { DbRepo.log(this, null, "【前台服务-地点规则】GeoForegroundService.onCreate") } catch (_: Throwable) {}
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // Start as a foreground service immediately
    startForeground(NOTIF_ID, buildOngoingNotification("正在获取位置..."))
    thread(name = "geo-fg-exec") {
      runCatching { executeCore() }.onFailure {
        try { DbRepo.log(this, null, "【前台服务-地点规则】执行失败：" + (it.message ?: "unknown")) } catch (_: Throwable) {}
      }.also {
        try { stopForeground(STOP_FOREGROUND_DETACH); stopSelf() } catch (_: Throwable) {}
      }
    }
    return START_NOT_STICKY
  }

  private fun buildOngoingNotification(text: String): Notification {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val ch = NotificationChannel(CHANNEL_ID, "地点前台服务", NotificationManager.IMPORTANCE_LOW)
      nm.createNotificationChannel(ch)
    }
    val pending = PendingIntent.getActivity(
      this, 0, Intent(this, MainActivity::class.java),
      PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE else 0)
    )
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("愿景提醒")
      .setContentText(text)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setOngoing(true)
      .setContentIntent(pending)
      .build()
  }

  private fun executeCore() {
    val ctx = this
    // 1) 开关判定（优先级最高）
    if (!isLocationRulesEnabled(ctx)) {
      try { DbRepo.log(ctx, null, "【前台服务-地点规则】地点规则开关为关闭，直接返回") } catch (_: Throwable) {}
      return
    }
    // 2) 读取（启用的）地点目标（仅取一条最近使用/更新时间最新的）
    val target = queryFirstGeoTarget(ctx)
    if (target == null) {
      try { DbRepo.log(ctx, null, "【前台服务-地点规则】未找到启用的地点规则，直接返回") } catch (_: Throwable) {}
      return
    }
    val (tLat, tLng) = target
    // 3) 获取当前位置（系统：高精度流<=30m）
    var loc: Location? = null
    try {
      loc = obtainHighAccuracyLocation(ctx, 30.0, 10000L)
      if (loc != null) {
        try { DbRepo.log(ctx, null, "【前台服务-地点规则】系统定位成功 acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {}
    // 4) 若失败，使用百度定位尝试（读取 AK 配置）
    if (loc == null) {
      try {
        val ak = getBaiduAk(ctx)
        loc = obtainBaiduLocation(ctx, ak, 30.0, 10000L)
        if (loc != null) {
          try { DbRepo.log(ctx, null, "【前台服务-地点规则】百度定位成功 acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
        }
      } catch (t: Throwable) {
        try { DbRepo.log(ctx, null, "【前台服务-地点规则】百度定位失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      }
    }
    // 5) 若仍失败，取系统最近已知位置
    if (loc == null) {
      try {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull {
          try { lm.getLastKnownLocation(it) } catch (_: Throwable) { null }
        }.maxByOrNull { it.time }
        loc = last
        if (loc != null) try { DbRepo.log(ctx, null, "【前台服务-地点规则】使用最近已知位置 acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
      } catch (_: Throwable) {}
    }
    if (loc == null) {
      try { DbRepo.log(ctx, null, "【前台服务-地点规则】无法获取任何位置，返回") } catch (_: Throwable) {}
      return
    }
    // 6) 距离判断并通知
    val d = distanceMeters(loc.latitude, loc.longitude, tLat, tLng)
    try { DbRepo.log(ctx, null, "【前台服务-地点规则】当前位置(${ '$' }{loc.latitude},${ '$' }{loc.longitude}) 到目标(${ '$' }tLat,${ '$' }tLng) 距离 = ${ '$' }d m") } catch (_: Throwable) {}
    if (d <= 100.0) {
      try {
        NotifyHelper.sendUnlockReminder(ctx, 901001, "愿景提醒", "你已到达目标地点，别忘了今天的一件事。")
        DbRepo.log(ctx, null, "【前台服务-地点规则】命中半径<=100m，已发送愿景提醒通知")
      } catch (_: Throwable) { }
    } else {
      try { DbRepo.log(ctx, null, "【前台服务-地点规则】未命中半径>100m，不发送提醒") } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return false
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try { db.rawQuery("SELECT location_rules_enabled FROM configs LIMIT 1", null).use { c -> return if (c.moveToFirst()) (c.getInt(0) == 1) else false } } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { false }
  }

  private fun getBaiduAk(ctx: Context): String {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
      val db = com.example.quote_app.data.DbRepository.openOrCreateFallback(ctx, cc) ?: return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
      try { db.rawQuery("SELECT baidu_ak FROM configs LIMIT 1", null).use { c -> return if (c.moveToFirst()) (c.getString(0) ?: "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2") else "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" } } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" }
  }

  private fun queryFirstGeoTarget(ctx: Context): Pair<Double, Double>? {
    return try {
      val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(ctx) ?: return null
      val db = android.database.sqlite.SQLiteDatabase.openDatabase(cc.dbPath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
      try { db.rawQuery("SELECT config FROM vision_triggers WHERE enabled=1 AND type='geo' ORDER BY updated_at DESC LIMIT 1", null).use { c -> if (!c.moveToFirst()) return null; val cfg = c.getString(0) ?: return null; val jo = JSONObject(cfg); val lat = jo.optDouble("lat", Double.NaN); val lng = jo.optDouble("lng", Double.NaN); return if (lat.isNaN() || lng.isNaN()) null else Pair(lat, lng) } } finally { try { db.close() } catch (_: Throwable) {} }
    } catch (_: Throwable) { null }
  }

  private fun obtainHighAccuracyLocation(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    try {
      val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val latch = CountDownLatch(1)
      var best: Location? = null
      val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
          if (best == null || loc.accuracy < best!!.accuracy) best = loc
          if (best != null && best!!.accuracy <= targetAccMeters) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
        }
        @Deprecated("deprecated")
        override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
      }
      try {
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
          lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
          lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
      } catch (_: Throwable) {}
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      return best
    } catch (_: Throwable) { return null }
  }

  // 尝试通过百度定位SDK获取高精度位置（若SDK/依赖缺失将直接抛出并被捕获）
  private fun obtainBaiduLocation(ctx: Context, ak: String, targetAccMeters: Double, timeoutMs: Long): Location? {
    try {
      val clazz = Class.forName("com.baidu.location.LocationClient")
      val optionClazz = Class.forName("com.baidu.location.LocationClientOption")
      val bdLocClazz = Class.forName("com.baidu.location.BDLocation")
      val client = clazz.getConstructor(Context::class.java).newInstance(ctx)
      val locField = optionClazz.getDeclaredConstructor().newInstance()
      optionClazz.getMethod("setOpenGps", Boolean::class.java).invoke(locField, true)
      optionClazz.getMethod("setLocationMode", optionClazz.getDeclaredClasses().first { it.simpleName=="LocationMode" }.getField("Hight_Accuracy").get(null)).also {
        // ok
      }
      optionClazz.getMethod("setCoorType", String::class.java).invoke(locField, "bd09ll")
      optionClazz.getMethod("setScanSpan", Int::class.java).invoke(locField, 0)
      optionClazz.getMethod("setIsNeedAddress", Boolean::class.java).invoke(locField, false)
      clazz.getMethod("setLocOption", optionClazz).invoke(client, locField)
      val holder = arrayOfNulls<Any>(1)
      val listenerProxy = java.lang.reflect.Proxy.newProxyInstance(
        bdLocClazz.classLoader,
        arrayOf(Class.forName("com.baidu.location.BDAbstractLocationListener"))
      ) { _, method, args ->
        if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
          holder[0] = args[0]
        }
        null
      }
      clazz.getMethod("registerLocationListener", Class.forName("com.baidu.location.BDAbstractLocationListener")).invoke(client, listenerProxy)
      clazz.getMethod("start").invoke(client)
      Thread.sleep(1000) // give it a second to warm up
      clazz.getMethod("requestLocation").invoke(client)
      val start = System.currentTimeMillis()
      while (System.currentTimeMillis() - start < timeoutMs) {
        val cur = holder[0]
        if (cur != null) {
          val acc = bdLocClazz.getMethod("getRadius").invoke(cur) as? Float ?: 9999f
          val lat = bdLocClazz.getMethod("getLatitude").invoke(cur) as? Double
          val lng = bdLocClazz.getMethod("getLongitude").invoke(cur) as? Double
          if (lat != null && lng != null && acc <= targetAccMeters) {
            val l = Location("baidu")
            l.latitude = lat
            l.longitude = lng
            l.accuracy = acc
            try { clazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
            return l
          }
        }
        Thread.sleep(300)
      }
      try { clazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
      return null
    } catch (_: Throwable) {
      return null
    }
  }

  private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371000.0
    val dLat = Math.toRadians(lat2-lat1)
    val dLon = Math.toRadians(lon2-lon1)
    val a = sin(dLat/2)*sin(dLat/2) + cos(Math.toRadians(lat1))*cos(Math.toRadians(lat2))*sin(dLon/2)*sin(dLon/2)
    val c = 2*atan2(sqrt(a), sqrt(1-a))
    return R*c
  }
}
