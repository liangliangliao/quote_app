import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView 容器：统一处理“空白→兜底/动态”的展示与 JS 注入
class HomeHtmlView extends StatefulWidget {
  final String assetPath;                 // 兜底/模板 HTML
  final Map<String, dynamic>? data;       // null 表示兜底（无/异常）

  const HomeHtmlView({super.key, required this.assetPath, required this.data});

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _revealed = false; // 是否已经把内容展示给用户

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) async {
            if (widget.data != null) {
              await _injectDynamic(widget.data!);
            }
            if (!(widget.data != null && widget.data!['__blank__'] == true)) { _revealIfNeeded(); }
          },
        ),
      );
    _loadBlankThenDecide();
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.data != oldWidget.data) {
      // 如果是占位空白，继续保持隐藏
      if (widget.data != null && widget.data!['__blank__'] == true) {
        if (mounted && _revealed) setState(() => _revealed = false);
        return;
      }
      // 兜底（null）或动态数据：显示
      if (widget.data == null) {
        if (!(widget.data != null && widget.data!['__blank__'] == true)) { _revealIfNeeded(); }
      } else {
        _injectDynamic(widget.data!);
        if (!(widget.data != null && widget.data!['__blank__'] == true)) { _revealIfNeeded(); }
      }
    }
  }

  void _revealIfNeeded() {
    if (!_revealed && mounted) setState(() => _revealed = true);
  }

  Future<void> _loadBlankThenDecide() async {
  await _controller.loadHtmlString(
    '<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>'
    '<body style="background:transparent;margin:0;padding:0;"></body></html>',
  );
  await Future.delayed(const Duration(milliseconds: 300));
  try {
    final html = await rootBundle.loadString(widget.assetPath);
    if (widget.data == null) {
      await _controller.loadHtmlString(html);
    } else {
      await _controller.loadHtmlString(html);
    }
  } catch (_) {
    try {
      final html = await rootBundle.loadString(widget.assetPath);
      await _controller.loadHtmlString(html);
    } catch(__) {}
  }
}


  Future<void> _injectDynamic(Map<String, dynamic> data) async {
    final payloadJson = jsonEncode(data);
    final js = '''
      (function(){
        try{
          var payload = $payloadJson;
          if (window.setDynamicData && typeof window.setDynamicData === 'function') {
            window.setDynamicData(payload);
          } else {
            window.PAYLOAD = payload;
            try{ if (window.onPayloadArrived) window.onPayloadArrived(payload); }catch(e){}
          }
          return true;
        }catch(e){ return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(js);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 60));
      try { await _controller.runJavaScriptReturningResult(js); } catch(__) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: _revealed ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 90),
      child: IgnorePointer(
        ignoring: !_revealed,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}