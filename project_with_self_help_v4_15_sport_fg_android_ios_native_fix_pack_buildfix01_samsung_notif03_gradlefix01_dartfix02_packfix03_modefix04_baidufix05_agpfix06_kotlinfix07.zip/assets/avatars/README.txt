Put avatar images here. Filenames should include the author's English name, e.g. Albert_Camus.jpg and William_James.jpg. The app will fuzzy-match by name.
