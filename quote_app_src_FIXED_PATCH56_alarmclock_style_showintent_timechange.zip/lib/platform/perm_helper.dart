import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> requestExactAlarm() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('requestExactAlarm');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> scheduleNativeNotification({
    required int whenMs,
    required String title,
    required String body,
    int nid = 1002,
    bool useAlarmClock = false,
  }) async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('scheduleNativeNotification', {
        'whenMs': whenMs,
        'title': title,
        'body': body,
        'nid': nid,
        'useAlarmClock': useAlarmClock,
      });
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> cancelNativeNotification(int nid) async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('cancelNativeNotification', {
        'nid': nid,
      });
      return ok ?? false;
    } catch (_) {
      return false;
    }
  });
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }
}


  static Future<bool> scheduleBackupWork({
    required int whenMs,
    required String title,
    required String body,
    int nid = 1003,
    String? tag,
  }) async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('scheduleBackupWork', {
        'whenMs': whenMs,
        'title': title,
        'body': body,
        'nid': nid,
        'tag': tag ?? 'notif_${nid}',
      });
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> cancelBackupWorkByTag(String tag) async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _ch.invokeMethod<bool>('cancelBackupWorkByTag', {'tag': tag});
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }
