package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class NativeNotifyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        android.util.Log.d("QuoteReceiver", "onReceive fired nid=" + intent.getIntExtra("nid", -1))
        val sp = context.getSharedPreferences("quote_diag", Context.MODE_PRIVATE)
        sp.edit().putInt("recv_hits", sp.getInt("recv_hits", 0)+1).apply()

        val svc = Intent(context, NativeNotifyService::class.java).apply {
            putExtra("title", intent.getStringExtra("title"))
            putExtra("body", intent.getStringExtra("body"))
            putExtra("nid", intent.getIntExtra("nid", 1002))
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svc)
        } else {
            context.startService(svc)
        }
    }
}
