package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("QuoteBoot", "BootCompletedReceiver onReceive: " + intent.action)
        // reschedule is handled on next app start; keep minimal here
    }
}
