package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class TimeChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("QuoteTimeChange", "Time change: " + intent.action)
        // Keep light: the app will reschedule on next launch or next tick.
        // You can post a lightweight work to rescan DB if needed.
    }
}
