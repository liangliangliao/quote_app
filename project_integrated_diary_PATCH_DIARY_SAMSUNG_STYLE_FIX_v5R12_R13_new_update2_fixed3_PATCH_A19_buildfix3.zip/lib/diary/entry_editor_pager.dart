import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'diary_dao.dart';
import 'entry_editor_page.dart';

class EntryEditorPagerPage extends StatefulWidget {
  final int notebookId;
  final int initialEntryId;
  const EntryEditorPagerPage({super.key, required this.notebookId, required this.initialEntryId});

  @override
  State<EntryEditorPagerPage> createState() => _EntryEditorPagerPageState();
}

class _EntryEditorPagerPageState extends State<EntryEditorPagerPage> {
  static const Color _paperBg = Color(0xFFF3F2EE);

  final _dao = DiaryDao();
  final PageController _controller = PageController(initialPage: 1);
  int _globalIndex = 0;
  int _total = 0;
  final List<DiaryEntry> _pages = []; // loaded entries
  int _index = 1; // current PageView index within (0.._pages.length+1)

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _pages.clear();
    final e = await _dao.getEntry(widget.initialEntryId);
    if (e != null) _pages.add(e);
    _total = await _dao.countEntries(widget.notebookId);
    final pos = await _dao.positionOfEntry(widget.notebookId, widget.initialEntryId) ?? 0;
    if (mounted) setState(() => _globalIndex = pos);
  }

  Future<bool> _ensureOlder() async {
    if (_pages.isEmpty) return false;
    final cur = _pages.last;
    final older = await _dao.neighbor(notebookId: widget.notebookId, cur: cur, newer: false);
    if (older == null) return false;
    if (mounted) setState(() => _pages.add(older));
    return true;
  }

  Future<bool> _ensureNewer() async {
    if (_pages.isEmpty) return false;
    final cur = _pages.first;
    final newer = await _dao.neighbor(notebookId: widget.notebookId, cur: cur, newer: true);
    if (newer == null) return false;
    if (mounted) {
      setState(() {
        _pages.insert(0, newer);
        _index++; // current visual index shifts right by 1
      });
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: _paperBg,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: _paperBg,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: _paperBg,
        body: SafeArea(
          child: Stack(
            children: [
              PageView.builder(
                physics: EdgeLockPagePhysics(
                  lockToStart: _total > 0 && _globalIndex <= 0,
                  lockToEnd: _total > 0 && _globalIndex >= _total - 1,
                  // NOTE: we keep Clamping to avoid Android glow.
                  parent: const ClampingScrollPhysics(),
                ),
                controller: _controller,
                itemCount: _pages.length + 2,
                onPageChanged: (i) async {
                  // Sentinel: swiping to older
                  if (i == _pages.length + 1) {
                    final ok = await _ensureOlder();
                    if (ok == true) {
                      if (!mounted) return;
                      setState(() {
                        _index = _pages.length;
                        _globalIndex = (_globalIndex + 1).clamp(0, _total - 1);
                      });
                      _controller.jumpToPage(_pages.length);
                    } else {
                      if (mounted) _controller.jumpToPage(_pages.length);
                    }
                    return;
                  }
                  // Sentinel: swiping to newer
                  if (i == 0) {
                    final ok = await _ensureNewer();
                    if (ok == true) {
                      if (!mounted) return;
                      setState(() {
                        _index = 1;
                        _globalIndex = (_globalIndex - 1).clamp(0, _total - 1);
                      });
                      _controller.jumpToPage(1);
                    } else {
                      if (mounted) _controller.jumpToPage(1);
                    }
                    return;
                  }

                  final prev = _index;
                  if (mounted) {
                    setState(() {
                      _index = i;
                      _globalIndex = (_globalIndex + (i - prev)).clamp(0, _total - 1);
                    });
                  }
                },
                itemBuilder: (ctx, i) {
                  // Keep sentinels for lazy loading.
                  if (i == 0 || i == _pages.length + 1) {
                    // Important: never return a pure white background here.
                    return const ColoredBox(color: _paperBg);
                  }
                  final e = _pages[i - 1];
                  return EntryEditorPage(
                    key: ValueKey<int>(e.id),
                    notebookId: widget.notebookId,
                    entryId: e.id,
                  );
                },
              ),
              Positioned(
                bottom: 0,
                left: 0,
                child: SafeArea(
                  top: false,
                  minimum: EdgeInsets.zero,
                  child: DecoratedBox(
                    decoration: const BoxDecoration(color: Colors.black54),
                    child: Text(
                      '${_globalIndex + 1}/$_total',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Physics copied from reader to keep UX identical.
///
/// We hard-disable dragging past the first/last entry to avoid revealing
/// any background (white/black) during edge drags.
class EdgeLockPagePhysics extends PageScrollPhysics {
  final bool lockToStart; // 锁定上一页（首条时）
  final bool lockToEnd; // 锁定下一页（末条时）

  const EdgeLockPagePhysics({this.lockToStart = false, this.lockToEnd = false, ScrollPhysics? parent})
      : super(parent: parent);

  @override
  EdgeLockPagePhysics applyTo(ScrollPhysics? ancestor) {
    return EdgeLockPagePhysics(
      lockToStart: lockToStart,
      lockToEnd: lockToEnd,
      parent: buildParent(ancestor),
    );
  }

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) {
    // offset > 0 : dragging right (to previous page)
    // offset < 0 : dragging left (to next page)
    if (lockToStart && offset > 0) return 0;
    if (lockToEnd && offset < 0) return 0;
    return super.applyPhysicsToUserOffset(position, offset);
  }
}
