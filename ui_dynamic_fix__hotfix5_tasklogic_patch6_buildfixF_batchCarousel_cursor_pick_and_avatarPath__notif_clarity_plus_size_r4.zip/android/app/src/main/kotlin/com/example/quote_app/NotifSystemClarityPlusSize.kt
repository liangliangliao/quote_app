package com.example.quote_app

import android.content.Context
import android.os.Build
import android.text.Layout
import android.util.TypedValue
import android.widget.RemoteViews
import android.widget.TextView
import androidx.core.widget.TextViewCompat

/**
 * 纯 TextView 方案：系统清晰度；在系统正文字号基础上“可调节地略放大 Δsp”。
 * - 同一 TextView：折叠 maxLines=5，展开 maxLines=12；
 * - 通过读取系统正文 textAppearance 的 textSize（sp）后 + deltaSp，再用 RemoteViews.setTextViewTextSize 应用。
 */
object NotifSystemClarityPlusSize {

    private fun resolveSystemBodySp(ctx: Context): Float {
        val tv = TextView(ctx)
        val candidates = intArrayOf(
            com.google.android.material.R.attr.textAppearanceBodyMedium,
            com.google.android.material.R.attr.textAppearanceBodyLarge,
            android.R.attr.textAppearance
        )
        val tvv = TypedValue()
        for (attr in candidates) {
            if (ctx.theme.resolveAttribute(attr, tvv, true) && tvv.resourceId != 0) {
                TextViewCompat.setTextAppearance(tv, tvv.resourceId)
                break
            }
        }
        val scaledDensity = ctx.resources.displayMetrics.scaledDensity
        return tv.textSize / scaledDensity   // px -> sp
    }

    private fun common(ctx: Context, body: CharSequence, maxLines: Int, deltaSp: Float): RemoteViews {
        val baseSp = resolveSystemBodySp(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.notif_body_system_clarity_plus_size).apply {
            setTextViewText(R.id.body_text, body)
            setInt(R.id.body_text, "setMaxLines", maxLines)
            // setTextViewTextSize 接受 sp 单位，兼容性良好（API16+）
            setTextViewTextSize(R.id.body_text, TypedValue.COMPLEX_UNIT_SP, baseSp + deltaSp)
            if (Build.VERSION.SDK_INT >= 23) {
                setInt(R.id.body_text, "setBreakStrategy", Layout.BREAK_STRATEGY_HIGH_QUALITY)
                setInt(R.id.body_text, "setHyphenationFrequency", Layout.HYPHENATION_FREQUENCY_NORMAL)
            }
        }
        return rv
    }

    fun collapsed(ctx: Context, body: CharSequence, deltaSp: Float = 1f) =
        common(ctx, body, maxLines = 5, deltaSp = deltaSp)

    fun expanded(ctx: Context, body: CharSequence, deltaSp: Float = 1f) =
        common(ctx, body, maxLines = 12, deltaSp = deltaSp)
}
