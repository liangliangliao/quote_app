
import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:quote_app/widgets/home_html_view.dart';
import '../data/dao.dart';
import '../utils/debug_logger.dart';
import 'package:quote_app/services/native_guard.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  Map<String, dynamic>? _todayData;
  Map<String, dynamic>? _latestRow;
  bool _firstLoaded = false;
  bool _loading = true;
  /// Token to track the most recent load request.  Each call to `_load()`
  /// increments this counter.  When asynchronous operations complete, the
  /// current token is checked against this field; if it has changed, the
  /// result is considered stale and ignored.  This prevents older async
  /// queries from overriding newer data and causing a visible flash of
  /// fallback content.  See `_load()` for usage.
  int _loadCounter = 0;
  bool _fav = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SimpleBus.homeTick.addListener(_onBus);
    _load();
  }

  void _onBus() { _load(); }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SimpleBus.homeTick.removeListener(_onBus);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _load();
    }
  }

  Future<String> _avatarToDataUrl(String raw) async {
    final s = (raw).toString().trim();
    if (s.isEmpty) return '';
    if (s.startsWith('data:') || s.startsWith('http://') || s.startsWith('https://')) return s;
    try {
      final f = File(s);
      if (await f.exists()) {
        final bytes = await f.readAsBytes();
        String mime = 'image/png';
        final lower = s.toLowerCase();
        if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) mime = 'image/jpeg';
        else if (lower.endsWith('.webp')) mime = 'image/webp';
        else if (lower.endsWith('.gif')) mime = 'image/gif';
        final b64 = base64Encode(bytes);
        return 'data:$mime;base64,$b64';
      }
    } catch (_) {}
    return '';
  }

  Future<void> _load() async {
    // Increment the load counter to identify this invocation.  Any
    // asynchronous results from previous invocations will be discarded
    // if their captured token no longer matches `_loadCounter`.
    final int loadId = ++_loadCounter;
    // Indicate we are loading: show blank placeholder until data arrives.
    setState(() {
      _firstLoaded = true;
      _loading = true;
      // Do not reset `_todayData` here.  If a previous load produced
      // content, we keep it until the new data arrives, so we avoid
      // flashing the fallback HTML unnecessarily.
    });
    try {
      final dao = QuoteDao();
      final latest = await dao.latestNotifiedToday();
      // If the widget has been disposed or another load has started,
      // abandon this result to avoid stale data overriding new state.
      if (!mounted || loadId != _loadCounter) return;
      _latestRow = latest;
      if (latest == null) {
        await DLog.i('HOME', '今日未检索到已通知记录：显示兜底 HTML');
        setState(() {
          // Mark loading complete and show fallback.  `_todayData` is
          // explicitly set to null to signal the fallback HTML should be
          // displayed.  `_loading` is false so the WebView will reveal
          // the content instead of staying hidden.
          _todayData = null;
          _loading = false;
        });
      } else {
        final avatarUrl = await _avatarToDataUrl((latest['avatar'] ?? '').toString());
        final payload = <String, dynamic>{
          'topic': (latest['theme'] ?? latest['topic'] ?? '').toString(),
          'quote': (latest['content'] ?? latest['quote'] ?? '').toString(),
          'author': (latest['author_name'] ?? latest['author'] ?? '').toString(),
          'source': (latest['source_from'] ?? latest['source'] ?? '').toString(),
          'note': (latest['explanation'] ?? latest['note'] ?? '').toString(),
          'avatarUrl': avatarUrl,
          'authorText': '——${(latest['author_name'] ?? latest['author'] ?? '').toString().trim()} ${(latest['source_from'] ?? latest['source'] ?? '').toString().trim()}',
        };
        await DLog.i('HOME', '已检索到今日最新已通知记录：准备注入');
        // If another load was triggered while awaiting avatar/data,
        // abandon this result.
        if (!mounted || loadId != _loadCounter) return;
        setState(() {
          // Assign the payload and mark loading complete.  The UI
          // will reveal the WebView and inject this dynamic data.
          _todayData = payload;
          _loading = false;
        });
      }
    } catch (e) {
      await DLog.e('HOME', '查询异常：将显示兜底；err=$e');
      // If the widget is still mounted and this result is current,
      // display fallback content.  Otherwise ignore.
      if (mounted && loadId == _loadCounter) {
        setState(() {
          _todayData = null;
          _loading = false;
        });
      }
    }
  }

  Future<void> _copyLatest() async {
    final text = (_latestRow?['content'] ?? '').toString();
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final assetPath = 'assets/html/poster-wall-only-frame-v23-1.html';
    final content = (_loading) ? const {'__blank__': true} : _todayData;
    final topPad = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // 内容区
          Positioned.fill(
            child: Padding(
              padding: EdgeInsets.only(top: topPad + kToolbarHeight),
              child: Center(child: HomeHtmlView(key: ValueKey(_loading ? 'blank' : 'ready'), assetPath: assetPath, data: content)),
            ),
          ),
          // 顶栏区域（悬浮白底按钮）
          Positioned(
            top: topPad,
            left: 0,
            right: 0,
            height: kToolbarHeight,
            child: IgnorePointer(
              ignoring: false,
              child: Row(
                children: [
                  const SizedBox(width: 8),
                  const Expanded(child: SizedBox()),
                  // share
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '分享',
                        icon: const Icon(Icons.share, color: Colors.black87),
                        onPressed: () async {
                          // 简化版分享：复制到剪贴板并提示
                          await _copyLatest();
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // copy
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '复制',
                        icon: const Icon(Icons.copy, color: Colors.black87),
                        onPressed: _copyLatest,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // favorite
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: _fav ? '取消收藏' : '收藏',
                        icon: Icon(_fav ? Icons.favorite : Icons.favorite_border, color: Colors.black87),
                        onPressed: () => setState(() => _fav = !_fav),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}