package com.example.quote_app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ReminderForegroundService : Service() {

    override fun onCreate() {
        super.onCreate()
        ensureServiceChannel()
        val notif = NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setContentTitle("提醒服务已运行")
            .setContentText("确保后台、锁屏、重启等场景稳定发送通知")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        startForeground(SERVICE_NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Keep running; scheduling is handled by Dart or Alarm Receivers.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // If user removes the app from recents, keep service sticky
        startForeground(SERVICE_NOTIF_ID, NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setContentTitle("提醒服务持续运行")
            .setContentText("防止被系统回收导致提醒丢失")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .build())
        super.onTaskRemoved(rootIntent)
    }

    private fun ensureServiceChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(SERVICE_CHANNEL_ID, "提醒前台服务", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }

    companion object {
        const val SERVICE_CHANNEL_ID = "reminder_foreground_channel"
        const val SERVICE_NOTIF_ID = 424242
    }
}
