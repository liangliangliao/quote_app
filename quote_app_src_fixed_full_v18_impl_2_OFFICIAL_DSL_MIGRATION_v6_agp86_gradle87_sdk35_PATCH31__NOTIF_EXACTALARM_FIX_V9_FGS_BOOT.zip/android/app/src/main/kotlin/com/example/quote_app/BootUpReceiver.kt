package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootUpReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == android.content.Intent.ACTION_BOOT_COMPLETED ||
            action == android.content.Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == android.content.Intent.ACTION_MY_PACKAGE_REPLACED) {
            try {
                val svc = Intent(context, ReminderForegroundService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(svc)
                } else {
                    context.startService(svc)
                }
            } catch (_: Exception) {}
        }
    }
}
