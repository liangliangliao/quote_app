package com.example.quote_app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {

    companion object {
        private const val REQ_POST_NOTIFICATIONS = 1001
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.quote_app/sys")
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "hasExactAlarmPermission" -> {
                    val can = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        am.canScheduleExactAlarms()
                    } else { true }
                    result.success(can)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ensure default notification channel exists
        NotificationUtils.ensureDefaultChannel(this)

        // Android 13+ notification runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationUtils.areNotificationsEnabled(this)) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQ_POST_NOTIFICATIONS
                )
            }
        }

        // NOTE: Per product decision, DO NOT auto-navigate to exact-alarm settings.
        // Users can open system Settings manually to enable Alarms & reminders for this app.

        
        // Start the foreground service to improve background delivery reliability
        try {
            val svc = Intent(this, ReminderForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
        } catch (_: Exception) {}
    
        // One-off diagnostic exact alarm in ~60s (only if permission already granted)
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val can = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
            if (can) {
                val prefs = getSharedPreferences("diag_prefs", Context.MODE_PRIVATE)
                if (!prefs.getBoolean("diag_alarm_scheduled", false)) {
                    val t = System.currentTimeMillis() + 60_000L
                    ExactAlarmTestReceiver.scheduleOnce(this, t)
                    prefs.edit().putBoolean("diag_alarm_scheduled", true).apply()
                }
            }
        } catch (_: Exception) {}
    }
}
