import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../data/db.dart';

class DiarySettingsPage extends StatefulWidget {
  const DiarySettingsPage({super.key});

  @override
  State<DiarySettingsPage> createState() => _DiarySettingsPageState();
}

class _DiarySettingsPageState extends State<DiarySettingsPage> {
  String? _bgPath;
  double _opacity = 0.25;
  final _pinCtrl = TextEditingController();
  bool _loaded = false;

  Future<String?> _persistBgImage(String srcPath) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final dstDir = Directory(p.join(dir.path, 'diary_bg'));
      if (!await dstDir.exists()) { await dstDir.create(recursive: true); }
      final ext = p.extension(srcPath);
      final dstPath = p.join(dstDir.path, 'bg_' + DateTime.now().millisecondsSinceEpoch.toString() + (ext.isEmpty ? '.jpg' : ext));
      await File(srcPath).copy(dstPath);
      return dstPath;
    } catch (_) {
      return srcPath; // fallback
    }
  }


  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        _bgPath = (rows.first['diary_bg_image'] ?? '') as String?;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _opacity = double.tryParse(op.toString()) ?? _opacity;
        _pinCtrl.text = (rows.first['diary_pin'] ?? '').toString();
      }
    } catch (_) {}
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _save() async {
    final db = await AppDatabase.instance();

    // Prefer updating the latest row that already contains diary settings.
    final picked = await db.rawQuery(
      "SELECT id FROM configs "
      "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
      "   OR diary_bg_opacity IS NOT NULL "
      "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
      "ORDER BY id DESC LIMIT 1",
    );
    final latest = await db.query('configs', columns: ['id'], orderBy: 'id DESC', limit: 1);
    final rows = picked.isNotEmpty ? picked : latest;

    final data = <String, Object?>{
      'diary_bg_image': (_bgPath ?? ''),
      'diary_bg_opacity': _opacity,
      'diary_pin': _pinCtrl.text.trim(),
    };

    if (rows.isEmpty) {
      // No configs row exists yet.
      await db.insert('configs', data);
    } else {
      final id = rows.first['id'];
      await db.update('configs', data, where: 'id=?', whereArgs: [id]);
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

  Future<void> _pickBg() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;
    final saved = await _persistBgImage(path);
    setState(() => _bgPath = saved);
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final exists = _bgPath != null && _bgPath!.isNotEmpty && File(_bgPath!).existsSync();
    return Scaffold(
      appBar: AppBar(title: const Text('日记设置')),
      body: ListView(
        children: [
          const ListTile(title: Text('背景设置')),
          ListTile(
            title: const Text('选择背景图'),
            subtitle: Text(exists ? _bgPath! : '未设置'),
            onTap: _pickBg,
          ),
          if (exists) ListTile(title: const Text('清除背景图'), onTap: () => setState(()=>_bgPath=null)),
          ListTile(title: const Text('背景透明度'), subtitle: Text('${(_opacity*100).round()}%')),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Slider(value: _opacity, onChanged: (v)=>setState(()=>_opacity=v))),
          const Divider(),
          const ListTile(title: Text('PIN 锁（进入日记模块时验证）')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(controller: _pinCtrl, decoration: const InputDecoration(labelText: '4位数字（留空表示不开启）', border: OutlineInputBorder()), maxLength: 4, keyboardType: TextInputType.number),
          ),
          const SizedBox(height: 12),
          Center(child: FilledButton(onPressed: _save, child: const Text('保存设置'))),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}