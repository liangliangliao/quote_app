
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView：首屏先隐藏（由 HTML gate 实现），宿主在“查表结果已定”后才显形。
/// - 结果=1：先 setDynamicData(payload)，再 reveal()
/// - 结果=0/异常：直接 reveal()，展示兜底
/// - 永不依赖 onPageFinished 作为显形信号
class HomeHtmlView extends StatefulWidget {
  final String assetPath;                 // 本地 HTML 模板（含兜底）
  final Map<String, dynamic>? dataOrNull; // null 表示走兜底（返回0或异常）

  const HomeHtmlView({
    super.key,
    required this.assetPath,
    required this.dataOrNull,
  });

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _revealed = false;
  Timer? _safetyTimer;
  bool _pageReady = false;

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('Host', onMessageReceived: (msg) {
        if (msg.message == 'revealed' && mounted && !_revealed) {
          setState(() => _revealed = true);
        }
      })
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) async {
          _pageReady = true;
          // 不在这里显形；等待 _injectThenReveal()
          await _injectThenReveal();
        },
      ));

    _loadHtml();
  }

  Future<void> _loadHtml() async {
    final html = await rootBundle.loadString(widget.assetPath);
    await _controller.loadHtmlString(html);
  }

  /// 统一数据注入与显形路径（被：onPageFinished / didUpdateWidget 调用）
  Future<void> _injectThenReveal() async {
    if (!_pageReady) return;

    _safetyTimer?.cancel();
    // 安全兜底：2s 后强制把外层 AnimatedOpacity 拉起来，避免永久透明
    _safetyTimer = Timer(const Duration(seconds: 2), () {
      if (mounted && !_revealed) setState(() => _revealed = true);
    });

    try {
      if (widget.dataOrNull != null) {
        final jsonPayload = jsonEncode(widget.dataOrNull);
        await _controller.runJavaScript('try{ setDynamicData($jsonPayload); }catch(e){}');
      }
    } catch (_) {
      // 忽略：注入失败视作走兜底
    } finally {
      try {
        await _controller.runJavaScript('try{ reveal(); }catch(e){}');
      } catch (_) {
        // 若 JS 执行失败，2s 安全兜底会把 _revealed 置为 true
      }
    }
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 每次进入首页/数据结果改变时，都重新注入 → 显形
    if (!identical(oldWidget.dataOrNull, widget.dataOrNull)) {
      _revealed = false;
      _injectThenReveal();
    }
  }

  @override
  void dispose() {
    _safetyTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: _revealed ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 120),
      child: IgnorePointer(
        ignoring: !_revealed,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}
