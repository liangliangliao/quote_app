package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbInspector
import android.database.sqlite.SQLiteDatabase

/**
 * BootReceiver listens for device boot completed or app package replacement
 * events and reinitializes all scheduled tasks.  It enqueues a one‑off
 * workmanager job with job name `wm_boot` which is handled in the Dart
 * dispatcher to restore all alarms and scheduled WorkManager tasks.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Build data payload
        val data = Data.Builder()
            .putString("job", "wm_boot")
            .build()
        val request = OneTimeWorkRequestBuilder<AlarmProxyWorker>()
            .setInputData(data)
            .build()
        WorkManager.getInstance(context).enqueue(request)

        // Schedule periodic geo location checks on boot to handle geo triggers
        try {
            if (isGeoRulesEnabled(context)) GeoWorker.schedule(context) else GeoWorker.cancel(context)
        } catch (_: Throwable) { /* ignore scheduling errors */ }

        // 改为后台：触发 UnlockWorker 做一次自检/刷新
        try { UnlockWorker.trigger(context) } catch (_: Throwable) { /* ignore */ }

        // Sport: ensure midnight renewal alarm exists after reboot and best-effort reschedule all sport plan alarms.
        try { com.example.quote_app.sport.SportPlanRenewal.scheduleMidnightAlarm(context) } catch (_: Throwable) {}
        try { com.example.quote_app.sport.SportPlanRenewal.rescheduleAllPlanAlarms(context) } catch (_: Throwable) {}
    }
}

private fun isGeoRulesEnabled(ctx: Context): Boolean {
  return try {
    val cc = DbInspector.loadOrLightScan(ctx) ?: return false
    val db = SQLiteDatabase.openDatabase(
      cc.dbPath,
      null,
      SQLiteDatabase.OPEN_READONLY
    )
    try {
      var enabled = false
      try {
        db.rawQuery(
          "SELECT location_rules_enabled FROM configs ORDER BY id DESC LIMIT 1",
          null
        ).use { c ->
          if (c.moveToFirst()) {
            enabled = (c.getInt(0) == 1)
          }
        }
      } catch (_: Throwable) {
      }
      enabled
    } finally {
      try {
        db.close()
      } catch (_: Throwable) {
      }
    }
  } catch (_: Throwable) {
    false
  }
}
