package com.example.quote_app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * UnlockWorker 在后台线程中完整处理一次“解锁触发轻提醒”的业务逻辑：
 *
 * 1. 记录本次来自解锁事件的处理开始。
 * 2. 调度一次 GeoWorker，用于在解锁后更新地理位置并触发情景提醒。
 * 3. 打开数据库，检查是否存在启用的 screen_unlock 触发器，以及解锁提醒总开关。
 * 4. 读取冷却时间（unlock_cooldown_days / unlock_cooldown_minutes），并结合
 *    SharedPreferences 中的 last_unlock_reminder_time 做限流。
 * 5. 满足条件时，记录本次解锁时间戳 last_unlock_time，并调用 NotifyHelper
 *    通过专用渠道发送“愿景提醒”通知。
 *
 * 该 Worker 由 UnlockReceiver 在收到解锁/亮屏广播时调度，保证即使应用不在前台
 * 也可以依赖 WorkManager 在合适的时机完成解锁提醒的业务逻辑。
 */
class UnlockWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        val context = applicationContext

        return try {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockWorker.doWork：开始处理一次解锁事件（由 BroadcastReceiver 调度）"
                )
            } catch (_: Throwable) {}

            // 1）无论是否最终会发送解锁提醒，都先调度一次 GeoWorker，保持与历史行为一致
            try {
                val request = OneTimeWorkRequestBuilder<GeoWorker>().build()
                WorkManager.getInstance(context).enqueue(request)
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：已为本次解锁调度一次 GeoWorker，用于解锁后更新地理位置并触发情景提醒"
                    )
                } catch (_: Throwable) {}
            } catch (_: Throwable) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：调度 GeoWorker 失败（本次仅影响地理位置相关提醒，不影响解锁基本提醒），异常已忽略"
                    )
                } catch (_: Throwable) {}
            }

            // 2）尝试通过 DbInspector 获取数据库路径
            val contract = try {
                DbInspector.loadOrLightScan(context)
            } catch (_: Throwable) {
                null
            }

            if (contract == null || contract.dbPath == null) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：DbInspector 加载失败或 dbPath 为空，无法读取配置，本次解锁提醒将被跳过"
                    )
                } catch (_: Throwable) {}
                return Result.success()
            }

            val dbPath = contract.dbPath!!

            // 3）打开数据库并检查 screen_unlock 触发器及解锁开关
            val db: SQLiteDatabase = try {
                SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
            } catch (e: Throwable) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：打开数据库失败，异常类型=" +
                            e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                    )
                } catch (_: Throwable) {}
                return Result.success()
            }

            var hasTrigger = false
            var configEnabled = false

            try {
                val cursor = db.rawQuery(
                    "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                    null
                )
                hasTrigger = cursor.moveToFirst()
                cursor.close()

                // 读取 notify_config.unlock_switch_enabled 开关
                try {
                    val c = db.rawQuery(
                        "SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1",
                        null
                    )
                    if (c.moveToFirst()) {
                        val v = c.getString(0)
                        if (v != null) {
                            val s = v.trim().lowercase()
                            configEnabled = (s == "1" || s == "true")
                        }
                    }
                    c.close()
                } catch (_: Throwable) {}

                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：数据库检查完成，hasTrigger=" + hasTrigger +
                            "，configEnabled=" + configEnabled +
                            "（是否存在解锁触发器 / 解锁提醒开关是否开启）"
                    )
                } catch (_: Throwable) {}
            } catch (_: Throwable) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：查询解锁触发器 / 配置时发生异常，本次解锁提醒将被跳过"
                    )
                } catch (_: Throwable) {}
                try {
                    db.close()
                } catch (_: Throwable) {}
                return Result.success()
            }

            if (!configEnabled) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：解锁轻提醒开关已关闭，本次解锁不发送任何通知"
                    )
                } catch (_: Throwable) {}
                try {
                    db.close()
                } catch (_: Throwable) {}
                return Result.success()
            }

            // 4）计算冷却时间（默认 30 分钟，可被 unlock_cooldown_days / unlock_cooldown_minutes 覆盖）
            var cooldownMs = 30L * 60L * 1000L
            try {
                // 优先读取按天配置
                try {
                    val cDay = db.rawQuery(
                        "SELECT value FROM notify_config WHERE key='unlock_cooldown_days' LIMIT 1",
                        null
                    )
                    if (cDay.moveToFirst()) {
                        val v = cDay.getString(0)
                        try {
                            val d = v?.toDouble()
                            if (d != null && d > 0.0) {
                                cooldownMs = (d * 24.0 * 60.0 * 60.0 * 1000.0).toLong()
                            }
                        } catch (_: Throwable) {}
                    }
                    cDay.close()
                } catch (_: Throwable) {}
                // 如果天数配置未覆盖，则尝试读取按分钟配置
                if (cooldownMs == 30L * 60L * 1000L) {
                    try {
                        val cMin = db.rawQuery(
                            "SELECT value FROM notify_config WHERE key='unlock_cooldown_minutes' LIMIT 1",
                            null
                        )
                        if (cMin.moveToFirst()) {
                            val v2 = cMin.getString(0)
                            try {
                                val m = v2?.toInt()
                                if (m != null && m > 0) {
                                    cooldownMs = m.toLong() * 60L * 1000L
                                }
                            } catch (_: Throwable) {}
                        }
                        cMin.close()
                    } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {
            } finally {
                try {
                    db.close()
                } catch (_: Throwable) {}
            }

            // 5）根据冷却时间结合 SharedPreferences 判断本次是否需要发送解锁提醒
            var inCooldown = false
            try {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                val now = System.currentTimeMillis()
                val last = prefs.getLong("last_unlock_reminder_time", 0L)
                if (last > 0L && (now - last) < cooldownMs) {
                    inCooldown = true
                }
            } catch (_: Throwable) {}

            if (inCooldown) {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：仍处于解锁提醒冷却期，跳过本次解锁通知，cooldownMs=" + cooldownMs
                    )
                } catch (_: Throwable) {}
                return Result.success()
            }

            if (hasTrigger || configEnabled) {
                // 记录本次解锁事件时间戳，供 App 启动兜底逻辑参考
                try {
                    val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                    val ts = System.currentTimeMillis()
                    prefs.edit().putLong("last_unlock_time", ts).apply()
                    try {
                        DbRepo.log(
                            context,
                            null,
                            "【解锁提醒】UnlockWorker：记录本次解锁事件时间戳 last_unlock_time=" + ts
                        )
                    } catch (_: Throwable) {}
                } catch (_: Throwable) {}

                sendReminder(context)
            } else {
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockWorker：当前不存在启用的解锁触发器，且配置开关未强制开启，本次不发送解锁提醒"
                    )
                } catch (_: Throwable) {}
            }

            Result.success()
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockWorker：doWork 顶层捕获异常，类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {}
            Result.success()
        }
    }

    /**
     * 发送解锁轻提醒通知，同时更新 last_unlock_reminder_time。
     */
    private fun sendReminder(context: Context) {
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_unlock_reminder_time", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {}

        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"

        val ts = System.currentTimeMillis()
        try {
            DbRepo.log(
                context,
                null,
                "【解锁提醒】UnlockWorker：即将通过专用解锁提醒渠道发送通知，将立即调用 NotifyHelper.sendUnlockReminder，ts=" +
                    ts + "，通知ID=" + id
            )
        } catch (_: Throwable) {}

        try {
            DbRepo.log(
                context,
                null,
                "【解锁提醒】UnlockWorker：调用 NotifyHelper.sendUnlockReminder 发送通知"
            )
            NotifyHelper.sendUnlockReminder(context, id, title, body)
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockWorker：调用 NotifyHelper.sendUnlockReminder 发生异常，类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {}
        }
    }
}
