package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbRepo

/**
 * BootReceiver 负责在以下事件发生时重新初始化定时任务与地理位置轮询：
 *
 * - 设备开机完成（BOOT_COMPLETED）
 * - 应用被更新 / 替换（MY_PACKAGE_REPLACED）
 *
 * 行为包括：
 * 1. 投递一次 WorkManager 任务 AlarmProxyWorker，携带参数 job=wm_boot，
 *    由 Dart 侧恢复所有闹钟与已注册的 WorkManager 任务；
 * 2. 调用 GeoWorker.schedule(context)，恢复地理情景提醒的周期任务。
 *
 * 注意：解锁轻提醒链路现已完全依赖 Manifest 静态 UnlockReceiver + UnlockWorker，
 * 此处不再拉起任何前台守护服务。
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val appCtx = context.applicationContext
        val action = intent?.action ?: "null"

        try {
            DbRepo.log(
                appCtx,
                null,
                "【启动广播】BootReceiver.onReceive：收到系统广播 action=" + action +
                    "，开始恢复闹钟与地理情景任务"
            )
        } catch (_: Throwable) {}

        // 1）通知 Dart 侧恢复闹钟和 WorkManager 任务
        try {
            val data: Data = Data.Builder()
                .putString("job", "wm_boot")
                .build()
            val request = OneTimeWorkRequestBuilder<AlarmProxyWorker>()
                .setInputData(data)
                .build()
            WorkManager.getInstance(appCtx).enqueue(request)

            try {
                DbRepo.log(
                    appCtx,
                    null,
                    "【启动广播】BootReceiver：已向 WorkManager 提交 AlarmProxyWorker(job=wm_boot) 任务"
                )
            } catch (_: Throwable) {}
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    appCtx,
                    null,
                    "【启动广播】BootReceiver：提交 AlarmProxyWorker 失败，异常类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {}
        }

        // 2）恢复地理情景提醒的周期任务
        try {
            GeoWorker.schedule(appCtx)
            try {
                DbRepo.log(
                    appCtx,
                    null,
                    "【启动广播】BootReceiver：已调用 GeoWorker.schedule 恢复地理情景提醒周期任务"
                )
            } catch (_: Throwable) {}
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    appCtx,
                    null,
                    "【启动广播】BootReceiver：GeoWorker.schedule 调用失败，异常类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {}
        }
    }
}
