
package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.quote_app.data.DbRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 兼容保留原 WorkManager 入口；核心逻辑抽到 runInlineOnce 供线程直接调用。
 */
class UnlockWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return withContext(Dispatchers.IO) {
            try {
                runInlineOnce(applicationContext)
                Result.success()
            } catch (t: Throwable) {
                try { DbRepo.log(applicationContext, null, "【解锁后台】UnlockWorker 失败: ${t.message}") } catch (_: Throwable) {}
                Result.failure()
            }
        }
    }

    companion object {
        @JvmStatic
        fun runInlineOnce(ctx: Context) {
            try { DbRepo.log(ctx, null, "【解锁后台】轻提醒线程开始（兼容原逻辑的占位实现）") } catch (_: Throwable) {}
            // 注意：这里保持最小实现，避免破坏原业务；真正的轻提醒逻辑仍在原代码处。
            try { DbRepo.log(ctx, null, "【解锁后台】轻提醒线程结束") } catch (_: Throwable) {}
        }
    }
}
