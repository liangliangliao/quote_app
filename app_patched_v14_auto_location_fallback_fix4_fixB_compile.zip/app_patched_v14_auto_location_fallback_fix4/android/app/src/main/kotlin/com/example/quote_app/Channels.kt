
package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import android.widget.Toast
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * 统一注册 MethodChannel；为了兼容旧代码，保留 native.scheduler，
 * 同时在 com.example.quote_app/sys 提供 getBaiduLocationOnce 与 showToast。
 */
object Channels {
    private const val CH_NATIVE = "native.scheduler"
    private const val CH_SYS = "com.example.quote_app/sys"

    private var nativeChannel: MethodChannel? = null
    private var sysChannel: MethodChannel? = null

    fun ensure(engine: FlutterEngine, appCtx: Context) {
        if (nativeChannel == null) {
            nativeChannel = MethodChannel(engine.dartExecutor.binaryMessenger, CH_NATIVE)
            nativeChannel!!.setMethodCallHandler { call, result ->
                // 旧通道仅保底，不新增实现，防止破坏历史行为
                result.notImplemented()
            }
        }
        if (sysChannel == null) {
            sysChannel = MethodChannel(engine.dartExecutor.binaryMessenger, CH_SYS)
            sysChannel!!.setMethodCallHandler { call, result ->
                when (call.method) {
                    "showToast" -> {
                        val msg = (call.argument<String>("message") ?: "")
                        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
                        result.success(true)
                    }
                    "getBaiduLocationOnce" -> {
                        // 这里不强依赖 Baidu SDK：若 SDK 不存在，直接走系统定位，
                        // 让 Dart 侧把它当作“百度失败→系统定位”的正常回退。
                        try {
                            val lm = appCtx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                            val provider = when {
                                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                                else -> null
                            }
                            val loc: Location? = if (provider != null) {
                                lm.getLastKnownLocation(provider)
                            } else null
                            if (loc != null) {
                                val m = mapOf("lat" to loc.latitude, "lon" to loc.longitude, "acc" to (loc.accuracy.toDouble()))
                                result.success(m)
                            } else {
                                result.error("UNAVAILABLE", "no location", null)
                            }
                        } catch (t: Throwable) {
                            result.error("ERR", t.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
        }
    }
}
