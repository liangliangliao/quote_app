
package com.example.quote_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread

/**
 * 最小可编译的前台服务实现：启动→记日志→立即结束。
 * 真正的定位与比对逻辑仍由现有 Dart/Kotlin 其它模块承担；这里保证编译通过且不破坏已有入口。
 */
class GeoForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try { startAsForeground() } catch (_: Throwable) {}

        thread(name = "geo-fg-run") {
            try {
                DbRepo.log(this, null, "【前台服务-地点规则】前台服务已启动")
            } catch (_: Throwable) {}
            // 这里不做复杂逻辑，防止与现有实现冲突
            try {
                DbRepo.log(this, null, "【前台服务-地点规则】前台服务准备结束")
            } catch (_: Throwable) {}

            try {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } catch (_: Throwable) {}
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = "geo_rule_fg"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(chId, "地点规则提醒", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val notif: Notification = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("正在检查地点规则…")
            .setOngoing(true)
            .build()
        startForeground(1012, notif)
    }
}
