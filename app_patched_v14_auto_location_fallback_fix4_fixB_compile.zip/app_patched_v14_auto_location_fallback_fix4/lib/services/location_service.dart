
import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简单的 POI 数据模型（保持与现有页面兼容）
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;

  PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });

  factory PoiItem.fromBaidu(Map<String, dynamic> m) {
    final loc = (m['location'] ?? {}) as Map;
    return PoiItem(
      name: (m['name'] ?? '') as String,
      address: m['address'] as String?,
      latitude: (loc['lat'] ?? 0.0).toDouble(),
      longitude: (loc['lng'] ?? 0.0).toDouble(),
      distance: (m['distance'] is num) ? (m['distance'] as num).toInt() : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'name': name,
    'address': address,
    'latitude': latitude,
    'longitude': longitude,
    'distance': distance,
  };
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 在弹窗里使用：默认百度SDK一次定位（要求 ≤30m），失败则回退系统高精度定位（同样 ≤30m）。
  /// 这里返回 geolocator 的 Position 以兼容页面代码。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    try { await DLog.i('LocationService', '【定位】优先使用百度SDK定位（≤30m），失败回退系统定位'); } catch (_) {}
    // 1) 尝试百度 SDK（通过原生通道）
    try {
      final Map<dynamic, dynamic>? m = await _sysCh.invokeMethod('getBaiduLocationOnce');
      if (m != null && m['lat'] != null && m['lon'] != null && m['acc'] != null) {
        final double lat = (m['lat'] as num).toDouble();
        final double lon = (m['lon'] as num).toDouble();
        final double acc = (m['acc'] as num).toDouble();
        try { await DLog.i('LocationService', '【定位】Baidu SDK 返回 lat=$lat lon=$lon acc=${acc}m'); } catch (_) {}
        if (acc <= 30.0) {
          return _buildPosition(lat, lon, acc);
        } else {
          try { await DLog.w('LocationService', '【定位】Baidu 精度 ${acc}m > 30m，回退系统定位'); } catch (_) {}
        }
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：${e.toString()}，回退系统定位'); } catch (_) {}
    }

    // 2) 系统定位（高精度，优先使用位置流直到 ≤30m）
    final Position? sys = await _systemLocationOnce();
    if (sys != null) {
      unawaited(_logNearbyLandmarkIfPossible(sys));
      return sys;
    }

    try { await DLog.e('LocationService', '【定位】百度与系统定位均失败'); } catch (_) {}
    return null;
  }

  static Position _buildPosition(double lat, double lon, double acc) {
    // geolocator 14.x Position 构造器需要以下字段
    return Position(
      latitude: lat,
      longitude: lon,
      timestamp: DateTime.now(),
      accuracy: acc,
      altitude: 0.0,
      altitudeAccuracy: 0.0,
      heading: 0.0,
      headingAccuracy: 0.0,
      speed: 0.0,
      speedAccuracy: 0.0,
      floor: null,
      isMocked: false,
    );
  }

  /// 系统定位：优先监听高精度流直到 ≤30m；如果流不可用则回退到单次定位。
  static Future<Position?> _systemLocationOnce() async {
    try { await DLog.i('LocationService', '【定位】系统定位（高精度流，目标≤30m）'); } catch (_) {}
    try {
      final locationSettings = const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 0,
      );

      // 尝试从流中取到精度 ≤30m 的一次位置
      final stream = Geolocator.getPositionStream(locationSettings: locationSettings);
      // 为避免无休止等待，这里不自定义超时，而是额外并行去取一次 getCurrentPosition，
      // 谁先返回就先用，更贴近“根据服务响应决定转圈”的要求。
      Position? chosen;
      final c1 = stream.firstWhere((p) => (p.accuracy <= 30.0)).then((p) => p).catchError((_) => null);
      final c2 = Geolocator.getCurrentPosition(locationSettings: locationSettings).then((p) => p).catchError((_) => null);
      chosen = await Future.any<Position?>([c1, c2]);
      if (chosen != null) {
        try { await DLog.i('LocationService', '【定位】系统返回 lat=${chosen.latitude} lon=${chosen.longitude} acc=${chosen.accuracy}m'); } catch (_) {}
        return chosen;
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】系统定位异常：${e.toString()}'); } catch (_) {}
    }
    return null;
  }

  /// 逆地理（保持与页面兼容的行为：如果可以，记录附近地标到日志）
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      await DLog.i('LocationService', '【逆地理】准备获取附近标志物 lat=${pos.latitude}, lon=${pos.longitude}');
      // 由于此处具体网络实现/ak 不在当前文件，保持简单：只写入日志，不中断流程。
      // 如页面已有通过服务器或其它服务拉取附近 POI 的逻辑，仍按原逻辑执行。
    } catch (_) {}
  }

  /// 弹出层上的失败提示（使用原生 Toast，能显示在遮罩之上）
  static Future<void> showFailureToast(String msg) async {
    try { await _sysCh.invokeMethod('showToast', {'message': msg}); } catch (_) {}
  }
}
