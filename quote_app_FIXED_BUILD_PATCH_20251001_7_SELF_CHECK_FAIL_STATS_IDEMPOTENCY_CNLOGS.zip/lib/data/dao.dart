
import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
  final rnd = r.nextInt(1<<32).toRadixString(36);
  return '${prefix}_${ts}_${rnd}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isNotEmpty) return rows.first;
    await db.insert('configs', {'api_key':'','model':'gpt-5','endpoint':'https://api.openai.com/v1/responses'});
    final one = await db.query('configs', limit: 1);
    return one.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint});
    } else {
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint}, where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }
}

class TaskDao {

  Future<void> updateNextTime(String taskUid, String nextTimeIso) async {
    final db = await AppDatabase.instance();
    try {
      await db.update('tasks', {'next_time': nextTimeIso}, where: 'task_uid=?', whereArgs: [taskUid]);
    } catch (_) {
      // 若无该列，则忽略
    }
  }

  Future<List<Map<String,dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return await db.query('tasks', orderBy: 'id DESC');
  }

  Future<Map<String,dynamic>?> getByUid(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<String> create({ required String name, required String type, String status = 'on', String prompt = '', String avatarPath = '', String startTime = '09:00', String? freqType, int? freqWeekday, int? freqDayOfMonth, String? freqCustom, }) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'status': status,
      'prompt': prompt,
      'avatar_path': avatarPath,
      'start_time': startTime,
      'freq_type': (freqType ?? 'daily'),
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': (freqCustom ?? '')
    });
    return uid;
  }

  Future<void> update(String uid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [uid]);
  }

  Future<void> delete(String uid) async {
    final db = await AppDatabase.instance();
    // Fill snapshots in logs before deleting the task
    final t = await getByUid(uid);
    if (t != null) {
      await db.rawUpdate(
        "UPDATE logs SET task_name_snapshot = COALESCE(task_name_snapshot, ?), task_start_time_snapshot = COALESCE(task_start_time_snapshot, ?) WHERE task_uid = ?",
        [ (t['name'] ?? '') as String, (t['start_time'] ?? '') as String, uid ]
      );
    }
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [uid]);
  }
}

class QuoteDao {
  Future<Map<String,dynamic>?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<List<Map<String,dynamic>>> all({int limit=100, int offset=0, String q=''}) async {
    final db = await AppDatabase.instance();
    if (q.trim().isEmpty) {
      return await db.query('quotes', orderBy: 'id DESC', limit: limit, offset: offset);
    } else {
      return await db.query('quotes', where: 'content LIKE ?', whereArgs: ['%$q%'], orderBy: 'id DESC', limit: limit, offset: offset);
    }
  }

  Future<String> insertQuote({required String taskUid, required String content}) async {
    final db = await AppDatabase.instance();
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'content': content,
      'notified': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    await LogDao().add(taskUid: taskUid, detail: '成功! 已插入名言');
    return uid;
  }

  // Deduplication: return true if content is unique against all existing quotes
  Future<bool> isUnique(String content, {double threshold = 0.90}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content']);
    final normNew = normalizeText(content);
    for (final r in rows) {
      final c = (r['content'] ?? '').toString();
      if (c.trim().isEmpty) continue;
      final sim = jaroWinkler(normNew, normalizeText(c));
      if (sim >= threshold || normalizeText(c) == normNew) {
        return false;
      }
    }
    return true;
  }

  // Round-robin (sequential) carousel for a task: oldest -> newest loop
  Future<Map<String,dynamic>?> carouselNextSequential(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC');
    if (rows.isEmpty) return null;
    final key = 'carousel_index_'+taskUid;
    final meta = await db.query('meta', where: 'key=?', whereArgs: [key], limit: 1);
    int idx = -1;
    if (meta.isNotEmpty) {
      idx = int.tryParse((meta.first['value'] ?? '-1').toString()) ?? -1;
    }
    final nextIdx = (idx + 1) % rows.length;
    final row = rows[nextIdx];
    // update cursor
    if (meta.isEmpty) {
      await db.insert('meta', {'key': key, 'value': nextIdx.toString()});
    } else {
      await db.update('meta', {'value': nextIdx.toString()}, where: 'key=?', whereArgs: [key]);
    }
    return row;
  }

  Future<void> markNotifiedByUid(String quoteUid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
  }
  // Compatibility wrapper used by UI pages
  Future<List<Map<String,dynamic>>> latest({int limit=100, int offset=0, String? q}) {
    return all(limit: limit, offset: offset, q: q ?? '');
  }


  Future<Map<String,dynamic>?> latestOne() async {
    final rows = await all(limit: 1, offset: 0);
    return rows.isNotEmpty ? rows.first : null;
  }


  Future<bool> existsSimilar(String content, {double threshold=0.90}) async {
    return !(await isUnique(content, threshold: threshold));
  }


  Future<bool> insertIfUnique({required String taskUid, required String content}) async {
    if (await isUnique(content, threshold: 0.90)) {
      await insertQuote(taskUid: taskUid, content: content);
      return true;
    }
    return false;
  }


  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isNotEmpty) {
      final id = rows.first['id'] as int;
      await db.update('quotes', {'content': content}, where: 'id=?', whereArgs: [id]);
      return true;
    } else {
      await insertQuote(taskUid: taskUid, content: content);
      return true;
    }
  }
}class LogDao {
  Future<void> clearAll() async { final db = await AppDatabase.instance(); await db.delete('logs'); }

  Future<String> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    // snapshot task name and start_time
    String? name, start;
    final trows = await db.query('tasks', where: 'task_uid=?', whereArgs: [taskUid], limit: 1);
    if (trows.isNotEmpty) {
      name = (trows.first['name'] ?? '').toString();
      start = (trows.first['start_time'] ?? '').toString();
    }
    final logUid = _uid('log');
    await db.insert('logs', {
      'log_uid': logUid,
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'task_name_snapshot': name,
      'task_start_time_snapshot': start,
    });
    return logUid;
  }

  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0}) async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
      'SELECT logs.*, '
      'COALESCE(logs.task_name_snapshot, tasks.name, "") AS task_name, '
      'COALESCE(logs.task_start_time_snapshot, tasks.start_time, "") AS task_start_time '
      'FROM logs LEFT JOIN tasks ON tasks.task_uid = logs.task_uid '
      'ORDER BY logs.id DESC LIMIT ? OFFSET ?', [limit, offset]);
    return rows;
  }
}


class FailureStatDao {
  Future<void> addFailure({required String taskUid, required String runKey, required String channel, required String uniqueName}) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final dateStr = now.toIso8601String().split('T').first;
    await db.insert('notify_failures', {
      'task_uid': taskUid,
      'run_key': runKey,
      'channel': channel,
      'unique_name': uniqueName,
      'status': 'failed',
      'date_str': dateStr,
      'created_at': now.toIso8601String(),
    });
  }

  Future<void> markLatestSuccessForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_failures', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isNotEmpty) {
      final id = rows.first['id'] as int;
      await db.update('notify_failures', {'status':'success'}, where: 'id=?', whereArgs: [id]);
    }
  }

  Future<List<Map<String, Object?>>> failedToday() async {
    final db = await AppDatabase.instance();
    final today = DateTime.now().toIso8601String().split('T').first;
    return await db.query('notify_failures', where: 'date_str=? AND status=?', whereArgs: [today, 'failed']);
  }
}

class ParamDao {
  Future<String?> get(String key) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_params', where: 'key=?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['value'] ?? '').toString();
  }
  Future<void> set(String key, String value) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_params', where: 'key=?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) {
      await db.insert('notify_params', {'key': key, 'value': value});
    } else {
      await db.update('notify_params', {'value': value}, where: 'key=?', whereArgs: [key]);
    }
  }
}

class NotifyGuardDao {
  Future<bool> exists(String taskUid, String runKey) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('notify_guard', where: 'task_uid=? AND run_key=?', whereArgs: [taskUid, runKey], limit: 1);
    return rows.isNotEmpty;
  }
  Future<void> markSent(String taskUid, String runKey) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().toIso8601String();
    try {
      await db.insert('notify_guard', {'task_uid': taskUid, 'run_key': runKey, 'sent_at': now});
    } catch (_) {
      // primary key conflict => already recorded
    }
  }
}
