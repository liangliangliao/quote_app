
import 'dart:convert';
import 'package:flutter/services.dart';

class NativeScheduler {
  static void initCallbacks() {
    const ch = MethodChannel('quote/native_scheduler');
    ch.setMethodCallHandler((call) async {
      if (call.method == 'am_notify_succeeded') {
        final uid = (call.arguments['uid'] ?? '').toString();
        final runKey = (call.arguments['runKey'] ?? '').toString();
        if (uid.isNotEmpty && runKey.isNotEmpty) {
          await SchedulerService.cancelWmFallback(uid, runKey, 1);
          await SchedulerService.cancelWmFallback(uid, runKey, 2);
          await SchedulerService.cancelWmNormal(uid, runKey);
          await LogDao().add(taskUid: uid, detail: '【信息】原生AM已成功，Dart侧已取消WM兜底+正常 run='+runKey);
        }
      }
    });
  }

  static const MethodChannel _ch = MethodChannel('native.scheduler');

  static Future<bool> scheduleExactAt({
    required int id,
    required int epochMs,
    Map<String, dynamic>? payload,
  }) async {
    final ok = await _ch.invokeMethod<bool>('scheduleExactAt', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload ?? {}),
    });
    return ok ?? false;
  }

  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
  }
}
