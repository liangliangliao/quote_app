
import 'dart:convert';
import 'package:flutter/material.dart';

class OctagonClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final w = size.width, h = size.height;
    final c = 0.18;
    final p = Path()
      ..moveTo(c*w, 0)..lineTo(w-c*w, 0)..lineTo(w, c*h)..lineTo(w, h-c*h)
      ..lineTo(w-c*w, h)..lineTo(c*w, h)..lineTo(0, h-c*h)..lineTo(0, c*h)
      ..close();
    return p;
  }
  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

double _clampPx(double minPx, double vwPercent, double maxPx, double viewportWidth) {
  final viaVw = viewportWidth * (vwPercent / 100.0);
  return (viaVw.clamp(minPx, maxPx) as num).toDouble();
}

class PosterPureFlutter extends StatelessWidget {
  final String topic;
  final String quote;
  final String author;
  final String note;
  final String avatar;
  final String woodBgAsset;
  const PosterPureFlutter({
    super.key,
    required this.topic,
    required this.quote,
    required this.author,
    required this.note,
    required this.avatar,
    this.woodBgAsset = 'assets/bg-wood-upload.jpg',
  });

  @override
  Widget build(BuildContext context) {
    final vw = MediaQuery.of(context).size.width;

    final s = _clampPx(10, 1.6, 14, vw);
    final m = _clampPx(14, 2.2, 18, vw);
    final avatarSize = _clampPx(56, 12, 84, vw);
    final innerPad = _clampPx(64, 8.6, 96, vw);

    final quoteFs = _clampPx(20, 4.8, 32, vw);
    final authorFs = _clampPx(14, 2.2, 17, vw);
    final noteFs = _clampPx(12, 2.1, 14, vw);

    final quoteStyle = TextStyle(
      fontSize: quoteFs,
      height: 1.60,
      letterSpacing: quoteFs * .06,
      fontWeight: FontWeight.w700,
      color: const Color(0xFF111111),
    );
    final authorStyle = TextStyle(
      fontSize: authorFs,
      height: 1.35,
      fontStyle: FontStyle.italic,
      letterSpacing: authorFs * .04,
      color: const Color(0xFF3A3A3A),
      fontWeight: FontWeight.w600,
    );
    final noteStyle = TextStyle(
      fontSize: noteFs,
      height: 1.62,
      letterSpacing: noteFs * .02,
      fontWeight: FontWeight.w600,
      color: const Color(0xFF202020),
    );
    final topicStyle = TextStyle(
      fontSize: m,
      height: 1.35,
      letterSpacing: m * .02,
      fontWeight: FontWeight.w500,
      color: const Color(0xFF111111),
    );

    final framePad = _clampPx(24, 5.6, 40, vw);
    final posterW = ((vw * .92) + 10).clamp(0.0, 570.0).toDouble();

    return Center(
      child: Container(
        width: posterW,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(woodBgAsset),
            fit: BoxFit.cover,
          ),
          borderRadius: BorderRadius.circular(4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.10),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.all(framePad),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(2),
            ),
            child: Padding(
              padding: EdgeInsets.all(innerPad),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: Text(topic, style: topicStyle)),
                      SizedBox(width: s),
                      ClipPath(
                        clipper: OctagonClipper(),
                        child: Container(
                          width: avatarSize,
                          height: avatarSize,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: _imageFrom(avatar),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: m + 10 - 18),
                  Expanded(
                    child: ScrollConfiguration(
                      behavior: const _NoGlowBehavior(),
                      child: SingleChildScrollView(
                        physics: const ClampingScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 15),
                              child: Text(quote, style: quoteStyle, textAlign: TextAlign.left),
                            ),
                            const SizedBox(height: 3),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Text(author, style: authorStyle, textAlign: TextAlign.right),
                            ),
                            const SizedBox(height: 3),
                            Padding(
                              padding: EdgeInsets.only(top: s + 4 - 1.2 * authorFs + 5 - 8),
                              child: Text(note, style: noteStyle, textAlign: TextAlign.left),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  ImageProvider _imageFrom(String any) {
    try {
      if (any.startsWith('data:')) {
        final b64 = any.substring(any.indexOf(',') + 1);
        return MemoryImage(base64.decode(b64));
      }
      if (any.startsWith('http')) return NetworkImage(any);
      if (any.startsWith('assets/')) return AssetImage(any);
    } catch (_) {}
    return const AssetImage('assets/bg-wood-upload.jpg');
  }
}

class _NoGlowBehavior extends ScrollBehavior {
  const _NoGlowBehavior();
  @override
  Widget buildViewportChrome(BuildContext context, Widget child, AxisDirection axisDirection) => child;
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const ClampingScrollPhysics();
}
