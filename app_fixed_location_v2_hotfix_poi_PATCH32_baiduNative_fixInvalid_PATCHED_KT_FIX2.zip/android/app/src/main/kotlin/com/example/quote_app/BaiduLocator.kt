package com.example.quote_app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.lang.reflect.Method
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Try Baidu SDK via reflection if present. Otherwise fall back to Android LocationManager.
 * Returns a Map compatible with Dart side expectation:
 *   {"lat":double,"lon":double,"acc":double,"provider":"baidu|system","src":"baidu-sdk|system-native"}
 */
object BaiduLocator {
    private const val TAG = "BaiduLocator"

    fun getLocationOnce(ctx: Context?, timeoutMs: Long, cb: (Boolean, Map<String, Any>?, String?) -> Unit) {
        if (ctx == null) { cb(false, null, "no_context"); return }
        // Try Baidu SDK first
        try {
            val ok = tryBaiduReflection(ctx, timeoutMs) { map ->
                cb(true, map, null)
            }
            if (ok) return
        } catch (t: Throwable) {
            Log.w(TAG, "Baidu reflection failed: ${t.message}")
        }
        // Fallback to system
        trySystem(ctx, timeoutMs) { success, map, err ->
            cb(success, map, err)
        }
    }

    /** Return true if reflection path started and delivered a result. */
    private fun tryBaiduReflection(ctx: Context, timeoutMs: Long, deliver: (Map<String, Any>) -> Unit): Boolean {
        return try {
            val lcClass = Class.forName("com.baidu.location.LocationClient")
            val optionClass = Class.forName("com.baidu.location.LocationClientOption")
            val listenerClass = Class.forName("com.baidu.location.BDAbstractLocationListener")
            val bdLocClass = Class.forName("com.baidu.location.BDLocation")

            // Build option
            val opt = optionClass.getDeclaredConstructor().newInstance()
            optionClass.getMethod("setOpenGps", Boolean::class.javaPrimitiveType).invoke(opt, true)
            optionClass.getMethod("setCoorType", String::class.java).invoke(opt, "wgs84")
            optionClass.getMethod("setScanSpan", Int::class.javaPrimitiveType).invoke(opt, 0)
            optionClass.getMethod("setIsNeedAddress", Boolean::class.javaPrimitiveType).invoke(opt, false)

            // Build client
            val client = lcClass.getConstructor(Context::class.java).newInstance(ctx)
            lcClass.getMethod("setLocOption", optionClass).invoke(client, opt)

            val latch = CountDownLatch(1)
            // Listener implementation
            val listener = java.lang.reflect.Proxy.newProxyInstance(
                listenerClass.classLoader,
                arrayOf(listenerClass)
            ) { _, method: Method, args ->
                if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
                    val bdLoc = args[0]
                    val lat = bdLocClass.getMethod("getLatitude").invoke(bdLoc) as Double
                    val lon = bdLocClass.getMethod("getLongitude").invoke(bdLoc) as Double
                    val acc = (bdLocClass.getMethod("getRadius").invoke(bdLoc) as? Float)?.toDouble() ?: 0.0
                    val map = hashMapOf<String, Any>(
                        "lat" to lat,
                        "lon" to lon,
                        "acc" to acc,
                        "provider" to "baidu",
                        "src" to "baidu-sdk"
                    )
                    try { lcClass.getMethod("unRegisterLocationListener", listenerClass).invoke(client, this) } catch (_:Throwable) {}
                    try { lcClass.getMethod("stop").invoke(client) } catch (_:Throwable) {}
                    deliver(map)
                    latch.countDown()
                    true
                } else false
            }

            lcClass.getMethod("registerLocationListener", listenerClass).invoke(client, listener)
            lcClass.getMethod("start").invoke(client)
            lcClass.getMethod("requestLocation").invoke(client)

            // Timeout guard
            Handler(Looper.getMainLooper()).postDelayed({
                if (latch.count == 1L) {
                    try { lcClass.getMethod("unRegisterLocationListener", listenerClass).invoke(client, listener) } catch (_:Throwable) {}
                    try { lcClass.getMethod("stop").invoke(client) } catch (_:Throwable) {}
                }
            }, timeoutMs)

            // If Baidu classes exist, assume success path will deliver (or timeout). Return true to avoid system path starting immediately.
            true
        } catch (cnf: ClassNotFoundException) {
            Log.w(TAG, "Baidu SDK not present.")
            false
        }
    }

    @SuppressLint("MissingPermission")
    private fun trySystem(ctx: Context, timeoutMs: Long, cb: (Boolean, Map<String, Any>?, String?) -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        // Try lastKnown first
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (_: SecurityException) { null }
        }.maxByOrNull { it.time }
        if (last != null) {
            cb(true, toMap(last), null)
            return
        }
        // request single update
        val latch = CountDownLatch(1)
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                if (latch.count == 1L) {
                    cb(true, toMap(loc), null)
                    latch.countDown()
                    try { lm.removeUpdates(this) } catch (_: Throwable) {}
                }
            }
            override fun onProviderDisabled(provider: String) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        } catch (se: SecurityException) {
            cb(false, null, "perm_denied")
            return
        } catch (t: Throwable) {
            cb(false, null, t.message)
            return
        }
        // Wait timeout then clean
        Thread {
            try { latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
            if (latch.count == 1L) {
                try { lm.removeUpdates(listener) } catch (_: Throwable) {}
                cb(false, null, "timeout")
            }
        }.start()
    }

    private fun toMap(loc: Location): Map<String, Any> = hashMapOf(
        "lat" to loc.latitude,
        "lon" to loc.longitude,
        "acc" to (loc.accuracy.toDouble()),
        "provider" to (loc.provider ?: "system"),
        "src" to "system-native"
    )
}