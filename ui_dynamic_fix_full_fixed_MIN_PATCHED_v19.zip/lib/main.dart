import 'package:path/path.dart' as p;
import 'dart:isolate';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'package:workmanager/workmanager.dart';

import 'data/db.dart';
import 'data/dao.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'services/wm_dispatcher.dart';
import 'background_tasks.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';
import 'services/native_guard.dart';
import 'utils/debug_logger.dart';
import 'platform/perm_helper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
  ));
  ui.DartPluginRegistrant.ensureInitialized();
  await AppDatabase.instance();
  // Ensure auxiliary columns exist (scheduled_run_key, next_time).  This should
  // be called once after opening the database to migrate older installations.
  try {
    await ensureExtraTaskColumns();
  } catch (_) {}
  await NotificationService.init();
  await SchedulerService.init();
  Workmanager().initialize(workmanagerCallbackDispatcher, isInDebugMode: false);
  SimpleBus.init();
  _registerHomeRefreshPort();
  runApp(const MyApp());

}


class NoOverscrollBehavior extends MaterialScrollBehavior {
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) {
    return child; // 禁用全局overscroll指示
  }
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      scrollBehavior: NoOverscrollBehavior(),
      title: '',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        // 为底部导航栏设置浅绿色背景和选中指示色
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.lightGreen.shade50,
          indicatorColor: Colors.lightGreen.shade200,
          labelTextStyle: MaterialStateProperty.all(const TextStyle(color: Colors.black87)),
          iconTheme: MaterialStateProperty.all(const IconThemeData(color: Colors.black87)),
        ),
      ),
      home: const GateKeeper(),
    );
  }
}

class GateKeeper extends StatefulWidget {
  const GateKeeper({super.key});
  @override
  State<GateKeeper> createState() => _GateKeeperState();
}

class _GateKeeperState extends State<GateKeeper> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _checkPerms();
  }

  Future<void> _checkPerms() async {
    // 第一道门卡：系统通知权限
    final hasNoti = await _areNotificationsEnabled();
    if (!hasNoti) {
      // 直接触发系统通知授权弹框，无自定义弹框
      try {
        await NotificationService.request();
      } catch (_) {}
      // 再次检查，如果仍未授权，则尝试打开系统设置界面
      final stillNo = !(await _areNotificationsEnabled());
      if (stillNo) {
        try { await _openNotificationSettings(); } catch (_) {}
      }
    }

      // 第二道门卡：精确闹钟权限（仅 Android，仅首次打开弹框）
  final _first = await _isFirstOpenAndMark();
  if (_first) {
// 第二道门卡：精确闹钟权限（仅 Android）
    final hasExact = await PermHelper.hasExactAlarmPermission();
    if (!hasExact && mounted) {
      final allow = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx)=> AlertDialog(
          title: const Text('闹钟提醒权限授权'),
          content: const Text('为确保定点提醒，请授予“闹钟与提醒(精确闹钟)”权限。'),
          actions: [
            TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('不允许')),
            FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('允许')),
          ],
        ),
      );
      if (allow == true) {
        await PermHelper.requestExactAlarmPermission();
        // 返回键回到此处后直接进入首页
  } // 非首次：跳过弹框
      } else {
        // 小确认框：是 / 否
        final go = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx)=> AlertDialog(
            content: const Text('你将不启用精准闹钟提醒功能！'),
            actions: [
              TextButton(onPressed: ()=> Navigator.of(ctx).pop(false), child: const Text('否')),
              FilledButton(onPressed: ()=> Navigator.of(ctx).pop(true), child: const Text('是')),
            ],
          ),
        );
        if (go != true) {
          // 停留在当前闹钟提醒框层面（重新弹出第二道门卡）
          _checkPerms();
          return;
        }
      }
    }

    setState(()=> _ready = true);
  }

  Future<bool> _areNotificationsEnabled() async {
    try {
      const ch = MethodChannel('com.example.quote_app/sys');
      final ok = await ch.invokeMethod<bool>('areNotificationsEnabled');
      return ok ?? true;
    } catch (_) {
      // 如果原生未实现，默认通过（实际发送时也会失败不崩溃）
      return true;
    }
  }

  Future<void> _openNotificationSettings() async {
    try {
      const ch = MethodChannel('com.example.quote_app/sys');
      await ch.invokeMethod('openNotificationSettings');
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return const RootShell();
  }
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});
  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _idx = 0;

  @override
  void initState() {
    super.initState();
    SchedulerService.scheduleNextForAll();
  }

  @override
  Widget build(BuildContext context) {
    final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];
    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) => setState(() { _idx = i; if (i == 0) SimpleBus.pokeHome(); }),
      ),
    );
  }
}


void _registerHomeRefreshPort() {
  const name = 'HOME_REFRESH_PORT';
  try { ui.IsolateNameServer.removePortNameMapping(name); } catch (_) {}
  final port = ReceivePort();
  ui.IsolateNameServer.registerPortWithName(port.sendPort, name);
  port.listen((_) {
    try { SimpleBus.pokeHome(); } catch (_) {}
  });
}

Future<bool> _isFirstOpenAndMark() async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final f = File(p.join(dir.path, '.first_open_done'));
    if (await f.exists()) return false;
    await f.writeAsString(DateTime.now().toIso8601String());
    return true;
  } catch (_) { return false; }
}
