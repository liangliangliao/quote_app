import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';

/// 首页 WebView 容器：统一处理“空白→兜底/动态”的展示与 JS 注入
class HomeHtmlView extends StatefulWidget {
  final String assetPath;                 // 兜底/模板 HTML
  final Map<String, dynamic>? data;       // null 表示兜底（无/异常）

  const HomeHtmlView({super.key, required this.assetPath, required this.data});

  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _revealed = false; // 首次加载显示控制
  bool _htmlLoaded = false; // 标识模板是否已加载完成

  // 无需隐藏/显示 HTML：我们通过一次性加载模板并在数据变化时直接注入，从而避免每次出现空白页面
  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) async {
            // 页面初次加载完成时注入初始数据（若有）
            _htmlLoaded = true;
            final hasData = widget.data != null;
            if (hasData) {
              await _injectDynamic(widget.data!);
            }
            _revealIfNeeded();
          },
        ),
      );
    _loadHtml();
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.data != oldWidget.data) {
      // 当模板已经加载并且数据变化时，直接注入新的数据，而不是重新加载空白模板
      if (_htmlLoaded) {
        final hasData = widget.data != null;
        if (hasData) {
          // 在下一微任务中执行 JS，确保 build 完成
          Future.microtask(() async {
            await _injectDynamic(widget.data!);
          });
        }
      }
    }
  }

  void _revealIfNeeded() {
    if (!_revealed && mounted) setState(() => _revealed = true);
  }

  Future<void> _loadHtml() async {
    // 加载模板 HTML；通过 file uri 加载原生资产，确保相对路径可用
    final uri = Uri.parse('file:///android_asset/flutter_assets/' + widget.assetPath);
    try {
      await _controller.loadRequest(uri);
    } catch (_) {
      // 回退到内联加载（当本地加载失败时）
      final html = await rootBundle.loadString(widget.assetPath);
      await _controller.loadHtmlString(html);
    }
  }

  Future<void> _injectDynamic(Map<String, dynamic> data) async {
    final payloadJson = jsonEncode(data);
    final js = '''
      (function(){
        try{
          var payload = $payloadJson;
          if (window.setDynamicData && typeof window.setDynamicData === 'function') {
            window.setDynamicData(payload);
          } else {
            window.PAYLOAD = payload;
            try{ if (window.onPayloadArrived) window.onPayloadArrived(payload); }catch(e){}
          }
          return true;
        }catch(e){ return false; }
      })();
    ''';
    try {
      await _controller.runJavaScriptReturningResult(js);
    } catch (_) {
      // 如果执行失败，则忽略错误；页面加载完成后注入可能仍会成功
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: _revealed ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 0),
      child: IgnorePointer(
        ignoring: !_revealed,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}