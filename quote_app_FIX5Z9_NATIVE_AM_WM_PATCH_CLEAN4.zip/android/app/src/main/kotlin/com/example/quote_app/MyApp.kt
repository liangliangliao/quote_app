package com.example.quote_app

import io.flutter.app.FlutterApplication

/**
 * Flutter V2 Embedding minimal Application.
 * android_alarm_manager_plus 4.x 不需要 V1 的 PluginRegistrantCallback / setPluginRegistrant。
 */
class MyApp : FlutterApplication()
