import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? true;
    } catch (_) {
      return true;
    }
  }
}
