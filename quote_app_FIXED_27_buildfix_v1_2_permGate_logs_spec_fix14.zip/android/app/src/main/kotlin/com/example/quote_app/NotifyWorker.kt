package com.example.quote_app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Data
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class NotifyWorker(appContext: Context, params: WorkerParameters)
  : CoroutineWorker(appContext, params) {

  private val client = OkHttpClient()

  override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
    try {
      val id = inputData.getInt("id", 0)
      val payload = inputData.getString("payload") ?: "{}"
      val o = JSONObject(payload)

      val type   = o.optString("type", "manual")
      val title  = o.optString("title", "")
      val uid    = o.optString("task_uid", "")
      val runKey = o.optString("run_key", "")
      var body   = o.optString("body", "")

      // 自动任务：联网→去重→入库→成功后再通知
      if (type == "auto") {
        val db = openQuotesDb()
        if (db == null) {
          Log.e("NotifyWorker", "open DB failed")
          return@withContext Result.retry()
        }
        val cfg = readConfigs(db)
        if (cfg.apiKey.isEmpty()) {
          Log.e("NotifyWorker", "api key empty")
          return@withContext Result.retry()
        }
        body = fetchQuote(cfg)  // may throw
        if (body.isBlank()) {
          Log.w("NotifyWorker", "empty quote from api")
          return@withContext Result.retry()
        }
        val inserted = insertQuoteIfNew(db, uid, body)
        if (!inserted) {
          Log.i("NotifyWorker", "duplicate quote, skip notify")
          return@withContext Result.success() // 不通知，视为完成
        }
      }

      if (body.isBlank()) {
        Log.w("NotifyWorker", "body empty, skip notify")
        return@withContext Result.success()
      }

      val channelId = "quote_notify"
      val notif = NotificationCompat.Builder(applicationContext, channelId)
        .setSmallIcon(applicationContext.applicationInfo.icon)
        .setContentTitle(if (title.isNotEmpty()) title else body.take(20))
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .build()
      NotificationManagerCompat.from(applicationContext).notify(id, notif)
      Result.success()
    } catch (e: Exception) {
      Log.e("NotifyWorker", "doWork error: ${e.message}")
      Result.retry()
    }
  }

  private fun openQuotesDb(): SQLiteDatabase? {
    return try {
      val pkgDir = applicationContext.filesDir.parentFile
      val appFlutter = File(pkgDir, "app_flutter")
      val dbFile = File(appFlutter, "quotes.db")
      SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READWRITE)
    } catch (e: Exception) {
      Log.e("NotifyWorker", "openQuotesDb: ${e.message}")
      null
    }
  }

  data class Config(val apiKey: String, val model: String, val endpoint: String)

  private fun readConfigs(db: SQLiteDatabase): Config {
    return try {
      db.rawQuery("SELECT api_key, model, endpoint FROM configs LIMIT 1", emptyArray()).use { c ->
        if (c.moveToFirst()) {
          Config(
            apiKey = c.getString(0) ?: "",
            model = c.getString(1) ?: "gpt-5",
            endpoint = c.getString(2) ?: "https://api.openai.com/v1/chat/completions"
          )
        } else Config("", "gpt-5", "https://api.openai.com/v1/chat/completions")
      }
    } catch (e: Exception) {
      Log.e("NotifyWorker", "readConfigs: ${e.message}")
      Config("", "gpt-5", "https://api.openai.com/v1/chat/completions")
    }
  }

  private fun fetchQuote(cfg: Config): String {
    val url = cfg.endpoint
    // 兼容 /v1/chat/completions 风格
    val payload = JSONObject().apply {
      put("model", cfg.model)
      if (url.contains("chat/completions")) {
        val messages = JSONArray().apply {
          put(JSONObject().apply {
            put("role", "system")
            put("content", "你是一位语录生成器，请输出一句简洁的中文名人名言。")
          })
          put(JSONObject().apply {
            put("role", "user")
            put("content", "给我一句今天的名人名言。")
          })
        }
        put("messages", messages)
        put("temperature", 0.7)
        put("n", 1)
      } else {
        // 兼容 /v1/responses 风格（OpenAI 新接口）
        put("input", "给我一句今天的中文名人名言。")
      }
    }
    val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    val req = Request.Builder()
      .url(url)
      .addHeader("Authorization", "Bearer ${cfg.apiKey}")
      .addHeader("Content-Type", "application/json")
      .post(body)
      .build()
    client.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
      val txt = resp.body?.string() ?: ""
      if (txt.isBlank()) throw Exception("empty body")
      // 简单解析两种返回
      val jo = JSONObject(txt)
      if (jo.has("choices")) {
        val arr = jo.getJSONArray("choices")
        if (arr.length() > 0) {
          val msg = arr.getJSONObject(0).optJSONObject("message")
          val content = msg?.optString("content")?.trim() ?: ""
          if (content.isNotEmpty()) return content
        }
      }
      if (jo.has("output_text")) {
        val content = jo.optString("output_text").trim()
        if (content.isNotEmpty()) return content
      }
      return jo.toString().take(120)
    }
  }

  private fun insertQuoteIfNew(db: SQLiteDatabase, taskUid: String, content: String): Boolean {
    return try {
      db.rawQuery("SELECT id FROM quotes WHERE task_uid=? AND content=? LIMIT 1",
        arrayOf(taskUid, content)).use { c ->
        if (c.moveToFirst()) return false
      }
      val qUid = "q_" + UUID.randomUUID().toString().replace("-", "").take(12)
      val now = System.currentTimeMillis()
      db.execSQL("INSERT INTO quotes(quote_uid, task_uid, content, notified, created_at) VALUES(?,?,?,?,?)",
        arrayOf(qUid, taskUid, content, 0, now))
      true
    } catch (e: Exception) {
      Log.e("NotifyWorker", "insertQuoteIfNew: ${e.message}")
      false
    }
  }
}
