package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import androidx.work.WorkManager

/**
 * 接收 AM 触发，显示由 Dart 侧（scheduler_service.dart）传入 payload 的“名人名言”通知。
 * 注意：这里不再写死任何内容；若 payload 缺失或正文为空，直接放弃发送并写入 log。
 */
class AlarmReceiver : BroadcastReceiver() {
  private fun cancelWmForRun(ctx: Context, uid: String, runKey: String) {
    try { WorkManager.getInstance(ctx).cancelUniqueWork("fb_next_${uid}_${runKey}") } catch (_: Exception) {}
    try { WorkManager.getInstance(ctx).cancelUniqueWork("wm_run_${uid}_${runKey}") } catch (_: Exception) {}
    try { WorkManager.getInstance(ctx).cancelUniqueWork("wm_after_am_${uid}_${runKey}") } catch (_: Exception) {}
  }

  override fun onReceive(ctx: Context, intent: Intent) {
    try {
      val payloadStr = intent.getStringExtra("payload") ?: "{}"
      val o = JSONObject(payloadStr)

      val id     = intent.getIntExtra("id", 0)
      val title  = o.optString("title", "").trim()   // 任务名，由 Dart 侧传入
      val body   = o.optString("body", "").trim()    // 名人名言正文，由 Dart 侧传入
      val uid    = o.optString("task_uid", "").trim()
      val runKey = o.optString("run_key", "").trim()

      if (uid.isNotEmpty() && runKey.isNotEmpty()) {
        cancelWmForRun(ctx, uid, runKey)
      }

      // 若正文为空，认为 payload 异常，不发送通知，避免“写死”的兜底文案
      if (body.isEmpty()) {
        Log.w("AlarmReceiver", "payload body empty, skip notify. raw=$payloadStr")
        return
      }

      val channelId = "quote_notify"
      val notif = NotificationCompat.Builder(ctx, channelId)
        .setSmallIcon(ctx.applicationInfo.icon)
        .setContentTitle(if (title.isNotEmpty()) title else body.take(20))
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .build()
      NotificationManagerCompat.from(ctx).notify(id, notif)
    } catch (e: Exception) {
      Log.e("AlarmReceiver", "onReceive error: ${e.message}")
    }
  }
}
