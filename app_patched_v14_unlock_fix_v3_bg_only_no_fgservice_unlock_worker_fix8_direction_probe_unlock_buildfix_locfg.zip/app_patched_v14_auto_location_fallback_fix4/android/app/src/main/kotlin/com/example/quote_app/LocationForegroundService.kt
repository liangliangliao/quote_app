package com.example.quote_app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.quote_app.data.DbRepo
import kotlin.concurrent.thread
import kotlin.math.*

/**
 * 前台定位服务：
 * - 仅在“配置表-地点规则开关=开启”时才启动；
 * - 获取当前位置（优先系统高精度，失败再回退最近已知位置；百度定位留给 Java/Flutter 集成后通过 DbRepo 扩展）；
 * - 与数据库中的目标地点坐标比对，<=100m 则发送“愿景提醒”通知；
 * - 关键节点写入【日志表】；
 * - 任务完成后自动 stopSelf() 并移除前台；
 */
class LocationForegroundService : Service() {

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // 启动前台通知（低重要级）
    startForeground(9001, buildOngoingNotification())
    try { DbRepo.log(this, null, "【地点规则】前台服务已启动（startId=$startId）") } catch (_: Throwable) {}

    // 在后台线程执行定位与比对
    thread(start=true) {
      runCatching {
        val loc = obtainCurrentLocation()
        if (loc == null) {
          try { DbRepo.log(this, null, "【地点规则】获取当前位置失败，结束本次（回包：NO_LOCATION）") } catch (_: Throwable) {}
          stopSelf()
          return@thread
        }
        val target = readTargetLocationFromDb()
        if (target == null) {
          try { DbRepo.log(this, null, "【地点规则】数据库未配置有效的目标位置，本次直接返回（回包：NO_TARGET）") } catch (_: Throwable) {}
          stopSelf()
          return@thread
        }
        val dist = distanceMeters(loc.latitude, loc.longitude, target.first, target.second)
        try { DbRepo.log(this, null, "【地点规则】当前位置=(${loc.latitude},${loc.longitude})，目标=(${target.first},${target.second})，距离=${dist}m") } catch (_: Throwable) {}

        if (dist <= 100.0) {
          try { DbRepo.log(this, null, "【地点规则】命中（<=100m），即将发送愿景提醒通知") } catch (_: Throwable) {}
          try { NotifyHelper.send(this, 2001, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null) } catch (_: Throwable) {}
        } else {
          try { DbRepo.log(this, null, "【地点规则】未命中（>${100}m），不发送通知") } catch (_: Throwable) {}
        }
      }.onFailure {
        try { DbRepo.log(this, null, "【地点规则】前台服务执行出现异常：" + it.message) } catch (_: Throwable) {}
      }.also {
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
      }
    }
    return START_NOT_STICKY
  }

  private fun buildOngoingNotification(): Notification {
    val chanId = "quote_location_fg"
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
      val chan = NotificationChannel(chanId, "地点前台服务", NotificationManager.IMPORTANCE_MIN)
      nm.createNotificationChannel(chan)
    }
    return NotificationCompat.Builder(this, chanId)
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setContentTitle("正在获取位置…")
      .setContentText("用于地点规则提醒")
      .setOngoing(true)
      .build()
  }

  private fun obtainCurrentLocation(): Location? {
    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    // 优先尝试当前高精度（API 30+）
    if (Build.VERSION.SDK_INT >= 30) {
      try {
        val token = android.os.CancellationSignal()
        var result: Location? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        val exec = ContextCompat.getMainExecutor(this)
        lm.getCurrentLocation(LocationManager.GPS_PROVIDER, token, exec) {
          result = it; latch.countDown()
        }
        latch.await(1200, java.util.concurrent.TimeUnit.MILLISECONDS)
        if (result != null && (result!!.accuracy <= 30f)) {
          try { DbRepo.log(this, null, "【地点规则】getCurrentLocation(GPS) 成功，精度=${result!!.accuracy}") } catch (_: Throwable) {}
          return result
        }
      } catch (_: Throwable) {}
    }
    // 回退：最后已知位置（GPS > NETWORK）
    val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    var best: Location? = null
    for (p in providers) {
      try {
        val last = lm.getLastKnownLocation(p)
        if (last != null) {
          if (best == null || (last.accuracy < best!!.accuracy)) best = last
        }
      } catch (_: Throwable) {}
    }
    if (best != null) {
      try { DbRepo.log(this, null, "【地点规则】使用 lastKnownLocation(${best!!.provider})，精度=${best!!.accuracy}") } catch (_: Throwable) {}
      return best
    }
    return null
  }

  private fun readTargetLocationFromDb(): Pair<Double, Double>? {
    // 通过 DbRepository 反射尝试多种方法名；若不可用，回退到 SharedPreferences（供前端临时写入）
    val ks = try { Class.forName("com.example.quote_app.data.DbRepository") } catch (_: Throwable) { null }
    val ctx = this
    val cand = arrayOf("readActiveGeoTarget","getActiveGeoTarget","getGeoTarget","queryTargetLocation")
    for (m in cand) {
      try {
        val method = ks?.getMethod(m, Context::class.java)
        val obj = method?.invoke(null, ctx)
        when (obj) {
          is android.util.Pair<*,*> -> {
            val lat = (obj.first as Number).toDouble()
            val lng = (obj.second as Number).toDouble()
            return lat to lng
          }
          is Array<*> -> if (obj.size >= 2) {
            val lat = (obj[0] as Number).toDouble()
            val lng = (obj[1] as Number).toDouble()
            return lat to lng
          }
          is String -> {
            val sp = obj.split(","); if (sp.size>=2) return sp[0].toDouble() to sp[1].toDouble()
          }
        }
      } catch (_: Throwable) {}
    }
    // fallback: 从 SP 读取（key: geo_target_lat / geo_target_lng）
    return try {
      val sp = ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
      val lat = java.lang.Double.longBitsToDouble(sp.getLong("geo_target_lat_bits", java.lang.Double.doubleToRawLongBits(Double.NaN)))
      val lng = java.lang.Double.longBitsToDouble(sp.getLong("geo_target_lng_bits", java.lang.Double.doubleToRawLongBits(Double.NaN)))
      if (lat.isNaN() || lng.isNaN()) null else (lat to lng)
    } catch (_: Throwable) { null }
  }

  private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat/2).pow(2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon/2).pow(2.0)
    val c = 2 * atan2(sqrt(a), sqrt(1-a))
    return R * c
  }
}
