
import 'dart:convert';
import 'package:flutter/services.dart';

class NativeScheduler {
  static const _ch = MethodChannel('app/native');
  static Future<bool> requestNotificationPermissionSystem() async { try { final r = await _ch.invokeMethod('request_notification_permission'); return (r==true); } catch (_) { return false; } }
  static const MethodChannel _ch = MethodChannel('native.scheduler');

  static Future<bool> scheduleExactAt({
    required int id,
    required int epochMs,
    Map<String, dynamic>? payload,
  }) async {
    final ok = await _ch.invokeMethod<bool>('scheduleExactAt', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload ?? {}),
    });
    return ok ?? false;
  }

  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
  }
}
