package com.example.quote_app.am

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.example.quote_app.data.DbInspector

object SqliteReader {
    private const val TAG = "quote_app/native"

    data class Payload(
        val title: String?,
        val content: String?,
        val bigPicture: String?,
        val actionsJson: String?,
        val payloadJson: String?
    )

    private fun tableExists(db: SQLiteDatabase, name: String): Boolean {
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(name)).use {
            return it.moveToFirst()
        }
    }

    private fun readPayload(c: Cursor): Payload {
        val title = c.getString(0)
        val content = c.getString(1)
        val big = if (c.columnCount > 2) c.getString(2) else null
        val actions = if (c.columnCount > 3) c.getString(3) else null
        val payload = if (c.columnCount > 4) c.getString(4) else null
        return Payload(title, content, big, actions, payload)
    }

    @JvmStatic
    fun payloadByTaskUidRunKey(context: Context, taskUid: String, runKey: String): Payload {
        try {
            val contract = DbInspector.loadOrLightScan(context)
            val db = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            db.use {
                if (tableExists(it, "payloads")) {
                    it.rawQuery(
                        "SELECT title,content,big_picture,actions_json,payload_json FROM payloads WHERE task_uid=? AND run_key=? LIMIT 1",
                        arrayOf(taskUid, runKey)
                    ).use { c ->
                        if (c.moveToFirst()) return readPayload(c)
                    }
                }
                // Fallback：只返回内容字段（从 quotes）
                it.rawQuery(
                    "SELECT content FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT 1",
                    arrayOf(taskUid)
                ).use { c ->
                    val content = if (c.moveToFirst()) c.getString(0) else null
                    return Payload(null, content, null, null, null)
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "SqliteReader.payloadByTaskUidRunKey: ${e.message}", e)
            throw RuntimeException(e)
        }
    }

    @JvmStatic
    fun payloadByJson(payloadJson: String?): Payload {
        return Payload(null, null, null, null, payloadJson)
    }

    @JvmStatic
    fun contentByTaskUid(context: Context, taskUid: String): String? {
        try {
            val contract = DbInspector.loadOrLightScan(context)
            val db = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            db.use {
                it.rawQuery(
                    "SELECT content FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT 1",
                    arrayOf(taskUid)
                ).use { c -> if (c.moveToFirst()) return c.getString(0) }
                return null
            }
        } catch (e: Throwable) {
            Log.e(TAG, "SqliteReader.contentByTaskUid: ${e.message}", e)
            throw RuntimeException(e)
        }
    }
}
