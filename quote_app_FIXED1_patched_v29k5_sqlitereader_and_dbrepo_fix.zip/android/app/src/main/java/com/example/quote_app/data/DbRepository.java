package com.example.quote_app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class DbRepository {

    public static final class Task {
        public String uid;
        public String title;
        public String content;
        public long triggerAtMillis;
        public boolean enabled = true;
        public String type;
        public String prompt;
        public String avatarPath;
    }

    public static final class Config {
        public String endpoint;
        public String apiKey;
        public String model;
    }

    private DbRepository() {}

    private static SQLiteDatabase open(String path) { try {
        try { return SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE); }
        catch (Throwable t) { return null; }
    } catch (Throwable e) { logAndRethrow("DbRepository.open", e); } }

    private static SQLiteDatabase openByCtx(Context ctx) { try {
        File appFlutter = new File(ctx.getFilesDir(), "../app_flutter");
        return open(new File(appFlutter, "quotes.db").getAbsolutePath());
    } catch (Throwable e) { logAndRethrow("DbRepository.openByCtx", e); } }

    public static void log(Context ctx, String taskUid, String message) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return;
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS logs(task_uid TEXT, message TEXT, created_at INTEGER DEFAULT (strftime('%s','now')))");
            ContentValues cv = new ContentValues();
            cv.put("task_uid", taskUid);
            cv.put("message", message);
            db.insert("logs", null, cv);
        } catch (Throwable ignore) {} finally { db.close(); }
    }

    public static Config loadConfig(Context ctx) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return null;
        try {
            Cursor c = db.rawQuery("SELECT key, value FROM config", null);
            try {
                if (c.moveToFirst()) {
    Config cfg = new Config();
    do {
        String k = c.getString(0);
        String v = c.getString(1);
        if ("endpoint".equals(k)) cfg.endpoint = v;
        else if ("api_key".equals(k)) cfg.apiKey = v;
        else if ("model".equals(k)) cfg.model = v;
    } while (c.moveToNext());
    if (cfg.endpoint == null) cfg.endpoint = "https://api.openai.com/v1";
    if (cfg.model == null) cfg.model = "gpt-5";
    if (cfg.apiKey == null) cfg.apiKey = "";
    return cfg;
}
            } catch (Throwable ignore) {} finally { c.close(); }
        } catch (Throwable ignore) {} finally { db.close(); }
        return null;
    }

    public static List<String> listQuoteTextsForTask(Context ctx, String uid, int limit) {
        List<String> out = new ArrayList<>();
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return out;
        try {
            Cursor c = db.rawQuery("SELECT content FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT ?",
                    new String[]{uid, String.valueOf(limit)});
            try {
                while (c.moveToNext()) out.add(c.getString(0));
            } catch (Throwable ignore) {} finally { c.close(); }
        } catch (Throwable ignore) {} finally { db.close(); }
        return out;
    }

    public static long insertQuote(Context ctx, String uid, String content, String extraJson) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return -1;
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS quotes(id INTEGER PRIMARY KEY AUTOINCREMENT, task_uid TEXT, content TEXT, extra TEXT, created_at INTEGER DEFAULT (strftime('%s','now')))");
            ContentValues cv = new ContentValues();
            cv.put("task_uid", uid);
            cv.put("content", content);
            cv.put("extra", extraJson);
            return db.insert("quotes", null, cv);
        } catch (Throwable t) {
            return -1;
        } finally { db.close(); }
    }

    public static void markQuoteNotified(Context ctx, long id) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return;
        try { db.execSQL("UPDATE quotes SET notified=1 WHERE id=?", new Object[]{id}); }
        catch (Throwable ignore) {} finally { db.close(); }
    }

    public static String getManualQuote(Context ctx, String uid) {
        SQLiteDatabase db = openByCtx(ctx);
        if (db == null) return null;
        try {
            Cursor c = db.rawQuery("SELECT content FROM quotes WHERE task_uid=? ORDER BY id DESC LIMIT 1", new String[]{uid});
            try { if (c.moveToFirst()) return c.getString(0); } catch (Throwable ignore) {} finally { c.close(); }
        } catch (Throwable ignore) {} finally { db.close(); }
        return null;
    }

    public static String getCarouselNextQuote(Context ctx, String uid) {
        return getManualQuote(ctx, uid);
    }

    public static Task getTaskFull(Context ctx, String uid) {
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        SQLiteDatabase db = open(cc.dbPath);
        if (db == null) return null;
        try {
            Cursor c = db.rawQuery("SELECT uid,title,content,trigger_at,enabled,type,prompt,avatar_path FROM " + cc.tasksSource + " WHERE uid=? LIMIT 1", new String[]{uid});
            try {
                if (c.moveToFirst()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    t.enabled = c.getInt(4) != 0;
                    t.type = c.getString(5);
                    t.prompt = c.getString(6);
                    t.avatarPath = c.getString(7);
                    return t;
                }
            } catch (Throwable ignore) {} finally { c.close(); }
        } catch (Throwable ignore) {} finally { db.close(); }
        return null;
    }

    public static List<Task> listFutureTasks(Context ctx) {
        List<Task> out = new ArrayList<>();
        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        SQLiteDatabase db = open(cc.dbPath);
        if (db == null) return out;
        try {
            long now = System.currentTimeMillis();
            Cursor c = db.rawQuery("SELECT uid,title,content,trigger_at FROM " + cc.tasksSource + " WHERE trigger_at>?", new String[]{ String.valueOf(now)});
            try {
                while (c.moveToNext()) {
                    Task t = new Task();
                    t.uid = c.getString(0);
                    t.title = c.getString(1);
                    t.content = c.getString(2);
                    t.triggerAtMillis = c.getLong(3);
                    out.add(t);
                }
            } catch (Throwable ignore) {} finally { c.close(); }
        } catch (Throwable ignore) {} finally { db.close(); }
        return out;
    }
}
