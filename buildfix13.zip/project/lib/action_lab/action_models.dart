import 'dart:convert';

String _safeStr(Object? v) => (v ?? '').toString();

enum ActionMode { plan, free }

enum ActionStepType { info, input, checklist, rating, summary }

class ActionStep {
  final String id;
  final ActionStepType type;
  final String title;
  final String body;
  final List<String> checklist;
  final bool required;
  final int minRating;
  final int maxRating;
  final String hint;

  const ActionStep({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    this.checklist = const [],
    this.required = true,
    this.minRating = 1,
    this.maxRating = 5,
    this.hint = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'title': title,
        'body': body,
        'checklist': checklist,
        'required': required,
        'minRating': minRating,
        'maxRating': maxRating,
        'hint': hint,
      };

  static ActionStep fromJson(Map<String, dynamic> j) {
    final t = _safeStr(j['type']);
    ActionStepType type = ActionStepType.info;
    for (final v in ActionStepType.values) {
      if (v.name == t) {
        type = v;
        break;
      }
    }
    final cl = <String>[];
    final raw = j['checklist'];
    if (raw is List) {
      for (final x in raw) {
        final s = _safeStr(x).trim();
        if (s.isNotEmpty) cl.add(s);
      }
    }
    return ActionStep(
      id: _safeStr(j['id']).isEmpty ? 'step_${DateTime.now().millisecondsSinceEpoch}' : _safeStr(j['id']),
      type: type,
      title: _safeStr(j['title']),
      body: _safeStr(j['body']),
      checklist: cl,
      required: (j['required'] is bool) ? (j['required'] as bool) : true,
      minRating: (j['minRating'] is num) ? (j['minRating'] as num).toInt() : 1,
      maxRating: (j['maxRating'] is num) ? (j['maxRating'] as num).toInt() : 5,
      hint: _safeStr(j['hint']),
    );
  }
}

class ActionTemplate {
  final String id;
  final String title;

  /// 概念：要落地的“抽象目的/功能/能力”。
  final String concept;

  /// 概念解释：一句话+必要细节。
  final String conceptDefinition;

  /// 操作化定义：在现实中如何“看得见”。
  final String operationalDefinition;

  /// 分类路径：例如「生活/健康/睡眠」。
  final String categoryPath;

  /// 计划模式（关联目标）/ 非计划模式（即时行动）
  final ActionMode mode;

  /// 建议行动步骤（严格可观察、可勾选/可输入）。
  final List<ActionStep> steps;

  /// 常见困难/挫折：失败时用于关联失败模块。
  final List<String> commonObstacles;

  /// 改变路径：用于识别问题行为、坏习惯，并提供替代路径。
  final List<String> changePath;

  /// 学习标签：用于未来学习模块联动（行为主义/习惯/强化等）。
  final List<String> learningTags;

  /// 计划模式时可选关联目标（未来目标模块会替换/映射此字段）。
  final String goalHint;

  const ActionTemplate({
    required this.id,
    required this.title,
    required this.concept,
    required this.conceptDefinition,
    required this.operationalDefinition,
    required this.categoryPath,
    required this.mode,
    required this.steps,
    this.commonObstacles = const [],
    this.changePath = const [],
    this.learningTags = const [],
    this.goalHint = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'concept': concept,
        'conceptDefinition': conceptDefinition,
        'operationalDefinition': operationalDefinition,
        'categoryPath': categoryPath,
        'mode': mode.name,
        'steps': steps.map((e) => e.toJson()).toList(),
        'commonObstacles': commonObstacles,
        'changePath': changePath,
        'learningTags': learningTags,
        'goalHint': goalHint,
      };

  static ActionTemplate fromJson(Map<String, dynamic> j) {
    final modeStr = _safeStr(j['mode']);
    final mode = modeStr == 'plan' ? ActionMode.plan : ActionMode.free;

    final steps = <ActionStep>[];
    final rawSteps = j['steps'];
    if (rawSteps is List) {
      for (final s in rawSteps) {
        if (s is Map) {
          steps.add(ActionStep.fromJson(s.map((k, v) => MapEntry(k.toString(), v))));
        }
      }
    }

    List<String> _listStr(dynamic raw) {
      final out = <String>[];
      if (raw is List) {
        for (final x in raw) {
          final s = _safeStr(x).trim();
          if (s.isNotEmpty) out.add(s);
        }
      }
      return out;
    }

    return ActionTemplate(
      id: _safeStr(j['id']),
      title: _safeStr(j['title']),
      concept: _safeStr(j['concept']),
      conceptDefinition: _safeStr(j['conceptDefinition']),
      operationalDefinition: _safeStr(j['operationalDefinition']),
      categoryPath: _safeStr(j['categoryPath']),
      mode: mode,
      steps: steps,
      commonObstacles: _listStr(j['commonObstacles']),
      changePath: _listStr(j['changePath']),
      learningTags: _listStr(j['learningTags']),
      goalHint: _safeStr(j['goalHint']),
    );
  }

  String toJsonString() => jsonEncode(toJson());

  static ActionTemplate? tryFromJsonString(String s) {
    try {
      final j = jsonDecode(s);
      if (j is Map) {
        return ActionTemplate.fromJson(j.map((k, v) => MapEntry(k.toString(), v)));
      }
    } catch (_) {}
    return null;
  }
}

class ActionRun {
  final String id;
  final String templateId;
  final String templateSnapshotJson;
  final String status; // in_progress / done / failed
  final int startedAtMs;
  final int updatedAtMs;
  final int? endedAtMs;
  final int idx;
  final String ansJson;
  final String? evalJson;
  final String? note;

  const ActionRun({
    required this.id,
    required this.templateId,
    required this.templateSnapshotJson,
    required this.status,
    required this.startedAtMs,
    required this.updatedAtMs,
    required this.endedAtMs,
    required this.idx,
    required this.ansJson,
    required this.evalJson,
    required this.note,
  });

  Map<String, Object?> toRow() => {
        'id': id,
        'template_id': templateId,
        'template_snapshot_json': templateSnapshotJson,
        'status': status,
        'started_at_ms': startedAtMs,
        'updated_at_ms': updatedAtMs,
        'ended_at_ms': endedAtMs,
        'idx': idx,
        'ans_json': ansJson,
        'eval_json': evalJson,
        'note': note,
      };

  static ActionRun fromRow(Map<String, Object?> r) => ActionRun(
        id: _safeStr(r['id']),
        templateId: _safeStr(r['template_id']),
        templateSnapshotJson: _safeStr(r['template_snapshot_json']),
        status: _safeStr(r['status']),
        startedAtMs: (r['started_at_ms'] as num?)?.toInt() ?? 0,
        updatedAtMs: (r['updated_at_ms'] as num?)?.toInt() ?? 0,
        endedAtMs: (r['ended_at_ms'] as num?)?.toInt(),
        idx: (r['idx'] as num?)?.toInt() ?? 0,
        ansJson: _safeStr(r['ans_json']),
        evalJson: r['eval_json']?.toString(),
        note: r['note']?.toString(),
      );

  Map<String, dynamic> get ans {
    try {
      final v = jsonDecode(ansJson);
      if (v is Map) return v.map((k, v) => MapEntry(k.toString(), v));
    } catch (_) {}
    return {};
  }

  ActionTemplate? get templateSnapshot => ActionTemplate.tryFromJsonString(templateSnapshotJson);
}
