import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:quote_app/action_lab/action_models.dart';

abstract class ActionLLMProvider {
  String get name;

  /// Generate a template draft from user keywords.
  ///
  /// Implementation should return a template WITHOUT the auto steps (concept/eval) already attached.
  /// The caller will wrap it into a full ActionTemplate.
  Future<ActionTemplateDraft> generate({required String keywords, required ActionMode mode});
}

class ActionTemplateDraft {
  final String title;
  final String categoryPath;
  final ActionMode mode;
  final String concept;
  final String conceptDefinition;
  final String operationalDefinition;
  final List<ActionStep> coreSteps;
  final List<String> obstacles;
  final List<String> changePath;
  final List<String> learningTags;
  final String goalHint;

  ActionTemplateDraft({
    required this.title,
    required this.categoryPath,
    required this.mode,
    required this.concept,
    required this.conceptDefinition,
    required this.operationalDefinition,
    required this.coreSteps,
    this.obstacles = const [],
    this.changePath = const [],
    this.learningTags = const [],
    this.goalHint = '',
  });
}

class MockActionLLMProvider implements ActionLLMProvider {
  @override
  String get name => '内置生成（离线）';

  @override
  Future<ActionTemplateDraft> generate({required String keywords, required ActionMode mode}) async {
    final k = keywords.trim();
    final lower = k.toLowerCase();

    String category = '日常生活/自我成长/微行动';
    String concept = '微行动（降低启动阻力）';
    String conceptDef = '把一个目标/改变拆成“现在就能做”的最小行为，以获得启动与强化。';
    String opDef = '能在 2–10 分钟内完成，并能被他人观察/被自己勾选验证的行为。';
    String title = '把“$k”落地成可执行行动';

    if (lower.contains('睡') || lower.contains('insomnia')) {
      category = '日常生活/健康/睡眠';
      concept = '睡前仪式（降低入睡摩擦）';
      conceptDef = '用固定流程把入睡从“靠意志”变成“靠流程”。';
      opDef = '10分钟内完成固定3–5步，并在结束后不再接触信息流。';
      title = '睡前仪式：让“$k”变得自动';
    } else if (lower.contains('拖延') || lower.contains('procrast')) {
      category = '学校/学习/拖延';
      concept = '启动动作（降低启动阻力）';
      conceptDef = '只要启动，后续更容易继续；把“开始”本身做成成功标准。';
      opDef = '2分钟内完成第一步，让任务从“未开始”变为“已开始”。';
      title = '作业/任务启动：从“$k”里出来';
    } else if (lower.contains('沟通') || lower.contains('表达') || lower.contains('关系')) {
      category = '人际关系/沟通/表达';
      concept = '具体请求（把需求落到行动层）';
      conceptDef = '用可执行请求替代情绪化抱怨，让对方知道怎么做。';
      opDef = '一句话包含：情境+感受+需要+具体可做请求（时间/行为）。';
      title = '沟通模板：把“$k”说清楚';
    } else if (lower.contains('专注') || lower.contains('工作') || lower.contains('效率')) {
      category = '工作/效率/专注';
      concept = '深度工作块（单任务专注）';
      conceptDef = '专注是行为：在一段时间里只做一件事，并持续拉回注意力。';
      opDef = '25分钟内只做一个任务，结束产出一个可见成果。';
      title = '25分钟深度工作块：围绕“$k”';
    }

    final core = <ActionStep>[];

    // first: checklist
    core.add(ActionStep(
      id: 'draft_check',
      type: ActionStepType.checklist,
      title: '行动清单（可勾选）',
      body: '把行动写成“看得见”的行为。越具体越好。',
      checklist: [
        '定义一个最小行动（<=10分钟）',
        '移除一个干扰（手机/通知/人/环境）',
        '完成后写一句“成果记录”',
      ],
    ));

    // second: input
    core.add(ActionStep(
      id: 'draft_out',
      type: ActionStepType.input,
      title: '成果记录（可见输出）',
      body: '写下你完成后的可见成果（哪怕很小）。',
      hint: '例如：写了3条；走了10分钟；清理了一角；发出一条消息。',
    ));

    return ActionTemplateDraft(
      title: title,
      categoryPath: category,
      mode: mode,
      concept: concept,
      conceptDefinition: conceptDef,
      operationalDefinition: opDef,
      coreSteps: core,
      obstacles: const ['启动困难', '环境干扰', '目标过大'],
      changePath: const ['把行动缩小到更小', '改变环境线索', '设置即时强化'],
      learningTags: const ['行为主义', '微行动', '强化'],
    );
  }
}

/// OpenAI/DeepSeek provider that requests a JSON-only output.
///
/// For security: API key is provided by user at runtime.
abstract class _HttpJsonProvider implements ActionLLMProvider {
  final String apiKey;
  final String endpoint;
  final String model;

  _HttpJsonProvider({required this.apiKey, required this.endpoint, required this.model});

  Map<String, String> get headers;

  @override
  Future<ActionTemplateDraft> generate({required String keywords, required ActionMode mode}) async {
    final prompt = _systemPrompt(mode: mode);
    final user = _userPrompt(keywords: keywords, mode: mode);

    final payload = buildPayload(systemPrompt: prompt, userPrompt: user);
    final resp = await http.post(Uri.parse(endpoint), headers: headers, body: jsonEncode(payload));
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
    }

    final text = parseText(resp.body);
    final obj = _extractJson(text);
    return _draftFromJson(obj, mode: mode);
  }

  /// Build request payload.
  Map<String, dynamic> buildPayload({required String systemPrompt, required String userPrompt});

  /// Parse model plain text from raw response.
  String parseText(String raw);

  String _systemPrompt({required ActionMode mode}) {
    return '你是一个“行动模板生成器”。要求：\n'
        '1) 行动必须与概念一致，是概念在现实中的直观表达；\n'
        '2) 必须给出操作化定义（现实可观察指标）；\n'
        '3) 步骤必须可执行、可勾选/可记录；\n'
        '4) 输出必须是严格 JSON（不要 markdown，不要多余文字）。\n'
        '模式：${mode == ActionMode.plan ? '计划模式（关联目标）' : '非计划模式（即时行动）'}。';
  }

  String _userPrompt({required String keywords, required ActionMode mode}) {
    return '关键词：$keywords\n\n'
        '请生成一个行动模板 JSON，对应结构：\n'
        '{\n'
        '  "title": "...",\n'
        '  "categoryPath": "日常生活/…",\n'
        '  "mode": "plan"|"free",\n'
        '  "concept": "...",\n'
        '  "conceptDefinition": "...",\n'
        '  "operationalDefinition": "...",\n'
        '  "goalHint": "...（仅计划模式可填）",\n'
        '  "coreSteps": [\n'
        '    {"type":"checklist","title":"...","body":"...","checklist":["..."]},\n'
        '    {"type":"input","title":"...","body":"...","hint":"...","required":true}\n'
        '  ],\n'
        '  "obstacles": ["..."],\n'
        '  "changePath": ["..."],\n'
        '  "learningTags": ["..."],\n'
        '}\n\n'
        '注意：coreSteps 至少 2 步，其中至少 1 个 checklist。';
  }

  Map<String, dynamic> _extractJson(String text) {
    // Find first { ... } block.
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start < 0 || end <= start) {
      throw Exception('未找到JSON对象');
    }
    final raw = text.substring(start, end + 1);
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  ActionTemplateDraft _draftFromJson(Map<String, dynamic> j, {required ActionMode mode}) {
    final title = (j['title'] ?? '').toString().trim();
    final category = (j['categoryPath'] ?? '').toString().trim();
    final concept = (j['concept'] ?? '').toString().trim();
    final conceptDef = (j['conceptDefinition'] ?? '').toString().trim();
    final opDef = (j['operationalDefinition'] ?? '').toString().trim();
    final goalHint = (j['goalHint'] ?? '').toString();

    final coreSteps = <ActionStep>[];
    final rawSteps = j['coreSteps'];
    if (rawSteps is List) {
      var n = 1;
      for (final x in rawSteps) {
        if (x is! Map) continue;
        final typeStr = (x['type'] ?? '').toString();
        final type = ActionStepType.values.firstWhere(
          (e) => e.name == typeStr,
          orElse: () => ActionStepType.input,
        );
        final stTitle = (x['title'] ?? '').toString();
        final body = (x['body'] ?? '').toString();
        final hint = (x['hint'] ?? '').toString();
        final req = (x['required'] ?? true) == true;
        final checklist = <String>[];
        final rawChecklist = x['checklist'];
        if (rawChecklist is List) {
          for (final it in rawChecklist) {
            final s = it.toString().trim();
            if (s.isNotEmpty) checklist.add(s);
          }
        }
        coreSteps.add(ActionStep(
          id: 'draft_s${n++}',
          type: type,
          title: stTitle,
          body: body,
          hint: hint,
          checklist: checklist,
          required: req,
        ));
      }
    }

    final obstacles = _stringList(j['obstacles']);
    final changePath = _stringList(j['changePath']);
    final learningTags = _stringList(j['learningTags']);

    if (title.isEmpty || category.isEmpty || concept.isEmpty || opDef.isEmpty || coreSteps.isEmpty) {
      throw Exception('JSON字段不完整');
    }

    return ActionTemplateDraft(
      title: title,
      categoryPath: category,
      mode: mode,
      concept: concept,
      conceptDefinition: conceptDef,
      operationalDefinition: opDef,
      coreSteps: coreSteps,
      obstacles: obstacles,
      changePath: changePath,
      learningTags: learningTags,
      goalHint: goalHint,
    );
  }

  List<String> _stringList(dynamic v) {
    if (v is List) {
      return v.map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toList();
    }
    return const [];
  }
}

class OpenAIActionLLMProvider extends _HttpJsonProvider {
  OpenAIActionLLMProvider({required super.apiKey, required super.model})
      : super(endpoint: 'https://api.openai.com/v1/responses');

  @override
  String get name => 'OpenAI';

  @override
  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      };

  @override
  Map<String, dynamic> buildPayload({required String systemPrompt, required String userPrompt}) {
    // Responses API (recommended). If your account uses a different endpoint, adapt here.
    return {
      'model': model,
      'input': [
        {
          'role': 'system',
          'content': [
            {'type': 'input_text', 'text': systemPrompt}
          ]
        },
        {
          'role': 'user',
          'content': [
            {'type': 'input_text', 'text': userPrompt}
          ]
        },
      ],
      'text': {'format': {'type': 'text'}},
    };
  }

  @override
  String parseText(String raw) {
    final j = jsonDecode(raw);
    // responses: output[0].content[0].text
    try {
      final output = (j['output'] as List).first;
      final content = (output['content'] as List).first;
      final text = (content['text'] ?? '').toString();
      if (text.isNotEmpty) return text;
    } catch (_) {}

    // fallback for other formats
    return raw;
  }
}

class DeepSeekActionLLMProvider extends _HttpJsonProvider {
  DeepSeekActionLLMProvider({required super.apiKey, required super.model})
      : super(endpoint: 'https://api.deepseek.com/chat/completions');

  @override
  String get name => 'DeepSeek';

  @override
  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      };

  @override
  Map<String, dynamic> buildPayload({required String systemPrompt, required String userPrompt}) {
    return {
      'model': model,
      'messages': [
        {'role': 'system', 'content': systemPrompt},
        {'role': 'user', 'content': userPrompt},
      ],
      'temperature': 0.2,
    };
  }

  @override
  String parseText(String raw) {
    final j = jsonDecode(raw);
    try {
      final choices = j['choices'] as List;
      final msg = choices.first['message'];
      final content = (msg['content'] ?? '').toString();
      if (content.isNotEmpty) return content;
    } catch (_) {}
    return raw;
  }
}

String newTemplateId({String prefix = 'ai_'}) {
  final ms = DateTime.now().millisecondsSinceEpoch;
  final r = Random().nextInt(99999).toString().padLeft(5, '0');
  return '${prefix}${ms}_$r';
}

ActionTemplate wrapDraftToTemplate(ActionTemplateDraft d) {
  final id = newTemplateId();

  final steps = <ActionStep>[];
  steps.add(ActionStep(
    id: '${id}_concept',
    type: ActionStepType.info,
    title: '概念与定义',
    body: '**概念：${d.concept}**\n\n${d.conceptDefinition}\n\n**操作化定义（现实可观察指标）**\n${d.operationalDefinition}',
    required: false,
  ));

  if (d.mode == ActionMode.plan) {
    steps.add(ActionStep(
      id: '${id}_goal',
      type: ActionStepType.input,
      title: '关联目标（计划模式）',
      body: d.goalHint.trim().isEmpty
          ? '写下你要关联的目标（未来会接入目标模块）。\n\n格式建议：目标一句话 + 截止时间 + 衡量指标。'
          : d.goalHint,
      hint: '例如：4周内把睡眠稳定到23:30入睡；用“连续天数”衡量。',
    ));
  }

  // core steps with new ids
  var n = 1;
  for (final s in d.coreSteps) {
    steps.add(ActionStep(
      id: '${id}_s${n++}',
      type: s.type,
      title: s.title,
      body: s.body,
      checklist: s.checklist,
      required: s.required,
      hint: s.hint,
      minRating: s.minRating,
      maxRating: s.maxRating,
    ));
  }

  steps.addAll([
    ActionStep(
      id: '${id}_match',
      type: ActionStepType.rating,
      title: '概念一致性评分',
      body: '你的实际行动，是否是“概念”的直观表达？\n\n提示：请对照“操作化定义/可观察指标”。',
      minRating: 1,
      maxRating: 5,
    ),
    ActionStep(
      id: '${id}_result',
      type: ActionStepType.rating,
      title: '现实结果评分',
      body: '这次行动在现实里带来了多大效果？\n\n1=几乎无变化，3=有一点点起色，5=明显改善/达成。',
      minRating: 1,
      maxRating: 5,
    ),
    ActionStep(
      id: '${id}_obstacle',
      type: ActionStepType.input,
      title: '遇到的困难（用于失败模块/改进）',
      body: '写下你遇到的阻力、挫折或失败点。没有也可以写“无”。',
      hint: '例如：手机干扰；情绪低落；时间不够；他人不配合…',
      required: false,
    ),
    ActionStep(
      id: '${id}_next',
      type: ActionStepType.input,
      title: '下一次的更小动作',
      body: '把下一次的行动缩小到“再怎么不想也做得到”的程度。',
      hint: '例如：只做2分钟；只准备材料；只开个头…',
      required: false,
    ),
    ActionStep(
      id: '${id}_summary',
      type: ActionStepType.summary,
      title: '完成',
      body: '你已经完成一次“概念→现实”的落地。\n\n建议：把“下一次的更小动作”设成提醒或加入计划。',
      required: false,
    ),
  ]);

  return ActionTemplate(
    id: id,
    title: d.title,
    concept: d.concept,
    conceptDefinition: d.conceptDefinition,
    operationalDefinition: d.operationalDefinition,
    categoryPath: d.categoryPath,
    mode: d.mode,
    steps: steps,
    commonObstacles: d.obstacles,
    changePath: d.changePath,
    learningTags: d.learningTags,
    goalHint: d.goalHint,
  );
}
