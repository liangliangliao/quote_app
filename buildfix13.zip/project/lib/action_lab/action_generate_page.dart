import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_llm_service.dart';
import 'package:quote_app/action_lab/action_models.dart';
import 'package:quote_app/action_lab/action_template_detail_page.dart';

class ActionGeneratePage extends StatefulWidget {
  const ActionGeneratePage({super.key});

  @override
  State<ActionGeneratePage> createState() => _ActionGeneratePageState();
}

class _ActionGeneratePageState extends State<ActionGeneratePage> {
  final _kw = TextEditingController();
  final _apiKey = TextEditingController();
  final _model = TextEditingController(text: 'gpt-4.1-mini');
  ActionMode _mode = ActionMode.free;

  String _provider = 'mock';
  bool _loading = false;
  String? _err;

  @override
  void dispose() {
    _kw.dispose();
    _apiKey.dispose();
    _model.dispose();
    super.dispose();
  }

  ActionLLMProvider _buildProvider() {
    if (_provider == 'openai') {
      return OpenAIActionLLMProvider(apiKey: _apiKey.text.trim(), model: _model.text.trim());
    }
    if (_provider == 'deepseek') {
      return DeepSeekActionLLMProvider(apiKey: _apiKey.text.trim(), model: _model.text.trim());
    }
    return MockActionLLMProvider();
  }

  Future<void> _generate() async {
    final kw = _kw.text.trim();
    if (kw.isEmpty) {
      setState(() => _err = '请输入关键词');
      return;
    }

    final provider = _buildProvider();
    if ((provider is OpenAIActionLLMProvider || provider is DeepSeekActionLLMProvider) && _apiKey.text.trim().isEmpty) {
      setState(() => _err = '请输入 API Key（仅本次使用，不会保存）');
      return;
    }

    setState(() {
      _loading = true;
      _err = null;
    });

    try {
      final draft = await provider.generate(keywords: kw, mode: _mode);
      final tpl = wrapDraftToTemplate(draft);
      if (!mounted) return;
      setState(() => _loading = false);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ActionTemplateDetailPage(template: tpl, fromAiPreview: true)),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI 生成行动模板')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
        children: [
          const Text('输入关键词 → 生成可执行模板', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(
            '模板会自动包含：概念/操作化定义 → 行动步骤 → 一致性/结果评分。\n生成后你可以保存到“我的模板”。',
            style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35),
          ),
          const SizedBox(height: 14),

          TextField(
            controller: _kw,
            decoration: InputDecoration(
              labelText: '关键词',
              hintText: '例如：拖延/睡眠/专注/沟通/学习/健身/焦虑…',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
            maxLines: 2,
          ),
          const SizedBox(height: 12),

          SegmentedButton<ActionMode>(
            segments: const [
              ButtonSegment(value: ActionMode.free, label: Text('非计划模式')),
              ButtonSegment(value: ActionMode.plan, label: Text('计划模式')),
            ],
            selected: {_mode},
            onSelectionChanged: (s) => setState(() => _mode = s.first),
          ),
          const SizedBox(height: 12),

          DropdownButtonFormField<String>(
            value: _provider,
            items: const [
              DropdownMenuItem(value: 'mock', child: Text('内置生成（离线）')),
              DropdownMenuItem(value: 'openai', child: Text('OpenAI（需要 API Key）')),
              DropdownMenuItem(value: 'deepseek', child: Text('DeepSeek（需要 API Key）')),
            ],
            onChanged: (v) => setState(() => _provider = v ?? 'mock'),
            decoration: InputDecoration(
              labelText: '生成器',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),

          if (_provider != 'mock') ...[
            const SizedBox(height: 12),
            TextField(
              controller: _apiKey,
              decoration: InputDecoration(
                labelText: 'API Key（仅本次使用，不保存）',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _model,
              decoration: InputDecoration(
                labelText: '模型名',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '注意：不同账号/平台可用的模型名可能不同；如果报错，请改成你账号实际可用的模型名。',
              style: TextStyle(color: Colors.black.withOpacity(0.7), height: 1.35),
            ),
          ],

          if (_err != null) ...[
            const SizedBox(height: 12),
            Text(_err!, style: const TextStyle(color: Colors.red)),
          ],

          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _loading ? null : _generate,
            icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome),
            label: const Text('生成模板'),
          ),

          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.04),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Text(
              '输出质量诀窍：\n- 用“我要做什么行为”描述关键词，而不是只写抽象词。\n- 例如：把“自律”改成“每天19:00写作15分钟”。\n- 计划模式适合：长期目标/习惯；非计划模式适合：当下就做。',
              style: TextStyle(color: Colors.black.withOpacity(0.75), height: 1.35),
            ),
          )
        ],
      ),
    );
  }
}
