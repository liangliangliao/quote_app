import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_flow_page.dart';
import 'package:quote_app/action_lab/action_models.dart';
import 'package:quote_app/action_lab/action_template_detail_page.dart';

class ActionHistoryPage extends StatefulWidget {
  const ActionHistoryPage({super.key});

  @override
  State<ActionHistoryPage> createState() => _ActionHistoryPageState();
}

class _ActionHistoryPageState extends State<ActionHistoryPage> {
  final _dao = ActionDao();
  bool _loading = true;
  String? _err;
  List<ActionRun> _runs = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final runs = await _dao.listRuns(limit: 300);
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = null;
        _runs = runs;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('历史与复盘'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _err != null
              ? Center(child: Text('加载失败：$_err'))
              : _runs.isEmpty
                  ? Center(child: Text('还没有行动记录。', style: TextStyle(color: Colors.black.withOpacity(0.7))))
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
                      itemCount: _runs.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) => _runCard(_runs[i]),
                    ),
    );
  }

  Widget _runCard(ActionRun r) {
    final tpl = r.templateSnapshot;
    final title = tpl?.title ?? r.templateId;
    final status = r.status;
    final fmt = DateFormat('yyyy-MM-dd HH:mm');
    final time = fmt.format(DateTime.fromMillisecondsSinceEpoch(r.updatedAtMs));

    int? _evalInt(String key) {
      try {
        final j = jsonDecode(r.evalJson ?? '{}');
        if (j is Map) {
          final v = j[key];
          if (v is num) return v.toInt();
          return int.tryParse((v ?? '').toString());
        }
      } catch (_) {}
      return null;
    }

    final match = _evalInt('concept_match');
    final result = _evalInt('result_score');

    final badge = status == 'done'
        ? '完成'
        : status == 'failed'
            ? '失败'
            : '进行中';

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ActionRunDetailPage(runId: r.id)),
        ).then((_) => _load()),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.black.withOpacity(0.06)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  ),
                  _pill(badge, status),
                ],
              ),
              const SizedBox(height: 6),
              Text(time, style: TextStyle(color: Colors.black.withOpacity(0.6))),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (match != null) _metric('一致性', match),
                  if (result != null) _metric('结果', result),
                  _metric('步骤', r.idx + 1),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pill(String text, String status) {
    Color bg;
    if (status == 'done') {
      bg = Colors.black.withOpacity(0.06);
    } else if (status == 'failed') {
      bg = Colors.black.withOpacity(0.10);
    } else {
      bg = Colors.black.withOpacity(0.06);
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
      child: Text(text, style: TextStyle(fontSize: 12, color: Colors.black.withOpacity(0.75))),
    );
  }

  Widget _metric(String k, int v) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.04),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text('$k：$v', style: TextStyle(color: Colors.black.withOpacity(0.75))),
    );
  }
}

class ActionRunDetailPage extends StatefulWidget {
  final String runId;
  const ActionRunDetailPage({super.key, required this.runId});

  @override
  State<ActionRunDetailPage> createState() => _ActionRunDetailPageState();
}

class _ActionRunDetailPageState extends State<ActionRunDetailPage> {
  final _dao = ActionDao();
  bool _loading = true;
  String? _err;
  ActionRun? _run;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await _dao.getRun(widget.runId);
      if (r == null) throw Exception('记录不存在');
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = null;
        _run = r;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_err != null) {
      return Scaffold(appBar: AppBar(title: const Text('行动记录')), body: Center(child: Text('加载失败：$_err')));
    }

    final r = _run!;
    final tpl = r.templateSnapshot;

    return Scaffold(
      appBar: AppBar(title: const Text('行动记录')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
        children: [
          Text(tpl?.title ?? r.templateId, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text('状态：${r.status}', style: TextStyle(color: Colors.black.withOpacity(0.7))),
          const SizedBox(height: 14),

          if (tpl != null)
            FilledButton.icon(
              onPressed: r.status == 'in_progress'
                  ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActionFlowPage(runId: r.id))).then((_) => _load())
                  : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActionTemplateDetailPage(template: tpl!))),
              icon: Icon(r.status == 'in_progress' ? Icons.play_arrow : Icons.description_outlined),
              label: Text(r.status == 'in_progress' ? '继续行动' : '查看模板'),
            ),

          const SizedBox(height: 12),
          _kvCard('评分/评价', _prettyJson(r.evalJson)),
          const SizedBox(height: 12),
          _kvCard('你的记录（答案/勾选）', _prettyJson(r.ansJson)),

          if (tpl != null) ...[
            const SizedBox(height: 12),
            _kvCard('概念与操作化定义', '${tpl.concept}\n\n${tpl.operationalDefinition}'),
          ]
        ],
      ),
    );
  }

  String _prettyJson(String? raw) {
    if (raw == null || raw.trim().isEmpty) return '（无）';
    try {
      final j = jsonDecode(raw);
      const enc = JsonEncoder.withIndent('  ');
      return enc.convert(j);
    } catch (_) {
      return raw;
    }
  }

  Widget _kvCard(String title, String body) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SelectableText(body, style: TextStyle(color: Colors.black.withOpacity(0.75), height: 1.35)),
        ],
      ),
    );
  }
}
