import 'action_models.dart';

// Built-in action templates (general, common, and concrete). Users can copy to customize.
final List<ActionTemplate> builtInActionTemplates = [
  // -------------------- Daily life --------------------
  _t(
    id: 'builtin_micro_start',
    title: '2分钟启动动作（立刻开始）',
    category: '日常生活/自我成长/微行动',
    mode: ActionMode.free,
    concept: '启动动作（降低启动阻力）',
    conceptDef: '把“开始”本身做成成功标准。只要开始了，后续更容易继续。',
    opDef: '在2分钟内完成一件“可观察”的第一步，让任务从“未开始”变为“已开始”。',
    checklist: [
      '选一个任务，只写“第一步”',
      '设置2分钟计时器',
      '只做第一步（不追求完成）',
      '结束时写一句：我刚刚做了什么？',
    ],
    obstacles: ['觉得太难', '担心做不好', '手机干扰'],
    changePath: ['把行动缩小到更小', '先做“准备动作”', '移除干扰线索（手机/通知）'],
    learning: ['行为主义', '刺激控制', '启动成本'],
  ),
  _t(
    id: 'builtin_5min_tidy',
    title: '5分钟环境整理（降低摩擦）',
    category: '日常生活/环境/整理',
    mode: ActionMode.free,
    concept: '环境设计（用环境支持行为）',
    conceptDef: '行为很多时候不是“意志问题”，而是“环境线索 + 摩擦”问题。',
    opDef: '5分钟内完成一个可见区域的整理，并把下一次要用的物品放到“触手可及”。',
    checklist: [
      '设5分钟计时器',
      '只整理一个区域（桌面/床头/包）',
      '把“下一次要用的东西”摆出来',
      '拍一张“整理后”照片或写一句记录',
    ],
    obstacles: ['想一次整理完', '分心去做别的'],
    changePath: ['只选一个区域', '计时结束就停', '把“丢弃/收纳”分两轮'],
    learning: ['刺激控制', '摩擦理论'],
  ),
  _t(
    id: 'builtin_sleep_ritual',
    title: '睡前10分钟仪式（更容易入睡）',
    category: '日常生活/健康/睡眠',
    mode: ActionMode.plan,
    concept: '睡前仪式（降低入睡摩擦）',
    conceptDef: '把入睡从“靠意志”变成“靠流程”，用固定线索触发睡意。',
    opDef: '睡前固定3–5步，10分钟内完成；结束后不再接触信息流（手机/短视频）。',
    goalHint: '写下你要达到的睡眠目标（时间/连续天数/主观疲劳评分）。',
    checklist: [
      '把手机放到卧室外或开启专注模式',
      '洗漱/热水洗手/简单拉伸（任选一项固定）',
      '关灯前写一句“今日结束语”（1分钟）',
      '上床后只做呼吸/身体扫描（不刷信息）',
    ],
    obstacles: ['停不下刷手机', '焦虑/脑子停不下'],
    changePath: ['把手机充电器放到客厅', '给“刷手机”设定替代行为：听白噪音', '晚间减少咖啡因/刺激内容'],
    learning: ['习惯回路', '刺激控制', '替代行为'],
  ),
  _t(
    id: 'builtin_fast_walk',
    title: '10分钟快走（行为激活）',
    category: '日常生活/健康/运动',
    mode: ActionMode.free,
    concept: '行为激活（先做再好转）',
    conceptDef: '情绪常常在行动之后改善；通过小强度运动提升能量与掌控感。',
    opDef: '10分钟内完成持续步行，能说话但略微喘；结束后记录体感评分。',
    checklist: [
      '穿鞋出门/在室内走动也算',
      '计时10分钟，保持稳定速度',
      '结束后喝一口水',
      '记录：能量/心情 1-5 分',
    ],
    obstacles: ['懒得动', '天气/场地不方便'],
    changePath: ['先走2分钟再决定是否继续', '室内原地踏步也算', '把运动鞋放在门口'],
    learning: ['行为激活', '强化'],
  ),
  _t(
    id: 'builtin_box_breath',
    title: '1分钟方块呼吸（情绪降温）',
    category: '日常生活/情绪/自我调节',
    mode: ActionMode.free,
    concept: '情绪调节（降低生理唤醒）',
    conceptDef: '先让身体降温，认知才更容易回到可用状态。',
    opDef: '进行 4-4-4-4 呼吸（吸4秒/停4秒/呼4秒/停4秒），至少完成4轮。',
    checklist: [
      '坐稳/站稳，放松肩膀',
      '吸气4秒',
      '屏息4秒',
      '呼气4秒',
      '停4秒，重复4轮',
    ],
    obstacles: ['觉得没用', '呼吸不顺'],
    changePath: ['把目标改成“做满1分钟”', '呼吸不顺就缩短到2秒'],
    learning: ['生理调节', '情绪技能'],
  ),

  // -------------------- Work --------------------
  _t(
    id: 'builtin_pomodoro',
    title: '25分钟深度工作块（单任务）',
    category: '工作/效率/专注',
    mode: ActionMode.plan,
    concept: '深度工作块（单任务专注）',
    conceptDef: '专注是行为：在一段时间里只做一件事，并持续把注意力拉回。',
    opDef: '25分钟内只处理一个任务，结束时产出一个可见成果（文档/提交/清单项）。',
    goalHint: '写下你要关联的目标（例如：本周完成XX），以及衡量指标（例如：完成清单项数）。',
    checklist: [
      '写下本次唯一任务（一句话）',
      '清空桌面/关闭通知（最少移除1个干扰）',
      '计时25分钟：只做这一件事',
      '结束写下：产出了什么（哪怕很小）',
      '休息5分钟（走动/喝水）',
    ],
    obstacles: ['被消息打断', '任务太大不知道从哪开始'],
    changePath: ['把任务改成“下一步动作”', '把手机放远', '设定“打断记录”稍后处理'],
    learning: ['时间盒', '刺激控制', '强化'],
  ),
  _t(
    id: 'builtin_work_request',
    title: '工作沟通：具体请求一条消息',
    category: '工作/沟通/协作',
    mode: ActionMode.free,
    concept: '具体请求（把需求落到行动层）',
    conceptDef: '把“抱怨/情绪”转成“对方可执行的动作”，降低误会与冲突。',
    opDef: '用一句话包含：情境+影响+你需要什么+具体请求（时间/行为）。',
    checklist: [
      '写清情境：发生了什么（客观）',
      '写清影响：对进度/质量有什么影响',
      '写清需要：你想解决什么',
      '写清请求：请对方在何时做什么',
      '发出后等待对方确认（是/否/改时间）',
    ],
    obstacles: ['怕冒犯', '说不清需求'],
    changePath: ['先写草稿再发', '用“我需要…”而不是“你总是…”', '给出两个可选时间点'],
    learning: ['非暴力沟通', '行为描述'],
  ),

  // -------------------- School / Study --------------------
  _t(
    id: 'builtin_study_review',
    title: '学习复盘卡：一页纸复习',
    category: '学校/学习/复习',
    mode: ActionMode.free,
    concept: '提取练习（用回忆强化记忆）',
    conceptDef: '与其反复看，不如尝试回忆；回忆会暴露薄弱点并强化记忆。',
    opDef: '不看资料写出：3个要点 + 1个例题/例子 + 1个不会点；总计10分钟内完成。',
    checklist: [
      '拿一张纸/打开笔记',
      '不看资料写出3个要点',
      '写出1个例题/例子',
      '标记1个不会点',
      '用2分钟补齐不会点并写一句总结',
    ],
    obstacles: ['一开始写不出来', '焦虑'],
    changePath: ['先写标题/框架', '把不会点当作“地图”', '从最简单的例子开始'],
    learning: ['提取练习', '间隔复习'],
  ),

  // -------------------- Family --------------------
  _t(
    id: 'builtin_family_time',
    title: '20分钟高质量陪伴（家庭/亲子）',
    category: '家庭/亲子/陪伴',
    mode: ActionMode.plan,
    concept: '高质量陪伴（强化关系连接）',
    conceptDef: '关系靠“共同注意力”与“积极互动”累积，而不是靠说教。',
    opDef: '20分钟内做到：不刷手机 + 由对方选择活动 + 你给出积极回应（至少3次）。',
    goalHint: '写下你想建立的关系目标（例如：每周3次高质量陪伴）。',
    checklist: [
      '提前说：我们有20分钟一起玩/聊',
      '把手机放远（或开飞行）',
      '让对方选择活动（玩/聊/散步）',
      '至少3次积极回应（点头/复述/赞同）',
      '结束时说一句感谢/欣赏',
    ],
    obstacles: ['容易分心', '时间被打断'],
    changePath: ['把时间缩小到10分钟', '设定固定时段', '提前告知其他人不要打断'],
    learning: ['正向强化', '共同注意力'],
  ),

  // -------------------- Love --------------------
  _t(
    id: 'builtin_nvc',
    title: '沟通四句式（把情绪变成请求）',
    category: '人际关系/沟通/表达',
    mode: ActionMode.free,
    concept: '非暴力沟通（观察-感受-需要-请求）',
    conceptDef: '用可验证的观察替代评判，用具体请求替代指责。',
    opDef: '一句话结构：当我看到/听到X（具体事实）→ 我感到Y（情绪词）→ 因为我需要Z（需要）→ 你愿意在T前做A吗？（具体行为）',
    checklist: [
      '写下事实：发生了什么（不评价）',
      '写下感受：用情绪词（不指责）',
      '写下需要：你在乎什么',
      '写下请求：对方能做的一个具体动作',
      '发出请求并允许对方协商',
    ],
    obstacles: ['忍不住指责', '把需要说成要求'],
    changePath: ['先写下来再说', '把“你应该”换成“你愿意吗”', '请求要具体且可拒绝'],
    learning: ['沟通技能', '情绪调节'],
  ),
  _t(
    id: 'builtin_repair',
    title: '冲突后修复对话（10分钟）',
    category: '爱情/沟通/修复',
    mode: ActionMode.free,
    concept: '关系修复（承认影响 + 共同计划）',
    conceptDef: '修复不是争对错，而是承认伤害、恢复安全感并达成下一次的做法。',
    opDef: '对话必须包含：承认影响（1句）+ 道歉（1句）+ 未来具体行动（1句）。总计<=10分钟。',
    checklist: [
      '说一句：我刚才的行为对你造成了什么影响',
      '说一句：对不起（不带“但是”）',
      '问一句：你希望我下次怎么做（具体）',
      '给一句：我下次会做A（可执行）',
      '结束一句：谢谢你告诉我',
    ],
    obstacles: ['拉扯对错', '情绪升级'],
    changePath: ['先做1分钟呼吸', '约定暂停词', '把目标改成“修复”不是“赢”'],
    learning: ['关系修复', '情绪技能'],
  ),
  _t(
    id: 'builtin_love_appreciation',
    title: '伴侣欣赏记录（每天1条）',
    category: '爱情/关系/经营',
    mode: ActionMode.plan,
    concept: '积极强化（让好行为更常发生）',
    conceptDef: '关系里的好行为需要被看见和强化，否则会被默认。',
    opDef: '每天记录并表达1条具体欣赏：行为 + 影响 + 感受。',
    goalHint: '写下你要坚持的周期（例如：连续14天）。',
    checklist: [
      '回忆今天对方做的一件具体事',
      '写一句：我看到你做了A',
      '写一句：这让我感到B/对我有C影响',
      '把这句话说给对方（或发消息）',
    ],
    obstacles: ['觉得尴尬', '想不起来'],
    changePath: ['从小事开始', '把欣赏写成“感谢”', '每天固定时间提醒'],
    learning: ['正向强化', '关系经营'],
  ),

  // -------------------- Social boundary --------------------
  _t(
    id: 'builtin_refuse',
    title: '礼貌拒绝（保护边界）',
    category: '人际关系/边界/拒绝',
    mode: ActionMode.free,
    concept: '边界表达（清晰 + 尊重）',
    conceptDef: '拒绝不是攻击，而是对资源与角色的清晰管理。',
    opDef: '回复必须包含：感谢/理解 + 明确拒绝 + 可选替代（可有可无）。',
    checklist: [
      '先感谢/理解：谢谢你想到我',
      '明确拒绝：这次我做不了/我不方便',
      '给出替代（可选）：我可以推荐X/下周再看',
      '不解释过多，不辩论',
    ],
    obstacles: ['内疚', '怕关系变差'],
    changePath: ['先写草稿', '把拒绝当作“信息”不是“评价”', '用替代方案降低对方损失'],
    learning: ['边界技能', '社交技巧'],
  ),

  // -------------------- Habit / change --------------------
  _t(
    id: 'builtin_phone_replace',
    title: '刷手机替代路径（3步）',
    category: '改变/不良习惯/手机',
    mode: ActionMode.plan,
    concept: '替代行为（用新行为取代旧习惯）',
    conceptDef: '习惯很少靠“压制”消失，更多靠“替代 + 环境”重写。',
    opDef: '当出现“想刷”的冲动时，执行：暂停10秒 → 做替代行为1分钟 → 再决定是否刷。',
    goalHint: '写下你想减少的信息流时间（例如：每天<60分钟），以及衡量方式（屏幕使用时长）。',
    checklist: [
      '冲动出现：停10秒，做一次深呼吸',
      '立刻做替代行为1分钟（伸展/喝水/整理/走动）',
      '再决定：如果要刷，设定5分钟计时并到点停',
      '记录一次：冲动强度 1-5 分',
    ],
    obstacles: ['冲动太强', '环境线索太多'],
    changePath: ['把手机放远', '移除信息流App快捷入口', '把替代行为提前摆好（书/水杯/拉伸垫）'],
    learning: ['习惯回路', '替代行为', '强化'],
  ),
];

List<String> builtInCategoryPaths() {
  final set = <String>{};
  for (final t in builtInActionTemplates) {
    final p = t.categoryPath.trim();
    if (p.isNotEmpty) set.add(p);
  }
  final list = set.toList()..sort();
  return list;
}

ActionTemplate _t({
  required String id,
  required String title,
  required String category,
  required ActionMode mode,
  required String concept,
  required String conceptDef,
  required String opDef,
  required List<String> checklist,
  String goalHint = '',
  List<String> obstacles = const [],
  List<String> changePath = const [],
  List<String> learning = const [],
}) {
  final steps = <ActionStep>[];
  steps.add(ActionStep(
    id: '${id}_concept',
    type: ActionStepType.info,
    title: '概念与定义',
    body: '**概念：$concept**\n\n$conceptDef\n\n**操作化定义（现实可观察指标）**\n$opDef',
    required: false,
  ));
  if (mode == ActionMode.plan) {
    steps.add(ActionStep(
      id: '${id}_goal',
      type: ActionStepType.input,
      title: '关联目标（计划模式）',
      body: goalHint.trim().isEmpty
          ? '写下你要关联的目标（未来会接入目标模块）。\n\n格式建议：目标一句话 + 截止时间 + 衡量指标。'
          : goalHint.trim(),
      hint: '例如：4周内把睡眠稳定到23:30入睡；用“连续天数”衡量。',
    ));
  }

  steps.add(ActionStep(
    id: '${id}_check',
    type: ActionStepType.checklist,
    title: '行动清单（可勾选）',
    body: '按照清单逐项完成。做不到也没关系，记录阻力即可。',
    checklist: checklist,
  ));

  steps.addAll(_evalSteps(id));

  return ActionTemplate(
    id: id,
    title: title,
    concept: concept,
    conceptDefinition: conceptDef,
    operationalDefinition: opDef,
    categoryPath: category,
    mode: mode,
    steps: steps,
    commonObstacles: obstacles,
    changePath: changePath,
    learningTags: learning,
    goalHint: goalHint,
  );
}

List<ActionStep> _evalSteps(String id) => [
      ActionStep(
        id: '${id}_match',
        type: ActionStepType.rating,
        title: '概念一致性评分',
        body: '你的实际行动，是否是“概念”的直观表达？\n\n提示：请对照“操作化定义/可观察指标”。',
        minRating: 1,
        maxRating: 5,
      ),
      ActionStep(
        id: '${id}_result',
        type: ActionStepType.rating,
        title: '现实结果评分',
        body: '这次行动在现实里带来了多大效果？\n\n1=几乎无变化，3=有一点点起色，5=明显改善/达成。',
        minRating: 1,
        maxRating: 5,
      ),
      ActionStep(
        id: '${id}_obstacle',
        type: ActionStepType.input,
        title: '遇到的困难（用于失败模块/改进）',
        body: '写下你遇到的阻力、挫折或失败点。没有也可以写“无”。',
        hint: '例如：手机干扰；情绪低落；时间不够；他人不配合…',
        required: false,
      ),
      ActionStep(
        id: '${id}_next',
        type: ActionStepType.input,
        title: '下一次的更小动作',
        body: '把下一次的行动缩小到“再怎么不想也做得到”的程度。',
        hint: '例如：只做2分钟；只准备材料；只开个头…',
        required: false,
      ),
      ActionStep(
        id: '${id}_summary',
        type: ActionStepType.summary,
        title: '完成',
        body: '你已经完成一次“概念→现实”的落地。\n\n建议：把“下一次的更小动作”设成提醒或加入计划。',
        required: false,
      ),
    ];
