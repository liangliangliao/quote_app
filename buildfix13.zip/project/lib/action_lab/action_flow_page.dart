import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:quote_app/action_lab/action_dao.dart';
import 'package:quote_app/action_lab/action_models.dart';

class ActionFlowPage extends StatefulWidget {
  final String runId;
  const ActionFlowPage({super.key, required this.runId});

  @override
  State<ActionFlowPage> createState() => _ActionFlowPageState();
}

class _ActionFlowPageState extends State<ActionFlowPage> {
  final _dao = ActionDao();

  bool _loading = true;
  String? _err;

  ActionRun? _run;
  ActionTemplate? _tpl;

  int _idx = 0;
  final Map<String, dynamic> _ans = {};
  final Map<String, TextEditingController> _textCtrls = {};

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    for (final c in _textCtrls.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _init() async {
    try {
      final run = await _dao.getRun(widget.runId);
      if (run == null) throw Exception('Run not found');
      final tpl = run.templateSnapshot;
      if (tpl == null) throw Exception('Template snapshot parse failed');

      _idx = run.idx;
      _ans.clear();
      _ans.addAll(run.ans);
      _primeControllers(tpl);

      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = null;
        _run = run;
        _tpl = tpl;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _err = e.toString();
      });
    }
  }

  void _primeControllers(ActionTemplate tpl) {
    for (final s in tpl.steps) {
      if (s.type == ActionStepType.input) {
        final k = s.id;
        _textCtrls.putIfAbsent(k, () => TextEditingController(text: (_ans[k] ?? '').toString()));
        _textCtrls[k]!.text = (_ans[k] ?? '').toString();
      }
    }
  }

  Future<void> _saveProgress() async {
    // sync text
    for (final e in _textCtrls.entries) {
      _ans[e.key] = e.value.text;
    }
    await _dao.saveRunProgress(runId: widget.runId, idx: _idx, ans: _ans);
  }

  ActionStep get _step => _tpl!.steps[_idx];

  bool _isStepComplete(ActionStep s) {
    if (!s.required) return true;
    final v = _ans[s.id];
    switch (s.type) {
      case ActionStepType.info:
      case ActionStepType.summary:
        return true;
      case ActionStepType.input:
        return (v ?? '').toString().trim().isNotEmpty;
      case ActionStepType.checklist:
        if (s.checklist.isEmpty) return true;
        if (v is List) return v.isNotEmpty;
        return false;
      case ActionStepType.rating:
        final n = (v is num) ? v.toInt() : int.tryParse((v ?? '').toString());
        return n != null;
    }
  }

  Future<void> _next() async {
    final s = _step;
    if (!_isStepComplete(s)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先完成当前步骤（或填写必要项）')));
      return;
    }
    await _saveProgress();
    if (!mounted) return;
    if (_idx < _tpl!.steps.length - 1) {
      setState(() => _idx++);
      await _saveProgress();
    } else {
      await _finish(success: true);
    }
  }

  Future<void> _back() async {
    if (_idx <= 0) return;
    await _saveProgress();
    if (!mounted) return;
    setState(() => _idx--);
  }

  Future<void> _finish({required bool success, String? failReason}) async {
    await _saveProgress();

    // 收集 eval：优先用评分字段。
    final eval = <String, dynamic>{};
    final tpl = _tpl!;

    int? _intAns(String id) {
      final v = _ans[id];
      if (v is num) return v.toInt();
      return int.tryParse((v ?? '').toString());
    }

    eval['concept_match'] = _intAns('${tpl.id}_match');
    eval['result_score'] = _intAns('${tpl.id}_result');
    eval['obstacle_text'] = (_ans['${tpl.id}_obstacle'] ?? '').toString();
    eval['next_action'] = (_ans['${tpl.id}_next'] ?? '').toString();
    if (!success) {
      eval['fail_reason'] = failReason ?? '';
    }

    await _dao.finishRun(runId: widget.runId, success: success, eval: eval);

    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(success ? '已完成' : '已标记失败'),
        content: Text(success
            ? '已记录一致性与结果评分。\n\n如果你遇到困难，可以在历史中回看“阻力”并做下一次更小动作。'
            : '失败不是问题；不复盘才是问题。\n\n已记录失败原因与阻力（未来可跳转到失败模块做复盘）。'),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(_), child: const Text('好的')),
        ],
      ),
    );

    if (!mounted) return;
    Navigator.pop(context);
  }

  Future<void> _markFailed() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('标记失败/中断'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('写下失败原因/阻力（会用于后续失败模块 & 改进路径）。'),
            const SizedBox(height: 10),
            TextField(
              controller: c,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: '例如：情绪崩了；外部打断；计划过大；环境不支持…',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(_, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(_, true), child: const Text('标记失败')),
        ],
      ),
    );
    if (ok != true) return;
    final reason = c.text.trim();
    await _finish(success: false, failReason: reason);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_err != null) {
      return Scaffold(appBar: AppBar(title: const Text('行动')), body: Center(child: Text('加载失败：$_err')));
    }

    final tpl = _tpl!;
    final total = tpl.steps.length;
    final s = _step;
    final progressText = '${_idx + 1} / $total';

    return Scaffold(
      appBar: AppBar(
        title: Text(tpl.title),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Text(progressText, style: TextStyle(color: Colors.black.withOpacity(0.7))),
            ),
          ),
          IconButton(
            tooltip: '标记失败',
            onPressed: _markFailed,
            icon: const Icon(Icons.flag_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 80),
        children: [
          _stepCard(s),
          const SizedBox(height: 14),
          LinearProgressIndicator(value: (_idx + 1) / total),
        ],
      ),
      bottomSheet: SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 12),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(top: BorderSide(color: Colors.black.withOpacity(0.06))),
          ),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _idx > 0 ? _back : null,
                  child: const Text('上一步'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: _next,
                  child: Text(_idx == total - 1 ? '完成' : '下一步'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _stepCard(ActionStep s) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(s.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (s.body.trim().isNotEmpty)
            Text(s.body, style: TextStyle(color: Colors.black.withOpacity(0.75), height: 1.35)),
          const SizedBox(height: 12),
          _stepInput(s),
        ],
      ),
    );
  }

  Widget _stepInput(ActionStep s) {
    switch (s.type) {
      case ActionStepType.info:
      case ActionStepType.summary:
        return const SizedBox.shrink();
      case ActionStepType.input:
        final c = _textCtrls[s.id]!;
        return TextField(
          controller: c,
          maxLines: 6,
          decoration: InputDecoration(
            hintText: s.hint.isEmpty ? '写在这里…' : s.hint,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onChanged: (_) {
            _ans[s.id] = c.text;
          },
        );
      case ActionStepType.checklist:
        final raw = _ans[s.id];
        final checked = <int>{};
        if (raw is List) {
          for (final x in raw) {
            final n = (x is num) ? x.toInt() : int.tryParse(x.toString());
            if (n != null) checked.add(n);
          }
        }
        return Column(
          children: [
            ...List.generate(s.checklist.length, (i) {
              final txt = s.checklist[i];
              final on = checked.contains(i);
              return CheckboxListTile(
                value: on,
                title: Text(txt),
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.leading,
                onChanged: (v) {
                  setState(() {
                    if (v == true) {
                      checked.add(i);
                    } else {
                      checked.remove(i);
                    }
                    _ans[s.id] = checked.toList()..sort();
                  });
                },
              );
            }),
          ],
        );
      case ActionStepType.rating:
        final raw = _ans[s.id];
        int v = (raw is num) ? raw.toInt() : int.tryParse((raw ?? '').toString()) ?? ((s.minRating + s.maxRating) ~/ 2);
        v = v.clamp(s.minRating, s.maxRating);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('评分：$v', style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('${s.minRating}~${s.maxRating}', style: TextStyle(color: Colors.black.withOpacity(0.6))),
              ],
            ),
            Slider(
              value: v.toDouble(),
              min: s.minRating.toDouble(),
              max: s.maxRating.toDouble(),
              divisions: (s.maxRating - s.minRating) <= 0 ? 1 : (s.maxRating - s.minRating),
              label: v.toString(),
              onChanged: (nv) {
                setState(() {
                  final vv = nv.round().clamp(s.minRating, s.maxRating);
                  _ans[s.id] = vv;
                });
              },
            ),
          ],
        );
    }
  }
}
