// Re-export shim to avoid duplicate class definitions.
// The canonical SimpleBus lives in services/native_guard.dart
export '../services/native_guard.dart' show SimpleBus, NativeGuard;