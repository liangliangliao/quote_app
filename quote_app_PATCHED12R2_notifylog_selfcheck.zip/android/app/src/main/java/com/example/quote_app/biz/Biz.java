package com.example.quote_app.biz;

import android.content.Context;
import android.text.TextUtils;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.data.DbRepository.Task;

import java.util.List;

public final class Biz {
    private Biz() {}

    /** 主入口：根据任务类型执行并发送通知；返回是否已处理 */
    public static boolean run(Context ctx, String uid) {
        Task t = DbRepository.getTaskByUid(ctx, uid);
        if (t == null || !t.enabled) {
            DbRepository.log(ctx, uid, "任务关闭或不存在，跳过");
            return false;
        }
        String type = t.type == null ? "MANUAL" : t.type.toUpperCase();
        switch (type) {
            case "AUTO":
                return autoTask(ctx, t);
            case "CAROUSEL":
                return carouselTask(ctx, t);
            default:
                return manualTask(ctx, t);
        }
    }

    private static boolean manualTask(Context ctx, Task t) {
        String content = t.content;
        String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
        int id = t.uid != null ? t.uid.hashCode() : 10001;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, t.avatarPath);
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "发送失败: " + e.getMessage());
            return false;
        }
    }

    private static boolean carouselTask(Context ctx, Task t) {
        String content = DbRepository.getCarouselNextQuote(ctx, t.uid);
        if (TextUtils.isEmpty(content)) content = t.content;
        String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
        int id = t.uid != null ? t.uid.hashCode() : 10003;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, t.avatarPath);
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "发送失败: " + e.getMessage());
            return false;
        }
    }

    private static boolean autoTask(Context ctx, Task t) {
        // 简化：此处不直接联网上游 API，先用任务内容或最近一条名言回退
        String content = null;
        List<String> recent = DbRepository.listQuoteTextsForTask(ctx, t.uid, 1);
        if (!recent.isEmpty()) content = recent.get(0);
        if (TextUtils.isEmpty(content)) content = t.content;
        String title = !TextUtils.isEmpty(t.title) ? t.title : "提醒";
        int id = t.uid != null ? t.uid.hashCode() : 10002;
        try {
            NotifyHelper.send(ctx.getApplicationContext(), id, title, content, t.avatarPath);
            DbRepository.log(ctx, t.uid, "成功!");
            return true;
        } catch (Throwable e) {
            DbRepository.log(ctx, t.uid, "发送失败: " + e.getMessage());
            return false;
        }
    }
}
