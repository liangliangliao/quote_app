package com.example.quote_app.am

import android.content.Context
import java.io.File

object DbPaths {
    fun quotesDbPath(context: Context): String {
        val appFlutterDir = File(context.filesDir, "../app_flutter").canonicalFile
        return File(appFlutterDir, "quotes.db").absolutePath
    }
}
