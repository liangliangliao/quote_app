import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../data/emotions.dart';

/// 发现之旅：展示当天的心情状态与时间轴
class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});

  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _EsteemPoint {
  final DateTime time;
  final double score;
  const _EsteemPoint({required this.time, required this.score});
}

class _EmotionLegendEntry {
  final String name;
  final double percent;
  final Color color;

  const _EmotionLegendEntry({
    required this.name,
    required this.percent,
    required this.color,
  });
}

class _DiscoverPageState extends State<DiscoverPage> {
  Map<String, dynamic>? _latestToday;
  List<Map<String, dynamic>> _todayList = [];
  bool _loading = false;

  // 自尊分析相关状态
  String _esteemRangeKey = 'today'; // 时间范围：today / 7d / 30d
  String _esteemGranularityKey = 'record'; // record / hour / day
  List<Map<String, dynamic>> _esteemList = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
    });
    try {
      final dao = EmotionDao();
      final latest = await dao.latestToday();
      final list = await dao.listTodayOrdered();

      // 默认用“今天 + 单次记录粒度”作为自尊分析的初始数据
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final esteemRows = await dao.listByRange(start, now);

      if (!mounted) return;
      setState(() {
        _latestToday = latest;
        _todayList = list;
        _esteemList = esteemRows;
      });
    } catch (_) {
      if (!mounted) return;
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  /// 根据当前选择的时间范围重新加载自尊分析数据
  Future<void> _reloadEsteemByFilter() async {
    final dao = EmotionDao();
    final now = DateTime.now();
    DateTime start;
    switch (_esteemRangeKey) {
      case '7d':
        start = now.subtract(const Duration(days: 7));
        break;
      case '30d':
        start = now.subtract(const Duration(days: 30));
        break;
      case 'today':
      default:
        start = DateTime(now.year, now.month, now.day);
        break;
    }

    final rows = await dao.listByRange(start, now);
    if (!mounted) return;
    setState(() {
      _esteemList = rows;
    });
  }




  List<double> _rawEsteemScores() {
    if (_esteemList.isEmpty) return const <double>[];
    return _esteemList.map<double>((row) {
      final name = (row['emoji_name'] ?? '').toString();
      return estimateSelfEsteemScore(name);
    }).toList();
  }

  Map<String, List<int>> _computeEsteemStats(List<double> scores) {
    // 统计每一个“整数自尊值”在当前时间范围内出现的频率，
    // 然后按照占比区间划分到 50% / 60% / 70% / 80% / 90% 档位。
    final Map<String, List<int>> result = <String, List<int>>{
      '50': <int>[],
      '60': <int>[],
      '70': <int>[],
      '80': <int>[],
      '90': <int>[],
    };

    if (scores.isEmpty) {
      return result;
    }

    // 先统计每一个整数自尊得分出现的次数
    final Map<int, int> countByScore = <int, int>{};
    for (final s in scores) {
      final int v = s.round(); // 0~100
      if (v < 0 || v > 100) continue;
      countByScore[v] = (countByScore[v] ?? 0) + 1;
    }

    final int total = scores.length;
    if (total == 0) {
      return result;
    }

    // 将每个分数按照它在全部记录中所占的百分比分配到对应档位
    countByScore.forEach((int score, int count) {
      final double p = (count * 100.0) / total;

      // 小于 50% 的自尊水平不统计
      if (p < 50.0) {
        return;
      } else if (p >= 50.0 && p < 60.0) {
        result['50']!.add(score);
      } else if (p >= 60.0 && p < 70.0) {
        result['60']!.add(score);
      } else if (p >= 70.0 && p < 80.0) {
        result['70']!.add(score);
      } else if (p >= 80.0 && p < 90.0) {
        result['80']!.add(score);
      } else if (p >= 90.0 && p <= 100.0) {
        // 大于等于 90% 且小于等于 100%
        result['90']!.add(score);
      }
    });

    // 为了展示稳定一些，对每个档位里的自尊分数做一次排序。
    for (final key in result.keys) {
      result[key]!.sort();
    }

    return result;
  }

  
  Map<String, double> _computeBasicEsteemStats(List<double> scores) {
    if (scores.isEmpty) {
      return <String, double>{
        'min': double.nan,
        'max': double.nan,
        'avg': double.nan,
        'mid': double.nan,
      };
    }

    // 将自尊得分统一映射为 0~100 的整数，并排序，便于统计最小值 / 最大值 / 中间值 / 平均值。
    final List<int> intScores = scores
        .map((s) => s.round().clamp(0, 100))
        .toList()
      ..sort();

    final int minScore = intScores.first;
    final int maxScore = intScores.last;

    final int sum = intScores.fold<int>(0, (a, b) => a + b);
    final double avgScore = sum / intScores.length;

    double midScore;
    if (intScores.length.isOdd) {
      midScore = intScores[intScores.length ~/ 2].toDouble();
    } else {
      final int left = intScores[intScores.length ~/ 2 - 1];
      final int right = intScores[intScores.length ~/ 2];
      midScore = (left + right) / 2.0;
    }

    return <String, double>{
      'min': minScore.toDouble(),
      'max': maxScore.toDouble(),
      'avg': avgScore,
      'mid': midScore,
    };
  }

DateTime? _parseInsertedAt(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return null;
    try {
      return DateTime.parse(insertedAt);
    } catch (_) {
      return null;
    }
  }

  /// 根据当前选择的粒度构建自尊曲线数据点。
  List<_EsteemPoint> _buildEsteemPoints() {
    if (_esteemList.isEmpty) return const <_EsteemPoint>[];

    // 逐条记录：直接按照每条记录的情绪计算自尊指数
    if (_esteemGranularityKey == 'record') {
      final List<_EsteemPoint> points = [];
      for (final row in _esteemList) {
        final dt = _parseInsertedAt(row['inserted_at']?.toString()) ?? DateTime.now();
        final name = (row['emoji_name'] ?? '').toString();
        final score = estimateSelfEsteemScore(name);
        points.add(_EsteemPoint(time: dt, score: score));
      }
      points.sort((a, b) => a.time.compareTo(b.time));
      return points;
    }

    // 按小时 / 按天聚合：在时间窗内收集所有情绪名称，用 computeSelfEsteemIndexFromEmotions 算出该时间窗的自尊指数
    final Map<String, List<String>> bucketNames = {};
    final Map<String, DateTime> bucketTime = {};

    for (final row in _esteemList) {
      final dt = _parseInsertedAt(row['inserted_at']?.toString());
      if (dt == null) continue;

      DateTime bucket;
      if (_esteemGranularityKey == 'day') {
        bucket = DateTime(dt.year, dt.month, dt.day);
      } else {
        bucket = DateTime(dt.year, dt.month, dt.day, dt.hour);
      }
      final key = bucket.toIso8601String();
      final name = (row['emoji_name'] ?? '').toString();
      if (name.isEmpty) continue;

      bucketNames.putIfAbsent(key, () => <String>[]).add(name);
      bucketTime[key] = bucket;
    }

    final keys = bucketNames.keys.toList()
      ..sort((a, b) => bucketTime[a]!.compareTo(bucketTime[b]!));

    final List<_EsteemPoint> points = [];
    for (final key in keys) {
      final names = bucketNames[key]!;
      if (names.isEmpty) continue;
      final score = computeSelfEsteemIndexFromEmotions(names);
      points.add(_EsteemPoint(time: bucketTime[key]!, score: score));
    }

    points.sort((a, b) => a.time.compareTo(b.time));
    return points;
  }

  String _formatTime(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return '';
    // 期望格式：YYYY-MM-DD HH:mm:ss
    final parts = insertedAt.split(' ');
    if (parts.length < 2) return insertedAt;
    return parts[1];
  }

  List<List<Map<String, dynamic>>> _chunkEmotions(List<Map<String, dynamic>> src, int size) {
    if (src.isEmpty) return <List<Map<String, dynamic>>>[];
    final List<List<Map<String, dynamic>>> rows = [];
    for (var i = 0; i < src.length; i += size) {
      final end = (i + size < src.length) ? i + size : src.length;
      rows.add(src.sublist(i, end));
    }
    return rows;
  }

  Widget _buildTimelineRow(List<Map<String, dynamic>> rowItems) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 时间轴横线 + 表情在上方
          SizedBox(
            height: 36,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned.fill(
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      height: 1,
                      color: Colors.black26,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    for (final item in rowItems)
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Text(
                              (item['emoji_char'] ?? '').toString(),
                              style: const TextStyle(fontSize: 22),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          // 时间显示在横线下方
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              for (final item in rowItems)
                Text(
                  _formatTime(item['inserted_at']?.toString()),
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.black54,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTimeline(List<Map<String, dynamic>> items) {
    if (items.isEmpty) {
      return const Text(
        '今天还没有记录心情，回到首页试试分享你的此时此刻吧～',
        style: TextStyle(fontSize: 13, color: Colors.black54),
      );
    }
    final rows = _chunkEmotions(items, 4);
    // 计算是否需要垂直滚动：超过 3 行时开启
    final bool needScroll = rows.length > 3;

    final timelineColumn = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final r in rows) _buildTimelineRow(r),
      ],
    );

    if (!needScroll) {
      return timelineColumn;
    } else {
      return SizedBox(
        // 每行高度约 56 左右，3 行 + 边距
        height: 56.0 * 3,
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: timelineColumn,
        ),
      );
    }
  }



  Widget _buildEsteemFilterBar() {
    return Row(
      children: [
        Expanded(
          child: DropdownButton<String>(
            value: _esteemRangeKey,
            isExpanded: true,
            items: const [
              DropdownMenuItem(
                value: 'today',
                child: Text('今天'),
              ),
              DropdownMenuItem(
                value: '7d',
                child: Text('近7天'),
              ),
              DropdownMenuItem(
                value: '30d',
                child: Text('近30天'),
              ),
            ],
            onChanged: (value) {
              if (value == null) return;
              setState(() {
                _esteemRangeKey = value;
              });
              _reloadEsteemByFilter();
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: DropdownButton<String>(
            value: _esteemGranularityKey,
            isExpanded: true,
            items: const [
              DropdownMenuItem(
                value: 'record',
                child: Text('逐条记录'),
              ),
              DropdownMenuItem(
                value: 'hour',
                child: Text('按小时'),
              ),
              DropdownMenuItem(
                value: 'day',
                child: Text('按天'),
              ),
            ],
            onChanged: (value) {
              if (value == null) return;
              setState(() {
                _esteemGranularityKey = value;
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _buildEsteemLineChart() {
    final points = _buildEsteemPoints();
    if (points.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final spots = <FlSpot>[];
    for (var i = 0; i < points.length; i++) {
      spots.add(FlSpot(i.toDouble(), points[i].score));
    }

    double minY = points.first.score;
    double maxY = points.first.score;
    for (final p in points) {
      if (p.score < minY) minY = p.score;
      if (p.score > maxY) maxY = p.score;
    }
    double yMin = (minY - 5).clamp(0, 100).toDouble();
    double yMax = (maxY + 5).clamp(0, 100).toDouble();
    if (yMax <= yMin) {
      yMax = (yMin + 10).clamp(0, 100).toDouble();
    }

    final double yRange = (yMax - yMin).abs();
    final double yInterval =
        yRange <= 0 ? 10 : (yRange / 4).clamp(2, 25);


    String formatBottomLabel(int index) {
      if (index < 0 || index >= points.length) return '';
      final t = points[index].time;
      if (_esteemGranularityKey == 'day') {
        // 仅显示月-日，保持简洁。
        return '${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      } else {
        // 小时粒度或更细时统一使用 HH:mm，避免过长的时间字符串被截断。
        return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
      }
    }

    return SizedBox(
      height: 220,
      child: LineChart(
        LineChartData(
          // 向左右各扩展一点，避免首尾标签被裁剪
          minX: -0.5,
          maxX: (points.length - 1).toDouble() + 0.5,
          minY: yMin,
          maxY: yMax,
          gridData: FlGridData(show: true),
          borderData: FlBorderData(show: true),
          titlesData: FlTitlesData(
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 36,
                interval: yInterval,
                getTitlesWidget: (value, meta) {
                  // 只显示间隔为 10 的刻度文本，避免纵坐标文字过于密集重叠。
                  final int v = value.toInt();
                  if (v % 10 != 0) {
                    return const SizedBox.shrink();
                  }
                  return Text(
                    v.toString(),
                    style: const TextStyle(fontSize: 10),
                  );
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: points.length <= 6 ? 1 : (points.length / 6).ceilToDouble(),
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();
                  final label = formatBottomLabel(index);
                  if (label.isEmpty) {
                    return const SizedBox.shrink();
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      label,
                      style: const TextStyle(fontSize: 8),
                      textAlign: TextAlign.center,
                    ),
                  );
                },
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              spots: spots,
              dotData: FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEsteemStatsView() {
    final scores = _rawEsteemScores();
    if (_esteemList.isEmpty || scores.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Text(
          '当前时间范围内还没有足够的数据用于统计',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    // 使用新的频率分档统计：50% / 60% / 70% / 80% / 90%
    final Map<String, List<int>> buckets = _computeEsteemStats(scores);
    // 基础统计：最小值 / 中间值 / 最大值 / 平均值
    final Map<String, double> basic = _computeBasicEsteemStats(scores);

    String joinBucketValues(String key) {
      final values = buckets[key] ?? <int>[];
      if (values.isEmpty) {
        return '--';
      }
      final sorted = List<int>.from(values)..sort();
      return sorted.join('，');
    }

    String fmtDouble(double? v, int fractionDigits) {
      if (v == null || v.isNaN) return '--';
      return v.toStringAsFixed(fractionDigits);
    }

    // 更加类似 Excel 的行列布局，将所有指标放在一个表格中，支持左右滑动。
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        columnSpacing: 16,
        headingRowHeight: 32,
        dataRowMinHeight: 28,
        dataRowMaxHeight: 36,
        columns: const <DataColumn>[
          DataColumn(
            label: Text(
              '指标',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
          DataColumn(label: Text('50%')),
          DataColumn(label: Text('60%')),
          DataColumn(label: Text('70%')),
          DataColumn(label: Text('80%')),
          DataColumn(label: Text('90%')),
          DataColumn(label: Text('最小值')),
          DataColumn(label: Text('中间值')),
          DataColumn(label: Text('最大值')),
          DataColumn(label: Text('平均值')),
        ],
        rows: <DataRow>[
          DataRow(
            cells: <DataCell>[
              const DataCell(Text('自尊水平值')),
              DataCell(Text(joinBucketValues('50'))),
              DataCell(Text(joinBucketValues('60'))),
              DataCell(Text(joinBucketValues('70'))),
              DataCell(Text(joinBucketValues('80'))),
              DataCell(Text(joinBucketValues('90'))),
              DataCell(Text(fmtDouble(basic['min'], 0))),
              DataCell(Text(fmtDouble(basic['mid'], 1))),
              DataCell(Text(fmtDouble(basic['max'], 0))),
              DataCell(Text(fmtDouble(basic['avg'], 1))),
            ],
          ),
        ],
      ),
    );
  }


Widget _buildEmotionPieChart() {
    if (_esteemList.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final Map<String, int> counts = {};
    for (final row in _esteemList) {
      final name = (row['emoji_name'] ?? '').toString();
      if (name.isEmpty) continue;
      counts[name] = (counts[name] ?? 0) + 1;
    }
    if (counts.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final total = counts.values.fold<int>(0, (a, b) => a + b);
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final sections = <PieChartSectionData>[];
    final legendEntries = <_EmotionLegendEntry>[];
    const palette = <Color>[
      Color(0xFF26C6DA),
      Color(0xFFAB47BC),
      Color(0xFFFFA726),
      Color(0xFF66BB6A),
      Color(0xFFEC407A),
      Color(0xFF7E57C2),
      Color(0xFFFF7043),
      Color(0xFF29B6F6),
    ];

    for (var i = 0; i < entries.length; i++) {
      final e = entries[i];
      final double percent = total == 0 ? 0 : (e.value * 100.0 / total);
      final Color color = palette[i % palette.length];

      // 为彻底避免图中标签重叠，这里不再在扇形内部绘制文字，仅在下方图例中展示名称和百分比。
      sections.add(
        PieChartSectionData(
          color: color,
          value: e.value.toDouble(),
          title: '',
          radius: 48,
          titlePositionPercentageOffset: 0.6,
          titleStyle: const TextStyle(fontSize: 10),
        ),
      );

      legendEntries.add(
        _EmotionLegendEntry(
          name: e.key,
          percent: percent,
          color: color,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 220,
          child: PieChart(
            PieChartData(
              sections: sections,
              sectionsSpace: 2,
              centerSpaceRadius: 0,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 12,
          runSpacing: 4,
          children: legendEntries
              .map<Widget>(
                (_EmotionLegendEntry item) => Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: item.color,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${item.name} ${item.percent.toStringAsFixed(0)}%',
                      style: const TextStyle(fontSize: 11),
                    ),
                  ],
                ),
              )
              .toList(),
        ),
      ],
    );
  }

  Widget _buildEsteemAnalyticsCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7F7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '自尊分析',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          _buildEsteemFilterBar(),
          const SizedBox(height: 8),
          _buildEsteemLineChart(),
          const SizedBox(height: 8),
          _buildEsteemStatsView(),
          const SizedBox(height: 16),
          const Text(
            '自尊得分根据情绪在「正向 / 负向 + 与自尊相关程度」两维度上的加权平均得到，'
            '积极、自我肯定情绪（如自信、胜利）会提高得分，羞愧、自卑等自我意识负性情绪会拉低得分；'
            '当找不到对应情绪定义时，会使用中性得分 50。',
            style: TextStyle(fontSize: 11, color: Colors.black54),
          ),
          const SizedBox(height: 12),
          const Text(
            '情绪分布（百分比）',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          _buildEmotionPieChart(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final latest = _latestToday;
    final String moodLine;
    if (latest == null) {
      moodLine = '当下心情：今天还没有记录心情';
    } else {
      final name = (latest['emoji_name'] ?? '').toString();
      final char = (latest['emoji_char'] ?? '').toString();
      moodLine = '当下心情：$name $char';
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text(
          '发现之旅',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: _loading && _todayList.isEmpty && _latestToday == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  children: [
                    Container(
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 当下心情文本
                          Text(
                            moodLine,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          // 当天所有情绪图标 + 时间轴
                          _buildTimeline(_todayList),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildEsteemAnalyticsCard(),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.assignment_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '问卷调查',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.flag_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '愿景与目标',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.self_improvement, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '冥想',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.note_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '记事本',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}