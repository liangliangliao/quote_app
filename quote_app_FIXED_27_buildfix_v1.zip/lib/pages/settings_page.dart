import 'dart:async';
import 'package:flutter/material.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';
import '../utils/debug_logger.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _cfgDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController();

  bool _editingConfig = false;
  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _apiKeyCtrl.text = await _cfgDao.getString('api_key', '');
    _modelCtrl.text = await _cfgDao.getString('model', 'gpt-5');
    _endpointCtrl.text = await _cfgDao.getString('endpoint', '');
    _tasks = await _taskDao.all();
    if (mounted) setState((){});
  }

  Future<void> _saveConfig() async {
    await _cfgDao.setString('api_key', _apiKeyCtrl.text.trim());
    await _cfgDao.setString('model', _modelCtrl.text.trim());
    await _cfgDao.setString('endpoint', _endpointCtrl.text.trim());
    setState(()=> _editingConfig = false);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('配置已保存')));
  }

  Future<void> _toggleTaskStatus(Map<String,dynamic> t) async {
    final uid = (t['task_uid'] ?? '').toString();
    final status = (t['status'] ?? 'on').toString();
    final next = status == 'on' ? 'off' : 'on';
    await _taskDao.updateStatus(uid, next);
    await SchedulerService.cancelNextForTask(uid, includeFallback: true);
    if (next == 'on') { await SchedulerService.scheduleNextForTask(uid); }
    _tasks = await _taskDao.all();
    if (mounted) setState(() {});
  }

  Future<void> _openTaskDialog() async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('此简化版仅展示与调试，不含完整任务编辑对话框。')));
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('模型配置', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            if (!_editingConfig) IconButton(onPressed: ()=> setState(()=> _editingConfig = true), icon: const Icon(Icons.edit)),
            if (_editingConfig) IconButton(onPressed: _saveConfig, icon: const Icon(Icons.save)),
          ],
        ),
        const SizedBox(height: 8),
        TextField(controller: _apiKeyCtrl, decoration: const InputDecoration(labelText: 'API Key'), enabled: _editingConfig),
        TextField(controller: _modelCtrl, decoration: const InputDecoration(labelText: 'Model'), enabled: _editingConfig),
        TextField(controller: _endpointCtrl, decoration: const InputDecoration(labelText: 'Endpoint (可选)'), enabled: _editingConfig),
      ],
    );

    return Scaffold(
      appBar: AppBar(title: const Text('系统设置'), actions: [
        IconButton(onPressed: () async { await SchedulerService.scheduleNextForAll(); }, icon: const Icon(Icons.refresh)),
      ]),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            cfgFields,
            const SizedBox(height: 16),
            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final t in _tasks)
              ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                title: Text((t['name'] ?? '') as String),
                subtitle: Text('类型: ${(t['type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}  时间: ${(t['start_time'] ?? '') as String}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(onPressed: () => SchedulerService.scheduleNextForTask((t['task_uid'] ?? '').toString()), child: const Text('续排')),
                    TextButton(onPressed: () => SchedulerService.cancelNextForTask((t['task_uid'] ?? '').toString(), includeFallback: true), child: const Text('取消')),
                    IconButton(onPressed: ()=> _toggleTaskStatus(t), icon: const Icon(Icons.power_settings_new)),
                  ],
                ),
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openTaskDialog,
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}
