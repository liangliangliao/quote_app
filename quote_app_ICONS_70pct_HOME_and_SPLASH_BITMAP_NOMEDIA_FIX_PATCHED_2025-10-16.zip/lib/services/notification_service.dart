import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    // Initialize the notifications plugin and explicitly handle notification taps.
    // Providing an onDidReceiveNotificationResponse callback prevents the plugin
    // from performing any default navigation when a notification is tapped.
    // We intentionally leave the callback empty to simply resume the app to its
    // previous state rather than always navigating to the home page.  Without
    // this callback the plugin may create a new activity which resets the
    // navigation stack, causing the app to open on the home tab.
    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        // Do nothing here; letting the app resume to whatever page it was on.
        return;
      },
    );

    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      try { await (android as dynamic).requestNotificationsPermission(); } catch (_) { try { await (android as dynamic).requestPermission(); } catch (_) {} }
      const AndroidNotificationChannel channel = AndroidNotificationChannel(
        'quote_high', '定时提醒',
        description: 'Quote 定时提醒',
        importance: Importance.high,
        playSound: true,
      );
      await android.createNotificationChannel(channel);
    }
  }

  static Future<void> request() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      try { await (android as dynamic).requestNotificationsPermission(); } catch (_) { try { await (android as dynamic).requestPermission(); } catch (_) {} }
      await android.requestNotificationsPermission();
    }
  }

  static Future<bool> isEnabled() async {
    if (!Platform.isAndroid) return true;
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return true;
    return await android.areNotificationsEnabled() ?? true;
  }

  static Future<void> showSimple(String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'quote_high', '定时提醒',
        importance: Importance.high, priority: Priority.high,
      ),
    );
    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    await _plugin.show(id, title, body, details);
  }

  static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'quote_high', '定时提醒',
      channelDescription: 'Quote 定时提醒',
      importance: Importance.high,
      priority: Priority.high,
      styleInformation: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? BigPictureStyleInformation(
              FilePathAndroidBitmap(largeIconPath),
              largeIcon: FilePathAndroidBitmap(largeIconPath),
              contentTitle: title,
              summaryText: body,
            )
          : const DefaultStyleInformation(true, true),
      largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
          ? FilePathAndroidBitmap(largeIconPath)
          : null,
    );
    final details = NotificationDetails(android: androidDetails);
    final nid = id ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000);
    await _plugin.show(nid, title, body, details);
  }

}
