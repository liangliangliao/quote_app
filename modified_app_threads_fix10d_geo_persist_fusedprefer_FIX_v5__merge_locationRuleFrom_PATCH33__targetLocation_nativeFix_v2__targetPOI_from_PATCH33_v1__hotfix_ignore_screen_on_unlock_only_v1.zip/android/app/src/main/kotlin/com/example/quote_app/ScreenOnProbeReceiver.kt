package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.quote_app.data.DbRepo

/**
 * 仅用于兜底：监听 SCREEN_ON，延迟检查是否已解锁（无锁屏/智能解锁等）。
 * 只有确认“已解锁”时，才触发 UnlockWorker；否则不做任何业务。
 * 同时做 3 秒去重，避免与 USER_PRESENT 双触发。
 */
class ScreenOnProbeReceiver : BroadcastReceiver() {
  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[" + now + "] " + msg)
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  override fun onReceive(context: Context, intent: Intent?) {
    if (intent?.action != Intent.ACTION_SCREEN_ON) return
    // 根据方案：SCREEN_ON 仅表示亮屏，此处不再做任何业务触发，避免与 USER_PRESENT/USER_UNLOCKED 双触发
    try { logWithTime(context, "【解锁后台-探测】忽略 SCREEN_ON（由系统 USER_PRESENT/USER_UNLOCKED 负责触发），不再做延迟检查（回包：IGNORE_SCREEN_ON）") } catch (_: Throwable) {}
    return
  }
}
