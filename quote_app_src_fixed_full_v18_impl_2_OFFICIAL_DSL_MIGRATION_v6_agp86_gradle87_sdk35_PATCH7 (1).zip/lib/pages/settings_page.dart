
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');

  bool _configEditing = false;
  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = ((cfg['endpoint'] ?? '') as String).isNotEmpty ? cfg['endpoint'] as String : 'https://api.openai.com/v1/responses';
    _tasks = await _taskDao.all();
    if (mounted) setState((){});
  }

  Future<void> _saveConfig() async {
    await _configDao.save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim().isEmpty?'gpt-5':_modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
    _configEditing = false;
    if (mounted) setState((){});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('配置已保存')));
  }

  Future<void> _openTaskDialog({Map<String,dynamic>? task}) async {
    final isEdit = task != null;
    final nameCtrl = TextEditingController(text: isEdit ? (task['name'] ?? '') as String : '');
    String type = isEdit ? (task['type'] ?? 'auto') as String : 'auto';
    String freqType = isEdit ? ((task['freq_type'] ?? 'daily') as String) : 'daily';
    int? selectedWeekday = isEdit ? (task['freq_weekday'] as int?) : 1;
    int? selectedMonthDay = isEdit ? (task['freq_day_of_month'] as int?) : 1;
    String freqCustomJson = isEdit ? ((task['freq_custom'] ?? '') as String) : '';
    final promptCtrl = TextEditingController(text: isEdit ? (task['prompt'] ?? '') as String : '');
    DateTime start = DateTime.now().add(const Duration(minutes: 1));
    if (isEdit) {
      try { start = DateTime.parse((task['start_time'] as String).replaceFirst(' ', 'T')); } catch (_){}
    }
    String avatarPath = isEdit ? (task['avatar_path'] ?? '') as String : '';
    String status = isEdit ? (task['status'] ?? 'open') as String : 'open';
    final manualQuoteCtrl = TextEditingController();
    if (isEdit && type=='manual') {
      final latest = await QuoteDao().latestForTask(task['task_uid'] as String);
      manualQuoteCtrl.text = latest ?? '';
    }
    if (isEdit && type=='manual') {
      final latest = await QuoteDao().latestForTask(task['task_uid'] as String);
      manualQuoteCtrl.text = latest ?? '';
    }

    final formKey = GlobalKey<FormState>();

    await showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: Text(isEdit ? '编辑任务' : '新增任务'),
        content: StatefulBuilder(builder: (ctx, setStateDialog) {
          Future<void> pickAvatar() async {
            final picker = ImagePicker();
            final x = await picker.pickImage(source: ImageSource.gallery);
            if (x == null) return;
            final bytes = await x.readAsBytes();
            final decoded = img.decodeImage(bytes);
            if (decoded != null) {
              final resized = img.copyResize(decoded, width: 72, height: 72);
              final dir = await getApplicationDocumentsDirectory();
              final file = File('${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png');
              await file.writeAsBytes(img.encodePng(resized));
              avatarPath = file.path;
              setStateDialog((){});
            }
          }

          Widget timePickerField(){
            return Row(
              children: [
                Expanded(
                  child: Text('${start.year}-${start.month.toString().padLeft(2,'0')}-${start.day.toString().padLeft(2,'0')} '
                      '${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}'),
                ),
                IconButton(
                  icon: const Icon(Icons.access_time),
                  onPressed: () async {
                    final t = await showTimePicker(context: ctx, initialTime: TimeOfDay(hour: start.hour, minute: start.minute));
                    if (t != null) {
                      setStateDialog((){
                        start = DateTime(start.year, start.month, start.day, t.hour, t.minute);
                      });
                    }
                  },
                )
              ],
            );
          }

          return Form(
            key: formKey,
            child: SingleChildScrollView(
              child: SizedBox(width: 420, child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(labelText: '任务名称'),
                    validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务名称' : null,
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: type,
                    items: const [
                      DropdownMenuItem(value: 'auto', child: Text('自动任务')),
                      DropdownMenuItem(value: 'manual', child: Text('手动任务')),
                      DropdownMenuItem(value: 'carousel', child: Text('轮播任务')),
                    ],
                    onChanged: (v){ setStateDialog(()=> type = v ?? 'auto'); },
                    decoration: const InputDecoration(labelText: '任务类型'),
                  ),
                  
const SizedBox(height: 8),
          
                  // 时间设置
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('时间：'),
                      TextButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.fromDateTime(start),
                          );
                          if (picked != null) {
                            setStateDialog(() {
                              start = DateTime(start.year, start.month, start.day, picked.hour, picked.minute);
                            });
                          }
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text('${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // 日期/频率
                  Row(
                    children: [
                      DropdownButton<String>(
                        value: freqType,
                        items: const [
                          DropdownMenuItem(value: 'daily', child: Text('每天')),
                          DropdownMenuItem(value: 'weekly', child: Text('每周')),
                          DropdownMenuItem(value: 'monthly', child: Text('每月')),
                          DropdownMenuItem(value: 'custom', child: Text('自定义')),
                        ],
                        onChanged: (v){ if (v!=null) setStateDialog(()=> freqType=v); },
                      ),
                      const SizedBox(width: 12),
                      if (freqType=='weekly') ...[
                        const Text('星期：'),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: selectedWeekday ?? 1,
                          items: const [
                            DropdownMenuItem(value: 1, child: Text('一')),
                            DropdownMenuItem(value: 2, child: Text('二')),
                            DropdownMenuItem(value: 3, child: Text('三')),
                            DropdownMenuItem(value: 4, child: Text('四')),
                            DropdownMenuItem(value: 5, child: Text('五')),
                            DropdownMenuItem(value: 6, child: Text('六')),
                            DropdownMenuItem(value: 7, child: Text('日')),
                          ],
                          onChanged: (v){ setStateDialog(()=> selectedWeekday = v); },
                        ),
                      ] else if (freqType=='monthly') ...[
                        const Text('日：'),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: selectedMonthDay ?? 1,
                          items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
                          onChanged: (v){ setStateDialog(()=> selectedMonthDay = v); },
                        ),
                      ],
                    ],
                  ),

              const Text('频率：'),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: freqType,
                items: const [
                  DropdownMenuItem(value: 'daily', child: Text('每天')),
                  DropdownMenuItem(value: 'weekly', child: Text('每周')),
                  DropdownMenuItem(value: 'monthly', child: Text('每月')),
                  DropdownMenuItem(value: 'custom', child: Text('自定义')),
                ],
                onChanged: (v){ if (v!=null) setStateDialog(()=> freqType=v); },
              ),
              const SizedBox(width: 16),
              if (freqType=='weekly') ...[
                const Text('星期：'),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: selectedWeekday ?? 1,
                  items: const [
                    DropdownMenuItem(value: 1, child: Text('一')),
                    DropdownMenuItem(value: 2, child: Text('二')),
                    DropdownMenuItem(value: 3, child: Text('三')),
                    DropdownMenuItem(value: 4, child: Text('四')),
                    DropdownMenuItem(value: 5, child: Text('五')),
                    DropdownMenuItem(value: 6, child: Text('六')),
                    DropdownMenuItem(value: 7, child: Text('日')),
                  ],
                  onChanged: (v){ setStateDialog(()=> selectedWeekday = v); },
                ),
              ] else if (freqType=='monthly') ...[
                const Text('日：'),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: selectedMonthDay ?? 1,
                  items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
                  onChanged: (v){ setStateDialog(()=> selectedMonthDay = v); },
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [

                      const Text('状态：'),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: Text(status=='open'?'开启(open)':'关闭(closed)'),
                        selected: status=='open',
                        onSelected: (_){
                          setStateDialog(()=> status = (status=='open'?'closed':'open'));
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Align(alignment: Alignment.centerLeft, child: Text('何时', style: Theme.of(context).textTheme.bodyMedium)),
                  timePickerField(),
                  
const SizedBox(height: 8),
          
                  // 时间设置
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('时间：'),
                      TextButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.fromDateTime(start),
                          );
                          if (picked != null) {
                            setStateDialog(() {
                              start = DateTime(start.year, start.month, start.day, picked.hour, picked.minute);
                            });
                          }
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text('${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // 日期/频率
                  Row(
                    children: [
                      DropdownButton<String>(
                        value: freqType,
                        items: const [
                          DropdownMenuItem(value: 'daily', child: Text('每天')),
                          DropdownMenuItem(value: 'weekly', child: Text('每周')),
                          DropdownMenuItem(value: 'monthly', child: Text('每月')),
                          DropdownMenuItem(value: 'custom', child: Text('自定义')),
                        ],
                        onChanged: (v){ if (v!=null) setStateDialog(()=> freqType=v); },
                      ),
                      const SizedBox(width: 12),
                      if (freqType=='weekly') ...[
                        const Text('星期：'),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: selectedWeekday ?? 1,
                          items: const [
                            DropdownMenuItem(value: 1, child: Text('一')),
                            DropdownMenuItem(value: 2, child: Text('二')),
                            DropdownMenuItem(value: 3, child: Text('三')),
                            DropdownMenuItem(value: 4, child: Text('四')),
                            DropdownMenuItem(value: 5, child: Text('五')),
                            DropdownMenuItem(value: 6, child: Text('六')),
                            DropdownMenuItem(value: 7, child: Text('日')),
                          ],
                          onChanged: (v){ setStateDialog(()=> selectedWeekday = v); },
                        ),
                      ] else if (freqType=='monthly') ...[
                        const Text('日：'),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: selectedMonthDay ?? 1,
                          items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
                          onChanged: (v){ setStateDialog(()=> selectedMonthDay = v); },
                        ),
                      ],
                    ],
                  ),

              const Text('频率：'),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: freqType,
                items: const [
                  DropdownMenuItem(value: 'daily', child: Text('每天')),
                  DropdownMenuItem(value: 'weekly', child: Text('每周')),
                  DropdownMenuItem(value: 'monthly', child: Text('每月')),
                  DropdownMenuItem(value: 'custom', child: Text('自定义')),
                ],
                onChanged: (v){ if (v!=null) setStateDialog(()=> freqType=v); },
              ),
              const SizedBox(width: 16),
              if (freqType=='weekly') ...[
                const Text('星期：'),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: selectedWeekday ?? 1,
                  items: const [
                    DropdownMenuItem(value: 1, child: Text('一')),
                    DropdownMenuItem(value: 2, child: Text('二')),
                    DropdownMenuItem(value: 3, child: Text('三')),
                    DropdownMenuItem(value: 4, child: Text('四')),
                    DropdownMenuItem(value: 5, child: Text('五')),
                    DropdownMenuItem(value: 6, child: Text('六')),
                    DropdownMenuItem(value: 7, child: Text('日')),
                  ],
                  onChanged: (v){ setStateDialog(()=> selectedWeekday = v); },
                ),
              ] else if (freqType=='monthly') ...[
                const Text('日：'),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: selectedMonthDay ?? 1,
                  items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
                  onChanged: (v){ setStateDialog(()=> selectedMonthDay = v); },
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [

                      const Text('头像'),
                      const SizedBox(width: 12),
                      CircleAvatar(
                        radius: 24,
                        backgroundImage: (avatarPath.isNotEmpty) ? FileImage(File(avatarPath)) : null,
                        child: avatarPath.isEmpty ? const Icon(Icons.person) : null,
                      ),
                      const SizedBox(width: 12),
                      TextButton.icon(onPressed: pickAvatar, icon: const Icon(Icons.upload), label: const Text('上传头像'))
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (type == 'auto') TextFormField(
                    controller: promptCtrl,
                    decoration: const InputDecoration(labelText: '提示词'),
                  ),
                  if (type == 'manual') TextFormField(
                    controller: manualQuoteCtrl,
                    maxLines: 4,
                    decoration: const InputDecoration(labelText: '名人名言内容（必填）'),
                    validator: (v)=> (type=='manual' && (v==null || v.trim().isEmpty)) ? '请输入名人名言' : null,
                  ),
                ],
              )),
            ),
          );
        }),
        actions: [
          TextButton(onPressed: () async {
            if (!isEdit) {
              Navigator.pop(context);
              return;
            }
            // delete
            await _taskDao.delete(task!['task_uid'] as String);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已删除任务')));
            await _load();
            Navigator.pop(context);
          }, child: const Text('删除')),
          TextButton(onPressed: (){
            Navigator.pop(context);
          }, child: const Text('取消')),
          FilledButton(onPressed: () async {
  bool closeNow = true;
  try {
    if (formKey.currentState?.validate() != true) { closeNow = false; return; }
    if (isEdit) {
      final patch = {
        'name': nameCtrl.text.trim(),
        'type': type,
        'start_time': '${start.year}-${start.month.toString().padLeft(2,'0')}-${start.day.toString().padLeft(2,'0')} ${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}',
        'prompt': type=='auto' ? promptCtrl.text.trim() : '',
        'avatar_path': avatarPath,
        'status': status,
        'freq_type': freqType,
        'freq_weekday': selectedWeekday,
        'freq_day_of_month': selectedMonthDay,
        'freq_custom': freqCustomJson,
      };
      
          final now = DateTime.now();
          final base = DateTime(now.year, now.month, now.day, start.hour, start.minute);
          final next = computeNextRunFrom(now, freqType: freqType, baseTime: base, freqWeekday: selectedWeekday, freqDayOfMonth: selectedMonthDay);
          patch['start_ts'] = base.millisecondsSinceEpoch;
          patch['next_run_ts'] = next.millisecondsSinceEpoch;
          await _taskDao.update(task!['task_uid'] as String, patch);
      // Manual task edit: update existing quote instead of inserting new row
      if (type == 'manual') {
        final content = manualQuoteCtrl.text.trim();
        if (content.isNotEmpty) {
          final ok = await QuoteDao().updateLatestForTask(task['task_uid'] as String, content);
          if (!ok) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('未找到该任务的现有名言，未插入新数据（按需求不插入）。')));
          }
        }
      }
    } else {
      // create
      final newUid = await _taskDao.create(
        name: nameCtrl.text.trim(),
        type: type,
        startTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, start.hour, start.minute),
        prompt: type=='auto' ? promptCtrl.text.trim() : '',
        avatarPath: avatarPath,
        status: status,
        freqType: freqType,
        freqWeekday: selectedWeekday,
        freqDayOfMonth: selectedMonthDay,
        freqCustom: freqCustomJson,
      );
      if (type == 'manual') {
        final content = manualQuoteCtrl.text.trim();
        if (content.isNotEmpty) {
          final dup = await QuoteDao().existsSimilar(content);
          if (dup) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('数据重复!请重新输入名人名言')));
            closeNow = false;
          } else {
            await QuoteDao().insertIfUnique(
              taskUid: newUid,
              type: 'manual',
              taskName: nameCtrl.text.trim(),
              avatarPath: avatarPath,
              content: content,
            );
          }
        }
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
    }
    await SchedulerService.scheduleNextForAll();
    await _load();
  } finally {
    if (context.mounted && closeNow) Navigator.pop(context);
  }
}, child: const Text('保存')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('API key', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: _apiKeyCtrl, enabled: _configEditing),
        const SizedBox(height: 8),
        const Text('模型名称', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: _modelCtrl, enabled: _configEditing),
        const SizedBox(height: 8),
        const Text('接口地址', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: _endpointCtrl, enabled: _configEditing),
      ],
    );

    final actions = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(onPressed: (){
          setState(()=> _configEditing = true);
        }, icon: const Icon(Icons.edit)),
        IconButton(onPressed: _saveConfig, icon: const Icon(Icons.save)),
      ],
    );

    return Scaffold(
      appBar: AppBar(title: const Text('设置'), actions: [
        IconButton(icon: const Icon(Icons.save), tooltip: '保存配置', onPressed: _saveConfig),
        IconButton(icon: const Icon(Icons.edit), tooltip: '编辑配置', onPressed: (){ setState((){ _configEditing = true;}); }),
      ]),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            cfgFields,
            const SizedBox(height: 16),
            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ..._tasks.map((t) => ListTile(
  title: InkWell(
    onTap: () => _openTaskDialog(task: t),
    child: Text((t['name'] ?? '') as String, style: const TextStyle(decoration: TextDecoration.underline)),
  ),
  subtitle: Text('时间: ${(t['start_time'] ?? '') as String}  类型: ${(t['type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}'),
))],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}