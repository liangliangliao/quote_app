
package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class UnlockReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val action = intent.action ?: ""
    logWithTime(context, "【解锁后台】收到广播：$"+"action")
    // 仅对解锁相关广播做处理
    when (action) {
      Intent.ACTION_USER_PRESENT,
      Intent.ACTION_USER_UNLOCKED -> handleUnlock(context)
      Intent.ACTION_SCREEN_ON -> handleScreenOn(context)
      else -> return
    }
  }

  private fun handleScreenOn(ctx: Context) {
    // 仅记录时间序，实际处理放在真正解锁里
    logWithTime(ctx, "【解锁后台】SCREEN_ON 收到，等待 USER_PRESENT/USER_UNLOCKED 确认")
  }

  private fun handleUnlock(ctx: Context) {
    if (!isLocationRulesEnabled(ctx)) {
      logWithTime(ctx, "【解锁后台】地点规则开关=关闭，跳过地点提醒与前台服务启动（回包：SKIP_SWITCH_OFF）")
      return
    }
    try {
      // 通过透明 Activity 拉起前台服务，避免 Android 12+ 限制
      val kick = Intent(ctx, FgKickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      ctx.startActivity(kick)
      logWithTime(ctx, "【解锁后台】已通过 FgKickActivity 请求启动 GeoForegroundService")
    } catch (t: Throwable) {
      logWithTime(ctx, "【解锁后台】启动 GeoForegroundService 失败：${t.message ?: "unknown"}")
    }
  }


  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      com.example.quote_app.data.DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        .getBoolean("configs.location_rules_enabled", false)
    } catch (_: Throwable) { false }
  }

}
