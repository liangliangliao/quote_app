
package com.example.quote_app

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class GeoWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
  override fun doWork(): Result {
    val ctx = applicationContext
    if (!isLocationRulesEnabled(ctx)) {
      logWithTime(ctx, "【GeoWorker】地点规则开关=关闭，跳过自动定位")
      return Result.success()
    }
    logWithTime(ctx, "【GeoWorker】开始一次后台定位轮询（占位实现，仅记录日志）")
    return Result.success()
  }

  companion object {
    const val UNIQUE_NAME = "geo_worker_unique_v1"
    @JvmStatic
    fun schedule(context: Context) {
      val req = PeriodicWorkRequestBuilder<GeoWorker>(15, TimeUnit.MINUTES)
        .addTag(UNIQUE_NAME).build()
      try {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
          UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, req
        )
      } catch (_: Throwable) {}
    }
  }


  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      com.example.quote_app.data.DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        .getBoolean("configs.location_rules_enabled", false)
    } catch (_: Throwable) { false }
  }

}
