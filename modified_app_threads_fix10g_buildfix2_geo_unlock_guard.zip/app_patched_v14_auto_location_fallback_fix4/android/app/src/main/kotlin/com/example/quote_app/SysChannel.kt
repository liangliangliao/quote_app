
package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

object SysChannel {
  private const val CHANNEL = "com.example.quote_app/sys"

  fun register(engine: FlutterEngine, appContext: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
      when (call.method) {
        "getBaiduLocationOnce" -> getBaiduFallback(appContext) { loc, err ->
          if (loc != null) result.success(mapOf(
              "lat" to loc.latitude,
              "lon" to loc.longitude,
              "accuracy" to loc.accuracy,
              "provider" to (loc.provider ?: "system")
          )) else result.error("NO_LOC", err ?: "failed", null)
        }
        "getSystemLocationOnce" -> getSystemOnce(appContext) { loc, err ->
          if (loc != null) result.success(mapOf(
              "lat" to loc.latitude,
              "lon" to loc.longitude,
              "accuracy" to loc.accuracy,
              "provider" to (loc.provider ?: "system")
          )) else result.error("NO_LOC", err ?: "failed", null)
        }
        else -> result.notImplemented()
      }
    }
  }

  // 尝试优先百度（如未集成则自动走系统）
  private fun getBaiduFallback(ctx: Context, cb: (Location?, String?) -> Unit) {
    try {
      val sdkClz = Class.forName("com.baidu.location.LocationClient")
      // 如果能加载到，说明接入了百度；此处简单直接走系统兜底，避免编译期依赖
      getSystemOnce(ctx, cb); return
    } catch (_: Throwable) {
      // 未接入百度，直接用系统
      getSystemOnce(ctx, cb); return
    }
  }

  // 系统一次性定位（30m 内返回或超时）
  private fun getSystemOnce(ctx: Context, cb: (Location?, String?) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val listener = object: LocationListener {
      override fun onLocationChanged(l: Location) {
        if (l.hasAccuracy() && l.accuracy <= 30f) {
          lm.removeUpdates(this); cb(l, null)
        }
      }
      override fun onProviderEnabled(p: String) {}
      override fun onProviderDisabled(p: String) {}
      override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
    }
    try {
      lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
      lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
    } catch (t: Throwable) {
      cb(null, t.message); return
    }
    android.os.Handler(Looper.getMainLooper()).postDelayed({
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      val last = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Throwable) { null }
        ?: try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Throwable) { null }
      cb(last, if (last == null) "timeout" else null)
    }, 15_000L)
  }
}
