
package com.example.quote_app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import androidx.core.app.NotificationCompat

class GeoForegroundService : Service() {
  private var started = false
  private val CHANNEL_ID = "geo_fg_channel_v1"
  private val NOTI_ID = 3211

  override fun onBind(intent: Intent?) = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (started) return START_NOT_STICKY
    started = true

    if (!isLocationRulesEnabled(this)) {
      logWithTime(this, "【前台服务-地点规则】开关已关闭，直接停止服务")
      stopSelf()
      return START_NOT_STICKY
    }

    ensureChannel()
    val noti = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("地点提醒正在运行")
      .setContentText("定位处理中…")
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setOngoing(true)
      .build()
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTI_ID, noti, ServiceInfoCompatType.location())
    } else {
      @Suppress("DEPRECATION")
      startForeground(NOTI_ID, noti)
    }
    logWithTime(this, "【前台服务-地点规则】前台服务已启动")

    // 启动一次性高精度定位（系统）
    obtainHighAccuracyOnce(this, 30.0, 15_000L){ loc, err ->
      if (loc != null) {
        logWithTime(this, "【前台服务-地点规则】获取到定位：acc=${loc.accuracy} lat=${loc.latitude} lon=${loc.longitude}")
      } else {
        logWithTime(this, "【前台服务-地点规则】定位失败：${err ?: "unknown"}")
      }
      stopSelfSafely()
    }

    return START_NOT_STICKY
  }

  private fun stopSelfSafely() {
    try {
      if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
    } catch (_: Throwable) {}
    stopSelf()
    logWithTime(this, "【前台服务-地点规则】前台服务已停止")
  }

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        val ch = NotificationChannel(CHANNEL_ID, "地点前台服务", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(ch)
      }
    }
  }

  object ServiceInfoCompatType {
    fun location(): Int = try {
      val cls = Class.forName("android.app.Service")
      val field = cls.getDeclaredField("FOREGROUND_SERVICE_TYPE_LOCATION")
      field.getInt(null)
    } catch (_: Throwable) { 0 }
  }

  // 一次性系统高精度定位（30m 内返回或超时）
  private fun obtainHighAccuracyOnce(ctx: Context, targetAccM: Double, timeoutMs: Long, cb: (Location?, String?) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val listener = object: LocationListener {
      override fun onLocationChanged(l: Location) {
        if (l.hasAccuracy() && l.accuracy <= targetAccM) {
          lm.removeUpdates(this); cb(l, null)
        }
      }
      override fun onProviderEnabled(p: String) {}
      override fun onProviderDisabled(p: String) {}
      override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
    }
    try {
      lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
      lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
    } catch (t: Throwable) {
      cb(null, t.message); return
    }

    // 超时回调
    android.os.Handler(Looper.getMainLooper()).postDelayed({
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      val last = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Throwable) { null }
        ?: try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Throwable) { null }
      if (last != null) cb(last, null) else cb(null, "timeout")
    }, timeoutMs)
  }


  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      com.example.quote_app.data.DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }

  private fun isLocationRulesEnabled(ctx: Context): Boolean {
    return try {
      ctx.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        .getBoolean("configs.location_rules_enabled", false)
    } catch (_: Throwable) { false }
  }

}
