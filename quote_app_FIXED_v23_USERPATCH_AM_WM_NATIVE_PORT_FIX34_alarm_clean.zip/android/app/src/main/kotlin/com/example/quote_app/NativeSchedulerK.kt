package com.example.quote_app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*
import java.util.concurrent.TimeUnit

object NativeSchedulerK {

  private const val CHANNEL_ID = "am_exact_channel"
  private const val UNIQUE_WORK_PREFIX = "wm_once_"

  private fun ensureChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = ctx.getSystemService(NotificationManager::class.java)
      if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        val ch = NotificationChannel(CHANNEL_ID, "Exact Alarm", NotificationManager.IMPORTANCE_HIGH)
        nm.createNotificationChannel(ch)
      }
    }
  }

  private fun pendingIntent(ctx: Context, id: Int, payload: String?): PendingIntent {
    val intent = Intent(ctx, com.example.quote_app.am.AlarmReceiver::class.java).apply {
      action = "ALARM_FIRE"
      putExtra("id", id)
      if (payload != null) putExtra("payload", payload)
    }
    val flags = (PendingIntent.FLAG_UPDATE_CURRENT or
      if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    return PendingIntent.getBroadcast(ctx, id, intent, flags)
  }

  fun requestExactPermission(ctx: Context): Boolean {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      am.canScheduleExactAlarms()
    } else true
  }

  fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    ensureChannel(ctx)
    val pi = pendingIntent(ctx, id, payload)
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
      }
      true
    } catch (_: Throwable) {
      false
    }
  }

  fun scheduleWmFallback(ctx: Context, id: Int, epochMs: Long, payload: String) {
    val delay = kotlin.math.max(0L, epochMs - System.currentTimeMillis())
    val input = Data.Builder().putInt("id", id).putString("payload", payload).build()
    val req = OneTimeWorkRequestBuilder<WmFallbackWorker>()
      .setInitialDelay(delay, TimeUnit.MILLISECONDS)
      .setInputData(input)
      .addTag(UNIQUE_WORK_PREFIX + id)
      .build()
    WorkManager.getInstance(ctx).enqueueUniqueWork(UNIQUE_WORK_PREFIX + id, ExistingWorkPolicy.REPLACE, req)
  }

  fun scheduleSelfCheck(ctx: Context, minutes: Int): Boolean {
    val mins = if (minutes < 15) 15 else minutes
    val req = PeriodicWorkRequestBuilder<SelfCheckWorker>(mins.toLong(), TimeUnit.MINUTES).build()
    WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("self_check", ExistingPeriodicWorkPolicy.UPDATE, req)
    return true
  }

  fun cancel(ctx: Context, id: Int) {
    try {
      val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
      am.cancel(pendingIntent(ctx, id, null))
    } catch (_: Throwable) {}
    try {
      WorkManager.getInstance(ctx).cancelUniqueWork(UNIQUE_WORK_PREFIX + id)
    } catch (_: Throwable) {}
  }

  fun cancelAll(ctx: Context) {
    try {
      WorkManager.getInstance(ctx).cancelAllWork()
    } catch (_: Throwable) {}
  }

  fun scheduleExactWmCompat(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    val ok = scheduleExactAt(ctx, id, epochMs, payload)
    if (!ok) scheduleWmFallback(ctx, id, epochMs, payload ?: "{}")
    return ok
  }
}
