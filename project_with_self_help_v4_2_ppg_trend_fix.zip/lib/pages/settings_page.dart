import '../diary/diary_settings_page.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'dart:async';
import 'dart:io';

import 'package:quote_app/services/native_am.dart';
import 'package:quote_app/services/native_wm.dart';
import 'package:quote_app/services/native_guard.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
// removed duplicate import of path_provider
// 用于选择和上传量表 Excel 模板文件
import 'package:file_picker/file_picker.dart';

// Import http for fetching DeepSeek model list. We keep this import scoped
// here rather than in a shared service since settings page performs
// configuration loading and saving directly.
import 'package:http/http.dart' as http;
import 'dart:convert';

// 导入量表数据和自动报告配置相关的 DAO
import '../data/scale_dao.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';
import '../utils/debug_logger.dart';
// removed duplicate import of native_guard (already imported above)

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _endpointCtrl = TextEditingController();
  final _recentHoursCtrl = TextEditingController();
  final _overviewThresholdCtrl = TextEditingController();

  // TMDb movie token controller. Holds the user configured read access token.
  final _movieTokenCtrl = TextEditingController();

  // DeepSeek configuration controllers and state. The DeepSeek API key
  // allows translation via the DeepSeek chat completion API. Users can
  // configure both the API key and choose a specific model from the
  // available DeepSeek models. These values are persisted in the
  // configs table via ConfigDao. When empty, DeepSeek translation is
  // effectively disabled and the app falls back to other translation
  // providers.
  final _deepseekKeyCtrl = TextEditingController();
  // List of available DeepSeek models fetched from the DeepSeek /models
  // endpoint. When the key is invalid or models cannot be fetched,
  // this list may remain empty.
  List<String> _deepseekModels = <String>[];
  // Currently selected DeepSeek model. Defaults to 'deepseek-chat'.
  String _selectedDeepseekModel = 'deepseek-chat';
  // Whether the DeepSeek models list is being loaded.
  bool _loadingDeepseek = false;

  // ====== 量表自动报告与模板导入 ======
  // 是否启用量表自动报告
  bool _autoReportEnabled = false;
  // 正在加载自动报告状态标记
  bool _loadingAutoReport = true;
  // 已选择的 Excel 模板文件
  PlatformFile? _selectedExcelFile;
  // 已选择文件的名称，用于界面展示
  String? _selectedFileName;

  bool _editingConfig = false;
  List<Map<String, dynamic>> _tasks = [];

  // ====== EMA / SSES 设置 ======
  // 是否启用 EMA / SSES 自尊问答
  bool _emaEnabled = false;
  // 自尊评分尺度：100 或 30
  int _esteemScale = 100;

  // ====== 运动设置 ======
  String? _sportBgPath;
  String? _sportSoundPath;
  List<String> _sportMusicList = <String>[];
  String _sportMusicMode = 'order'; // order / random

  /// 选择量表 Excel 文件
  Future<void> _pickExcelFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['xlsx'],
      );
      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _selectedExcelFile = result.files.first;
          _selectedFileName = _selectedExcelFile?.name;
        });
      }
    } catch (e) {
      // 弹出错误提示
      showToast('选择文件失败: ${e.toString()}');
    }
  }

  /// 导入量表 Excel 模板
  Future<void> _importExcel() async {
    if (_selectedExcelFile == null) {
      showToast('请选择 Excel 文件');
      return;
    }
    final ext = _selectedExcelFile!.extension?.toLowerCase();
    if (ext != 'xlsx') {
      showToast('仅支持导入 .xlsx 格式的文件');
      return;
    }
    final path = _selectedExcelFile!.path;
    if (path == null || path.isEmpty) {
      showToast('无法读取文件路径');
      return;
    }
    try {
      final file = File(path);
      final dao = ScaleDao();
      await dao.importFromExcel(file);
      showToast('导入成功');
      // 导入成功后清空选择的文件，刷新量表列表时可在测评中心看到
      setState(() {
        _selectedExcelFile = null;
        _selectedFileName = null;
      });
    } catch (e) {
      showToast('导入失败: ${e.toString()}');
    }
  }

  @override
  void initState() {
    super.initState();
    // 监听设置页刷新 bus，在切换到设置页或数据变更时刷新配置和任务列表
    SimpleBus.settingsTick.addListener(_onBus);
    _load();
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    _recentHoursCtrl.dispose();
    _overviewThresholdCtrl.dispose();

    _movieTokenCtrl.dispose();

    // Dispose the DeepSeek controller to release resources.
    _deepseekKeyCtrl.dispose();

// 移除监听，避免在页面销毁后回调
    SimpleBus.settingsTick.removeListener(_onBus);
    super.dispose();
  }

  /// 当接收到设置页刷新通知时重新加载配置和任务数据
  void _onBus() {
    _load();
  }

  
  Future<void> _reloadTasksAfterSave() async {
    _tasks = await _taskDao.all();
      if (mounted) setState(() {});
    
  }
void showToast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  /// Fetch the list of available DeepSeek models from the DeepSeek API.
  ///
  /// Requires that a non‑empty API key has been entered. When the key is
  /// missing, this method clears the models list. Errors during fetch
  /// are silently ignored; the list remains unchanged in that case.
  Future<void> _fetchDeepseekModels() async {
    final key = _deepseekKeyCtrl.text.trim();
    if (key.isEmpty) {
      // No key: clear models and return.
      if (mounted) {
        setState(() {
          _deepseekModels = <String>[];
        });
      }
      return;
    }
    // Mark as loading while fetching.
    if (mounted) {
      setState(() {
        _loadingDeepseek = true;
      });
    }
    try {
      http.Response? res;
      // DeepSeek provides an OpenAI-compatible Models API. Some environments
      // use /models, others use /v1/models. Try both.
      final endpoints = <String>[
        'https://api.deepseek.com/models',
        'https://api.deepseek.com/v1/models',
      ];
      for (final ep in endpoints) {
        try {
          final uri = Uri.parse(ep);
          final r = await http
              .get(uri, headers: {'Authorization': 'Bearer $key'})
              .timeout(const Duration(seconds: 20));
          if (r.statusCode == 200) {
            res = r;
            break;
          }
        } catch (_) {
          // try next endpoint
        }
      }
      if (res == null || res.statusCode != 200) {
        // Ensure UI updates even on failure.
        if (mounted) {
          setState(() {
            _deepseekModels = <String>[];
          });
        }
        return;
      }

      final decoded = jsonDecode(res.body);
      // The response may have a 'data' or 'models' key with a list of
      // model objects or simple strings. We normalize to a list of names.
      List<dynamic>? list;
      if (decoded is Map<String, dynamic>) {
        if (decoded['data'] is List) {
          list = decoded['data'] as List<dynamic>;
        } else if (decoded['models'] is List) {
          list = decoded['models'] as List<dynamic>;
        }
      } else if (decoded is List) {
        list = decoded;
      }
      final models = <String>[];
      if (list != null) {
        for (final item in list) {
          if (item is Map<String, dynamic>) {
            // Use 'id' or 'model' or 'name' as model identifier.
            final v = item['id'] ?? item['model'] ?? item['name'];
            if (v != null) {
              final name = v.toString().trim();
              if (name.isNotEmpty) {
                models.add(name);
              }
            }
          } else if (item is String) {
            final name = item.trim();
            if (name.isNotEmpty) models.add(name);
          }
        }
      }
      // De-duplicate while keeping stable order.
      final uniq = <String>[];
      final seen = <String>{};
      for (final m in models) {
        if (seen.add(m)) uniq.add(m);
      }
      if (mounted) {
        setState(() {
          _deepseekModels = uniq;
          if (_deepseekModels.isNotEmpty && !_deepseekModels.contains(_selectedDeepseekModel)) {
            _selectedDeepseekModel = _deepseekModels.first;
          }
        });
      }
    } catch (_) {
      // Ignore errors: don't update models on failure.
    } finally {
      if (mounted) {
        setState(() {
          _loadingDeepseek = false;
        });
      }
    }
  }

  // ====== Sport settings helpers ======
  Future<void> _pickSportBgImage() async {
    try {
      final picker = ImagePicker();
      final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (x == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final ext = p.extension(x.path).isEmpty ? '.jpg' : p.extension(x.path);
      final dst = p.join(dir.path, 'sport_running_bg$ext');
      await File(x.path).copy(dst);
      await _configDao.setSportRunningBg(dst);
      if (!mounted) return;
      setState(() { _sportBgPath = dst; });
      showToast('已设置运动背景图');
    } catch (_) {
      showToast('选择背景图失败');
    }
  }

  Future<void> _clearSportBgImage() async {
    try {
      await _configDao.setSportRunningBg('');
      if (!mounted) return;
      setState(() { _sportBgPath = null; });
      showToast('已清除运动背景图');
    } catch (_) {
      showToast('清除失败');
    }
  }

  Future<void> _pickSportStartSound() async {
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['mp3', 'wav', 'ogg', 'm4a'],
        withData: false,
      );
      if (res == null || res.files.isEmpty) return;
      final src = res.files.first.path;
      if (src == null || src.isEmpty) return;
      final dir = await getApplicationDocumentsDirectory();
      final ext = p.extension(src).isEmpty ? '.mp3' : p.extension(src);
      final dst = p.join(dir.path, 'sport_start_sound$ext');
      await File(src).copy(dst);
      await _configDao.setSportStartSound(dst);
      if (!mounted) return;
      setState(() { _sportSoundPath = dst; });
      showToast('已设置运动开始铃声');
    } catch (_) {
      showToast('选择铃声失败');
    }
  }

  Future<void> _clearSportStartSound() async {
    try {
      await _configDao.setSportStartSound('');
      if (!mounted) return;
      setState(() { _sportSoundPath = null; });
      showToast('已恢复默认铃声');
    } catch (_) {
      showToast('清除失败');
    }
  }

  Future<void> _pickSportMusicPlaylist() async {
    try {
      final res = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: const ['mp3', 'wav', 'ogg', 'm4a'],
        withData: false,
      );
      if (res == null || res.files.isEmpty) return;
      final dir = await getApplicationDocumentsDirectory();
      final outDir = Directory(p.join(dir.path, 'sport_music'));
      if (!await outDir.exists()) {
        await outDir.create(recursive: true);
      }
      final List<String> dstList = [];
      for (final f in res.files) {
        final src = f.path;
        if (src == null || src.isEmpty) continue;
        final ext = p.extension(src).isEmpty ? '.mp3' : p.extension(src);
        final base = p.basenameWithoutExtension(src);
        final ts = DateTime.now().millisecondsSinceEpoch;
        final dst = p.join(outDir.path, 'music_${ts}_$base$ext');
        await File(src).copy(dst);
        dstList.add(dst);
      }
      // Append to existing list (avoid duplicates)
      final merged = <String>[..._sportMusicList];
      for (final x in dstList) {
        if (!merged.contains(x)) merged.add(x);
      }
      await _configDao.setSportMusicPlaylist(merged);
      if (!mounted) return;
      setState(() {
        _sportMusicList = merged;
      });
      showToast('已更新运动播放清单');
    } catch (_) {
      showToast('选择音乐失败');
    }
  }

  Future<void> _clearSportMusicPlaylist() async {
    try {
      await _configDao.setSportMusicPlaylist(<String>[]);
      if (!mounted) return;
      setState(() {
        _sportMusicList = <String>[];
      });
      showToast('已清空播放清单');
    } catch (_) {
      showToast('清除失败');
    }
  }

  Future<void> _setSportMusicMode(String mode) async {
    final val = (mode == 'random') ? 'random' : 'order';
    try {
      await _configDao.setSportMusicMode(val);
      if (!mounted) return;
      setState(() {
        _sportMusicMode = val;
      });
      showToast('已更新播放模式');
    } catch (_) {
      // ignore
    }
  }

  /// Compute the next run time for the given task map.
  /// This replicates the logic of SchedulerService._computeNextRun so that we
  /// always cancel alarms based on the latest future trigger, rather than a
  /// possibly stale next_time stored in the database. If next_time is valid
  /// and in the future, it is used directly. Otherwise we derive the next
  /// run from start_time, freq_type, freq_weekday and freq_day_of_month.
  DateTime? _computeNextRunFor(Map<String, dynamic> t) {
    final now = DateTime.now();
    // Prefer next_time if it exists and is in the future.
    try {
      final raw = (t['next_time'] ?? '').toString();
      if (raw.isNotEmpty) {
        final dt = DateTime.tryParse(raw);
        if (dt != null && dt.isAfter(now.subtract(const Duration(seconds: 10)))) {
          return dt;
        }
      }
    } catch (_) {}
    // Parse start_time which may be HH:mm or absolute date time string
    String start = (t['start_time'] ?? '09:00').toString().trim();
    if (start.isEmpty) start = '09:00';
    DateTime? absDt;
    int hh = 9, mm = 0;
    // absolute date-time, e.g., 2025-10-25 10:05 or 2025-10-25 10:05:00
    final reAbs = RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?\$');
    if (reAbs.hasMatch(start)) {
      try {
        // replace space with 'T' to parse ISO-like string
        final s = start.replaceFirst(' ', 'T');
        absDt = DateTime.parse(s);
        hh = absDt.hour;
        mm = absDt.minute;
      } catch (_) {
        absDt = null;
      }
    } else {
      final m = RegExp(r'\b(\d{1,2}):(\d{2})\b').firstMatch(start);
      if (m != null) {
        hh = int.tryParse(m.group(1) ?? '') ?? 9;
        mm = int.tryParse(m.group(2) ?? '') ?? 0;
      }
    }
    // Determine frequency type; treat manual/empty/null as daily
    String freqType = (t['freq_type'] ?? 'daily').toString();
    if (freqType.isEmpty || freqType == 'null' || freqType == 'manual') {
      freqType = 'daily';
    }
    final int? weekDay = t['freq_weekday'] is int ? t['freq_weekday'] as int : null;
    final int? dayOfMonth = t['freq_day_of_month'] is int ? t['freq_day_of_month'] as int : null;
    // If start_time is an absolute future date-time, use it
    if (absDt != null && absDt.isAfter(now)) {
      return absDt;
    }
    // Weekly frequency
    if (freqType == 'weekly' && weekDay != null) {
      final wd = weekDay;
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isBefore(now)) {
        return cand;
      }
      return cand.add(const Duration(days: 7));
    }
    // Monthly frequency
    if (freqType == 'monthly' && dayOfMonth != null) {
      final d = dayOfMonth.clamp(1, 31);
      int y = now.year;
      int mth = now.month;
      int end = DateTime(y, mth + 1, 0).day;
      var cand = DateTime(y, mth, d.clamp(1, end), hh, mm);
      if (!cand.isBefore(now)) {
        return cand;
      }
      mth += 1;
      end = DateTime(y, mth + 1, 0).day;
      return DateTime(y, mth, d.clamp(1, end), hh, mm);
    }
    // Default daily frequency
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    if (!today.isBefore(now)) {
      return today;
    }
    return today.add(const Duration(days: 1));
  }

  /// Read the next run time (milliseconds) directly from the database for the given task uid.
  /// Returns null if next_time is not present or cannot be parsed.  This helper is used
  /// when cancelling alarms to ensure we always use the latest persisted next_time rather
  /// than recomputing it or using a stale in-memory value.
  Future<int?> _readNextMillisFromDbOrNull(String uid) async {
    try {
      final t = await _taskDao.getByUid(uid);
      final raw = (t?['next_time'] ?? '') as String?;
      if (raw != null && raw.isNotEmpty) {
        try {
          final dt = DateTime.parse(raw);
          return dt.millisecondsSinceEpoch;
        } catch (_) {
          return null;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? '') as String;

    // load recent hours
    final rh = await _configDao.getRecentHours();
    _recentHoursCtrl.text = rh.toString();

    final ot = await _configDao.getOverviewThreshold();
    _overviewThresholdCtrl.text = ot.toString();

    // Load movie token; fall back to default inside DAO
    try {
      final mt = await _configDao.getMovieToken();
      _movieTokenCtrl.text = mt;
    } catch (_) {
      _movieTokenCtrl.text = '';
    }

    // Load DeepSeek API key and model. If not set, fall back to
    // sensible defaults. Fetch the available model list afterwards.
    try {
      final dsKey = await _configDao.getDeepseekKey();
      _deepseekKeyCtrl.text = dsKey;
    } catch (_) {
      _deepseekKeyCtrl.text = '';
    }
    try {
      final dsModel = await _configDao.getDeepseekModel();
      _selectedDeepseekModel = dsModel;
    } catch (_) {
      _selectedDeepseekModel = 'deepseek-chat';
    }

    // Fetch the list of DeepSeek models asynchronously. This will update
    // state when complete. It is invoked outside of setState to avoid
    // triggering redundant rebuilds.
    _fetchDeepseekModels();

    _tasks = await _taskDao.all();
    // 读取量表自动报告开关状态
    try {
      final auto = await _configDao.getAutoReportEnabled();
      _autoReportEnabled = auto;
    } catch (_) {
      _autoReportEnabled = false;
    }
    // 读取 EMA / SSES 设置
    try {
      final ema = await _configDao.getEmaEnabled();
      final scale = await _configDao.getSelfEsteemScale();
      _emaEnabled = ema;
      _esteemScale = scale;
    } catch (_) {
      _emaEnabled = false;
      _esteemScale = 100;
    }

    // 读取运动设置
    try {
      _sportBgPath = await _configDao.getSportRunningBg();
      _sportSoundPath = await _configDao.getSportStartSound();
      _sportMusicList = await _configDao.getSportMusicPlaylist();
      _sportMusicMode = await _configDao.getSportMusicMode();
    } catch (_) {
      _sportBgPath = null;
      _sportSoundPath = null;
      _sportMusicList = <String>[];
      _sportMusicMode = 'order';
    }
    _loadingAutoReport = false;
    if (mounted) setState(() {});
  }

  Future<void> _saveConfig() async {
    await _configDao.save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
    // also persist recent hours with the same save action
    final _rh = int.tryParse(_recentHoursCtrl.text.trim()) ?? 2;
    await _configDao.setRecentHours(_rh < 1 ? 1 : _rh);
    final _ot = int.tryParse(_overviewThresholdCtrl.text.trim()) ?? 500;
    await _configDao.setOverviewThreshold(_ot < 1 ? 1 : _ot);

    // Persist movie token
    await _configDao.setMovieToken(_movieTokenCtrl.text.trim());

    // Persist DeepSeek API key and selected model. Even if no models were
    // fetched, persisting the key allows TranslationService to pick it up
    // immediately. Persisting the model ensures we store a valid value or
    // default 'deepseek-chat'.
    await _configDao.setDeepseekKey(_deepseekKeyCtrl.text.trim());
    await _configDao.setDeepseekModel(_selectedDeepseekModel);
    // Refresh DeepSeek model list after saving key, so dropdown shows all
    // available models immediately.
    _fetchDeepseekModels();
      setState(()=> _editingConfig = false);
      showToast('配置已保存');
    
  }

  
Future<String?> _saveAvatarTemp(File file) async {
  // 保留原始扩展名与尺寸，不裁剪
  final docs = await getApplicationDocumentsDirectory();
  final ext = p.extension(file.path);
  final base = p.basename(file.path);
  final safeName = 'avatar_${DateTime.now().millisecondsSinceEpoch}${ext.isNotEmpty ? ext : p.extension(base)}';
  final dst = File(p.join(docs.path, safeName));
  await dst.writeAsBytes(await file.readAsBytes());
  return dst.path;
}


  Future<void> _openTaskDialog({Map<String, dynamic>? task}) async {
    final isEdit = task != null;

    String name = isEdit ? (task['name'] ?? '') as String : '';
    String type = isEdit ? (task['type'] ?? 'manual') as String : 'manual'; // manual / auto / carousel / 批量导入任务
    String status = isEdit ? (task['status'] ?? 'on') as String : 'on';     // on / off
    String prompt = isEdit ? (task['prompt'] ?? '') as String : '';
    // Carousel order: desc (降序) | asc (升序) | random (随机)
    String carouselOrder = isEdit ? ((task?['carousel_order'] ?? 'desc') as String) : 'desc';
    String manualQuote = '';
    String theme = '';
    String authorName = '';
    String sourceFrom = '';
    String explanation = '';
    
    // Prepare avatarPath early; it may be overwritten for bulk-import tasks based on quote avatar
    String avatarPath = isEdit ? (task['avatar_path'] ?? '') as String : '';
    // 回显手动任务或批量导入任务的名言及其他字段
    if (isEdit && (task?['task_uid'] != null)) {
      final taskUid = task!['task_uid'] as String;
      if (type == 'manual') {
        final mq = await QuoteDao().latestForTask(taskUid);
        manualQuote = (mq?['content'] ?? '') as String;
        theme = (mq?['theme'] ?? '') as String;
        authorName = (mq?['author_name'] ?? '') as String;
        sourceFrom = (mq?['source_from'] ?? '') as String;
        explanation = (mq?['explanation'] ?? '') as String;
      } else if (type == '批量导入任务') {
        // Use cursor to select which quote to show.  Default to 0 if missing.
        final cursorVal = (task['cursor'] is int) ? task['cursor'] as int : int.tryParse((task['cursor'] ?? '0').toString()) ?? 0;
        final mq = await QuoteDao().findByTaskOffsetDesc(taskUid, cursorVal);
        if (mq != null) {
          manualQuote = (mq['content'] ?? '') as String;
          theme = (mq['theme'] ?? '') as String;
          authorName = (mq['author_name'] ?? '') as String;
          sourceFrom = (mq['source_from'] ?? '') as String;
          explanation = (mq['explanation'] ?? '') as String;
          // For bulk import tasks, use the quote's avatar for preview
          avatarPath = (mq['avatar'] ?? '') as String;
        }
      }
    }

    // freq
    String freqType = isEdit ? (task['freq_type'] ?? 'daily') as String : 'daily'; // daily/weekly/monthly/custom
    int? selectedWeekday = (task?['freq_weekday'] as int?);
    int? selectedMonthDay = (task?['freq_day_of_month'] as int?);
    TimeOfDay time = _parseTimeOfDay((task?['start_time'] ?? '') as String) ?? TimeOfDay.now();
    final formKey = GlobalKey<FormState>();

    // Auto-refresh "next trigger" preview
    Timer? ticker;
    void ensureTicker(StateSetter setStateDialog, BuildContext ctx) {
      ticker ??= Timer.periodic(const Duration(seconds: 30), (_){
        if (Navigator.of(ctx).mounted) setStateDialog((){});
      });
    }

    String two(int n)=> n.toString().padLeft(2,'0');
    String weekdayText(int w){
      const names = ['一','二','三','四','五','六','日'];
      return (w>=1 && w<=7)? names[w-1] : '一';
    }
    DateTime computeNext(DateTime now){
      if (freqType == 'weekly'){
        final wd = (selectedWeekday ?? 1);
        int delta = (wd - now.weekday) % 7;
        var cand = DateTime(now.year, now.month, now.day, time.hour, time.minute).add(Duration(days: delta));
        if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
        return cand;
      } else if (freqType == 'monthly'){
        final d = (selectedMonthDay ?? 1);
        int y = now.year, m = now.month;
        int end = DateTime(y, m + 1, 0).day;
        var cand = DateTime(y, m, d.clamp(1, end), time.hour, time.minute);
        if (!cand.isAfter(now)) {
          m += 1;
          end = DateTime(y, m + 1, 0).day;
          cand = DateTime(y, m, d.clamp(1, end), time.hour, time.minute);
        }
        return cand;
      } else {
        final today = DateTime(now.year, now.month, now.day, time.hour, time.minute);
        if (today.isAfter(now)) return today;
        return today.add(const Duration(days: 1));
      }
    }

    String _fmt(DateTime dt){ String two(int n)=> n.toString().padLeft(2,'0'); return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}'; }
    await showDialog(context: context, builder: (dialogCtx) {
      return StatefulBuilder(
        builder: (ctx, setStateDialog) {
          ensureTicker(setStateDialog, ctx);
          final next = computeNext(DateTime.now());
          final nextStr = '${next.year}-${two(next.month)}-${two(next.day)} ${two(next.hour)}:${two(next.minute)}';

          return AlertDialog(
            title: Text(isEdit ? '编辑任务' : '新增任务'),
            content: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('任务标题'),
                    TextFormField(
                      initialValue: name,
                      onChanged: (v)=> name = v,
                      validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务标题' : null,
                    ),
                    const SizedBox(height: 8),
                    const Text('任务类型'),
                    DropdownButton<String>(
                      value: type,
                      onChanged: (v){ setStateDialog(()=> type = v ?? 'manual'); },
                      items: const [
                        DropdownMenuItem(value: 'manual', child: Text('手动')),
                        DropdownMenuItem(value: 'auto', child: Text('自动')),
                        DropdownMenuItem(value: 'carousel', child: Text('轮播')),
                        DropdownMenuItem(value: '批量导入任务', child: Text('批量导入任务')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (type == 'auto') ...[
                      const Text('提示词'),
                      TextFormField(
                        initialValue: prompt,
                        onChanged: (v)=> prompt = v,
                        validator: (v)=> (type=='auto' && (v==null || v.trim().isEmpty)) ? '请输入提示词' : null,
                      ),
                    ],
                    if (type == 'manual' || type == '批量导入任务') ...[
                      const Text('名人名言'),
                      
TextFormField(
            initialValue: manualQuote,
                        onChanged: (v)=> manualQuote = v,
                        validator: (v)=> (type=='manual' && (v==null || v.trim().isEmpty)) ? '请输入名人名言' : null,
                        minLines: 3,
                        maxLines: null,
                        keyboardType: TextInputType.multiline,
                        textInputAction: TextInputAction.newline,
                      ),

  const SizedBox(height: 8),
  const Text('主题'),
  TextFormField(
    initialValue: theme,
    onChanged: (v) => theme = v,
  ),
  const SizedBox(height: 8),
  const Text('署名'),
  TextFormField(
    initialValue: authorName,
    onChanged: (v) => authorName = v,
  ),
  const SizedBox(height: 8),
  const Text('出处'),
  TextFormField(
    initialValue: sourceFrom,
    onChanged: (v) => sourceFrom = v,
  ),
  const SizedBox(height: 8),
  const Text('简明解释'),
  TextFormField(
    initialValue: explanation,
    onChanged: (v) => explanation = v,
    minLines: 3,
    maxLines: null,
    keyboardType: TextInputType.multiline,
    textInputAction: TextInputAction.newline,
  ),
],
                    // When creating or editing a carousel task, allow the user to select the play order
                    if (type == 'carousel') ...[
                      const Text('轮播顺序'),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RadioListTile<String>(
                            title: const Text('降序'),
                            value: 'desc',
                            groupValue: carouselOrder,
                            onChanged: (v) {
                              setStateDialog(() => carouselOrder = v ?? 'desc');
                            },
                          ),
                          RadioListTile<String>(
                            title: const Text('升序'),
                            value: 'asc',
                            groupValue: carouselOrder,
                            onChanged: (v) {
                              setStateDialog(() => carouselOrder = v ?? 'desc');
                            },
                          ),
                          RadioListTile<String>(
                            title: const Text('随机'),
                            value: 'random',
                            groupValue: carouselOrder,
                            onChanged: (v) {
                              setStateDialog(() => carouselOrder = v ?? 'desc');
                            },
                          ),
                        ],
                      ),
                    ],
const SizedBox(height: 8),
const Text('头像（用于通知图标）'),
                    Row(
                      children: [
                        // 显示文件名；若未选择则显示提示文字；不展示图片
                        Flexible(
                          child: Text(
                            avatarPath.isNotEmpty ? p.basename(avatarPath) : '未选择',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        OutlinedButton.icon(
                          onPressed: () async {
                            final picker = ImagePicker();
                            final x = await picker.pickImage(source: ImageSource.gallery);
                            if (x != null) {
                              final p = await _saveAvatarTemp(File(x.path));
                              setStateDialog(()=> avatarPath = p ?? '');
                            }
                          },
                          icon: const Icon(Icons.photo),
                          label: const Text('选择图片'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('状态'),
                    DropdownButton<String>(
                      value: status,
                      onChanged: (v){ setStateDialog(()=> status = v ?? 'on'); },
                      items: const [
                        DropdownMenuItem(value: 'on', child: Text('开启')),
                        DropdownMenuItem(value: 'off', child: Text('关闭')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('时间：'),
                    // frequency row
                    Row(
                      children: [
                        DropdownButton<String>(
                          value: freqType,
                          onChanged: (v){ setStateDialog(()=> freqType = v ?? 'daily'); },
                          items: const [
                            DropdownMenuItem(value: 'daily', child: Text('每天')),
                            DropdownMenuItem(value: 'weekly', child: Text('每周')),
                            DropdownMenuItem(value: 'monthly', child: Text('每月')),
                          ],
                        ),
                        const SizedBox(width: 12),
                        if (freqType=='weekly')
                          DropdownButton<int>(
                            value: selectedWeekday ?? 1,
                            onChanged: (v){ setStateDialog(()=> selectedWeekday = v ?? 1); },
                            items: const [
                              DropdownMenuItem(value: 1, child: Text('周一')),
                              DropdownMenuItem(value: 2, child: Text('周二')),
                              DropdownMenuItem(value: 3, child: Text('周三')),
                              DropdownMenuItem(value: 4, child: Text('周四')),
                              DropdownMenuItem(value: 5, child: Text('周五')),
                              DropdownMenuItem(value: 6, child: Text('周六')),
                              DropdownMenuItem(value: 7, child: Text('周日')),
                            ],
                          ),
                        if (freqType=='monthly')
                          DropdownButton<int>(
                            value: (selectedMonthDay ?? 1).clamp(1, 28),
                            onChanged: (v){ setStateDialog(()=> selectedMonthDay = (v ?? 1).clamp(1, 28)); },
                            items: [
                              for (int d=1; d<=28; d++)
                                DropdownMenuItem(value: d, child: Text('$d日')),
                            ],
                          ),
                        const Spacer(),
                        IconButton(
                          onPressed: () async {
                            final t = await showTimePicker(context: ctx, initialTime: time);
                            if (t != null) setStateDialog(()=> time = t);
                          },
                          icon: const Icon(Icons.access_time),
                        ),
                        Text('${two(time.hour)}:${two(time.minute)}'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      () {
                        final hhmm = '${two(time.hour)}:${two(time.minute)}';
                        if (freqType=='weekly') {
                          final w = selectedWeekday ?? 1;
                          return '每周${weekdayText(w)} $hhmm （下一次：$nextStr）';
                        } else if (freqType=='monthly') {
                          final d = selectedMonthDay ?? 1;
                          return '每月${d}日 $hhmm （下一次：$nextStr）';
                        } else {
                          return '每天 $hhmm （下一次：$nextStr）';
                        }
                      }(),
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              if (isEdit)
                TextButton(
                  onPressed: () async {
                    final uid = task!['task_uid'] as String;
                    // Cancel AM/WM using the latest persisted next_time from DB rather than computing a value.
                    try {
                      final nextMillis = await _readNextMillisFromDbOrNull(uid);
                      if (await NativeGuard.isNativeWM()) {
                        await NativeWm.cancelWmByUidBoth(uid);
                      }
                      if (await NativeGuard.isNativeAM()) {
                        if (nextMillis != null) {
                          await NativeAm.cancelExactByNext(uid, nextMillis);
                        } else {
                          final _t = await _taskDao.getByUid(uid);
                          final rk = (_t?['scheduled_run_key'] ?? '') as String?;
                          await NativeAm.cancelExactById(uid, rk);
                        }
                      }
                    } catch (_) {}
                    await SchedulerService.cancelNextForTask(uid);
                    await _taskDao.delete(uid);
                    showToast('已删除任务');
                    await _load();
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('删除'),
                ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: () async {
                  if (formKey.currentState?.validate() != true) return;

                  String? uidToSchedule;

                  // Compose freq_custom for potential future use (not required now)
                  final freqCustomJson = '';

                  if (isEdit) {
                    final patch = <String, dynamic>{
                      'name': name.trim(),
                      'type': type,
                      'prompt': type=='auto' ? prompt.trim() : '',
                      'avatar_path': avatarPath,
                      'status': status,
                      'freq_type': freqType,
                      'freq_weekday': selectedWeekday,
                      'freq_day_of_month': selectedMonthDay,
                      'start_time': _fmt(computeNext(DateTime.now())),
                      'freq_custom': freqCustomJson,
                    };
                    // Handle carousel order updates: persist and reset cursor when changed
                    if (type == 'carousel') {
                      patch['carousel_order'] = carouselOrder;
                      final oldOrder = (task?['carousel_order'] ?? 'desc').toString();
                      if (oldOrder != carouselOrder) {
                        // When order changes, reset cursor to 0
                        patch['cursor'] = 0;
                      }
                    }
                    await _taskDao.update(task!['task_uid'] as String, patch);
                    // Cancel existing alarms using the latest persisted next_time from DB rather than computing a value
                    try {
                      final uid = task['task_uid'] as String;
                      final nextMillis = await _readNextMillisFromDbOrNull(uid);
                      if (await NativeGuard.isNativeWM()) {
                        await NativeWm.cancelWmByUidBoth(uid);
                      }
                      if (await NativeGuard.isNativeAM()) {
                        if (nextMillis != null) {
                          await NativeAm.cancelExactByNext(uid, nextMillis);
                        } else {
                          final _t2 = await _taskDao.getByUid(uid);
                          final rk = (_t2?['scheduled_run_key'] ?? '') as String?;
                          await NativeAm.cancelExactById(uid, rk);
                        }
                      }
                    } catch (_) {}
                    await SchedulerService.cancelNextForTask(task['task_uid'] as String);
                    uidToSchedule = task['task_uid'] as String;
                    await _reloadTasksAfterSave();

                                          
                    if (type == 'manual') {
                      final content = manualQuote.trim();
                      if (content.isNotEmpty) {
                        final ok = await QuoteDao().updateLatestForTaskDetailed(
                          taskUid: task['task_uid'] as String,
                          content: content,
                          theme: theme,
                          authorName: authorName,
                          sourceFrom: sourceFrom,
                          explanation: explanation,
                          avatarPath: avatarPath,
                        );
                        if (!ok) {
                          // 按你的要求：编辑手动任务时不新增，只更新
                          showToast('未找到该任务的现有名言（未新增）');
                        }
                      }
                    }
                  } else {
                    final newUid = await _taskDao.create(
                      name: name.trim(),
                      type: type,
                      startTime: _fmt(computeNext(DateTime.now())),
                      prompt: type=='auto' ? prompt.trim() : '',
                      avatarPath: avatarPath,
                      status: status,
                      freqType: freqType,
                      freqWeekday: selectedWeekday,
                      freqDayOfMonth: selectedMonthDay,
                      freqCustom: freqCustomJson,
                      carouselOrder: carouselOrder,
                    );
                    uidToSchedule = newUid;
                    await _reloadTasksAfterSave();

                    if (type == 'manual') {
                      final content = manualQuote.trim();
                      if (content.isNotEmpty) {
                        final dup = await QuoteDao().existsSimilar(content);
                        if (dup) {
                          showToast('数据重复!请重新输入名人名言');
                          return;
                        }
                        final now = DateTime.now(); String two(int n)=> n<10? '0$n':'$n'; final nowStr='${now.year}-${two(now.month)}-${two(now.day)} ${now.hour}:${two(now.minute)}:${two(now.second)}';
                        await QuoteDao().insertIfUniqueDetailed(taskUid: newUid, content: content, theme: theme, authorName: authorName, sourceFrom: sourceFrom, explanation: explanation, avatarPath: avatarPath, taskName: name, taskType: type, insertedAt: nowStr);
                      }
                    }
                  }

                                    await _load();
                  if (uidToSchedule != null) {
                    await SchedulerService.scheduleNextForTask(uidToSchedule!);
                  }
                  showToast('已保存');
                  if (context.mounted) Navigator.pop(context);
                }
                  ,
                child: const Text('保存'),
              ),
            ],
          );
        },
      );
    });
    ticker?.cancel();
  }

  
  TimeOfDay? _parseTimeOfDay(String startTime){
    // supports 'HH:mm' or 'yyyy-MM-dd HH:mm'
    startTime = (startTime ?? '').trim();
    if (startTime.isEmpty) return null;
    String? hhmm;
    if (RegExp(r'^\d{2}:\d{2}$').hasMatch(startTime)) {
      hhmm = startTime;
    } else {
      final m = RegExp(r'\b(\d{2}:\d{2})\b').firstMatch(startTime);
      hhmm = m?.group(1);
    }
    if (hhmm == null) return null;
    final hm = hhmm.split(':');
    final h = int.tryParse(hm[0]); final m2 = int.tryParse(hm[1]);
    if (h == null || m2 == null) return null;
    return TimeOfDay(hour: h, minute: m2);
  }
  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('API key', style: TextStyle(fontWeight: FontWeight.bold)),
        // Remove underline border for API key input
        TextField(
          controller: _apiKeyCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
        const SizedBox(height: 8),
        const Text('模型名称', style: TextStyle(fontWeight: FontWeight.bold)),
        // Remove underline border for model input
        TextField(
          controller: _modelCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
        const SizedBox(height: 8),
        const Text('接口地址', style: TextStyle(fontWeight: FontWeight.bold)),
        // Remove underline border for endpoint input
        TextField(
          controller: _endpointCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
        const SizedBox(height: 8),
        const Text('首页查询时间窗（小时）', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(
          controller: _recentHoursCtrl,
          enabled: _editingConfig,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(border: InputBorder.none),
        ),
        const SizedBox(height: 8),
        const Text('长周期总览显示阈值（条）', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(
          controller: _overviewThresholdCtrl,
          enabled: _editingConfig,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(border: InputBorder.none),
        ),

        const SizedBox(height: 8),
        const Text('电影 API Token', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(
          controller: _movieTokenCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),

        const SizedBox(height: 8),
        // DeepSeek API key input
        const Text('DeepSeek 密钥', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(
          controller: _deepseekKeyCtrl,
          enabled: _editingConfig,
          decoration: const InputDecoration(border: InputBorder.none),
        ),

        const SizedBox(height: 8),
        // DeepSeek model dropdown. When the models list is being loaded, show a
        // hint; otherwise provide a dropdown for selection. If editing is
        // disabled, the dropdown is disabled.
        const Text('DeepSeek 模型', style: TextStyle(fontWeight: FontWeight.bold)),
        _loadingDeepseek
            ? const Padding(
                padding: EdgeInsets.symmetric(vertical: 8.0),
                child: Text('正在加载模型列表...', style: TextStyle(color: Colors.grey)),
              )
            : DropdownButton<String>(
                isExpanded: true,
                value: _selectedDeepseekModel,
                onChanged: (_editingConfig && _deepseekModels.isNotEmpty)
                    ? (String? v) {
                        if (v == null) return;
                        setState(() {
                          _selectedDeepseekModel = v;
                        });
                        // Persist immediately when user selects; this ensures
                        // TranslationService picks up the new model without
                        // requiring a full save. Errors are ignored.
                        _configDao.setDeepseekModel(v);
                      }
                    : null,
                items: (_deepseekModels.isNotEmpty
                        ? _deepseekModels
                        : <String>[_selectedDeepseekModel])
                    .map<DropdownMenuItem<String>>((String m) {
                  return DropdownMenuItem<String>(
                    value: m,
                    child: Text(m),
                  );
                }).toList(),
              ),
      ],
    );

    return Scaffold(backgroundColor: Colors.white,
      appBar: AppBar(
        title: const SizedBox.shrink(),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        // Remove the default bottom divider by specifying a zero-height bottom
        bottom: const PreferredSize(preferredSize: Size.fromHeight(0), child: SizedBox()),
        leading: Padding(
          padding: const EdgeInsets.all(10),
          child: Material(
            color: Colors.white,
            elevation: 6,
            shape: const CircleBorder(),
            child: IconButton(
              icon: Icon(_editingConfig ? Icons.save : Icons.edit, color: Colors.black87),
              onPressed: () async {
                if (_editingConfig) {
                  // 如果处于编辑状态，保存配置并退出编辑模式（保存函数内部已处理 _editingConfig=false）
                  await _saveConfig();
                } else {
                  // 当前非编辑状态，进入编辑模式
                  setState(() => _editingConfig = true);
                }
              },
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Material(
              color: Colors.white,
              elevation: 6,
              shape: const CircleBorder(),
              child: IconButton(onPressed: ()=> _openTaskDialog(), icon: const Icon(Icons.add, color: Colors.black87)),
            ),
          ),
        ],
      ),
      body: Padding(
        // Remove top and bottom padding; keep horizontal padding only
        padding: const EdgeInsets.only(left: 12.0, right: 12.0),
        child: ListView(children: [
          ListTile(title: const Text('日记设置'), trailing: const Icon(Icons.chevron_right), onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (_)=>const DiarySettingsPage())); },),
          Divider(),
            
            // 配置字段
            cfgFields,
            const SizedBox(height: 16),
            // 量表自动报告开关与模板导入配置卡片
            Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 自动报告开关
                  SwitchListTile(
                    title: const Text('量表自动报告开关'),
                    subtitle: const Text('开启后，提交问卷时将调用大模型生成报告（暂未实现）'),
                    value: _autoReportEnabled,
                    onChanged: _loadingAutoReport
                        ? null
                        : (bool value) async {
                            // 即刻更新 UI
                            setState(() {
                              _autoReportEnabled = value;
                            });
                            await _configDao.setAutoReportEnabled(value);
                            showToast(value ? '已开启量表自动报告' : '已关闭量表自动报告');
                          },
                  ),
                  const Divider(height: 1),
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('上传量表模板文件', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                _selectedFileName ?? '请选择 .xlsx 文件',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () => _pickExcelFile(),
                              child: const Text('选择文件'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ElevatedButton(
                          onPressed: () => _importExcel(),
                          child: const Text('导入'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // EMA / SSES 配置卡片
            Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // EMA 开关
                  SwitchListTile(
                    title: const Text('启用即时自尊问答（EMA/SSES）'),
                    subtitle: const Text('开启后记录情绪时会额外弹出自尊题目'),
                    value: _emaEnabled,
                    onChanged: (bool value) async {
                      // Persist the new setting first; if it fails, keep the old state
                      try {
                        await _configDao.setEmaEnabled(value);
                        // only update local state after persistence succeeds
                        if (!mounted) return;
                        setState(() {
                          _emaEnabled = value;
                        });
                        showToast(value ? '已开启自尊问答' : '已关闭自尊问答');
                      } catch (_) {
                        // ignore failures silently
                      }
                    },
                  ),
                  const Divider(height: 1),
                  // 自尊评分尺度选择
                  ListTile(
                    title: const Text('自尊评分尺度'),
                    subtitle: const Text('选择 100 分制或 30 分制'),
                    trailing: DropdownButton<int>(
                      value: _esteemScale,
                      items: const [
                        DropdownMenuItem<int>(value: 100, child: Text('100 分制')),
                        DropdownMenuItem<int>(value: 30, child: Text('30 分制')),
                      ],
                      onChanged: (int? val) async {
                        if (val == null) return;
                        try {
                          // Persist scale first
                          await _configDao.setSelfEsteemScale(val);
                          if (!mounted) return;
                          setState(() {
                            _esteemScale = val;
                          });
                          showToast('已设置自尊评分尺度为 $val');
                        } catch (_) {
                          // ignore errors
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 运动设置卡片（背景图 + 开始铃声）
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('运动设置', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('运动进行时背景图片'),
                      subtitle: Text(_sportBgPath == null || _sportBgPath!.isEmpty ? '未设置' : p.basename(_sportBgPath!)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextButton(onPressed: _editingConfig ? _pickSportBgImage : null, child: const Text('选择')),
                          if (_sportBgPath != null && _sportBgPath!.isNotEmpty)
                            TextButton(onPressed: _editingConfig ? _clearSportBgImage : null, child: const Text('清除')),
                        ],
                      ),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('运动开始铃声'),
                      subtitle: Text(_sportSoundPath == null || _sportSoundPath!.isEmpty ? '系统通知铃声（默认）' : p.basename(_sportSoundPath!)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextButton(onPressed: _editingConfig ? _pickSportStartSound : null, child: const Text('选择')),
                          if (_sportSoundPath != null && _sportSoundPath!.isNotEmpty)
                            TextButton(onPressed: _editingConfig ? _clearSportStartSound : null, child: const Text('清除')),
                        ],
                      ),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('运动进行时音乐播放清单'),
                      subtitle: Text(
                        _sportMusicList.isEmpty
                            ? '未设置'
                            : '${_sportMusicList.length} 首：' + _sportMusicList.take(3).map((e) => p.basename(e)).join('、') + (_sportMusicList.length > 3 ? '…' : ''),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextButton(onPressed: _editingConfig ? _pickSportMusicPlaylist : null, child: const Text('选择')),
                          if (_sportMusicList.isNotEmpty)
                            TextButton(onPressed: _editingConfig ? _clearSportMusicPlaylist : null, child: const Text('清除')),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        const SizedBox(width: 16),
                        const Text('播放模式', style: TextStyle(color: Colors.black87)),
                        const SizedBox(width: 16),
                        DropdownButton<String>(
                          value: (_sportMusicMode == 'random') ? 'random' : 'order',
                          onChanged: _editingConfig
                              ? (v) {
                                  if (v != null) _setSportMusicMode(v);
                                }
                              : null,
                          items: const [
                            DropdownMenuItem(value: 'order', child: Text('顺序循环')),
                            DropdownMenuItem(value: 'random', child: Text('随机循环')),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Text('说明：未设置铃声时，运动倒计时结束会播放系统通知铃声；播放清单只在运动正式开始后循环播放。', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // 解锁提醒冷却时间设置卡片
            const UnlockCooldownConfigWidget(),
            const SizedBox(height: 16),

            // 百度 AK 设置卡片（Web / Android）
            const BaiduWebAkConfigWidget(),
            const SizedBox(height: 12),
            const BaiduAndroidAkConfigWidget(),
            const SizedBox(height: 16),

            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final t in _tasks)
              ListTile(
                title: InkWell(
                  onTap: () => _openTaskDialog(task: t),
                  child: Text((t['name'] ?? '') as String, style: const TextStyle(decoration: TextDecoration.underline)),
                ),
                subtitle: Text('时间: ${(t['start_time'] ?? '') as String}   下一次: ${((t['next_time'] ?? '') as String).toString().replaceFirst('T', ' ').split('.').first}   频率: ${(t['freq_type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}'),
              ),
          ],
        ),
      ),

    );
  }
}

class _SelfCheckConfigWidget extends StatefulWidget {
  const _SelfCheckConfigWidget({super.key});
  @override
  State<_SelfCheckConfigWidget> createState() => _SelfCheckConfigWidgetState();
}
class _SelfCheckConfigWidgetState extends State<_SelfCheckConfigWidget> {
  final _ctrl = TextEditingController();
  bool _loading = true;
  @override
  void initState() {
    super.initState();
    _load();
  }
  Future<void> _load() async {
    final minutes = await NotifyConfigDao().getSelfCheckMinutes();
    setState(() { _ctrl.text = minutes.toString(); _loading=false; });
  }
  Future<void> _save() async {
    final m = int.tryParse(_ctrl.text) ?? 15;
    await NotifyConfigDao().setSelfCheckMinutes(m);
    await SchedulerService.scheduleSelfCheck();
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存（自检功能已禁用，不会注册周期任务）')));
  }
  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('自检频率（分钟）', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: _ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: '>=15')),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: _save, child: const Text('保存并生效')),
          ],
        ),
      ),
    );
  }
}



class RecentHoursWidget extends StatefulWidget {
  const RecentHoursWidget({super.key});
  @override
  State<RecentHoursWidget> createState() => _RecentHoursWidgetState();
}
class _RecentHoursWidgetState extends State<RecentHoursWidget> {
  final _ctrl = TextEditingController();
  bool _loading = true;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final h = await ConfigDao().getRecentHours();
    setState(() { _ctrl.text = h.toString(); _loading = false; });
  }
  Future<void> _save() async {
    final h = int.tryParse(_ctrl.text.trim()) ?? 2;
    await ConfigDao().setRecentHours(h);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存最近小时数')));
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('首页查询时间窗（小时）', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: _ctrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: '默认 2（单位：小时）',
              ),
            ),
            const SizedBox(height: 8),
            const Text('说明：只查询“今日且最近 N 小时内”的通知记录（notified=1）。'),
            const SizedBox(height: 8),
            Row(children:[
              ElevatedButton(onPressed: _save, child: const Text('保存')),
            ]),
          ],
        ),
      ),
    );
  }
}

/// 解锁提醒冷却时间配置控件。
/// 允许用户设置解锁触发愿景提醒的冷却间隔（分钟或天）。
class UnlockCooldownConfigWidget extends StatefulWidget {
  const UnlockCooldownConfigWidget({super.key});
  @override
  State<UnlockCooldownConfigWidget> createState() => _UnlockCooldownConfigWidgetState();
}

class _UnlockCooldownConfigWidgetState extends State<UnlockCooldownConfigWidget> {
  final _minutesCtrl = TextEditingController();
  final _daysCtrl = TextEditingController();
  bool _loading = true;
  @override
  void initState() {
    super.initState();
    _load();
  }
  Future<void> _load() async {
    final dao = NotifyConfigDao();
    final mins = await dao.getUnlockCooldownMinutes();
    final days = await dao.getUnlockCooldownDays();
    // 如果 days > 0，则优先显示 days；否则显示 mins
    if (days > 0) {
      _daysCtrl.text = days.toString();
      _minutesCtrl.text = '';
    } else {
      _minutesCtrl.text = mins.toString();
      _daysCtrl.text = '';
    }
    if (mounted) setState(() { _loading = false; });
  }
  @override
  void dispose() {
    _minutesCtrl.dispose();
    _daysCtrl.dispose();
    super.dispose();
  }
  Future<void> _save() async {
    final dao = NotifyConfigDao();
    // 优先取天数
    final dStr = _daysCtrl.text.trim();
    if (dStr.isNotEmpty) {
      final d = double.tryParse(dStr);
      if (d != null && d > 0) {
        await dao.setUnlockCooldown(days: d);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存解锁冷却时间（天）')));
        return;
      }
    }
    final mStr = _minutesCtrl.text.trim();
    if (mStr.isNotEmpty) {
      final m = int.tryParse(mStr);
      if (m != null && m > 0) {
        await dao.setUnlockCooldown(minutes: m);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存解锁冷却时间（分钟）')));
        return;
      }
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请输入有效的冷却时间')));
  }
  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('解锁提醒冷却时间', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _minutesCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: '分钟',
                      hintText: '默认 30',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextField(
                    controller: _daysCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: '天',
                      hintText: '可选',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                ElevatedButton(onPressed: _save, child: const Text('保存')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// 百度 Web AK 配置控件（用于 Web API：逆地理/Place/IP 等）
class BaiduWebAkConfigWidget extends StatefulWidget {
  const BaiduWebAkConfigWidget({super.key});
  @override
  State<BaiduWebAkConfigWidget> createState() => _BaiduWebAkConfigWidgetState();
}

class _BaiduWebAkConfigWidgetState extends State<BaiduWebAkConfigWidget> {
  final _akCtrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final ak = await ConfigDao().getBaiduAk();
    _akCtrl.text = ak;
    if (mounted) setState(() { _loading = false; });
  }

  @override
  void dispose() {
    _akCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final ak = _akCtrl.text.trim();
    await ConfigDao().setBaiduAk(ak);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存百度 Web AK')));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('百度 Web AK', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('用于：Web 逆地理、Place 周边检索、IP 定位等（不依赖包名/SHA1）。', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: _akCtrl,
              decoration: const InputDecoration(
                hintText: '输入 Baidu Web API Key',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [ElevatedButton(onPressed: _save, child: const Text('保存'))]),
          ],
        ),
      ),
    );
  }
}

/// 百度 Android AK 配置控件（用于 Baidu SDK：定位/搜索 SDK）
class BaiduAndroidAkConfigWidget extends StatefulWidget {
  const BaiduAndroidAkConfigWidget({super.key});
  @override
  State<BaiduAndroidAkConfigWidget> createState() => _BaiduAndroidAkConfigWidgetState();
}

class _BaiduAndroidAkConfigWidgetState extends State<BaiduAndroidAkConfigWidget> {
  final _akCtrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final ak = await ConfigDao().getBaiduAndroidAk();
    _akCtrl.text = ak;
    if (mounted) setState(() { _loading = false; });
  }

  @override
  void dispose() {
    _akCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final ak = _akCtrl.text.trim();
    await ConfigDao().setBaiduAndroidAk(ak);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存百度 Android AK（重启 App 后生效）')));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('百度 Android AK', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('用于：Baidu Location/Map/Search SDK（必须在百度控制台绑定：包名 + SHA1）。', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: _akCtrl,
              decoration: const InputDecoration(
                hintText: '输入 Baidu Android SDK Key',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [ElevatedButton(onPressed: _save, child: const Text('保存'))]),
          ],
        ),
      ),
    );
  }
}
