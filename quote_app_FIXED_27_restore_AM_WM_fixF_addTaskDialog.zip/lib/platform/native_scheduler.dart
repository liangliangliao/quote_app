import 'dart:convert';
import 'package:flutter/services.dart';

class NativeScheduler {
  static const MethodChannel _ch = MethodChannel('quote/native_scheduler');

  // -------- Channel/permission helpers --------
  static Future<void> ensureChannel() async {
    await _ch.invokeMethod('ensureChannel');
  }

  static Future<bool> hasExactAlarmPermission() async {
    final res = await _ch.invokeMethod('hasExactAlarmPermission');
    return res == true;
  }

  static Future<void> requestExactAlarmPermission() async {
    await _ch.invokeMethod('requestExactAlarmPermission');
  }

  // -------- AM (AlarmManager) primary scheduling --------

  /// Alias kept for历史兼容：Dart侧有地方调用 scheduleExactAt；底层等价于 scheduleAfter
  static Future<bool> scheduleExactAt({
    required int id,
    required int epochMs,
    required Map<String, dynamic> payload,
  }) async {
    final ok = await _ch.invokeMethod('scheduleExactAt', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload),
    });
    return ok == true;
  }

  /// 新接口（等价于 scheduleExactAt），供后续调用
  static Future<bool> scheduleAfter({
    required int id,
    required int epochMs,
    required Map<String, dynamic> payload,
  }) async {
    final ok = await _ch.invokeMethod('scheduleAfter', {
      'id': id,
      'epochMs': epochMs,
      'payload': jsonEncode(payload),
    });
    return ok == true;
  }

  /// 取消 AM 已注册的 PendingIntent（依赖相同 requestCode=id）
  static Future<void> cancel(int id) async {
    await _ch.invokeMethod('cancel', {'id': id});
  }

  // -------- WM (WorkManager) fallback --------

  static Future<bool> scheduleFallback({
    required String unique,
    required int delayMs,
    required Map<String, dynamic> payload,
  }) async {
    final ok = await _ch.invokeMethod('scheduleFallback', {
      'unique': unique,
      'delayMs': delayMs,
      'payload': jsonEncode(payload),
    });
    return ok == true;
  }

  static Future<void> cancelFallback(String unique) async {
    await _ch.invokeMethod('cancelFallback', {'unique': unique});
  }
}
