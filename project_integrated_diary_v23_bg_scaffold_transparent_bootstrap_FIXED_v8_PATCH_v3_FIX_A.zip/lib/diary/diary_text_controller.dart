import 'dart:io';

import 'package:flutter/material.dart';

/// A TextEditingController that renders attachment marker lines like:
///   [图片] /path/to/file
///   [语音] /path/to/file
///
/// - Storage stays text-based for compatibility with existing DB/logic.
/// - In the editor/reader TextField, markers are rendered as inline widgets so
///   file paths never leak into the UI (including after backspace).
class DiaryContentController extends TextEditingController {
  DiaryContentController({String? text}) : super(text: text);

  /// Set by the hosting page (via LayoutBuilder) so inline images can be sized.
  double? contentWidth;

  static final RegExp _imgReg = RegExp(r'^\[图片\]\s*(.+)$');
  static final RegExp _audioReg = RegExp(r'^\[语音\]\s*(.+)$');

  static bool _isMarkerLine(String line) {
    final l = line.trimLeft();
    return l.startsWith('[图片]') || l.startsWith('[语音]');
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final baseStyle = style ?? DefaultTextStyle.of(context).style;
    final full = value.text;
    if (full.isEmpty) return TextSpan(style: baseStyle, text: '');

    // We rebuild the span line-by-line so we can replace marker lines with widgets.
    final lines = full.split(RegExp(r'\r?\n'));
    final spans = <InlineSpan>[];

    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];

      final img = _imgReg.firstMatch(line.trimRight());
      final aud = _audioReg.firstMatch(line.trimRight());

      if (img != null) {
        final p = img.group(1)?.trim();
        spans.add(_imageWidgetSpan(context, p));
      } else if (aud != null) {
        final p = aud.group(1)?.trim();
        spans.add(_audioWidgetSpan(context, p));
      } else {
        // Normal text line.
        spans.add(TextSpan(style: baseStyle, text: line));
      }

      // Re-add newlines between lines.
      if (i != lines.length - 1) {
        spans.add(TextSpan(style: baseStyle, text: '\n'));
      }
    }

    return TextSpan(style: baseStyle, children: spans);
  }

  InlineSpan _imageWidgetSpan(BuildContext context, String? path) {
    final w = (contentWidth ?? 280).clamp(120.0, 2000.0);
    final h = (w * 0.72).clamp(120.0, 1200.0);

    final file = (path == null || path.isEmpty) ? null : File(path);
    final exists = file != null && file.existsSync();

    return WidgetSpan(
      alignment: PlaceholderAlignment.baseline,
      baseline: TextBaseline.alphabetic,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: w,
            height: h,
            child: exists
                ? Image.file(file!, fit: BoxFit.cover)
                : Container(
                    color: Colors.black.withOpacity(0.06),
                    alignment: Alignment.center,
                    child: const Text('[图片不可用]'),
                  ),
          ),
        ),
      ),
    );
  }

  InlineSpan _audioWidgetSpan(BuildContext context, String? path) {
    // Keep it simple and path-free; playback is handled by the page's attachment UI.
    return WidgetSpan(
      alignment: PlaceholderAlignment.baseline,
      baseline: TextBaseline.alphabetic,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.05),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.mic_none, size: 18),
              SizedBox(width: 6),
              Text('语音'),
            ],
          ),
        ),
      ),
    );
  }
}
