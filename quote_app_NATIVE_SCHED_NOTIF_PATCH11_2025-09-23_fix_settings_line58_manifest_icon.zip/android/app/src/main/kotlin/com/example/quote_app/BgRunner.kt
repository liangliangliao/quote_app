package com.example.quote_app

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.FlutterInjector
import io.flutter.embedding.engine.loader.FlutterLoader
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant

object BgRunner {
    private var engine: FlutterEngine? = null
    private var channel: MethodChannel? = null

    @Synchronized
    fun ensureEngine(context: Context) {
        if (engine != null) return
        val loader: FlutterLoader = FlutterInjector.instance().flutterLoader()
        loader.startInitialization(context)
        loader.ensureInitializationComplete(context, null)
        val eng = FlutterEngine(context)
        // Register plugins for this headless engine
        GeneratedPluginRegistrant.registerWith(eng)
        eng.dartExecutor.executeDartEntrypoint(
            DartExecutor.DartEntrypoint(loader.findAppBundlePath(), "bgMain")
        )
        engine = eng
        channel = MethodChannel(eng.dartExecutor.binaryMessenger, "com.example.quote_app/bg")
    }

    fun invokeDart(context: Context, method: String, args: HashMap<String, Any?>) {
        ensureEngine(context)
        Handler(Looper.getMainLooper()).post {
            channel?.invokeMethod(method, args)
        }
        // Stop engine later to free memory
        Handler(Looper.getMainLooper()).postDelayed({
            try { engine?.destroy() } catch (_: Exception) {}
            engine = null
            channel = null
        }, 20_000) // 20s enough for one dispatch
    }
}
