import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  static const String chGeneralId = 'quote_general';
  static const String chGeneralName = '默认通知';
  static const String chGeneralDesc = '统一的应用通知通道';

  static Future<void> init() async {
    if (_inited) return;
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    const init = InitializationSettings(android: androidInit, iOS: iosInit);
    await _plugin.initialize(init);
    // 创建通道（Android）
    const channel = AndroidNotificationChannel(
      chGeneralId, chGeneralName,
      description: chGeneralDesc,
      importance: Importance.defaultImportance,
    );
    final androidSpec = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidSpec?.createNotificationChannel(channel);
    _inited = true;
  }

  /// 统一展示通知；id 若不传默认用 0
  static Future<void> show({
    required String title,
    required String body,
    String? payload,
    String? avatarPath,
    int id = 0,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      chGeneralId,
      chGeneralName,
      channelDescription: chGeneralDesc,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      largeIcon: (avatarPath != null && avatarPath.isNotEmpty)
          ? FilePathAndroidBitmap(avatarPath)
          : const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: BigTextStyleInformation(body),
      ticker: 'quote_ticker',
    );
    const iosDetails = DarwinNotificationDetails(
      presentAlert: true, presentBadge: true, presentSound: true,
    );
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);
    await _plugin.show(id, title, body, details, payload: payload);
  }
}
