import 'dao.dart';
import 'db.dart';

extension QuoteDaoX on QuoteDao {
  Future<Map<String,dynamic>?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    return rows.isNotEmpty ? rows.first : null;
  }

  Future<void> markNotified(String quoteUid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
  }

  Future<List<Map<String,dynamic>>> allContentsForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content'], where: 'task_uid=?', whereArgs: [taskUid]);
    return rows;
  }
}
