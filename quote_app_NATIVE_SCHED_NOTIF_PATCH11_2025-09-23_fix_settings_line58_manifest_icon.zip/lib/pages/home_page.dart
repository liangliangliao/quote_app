import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? _latest;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    SchedulerService.init();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    _latest = await QuoteDao().latestOne();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final content = (_latest?['content'] ?? '') as String;
    final taskName = (_latest?['task_name'] ?? '') as String;
    if (content.isEmpty) {
      return const Center(child: Text('暂无数据！'));
    }
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (taskName.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text('任务：$taskName', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ),
          Expanded(
            child: SingleChildScrollView(
              child: Text(content, style: const TextStyle(fontSize: 18)),
            ),
          ),
        ],
      ),
    );
  }
}
