package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import androidx.work.WorkManager;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.wm.WmScheduler;
import com.example.quote_app.schedule.NextTriggerCalculator;

import org.json.JSONObject;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try { com.example.quote_app.data.DbRepo.log(context, null, "【原生】AM 广播触发"); } catch (Throwable ignore) {}
        String _act = intent==null?null:intent.getAction();
try { com.example.quote_app.data.DbRepo.log(context, null, "【原生】AM Intent action="+String.valueOf(_act)); } catch (Throwable ignore) {}
int id = intent != null ? intent.getIntExtra("id", 0) : 0;
        String payload = intent != null ? intent.getStringExtra("payload") : "{}";
        String uid = null;
        String runKey = "";

        try {
            DbRepository.log(context.getApplicationContext(), uid==null?"":uid, "【原生】AM 触发 uid="+(uid==null?"":uid)+" run="+runKey);
            JSONObject obj = new JSONObject(payload == null ? "{}" : payload);
            uid = obj.optString("uid", null);
            runKey = obj.optString("runKey", "");
            try { DbRepository.log(context.getApplicationContext(), uid==null?"":uid, "【原生】AM 触发(解析后) uid="+(uid==null?"":uid)+" run="+runKey); } catch (Throwable ignore) {}

        } catch (Throwable ignore) {}

        if (TextUtils.isEmpty(uid)) {
            // 兜底：没有 uid 仍然发一个到点提醒
            String title = "提醒";
            String body = "到点了";
            try { NotifyHelper.send(context.getApplicationContext(), id, title, body, null); } catch (Throwable ignore) {}
            return;
        }

        boolean entered = false;
        try {
            entered = DbRepository.runGuardBegin(context.getApplicationContext(), uid, runKey, "am");
            if (!entered) return;

            boolean handled = Biz.run(context.getApplicationContext(), uid);
            if (handled) {
                DbRepository.log(context.getApplicationContext(), uid, "【原生】AM 发送成功 uid="+uid+" run="+runKey);
                // 成功：取消兜底WM
                DbRepository.markLatestSuccess(context.getApplicationContext(), uid);
                long next = NextTriggerCalculator.compute(context.getApplicationContext(), uid);
                if (next > 0) {
                    NativeSchedulerK.scheduleExactWmCompat(context.getApplicationContext(), id, next, payload);
                    WmScheduler.schedulePair(context.getApplicationContext(), next, uid, "ts_"+next);
                }
                try { WmScheduler.cancelFallback(context.getApplicationContext(), uid, runKey); } catch (Throwable ignore) {}
            } else {
                // === 通知失败 ===
                try { DbRepository.log(context.getApplicationContext(), uid, "通知失败，来源="+(idCard==null?"":idCard)); } catch (Throwable ignore) {}
                String src = null, runK = runKey; try { if (idCard!=null) src = idCard.split("_")[0].replace("src=",""); } catch (Throwable ignore) {}
                if ("am".equals(src) || "main-wm".equals(src)) {
                    // 取消当前，直接续排
                    try { if (idCard!=null) NativeSchedulerK.cancelByIdCard(context.getApplicationContext(), idCard); } catch (Throwable ignore) {}
                    try { NativeSchedulerK.scheduleNextForUid(context.getApplicationContext(), uid); } catch (Throwable ignore) {}
                } else if ("fallback-wm".equals(src)) {
                    // 取消当前fallback，<=2次尝试则立刻重试一次fallback
                    try { if (idCard!=null) NativeSchedulerK.cancelByIdCard(context.getApplicationContext(), idCard); } catch (Throwable ignore) {}
                    try {
                        android.content.SharedPreferences sp = context.getSharedPreferences("wm_retry", Context.MODE_PRIVATE);
                        int c = sp.getInt("c_"+idCard, 0) + 1; sp.edit().putInt("c_"+idCard, c).apply();
                        if (c <= 2) {
                            long now = java.lang.System.currentTimeMillis();
                            String rk = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(now));
                            com.example.quote_app.wm.WmScheduler.schedulePair(context.getApplicationContext(), now, uid, rk);
                            DbRepository.log(context.getApplicationContext(), uid, "【原生】WM 兜底重试一次：uid="+uid+" rk="+rk);
                        } else {
                            DbRepository.log(context.getApplicationContext(), uid, "【原生】WM 兜底已超过2次重试，停止");
                        }
                    } catch (Throwable ignore) {}
                } else {
                    // selfck-wm：仅取消
                    try { if (idCard!=null) NativeSchedulerK.cancelByIdCard(context.getApplicationContext(), idCard); } catch (Throwable ignore) {}
                }
                DbRepository.log(context.getApplicationContext(), uid, "【原生】AM 发送失败 uid="+uid+" run="+runKey);
                DbRepository.log(context.getApplicationContext(), uid, "AM通道：业务未处理");
            }
        } catch (Throwable t) {
            DbRepository.log(context.getApplicationContext(), uid, "AM异常: " + (t.getMessage()==null?"未知错误":t.getMessage()));
        } finally {
            try { DbRepository.runGuardEnd(context.getApplicationContext(), uid, runKey, "am"); } catch (Throwable ignore) {}
        }
    }
}
