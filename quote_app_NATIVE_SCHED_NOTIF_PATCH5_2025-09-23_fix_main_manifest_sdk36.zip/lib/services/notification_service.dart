import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  static const String chGeneralId = 'quote_general';
  static const String chGeneralName = '默认通知';
  static const String chGeneralDesc = '统一的应用通知通道';

  static Future<void> init() async {
    if (_inited) return;
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    const init = InitializationSettings(android: androidInit, iOS: iosInit);
    await _plugin.initialize(init);
    if (Platform.isAndroid) {
      const channel = AndroidNotificationChannel(
        chGeneralId, chGeneralName,
        description: chGeneralDesc,
        importance: Importance.defaultImportance,
        showBadge: true,
        enableVibration: true,
      );
      final nm = await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await nm?.createNotificationChannel(channel);
    }
    _inited = true;
  }

  static Future<void> show({required String title, required String body, String? payload, String? avatarPath, int id = 0}) async {
    await init();
    final androidDetails = AndroidNotificationDetails(
      chGeneralId, chGeneralName,
      channelDescription: chGeneralDesc,
      priority: Priority.defaultPriority,
      importance: Importance.defaultImportance,
      largeIcon: (avatarPath != null && avatarPath.isNotEmpty)
          ? FilePathAndroidBitmap(avatarPath)
          : const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: const DefaultStyleInformation(true, true),
      ticker: 'quote_ticker',
    );
    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true, presentBadge: true, presentSound: true,
    );
    final details = NotificationDetails(android: androidDetails, iOS: darwinDetails);
    await _plugin.show(id, title, body, details, payload: payload);
  }
}
