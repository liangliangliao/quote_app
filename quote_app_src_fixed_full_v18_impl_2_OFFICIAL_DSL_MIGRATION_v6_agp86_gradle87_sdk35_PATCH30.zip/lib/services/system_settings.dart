import 'dart:io';
import 'package:flutter/services.dart';

class SystemSettings {
  static const MethodChannel _ch = MethodChannel('sys.settings');
  static Future<bool> openExactAlarmSettings() async {
    if (!Platform.isAndroid) return false;
    try { return (await _ch.invokeMethod<bool>('openExactAlarmSettings')) ?? false; } catch (_) { return false; }
  }
  static Future<bool> openIgnoreBatteryOptimizations() async {
    if (!Platform.isAndroid) return false;
    try { return (await _ch.invokeMethod<bool>('openIgnoreBatteryOptimizations')) ?? false; } catch (_) { return false; }
  }
  static Future<bool> openNotificationSettings() async {
    if (!Platform.isAndroid) return false;
    try { return (await _ch.invokeMethod<bool>('openNotificationSettings')) ?? false; } catch (_) { return false; }
  }
}
