import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// A helper service to obtain the current device location in a robust manner.
///
/// This service first attempts to use the Geolocator plugin to obtain the
/// current position with high accuracy. If that fails (for example on
/// devices without Google Play services in Mainland China), it falls back
/// to Baidu's IP‑based geolocation API. The Baidu API key is read from
/// the notify_config table (key = 'baidu_ak'). If no key is configured,
/// the fallback will be skipped and null is returned.
class LocationService {
  // Latitude and longitude bounding box for mainland China. These constants
  // are used to determine whether a device's current coordinates fall
  // within the approximate borders of mainland China. If both latitude and
  // longitude lie within these ranges, we consider the device to be in
  // China for the purpose of choosing a location provider.
  static const double _chinaMinLat = 3.86;
  static const double _chinaMaxLat = 53.55;
  static const double _chinaMinLon = 73.66;
  static const double _chinaMaxLon = 135.05;
  /// Attempts to obtain the current position. Returns a [Position] if
  /// successful, otherwise returns null.
  static Future<Position?> getCurrentPositionSmart() async {
    // Try using Geolocator first
    try {
      // Attempt to obtain a fresh location fix with a time limit.  In some indoor
      // environments or on devices without Google Play services, this call may
      // throw or time out.  We wrap it in a try/catch to gracefully handle
      // failures.
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 4),
      );
      // Record a log entry indicating that the standard Geolocator API was used
      // to obtain the location. This helps differentiate overseas provider
      // usage from the Baidu fallback in the logs table.
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator 获取位置：'
            'lat=${pos.latitude}, lon=${pos.longitude}');
      } catch (_) {}
      return pos;
    } catch (_) {
      // ignore and try last known position or Baidu fallback
    }
    // If a current position could not be obtained, attempt to retrieve the last
    // known position from the system.  This is useful when GPS is disabled or
    // no recent fix is available.  If null, fall through to Baidu.
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        try {
          DLog.i('LocationService', '【定位】使用 Geolocator 最近一次已知位置：'
              'lat=${last.latitude}, lon=${last.longitude}');
        } catch (_) {}
        return last;
      }
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // If there is no last known position, attempt to obtain a low-accuracy
    // location via the network/GPS provider. This provides a coarse location
    // quickly before falling back to Baidu IP. This call may still throw
    // exceptions which are caught and ignored.
    try {
      final low = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 4),
      );
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator (低精度) 获取位置：'
            'lat=${low.latitude}, lon=${low.longitude}');
      } catch (_) {}
      return low;
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // Fallback to Baidu IP location if configured
    try {
      final ak = await NotifyConfigDao().getBaiduAk();
      if (ak.trim().isEmpty) {
        return null;
      }
      final url = Uri.parse(
        'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(ak.trim())}&coor=gcj02',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && data['status'] == 0) {
          final content = data['content'];
          if (content is Map) {
            final point = content['point'];
            if (point is Map) {
              final latStr = point['y']?.toString() ?? '';
              final lngStr = point['x']?.toString() ?? '';
              final lat = double.tryParse(latStr);
              final lng = double.tryParse(lngStr);
              if (lat != null && lng != null) {
                // Construct a Position with minimal fields; other fields left at zero
                // Log that Baidu IP location fallback is being used so the logs can
                // differentiate between location providers. Include the coordinates.
                try {
                  DLog.i('LocationService', '【定位】使用 Baidu IP 定位获取位置：'
                      'lat=$lat, lon=$lng');
                } catch (_) {}
                return Position(
                  latitude: lat,
                  longitude: lng,
                  timestamp: DateTime.now(),
                  accuracy: 0,
                  altitude: 0,
                  heading: 0,
                  speed: 0,
                  speedAccuracy: 0,
                  altitudeAccuracy: 0,
                  headingAccuracy: 0,
                );
              }
            }
          }
        }
      }
    } catch (_) {
      // ignore network or JSON errors
    }
    return null;
  }

  /// Attempts to obtain the current position with a bias toward using the
  /// Baidu IP geolocation service when it is configured. This helper first
  /// checks whether a Baidu API key exists in the notify_config table. If a
  /// non‑empty key is found, it will immediately attempt to query Baidu's
  /// `location/ip` endpoint to obtain a coordinate. Should this request
  /// succeed, the resulting position is returned and no further calls are
  /// attempted. If the Baidu lookup fails or no key is configured, this
  /// method falls back to [getCurrentPositionSmart] which uses Geolocator
  /// and then Baidu as a final option. All key steps are logged via DLog so
  /// that the logs table clearly shows which provider was used.
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // First attempt to obtain a location via the system's location services.
    // We try a high‑accuracy fix, then fall back to the last known position
    // and a low‑accuracy fix. This gives us a reasonable coordinate for
    // determining whether the device is in mainland China. All retrieval
    // attempts are wrapped in try/catch so failures do not throw.
    Position? systemPos;
    // 1) High accuracy current position
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 4),
      );
      systemPos = pos;
      // Log the use of Geolocator for a high‑accuracy fix
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator 获取位置：'
            'lat=${pos.latitude}, lon=${pos.longitude}');
      } catch (_) {}
    } catch (_) {
      // ignore and fall back
    }
    // 2) Last known position if high accuracy fails
    if (systemPos == null) {
      try {
        final last = await Geolocator.getLastKnownPosition();
        if (last != null) {
          systemPos = last;
          try {
            DLog.i('LocationService', '【定位】使用 Geolocator 最近一次已知位置：'
                'lat=${last.latitude}, lon=${last.longitude}');
          } catch (_) {}
        }
      } catch (_) {
        // ignore
      }
    }
    // 3) Low accuracy current position as a coarse fallback
    if (systemPos == null) {
      try {
        final low = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low,
          timeLimit: const Duration(seconds: 4),
        );
        systemPos = low;
        try {
          DLog.i('LocationService', '【定位】使用 Geolocator (低精度) 获取位置：'
              'lat=${low.latitude}, lon=${low.longitude}');
        } catch (_) {}
      } catch (_) {
        // ignore
      }
    }
    // If we obtained a system location, determine whether it lies within
    // mainland China and, if so, prefer Baidu IP geolocation for a more
    // robust location (particularly on devices without Google Play services).
    if (systemPos != null) {
      final lat = systemPos.latitude;
      final lon = systemPos.longitude;
      final inChina = lat >= _chinaMinLat && lat <= _chinaMaxLat &&
          lon >= _chinaMinLon && lon <= _chinaMaxLon;
      if (inChina) {
        // Log that we detected a mainland China coordinate and will use
        // Baidu geolocation.
        try {
          await DLog.i('LocationService', '检测目前所在地为中国将采用百度定位服务获取位置');
        } catch (_) {}
        // Attempt to query Baidu IP location. Use either the user‑configured
        // API key or a built‑in fallback if none is provided. On any
        // exception or invalid response, we will fall back to the system
        // location obtained above.
        int? httpStatus;
        int? baiduStatus;
        String? baiduMessage;
        try {
          String ak = '';
          try {
            ak = await NotifyConfigDao().getBaiduAk();
          } catch (_) {
            ak = '';
          }
          final effectiveAk = ak.trim().isNotEmpty
              ? ak.trim()
              : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
          if (effectiveAk.isNotEmpty) {
            final url = Uri.parse(
              'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(effectiveAk)}&coor=gcj02',
            );
            final res = await http
                .get(url)
                .timeout(const Duration(seconds: 5));
            httpStatus = res.statusCode;
            if (res.statusCode == 200) {
              try {
                final data = jsonDecode(res.body);
                if (data is Map) {
                  final rawStatus = data['status'];
                  if (rawStatus is int) {
                    baiduStatus = rawStatus;
                  } else if (rawStatus is String) {
                    baiduStatus = int.tryParse(rawStatus);
                  }
                  final rawMsg = data['message'];
                  if (rawMsg is String) {
                    baiduMessage = rawMsg;
                  }
                  if (data['status'] == 0) {
                    final content = data['content'];
                    if (content is Map) {
                      final point = content['point'];
                      if (point is Map) {
                        final latStr = point['y']?.toString() ?? '';
                        final lngStr = point['x']?.toString() ?? '';
                        final baiduLat = double.tryParse(latStr);
                        final baiduLon = double.tryParse(lngStr);
                        if (baiduLat != null && baiduLon != null) {
                          try {
                            await DLog.i('LocationService', '【定位】使用 Baidu IP 定位获取位置：'
                                'lat=$baiduLat, lon=$baiduLon');
                          } catch (_) {}
                          return Position(
                            latitude: baiduLat,
                            longitude: baiduLon,
                            timestamp: DateTime.now(),
                            accuracy: 0,
                            altitude: 0,
                            heading: 0,
                            speed: 0,
                            speedAccuracy: 0,
                            altitudeAccuracy: 0,
                            headingAccuracy: 0,
                          );
                        }
                      }
                    }
                  }
                }
              } catch (_) {
                // JSON parse error; fall through to fallback logging below.
              }
            }
          }
          // If we reach here, Baidu call either failed or returned no usable
          // coordinates. Log a warning and fall back to the system location.
          try {
            await DLog.i(
              'LocationService',
              '调用百度定位服务出现异常(http=${httpStatus ?? -1}, status=${baiduStatus ?? -1}, msg=${baiduMessage ?? ''})，将采用系统默认定位服务获取位置',
            );
          } catch (_) {}
          return systemPos;
        } catch (_) {
          // On any exception, log and fall back to the system location
          try {
            await DLog.i(
              'LocationService',
              '调用百度定位服务出现异常(http=${httpStatus ?? -1}, status=${baiduStatus ?? -1}, msg=${baiduMessage ?? ''})，将采用系统默认定位服务获取位置',
            );
          } catch (_) {}
          return systemPos;
        }
      } else {
        // Not in mainland China; use the system location and log this choice
        try {
          await DLog.i('LocationService', '检测目前所在地为非中国地区，将采用系统默认定位获取位置');
        } catch (_) {}
        return systemPos;
      }
    }
    // If no system location could be obtained, fall back to the existing
    // smart logic which itself attempts various providers and Baidu. This
    // will log internally and may still return null if no location is
    // available.
    return await getCurrentPositionSmart();
  }
}