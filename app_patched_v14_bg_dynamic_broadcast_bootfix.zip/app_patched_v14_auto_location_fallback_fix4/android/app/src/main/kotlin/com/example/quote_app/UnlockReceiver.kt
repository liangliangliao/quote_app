package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.quote_app.bg.GatekeeperService
import android.database.sqlite.SQLiteDatabase
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.Data
import androidx.work.WorkManager
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver listens for the USER_PRESENT broadcast which fires
 * when the user unlocks the device. When triggered, it checks for
 * any enabled screen‑unlock vision triggers and, if present, sends a
 * gentle reminder notification encouraging the user to recall their
 * vision goal.
 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
    val act = intent?.action
    if (act == android.content.Intent.ACTION_SCREEN_ON || act == android.content.Intent.ACTION_USER_PRESENT || act == android.content.Intent.ACTION_USER_UNLOCKED) {
        com.example.quote_app.data.DbRepo.log(context, null, \"正在解锁屏幕将触发通知发送\")
    }
} catch (_: Throwable) {}
try {
            // Log the received broadcast action for debugging and analytics
            try {
                DbRepo.log(context, null, "[UnlockReceiver] onReceive action=" + (intent?.action ?: "null"))
            } catch (_: Throwable) {}

            // No matter whether a screen_unlock trigger exists or whether a reminder will be sent,
            // enqueue a one‑off GeoWorker when the user unlocks the device. This ensures that
            // the device's current location is checked after every unlock so that geo rules
            // can fire without requiring the user to manually press the locate button.  Wrap
            // the scheduling in a try/catch so that any WorkManager issues do not break
            // the unlock flow.  Duplicates are allowed; WorkManager treats each request
            // independently for one‑off workers.
            try {
                val request = OneTimeWorkRequestBuilder<GeoWorker>().setInputData(Data.Builder().putBoolean("force_unlock_geo", true).build()).build()
                WorkManager.getInstance(context).enqueue(request)
            } catch (_: Throwable) {
                // ignore scheduling errors
            }
            // Open the SQLite database and query for enabled screen_unlock triggers.
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
            if (contract == null || contract.dbPath == null) {
                // If contract or db path is unavailable, assume triggers may exist
                try {
                    DbRepo.log(context, null, "[UnlockReceiver] contract or dbPath unavailable, fallback to send reminder")
                } catch (_: Throwable) {}
                sendReminder(context)
                return
            }
            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                null
            )
            val hasTrigger = cursor.moveToFirst()
            cursor.close()
            // Also check the persistent flag stored in notify_config so that
            // unlocking can trigger reminders even if there is no
            // screen_unlock row in vision_triggers. If the key is missing or
            // false, configEnabled will remain false.
            var configEnabled = false
            try {
                val c = db.rawQuery(
                    "SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1",
                    null
                )
                if (c.moveToFirst()) {
                    val v = c.getString(0)
                    if (v != null) {
                        val s = v.trim().lowercase()
                        configEnabled = (s == "1" || s == "true")
                    }
                }
                c.close()
            } catch (_: Throwable) {
                // ignore DB errors
            }
            try {
                DbRepo.log(context, null, "[UnlockReceiver] hasTrigger=" + hasTrigger + ", configEnabled=" + configEnabled)
            } catch (_: Throwable) {}
            db.close()
            if (hasTrigger || configEnabled) {
                // Record the timestamp of this unlock event so the app can detect
                // recent unlocks when it starts. This value will be consumed
                // by App.maybeSendUnlockReminderOnAppStart to avoid sending
                // reminders when the app is opened long after unlocking.
                try {
                    val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                    try {
                        DbRepo.log(context, null, "[UnlockReceiver] unlock event, saved last_unlock_time (logs table) at ts=" + System.currentTimeMillis())
                    } catch (_: Throwable) {}
                } catch (_: Throwable) { /* ignore errors */ }
                sendReminder(context)
            }
        } catch (_: Throwable) {
            // On any error, fallback to sending reminder. Record the unlock time
            try {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                try {
                    DbRepo.log(context, null, "[UnlockReceiver] exception fallback, saved last_unlock_time (logs table) at ts=" + System.currentTimeMillis())
                } catch (_: Throwable) {}
            } catch (_: Throwable) { /* ignore */ }
            sendReminder(context)
        }
    }

    /**
     * Sends a notification reminding the user about their vision goal.
     */
    private fun sendReminder(context: Context) {
        // 记录最近一次通过解锁事件发送提醒的时间，方便 App 在启动时
        // 避免立刻再补发一条重复通知。
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_unlock_reminder_time", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
            // ignore
        }

        // Use a deterministic ID to avoid flooding the notification drawer
        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        // Pass notifType so that tapping the notification opens the vision focus page
        try {
            DbRepo.log(context, null, "[UnlockReceiver] sending reminder notification at ts=" + System.currentTimeMillis())
        } catch (_: Throwable) {}
        NotifyHelper.send(context, id, title, body, null, "vision_focus", null)

        // No need to enqueue GeoWorker here; it will be scheduled in onReceive unconditionally.
    }
}