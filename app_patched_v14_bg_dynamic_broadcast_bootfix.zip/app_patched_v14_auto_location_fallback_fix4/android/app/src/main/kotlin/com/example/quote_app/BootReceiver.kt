package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.core.content.ContextCompat
import com.example.quote_app.bg.GatekeeperService

/**
 * BootReceiver listens for device boot completed or app package replacement
 * events and reinitializes all scheduled tasks.  It enqueues a one‑off
 * workmanager job with job name `wm_boot` which is handled in the Dart
 * dispatcher to restore all alarms and scheduled WorkManager tasks.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Build data payload
        val data = Data.Builder()
            .putString("job", "wm_boot")
            .build()
        val request = OneTimeWorkRequestBuilder<AlarmProxyWorker>()
            .setInputData(data)
            .build()
        WorkManager.getInstance(context).enqueue(request)

        // Schedule periodic geo location checks on boot to handle geo triggers
        try {
            GeoWorker.schedule(context)
        try { ContextCompat.startForegroundService(context, Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) { }
        } catch (_: Throwable) { /* ignore scheduling errors */ }
    }
}