
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import 'package:intl/intl.dart';
import '../platform/native_scheduler.dart';
import 'task_runner.dart';

class SchedulerService {
  static Future<void> init() async { /* no-op: Workmanager.initialize is handled in main.dart */ }

  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final start = (t['start_time'] ?? '09:00').toString();
    final now = DateTime.now();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length>1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (!next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }

  static int _alarmId(String uid, String runKey) {
    return (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;
  }

  static String _runKeyFromTime(DateTime t) {
    return DateFormat('yyyyMMdd_HHmm').format(t);
  }

  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);

    try {
      await NativeScheduler.scheduleExactAt(
        id: _alarmId(uid, runKey),
        epochMs: next.millisecondsSinceEpoch,
        payload: {'uid': uid, 'runKey': runKey},
      );
      await DLog.i('SCH', 'AM 注册完成 uid='+uid+' am_id='+_alarmId(uid, runKey).toString()+' run='+runKey);
    } catch (e) {
      await DLog.w('SCH','AM 注册失败，忽略: '+e.toString());
    }

    try {
      final delay = next.difference(DateTime.now());
      final _uniqueName = 'wm_run_'+uid+'_'+runKey;
      await Workmanager().registerOneOffTask(
        _uniqueName,
        'wm_task',
        initialDelay: delay.isNegative ? Duration.zero : delay,
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+_uniqueName+' run='+runKey);
    } catch (e) {
      await DLog.e('SCH','WM 注册失败: '+e.toString());
    }
  }

  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      await scheduleNextForTask((t['task_uid'] ?? '').toString());
    }
  }

  static Future<void> cancelNextForTask(String uid) async {
    try { await Workmanager().cancelAll(); } catch (_) {}
    try { await NativeScheduler.cancel(0); } catch (_) {}
  }

  static Future<void> wmRunTask(String uid, String? runKey) async {
    await TaskRunner.run(uid);
  }

  
  /// 注册/更新 自检 WM（周期最低 15 分钟），频率由 notify_config.selfcheck_minutes 决定
  static Future<void> scheduleSelfCheck() async {
    try {
      await _AuxTables.ensure();
      final minutes = await NotifyConfigDao().getSelfCheckMinutes();
      final unique = 'wm_selfcheck';
      await Workmanager().registerPeriodicTask(
        unique,
        'wm_selfcheck',
        frequency: Duration(minutes: minutes),
        inputData: {'job':'wm_selfcheck'},
        existingWorkPolicy: ExistingWorkPolicy.replace,
      );
      await DLog.i('SCH','已注册自检 WM，频率='+minutes.toString()+'分钟');
    } catch (e) {
      await DLog.e('SCH','注册自检 WM 失败: '+e.toString());
    }
  }

  /// 处理自检：补发当日失败的通知（立刻注册正常 WM）
  static Future<void> selfCheckTodayFailures() async {
    try {
      await _AuxTables.ensure();
      final fails = await FailureStatDao().failsOfToday();
      for (final row in fails) {
        final uid = (row['task_uid'] ?? '').toString();
        if (uid.isEmpty) continue;
        // 立刻注册一个正常 WM 进行补发
        final now = DateTime.now();
        final rk = DateFormat('yyyyMMdd_HHmm').format(now);
        final uniqueN = _wmUniqueNormal(uid, rk);
        try {
          await Workmanager().registerOneOffTask(
            uniqueN,
            'wm_task',
            initialDelay: Duration.zero,
            inputData: {'job':'wm_run','task_uid': uid, 'run_key': rk, 'chan':'normal', 'attempt': 1},
            existingWorkPolicy: ExistingWorkPolicy.replace,
            tag: uid,
          );
          await DLog.i('SCH','自检补发已注册 uid='+uid+' wm_unique='+uniqueN);
        } catch (e) {
          await DLog.e('SCH','自检补发注册失败 uid='+uid+' err='+e.toString());
        }
      }
    } catch (e) {
      await DLog.e('SCH','自检处理失败: '+e.toString());
    }
  }
static Future<void> callback([String? uid, String? runKey]) async {
    if (uid == null || uid.isEmpty) { return; }

    await TaskRunner.run(uid);
  }

  static Future<void> catchupIfMissed() async {}
}
