import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../data/emotions.dart';

/// 发现之旅：展示当天的心情状态与时间轴
class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});

  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _EsteemPoint {
  final DateTime time;
  final double score;
  const _EsteemPoint({required this.time, required this.score});
}

class _DiscoverPageState extends State<DiscoverPage> {
  Map<String, dynamic>? _latestToday;
  List<Map<String, dynamic>> _todayList = [];
  bool _loading = false;

  // 自尊分析相关状态
  String _esteemRangeKey = 'today'; // 时间范围：today / 7d / 30d
  String _esteemGranularityKey = 'record'; // record / hour / day
  List<Map<String, dynamic>> _esteemList = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
    });
    try {
      final dao = EmotionDao();
      final latest = await dao.latestToday();
      final list = await dao.listTodayOrdered();

      // 默认用“今天 + 单次记录粒度”作为自尊分析的初始数据
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final esteemRows = await dao.listByRange(start, now);

      if (!mounted) return;
      setState(() {
        _latestToday = latest;
        _todayList = list;
        _esteemList = esteemRows;
      });
    } catch (_) {
      if (!mounted) return;
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  /// 根据当前选择的时间范围重新加载自尊分析数据
  Future<void> _reloadEsteemByFilter() async {
    final dao = EmotionDao();
    final now = DateTime.now();
    DateTime start;
    switch (_esteemRangeKey) {
      case '7d':
        start = now.subtract(const Duration(days: 7));
        break;
      case '30d':
        start = now.subtract(const Duration(days: 30));
        break;
      case 'today':
      default:
        start = DateTime(now.year, now.month, now.day);
        break;
    }

    final rows = await dao.listByRange(start, now);
    if (!mounted) return;
    setState(() {
      _esteemList = rows;
    });
  }




  List<double> _rawEsteemScores() {
    if (_esteemList.isEmpty) return const <double>[];
    return _esteemList.map<double>((row) {
      final name = (row['emoji_name'] ?? '').toString();
      return estimateSelfEsteemScore(name);
    }).toList();
  }

  Map<String, double> _computeEsteemStats(List<double> scores) {
    if (scores.isEmpty) {
      return {
        'p50': 0,
        'p90': 0,
        'p95': 0,
        'min': 0,
        'max': 0,
        'avg': 0,
      };
    }
    final sorted = List<double>.from(scores)..sort();
    double percentile(double p) {
      if (sorted.isEmpty) return 0;
      final idx = (p * (sorted.length - 1))
          .clamp(0, (sorted.length - 1).toDouble())
          .toInt();
      return sorted[idx];
    }

    final double sum = scores.fold(0.0, (a, b) => a + b);
    final double avg = sum / scores.length;
    final double min = sorted.first;
    final double max = sorted.last;
    return {
      'p50': percentile(0.5),
      'p90': percentile(0.9),
      'p95': percentile(0.95),
      'min': min,
      'max': max,
      'avg': avg,
    };
  }

  DateTime? _parseInsertedAt(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return null;
    try {
      return DateTime.parse(insertedAt);
    } catch (_) {
      return null;
    }
  }

  /// 根据当前选择的粒度构建自尊曲线数据点。
  List<_EsteemPoint> _buildEsteemPoints() {
    if (_esteemList.isEmpty) return const <_EsteemPoint>[];

    // 逐条记录：直接按照每条记录的情绪计算自尊指数
    if (_esteemGranularityKey == 'record') {
      final List<_EsteemPoint> points = [];
      for (final row in _esteemList) {
        final dt = _parseInsertedAt(row['inserted_at']?.toString()) ?? DateTime.now();
        final name = (row['emoji_name'] ?? '').toString();
        final score = estimateSelfEsteemScore(name);
        points.add(_EsteemPoint(time: dt, score: score));
      }
      points.sort((a, b) => a.time.compareTo(b.time));
      return points;
    }

    // 按小时 / 按天聚合：在时间窗内收集所有情绪名称，用 computeSelfEsteemIndexFromEmotions 算出该时间窗的自尊指数
    final Map<String, List<String>> bucketNames = {};
    final Map<String, DateTime> bucketTime = {};

    for (final row in _esteemList) {
      final dt = _parseInsertedAt(row['inserted_at']?.toString());
      if (dt == null) continue;

      DateTime bucket;
      if (_esteemGranularityKey == 'day') {
        bucket = DateTime(dt.year, dt.month, dt.day);
      } else {
        bucket = DateTime(dt.year, dt.month, dt.day, dt.hour);
      }
      final key = bucket.toIso8601String();
      final name = (row['emoji_name'] ?? '').toString();
      if (name.isEmpty) continue;

      bucketNames.putIfAbsent(key, () => <String>[]).add(name);
      bucketTime[key] = bucket;
    }

    final keys = bucketNames.keys.toList()
      ..sort((a, b) => bucketTime[a]!.compareTo(bucketTime[b]!));

    final List<_EsteemPoint> points = [];
    for (final key in keys) {
      final names = bucketNames[key]!;
      if (names.isEmpty) continue;
      final score = computeSelfEsteemIndexFromEmotions(names);
      points.add(_EsteemPoint(time: bucketTime[key]!, score: score));
    }

    points.sort((a, b) => a.time.compareTo(b.time));
    return points;
  }

  String _formatTime(String? insertedAt) {
    if (insertedAt == null || insertedAt.isEmpty) return '';
    // 期望格式：YYYY-MM-DD HH:mm:ss
    final parts = insertedAt.split(' ');
    if (parts.length < 2) return insertedAt;
    return parts[1];
  }

  List<List<Map<String, dynamic>>> _chunkEmotions(List<Map<String, dynamic>> src, int size) {
    if (src.isEmpty) return <List<Map<String, dynamic>>>[];
    final List<List<Map<String, dynamic>>> rows = [];
    for (var i = 0; i < src.length; i += size) {
      final end = (i + size < src.length) ? i + size : src.length;
      rows.add(src.sublist(i, end));
    }
    return rows;
  }

  Widget _buildTimelineRow(List<Map<String, dynamic>> rowItems) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 时间轴横线 + 表情在上方
          SizedBox(
            height: 36,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned.fill(
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      height: 1,
                      color: Colors.black26,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    for (final item in rowItems)
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Text(
                              (item['emoji_char'] ?? '').toString(),
                              style: const TextStyle(fontSize: 22),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          // 时间显示在横线下方
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              for (final item in rowItems)
                Text(
                  _formatTime(item['inserted_at']?.toString()),
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.black54,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTimeline(List<Map<String, dynamic>> items) {
    if (items.isEmpty) {
      return const Text(
        '今天还没有记录心情，回到首页试试分享你的此时此刻吧～',
        style: TextStyle(fontSize: 13, color: Colors.black54),
      );
    }
    final rows = _chunkEmotions(items, 4);
    // 计算是否需要垂直滚动：超过 3 行时开启
    final bool needScroll = rows.length > 3;

    final timelineColumn = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final r in rows) _buildTimelineRow(r),
      ],
    );

    if (!needScroll) {
      return timelineColumn;
    } else {
      return SizedBox(
        // 每行高度约 56 左右，3 行 + 边距
        height: 56.0 * 3,
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: timelineColumn,
        ),
      );
    }
  }



  Widget _buildEsteemFilterBar() {
    return Row(
      children: [
        Expanded(
          child: DropdownButton<String>(
            value: _esteemRangeKey,
            isExpanded: true,
            items: const [
              DropdownMenuItem(
                value: 'today',
                child: Text('今天'),
              ),
              DropdownMenuItem(
                value: '7d',
                child: Text('近7天'),
              ),
              DropdownMenuItem(
                value: '30d',
                child: Text('近30天'),
              ),
            ],
            onChanged: (value) {
              if (value == null) return;
              setState(() {
                _esteemRangeKey = value;
              });
              _reloadEsteemByFilter();
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: DropdownButton<String>(
            value: _esteemGranularityKey,
            isExpanded: true,
            items: const [
              DropdownMenuItem(
                value: 'record',
                child: Text('逐条记录'),
              ),
              DropdownMenuItem(
                value: 'hour',
                child: Text('按小时'),
              ),
              DropdownMenuItem(
                value: 'day',
                child: Text('按天'),
              ),
            ],
            onChanged: (value) {
              if (value == null) return;
              setState(() {
                _esteemGranularityKey = value;
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _buildEsteemLineChart() {
    final points = _buildEsteemPoints();
    if (points.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final spots = <FlSpot>[];
    for (var i = 0; i < points.length; i++) {
      spots.add(FlSpot(i.toDouble(), points[i].score));
    }

    double minY = points.first.score;
    double maxY = points.first.score;
    for (final p in points) {
      if (p.score < minY) minY = p.score;
      if (p.score > maxY) maxY = p.score;
    }
    double yMin = (minY - 5).clamp(0, 100).toDouble();
    double yMax = (maxY + 5).clamp(0, 100).toDouble();
    if (yMax <= yMin) {
      yMax = (yMin + 10).clamp(0, 100).toDouble();
    }

    String formatBottomLabel(int index) {
      if (index < 0 || index >= points.length) return '';
      final t = points[index].time;
      if (_esteemGranularityKey == 'day') {
        return '${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      } else if (_esteemGranularityKey == 'hour') {
        return '${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}\n${t.hour.toString().padLeft(2, '0')}:00';
      } else {
        return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
      }
    }

    return SizedBox(
      height: 220,
      child: LineChart(
        LineChartData(
          minX: 0,
          maxX: (points.length - 1).toDouble(),
          minY: yMin,
          maxY: yMax,
          gridData: FlGridData(show: true),
          borderData: FlBorderData(show: true),
          titlesData: FlTitlesData(
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                getTitlesWidget: (value, meta) {
                  return Text(
                    value.toInt().toString(),
                    style: const TextStyle(fontSize: 10),
                  );
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: points.length <= 6 ? 1 : (points.length / 6).ceilToDouble(),
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();
                  final label = formatBottomLabel(index);
                  if (label.isEmpty) {
                    return const SizedBox.shrink();
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      label,
                      style: const TextStyle(fontSize: 8),
                      textAlign: TextAlign.center,
                    ),
                  );
                },
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              spots: spots,
              dotData: FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEsteemStatsView() {
    final scores = _rawEsteemScores();
    final stats = _computeEsteemStats(scores);
    if (_esteemList.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Text(
          '当前时间范围内还没有足够的数据用于统计',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }
    String fmt(double v) => v.toStringAsFixed(1);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '中位数(P50)：${fmt(stats['p50'] ?? 0)}    平均值：${fmt(stats['avg'] ?? 0)}',
          style: const TextStyle(fontSize: 12),
        ),
        const SizedBox(height: 4),
        Text(
          'P90：${fmt(stats['p90'] ?? 0)}    P95：${fmt(stats['p95'] ?? 0)}',
          style: const TextStyle(fontSize: 12),
        ),
        const SizedBox(height: 4),
        Text(
          '最大值：${fmt(stats['max'] ?? 0)}    最小值：${fmt(stats['min'] ?? 0)}',
          style: const TextStyle(fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildEmotionPieChart() {
    if (_esteemList.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final Map<String, int> counts = {};
    for (final row in _esteemList) {
      final name = (row['emoji_name'] ?? '').toString();
      if (name.isEmpty) continue;
      counts[name] = (counts[name] ?? 0) + 1;
    }
    if (counts.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          '当前时间范围内还没有情绪记录',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      );
    }

    final total = counts.values.fold<int>(0, (a, b) => a + b);
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final sections = <PieChartSectionData>[];
    for (var i = 0; i < entries.length; i++) {
      final e = entries[i];
      final double percent = total == 0 ? 0 : (e.value * 100.0 / total);
      sections.add(
        PieChartSectionData(
          value: e.value.toDouble(),
          title: '${e.key}\n${percent.toStringAsFixed(0)}%',
          radius: 40,
          titleStyle: const TextStyle(fontSize: 10),
        ),
      );
    }

    return SizedBox(
      height: 220,
      child: PieChart(
        PieChartData(
          sections: sections,
          sectionsSpace: 2,
          centerSpaceRadius: 0,
        ),
      ),
    );
  }

  Widget _buildEsteemAnalyticsCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7F7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '自尊分析',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          _buildEsteemFilterBar(),
          const SizedBox(height: 8),
          _buildEsteemLineChart(),
          const SizedBox(height: 8),
          _buildEsteemStatsView(),
          const SizedBox(height: 16),
          const Text(
            '自尊得分根据情绪在「正向 / 负向 + 与自尊相关程度」两维度上的加权平均得到，'
            '积极、自我肯定情绪（如自信、胜利）会提高得分，羞愧、自卑等自我意识负性情绪会拉低得分；'
            '当找不到对应情绪定义时，会使用中性得分 50。',
            style: TextStyle(fontSize: 11, color: Colors.black54),
          ),
          const SizedBox(height: 12),
          const Text(
            '情绪分布（百分比）',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          _buildEmotionPieChart(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final latest = _latestToday;
    final String moodLine;
    if (latest == null) {
      moodLine = '当下心情：今天还没有记录心情';
    } else {
      final name = (latest['emoji_name'] ?? '').toString();
      final char = (latest['emoji_char'] ?? '').toString();
      moodLine = '当下心情：$name $char';
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text(
          '发现之旅',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: _loading && _todayList.isEmpty && _latestToday == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 15),
                          // 当下心情文本
                          Text(
                            moodLine,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          // 当天所有情绪图标 + 时间轴
                          _buildTimeline(_todayList),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildEsteemAnalyticsCard(),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.assignment_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '问卷调查',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.flag_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '愿景与目标',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.self_improvement, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '冥想',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7F7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.note_outlined, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '记事本',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}