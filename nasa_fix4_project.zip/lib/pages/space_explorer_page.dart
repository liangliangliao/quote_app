import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../services/nasa_api_service.dart';
import 'apod_detail_page.dart';
import 'epic_image_detail_page.dart';
import 'nasa_media_detail_page.dart';

/// "看宇宙" 页面：
/// - 每日 APOD（支持日期范围筛选、50 条分页、下拉加载）
/// - 图像搜索（支持日期范围筛选、50 条分页、下拉加载）
/// - 探测器照片（基于 NASA Image & Video Library，支持日期范围筛选、50 条分页、下拉加载）
/// - 火星照片（优先使用 Image & Video Library 的火星相关真实照片，避免 Mars-Rover API 404 波动）
/// - EPIC 地球（支持日期范围筛选，按天回溯加载，50 条分页）
/// - 地球影像（Earth Assets：按经纬度 + 日期范围返回可用影像列表，50 条分页）
class SpaceExplorerPage extends StatefulWidget {
  const SpaceExplorerPage({super.key});

  @override
  State<SpaceExplorerPage> createState() => _SpaceExplorerPageState();
}

class _SpaceExplorerPageState extends State<SpaceExplorerPage>
    with SingleTickerProviderStateMixin {
  // NASA API Key
  static const String _nasaApiKey = 'yl0Zwzo2DiDT6BvM3ITCieFjuiGhhgjFvak56sRS';
  static const String _nasaProxy =
      String.fromEnvironment('NASA_PROXY', defaultValue: '');

  late final NasaApiService _service;
  late final TabController _tabController;

  // -------------------- Common helpers --------------------
  String _fmt(DateTime d) {
    final y = d.year.toString().padLeft(4, '0');
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '$y-$m-$day';
  }

  Future<DateTime?> _pickDate(DateTime initial, DateTime first, DateTime last) {
    return showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: last,
    );
  }

  // -------------------- APOD (paged by 50 days) --------------------
  final ScrollController _apodScroll = ScrollController();
  List<Apod> _apods = [];
  bool _apodLoading = false;
  bool _apodLoadingMore = false;
  bool _apodHasMore = true;
  String? _apodError;
  late DateTime _apodEndBound;
  late DateTime _apodStartBound;
  late DateTime _apodCursorEnd;

  // -------------------- Image search (paged by 50 using buffer) --------------------
  final ScrollController _searchScroll = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  List<NasaMediaItem> _searchShown = [];
  final List<NasaMediaItem> _searchBuffer = [];
  bool _searchLoading = false;
  bool _searchLoadingMore = false;
  bool _searchHasMore = true;
  String? _searchError;
  int _searchPage = 1;
  late DateTime _searchStart;
  late DateTime _searchEnd;

  // -------------------- Probe photos tab (same as search) --------------------
  final ScrollController _probeScroll = ScrollController();
  final TextEditingController _probeQueryController =
      TextEditingController(text: 'spacecraft');
  List<NasaMediaItem> _probeShown = [];
  final List<NasaMediaItem> _probeBuffer = [];
  bool _probeLoading = false;
  bool _probeLoadingMore = false;
  bool _probeHasMore = true;
  String? _probeError;
  int _probePage = 1;
  late DateTime _probeStart;
  late DateTime _probeEnd;

  // -------------------- Mars photos tab (use images-api) --------------------
  final ScrollController _marsScroll = ScrollController();
  String _marsPreset = 'Mars rover';
  List<NasaMediaItem> _marsShown = [];
  final List<NasaMediaItem> _marsBuffer = [];
  bool _marsLoading = false;
  bool _marsLoadingMore = false;
  bool _marsHasMore = true;
  String? _marsError;
  int _marsPage = 1;
  late DateTime _marsStart;
  late DateTime _marsEnd;

  // -------------------- EPIC (paged by dates) --------------------
  final ScrollController _epicScroll = ScrollController();
  List<EpicImage> _epicImages = [];
  bool _epicLoading = false;
  bool _epicLoadingMore = false;
  bool _epicHasMore = true;
  String? _epicError;
  late DateTime _epicStart;
  late DateTime _epicEnd;
  late DateTime _epicCursor;

  // -------------------- Earth imagery assets (list + paging) --------------------
  final ScrollController _earthScroll = ScrollController();
  final TextEditingController _latController = TextEditingController(text: '31.2304');
  final TextEditingController _lonController = TextEditingController(text: '121.4737');
  late DateTime _earthStart;
  late DateTime _earthEnd;
  List<EarthImage> _earthAll = [];
  List<EarthImage> _earthShown = [];
  bool _earthLoading = false;
  bool _earthLoadingMore = false;
  bool _earthHasMore = true;
  String? _earthError;
  int _earthShownCount = 0;

  @override
  void initState() {
    super.initState();
    _service = NasaApiService(
      apiKey: _nasaApiKey,
      proxyUrl: _nasaProxy.isEmpty ? null : _nasaProxy,
      allowBadCertificates: true,
    );

    _tabController = TabController(length: 6, vsync: this);

    final now = DateTime.now();
    // 默认：过去 1 年范围（用户可自行调整）
    _apodEndBound = now;
    _apodStartBound = now.subtract(const Duration(days: 365));
    _apodCursorEnd = _apodEndBound;

    _searchEnd = now;
    _searchStart = now.subtract(const Duration(days: 365));

    _probeEnd = now;
    _probeStart = now.subtract(const Duration(days: 365));

    _marsEnd = now;
    _marsStart = now.subtract(const Duration(days: 365));

    _epicEnd = now;
    _epicStart = now.subtract(const Duration(days: 30));
    _epicCursor = _epicEnd;

    _earthEnd = now;
    _earthStart = now.subtract(const Duration(days: 30));

    _apodScroll.addListener(() {
      if (_apodHasMore && !_apodLoadingMore && _apodScroll.position.pixels > _apodScroll.position.maxScrollExtent - 400) {
        _loadApodMore();
      }
    });
    _searchScroll.addListener(() {
      if (_searchHasMore && !_searchLoadingMore && _searchScroll.position.pixels > _searchScroll.position.maxScrollExtent - 400) {
        _loadSearchMore();
      }
    });
    _probeScroll.addListener(() {
      if (_probeHasMore && !_probeLoadingMore && _probeScroll.position.pixels > _probeScroll.position.maxScrollExtent - 400) {
        _loadProbeMore();
      }
    });
    _marsScroll.addListener(() {
      if (_marsHasMore && !_marsLoadingMore && _marsScroll.position.pixels > _marsScroll.position.maxScrollExtent - 400) {
        _loadMarsMore();
      }
    });
    _epicScroll.addListener(() {
      if (_epicHasMore && !_epicLoadingMore && _epicScroll.position.pixels > _epicScroll.position.maxScrollExtent - 400) {
        _loadEpicMore();
      }
    });
    _earthScroll.addListener(() {
      if (_earthHasMore && !_earthLoadingMore && _earthScroll.position.pixels > _earthScroll.position.maxScrollExtent - 400) {
        _loadEarthMore();
      }
    });

    _loadApodInitial();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _apodScroll.dispose();
    _searchScroll.dispose();
    _probeScroll.dispose();
    _marsScroll.dispose();
    _epicScroll.dispose();
    _earthScroll.dispose();
    _searchController.dispose();
    _probeQueryController.dispose();
    _latController.dispose();
    _lonController.dispose();
    super.dispose();
  }

  // -------------------- APOD loaders --------------------
  Future<void> _loadApodInitial() async {
    setState(() {
      _apodLoading = true;
      _apodError = null;
      _apods = [];
      _apodCursorEnd = _apodEndBound;
      _apodHasMore = true;
    });
    try {
      await _loadApodMore(initial: true);
    } finally {
      if (mounted) {
        setState(() {
          _apodLoading = false;
        });
      }
    }
  }

  Future<void> _loadApodMore({bool initial = false}) async {
    if (!_apodHasMore) return;
    if (!initial) {
      setState(() {
        _apodLoadingMore = true;
      });
    } else {
      _apodLoadingMore = true;
    }
    try {
      var end = _apodCursorEnd;
      if (end.isBefore(_apodStartBound)) {
        setState(() => _apodHasMore = false);
        return;
      }
      var start = end.subtract(const Duration(days: 49));
      if (start.isBefore(_apodStartBound)) start = _apodStartBound;

      final batch = await _service.fetchApods(startDate: start, endDate: end);
      batch.sort((a, b) => b.date.compareTo(a.date));

      // 过滤非图片项：用户需求主要是“图片显示”
      final images = batch.where((e) => e.mediaType == 'image' && e.url.isNotEmpty).toList();
      if (mounted) {
        setState(() {
          _apods.addAll(images);
        });
      }

      // 下一页：往更早的日期
      _apodCursorEnd = start.subtract(const Duration(days: 1));
      if (_apodCursorEnd.isBefore(_apodStartBound)) {
        setState(() => _apodHasMore = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _apodError = e.toString();
          _apodHasMore = false;
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _apodLoadingMore = false;
        });
      }
    }
  }

  // -------------------- Search / Probe / Mars loaders (50 items with buffer) --------------------
  Future<void> _resetAndSearch() async {
    setState(() {
      _searchShown = [];
      _searchBuffer.clear();
      _searchPage = 1;
      _searchHasMore = true;
      _searchError = null;
      _searchLoading = true;
    });
    try {
      await _loadSearchMore(initial: true);
    } finally {
      if (mounted) setState(() => _searchLoading = false);
    }
  }

  Future<void> _loadSearchMore({bool initial = false}) async {
    final q = _searchController.text.trim();
    if (q.isEmpty) return;
    if (!_searchHasMore) return;
    if (!initial) setState(() => _searchLoadingMore = true);
    try {
      // 先把 buffer 的内容填到 50
      while (_searchBuffer.length < 50) {
        final res = await _service.searchMedia(
          query: q,
          mediaType: 'image',
          page: _searchPage,
          startDate: _searchStart,
          endDate: _searchEnd,
        );
        _searchPage++;
        if (res.isEmpty) {
          _searchHasMore = false;
          break;
        }
        _searchBuffer.addAll(res.where((e) => e.thumbUrl.isNotEmpty || e.mediaUrl.isNotEmpty));
        // 避免无限循环
        if (_searchPage > 50) break;
      }
      final take = _searchBuffer.take(50).toList();
      _searchBuffer.removeRange(0, take.length);
      if (mounted) setState(() => _searchShown.addAll(take));
      if (take.isEmpty) _searchHasMore = false;
    } catch (e) {
      if (mounted) {
        setState(() {
          _searchError = e.toString();
          _searchHasMore = false;
        });
      }
    } finally {
      if (mounted) setState(() => _searchLoadingMore = false);
    }
  }

  Future<void> _resetAndLoadProbe() async {
    setState(() {
      _probeShown = [];
      _probeBuffer.clear();
      _probePage = 1;
      _probeHasMore = true;
      _probeError = null;
      _probeLoading = true;
    });
    try {
      await _loadProbeMore(initial: true);
    } finally {
      if (mounted) setState(() => _probeLoading = false);
    }
  }

  Future<void> _loadProbeMore({bool initial = false}) async {
    final q = _probeQueryController.text.trim();
    if (q.isEmpty) return;
    if (!_probeHasMore) return;
    if (!initial) setState(() => _probeLoadingMore = true);
    try {
      while (_probeBuffer.length < 50) {
        final res = await _service.searchMedia(
          query: q,
          mediaType: 'image',
          page: _probePage,
          startDate: _probeStart,
          endDate: _probeEnd,
        );
        _probePage++;
        if (res.isEmpty) {
          _probeHasMore = false;
          break;
        }
        _probeBuffer.addAll(res);
        if (_probePage > 50) break;
      }
      final take = _probeBuffer.take(50).toList();
      _probeBuffer.removeRange(0, take.length);
      if (mounted) setState(() => _probeShown.addAll(take));
      if (take.isEmpty) _probeHasMore = false;
    } catch (e) {
      if (mounted) {
        setState(() {
          _probeError = e.toString();
          _probeHasMore = false;
        });
      }
    } finally {
      if (mounted) setState(() => _probeLoadingMore = false);
    }
  }

  Future<void> _resetAndLoadMars() async {
    setState(() {
      _marsShown = [];
      _marsBuffer.clear();
      _marsPage = 1;
      _marsHasMore = true;
      _marsError = null;
      _marsLoading = true;
    });
    try {
      await _loadMarsMore(initial: true);
    } finally {
      if (mounted) setState(() => _marsLoading = false);
    }
  }

  Future<void> _loadMarsMore({bool initial = false}) async {
    if (!_marsHasMore) return;
    if (!initial) setState(() => _marsLoadingMore = true);
    try {
      while (_marsBuffer.length < 50) {
        final res = await _service.searchMedia(
          query: _marsPreset,
          mediaType: 'image',
          page: _marsPage,
          startDate: _marsStart,
          endDate: _marsEnd,
        );
        _marsPage++;
        if (res.isEmpty) {
          _marsHasMore = false;
          break;
        }
        _marsBuffer.addAll(res);
        if (_marsPage > 50) break;
      }
      final take = _marsBuffer.take(50).toList();
      _marsBuffer.removeRange(0, take.length);
      if (mounted) setState(() => _marsShown.addAll(take));
      if (take.isEmpty) _marsHasMore = false;
    } catch (e) {
      if (mounted) {
        setState(() {
          _marsError = e.toString();
          _marsHasMore = false;
        });
      }
    } finally {
      if (mounted) setState(() => _marsLoadingMore = false);
    }
  }

  // -------------------- EPIC loaders --------------------
  Future<void> _resetAndLoadEpic() async {
    setState(() {
      _epicImages = [];
      _epicCursor = _epicEnd;
      _epicHasMore = true;
      _epicError = null;
      _epicLoading = true;
    });
    try {
      await _loadEpicMore(initial: true);
    } finally {
      if (mounted) setState(() => _epicLoading = false);
    }
  }

  Future<void> _loadEpicMore({bool initial = false}) async {
    if (!_epicHasMore) return;
    if (!initial) setState(() => _epicLoadingMore = true);
    try {
      final out = <EpicImage>[];
      var cursor = _epicCursor;
      while (out.length < 50) {
        if (cursor.isBefore(_epicStart)) {
          _epicHasMore = false;
          break;
        }
        try {
          final day = await _service.fetchEpicImagesForDate(date: cursor, natural: true);
          out.addAll(day);
        } catch (_) {
          // 某些日期可能没有数据，继续回溯
        }
        cursor = cursor.subtract(const Duration(days: 1));
      }
      _epicCursor = cursor;
      if (mounted) setState(() => _epicImages.addAll(out));
      if (out.isEmpty) _epicHasMore = false;
    } catch (e) {
      if (mounted) {
        setState(() {
          _epicError = e.toString();
          _epicHasMore = false;
        });
      }
    } finally {
      if (mounted) setState(() => _epicLoadingMore = false);
    }
  }

  // -------------------- Earth imagery loaders --------------------
  Future<void> _resetAndLoadEarthAssets() async {
    final lat = double.tryParse(_latController.text.trim());
    final lon = double.tryParse(_lonController.text.trim());
    if (lat == null || lon == null) {
      setState(() => _earthError = '请输入有效的经纬度');
      return;
    }
    if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      setState(() => _earthError = '经纬度范围：lat ∈ [-90, 90]，lon ∈ [-180, 180]');
      return;
    }
    setState(() {
      _earthLoading = true;
      _earthError = null;
      _earthAll = [];
      _earthShown = [];
      _earthShownCount = 0;
      _earthHasMore = true;
    });
    try {
      final list = await _service.fetchEarthAssetsRange(
        lat: lat,
        lon: lon,
        begin: _earthStart,
        end: _earthEnd,
      );
      if (mounted) {
        setState(() {
          _earthAll = list;
        });
      }
      _loadEarthMore(initial: true);
    } catch (e) {
      if (mounted) {
        setState(() {
          _earthError = e.toString();
          _earthHasMore = false;
        });
      }
    } finally {
      if (mounted) setState(() => _earthLoading = false);
    }
  }

  void _loadEarthMore({bool initial = false}) {
    if (!_earthHasMore) return;
    if (!initial) setState(() => _earthLoadingMore = true);
    final next = (_earthShownCount + 50).clamp(0, _earthAll.length);
    final add = _earthAll.sublist(_earthShownCount, next);
    _earthShownCount = next;
    if (mounted) {
      setState(() {
        _earthShown.addAll(add);
        _earthHasMore = _earthShownCount < _earthAll.length;
        _earthLoadingMore = false;
      });
    }
  }

  // -------------------- UI --------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('看宇宙', style: TextStyle(color: Colors.black87)),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Transform.translate(
            // 需求：第一个 tab 整体左移 45dp（30 + 15）
            offset: const Offset(-45, 0),
            child: TabBar(
              controller: _tabController,
              isScrollable: true,
              padding: EdgeInsets.zero,
              labelPadding: const EdgeInsets.symmetric(horizontal: 13),
              indicatorPadding: EdgeInsets.zero,
              indicatorColor: Colors.blueAccent,
              labelColor: Colors.blueAccent,
              unselectedLabelColor: Colors.black54,
              onTap: (i) {
                // 首次进入时自动加载
                if (i == 4 && _epicImages.isEmpty && !_epicLoading) {
                  _resetAndLoadEpic();
                }
              },
              tabs: const [
                Tab(text: '每日APOD'),
                Tab(text: '图像搜索'),
                Tab(text: '探测器照片'),
                Tab(text: '火星照片'),
                Tab(text: 'EPIC地球'),
                Tab(text: '地球影像'),
              ],
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildApodTab(),
          _buildSearchTab(),
          _buildProbeTab(),
          _buildMarsTab(),
          _buildEpicTab(),
          _buildEarthTab(),
        ],
      ),
    );
  }

  Widget _buildDateRangeBar({
    required DateTime start,
    required DateTime end,
    required VoidCallback onPickStart,
    required VoidCallback onPickEnd,
    required VoidCallback onApply,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Row(
        children: [
          const Text('开始:'),
          const SizedBox(width: 6),
          InkWell(
            onTap: onPickStart,
            child: Row(
              children: [
                Text(_fmt(start), style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(width: 4),
                const Icon(Icons.calendar_month, size: 18),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Text('结束:'),
          const SizedBox(width: 6),
          InkWell(
            onTap: onPickEnd,
            child: Row(
              children: [
                Text(_fmt(end), style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(width: 4),
                const Icon(Icons.calendar_month, size: 18),
              ],
            ),
          ),
          const Spacer(),
          TextButton(onPressed: onApply, child: const Text('应用')),
        ],
      ),
    );
  }

  Widget _buildError(String title, String msg, VoidCallback onRetry) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('$title\n$msg', textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: onRetry, child: const Text('重试')),
          ],
        ),
      ),
    );
  }

  Widget _buildMediaList(
    ScrollController controller,
    List<NasaMediaItem> items, {
    bool showLoadingMore = false,
  }) {
    return ListView.separated(
      controller: controller,
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: items.length + (showLoadingMore ? 1 : 0),
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, idx) {
        if (idx >= items.length) {
          return const Padding(
            padding: EdgeInsets.all(16.0),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final it = items[idx];
        final thumb = it.thumbUrl.isNotEmpty ? it.thumbUrl : it.mediaUrl;
        return ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: thumb.isEmpty
                ? const SizedBox(width: 64, height: 64, child: Icon(Icons.image_not_supported))
                : Image.network(
                    thumb,
                    width: 64,
                    height: 64,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox(
                      width: 64,
                      height: 64,
                      child: Center(child: Icon(Icons.broken_image)),
                    ),
                  ),
          ),
          title: Text(it.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(it.date.isEmpty ? '' : it.date.split('T').first),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.of(context).push(
              CupertinoPageRoute(builder: (_) => NasaMediaDetailPage(item: it)),
            );
          },
        );
      },
    );
  }

  // -------------------- Tabs --------------------
  Widget _buildApodTab() {
    if (_apodLoading && _apods.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_apodError != null && _apods.isEmpty) {
      return _buildError('加载天文图失败', _apodError!, _loadApodInitial);
    }
    return Column(
      children: [
        _buildDateRangeBar(
          start: _apodStartBound,
          end: _apodEndBound,
          onPickStart: () async {
            final picked = await _pickDate(_apodStartBound, DateTime(1995, 6, 16), _apodEndBound);
            if (picked == null) return;
            setState(() => _apodStartBound = picked);
          },
          onPickEnd: () async {
            final picked = await _pickDate(_apodEndBound, _apodStartBound, DateTime.now());
            if (picked == null) return;
            setState(() => _apodEndBound = picked);
          },
          onApply: _loadApodInitial,
        ),
        const Divider(height: 1),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _loadApodInitial,
            child: ListView.separated(
              controller: _apodScroll,
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: _apods.length + (_apodLoadingMore ? 1 : 0),
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, idx) {
                if (idx >= _apods.length) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final a = _apods[idx];
                return ListTile(
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      a.url,
                      width: 64,
                      height: 64,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const SizedBox(
                        width: 64,
                        height: 64,
                        child: Center(child: Icon(Icons.broken_image)),
                      ),
                    ),
                  ),
                  title: Text(a.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(a.date),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).push(
                      CupertinoPageRoute(builder: (_) => ApodDetailPage(apod: a)),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: '输入关键词（如 moon, nebula, galaxy）',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        setState(() {
                          _searchShown = [];
                          _searchBuffer.clear();
                          _searchError = null;
                          _searchHasMore = true;
                          _searchPage = 1;
                        });
                      },
                    )
                  : null,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onSubmitted: (_) => _resetAndSearch(),
          ),
        ),
        _buildDateRangeBar(
          start: _searchStart,
          end: _searchEnd,
          onPickStart: () async {
            final picked = await _pickDate(_searchStart, DateTime(1900, 1, 1), _searchEnd);
            if (picked == null) return;
            setState(() => _searchStart = picked);
          },
          onPickEnd: () async {
            final picked = await _pickDate(_searchEnd, _searchStart, DateTime.now());
            if (picked == null) return;
            setState(() => _searchEnd = picked);
          },
          onApply: _resetAndSearch,
        ),
        const Divider(height: 1),
        Expanded(
          child: _searchLoading && _searchShown.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : (_searchError != null && _searchShown.isEmpty)
                  ? _buildError('搜索失败', _searchError!, _resetAndSearch)
                  : RefreshIndicator(
                      onRefresh: _resetAndSearch,
                      child: _buildMediaList(
                        _searchScroll,
                        _searchShown,
                        showLoadingMore: _searchLoadingMore,
                      ),
                    ),
        ),
      ],
    );
  }

  Widget _buildProbeTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: TextField(
            controller: _probeQueryController,
            decoration: InputDecoration(
              hintText: '探测器/任务关键词（如 voyager, cassini, juno, new horizons）',
              prefixIcon: const Icon(Icons.public),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onSubmitted: (_) => _resetAndLoadProbe(),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Wrap(
            spacing: 8,
            children: [
              _chip('Voyager', 'voyager'),
              _chip('Cassini', 'cassini'),
              _chip('Juno', 'juno'),
              _chip('New Horizons', 'new horizons'),
              _chip('Hubble', 'hubble'),
            ],
          ),
        ),
        _buildDateRangeBar(
          start: _probeStart,
          end: _probeEnd,
          onPickStart: () async {
            final picked = await _pickDate(_probeStart, DateTime(1900, 1, 1), _probeEnd);
            if (picked == null) return;
            setState(() => _probeStart = picked);
          },
          onPickEnd: () async {
            final picked = await _pickDate(_probeEnd, _probeStart, DateTime.now());
            if (picked == null) return;
            setState(() => _probeEnd = picked);
          },
          onApply: _resetAndLoadProbe,
        ),
        const Divider(height: 1),
        Expanded(
          child: _probeLoading && _probeShown.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : (_probeError != null && _probeShown.isEmpty)
                  ? _buildError('加载失败', _probeError!, _resetAndLoadProbe)
                  : RefreshIndicator(
                      onRefresh: _resetAndLoadProbe,
                      child: _buildMediaList(
                        _probeScroll,
                        _probeShown,
                        showLoadingMore: _probeLoadingMore,
                      ),
                    ),
        ),
      ],
    );
  }

  Widget _chip(String label, String q) {
    return ActionChip(
      label: Text(label),
      onPressed: () {
        _probeQueryController.text = q;
        _resetAndLoadProbe();
      },
    );
  }

  Widget _buildMarsTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: Row(
            children: [
              const Text('类别:'),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: _marsPreset,
                items: const [
                  DropdownMenuItem(value: 'Mars rover', child: Text('火星车实拍')),
                  DropdownMenuItem(value: 'Mars surface', child: Text('火星地表')),
                  DropdownMenuItem(value: 'Curiosity rover', child: Text('Curiosity')),
                  DropdownMenuItem(value: 'Perseverance rover', child: Text('Perseverance')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _marsPreset = v);
                  _resetAndLoadMars();
                },
              ),
              const Spacer(),
              TextButton(onPressed: _resetAndLoadMars, child: const Text('加载')),
            ],
          ),
        ),
        _buildDateRangeBar(
          start: _marsStart,
          end: _marsEnd,
          onPickStart: () async {
            final picked = await _pickDate(_marsStart, DateTime(1900, 1, 1), _marsEnd);
            if (picked == null) return;
            setState(() => _marsStart = picked);
          },
          onPickEnd: () async {
            final picked = await _pickDate(_marsEnd, _marsStart, DateTime.now());
            if (picked == null) return;
            setState(() => _marsEnd = picked);
          },
          onApply: _resetAndLoadMars,
        ),
        const Divider(height: 1),
        Expanded(
          child: _marsLoading && _marsShown.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : (_marsError != null && _marsShown.isEmpty)
                  ? _buildError('加载失败', _marsError!, _resetAndLoadMars)
                  : RefreshIndicator(
                      onRefresh: _resetAndLoadMars,
                      child: _buildMediaList(
                        _marsScroll,
                        _marsShown,
                        showLoadingMore: _marsLoadingMore,
                      ),
                    ),
        ),
      ],
    );
  }

  Widget _buildEpicTab() {
    if (_epicLoading && _epicImages.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_epicError != null && _epicImages.isEmpty) {
      return _buildError('加载 EPIC 失败', _epicError!, _resetAndLoadEpic);
    }
    return Column(
      children: [
        _buildDateRangeBar(
          start: _epicStart,
          end: _epicEnd,
          onPickStart: () async {
            final picked = await _pickDate(_epicStart, DateTime(2015, 1, 1), _epicEnd);
            if (picked == null) return;
            setState(() => _epicStart = picked);
          },
          onPickEnd: () async {
            final picked = await _pickDate(_epicEnd, _epicStart, DateTime.now());
            if (picked == null) return;
            setState(() => _epicEnd = picked);
          },
          onApply: _resetAndLoadEpic,
        ),
        const Divider(height: 1),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _resetAndLoadEpic,
            child: ListView.separated(
              controller: _epicScroll,
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: _epicImages.length + (_epicLoadingMore ? 1 : 0),
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, idx) {
                if (idx >= _epicImages.length) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final e = _epicImages[idx];
                return ListTile(
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      e.url,
                      width: 64,
                      height: 64,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const SizedBox(
                        width: 64,
                        height: 64,
                        child: Center(child: Icon(Icons.broken_image)),
                      ),
                    ),
                  ),
                  title: Text(e.caption.isEmpty ? 'EPIC 图像' : e.caption,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(e.date.split(' ').first),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).push(
                      CupertinoPageRoute(builder: (_) => EpicImageDetailPage(image: e)),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEarthTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('获取地球卫星影像（按经纬度 + 日期范围）',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              TextField(
                controller: _latController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: '纬度 (lat)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _lonController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: '经度 (lon)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 6),
            ],
          ),
        ),
        _buildDateRangeBar(
          start: _earthStart,
          end: _earthEnd,
          onPickStart: () async {
            final picked = await _pickDate(_earthStart, DateTime(2000, 1, 1), _earthEnd);
            if (picked == null) return;
            setState(() => _earthStart = picked);
          },
          onPickEnd: () async {
            final picked = await _pickDate(_earthEnd, _earthStart, DateTime.now());
            if (picked == null) return;
            setState(() => _earthEnd = picked);
          },
          onApply: _resetAndLoadEarthAssets,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Row(
            children: [
              ElevatedButton(
                onPressed: _earthLoading ? null : _resetAndLoadEarthAssets,
                child: const Text('获取列表'),
              ),
              const SizedBox(width: 12),
              if (_earthLoading) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
              const Spacer(),
              Text('共 ${_earthAll.length} 条'),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: (_earthError != null && _earthShown.isEmpty)
              ? _buildError('获取失败', _earthError!, _resetAndLoadEarthAssets)
              : RefreshIndicator(
                  onRefresh: _resetAndLoadEarthAssets,
                  child: ListView.separated(
                    controller: _earthScroll,
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: _earthShown.length + (_earthLoadingMore ? 1 : 0),
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, idx) {
                      if (idx >= _earthShown.length) {
                        return const Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Center(child: CircularProgressIndicator()),
                        );
                      }
                      final it = _earthShown[idx];
                      return ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            it.url,
                            width: 64,
                            height: 64,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const SizedBox(
                              width: 64,
                              height: 64,
                              child: Center(child: Icon(Icons.broken_image)),
                            ),
                          ),
                        ),
                        title: Text('日期：${it.date}'),
                        subtitle: Text('id: ${it.id}'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          Navigator.of(context).push(
                            CupertinoPageRoute(
                              builder: (_) => _SimpleImagePage(title: '地球影像 ${it.date}', url: it.url),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }
}

class _SimpleImagePage extends StatelessWidget {
  final String title;
  final String url;

  const _SimpleImagePage({required this.title, required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: InteractiveViewer(
          child: Image.network(
            url,
            errorBuilder: (_, __, ___) => const Padding(
              padding: EdgeInsets.all(24.0),
              child: Text('图片加载失败，请检查网络后重试。'),
            ),
          ),
        ),
      ),
    );
  }
}
