import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:audioplayers/audioplayers.dart';

import '../data/db.dart';
import 'diary_dao.dart';
import 'tag_picker_page.dart';
import 'weather.dart';
import 'diary_text_controller.dart';

class EntryEditorPage extends StatefulWidget {
  final int notebookId;
  final int? entryId;
  const EntryEditorPage({super.key, required this.notebookId, this.entryId});

  @override
  State<EntryEditorPage> createState() => _EntryEditorPageState();
}

class _EntryEditorPageState extends State<EntryEditorPage> {
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy年MM月dd日 HH:mm');
  final _textCtrl = DiaryContentController();

  int _entryId = 0;
  DateTime _time = DateTime.now();
  int? _weatherCode;
  String? _moodName;
  String? _moodIcon;
  bool _starred = false;

  bool _dirty = false;

  String _lastText = '';
  TextSelection _lastSel = const TextSelection.collapsed(offset: 0);


  String? _bgPath;
  final FocusNode _focusNode = FocusNode();
  final ScrollController _contentScrollController = ScrollController();

  final GlobalKey _textBoxKey = GlobalKey();

  double _bgOpacity = 0.25;

  final List<int> _tagIds = [];
  final Map<int, String> _tagNameById = {};

  @override
  void initState() {
    super.initState();
    _textCtrl.addListener(() { if (mounted) setState(() {}); });
    _bootstrap();
    _textCtrl.addListener(() {
      if (!_dirty) setState(() => _dirty = true);
    });
  }

  @override
  @override
  void dispose() {
    _contentScrollController.dispose();
    _focusNode.dispose();
    _textCtrl.dispose();
    super.dispose();
  }

  Future<void> _bootstrap() async {
    // config: diary bg image & opacity
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        final img = rows.first['diary_bg_image'];
        _bgPath = img == null ? null : img.toString();
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
    } catch (_) {}

    // recent mood from emotions
    try {
      final rows = await db.query('emotions', orderBy: 'inserted_at DESC', limit: 1);
      if (rows.isNotEmpty) {
        _moodName = (rows.first['emoji_name'] ?? '').toString();
        _moodIcon = (rows.first['emoji_char'] ?? '').toString();
      }
    } catch (_) {}

    await _dao.ensureSchema();

    if (widget.entryId != null) {
      final e = await _dao.getEntry(widget.entryId!);
      if (e != null) {
        _entryId = e.id;
        _time = DateTime.fromMillisecondsSinceEpoch(e.entryTime);
        _weatherCode = e.weatherCode;
        _moodName = e.moodName ?? _moodName;
        _moodIcon = e.moodIcon ?? _moodIcon;
        _textCtrl.text = e.content;
        _starred = (e.starred == 1);

        final tags = await _dao.tagsForEntry(e.id);
        _tagIds
          ..clear()
          ..addAll(tags.map((t) => t.id));
        for (final t in tags) {
          _tagNameById[t.id] = t.name;
        }
      }
    }

    // If no entryId, keep defaults but build tag name map for future display
    await _refreshTagNameMap();

    if (mounted) setState(() {});
  }

  Future<void> _refreshTagNameMap() async {
    try {
      final all = await _dao.listTags();
      for (final t in all) {
        _tagNameById[t.id] = t.name;
      }
    } catch (_) {}
  }

  String _preview(String content) {
    final lines = content.split(RegExp(r'\r?\n'));
    for (final raw in lines) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      if (line.startsWith('[图片]') || line.startsWith('[语音]')) continue;
      return line.length > 50 ? line.substring(0, 50) : line;
    }
    return '（空白日记）';
  }

  Future<void> _save() async {
    if (!_dirty) return;

    final w = weatherByCode(_weatherCode);
    final e = DiaryEntry(
      id: _entryId,
      notebookId: widget.notebookId,
      entryTime: _time.millisecondsSinceEpoch,
      weatherCode: _weatherCode,
      weatherName: _weatherCode == null ? null : w.name,
      moodName: _moodName,
      moodIcon: _moodIcon,
      content: _textCtrl.text,
      preview: _preview(_textCtrl.text),
      starred: _starred ? 1 : 0,
    );
    final id = await _dao.upsertEntry(e);
    await _dao.touchNotebook(widget.notebookId);
    await _dao.setTagsForEntry(id, _tagIds);

    if (!mounted) return;
    Navigator.pop(context, id);
  }

  Future<void> _cancel() async {
    if (!_dirty) {
      Navigator.pop(context);
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('放弃未保存内容？'),
        content: const Text('你有修改尚未保存，确定要退出吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('继续编辑')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('放弃')),
        ],
      ),
    );
    if (ok == true && mounted) Navigator.pop(context);
  }

  Future<void> _pickTime() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _time,
      firstDate: DateTime(2000, 1, 1),
      lastDate: DateTime(DateTime.now().year + 1),
    );
    if (d == null) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_time));
    if (t == null) return;
    setState(() {
      _time = DateTime(d.year, d.month, d.day, t.hour, t.minute);
      _dirty = true;
    });
  }

  Future<void> _pickTags() async {
    final res = await Navigator.push<List<int>?>(
      context,
      MaterialPageRoute(builder: (_) => TagPickerPage(dao: _dao, initialSelected: _tagIds)),
    );
    if (res == null) return;
    setState(() {
      _tagIds
        ..clear()
        ..addAll(res);
      _dirty = true;
    });
    await _refreshTagNameMap();
    if (mounted) setState(() {});
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.white),
        Opacity(opacity: (1.0 - _bgOpacity).clamp(0.0, 1.0), child: Image.file(f, fit: BoxFit.contain)),
        child,
      ],
    );
  }

  @override
  
  
  Future<void> _insertImage() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;

    // 在当前光标所在位置插入一行图片标记，保证插入行为与用户编辑位置一致。
    final text = _textCtrl.text;
    final sel = _textCtrl.selection;
    int offset = sel.isValid ? sel.baseOffset : text.length;
    if (offset < 0 || offset > text.length) {
      offset = text.length;
    }

    final String markerLine = '[图片] ' + path;
    String prefix = text.substring(0, offset);
    String suffix = text.substring(offset);

    // 确保图片标记单独占一行：如果前面不是换行则补一个换行。
    if (prefix.isNotEmpty && !prefix.endsWith('\n')) {
      prefix += '\n';
    }

    // 为了方便在图片下一行继续输入，如果后面不是换行，则在标记后面自动补一个换行。
    final bool needTrailingNewline = !suffix.startsWith('\n');
    final String inserted = needTrailingNewline ? (markerLine + '\n') : markerLine;

    final String newText = prefix + inserted + suffix;
    final int newOffset = (prefix + inserted).length;

    setState(() {
      _textCtrl.value = TextEditingValue(
        text: newText,
        selection: TextSelection.collapsed(offset: newOffset),
      );
      _dirty = true;
    });
  }


  Future<void> _insertAudio() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;

    // 在当前光标所在位置插入一行语音标记，保证插入行为与用户编辑位置一致。
    final text = _textCtrl.text;
    final sel = _textCtrl.selection;
    int offset = sel.isValid ? sel.baseOffset : text.length;
    if (offset < 0 || offset > text.length) {
      offset = text.length;
    }

    final String markerLine = '[语音] ' + path;
    String prefix = text.substring(0, offset);
    String suffix = text.substring(offset);

    if (prefix.isNotEmpty && !prefix.endsWith('\n')) {
      prefix += '\n';
    }

    final bool needTrailingNewline = !suffix.startsWith('\n');
    final String inserted = needTrailingNewline ? (markerLine + '\n') : markerLine;

    final String newText = prefix + inserted + suffix;
    final int newOffset = (prefix + inserted).length;

    setState(() {
      _textCtrl.value = TextEditingValue(
        text: newText,
        selection: TextSelection.collapsed(offset: newOffset),
      );
      _dirty = true;
    });
  }


  void _onTextChanged(String s) {
    // 标记脏
    if (mounted && !_dirty) setState(() { _dirty = true; });
    // 检测是否是“退格一次”导致
    final curSel = _textCtrl.selection;
    final prevText = _lastText;
    final prevSel = _lastSel;
    _lastText = s;
    _lastSel = curSel;

    if (prevText.isEmpty) return;
    final deleted = prevText.length - s.length;
    if (deleted != 1) return; // 只处理一次退格
    if (!curSel.isCollapsed) return;

    // 计算被删除的那个字符，如果是换行，则不触发“整行删除附件”的逻辑，避免误删图片/语音。
    int diffIndex = 0;
    final int minLen = s.length;
    while (diffIndex < minLen && prevText.codeUnitAt(diffIndex) == s.codeUnitAt(diffIndex)) {
      diffIndex++;
    }
    if (diffIndex >= prevText.length) {
      diffIndex = prevText.length - 1;
    }
    if (diffIndex < 0) return;
    final int deletedCodeUnit = prevText.codeUnitAt(diffIndex);
    if (deletedCodeUnit == 10) {
      // 仅仅删除了一个换行符（例如从附件下一行回退到附件行），不认为是“删除附件”，直接返回。
      return;
    }

    // 找到当前光标所在行
    final idx = curSel.baseOffset;
    int lineStart = 0;
    int i = 0;
    for (i = 0; i < s.length && i < idx; i++) {
      if (s.codeUnitAt(i) == 10) { // '\n'
        lineStart = i + 1;
      }
    }
    int lineEnd = s.indexOf('\n', lineStart);
    if (lineEnd < 0) lineEnd = s.length;
    final line = s.substring(lineStart, lineEnd).trimLeft();
    final isMarker = line.startsWith('[图片]') || line.startsWith('[语音]');
    if (!isMarker) return;

    // 删除整行 marker
    final newText = (s.substring(0, lineStart) + s.substring(lineEnd + (lineEnd < s.length ? 1 : 0)));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _textCtrl.text = newText;
      _textCtrl.selection = TextSelection.collapsed(offset: lineStart);
      setState(() {});
    });
  }


  void _handleTextTap() {
    // 当点击 TextField 内部时，把光标移动到当前行的最左侧。
    final sel = _textCtrl.selection;
    if (!sel.isValid) return;
    final text = _textCtrl.text;
    if (text.isEmpty) return;
    int off = sel.baseOffset;
    if (off < 0) off = 0;
    if (off > text.length) off = text.length;
    while (off > 0 && text.codeUnitAt(off - 1) != 10) {
      off--;
    }
    _textCtrl.selection = TextSelection.collapsed(offset: off);
  }

    void _handleDoubleTapDown(TapDownDetails details) {
    final ctx = _textBoxKey.currentContext;
    if (ctx == null) return;
    final box = ctx.findRenderObject() as RenderBox?;
    if (box == null) return;

    // 将全局坐标转换为相对于文本编辑区域的本地坐标
    final local = box.globalToLocal(details.globalPosition);
    final size = box.size;
    final baseStyle = DefaultTextStyle.of(ctx).style;
    final String text = _textCtrl.text;

    if (text.isEmpty) {
      // 没有内容时，始终把光标放在开头
      FocusScope.of(context).requestFocus(_focusNode);
      _textCtrl.selection = const TextSelection.collapsed(offset: 0);
      return;
    }

    // 使用当前 TextEditingController 生成 TextSpan
    final span = _textCtrl.buildTextSpan(
      context: ctx,
      style: baseStyle,
      withComposing: false,
    );
    final painter = TextPainter(
      text: span,
      textDirection: TextDirection.ltr,
      maxLines: null,
    )..layout(maxWidth: size.width);

    // 计算最后一个字符的光标位置，用来限制点击高度，避免为了点击极底部空白去修改正文内容
    final endCaret = painter.getOffsetForCaret(
      TextPosition(offset: text.length),
      Rect.zero,
    );

    double dy = local.dy;
    if (dy < 0) {
      dy = 0;
    }
    final double maxDy = endCaret.dy;
    if (dy > maxDy) {
      dy = maxDy;
    }

    final pos = painter.getPositionForOffset(Offset(0, dy));
    int off = pos.offset;

    // 始终回退到当前行行首
    while (off > 0 && text.codeUnitAt(off - 1) != 10) {
      off--;
    }

    FocusScope.of(context).requestFocus(_focusNode);
    _textCtrl.selection = TextSelection.collapsed(offset: off);
  }


Widget _attachmentsPreview() {
    final content = _textCtrl.text;
    final lines = content.split(RegExp(r'\r?\n'));
    final widgets = <Widget>[];

    final imgReg = RegExp(r'^\[图片\]\s*(.+)$');
    final audioReg = RegExp(r'^\[语音\]\s*(.+)$');

    for (final raw in lines) {
      final line = raw.trimRight();
      if (line.isEmpty) continue;

      final mImg = imgReg.firstMatch(line);
      final mAud = audioReg.firstMatch(line);

      if (mImg != null) {
        final path = mImg.group(1)!;
        final f = File(path);
        if (!f.existsSync()) continue;

        widgets.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: LayoutBuilder(
              builder: (ctx, cons) {
                final double w = math.min(MediaQuery.of(ctx).size.width - 32, 560).toDouble();
                final double h = math.min(MediaQuery.of(ctx).size.height * 0.35, 320).toDouble();
                return SizedBox(
                  width: w,
                  height: h,
                  child: InteractiveViewer(
                    minScale: 0.5,
                    maxScale: 4,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(f, width: w, height: h, fit: BoxFit.contain),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      } else if (mAud != null) {
        final path = mAud.group(1)!;
        widgets.add(_AudioTile(path: path));
      }
    }

    if (widgets.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets),
    );
  }



Widget build(BuildContext context) {
    final w = weatherByCode(_weatherCode);

    return _bgWrap(Scaffold(extendBodyBehindAppBar: true,
      backgroundColor: (_bgPath == null || _bgPath!.isEmpty) ? Colors.white : Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0,
        title: const Text('写日记'),
        actions: [
          IconButton(onPressed: _dirty ? _cancel : null, icon: const Icon(Icons.close)),
          IconButton(onPressed: _dirty ? _save : null, icon: const Icon(Icons.check)),
        ],
      ),
      body: GestureDetector(onTapDown: _handleDoubleTapDown, onDoubleTapDown: _handleDoubleTapDown, behavior: HitTestBehavior.translucent, child: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Material(
                  color: Colors.transparent,
                  elevation: 0,
                  child: Padding(
                    padding: EdgeInsets.zero,
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: _pickTime,
                            child: Row(
                              children: [
                                const Icon(Icons.schedule, size: 18),
                                const SizedBox(width: 6),
                                Text(_fmt.format(_time)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: _weatherCode,
                          hint: const Text('天气'),
                          items: weatherOptions
                              .map((w) => DropdownMenuItem<int>(
                                    value: w.code,
                                    child: Row(
                                      children: [
                                        Icon(w.icon, size: 18),
                                        const SizedBox(width: 6),
                                        Text(w.name),
                                      ],
                                    ),
                                  ))
                              .toList(),
                          onChanged: (v) => setState(() {
                            _weatherCode = v;
                            _dirty = true;
                          }),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          tooltip: _starred ? '取消收藏' : '收藏',
                          onPressed: () => setState(() {
                            _starred = !_starred;
                            _dirty = true;
                          }),
                          icon: Icon(_starred ? Icons.star : Icons.star_border),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    controller: _contentScrollController,
                    padding: const EdgeInsets.only(bottom: 96),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          key: _textBoxKey,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: TextField(
                            controller: _textCtrl,
                            focusNode: _focusNode,
                            maxLines: null,
                            onTap: _handleTextTap,
                            autofocus: true,
                            textAlignVertical: TextAlignVertical.top,
                            decoration: const InputDecoration.collapsed(hintText: '写点什么……'),
                            onChanged: _onTextChanged,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: _attachmentsPreview(),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                top: false,
                minimum: EdgeInsets.zero,
                child: Row(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 6,
                          children: _tagIds
                              .map((id) => Chip(
                                    label: Text(_tagNameById[id] ?? '标签#$id'),
                                  ))
                              .toList(),
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: '插入语音',
                      onPressed: _insertAudio,
                      icon: const Icon(Icons.mic_none),
                    ),
                    IconButton(
                      tooltip: '插入图片',
                      onPressed: _insertImage,
                      icon: const Icon(Icons.image_outlined),
                    ),
                    OutlinedButton.icon(
                      onPressed: _pickTags,
                      icon: const Icon(Icons.label_outline),
                      label: const Text('标签'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      )),
    ));
  }
}


class _AudioTile extends StatefulWidget {
  final String path;
  const _AudioTile({required this.path});
  @override
  State<_AudioTile> createState() => _AudioTileState();
}

class _AudioTileState extends State<_AudioTile> {
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _player.pause();
    } else {
      await _player.play(DeviceFileSource(widget.path));
    }
    if (mounted) setState(() => _playing = !_playing);
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: IconButton(icon: Icon(_playing ? Icons.pause : Icons.play_arrow), onPressed: _toggle),
      title: const Text('语音'),
      subtitle: const Text('点击播放'),
      tileColor: Colors.black.withOpacity(0.05),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    );
  }
}
