
import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// 简化且可编译的 POI 模型（页面仅读取这些字段）。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final int? distance;
  PoiItem({
    required this.name,
    required this.latitude,
    required this.longitude,
    this.address,
    this.distance,
  });
}

class LocationService {
  static const MethodChannel _sysCh = MethodChannel('com.example.quote_app/sys');

  /// 优先使用百度SDK定位，高精度流目标≤30m；失败回退系统定位（同样≤30m）。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    try { await DLog.i('LocationService', '【定位】优先使用百度SDK定位（目标≤30m），失败回退系统定位'); } catch (_){}
    // 1) Baidu（原生）一次定位
    try {
      final bd = await _baiduSdkLocationOnce();
      if (bd != null) {
        unawaited(_logNearbyLandmarkIfPossible(bd));
        if (bd.accuracy <= 30) return bd;
        try { await DLog.w('LocationService', '【定位】Baidu返回但精度 ${bd.accuracy}m，大于30m，回退系统流继续获取'); } catch (_){}
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】Baidu SDK 异常：$e'); } catch (_){}
    }

    // 2) 系统高精度流（直到≤30m），失败回退单次
    final sys = await _systemLocationOnce();
    if (sys != null) {
      unawaited(_logNearbyLandmarkIfPossible(sys));
      return sys;
    }

    try { await DLog.e('LocationService', '【定位】两种方式均失败'); } catch (_){}
    return null;
  }

  /// 使用百度逆地理查询附近POI（保持与现有展示口径一致）
  static Future<List<PoiItem>> fetchNearbyPois(Position pos, {int radius = 300}) async {
    final ak = await ConfigDao().getBaiduAk();
    final url = Uri.parse(
        'https://api.map.baidu.com/reverse_geocoding/v3/?ak=${Uri.encodeQueryComponent(ak)}&output=json&coordtype=wgs84ll&extensions_poi=1&radius=$radius&location=${pos.latitude},${pos.longitude}');
    try {
      final resp = await http.get(url);
      if (resp.statusCode == 200) {
        final map = json.decode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
        final result = (map['result'] ?? {}) as Map<String, dynamic>;
        final pois = (result['pois'] as List?) ?? const [];
        final list = <PoiItem>[];
        for (final it in pois) {
          final m = (it as Map).cast<String, dynamic>();
          list.add(PoiItem(
            name: (m['name'] ?? '').toString(),
            address: (m['addr'] ?? m['address'] ?? '').toString().isEmpty ? null : (m['addr'] ?? m['address']).toString(),
            latitude: (m['point']?['y'] ?? pos.latitude) * 1.0,
            longitude: (m['point']?['x'] ?? pos.longitude) * 1.0,
            distance: int.tryParse('${m['distance'] ?? ''}'),
          ));
        }
        try { await DLog.i('LocationService', '【逆地理】共返回POI ${list.length} 个'); } catch (_){}
        return list;
      } else {
        try { await DLog.w('LocationService', '【逆地理】HTTP ${resp.statusCode}'); } catch (_){}
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【逆地理】请求失败：$e'); } catch (_){}
    }
    return <PoiItem>[];
  }

  /// —— 私有：调用原生百度SDK一次定位
  static Future<Position?> _baiduSdkLocationOnce() async {
    try {
      final ret = await _sysCh.invokeMethod<Map>('getBaiduLocationOnce');
      if (ret == null) return null;
      final lat = (ret['lat'] as num?)?.toDouble();
      final lon = (ret['lon'] as num?)?.toDouble();
      final acc = (ret['acc'] as num?)?.toDouble() ?? 9999;
      if (lat == null || lon == null) return null;
      final p = Position(
        latitude: lat,
        longitude: lon,
        accuracy: acc,
        altitude: 0,
        heading: 0,
        speed: 0,
        speedAccuracy: 0,
        timestamp: DateTime.now(),
        floor: null,
        isMocked: false,
      );
      try { await DLog.i('LocationService', '【定位】Baidu SDK：$lat,$lon acc=${acc}m'); } catch (_){}
      return p;
    } catch (e) {
      try { await DLog.w('LocationService', '【定位】原生通道调用失败：$e'); } catch (_){}
      return null;
    }
  }

  /// 使用系统定位的高精度“流”，直到精度≤30m；如不可用则回退一次性获取。
  static Future<Position?> _systemLocationOnce() async {
    try {
      // 先尝试流式定位，提高拿到≤30m的概率
      final stream = Geolocator.getPositionStream(
          locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.best, distanceFilter: 0));
      // 这里不自定义超时，由底层决定；若底层不可用会抛异常
      final pos = await stream.firstWhere((p) => p.accuracy <= 30);
      try { await DLog.i('LocationService', '【定位】系统流返回: ${pos.latitude},${pos.longitude} acc=${pos.accuracy}m'); } catch (_){}
      return pos;
    } catch (e) {
      // 回退单次高精度
      try { await DLog.w('LocationService', '【定位】系统流异常，回退单次：$e'); } catch (_){}
      try {
        final single = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
        try { await DLog.i('LocationService', '【定位】系统单次返回: ${single.latitude},${single.longitude} acc=${single.accuracy}m'); } catch (_){}
        return single;
      } catch (e2) {
        try { await DLog.e('LocationService', '【定位】系统单次也失败：$e2'); } catch (_){}
        return null;
      }
    }
  }

  /// 逆地理日志（保持与页面现有展示一致：优先百度逆地理；失败则忽略）
  static Future<void> _logNearbyLandmarkIfPossible(Position p) async {
    try {
      final pois = await fetchNearbyPois(p, radius: 300);
      if (pois.isNotEmpty) {
        final first = pois.first;
        await DLog.i('LocationService', '【逆地理】附近：${first.name} ${first.distance ?? ''}m');
      }
    } catch (e) {
      try { await DLog.w('LocationService', '【逆地理】记录附近标志物失败：$e'); } catch (_){}
    }
  }
}
