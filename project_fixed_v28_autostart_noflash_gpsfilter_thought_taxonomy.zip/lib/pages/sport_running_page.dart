import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import '../data/dao.dart';
import '../data/sport_dao.dart';

/// 运动进行中页
///
/// 关键特性（对齐需求）：
/// - 支持计划/非计划记录恢复：从 sport_records 读取并恢复步数/距离/用时/状态
/// - 进程被杀后：record(in_progress) 在启动时被置为 paused（由 SportDao.markInProgressAsPaused）；
///   进入本页会直接恢复暂停态并允许继续
/// - 步数：优先使用 Android StepCounter 传感器（EventChannel），避免 GPS 估算造成延迟/不准
/// - 运动过程中周期性持久化（每 3 秒一次 + 状态变更时）防止数据丢失
class SportRunningPage extends StatefulWidget {
  final int recordId;
  final Map<String, dynamic>? plan;
  final String mode; // plan / instant

  const SportRunningPage({
    super.key,
    required this.recordId,
    this.plan,
    required this.mode,
  });

  @override
  State<SportRunningPage> createState() => _SportRunningPageState();
}

class _SportRunningPageState extends State<SportRunningPage> {
  final SportDao _dao = SportDao();
  final ConfigDao _configDao = ConfigDao();

  static const MethodChannel _sys = MethodChannel('com.example.quote_app/sys');
  static const EventChannel _stepsCh = EventChannel('com.example.quote_app/steps');

  final AudioPlayer _audioPlayer = AudioPlayer();

  // UI settings
  String? _bgImagePath;
  String? _startSoundPath;

  // Quote
  String _quoteContent = '生命在于运动';
  String _quoteAuthor = '';
  String _quoteExplanation = '';

  // State
  String _status = 'loading'; // not_started / in_progress / paused / stopped / completed
  int _countdown = 5;
  bool _ready = false;


  // Progress
  double _distance = 0.0; // meters
  int _steps = 0;
  int _stepsOffset = 0; // for sensor reset on resume
  int _elapsedOffsetSec = 0; // persisted elapsed seconds
  final Stopwatch _segmentWatch = Stopwatch();

  // Location
  Position? _lastPosition;
  Position? _startPosition;
  StreamSubscription<Position>? _posSub;
  DateTime? _lastPosTs;
  double _currentSpeedMps = 0.0;


  // Steps
  StreamSubscription<dynamic>? _stepsSub;
  bool _sensorStepsActive = false;

  // Timers
  Timer? _countdownTimer;
  Timer? _uiTimer;
  Timer? _persistTimer;

  // Plan
  int? _planId;
  Map<String, dynamic>? _loadedPlan;

  Map<String, dynamic>? get _plan => widget.plan ?? _loadedPlan;
  String get _targetType => (_plan?['target_type'] ?? 'steps').toString();
  double? get _targetValue => _plan?['target_value'] is num ? (_plan?['target_value'] as num).toDouble() : null;
  String get _targetUnit => (_plan?['target_unit'] ?? '步').toString();

  Duration get _totalElapsed {
    return Duration(seconds: _elapsedOffsetSec + _segmentWatch.elapsed.inSeconds);
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _initLocationPerm();
    await _loadUiSettings();
    await _loadQuote();
    await _restoreFromRecord();

    if (!mounted) return;
    setState(() {
      _ready = true;
    });
    // New record: start 5s countdown. Resumed record: keep state.
    if (_status == 'not_started' && _elapsedOffsetSec == 0 && _steps == 0 && _distance == 0.0) {
      _startCountdown();
    } else {
      _startUiTimer();
      if (_status == 'in_progress') {
        // Safety: if we ever land here with in_progress, treat as running.
        _resumeRunning(startTimers: true);
      }
    }
  }

  Future<void> _initLocationPerm() async {
    try {
      await Geolocator.requestPermission();
    } catch (_) {}
  }

  Future<void> _loadUiSettings() async {
    try {
      final bg = await _configDao.getSportRunningBg();
      final sound = await _configDao.getSportStartSound();
      if (!mounted) return;
      setState(() {
        _bgImagePath = (bg?.trim().isEmpty ?? true) ? null : bg;
        _startSoundPath = (sound?.trim().isEmpty ?? true) ? null : sound;
      });
    } catch (_) {}
  }

  Future<void> _loadQuote() async {
    try {
      final q = await _dao.getRandomSportQuote();
      if (q == null) return;
      if (!mounted) return;
      setState(() {
        _quoteContent = (q['content'] ?? _quoteContent).toString();
        _quoteAuthor = (q['author'] ?? '').toString();
        _quoteExplanation = (q['explanation'] ?? '').toString();
      });
    } catch (_) {}
  }

  Future<void> _restoreFromRecord() async {
    final r = await _dao.getRecord(widget.recordId);
    if (r == null) return;

    _planId = r['plan_id'] as int?;
    if (widget.plan == null && _planId != null) {
      try {
        _loadedPlan = await _dao.getPlan(_planId!);
      } catch (_) {}
    }

    final st = (r['status'] ?? 'not_started').toString();
    final dur = (r['total_duration'] is num) ? (r['total_duration'] as num).toInt() : 0;
    final steps = (r['total_steps'] is num) ? (r['total_steps'] as num).toInt() : 0;
    final dist = (r['total_distance'] is num) ? (r['total_distance'] as num).toDouble() : 0.0;

    // Start location
    try {
      final sl = (r['start_location'] ?? '').toString();
      if (sl.isNotEmpty) {
        final m = jsonDecode(sl);
        if (m is Map && m['lat'] != null && m['lon'] != null) {
          _startPosition = Position(
            latitude: (m['lat'] as num).toDouble(),
            longitude: (m['lon'] as num).toDouble(),
            timestamp: DateTime.now(),
            accuracy: 0,
            altitude: 0,
            heading: 0,
            speed: 0,
            speedAccuracy: 0,
            floor: null,
            isMocked: false,
            headingAccuracy: 0,
            altitudeAccuracy: 0,
          );
        }
      }
    } catch (_) {}

    setState(() {
      _status = st;
      _elapsedOffsetSec = dur;
      _steps = steps;
      _distance = dist;
      _stepsOffset = steps;
    });

    // If resumed paused/stopped: do not auto-start sensor/location.
    if (_status == 'in_progress') {
      _segmentWatch
        ..reset()
        ..start();
      await _startSensors();
      _startPersistTimer();
    }
  }

  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdown = 5;
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        _countdown -= 1;
      });
      if (_countdown <= 0) {
        t.cancel();
        _startRunningFromCountdown();
      }
    });
  }

  Future<void> _startRunningFromCountdown() async {
    if (!mounted) return;
    setState(() {
      _status = 'in_progress';
    });
    await _playStartBell();
    _segmentWatch
      ..reset()
      ..start();
    _elapsedOffsetSec = 0;
    _distance = 0.0;
    _steps = 0;
    _stepsOffset = 0;
    _startPosition = null;
    _lastPosition = null;
    await _startSensors();
    _startUiTimer();
    _startPersistTimer();
    await _persistProgress(reason: 'start');
    await _syncPlanStatus('in_progress');
  }

  void _startUiTimer() {
    _uiTimer?.cancel();
    _uiTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {});
      _checkTargetReached();
    });
  }

  Future<void> _startSensors() async {
    await _startStepStream();
    _startLocationStream();
  }

  void _stopSensors() {
    _posSub?.cancel();
    _posSub = null;
    _stopStepStream();
  }

  Future<void> _startStepStream() async {
    // Ask runtime permission on Android 10+.
    try {
      final st = await Permission.activityRecognition.request();
      if (!st.isGranted) {
        _sensorStepsActive = false;
        return;
      }
    } catch (_) {
      // If permission_handler doesn't support the platform, ignore.
    }

    try {
      await _sys.invokeMethod('resetStepCounter');
    } catch (_) {}

    _stepsSub?.cancel();
    _sensorStepsActive = true;
    _stepsSub = _stepsCh.receiveBroadcastStream().listen((v) {
      if (!_sensorStepsActive) return;
      final x = (v is num) ? v.toInt() : int.tryParse(v.toString());
      if (x == null) return;
      if (!mounted) return;
      setState(() {
        _steps = _stepsOffset + x;
      });
    }, onError: (_) {
      _sensorStepsActive = false;
    });
  }

  void _stopStepStream() {
    _sensorStepsActive = false;
    _stepsSub?.cancel();
    _stepsSub = null;
  }

  void _startLocationStream() {
    _posSub?.cancel();
    _posSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),
    ).listen(_onPositionUpdate);
  }

  void _onPositionUpdate(Position pos) {
    if (_status != 'in_progress') return;

    // First location as start location
    _startPosition ??= pos;

    final nowTs = pos.timestamp ?? DateTime.now();
    final last = _lastPosition;
    final lastTs = _lastPosTs;

    // Filter extremely inaccurate points to avoid distance drifting when stationary.
    final accCur = (pos.accuracy.isFinite) ? pos.accuracy : 0.0;
    if (accCur > 60) {
      // Still advance last position to avoid accumulating a huge jump later.
      _lastPosition = pos;
      _lastPosTs = nowTs;
      return;
    }

    if (last != null) {
      final accLast = (last.accuracy.isFinite) ? last.accuracy : 0.0;
      var dist = Geolocator.distanceBetween(
        last.latitude,
        last.longitude,
        pos.latitude,
        pos.longitude,
      );

      // Use the larger accuracy radius as the minimum movement threshold.
      // A practical jitter gate: use accuracy radius * 1.2 (or at least 5m).
      // This suppresses 'distance increasing while standing still' caused by GNSS noise.
      final threshold = max(5.0, max(accCur, accLast) * 1.2);

      // Time delta (seconds)
      final dtSec = lastTs == null ? null : nowTs.difference(lastTs).inMilliseconds / 1000.0;

      // Prefer sensor-provided speed if reasonable; otherwise compute.
      double speedMps;
      if (pos.speed.isFinite && pos.speed >= 0) {
        speedMps = pos.speed;
      } else if (dtSec != null && dtSec > 0) {
        speedMps = dist / dtSec;
      } else {
        speedMps = 0.0;
      }

      // Stationary / jitter suppression:
      // - ignore tiny moves within accuracy radius
      // - ignore updates with near-zero speed
      // - ignore huge spikes (GPS jumps)
      if (!dist.isFinite || dist <= 0) {
        dist = 0;
        speedMps = 0;
      } else if (dist < threshold || speedMps < 0.5) {
        dist = 0;
        speedMps = 0;
      } else if (dist > 50) {
        // one update jumped too far -> likely bad fix
        dist = 0;
      }

      if (dist > 0) {
        _distance += dist;
        // Fallback step estimation when sensor unavailable
        if (!_sensorStepsActive) {
          _steps = (_distance / 0.7).floor();
        }
      }

      // Low-pass filter for display speed
      _currentSpeedMps = _currentSpeedMps * 0.7 + speedMps * 0.3;
    }

    _lastPosition = pos;
    _lastPosTs = nowTs;
  }

  Future<void> _playStartBell() async {
    try {
      final p = _startSoundPath;
      if (p != null && p.isNotEmpty) {
        await _audioPlayer.stop();
        await _audioPlayer.play(DeviceFileSource(p));
        return;
      }
    } catch (_) {}
    try {
      await _sys.invokeMethod('playSystemNotificationSound');
    } catch (_) {}
  }

  String _formatDuration(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  double _calcAvgSpeedKmH() {
    final sec = _totalElapsed.inSeconds;
    if (sec <= 0) return 0;
    final hours = sec / 3600.0;
    return (_distance / 1000.0) / hours;
  }

  void _togglePause() async {
    if (_status == 'in_progress') {
      // pause
      _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
      _segmentWatch
        ..stop()
        ..reset();
      _stopSensors();
      setState(() {
        _status = 'paused';
        _stepsOffset = _steps;
      });
      await _persistProgress(reason: 'pause');
      await _syncPlanStatus('paused');
      return;
    }
    if (_status == 'paused') {
      // resume
      setState(() {
        _status = 'in_progress';
      });
      _segmentWatch
        ..reset()
        ..start();
      _stepsOffset = _steps;
      await _startSensors();
      _startPersistTimer();
      await _persistProgress(reason: 'resume');
      await _syncPlanStatus('in_progress');
    }
  }

  void _stop() async {
    if (_status == 'completed') return;
    if (_status == 'in_progress') {
      _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
    }
    _segmentWatch
      ..stop()
      ..reset();
    _stopSensors();
    setState(() {
      _status = 'stopped';
      _stepsOffset = _steps;
    });
    await _persistProgress(reason: 'stop');
    await _syncPlanStatus('stopped');
    // stopped is not completed; keep record for resume.
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  void _restart() async {
    // Reset and start immediately (no countdown) – aligns with “重新开始”行为
    _elapsedOffsetSec = 0;
    _distance = 0;
    _steps = 0;
    _stepsOffset = 0;
    _startPosition = null;
    _lastPosition = null;
    _segmentWatch
      ..reset()
      ..start();
    setState(() {
      _status = 'in_progress';
    });
    await _startSensors();
    _startUiTimer();
    _startPersistTimer();
    await _persistProgress(reason: 'restart');
    await _syncPlanStatus('in_progress');
  }

  void _resumeRunning({required bool startTimers}) {
    _segmentWatch
      ..reset()
      ..start();
    _startSensors();
    if (startTimers) {
      _startUiTimer();
      _startPersistTimer();
    }
  }

  void _checkTargetReached() {
    if (_status != 'in_progress') return;
    final targetVal = _targetValue;
    if (targetVal == null || targetVal <= 0) return;

    double progress;
    if (_targetType == 'steps') {
      progress = _steps.toDouble();
    } else if (_targetType == 'duration') {
      // target_value uses hours in plan dialog
      progress = _totalElapsed.inSeconds / 3600.0;
    } else {
      progress = _distance / 1000.0;
    }
    if (progress >= targetVal) {
      _complete();
    }
  }

  Future<void> _complete({String? dialogTitle, String? dialogContent}) async {
    if (_status == 'completed') return;
    _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
    _segmentWatch
      ..stop()
      ..reset();
    _stopSensors();
    setState(() {
      _status = 'completed';
      _stepsOffset = _steps;
    });

    // Try to fetch a fresh end location once (best-effort).
    Position? endPos = _lastPosition;
    try {
      endPos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    } catch (_) {
      // retry once
      try {
        endPos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
      } catch (_) {}
    }
    if (endPos != null) _lastPosition = endPos;

    await _persistProgress(reason: 'complete', forceEndTime: true);
    await _syncPlanStatus('completed');

    if (!mounted) return;
    final title = dialogTitle ?? (widget.mode == 'instant' ? '已结束' : '已完成');
    final content = dialogContent ?? (widget.mode == 'instant' ? '本次运动已结束！' : '运动已达标！');

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('确定'),
          ),
        ],
      ),
    );
    if (mounted) Navigator.of(context).pop();
  }

  void _startPersistTimer() {
    _persistTimer?.cancel();
    _persistTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (_status == 'in_progress') {
        _persistProgress(reason: 'tick');
      }
    });
  }

  Future<void> _persistProgress({required String reason, bool forceEndTime = false}) async {
    // Persist minimal progress frequently to avoid loss on crash/kill.
    final now = DateTime.now().toIso8601String();
    final totalSec = _totalElapsed.inSeconds;
    final m = <String, dynamic>{
      'updated_at': now,
      'status': _status,
      'total_duration': totalSec,
      'total_steps': _steps,
      'total_distance': _distance,
      'avg_speed': _calcAvgSpeedKmH(),
    };
    if (_startPosition != null) {
      m['start_location'] = jsonEncode({'lat': _startPosition!.latitude, 'lon': _startPosition!.longitude});
    }
    if (forceEndTime || _status == 'completed') {
      m['end_time'] = now;
      if (_lastPosition != null) {
        m['end_location'] = jsonEncode({'lat': _lastPosition!.latitude, 'lon': _lastPosition!.longitude});
      }
    }

    try {
      await _dao.updateRecord(widget.recordId, m);
    } catch (_) {
      // ignore: local DB failure is rare; periodic writes reduce loss anyway.
    }
  }

  Future<void> _syncPlanStatus(String status) async {
    final pid = _planId;
    if (pid == null) return;
    try {
      await _dao.updatePlanStatus(pid, status);
    } catch (_) {}
  }

  @override
  void dispose() {
    // If the user leaves the page while the session is still running, we must not
    // lose state. Treat it as a pause so SportDetailPage can show a resume入口.
    if (_status == 'in_progress') {
      try {
        _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
      } catch (_) {}
      _segmentWatch
        ..stop()
        ..reset();
      _stopSensors();
      _status = 'paused';
      // Fire-and-forget persistence; dispose must stay sync.
      Future.microtask(() async {
        try {
          await _persistProgress(reason: 'dispose_pause');
        } catch (_) {}
        try {
          await _syncPlanStatus('paused');
        } catch (_) {}
      });
    }
    _countdownTimer?.cancel();
    _uiTimer?.cancel();
    _persistTimer?.cancel();
    _stopSensors();
    try {
      _audioPlayer.dispose();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return Scaffold(
        appBar: AppBar(title: const Text('运动进行中')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final elapsed = _totalElapsed;

    final targetVal = _targetValue;
    final remainingText = () {
      if (targetVal == null || targetVal <= 0) return '';
      double progress;
      double remain;
      String unit;
      if (_targetType == 'steps') {
        progress = _steps.toDouble();
        remain = targetVal - progress;
        unit = '步';
      } else if (_targetType == 'duration') {
        progress = elapsed.inSeconds / 3600.0;
        remain = targetVal - progress;
        unit = '小时';
      } else {
        progress = _distance / 1000.0;
        remain = targetVal - progress;
        unit = 'km';
      }
      if (remain < 0) remain = 0;
      return '剩余: ${remain.toStringAsFixed(1)} $unit';
    }();

    final statusText = _status == 'in_progress'
        ? '进行中'
        : _status == 'paused'
            ? '已暂停'
            : _status == 'stopped'
                ? '已停止'
                : _status == 'completed'
                    ? '已完成'
                    : '未开始';

    return Scaffold(
      appBar: AppBar(title: const Text('运动进行中')),
      body: Container(
        decoration: (_bgImagePath != null && _bgImagePath!.isNotEmpty && File(_bgImagePath!).existsSync())
            ? BoxDecoration(
                image: DecorationImage(
                  image: FileImage(File(_bgImagePath!)),
                  fit: BoxFit.cover,
                ),
              )
            : null,
        child: Container(
          color: (_bgImagePath != null && _bgImagePath!.isNotEmpty) ? Colors.white.withOpacity(0.88) : null,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Card(
                  color: const Color(0xFFF0F8FF),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Text(_quoteContent, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        if (_quoteAuthor.trim().isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text('—— $_quoteAuthor', textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic)),
                        ],
                        if (_quoteExplanation.trim().isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(_quoteExplanation, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                if (_status == 'not_started')
                  Column(
                    children: [
                      Text('准备开始', style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 12),
                      Text(
                        '$_countdown',
                        style: const TextStyle(fontSize: 64, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                    ],
                  )
                else
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('状态: $statusText', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('已用时: ${_formatDuration(elapsed)}', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('步数: $_steps 步${_sensorStepsActive ? '' : '（估算）'}', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('距离: ${(_distance / 1000.0).toStringAsFixed(2)} km', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('实时速度: ${(_currentSpeedMps * 3.6).clamp(0, 99).toStringAsFixed(2)} km/h', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('平均速度: ${_calcAvgSpeedKmH().toStringAsFixed(2)} km/h', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        if (targetVal != null && targetVal > 0) Text(remainingText, style: const TextStyle(fontSize: 16)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: _status == 'not_started' || _status == 'completed'
          ? null
          : BottomAppBar(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  if (_status == 'in_progress' || _status == 'paused')
                    IconButton(
                      icon: Icon(_status == 'paused' ? Icons.play_arrow : Icons.pause),
                      onPressed: _togglePause,
                    ),
                  if (_status == 'in_progress' || _status == 'paused')
                    IconButton(
                    icon: Icon(widget.mode == 'instant' ? Icons.flag : Icons.stop),
                    onPressed: widget.mode == 'instant' ? () => _complete() : _stop,
                    ),
                  if (_status == 'stopped')
                    IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: _restart,
                    ),
                ],
              ),
            ),
    );
  }
}
