package com.example.quote_app.schedule;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.example.quote_app.data.DbInspector;
import com.example.quote_app.data.DbRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Native mirror of Dart's `_nextTimeForTask` basic logic:
 * 1) If tasks.next_time is a valid future ISO‑8601 string -> use it;
 * 2) Otherwise parse tasks.start_time(HH:mm) and return today at HH:mm if in future,
 *    else tomorrow at HH:mm.
 * This keeps native auto‑reschedule in sync with Dart for the common cases and avoids
 * drift between AM and WM scheduling. More complex freq rules are handled in Dart.
 */
public final class NextTriggerCalculator {
    private NextTriggerCalculator() {}

    public static long compute(Context ctx, String uid) {
        if (TextUtils.isEmpty(uid)) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, 1);
            return cal.getTimeInMillis();
        }

        DbInspector.Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.dbPath)) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, 1);
            return cal.getTimeInMillis();
        }

        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY);
            String table = TextUtils.isEmpty(cc.tasksSource) ? "tasks" : cc.tasksSource;
            String uidCol = cc.taskColMap.containsKey("uid") ? cc.taskColMap.get("uid") : "task_uid";
            String nextCol = cc.taskColMap.containsKey("next_time") ? cc.taskColMap.get("next_time") : "next_time";
            String startCol = cc.taskColMap.containsKey("trigger_at") ? cc.taskColMap.get("trigger_at") : "start_time";

            Cursor c = db.rawQuery("SELECT "+nextCol+","+startCol+" FROM "+table+" WHERE "+uidCol+"=? LIMIT 1", new String[]{uid});
            String nextIso = null;
            String startVal = null;
            if (c.moveToFirst()) {
                int idx0 = 0;
                int idx1 = 1;
                nextIso = safeGetString(c, idx0);
                startVal = safeGetString(c, idx1);
            }
            c.close();

            long now = System.currentTimeMillis();
            // Try next_time (ISO 8601)
            long ts = parseIso(nextIso);
            if (ts > now) return ts;

            // Fallback to HH:mm from start_time
            int[] hm = parseHHmm(startVal);
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            cal.set(Calendar.HOUR_OF_DAY, hm[0]);
            cal.set(Calendar.MINUTE, hm[1]);
            long cand = cal.getTimeInMillis();
            // grace: 10 seconds
            if (cand >= now - 10_000L) return cand;
            cal.add(Calendar.DAY_OF_YEAR, 1);
            return cal.getTimeInMillis();
        } catch (Throwable e) {
            try { DbRepository.log(ctx, uid, "NextTriggerCalculator error: "+e.getMessage()); } catch (Throwable ignore) {}
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, 1);
            return cal.getTimeInMillis();
        } finally {
            if (db != null) try { db.close(); } catch (Throwable ignore) {}
        }
    }

    private static String safeGetString(Cursor c, int idx) {
        try { return c.isNull(idx) ? null : c.getString(idx); } catch (Throwable ignore) { return null; }
    }

    private static long parseIso(String s) {
        if (TextUtils.isEmpty(s)) return -1L;
        // Try common ISO formats
        String[] fmts = new String[] {
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ss.SSS",
                "yyyy-MM-dd'T'HH:mm:ss",
                "yyyy-MM-dd HH:mm:ss"
        };
        for (String f : fmts) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(f, Locale.US);
                sdf.setTimeZone(TimeZone.getDefault());
                Date d = sdf.parse(s);
                if (d != null) return d.getTime();
            } catch (ParseException ignore) {}
        }
        return -1L;
    }

    private static int[] parseHHmm(String v) {
        int h = 9, m = 0;
        if (!TextUtils.isEmpty(v)) {
            java.util.regex.Matcher m1 = java.util.regex.Pattern.compile("(\d{1,2}):(\d{2})").matcher(v);
            if (m1.find()) {
                try { h = Integer.parseInt(m1.group(1)); } catch (Throwable ignore) {}
                try { m = Integer.parseInt(m1.group(2)); } catch (Throwable ignore) {}
            }
        }
        if (h < 0 || h > 23) h = 9;
        if (m < 0 || m > 59) m = 0;
        return new int[]{h, m};
    }
}
