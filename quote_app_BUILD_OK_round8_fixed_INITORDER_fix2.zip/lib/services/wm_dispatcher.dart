import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/debug_logger.dart';
import '../utils/run_context.dart';
import '../data/db.dart';
import 'notification_service.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    // 保证回调线程环境初始化
    try {
      RunContext.isBackground = true;
      WidgetsFlutterBinding.ensureInitialized();
      ui.DartPluginRegistrant.ensureInitialized();
      await AppDatabase.instance();
      await NotificationService.init();
      await DLog.i('WM', 'callbackDispatcher start: ' + task);

      if (task == 'due_once' || task == 'due_check_periodic') {
        await SchedulerService.callback();
        await DLog.i('WM', 'callback executed: ' + task);
      }
      return true;
    } catch (e, s) {
      await DLog.e('WM', 'init/callback failed: ' + e.toString() + '\n' + s.toString());
      return false;
    }
  });
}
