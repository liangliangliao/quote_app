package com.example.quote_app.bg
import com.example.quote_app.GeoWorker
import com.example.quote_app.NotifyHelper
import com.example.quote_app.data.DbRepo

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import android.os.SystemClock
import android.app.AlarmManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ActivityCompat
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class GatekeeperService : Service() {
  private val channelId = "gatekeeper_fg"
  private var screenReceiver: BroadcastReceiver? = null

  override fun onCreate() {
    super.onCreate()
    // Channel for foreground service
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (nm.getNotificationChannel(channelId) == null) {
        nm.createNotificationChannel(NotificationChannel(channelId, "Gatekeeper Service", NotificationManager.IMPORTANCE_MIN))
      }
    }
    val n = NotificationCompat.Builder(this, channelId)
      .setContentTitle("后台守护")
      .setContentText("提高提醒稳定性")
      .setSmallIcon(android.R.drawable.stat_notify_more)
      .setOngoing(true)
      .build()
    startForeground(11, n)

    val f = IntentFilter().apply {
      addAction(Intent.ACTION_SCREEN_ON)
      addAction(Intent.ACTION_USER_PRESENT)
      addAction(Intent.ACTION_USER_UNLOCKED)
    }
    screenReceiver = object: BroadcastReceiver() {
      override fun onReceive(c: Context, i: Intent) {
        try { DbRepo.log(c, null, "正在解锁屏幕将触发通知发送") } catch (_: Throwable) { }
        // Direct unlock reminder (distinct from geo)
        val granted = if (Build.VERSION.SDK_INT >= 33)
          ActivityCompat.checkSelfPermission(c, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        else true
        if (granted) {
          try {
            DbRepo.log(c, null, "正在发送通知")
            NotifyHelper.send(c, 2000, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null)
            DbRepo.log(c, null, "通知发送成功")
          } catch (_: Throwable) { }
        } else {
          try { DbRepo.log(c, null, "[GatekeeperService] 通知权限未授予，无法发送解锁提醒") } catch (_: Throwable) { }
        }
        // Force a one-off GeoWorker compare regardless of switch
        try {
          val data = Data.Builder().putBoolean("force_unlock_geo", true).build()
          val req = OneTimeWorkRequestBuilder<GeoWorker>().setInputData(data).build()
          WorkManager.getInstance(c).enqueue(req)
        } catch (_: Throwable) { }
      }
    }
    try { ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_EXPORTED) } catch (_: Throwable) { }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
  override fun onBind(intent: Intent?): IBinder? = null

  override fun onTaskRemoved(rootIntent: Intent?) {
    super.onTaskRemoved(rootIntent)
    // Schedule a short restart to keep receiver available (not a poll loop)
    val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val it = Intent(this, GatekeeperService::class.java)
    val flags = if (Build.VERSION.SDK_INT >= 23)
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    else PendingIntent.FLAG_UPDATE_CURRENT
    val pi = PendingIntent.getService(this, 2002, it, flags)
    val at = SystemClock.elapsedRealtime() + 3000L
    try { am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
    catch (_: Throwable) { am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
  }
}