import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/db.dart';
import 'diary_dao.dart';
import 'entry_editor_page.dart';

class EntryEditorPagerPage extends StatefulWidget {
  final int notebookId;
  final int initialEntryId;
  const EntryEditorPagerPage({super.key, required this.notebookId, required this.initialEntryId});

  @override
  State<EntryEditorPagerPage> createState() => _EntryEditorPagerPageState();
}

class _EntryEditorPagerPageState extends State<EntryEditorPagerPage> {
  // Stable base background used during page transitions to avoid white/black
  // flashes. Matches the diary reader mint base.
  static const Color _mintBg = Color(0xFFDDEFE6);

  final _dao = DiaryDao();
  final PageController _controller = PageController(initialPage: 1);
  int _globalIndex = 0;
  int _total = 0;
  bool _hasDiaryBgImage = false;
  String? _diaryBgImagePath;
  final List<DiaryEntry> _pages = []; // loaded entries
  int _index = 1; // current PageView index within (0.._pages.length+1)

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _pages.clear();
    // Read latest diary settings (background image) to drive system nav bar color.
    try {
      final db = await AppDatabase.instance();
      final rows = await db.rawQuery(
        "SELECT diary_bg_image FROM configs ORDER BY id DESC LIMIT 1",
      );
      if (rows.isNotEmpty) {
        final p = (rows.first['diary_bg_image'] ?? '').toString();
        _diaryBgImagePath = p.isNotEmpty ? p : null;
        _hasDiaryBgImage = _diaryBgImagePath != null;
      }
    } catch (_) {
      // ignore
    }
    final e = await _dao.getEntry(widget.initialEntryId);
    if (e != null) _pages.add(e);
    _total = await _dao.countEntries(widget.notebookId);
    final pos = await _dao.positionOfEntry(widget.notebookId, widget.initialEntryId) ?? 0;
    if (mounted) {
      setState(() {
        _globalIndex = pos;
        // _hasDiaryBgImage already derived from configs.
      });
    }
  }

  Future<bool> _ensureOlder() async {
    if (_pages.isEmpty) return false;
    final cur = _pages.last;
    final older = await _dao.neighbor(notebookId: widget.notebookId, cur: cur, newer: false);
    if (older == null) return false;
    if (mounted) setState(() => _pages.add(older));
    return true;
  }

  Future<bool> _ensureNewer() async {
    if (_pages.isEmpty) return false;
    final cur = _pages.first;
    final newer = await _dao.neighbor(notebookId: widget.notebookId, cur: cur, newer: true);
    if (newer == null) return false;
    if (mounted) {
      setState(() {
        _pages.insert(0, newer);
        _index++; // current visual index shifts right by 1
      });
    }
    return true;
  }

  @override
  

Widget _bgWrap(Widget child) {
  final hasBg = _diaryBgImagePath != null && _diaryBgImagePath!.isNotEmpty;
  return Stack(
    fit: StackFit.expand,
    children: [
      const ColoredBox(color: Colors.white),
      if (hasBg)
        Image.file(File(_diaryBgImagePath!), fit: BoxFit.cover),
      child,
    ],
  );
}

Widget build(BuildContext context) {
    final hasBgImage = _diaryBgImagePath != null && _diaryBgImagePath!.isNotEmpty;
    final baseBgColor = hasBgImage ? Colors.transparent : Colors.white;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: hasBgImage ? Colors.transparent : Colors.white,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarContrastEnforced: false,
      ),
      child: _bgWrap(Scaffold(
        backgroundColor: Colors.transparent,
        extendBody: hasBgImage,
        body: SafeArea(
          top: false,
          child: Stack(
            children: [
              ScrollConfiguration(
                behavior: const _NoOverscrollBehavior(),
                child: PageView.builder(
                  physics: EdgeLockPagePhysics(
                    lockToStart: _index <= 0,
                    lockToEnd: _index >= _pages.length - 1,
                    realStartPage: 1,
                    realEndPage: _pages.length,
                    // NOTE: we keep Clamping to avoid Android glow.
                    parent: const ClampingScrollPhysics(),
                  ),
                  controller: _controller,
                  itemCount: _pages.length + 2,
                  onPageChanged: (i) async {
                    // Sentinel: swiping to older
                    if (i == _pages.length + 1) {
                      final ok = await _ensureOlder();
                      if (ok == true) {
                        if (!mounted) return;
                        setState(() {
                          _index = _pages.length;
                          _globalIndex = (_globalIndex + 1).clamp(0, _total - 1);
                        });
                        _controller.jumpToPage(_pages.length);
                      } else {
                        if (mounted) _controller.jumpToPage(_pages.length);
                      }
                      return;
                    }
                    // Sentinel: swiping to newer
                    if (i == 0) {
                      final ok = await _ensureNewer();
                      if (ok == true) {
                        if (!mounted) return;
                        setState(() {
                          _index = 1;
                          _globalIndex = (_globalIndex - 1).clamp(0, _total - 1);
                        });
                        _controller.jumpToPage(1);
                      } else {
                        if (mounted) _controller.jumpToPage(1);
                      }
                      return;
                    }
  
                    final prev = _index;
                    if (mounted) {
                      setState(() {
                        _index = i;
                        _globalIndex = (_globalIndex + (i - prev)).clamp(0, _total - 1);
                      });
                    }
                  },
                  itemBuilder: (ctx, i) {
                    // Keep sentinels for lazy loading.
                    if (i == 0 || i == _pages.length + 1) {
                      // Important: never return a pure white background here.
                      return const ColoredBox(color: _mintBg);
                    }
                    final e = _pages[i - 1];
                    return EntryEditorPage(
                      key: ValueKey<int>(e.id),
                      notebookId: widget.notebookId,
                      entryId: e.id,
                    );
                  },
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                child: SafeArea(
                  top: false,
                  minimum: EdgeInsets.zero,
                  child: DecoratedBox(
                    decoration: BoxDecoration(color: hasBgImage ? Colors.transparent : Colors.black54),
                    child: Text(
                      '${_globalIndex + 1}/$_total',
                      style: const TextStyle(color: Colors.black),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      )),
    );
  }
}

class _NoOverscrollBehavior extends ScrollBehavior {
  const _NoOverscrollBehavior();
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) {
    return child;
  }
}

/// Physics copied from reader to keep UX identical.
///
/// We hard-disable dragging past the first/last entry to avoid revealing
/// any background (white/black) during edge drags.
class EdgeLockPagePhysics extends PageScrollPhysics {
  final bool lockToStart;
  final bool lockToEnd;
  final int realStartPage;
  final int realEndPage;

  const EdgeLockPagePhysics({
    required this.lockToStart,
    required this.lockToEnd,
    required this.realStartPage,
    required this.realEndPage,
    ScrollPhysics? parent,
  }) : super(parent: parent);

  @override
  EdgeLockPagePhysics applyTo(ScrollPhysics? ancestor) => EdgeLockPagePhysics(
        lockToStart: lockToStart,
        lockToEnd: lockToEnd,
        realStartPage: realStartPage,
        realEndPage: realEndPage,
        parent: buildParent(ancestor),
      );

  // Use a small fraction of the viewport as tolerance so the edge lock still
  // works even when `position.pixels` is slightly off due to fractional pages.
  static const double _epsFraction = 0.0; // 8% of viewport

  double _edgeEps(ScrollMetrics position) {
    final vp = position.viewportDimension;
    if (vp.isFinite && vp > 0) return vp * _epsFraction;
    return 8.0;
  }

  double _startPx(ScrollMetrics position) => realStartPage * position.viewportDimension;

  double _endPx(ScrollMetrics position) => realEndPage * position.viewportDimension;

  @override
  double applyBoundaryConditions(ScrollMetrics position, double value) {
    // Hard clamp the scroll extents for the real content pages.
    // This prevents even a tiny drag into the sentinel pages at either end.
    final startPx = _startPx(position);
    final endPx = _endPx(position);
    if (lockToStart && value < startPx) {
      return value - startPx;
    }
    if (lockToEnd && value > endPx) {
      return value - endPx;
    }
    return super.applyBoundaryConditions(position, value);
  }

  @override

  @override
  bool shouldAcceptUserOffset(ScrollMetrics position) {
    final startPx = _startPx(position);
    final endPx = _endPx(position);
    if (lockToStart && position.pixels <= startPx) {
      return false;
    }
    if (lockToEnd && position.pixels >= endPx) {
      return false;
    }
    return true;
  }
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) {
    final startPx = _startPx(position);
    final endPx = _endPx(position);
    final eps = _edgeEps(position);

    if (lockToStart && position.pixels <= startPx + eps && offset > 0) {
      return 0.0;
    }
    if (lockToEnd && position.pixels >= endPx - eps && offset < 0) {
      return 0.0;
    }
    return super.applyPhysicsToUserOffset(position, offset);
  }

  @override
  Simulation? createBallisticSimulation(ScrollMetrics position, double velocity) {
    final startPx = _startPx(position);
    final endPx = _endPx(position);
    final eps = _edgeEps(position);

    if (lockToStart && position.pixels <= startPx + eps && velocity > 0) {
      return null;
    }
    if (lockToEnd && position.pixels >= endPx - eps && velocity < 0) {
      return null;
    }
    return super.createBallisticSimulation(position, velocity);
  }
}