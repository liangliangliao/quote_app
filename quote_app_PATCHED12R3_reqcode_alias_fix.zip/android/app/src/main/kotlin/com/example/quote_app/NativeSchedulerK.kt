package com.example.quote_app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*
import java.util.concurrent.TimeUnit

object NativeSchedulerK {

  private const val UNIQUE_WORK_PREFIX = "wm_once_"

  private fun buildPi(ctx: Context, id: Int, payload: String?): PendingIntent {
    val i = Intent(ctx, com.example.quote_app.am.AlarmReceiver::class.java)
      .putExtra("id", id)
      .putExtra("payload", payload ?: "{}")
    val flags = if (Build.VERSION.SDK_INT >= 23)
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    else PendingIntent.FLAG_UPDATE_CURRENT
    return PendingIntent.getBroadcast(ctx, id, i, flags)
  }

  @JvmStatic
  fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val pi = buildPi(ctx, id, payload)
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        com.example.quote_app.data.DbRepository.log(ctx, null, \"【原生】AM 计划 at=\"+epochMs);
        \1
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
      }
      true
    } catch (_: Throwable) { false }
  }

  fun scheduleWmFallback(ctx: Context, id: Int, epochMs: Long, payload: String): Boolean {
    val delay = kotlin.math.max(0, epochMs - System.currentTimeMillis())
    val data = Data.Builder().putInt("id", id).putString("payload", payload).build()
    val req = OneTimeWorkRequestBuilder<NotifyWorker>()
      .setInitialDelay(delay, TimeUnit.MILLISECONDS)
      .setInputData(data)
      .addTag(UNIQUE_WORK_PREFIX + id)
      .build()
    return try {
      WorkManager.getInstance(ctx).enqueueUniqueWork(
        UNIQUE_WORK_PREFIX + id,
        ExistingWorkPolicy.REPLACE,
        req
      )
      true
    } catch (_: Throwable) { false }
  }

  @JvmStatic
  fun scheduleExactWmCompat(ctx: Context, id: Int, epochMs: Long, payload: String?): Boolean {
    val ok = scheduleExactAt(ctx, id, epochMs, payload)
    if (!ok) scheduleWmFallback(ctx, id, epochMs, payload ?: "{}")
    return ok
  }

  @JvmStatic
  fun cancel(ctx: Context, id: Int) {
    try {
      val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
      am.cancel(buildPi(ctx, id, null))
    } catch (_: Throwable) {}
    try {
      WorkManager.getInstance(ctx).cancelUniqueWork(UNIQUE_WORK_PREFIX + id)
    } catch (_: Throwable) {}
  }

  @JvmStatic
  fun cancelAll(ctx: Context) {
    try { WorkManager.getInstance(ctx).cancelAllWork() } catch (_: Throwable) {}
  }

  fun scheduleSelfCheck(ctx: Context, minutes: Int): Boolean {
    val data = Data.Builder().putString("job","selfcheck").build()
    val req = OneTimeWorkRequestBuilder<SelfCheckWorker>()
      .setInitialDelay(minutes.toLong(), TimeUnit.MINUTES)
      .setInputData(data)
      .build()
    return try {
      com.example.quote_app.data.DbRepository.log(ctx, null, "【原生】WM 自检计划 +"+minutes+"min");
      WorkManager.getInstance(ctx).enqueue(req)
      true
    } catch (_: Throwable) { false }
  }
}