import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import '../services/notification_service.dart';
import '../services/openai_service.dart';

class SchedulerService {
  static Future<void> init() async {
    await AndroidAlarmManager.initialize();
    await scheduleNextForAll();
  }

  static Future<void> scheduleNextForAll() async {
    final dao = TaskDao();
    final tasks = await dao.all();
    final now = DateTime.now();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final next = _nextTrigger(now, t);
      if (next == null) continue;
      final id = (t['task_uid'] as String).hashCode & 0x7fffffff;
      await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: true,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );
    }
  }

  static DateTime? _nextTrigger(DateTime now, Map<String, dynamic> task) {
    final st = (task['start_time'] as String? ?? '').trim();
    if (st.isEmpty) return null;
    DateTime base;
    try {
      final parts = st.split(' ');
      final d = parts[0].split('-').map(int.parse).toList();
      final tm = parts[1].split(':').map(int.parse).toList();
      base = DateTime(d[0], d[1], d[2], tm[0], tm[1]);
    } catch (_) {
      return null;
    }
    final freq = (task['freq_type'] ?? 'daily') as String;
    if (freq == 'daily') {
      final today = DateTime(now.year, now.month, now.day, base.hour, base.minute);
      if (today.isAfter(now)) return today;
      return today.add(const Duration(days: 1));
    } else if (freq == 'weekly') {
      final target = (task['freq_weekday'] as int?) ?? 1; // 1..7
      final today = DateTime(now.year, now.month, now.day, base.hour, base.minute);
      int delta = (target - now.weekday) % 7;
      var cand = today.add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freq == 'monthly') {
      final day = (task['freq_day_of_month'] as int?) ?? 1;
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, day.clamp(1, end), base.hour, base.minute);
      if (!cand.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, day.clamp(1, end), base.hour, base.minute);
      }
      return cand;
    } else {
      final today = DateTime(now.year, now.month, now.day, base.hour, base.minute);
      if (today.isAfter(now)) return today;
      return today.add(const Duration(days: 1));
    }
  }

  static Future<void> callback() async {
    final now = DateTime.now();
    final hhmm = DateFormat('HH:mm').format(now);
    final tasks = await TaskDao().all();
    final cfg = await ConfigDao().getOne();

    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;

      final st = (t['start_time'] as String? ?? '');
      final stHm = st.split(' ').last.split(':').take(2).join(':');
      if (stHm != hhmm) continue;

      final freq = (t['freq_type'] ?? 'daily') as String;
      if (freq == 'weekly') {
        final wd = (t['freq_weekday'] as int?) ?? 1;
        if (now.weekday != wd) continue;
      } else if (freq == 'monthly') {
        final d = (t['freq_day_of_month'] as int?) ?? 1;
        if (now.day != d) continue;
      }

      final type = (t['type'] ?? 'auto') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final taskUid = (t['task_uid'] as String);

      if (type == 'manual') {
        final db = await AppDatabase.instance();
        final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
        if (rows.isEmpty) continue;
        final content = (rows.first['content'] ?? '') as String;
        if (content.isEmpty) continue;
        await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
        continue;
      }

      if (type == 'carousel') {
        final db = await AppDatabase.instance();
        final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC');
        if (rows.isEmpty) continue;
        final metaKey = 'carousel_index_$taskUid';
        final m = await db.query('meta', where: 'key=?', whereArgs: [metaKey], limit: 1);
        int idx = 0;
        if (m.isNotEmpty) {
          idx = int.tryParse((m.first['value'] ?? '0') as String) ?? 0;
        }
        idx = idx % rows.length;
        final content = (rows[idx]['content'] ?? '') as String;
        if (content.isEmpty) continue;
        await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
        final nextIndex = (idx + 1) % rows.length;
        await db.insert('meta', {'key': metaKey, 'value': nextIndex.toString()}, conflictAlgorithm: ConflictAlgorithm.replace);
        continue;
      }

      // auto
      try {
        final openai = OpenAIService(
          endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
          apiKey: (cfg['api_key'] ?? '') as String,
          model: (cfg['model'] ?? 'gpt-5') as String,
        );
        final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;
        String? uid;
        for (int i=0; i<10; i++) {
          final quote = (await openai.generateQuote(prompt)).trim();
          if (quote.isEmpty) break;
          final exists = await QuoteDao().existsSimilar(quote, threshold: 0.9);
          if (exists) {
            if (i==9) {
              await LogDao().add(taskUid: taskUid, detail: '错误! 连续调用api10次去重检验未通过！');
            }
            continue;
          }
          uid = await QuoteDao().insert(taskUid: taskUid, content: quote, taskName: name, taskType: 'auto', avatarPath: avatar);
          break;
        }
        await LogDao().add(taskUid: taskUid, detail: uid==null ? '错误! 插入名言失败（可能重复）' : '成功!');
        if (uid != null) {
          final content = (await QuoteDao().getByUid(uid))?['content'] as String? ?? '';
          if (content.isNotEmpty) {
            await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
            await QuoteDao().markNotifiedByUid(uid);
          }
        }
      } catch (e) {
        await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
      }
    }

    await scheduleNextForAll();
  }
}

@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await AppDatabase.instance();
  await SchedulerService.callback();
}