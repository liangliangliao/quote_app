// lib/utils/bg_audit.dart
// Minimal, dependency-light background trigger audit.
// Stores JSONL events in app documents directory, up to 200 lines.

import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

import 'package:path_provider/path_provider.dart';

class BgAudit {
  static const _fileName = 'bg_events_v1.jsonl';

  static Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  /// Append a background event record.
  static Future<void> mark({
    required String source, // 'alarm' | 'work'
    required String label,
    String? note,
  }) async {
    final f = await _file();
    final event = <String, dynamic>{
      'ts': DateTime.now().toIso8601String(),
      'source': source,
      'label': label,
      'note': note,
      'isolate': Isolate.current.debugName ?? 'bg',
    };
    try {
      // Ensure file exists
      if (!(await f.exists())) {
        await f.create(recursive: true);
      }
      // Append as JSONL
      await f.writeAsString(jsonEncode(event) + '\n', mode: FileMode.append, flush: true);

      // Trim to last 200 lines to avoid growth
      final content = await f.readAsString();
      final lines = content.split('\n').where((e) => e.trim().isNotEmpty).toList();
      if (lines.length > 200) {
        final trimmed = lines.sublist(lines.length - 200).join('\n') + '\n';
        await f.writeAsString(trimmed, flush: true);
      }
    } catch (_) {
      // swallow I/O errors to avoid crashing background isolate
    }
  }

  /// Read all events (newest first).
  static Future<List<Map<String, dynamic>>> readAll() async {
    try {
      final f = await _file();
      if (!await f.exists()) return [];
      final content = await f.readAsString();
      final lines = content.split('\n').where((e) => e.trim().isNotEmpty).toList();
      final events = <Map<String, dynamic>>[];
      for (final line in lines) {
        try {
          events.add(jsonDecode(line) as Map<String, dynamic>);
        } catch (_) {}
      }
      return events.reversed.toList(); // newest first
    } catch (_) {
      return [];
    }
  }
}
