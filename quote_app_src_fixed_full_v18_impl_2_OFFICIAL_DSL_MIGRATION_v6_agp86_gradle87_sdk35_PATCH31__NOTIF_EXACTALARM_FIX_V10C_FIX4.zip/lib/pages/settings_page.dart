import 'package:flutter/material.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _busy = false;
  String _msg = '';

  Future<void> _reschedule() async {
    setState(()=> _busy = true);
    try {
      await SchedulerService.scheduleNextForAll();
      setState(()=> _msg = '已重排所有任务（根据权限自动选择精确/后台轮询）');
    } catch (e) {
      setState(()=> _msg = '重排失败：$e');
    } finally {
      setState(()=> _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('通知与定时设置', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _busy ? null : _reschedule,
              icon: const Icon(Icons.schedule),
              label: const Text('重排全部任务'),
            ),
            const SizedBox(height: 12),
            if (_msg.isNotEmpty) Text(_msg),
          ],
        ),
      ),
    );
  }
}
