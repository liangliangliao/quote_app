
import 'dart:convert';
import 'package:flutter/material.dart';

class _NoIndicatorScroll extends ScrollBehavior {
  @override
  Widget buildViewportChrome(BuildContext context, Widget child, AxisDirection axisDirection) => child;
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const ClampingScrollPhysics();
}

class OctagonClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final w = size.width, h = size.height;
    final c = 0.18;
    final p = Path()
      ..moveTo(c*w, 0)
      ..lineTo(w-c*w, 0)
      ..lineTo(w, c*h)
      ..lineTo(w, h-c*h)
      ..lineTo(w-c*w, h)
      ..lineTo(c*w, h)
      ..lineTo(0, h-c*h)
      ..lineTo(0, c*h)
      ..close();
    return p;
  }
  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

ImageProvider _imageFrom(String? any, {String? fallbackAsset}) {
  if (any == null || any.isEmpty) return AssetImage(fallbackAsset ?? 'assets/bg-wood-upload.jpg');
  if (any.startsWith('data:')) {
    final b64 = any.substring(any.indexOf(',')+1);
    return MemoryImage(base64.decode(b64));
  }
  if (any.startsWith('http')) return NetworkImage(any);
  if (any.startsWith('assets/')) return AssetImage(any);
  return AssetImage(fallbackAsset ?? 'assets/bg-wood-upload.jpg');
}

/// 纯 Flutter 版相框海报
class PosterPureFlutter extends StatelessWidget {
  final String topic;
  final String quote;
  final String author;
  final String note;
  final String avatar;
  final String woodBgAsset;

  const PosterPureFlutter({
    super.key,
    required this.topic,
    required this.quote,
    required this.author,
    required this.note,
    required this.avatar,
    this.woodBgAsset = 'assets/bg-wood-upload.jpg',
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final short = (cons.maxWidth < cons.maxHeight) ? cons.maxWidth : cons.maxHeight;
      final tTitle = (short * 0.050).clamp(16.0, 26.0);
      final tQuote = (short * 0.085).clamp(22.0, 40.0);
      final tAuth  = (short * 0.044).clamp(14.0, 22.0);
      final tNote  = (short * 0.040).clamp(12.0, 18.0);
      final frameTop = (short * 0.035).clamp(14.0, 24.0);
      final frameBottom = (short * 0.035).clamp(14.0, 24.0);
      final canvasPad = (short * 0.040).clamp(18.0, 28.0);
      final avatarSize = (short * 0.17).clamp(60.0, 110.0);

      return Container(
        color: Colors.white,
        alignment: Alignment.topCenter,
        padding: EdgeInsets.only(top: (short * 0.10).clamp(30.0, 60.0)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Container(
            decoration: BoxDecoration(
              image: DecorationImage(image: AssetImage(woodBgAsset), fit: BoxFit.cover),
              borderRadius: BorderRadius.circular(6),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 18, spreadRadius: 2, offset: Offset(0,8))],
            ),
            child: Padding(
              // 要求：相框里的左右内边距为25dp（顶/底保持视觉比例）
              padding: EdgeInsets.only(left: 25, right: 25, top: frameTop, bottom: frameBottom),
              child: Container(
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4)),
                child: Padding(
                  padding: EdgeInsets.all(canvasPad),
                  child: ScrollConfiguration(
                    behavior: _NoIndicatorScroll(),
                    child: SingleChildScrollView(
                      physics: const ClampingScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Text(
                                  topic,
                                  style: TextStyle(color: Colors.black87, fontSize: tTitle, height: 1.35, fontWeight: FontWeight.w500),
                                ),
                              ),
                              SizedBox(width: 16),
                              ClipPath(
                                clipper: OctagonClipper(),
                                child: Container(
                                  width: avatarSize, height: avatarSize,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(image: _imageFrom(avatar, fallbackAsset: woodBgAsset), fit: BoxFit.cover),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: canvasPad * 0.6),
                          Text(quote, style: TextStyle(color: Colors.black87, fontSize: tQuote, height: 1.4, fontWeight: FontWeight.w700)),
                          SizedBox(height: canvasPad * 0.5),
                          Text(author, style: TextStyle(color: Colors.black87, fontSize: tAuth, height: 1.35, fontStyle: FontStyle.italic, fontWeight: FontWeight.w600)),
                          SizedBox(height: canvasPad * 0.5),
                          Text(note, style: TextStyle(color: Colors.black87, fontSize: tNote, height: 1.55)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
