import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import '../platform/perm_helper.dart';

class SchedulerService {
  static final DateFormat dateFormat = DateFormat('yyyy-MM-dd HH:mm');

  static String _fmt(DateTime dt) => dateFormat.format(dt);

  static String _diffHuman(Duration d) {
    final sign = d.isNegative ? "-" : "";
    final dd = d.abs();
    final h = dd.inHours;
    final m = dd.inMinutes % 60;
    final s = dd.inSeconds % 60;
    if (h > 0) return "${sign}${h}h${m}m";
    if (m > 0) return "${sign}${m}m${s}s";
    return "${sign}${s}s";
  }

  static Future<void> init() async {
    await AndroidAlarmManager.initialize();
    await NotificationService.init();

    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (!ok) {
        await LogDao().add(taskUid: 'system',
          detail: '警告! 系统未授予精确闹钟权限(Alarms & reminders)。Android 14+ 默认关闭。');
      }
    } catch (_) {}

    await LogDao().add(taskUid: 'system', detail: '[Scheduler] scheduleNextForAll() start');
    await scheduleNextForAll();
    await LogDao().add(taskUid: 'system', detail: '[Scheduler] init() done');
  }

  static int _alarmIdForTask(String taskUid) {
    // stable 31-bit hash
    int h = 0;
    for (int i = 0; i < taskUid.length; i++) {
      h = (h * 131 + taskUid.codeUnitAt(i)) & 0x7fffffff;
    }
    return h;
  }

  static DateTime _computeNext(Map<String, dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    final String freq = (t['freq_type'] ?? 'daily') as String;
    final int? weekday = t['freq_weekday'] as int?; // 1-7 (Mon..Sun)
    final int? dayOfMonth = t['freq_day_of_month'] as int?;

    final startStr = (t['start_time'] ?? '') as String;
    int hh = 9, mm = 0;
    if (startStr.contains(' ')) {
      final hm = startStr.split(' ')[1].split(':');
      if (hm.length == 2) {
        hh = int.tryParse(hm[0]) ?? 9;
        mm = int.tryParse(hm[1]) ?? 0;
      }
    }

    if (freq == 'weekly') {
      final wd = (weekday ?? 1);
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freq == 'monthly') {
      final d = (dayOfMonth ?? 1);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      // daily
      final today = DateTime(now.year, now.month, now.day, hh, mm);
      if (today.isAfter(now)) return today;
      return today.add(const Duration(days: 1));
    }
  }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    await LogDao().add(taskUid: 'system', detail: '[Scheduler] scheduleNextForAll() tasks=${tasks.length}');
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final next = _computeNext(t);
      await LogDao().add(taskUid: 'system',
        detail: "[Scheduler] schedule task=${(t['task_uid'] as String? ?? '')} next=${_fmt(next)} (下次间隔 in ${_diffHuman(next.difference(DateTime.now()))})");
      // Persist into tasks.start_time for visibility
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [t['task_uid']]);

      final id = _alarmIdForTask(t['task_uid'] as String);
      try {
        await AndroidAlarmManager.oneShotAt(
          next,
          id,
          alarmCallback,
          exact: true,
          wakeup: true,
          allowWhileIdle: true,
          rescheduleOnReboot: true,
        );
        await LogDao().add(taskUid: 'system', detail: "[Scheduler] oneShotAt scheduled id=${id} at=${_fmt(next)}");
      } catch (e) {
        await LogDao().add(taskUid: 'system', detail: "[Scheduler][ERR] schedule oneShotAt: $e");
      }
    }
  }

  static Future<void> callback() async {
    await LogDao().add(taskUid: 'system', detail: '[Scheduler] callback() start');
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    await LogDao().add(taskUid: 'system', detail: '[Scheduler] now=${_fmt(now)}');

    final tasks = await db.query('tasks');
    await LogDao().add(taskUid: 'system', detail: '[Scheduler] tasks=${tasks.length}');
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final start = (t['start_time'] ?? '') as String;
      if (start.isEmpty) {
        await LogDao().add(taskUid: 'system', detail: '[Scheduler] skip: empty start_time');
        continue;
      }
      if (!_isDue(start, now)) {
        await LogDao().add(taskUid: 'system',
          detail: "[Scheduler] skip: not due (未到触发窗口) start=$start now=${_fmt(now)} diff=${_diffHuman(now.difference(DateTime.parse(start)))} thr=59s");
        continue;
      }

      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        final content = (q?['content'] ?? '') as String;
        if (content.isNotEmpty) {
          await LogDao().add(taskUid: 'system', detail: "[Scheduler] due (命中窗口/within) start=$start now=${_fmt(now)} diff=${_diffHuman(now.difference(DateTime.parse(start)))} thr=59s");
          await LogDao().add(taskUid: 'system', detail: "[Scheduler] show begin id=${_alarmIdForTask(taskUid)} type=${type} task=$taskUid");
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          await LogDao().add(taskUid: 'system', detail: "[Scheduler] show done id=${_alarmIdForTask(taskUid)}");
          await LogDao().add(taskUid: taskUid, detail: '手动任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '手动任务无可用名言');
        }
      } else {
        // auto
        final cfg = await ConfigDao().getOne();
        try {
          final openai = OpenAIService(
            endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
            apiKey: (cfg['api_key'] ?? '') as String,
            model: (cfg['model'] ?? 'gpt-5') as String,
          );
          final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;

          String? uid;
          for (int i = 0; i < 10; i++) {
            final quote = (await openai.generateQuote(prompt)).trim();
            if (quote.isEmpty) break;
            final exists = await QuoteDao().existsSimilar(quote, threshold: 0.9);
            if (exists) {
              if (i == 9) {
                await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
              }
              continue;
            }
            uid = await QuoteDao().insertIfUnique(
              taskUid: taskUid,
              type: type,
              taskName: name,
              avatarPath: avatar,
              content: quote,
            );
            if (uid.isNotEmpty) break;
          }

          final q = await QuoteDao().latestForTask(taskUid);
          final content = (q?['content'] ?? '') as String;
          if (content.isNotEmpty) {
            await LogDao().add(taskUid: 'system', detail: "[Scheduler] due (命中窗口/within) start=$start now=${_fmt(now)} diff=${_diffHuman(now.difference(DateTime.parse(start)))} thr=59s");
            await LogDao().add(taskUid: 'system', detail: "[Scheduler] show begin id=${_alarmIdForTask(taskUid)} type=${type} task=$taskUid");
            await NotificationService.show(
              id: _alarmIdForTask(taskUid),
              title: name,
              body: content,
              largeIconPath: avatar.isEmpty ? null : avatar,
            );
            await LogDao().add(taskUid: 'system', detail: "[Scheduler] show done id=${_alarmIdForTask(taskUid)}");
            await QuoteDao().markNotified(q!['id'] as int);
            await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送');
          } else {
            await LogDao().add(taskUid: taskUid, detail: '自动任务生成失败或无内容');
          }
        } catch (e) {
          await LogDao().add(taskUid: 'system', detail: '[Scheduler][ERR] openai or insert: $e');
        }
      }

      // After firing: compute next and persist + reschedule
      final next = _computeNext(t, from: now.add(const Duration(seconds: 1)));
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
      await LogDao().add(taskUid: 'system',
        detail: "[Scheduler] reschedule next=${_fmt(next)} for task=$taskUid (下次间隔 in ${_diffHuman(next.difference(DateTime.now()))})");
      final id = _alarmIdForTask(taskUid);
      try {
        await AndroidAlarmManager.oneShotAt(
          next,
          id,
          alarmCallback,
          exact: true,
          wakeup: true,
          allowWhileIdle: true,
          rescheduleOnReboot: true,
        );
        await LogDao().add(taskUid: 'system', detail: "[Scheduler] oneShotAt scheduled id=${id} at=${_fmt(next)}");
      } catch (e) {
        await LogDao().add(taskUid: 'system', detail: "[Scheduler][ERR] schedule oneShotAt: $e");
      }
    }
  }

  static bool _isDue(String startStr, DateTime now) {
    try {
      final start = dateFormat.parse(startStr);
      final diff = now.difference(start).inSeconds;
      return diff >= 0 && diff <= 59;
    } catch (e) {
      return false;
    }
  }

  // entry point for AndroidAlarmManager
  static Future<void> alarmCallback() async {
    WidgetsFlutterBinding.ensureInitialized();
    await AppDatabase.instance();
    try { await LogDao().add(taskUid: 'system', detail: '[Alarm] alarmCallback entry'); } catch (_) {}
    await SchedulerService.callback();
  }
}
