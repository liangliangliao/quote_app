package com.example.quote_app

import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.widget.RemoteViews
import android.widget.TextView
import androidx.core.widget.TextViewCompat
import kotlin.math.max
import kotlin.math.ceil

object NotifSystemHeader512_CustomBody {

    private fun dp(ctx: Context, v: Float) = v * ctx.resources.displayMetrics.density
    private fun sp(ctx: Context, v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, ctx.resources.displayMetrics)

    // 系统正文样式 → 复制后再做“加粗/加大/加字距”
    private fun obtainCustomBodyPaint(ctx: Context): TextPaint {
        val tv = TextView(ctx)
        val candidates = intArrayOf(
            com.google.android.material.R.attr.textAppearanceBodyMedium,
            com.google.android.material.R.attr.textAppearanceBodyLarge,
            android.R.attr.textAppearance
        )
        val tvv = TypedValue()
        for (attr in candidates) {
            if (ctx.theme.resolveAttribute(attr, tvv, true) && tvv.resourceId != 0) {
                TextViewCompat.setTextAppearance(tv, tvv.resourceId)
                break
            }
        }
        return TextPaint(tv.paint).apply {
            isFakeBoldText = true               // 加粗
            textSize = tv.textSize + sp(ctx, 2f) // 比标题略大（近似 +2sp）
            if (Build.VERSION.SDK_INT >= 21) {
                letterSpacing = 0.03f           // 字间距略拉宽
            }
            color = tv.currentTextColor
        }
    }

    // 尽量估算系统通知的左右留白，确保文本到达右边缘
    private fun systemNotifSidePadding(ctx: Context): Pair<Int, Int> {
        fun dimen(name: String): Int {
            val id = ctx.resources.getIdentifier(name, "dimen", "android")
            return if (id != 0) ctx.resources.getDimensionPixelSize(id) else 0
        }
        val start = listOf("notification_content_margin_start","notification_side_paddings","notification_content_margin")
            .map { dimen(it) }.maxOrNull() ?: 0
        val end = listOf("notification_content_margin_end","notification_side_paddings","notification_content_margin")
            .map { dimen(it) }.maxOrNull() ?: 0
        return start to end
    }
    private fun computeAvailWidth(ctx: Context): Int {
        val screen = ctx.resources.displayMetrics.widthPixels
        val (s,e) = systemNotifSidePadding(ctx)
        val contentPadId = ctx.resources.getIdentifier("notification_content_margin", "dimen", "android")
        val contentPad = if (contentPadId != 0) ctx.resources.getDimensionPixelSize(contentPadId) else 0
        return max(256, screen - s - e - contentPad * 2)
    }

    private fun renderTopBitmap(ctx: Context, text: String, avail: Int, lines: Int): Bitmap {
        val p = obtainCustomBodyPaint(ctx)
        val layout = if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, p, avail)
                .setIncludePad(false)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, p, avail, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }
        val take = maxOf(1, minOf(lines, layout.lineCount))
        val fm = p.fontMetrics
        val lineH = (fm.descent - fm.ascent)
        val bmp = Bitmap.createBitmap(avail, ceil(lineH * take.toDouble()).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        var base = -fm.ascent
        for (i in 0 until take) {
            val s = layout.getLineStart(i)
            val e = layout.getLineEnd(i)
            val l = text.substring(s, e).trimEnd('\n',' ')
            c.drawText(l, 0f, base, p)
            base += lineH
        }
        return bmp
    }

    fun buildRemoteViews(ctx: Context, layoutRes: Int, body: String, collapsed: Boolean): RemoteViews {
        val topLines = 5
        val total = if (collapsed) 5 else 12
        val avail = computeAvailWidth(ctx)

        // 先用“自定义正文 Paint”测量并切成 5 行 + 其余
        val p = obtainCustomBodyPaint(ctx)
        val measure = if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(body, 0, body.length, p, avail)
                .setIncludePad(false)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED).build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(body, p, avail, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }
        val cut = if (measure.lineCount > 0) measure.getLineEnd(minOf(topLines - 1, measure.lineCount - 1)) else 0
        val topText = if (cut > 0) body.substring(0, cut) else body
        val bottomText = if (cut < body.length) body.substring(cut).trimStart() else ""

        val bmp = renderTopBitmap(ctx, topText, avail, topLines)

        return RemoteViews(ctx.packageName, layoutRes).apply {
            setImageViewBitmap(R.id.body_top_bitmap, bmp)
            if (total > topLines) {
                setTextViewText(R.id.body_bottom, bottomText)
                // 统一底部段落的样式：加粗 + 大一点 + 加字距（与上方一致）
                setTextViewTextSize(R.id.body_bottom, TypedValue.COMPLEX_UNIT_SP, 17f)
                setFloat(R.id.body_bottom, "setLetterSpacing", 0.03f)
                // 7 行（展开时）；折叠时不显示
                setInt(R.id.body_bottom, "setMaxLines", total - topLines)
            } else {
                setTextViewText(R.id.body_bottom, "")
            }
        }
    }
}
