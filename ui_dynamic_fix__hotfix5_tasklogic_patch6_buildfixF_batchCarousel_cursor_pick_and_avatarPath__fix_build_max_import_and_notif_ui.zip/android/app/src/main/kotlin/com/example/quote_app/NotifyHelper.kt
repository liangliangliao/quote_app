package com.example.quote_app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationCompat.DecoratedCustomViewStyle
import android.widget.RemoteViews

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"
  private const val DEFAULT_CHANNEL_NAME = "Quotes"

  @JvmStatic
  fun send(ctx: Context, id: Int, title: String, body: String, avatarPath: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Android 13+ 需要 POST_NOTIFICATIONS 运行时权限；若缺失，静默失败。这里直接短路并记录。
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
        return
      }
    }

    // 系统级通知开关被关也会静默丢弃
    if (!nm.areNotificationsEnabled()) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: notifications disabled at system level") } catch (_: Throwable) {}
      return
    }

    // 8.0+ 必须先创建渠道
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(
        DEFAULT_CHANNEL_ID,
        DEFAULT_CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      )
      nm.createNotificationChannel(ch)
    }

    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      .setStyle(DecoratedCustomViewStyle())

    
    try {
      val collapsed = NotifSystemHeader512_CustomBody.build(ctx, R.layout.notif_card_body_only_custom_body, body, 3, 3)
      val expanded = NotifSystemHeader512_CustomBody.build(ctx, R.layout.notif_card_body_only_custom_body, body, 3, 7)
      builder.setCustomContentView(collapsed)
      builder.setCustomBigContentView(expanded)
    } catch (_: Throwable) {}

    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }

    nm.notify(id, builder.build())
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] posted id="+id+" chan="+DEFAULT_CHANNEL_ID) } catch (_: Throwable) {}
  }
}
