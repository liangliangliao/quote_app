import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/debug_logger.dart';
import 'scheduler_service.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      ui.DartPluginRegistrant.ensureInitialized();

      final uid = (inputData?['uid'] ?? '').toString();
      final runKey = (inputData?['run_key'] ?? '').toString();

      if (task == 'bg_selfcheck') {
        await DLog.i('WM', '自检触发');
        await SchedulerService.selfCheckCatchUp();
        return Future.value(true);
      }

      if (task == 'task_fire' && uid.isNotEmpty && runKey.isNotEmpty) {
        await DLog.i('WM', 'WM触发 uid=$uid runKey=$runKey');
        await SchedulerService.wmRunTask(uid, runKey);
        return Future.value(true);
      }

      await DLog.w('WM', '未知任务: $task  data=$inputData');
      return Future.value(false);
    } catch (e) {
      await DLog.e('WM', '回调异常: $e');
      return Future.value(false);
    }
  });
}
