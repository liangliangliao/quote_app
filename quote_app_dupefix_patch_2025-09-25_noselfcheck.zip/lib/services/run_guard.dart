import 'package:sqflite/sqflite.dart';
import '../data/db.dart';
import '../utils/debug_logger.dart';

class RunGuard {
  static Future<void> _ensureTables(Database db) async {
    await db.execute(
      "CREATE TABLE IF NOT EXISTS run_guard("
      "uid TEXT NOT NULL,"
      "run_key TEXT NOT NULL,"
      "source TEXT,"
      "ts INTEGER DEFAULT (strftime('%s','now')),"
      "PRIMARY KEY(uid, run_key)"
      ")"
    );
    await db.execute(
      "CREATE TABLE IF NOT EXISTS pending_run("
      "uid TEXT PRIMARY KEY,"
      "run_key TEXT,"
      "wm_unique TEXT,"
      "alarm_id INTEGER"
      ")"
    );
  }

  /// Returns true if this is the first (winning) execution for (uid, runKey).
  static Future<bool> begin(String uid, String runKey, {String source = ''}) async {
    final db = await AppDatabase.instance();
    await _ensureTables(db);
    try {
      await db.insert('run_guard', {
        'uid': uid,
        'run_key': runKey,
        'source': source,
        'ts': DateTime.now().millisecondsSinceEpoch
      });
      return true;
    } catch (e) {
      await DLog.w('RunGuard', 'dup run suppressed uid=$uid runKey=$runKey src=$source');
      return false;
    }
  }

  static Future<void> clearPending(String uid) async {
    final db = await AppDatabase.instance();
    await _ensureTables(db);
    await db.delete('pending_run', where: 'uid=?', whereArgs: [uid]);
  }

  static Future<Map<String, Object?>?> getPending(String uid) async {
    final db = await AppDatabase.instance();
    await _ensureTables(db);
    final rows = await db.query('pending_run', where: 'uid=?', whereArgs: [uid], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  static Future<void> savePending({
    required String uid,
    required String runKey,
    String wmUnique = '',
    int alarmId = 0,
  }) async {
    final db = await AppDatabase.instance();
    await _ensureTables(db);
    await db.insert('pending_run', {
      'uid': uid,
      'run_key': runKey,
      'wm_unique': wmUnique,
      'alarm_id': alarmId,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
