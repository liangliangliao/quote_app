import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/debug_logger.dart';
import '../platform/perm_helper.dart';
import 'notification_service.dart';
import 'run_guard.dart';

typedef Json = Map<String, dynamic>;

class SchedulerService {
  // ---------------- RunKey 统一规则 ----------------
  static String _runKey(String uid, DateTime whenUtc) {
    // 以分钟对齐，跨渠道一致
    final minute = whenUtc.millisecondsSinceEpoch ~/ 60000;
    return '$uid@$minute';
  }

  // 生成稳定的 AlarmId（避免与其他任务冲突）
  static int _alarmId(String uid, DateTime whenUtc) {
    final minute = whenUtc.millisecondsSinceEpoch ~/ 60000;
    return (uid.hashCode ^ minute ^ 0x5F3759DF) & 0x7fffffff;
  }

  // ---------------- 对外 API ----------------
  static Future<void> init() async {
    await DLog.i('SCH', 'init');
    // WorkManager 初始化由插件完成；此处只确保自检已注册（如果你已有初始化，请忽略）
  }

  /// 安排一次任务：在 when 本地时间触发
  static Future<void> scheduleOnce({
    required String uid,
    required DateTime whenLocal,
    required String title,
    required String body,
  }) async {
    final whenUtc = whenLocal.toUtc();
    final runKey = _runKey(uid, whenUtc);
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'schedule uid=$uid when=$whenLocal hasExact=$hasExact');

    // 先记录 pending，便于后续取消时判断是否有必要
    final wmUnique = 'next_$uid';
    final alarmId = _alarmId(uid, whenUtc);
    await RunGuard.savePending(uid: uid, runKey: runKey, wmUnique: wmUnique, alarmId: alarmId);

    if (hasExact) {
      // 使用 AlarmManager 精确触发
      await AndroidAlarmManager.oneShotAt(
        whenLocal,
        alarmId,
        _alarmCallback,
        exact: true,
        allowWhileIdle: true,
        wakeup: true,
        rescheduleOnReboot: true,
        params: <String, dynamic>{'uid': uid, 'run_key': runKey, 'title': title, 'body': body},
      );
      await DLog.i('SCH', '已注册 AM 精确闹钟 id=$alarmId runKey=$runKey');
      // 不再并行注册 WM，避免双发；若 AM 失败，依赖“自检补发”兜底
    } else {
      // 无精确权限：只注册 WM 单通道（KEEP 防重复）
      final delay = whenLocal.difference(DateTime.now());
      await Workmanager().registerOneOffTask(
        wmUnique,
        'task_fire',
        inputData: {'uid': uid, 'run_key': runKey, 'title': title, 'body': body},
        existingWorkPolicy: ExistingWorkPolicy.keep,
        initialDelay: delay.isNegative ? const Duration(seconds: 1) : delay,
        backoffPolicy: BackoffPolicy.linear,
        backoffPolicyDelay: const Duration(minutes: 5),
      );
      await DLog.i('SCH', '已注册 WM 一次性任务 name=$wmUnique runKey=$runKey');
    }
  }

  /// 取消下一次任务（仅在确有 pending 时执行，避免多余日志）
  static Future<void> cancelNextForTask(String uid) async {
    final pending = await RunGuard.getPending(uid);
    if (pending == null) {
      await DLog.i('SCH', '无待取消任务 uid=$uid（跳过）');
      return;
    }
    final wmUnique = (pending['wm_unique'] ?? '').toString();
    final alarmId = (pending['alarm_id'] ?? 0) as int? ?? 0;
    try {
      if (alarmId != 0) {
        await AndroidAlarmManager.cancel(alarmId);
        await DLog.i('SCH', '已取消 AM id=$alarmId');
      }
    } catch (_) {}
    try {
      if (wmUnique.isNotEmpty) {
        await Workmanager().cancelByUniqueName(wmUnique);
        await DLog.i('SCH', '已取消 WM name=$wmUnique');
      }
    } catch (_) {}
    await RunGuard.clearPending(uid);
    await DLog.i('SCH', '取消完成 uid=$uid');
  }

  // ---------------- 执行路径 ----------------
  @pragma('vm:entry-point')
  static Future<void> _alarmCallback(int id, Map<String, dynamic> params) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      ui.DartPluginRegistrant.ensureInitialized();
      final uid = (params['uid'] ?? '').toString();
      final runKey = (params['run_key'] ?? '').toString();
      final title = (params['title'] ?? '').toString();
      final body = (params['body'] ?? '').toString();

      if (!await RunGuard.begin(uid, runKey, source: 'AM')) return;
      await NotificationService.show(title: title, body: body);
      await RunGuard.clearPending(uid);
      await DLog.i('SCH', 'AM完成 uid=$uid runKey=$runKey');
    } catch (e) {
      await DLog.e('SCH', 'AM回调异常: $e');
    }
  }

  static Future<void> wmRunTask(String uid, String runKey) async {
    try {
      if (!await RunGuard.begin(uid, runKey, source: 'WM')) return;
      // 业务侧如果需要标题/内容，请在 runKey 关联查询或在 inputData 传递；此处仅演示
      await NotificationService.show(title: '提醒', body: '到点啦');
      await RunGuard.clearPending(uid);
      await DLog.i('SCH', 'WM完成 uid=$uid runKey=$runKey');
    } catch (e) {
      await DLog.e('SCH', 'WM执行异常: $e');
    }
  }

  /// “当天补发检查”。仅此处触发，避免多处重复调用。
  static Future<void> selfCheckCatchUp() async {
    await DLog.i('SCH', '执行当天补发检查（单通道）');
    // TODO: 结合你的 tasks 表实现具体补发逻辑，并用 RunGuard 防重复
  }
}
