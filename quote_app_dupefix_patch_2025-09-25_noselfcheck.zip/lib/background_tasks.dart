import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';

/// 自检功能已停用。
class BackgroundTasks {
  /// 调用此方法将不会注册任何周期任务。
  static Future<void> registerSelfCheck() async {
    await DLog.i('BG', '自检已禁用，无周期任务注册');
  }
}
