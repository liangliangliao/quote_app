import 'package:flutter/foundation.dart';
import '../data/db.dart';

/// 统一日志写入：既打印到控制台，又落库到 logs 表
class DLog {
  static Future<void> i(String tag, String msg, {String taskUid = '_SYS_'}) async {
    final now = DateTime.now().toIso8601String();
    final line = "【信息】[$now][$tag] $msg";
    if (kDebugMode) {
      // ignore: avoid_print
      print(line);
    }
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': taskUid,
        'detail': line,
      });
    } catch (_) {}
  }

  static Future<void> w(String tag, String msg, {String taskUid = '_SYS_'}) async {
    final now = DateTime.now().toIso8601String();
    final line = "【警告】[$now][$tag] $msg";
    if (kDebugMode) {
      // ignore: avoid_print
      print(line);
    }
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': taskUid,
        'detail': line,
      });
    } catch (_) {}
  }

  static Future<void> e(String tag, String msg, {String taskUid = '_SYS_'}) async {
    final now = DateTime.now().toIso8601String();
    final line = "【错误】[$now][$tag] $msg";
    // 始终打印错误
    // ignore: avoid_print
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': taskUid,
        'detail': line,
      });
    } catch (_) {}
  }
}
