package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

object SysChannel {
    private const val TAG = "SysChannel"
    private const val CH_SYS = "com.example.quote_app/sys"
    private const val CH_SCHED = "native.scheduler"

    fun register(engine: FlutterEngine, ctx: Context) {
        val messenger = engine.dartExecutor.binaryMessenger

        // System channel
        val sys = MethodChannel(messenger, CH_SYS)
        sys.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            when (call.method) {

                "startFgGuard" -> {
                    try {
                        val unlock = (call.argument<Boolean>("unlock") == true)
                        val geo = (call.argument<Boolean>("geo") == true)
                        val intent = Intent(ctx, GeoForegroundService::class.java).apply {
                            action = "com.example.quote_app.FG_START"
                            putExtra("unlock", unlock)
                            putExtra("geo", geo)
                        }
                        if (Build.VERSION.SDK_INT >= 26) {
                            ctx.startForegroundService(intent)
                        } else {
                            ctx.startService(intent)
                        }
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】收到 Dart 启动指令：unlock=" + unlock + " geo=" + geo) } catch (_: Throwable) {}
                        result.success(true)
                    } catch (e: Throwable) {
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】启动失败：" + e.javaClass.simpleName + " " + (e.message ?: "")) } catch (_: Throwable) {}
                        result.success(false)
                    }
                }
                "stopFgGuard" -> {
                    try {
                        val intent = Intent(ctx, GeoForegroundService::class.java)
                        val ok = ctx.stopService(intent)
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】收到 Dart 停止指令，stopService=" + ok) } catch (_: Throwable) {}
                        result.success(ok)
                    } catch (e: Throwable) {
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】停止失败：" + e.javaClass.simpleName + " " + (e.message ?: "")) } catch (_: Throwable) {}
                        result.success(false)
                    }
                }

                "getBaiduLocationOnce" -> {
                    BaiduLocator.getOnce(ctx) { loc ->
                        if (loc == null) {
                            result.error("NO_LOCATION", "Timeout or no provider", null)
                        } else {
                            val map = hashMapOf<String, Any>(
                                "lat" to loc.latitude,
                                "lon" to loc.longitude,
                                "acc" to loc.accuracy.toDouble(),
                                "provider" to (loc.provider ?: "unknown")
                            )
                            result.success(map)
                        }
                    }
                }
                "hasExactAlarmPermission" -> {
                    val ok = canScheduleExact(ctx)
                    result.success(ok)
                }
                "requestExactAlarmPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            ctx.startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            result.error("REQ_ERR", e.message, null)
                        }
                    } else {
                        result.success(true)
                    }
                }
                else -> result.notImplemented()
            }
        }

        // Native scheduler channel
        val sch = MethodChannel(messenger, CH_SCHED)
        sch.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            when (call.method) {

                "startFgGuard" -> {
                    try {
                        val unlock = (call.argument<Boolean>("unlock") == true)
                        val geo = (call.argument<Boolean>("geo") == true)
                        val intent = Intent(ctx, GeoForegroundService::class.java).apply {
                            action = "com.example.quote_app.FG_START"
                            putExtra("unlock", unlock)
                            putExtra("geo", geo)
                        }
                        if (Build.VERSION.SDK_INT >= 26) {
                            ctx.startForegroundService(intent)
                        } else {
                            ctx.startService(intent)
                        }
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】收到 Dart 启动指令：unlock=" + unlock + " geo=" + geo) } catch (_: Throwable) {}
                        result.success(true)
                    } catch (e: Throwable) {
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】启动失败：" + e.javaClass.simpleName + " " + (e.message ?: "")) } catch (_: Throwable) {}
                        result.success(false)
                    }
                }
                "stopFgGuard" -> {
                    try {
                        val intent = Intent(ctx, GeoForegroundService::class.java)
                        val ok = ctx.stopService(intent)
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】收到 Dart 停止指令，stopService=" + ok) } catch (_: Throwable) {}
                        result.success(ok)
                    } catch (e: Throwable) {
                        try { com.example.quote_app.data.DbRepo.log(ctx, null,
                            "【前台服务】停止失败：" + e.javaClass.simpleName + " " + (e.message ?: "")) } catch (_: Throwable) {}
                        result.success(false)
                    }
                }

                "canScheduleExact" -> {
                    result.success(canScheduleExact(ctx))
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun canScheduleExact(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.canScheduleExactAlarms()
            } catch (e: Exception) {
                Log.w(TAG, "canScheduleExactAlarms check failed: ${e.message}")
                false
            }
        } else true
    }
}
