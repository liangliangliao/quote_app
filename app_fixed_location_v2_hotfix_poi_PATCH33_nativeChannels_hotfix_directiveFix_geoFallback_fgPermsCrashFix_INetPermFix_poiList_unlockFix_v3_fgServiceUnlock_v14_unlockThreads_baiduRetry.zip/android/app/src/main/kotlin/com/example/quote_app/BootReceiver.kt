package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbInspector
import android.database.sqlite.SQLiteDatabase
import android.os.Build

/**
 * BootReceiver listens for device boot completed or app package replacement
 * events and reinitializes all scheduled tasks.  It enqueues a one‑off
 * workmanager job with job name `wm_boot` which is handled in the Dart
 * dispatcher to restore all alarms and scheduled WorkManager tasks.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        
        // ——新增：开机自检，若任一开关已开启，则拉起前台服务守护——
        try {
            val db = openDbFromInspector(context)
            var unlockOn = false
            var geoOn = false
            if (db != null) {
                try {
                    val c1 = db.rawQuery("SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1", null)
                    if (c1.moveToFirst()) unlockOn = "1" == (c1.getString(0) ?: "0"); c1.close()
                } catch (_: Throwable) {}
                try {
                    val c2 = db.rawQuery("SELECT location_rules_enabled FROM configs ORDER BY id DESC LIMIT 1", null)
                    if (c2.moveToFirst()) geoOn = "1" == (c2.getString(0) ?: "0"); c2.close()
                } catch (_: Throwable) {}
                db.close()
            }
            com.example.quote_app.data.DbRepo.log(context, null, "【前台服务】开机自启检查 unlock="+unlockOn+" geo="+geoOn)
            if (unlockOn || geoOn) {
                val it = Intent(context, GeoForegroundService::class.java).apply {
                    action = "com.example.quote_app.FG_START"
                    putExtra("unlock", unlockOn); putExtra("geo", geoOn)
                }
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(it) else context.startService(it)
            }
        } catch (_: Throwable) {}
// Build data payload
        val data = Data.Builder()
            .putString("job", "wm_boot")
            .build()
        val request = OneTimeWorkRequestBuilder<AlarmProxyWorker>()
            .setInputData(data)
            .build()
        WorkManager.getInstance(context).enqueue(request)

        // Schedule periodic geo location checks on boot to handle geo triggers
        try {
            if (isGeoRulesEnabled(context)) GeoWorker.schedule(context) else GeoWorker.cancel(context)
        } catch (_: Throwable) { /* ignore scheduling errors */ }

        // 改为后台：触发 UnlockWorker 做一次自检/刷新
        try { UnlockWorker.trigger(context) } catch (_: Throwable) { /* ignore */ }
}
}


private fun openDbFromInspector(ctx: Context): SQLiteDatabase? {
  return try {
    val cc = DbInspector.loadOrLightScan(ctx) ?: return null
    SQLiteDatabase.openDatabase(
      cc.dbPath,
      null,
      SQLiteDatabase.OPEN_READONLY
    )
  } catch (_: Throwable) {
    null
  }
}
private fun isGeoRulesEnabled(ctx: Context): Boolean {
  return try {
    val cc = DbInspector.loadOrLightScan(ctx) ?: return false
    val db = SQLiteDatabase.openDatabase(
      cc.dbPath,
      null,
      SQLiteDatabase.OPEN_READONLY
    )
    try {
      var enabled = false
      try {
        db.rawQuery(
          "SELECT location_rules_enabled FROM configs ORDER BY id DESC LIMIT 1",
          null
        ).use { c ->
          if (c.moveToFirst()) {
            enabled = (c.getInt(0) == 1)
          }
        }
      } catch (_: Throwable) {
      }
      enabled
    } finally {
      try {
        db.close()
      } catch (_: Throwable) {
      }
    }
  } catch (_: Throwable) {
    false
  }
}