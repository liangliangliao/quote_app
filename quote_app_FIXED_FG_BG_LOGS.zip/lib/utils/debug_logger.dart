import './run_context.dart';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/foundation.dart';
import '../data/db.dart';

class DLog {
  static String _fmtTs() {
    final n = DateTime.now();
    String two(int x)=> x<10?'0$x':'$x'; String thr(int x)=> x<10?'00$x':(x<100?'0$x':'$x');
    return '${n.year}-${two(n.month)}-${two(n.day)} ${two(n.hour)}:${two(n.minute)}:${two(n.second)}.${thr(n.millisecond)}';
  }
  static Future<void> i(String tag, String msg) async {
    final line = '[' + RunContext.where() + ' ' + _fmtTs() + '][INF][' + tag + '] ' + msg;
    if (kDebugMode) { print(line); }
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      });
    } catch (_) {}
  }

  static Future<void> e(String tag, String msg) async {
    final line = '[' + RunContext.where() + ' ' + _fmtTs() + '][ERR][' + tag + '] ' + msg;
    if (kDebugMode) { print(line); }
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      });
    } catch (_) {}
  }

  static Future<void> d(String tag, String msg) async {
    final line = '[' + RunContext.where() + ' ' + _fmtTs() + '][DBG][' + tag + '] ' + msg;
    print(line);
    try {
      final db = await AppDatabase.instance();
      await db.insert('logs', {
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'task_uid': '_SYS_',
        'detail': line,
      });
    } catch (e) {
      print('[ERR][DLog] db-insert failed: ' + e.toString());
    }
  }
}