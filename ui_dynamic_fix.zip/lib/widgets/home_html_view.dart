
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
    if (d == null || d.isEmpty) return;
    final payload = jsonEncode({
      'topic': (data['topic'] ?? data['topic_text'] ?? data['theme'] ?? ''),
      'quote': (data['content'] ?? data['quote'] ?? data['quote_text'] ?? ''),
      'author': (() { final a=(data['author'] ?? data['signature'] ?? data['署名']); final s=(data['source'] ?? data['出处']); if (a!=null && a.toString().isNotEmpty) {return '---' + a.toString() + (s!=null && s.toString().isNotEmpty ? '《' + s.toString() + '》' : ''); } return (data['authorText'] ?? data['author_text'] ?? ''); })(),
      'note': (data['explain'] ?? data['note'] ?? data['comment'] ?? data['memo'] ?? ''),
      'avatarUrl': (data['avatarUrl'] ?? data['avatar_url'] ?? data['avatar'] ?? data['avatarImg'] ?? data['portrait_url'] ?? ''),
      if (d.containsKey('focalX')) 'focalX': d['focalX'],
      if (d.containsKey('focalY')) 'focalY': d['focalY'],
    });
    try { await _controller.runJavaScript('window.setDynamicData($payload);'); } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
