
import 'package:flutter/material.dart';
import 'dart:isolate';
import 'package:flutter/services.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/settings_page.dart';
import 'pages/logs_page.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'data/db.dart';

void main() {
  IsolateTokens.token = RootIsolateToken.instance;
  WidgetsFlutterBinding.ensureInitialized();
  // Start app immediately to avoid long splash hang; init async after first frame.
  runApp(const MyApp());
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    await AppDatabase.instance();
    await NotificationService.init();
    await SchedulerService.init();
    await SchedulerService.scheduleNextForAll();
  });
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];
  // Titles removed per UI requirement
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        body: _pages[_idx],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _idx,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home), label: '首页'),
            NavigationDestination(icon: Icon(Icons.history), label: '历史'),
            NavigationDestination(icon: Icon(Icons.list), label: '日志'),
            NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
          ],
          onDestinationSelected: (i)=> setState(()=> _idx = i),
        ),
      ),
    );
  }
}

class IsolateTokens { static RootIsolateToken? token; }
