package com.example.quote_app

import android.app.AlarmManager
import android.content.Context
import android.os.Build

object ExactAlarmHelper {
    fun hasExactAlarmPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
            val am = context.applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.canScheduleExactAlarms()
        } catch (e: Exception) {
            true // 乐观：偶发异常时按 true 处理，避免抖动
        }
        } else {
            true
        }
    }
}
