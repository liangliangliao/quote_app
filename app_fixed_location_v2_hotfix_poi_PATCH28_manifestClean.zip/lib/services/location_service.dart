
static const MethodChannel _baiduCh = MethodChannel('com.example.quote_app/baidu_loc');

static Future<Position?> _baiduNativeOnce() async {
  try {
    final map = await _baiduCh.invokeMethod<Map<dynamic, dynamic>>('locOnce');
    if (map != null) {
      return _makePosition(
        lat: (map['lat'] as num).toDouble(),
        lon: (map['lon'] as num).toDouble(),
        accuracy: (map['acc'] as num).toDouble(),
      );
    }
  } catch (_) {}
  return null;
}
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// POI 数据模型：地点名称 + 地址 + 坐标 + 距离（米）
///
/// 注意：
/// - [distance] 使用 double?，方便直接承接 Baidu / 系统返回的浮点距离；
/// - 调用方目前只在 UI 文本中使用该字段，不依赖其精确类型。
class PoiItem {
  final String name;
  final String? address;
  final double latitude;
  final double longitude;
  final double? distance;

  const PoiItem({
    required this.name,
    this.address,
    required this.latitude,
    required this.longitude,
    this.distance,
  });
}

/// 统一封装定位与附近 POI 查询的服务。
class LocationService {
  /// 对应 android 侧 [SysChannel.CHANNEL] 的 MethodChannel。
  static const MethodChannel _sysCh =
      MethodChannel('com.example.quote_app/sys');

  /// Baidu 插件是否可用；一旦出现 MissingPluginException，则置为 false，后续不再调用。
  static bool _baiduPluginAvailable = true;

  /// 希望的最大精度（半径）阈值，单位：米。
  static const double _desiredAccuracyMeters = 30.0;

  /// 最近一次成功定位所采用的 provider 名称：
  /// - 'baidu' / 'system' / 'last_known'
  /// - null 表示尚未成功定位。
  static String? lastProvider;

  // ---------------------------------------------------------------------------
  // 对外暴露的定位入口
  // ---------------------------------------------------------------------------

  /// 「偏好 Baidu」策略：
  /// 1) 先尝试 Baidu SDK（高精度流 + 30m 阈值）；
  /// 2) 若失败或精度不达标，则回退到系统 Geolocator 高精度；
  /// 3) 再失败则使用 lastKnown 兜底。
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // 1. Baidu SDK 优先
    try {
      final bd = await _baiduNativeOnce() ?? await _baiduSdkLocationOnce();
      if (bd != null) {
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i(
              'LocationService',
              '【定位】Baidu SDK 成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
            );
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w(
              'LocationService',
              '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)，尝试系统定位',
            );
          } catch (_) {}
        }
      }
    } catch (_) {
      // 已在 _baiduSdkLocationOnce 内部记录日志，这里忽略异常。
    }

    // 2. 系统高精度定位
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i(
              'LocationService',
              '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
            );
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w(
              'LocationService',
              '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)',
            );
          } catch (_) {}
        }
      }
    } catch (_) {
      // 已在 _getCurrentPositionHighAccuracy 内部记录日志。
    }

    // 3. lastKnown 兜底
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】Baidu / System / lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

  /// 「偏好系统」策略：
  /// 1) 先尝试系统 Geolocator 高精度；
  /// 2) 若失败或精度不达标，再尝试 Baidu SDK；
  /// 3) 再失败则使用 lastKnown 兜底。
  static Future<Position?> getCurrentPositionPreferSystem() async {
    // 1. 系统优先
    try {
      final sys = await _getCurrentPositionHighAccuracy();
      if (sys != null) {
        if (sys.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'system';
          try {
            await DLog.i(
              'LocationService',
              '【定位】系统定位成功 acc=${sys.accuracy}m, lat=${sys.latitude}, lon=${sys.longitude}',
            );
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(sys));
          return sys;
        } else {
          try {
            await DLog.w(
              'LocationService',
              '【定位】系统定位精度不满足要求 acc=${sys.accuracy}m (>$_desiredAccuracyMeters m)，尝试 Baidu SDK',
            );
          } catch (_) {}
        }
      }
    } catch (_) {}

    // 2. Baidu 兜底
    try {
      final bd = await _baiduNativeOnce() ?? await _baiduSdkLocationOnce();
      if (bd != null) {
        if (bd.accuracy <= _desiredAccuracyMeters) {
          lastProvider = 'baidu';
          try {
            await DLog.i(
              'LocationService',
              '【定位】Baidu SDK 成功 acc=${bd.accuracy}m, lat=${bd.latitude}, lon=${bd.longitude}',
            );
          } catch (_) {}
          unawaited(_logNearbyLandmarkIfPossible(bd));
          return bd;
        } else {
          try {
            await DLog.w(
              'LocationService',
              '【定位】Baidu SDK 精度不满足要求 acc=${bd.accuracy}m (>$_desiredAccuracyMeters m)',
            );
          } catch (_) {}
        }
      }
    } catch (_) {}

    // 3. lastKnown 兜底
    try {
      final last = await _getLastKnownPosition();
      if (last != null) {
        lastProvider = 'last_known';
        return last;
      }
    } catch (_) {}

    lastProvider = null;
    try {
      await DLog.w(
        'LocationService',
        '【定位】系统 / Baidu / lastKnown 全部失败，无法获取位置',
      );
    } catch (_) {}
    return null;
  }

  // ---------------------------------------------------------------------------
  // 内部：系统定位实现
  // ---------------------------------------------------------------------------

  static Future<Position?> _getCurrentPositionHighAccuracy() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位服务未开启',
        );
      } catch (_) {}
      return null;
    }

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】未授予定位权限',
        );
      } catch (_) {}
      return null;
    }

    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 30),
      );
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】高精度定位超时，尝试中等精度：$e',
        );
      } catch (_) {}
      try {
        return await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium,
          timeLimit: const Duration(seconds: 30),
        );
      } on TimeoutException catch (e2) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】中等精度定位仍然超时：$e2',
          );
        } catch (_) {}
        return null;
      } catch (e2) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】中等精度定位异常：$e2',
          );
        } catch (_) {}
        return null;
      }
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】系统定位异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

  static Future<Position?> _getLastKnownPosition() async {
    try {
      final pos = await Geolocator.getLastKnownPosition();
      if (pos == null) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】lastKnown 位置为空',
          );
        } catch (_) {}
        return null;
      }
      try {
        await DLog.i(
          'LocationService',
          '【定位】lastKnown 成功 acc=${pos.accuracy}m, lat=${pos.latitude}, lon=${pos.longitude}',
        );
      } catch (_) {}
      return pos;
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】lastKnown 调用异常：$e',
        );
      } catch (_) {}
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // 内部：Baidu SDK 定位（通过原生 SysChannel）
  // ---------------------------------------------------------------------------

  static Future<Position?> _baiduSdkLocationOnce() async {
  // 新方向：不再依赖原生 Baidu SDK 插件，改为在 Flutter 侧复用系统定位，
  // 再结合后续的百度 / 系统逆地理服务来获取周边 POI。
  //
  // 这样可以彻底避免 MissingPluginException(No implementation found for method
  // getBaiduLocationOnce ...) 这类插件注册问题，同时对用户来说依然是
  // “默认先尝试更快的定位通路”，只是在实现层面换成了兼容模式。
  try {
    // 1) 优先尝试 lastKnown：室内或信号较差时，这往往比重新请求更稳。
    Position? last;
    try {
      last = await Geolocator.getLastKnownPosition();
    } catch (_) {
      last = null;
    }
    if (last != null) {
      try {
        await DLog.i(
          'LocationService',
          '【定位】Baidu 兼容模式使用 lastKnown acc=${last.accuracy}m, lat=${last.latitude}, lon=${last.longitude}',
        );
      } catch (_) {}
      return last;
    }

    // 2) 若没有 lastKnown，则走一次中等精度的系统定位作为“Baidu 通路”。
    final current = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.medium,
      timeLimit: const Duration(seconds: 30),
    );
    try {
      await DLog.i(
        'LocationService',
        '【定位】Baidu 兼容模式使用系统定位 acc=${current.accuracy}m, lat=${current.latitude}, lon=${current.longitude}',
      );
    } catch (_) {}
    return current;
  } on TimeoutException catch (e) {
    try {
      await DLog.w(
        'LocationService',
        '【定位】Baidu 兼容模式超时：$e',
      );
    } catch (_) {}
    return null;
  } catch (e) {
    try {
      await DLog.w(
        'LocationService',
        '【定位】Baidu 兼容模式异常：$e',
      );
    } catch (_) {}
    return null;
  }
}

  /// 使用系统逆地理服务（geocoding）记录一次「附近地标」到日志中。
  static Future<void> _logNearbyLandmarkIfPossible(Position pos) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        pos.latitude,
        pos.longitude,
      );
      if (placemarks.isEmpty) return;
      final p = placemarks.first;
      final parts = <String>[
        p.country ?? '',
        p.administrativeArea ?? '',
        p.subAdministrativeArea ?? '',
        p.locality ?? '',
        p.subLocality ?? '',
        p.thoroughfare ?? '',
        p.subThoroughfare ?? '',
        p.name ?? '',
      ];
      final addr = parts.where((e) => e.isNotEmpty).join('');
      if (addr.isEmpty) return;
      await DLog.i(
        'LocationService',
        '【定位】附近地标：$addr (lat=${pos.latitude}, lon=${pos.longitude}, acc=${pos.accuracy}m)',
      );
    } catch (_) {
      // 逆地理失败不影响主流程。
    }
  }

  // ---------------------------------------------------------------------------
  // 内部：Baidu Web 逆地理 + POI 查询（50 米内的标记物，分页）
  // ---------------------------------------------------------------------------

  static Future<List<PoiItem>> _fetchNearbyPoisFromBaiduApi({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 1,
    int pageSize = 10,
  }) async {
    // 半径范围保护：默认 50m，最大 3000m。
    final radius = radiusMeters <= 0
        ? 50
        : (radiusMeters > 3000 ? 3000 : radiusMeters);

    String ak;
    try {
      ak = (await ConfigDao().getBaiduAk()).trim();
    } catch (_) {
      ak = '';
    }
    if (ak.isEmpty) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】未配置 Baidu AK，无法查询附近 POI',
        );
      } catch (_) {}
      return const [];
    }

    final params = <String, String>{
      'ak': ak,
      'output': 'json',
      'coordtype': 'wgs84ll',
      'location': '$latitude,$longitude',
      'extensions_poi': '1',
      'radius': radius.toString(),
      'ret_coordtype': 'wgs84ll',
      // 一次最多拉较多 poi，后续在内存中做分页。
      'page_size': '50',
      'page_num': '0',
    };

    final uri =
        Uri.parse('https://api.map.baidu.com/reverse_geocoding/v3/?' +
            params.entries
                .map((e) =>
                    '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}')
                .join('&'));

    try {
      final resp = await http.get(uri).timeout(const Duration(seconds: 10));
      if (resp.statusCode != 200) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu 逆地理 HTTP ${resp.statusCode}',
          );
        } catch (_) {}
        return const [];
      }

      final data = json.decode(resp.body) as Map<String, dynamic>;
      if (data['status'] != 0) {
        try {
          await DLog.w(
            'LocationService',
            '【定位】Baidu 逆地理返回错误：status=${data['status']}, msg=${data['msg']}',
          );
        } catch (_) {}
        return const [];
      }

      final result = data['result'] as Map<String, dynamic>?;
      final rawPois = (result?['pois'] as List?) ?? const [];

      final List<PoiItem> all = [];
      for (final raw in rawPois) {
        if (raw is! Map) continue;
        final map = raw.map((k, v) => MapEntry(k.toString(), v));

        final rawName = (map['name'] ?? '').toString();
        final rawAddr =
            (map['addr'] ?? map['address'] ?? '').toString();

        double? lat = (map['point'] is Map)
            ? (map['point']['y'] as num?)?.toDouble()
            : null;
        double? lng = (map['point'] is Map)
            ? (map['point']['x'] as num?)?.toDouble()
            : null;

        if (lat == null || lng == null) {
          if (map['location'] is Map) {
            lat = (map['location']['lat'] as num?)?.toDouble();
            lng = (map['location']['lng'] as num?)?.toDouble();
          }
        }

        lat ??= latitude;
        lng ??= longitude;

        final distNum = map['distance'];
        final dist =
            distNum is num ? distNum.toDouble() : null;

        // 关键字过滤（如有）。
        if (keyword.isNotEmpty) {
          final text =
              (rawName + rawAddr).toLowerCase();
          if (!text.contains(keyword.toLowerCase())) {
            continue;
          }
        }

        all.add(
          PoiItem(
            name: rawName.isEmpty ? '未知地点' : rawName,
            address: rawAddr.isEmpty ? null : rawAddr,
            latitude: lat,
            longitude: lng,
            distance: dist,
          ),
        );
      }

      if (all.isEmpty) return const [];

      // 在内存中分页：page 从 1 开始。
      if (page <= 0) page = 1;
      if (pageSize <= 0) pageSize = 10;
      final start = (page - 1) * pageSize;
      if (start >= all.length) return const [];
      final end = start + pageSize;
      return all.sublist(start, end > all.length ? all.length : end);
    } on TimeoutException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu 逆地理请求超时：$e',
        );
      } catch (_) {}
      return const [];
    } on SocketException catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu 逆地理网络异常：$e',
        );
      } catch (_) {}
      return const [];
    } catch (e) {
      try {
        await DLog.w(
          'LocationService',
          '【定位】Baidu 逆地理解析异常：$e',
        );
      } catch (_) {}
      return const [];
    }
  }

  // ---------------------------------------------------------------------------
  // 对外暴露：附近 POI 查询（Baidu / system 分支共用同一个实现）
  // ---------------------------------------------------------------------------

  /// 使用「当前位置」作为中心点，通过 Baidu Web 服务查询附近 POI。
  ///
  /// 该方法更偏向「Baidu provider」场景，但逻辑上与 [fetchNearbyPoisSystem] 完全一致：
  /// - 半径固定使用调用方传入的 [radiusMeters]（通常为 50m）；
  /// - 先拉取较多 POI，再在内存中做分页；
  /// - 返回的 [PoiItem] 可直接用于前端列表展示。
  static Future<List<PoiItem>> fetchNearbyPois({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 1,
    int pageSize = 10,
  }) {
    return _fetchNearbyPoisFromBaiduApi(
      latitude: latitude,
      longitude: longitude,
      radiusMeters: radiusMeters,
      keyword: keyword,
      page: page,
      pageSize: pageSize,
    );
  }

  /// 使用「系统定位」获得的坐标，再通过 Baidu Web 服务查询附近 POI。
  ///
  /// 为了让“系统逆地理”和“Baidu 逆地理”在表现上保持一致，这里复用完全相同的
  /// Baidu 逆地理 + POI 查询逻辑，只是 provider 来源不同。
  static Future<List<PoiItem>> fetchNearbyPoisSystem({
    required double latitude,
    required double longitude,
    required int radiusMeters,
    String keyword = '',
    int page = 1,
    int pageSize = 10,
  }) {
    return _fetchNearbyPoisFromBaiduApi(
      latitude: latitude,
      longitude: longitude,
      radiusMeters: radiusMeters,
      keyword: keyword,
      page: page,
      pageSize: pageSize,
    );
  }
}
  Future<Position?> _getCurrentPositionLowPower() async {
    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 30),
      );
    } catch (e, st) {
      try {
        await DLog.w('LocationService', '【定位】低精度定位异常：$e; stack=$st');
      } catch (_) {}
      return null;
    }
  }
