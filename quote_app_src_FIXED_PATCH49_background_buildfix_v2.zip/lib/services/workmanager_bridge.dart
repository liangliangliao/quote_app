import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import 'package:flutter/services.dart' show BackgroundIsolateBinaryMessenger;
import 'package:quote_app/app_globals.dart';
import 'notification_service.dart';
import 'openai_service.dart';

const String kQuotesTask = 'quotes_job';

@pragma('vm:entry-point')
void wmCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    try {
      if (AppGlobals.rootIsolateToken != null) {
        BackgroundIsolateBinaryMessenger.ensureInitialized(AppGlobals.rootIsolateToken!);
      }
    } catch (_) {}
    try { await NotificationService.init(); } catch (_) {}
    String body = inputData?['fallback'] ?? '到点啦～';
    try {
      final fetched = await OpenAIService.fetchOneLiner();
      if (fetched.trim().isNotEmpty) body = fetched;
    } catch (_) {}
    final nid = (inputData != null && inputData['nid'] is int) ? (inputData['nid'] as int) : 2001;
    await NotificationService.show(id: nid, title: '名人名言', body: body);
    return true;
  });
}

class WorkManagerBridge {
  static Future<void> init() async {
    try {
      await Workmanager().initialize(wmCallbackDispatcher, isInDebugMode: false);
    } catch (_) {}
  }

  static Future<void> scheduleOneOff(DateTime when, {int? nid, String? fallback}) async {
    final delay = when.difference(DateTime.now());
    await Workmanager().registerOneOffTask(
      'quote_${when.millisecondsSinceEpoch}',
      kQuotesTask,
      initialDelay: delay.isNegative ? Duration.zero : delay,
      inputData: {
        'nid': nid ?? 2001,
        'fallback': fallback ?? '到点啦～',
      },
      constraints: Constraints(
        networkType: NetworkType.notRequired,
      ),
    );
  }
}