package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.core.content.ContextCompat
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.OutOfQuotaPolicy
import com.example.quote_app.bg.GatekeeperService
import com.example.quote_app.data.DbRepo

/**
 * 亮屏/解锁触发通知与定位比对的入口。
 * - 不依赖开关：无条件触发一次 GeoWorker(force_unlock_geo=true) 做位置比对。
 * - 数据库规则：存在 screen_unlock 触发或 unlock_switch_enabled=1 时，发送解锁提醒。
 */
class UnlockReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val act = intent?.action

        // 1) 记录“正在解锁屏幕将触发通知发送”，并尽力拉起前台守护服务
        try { DbRepo.log(context, null, "正在解锁屏幕将触发通知发送") } catch (_: Throwable) {}
        try { ContextCompat.startForegroundService(context, Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}

        // 2) 不受开关影响：强制触发一次定位比对
        try {
            val req = OneTimeWorkRequestBuilder<com.example.quote_app.GeoWorker>()
                .setInputData(Data.Builder().putBoolean("force_unlock_geo", true).build())
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORKER)
                .build()
            WorkManager.getInstance(context).enqueue(req)
        } catch (_: Throwable) {}

        // 3) 数据库规则判定：有解锁触发或开关开启才发送“解锁提醒”
        try {
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
            val dbPath = contract?.dbPath
            var shouldNotify = false

            if (dbPath != null) {
                val db: SQLiteDatabase = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
                try {
                    // hasTrigger
                    val c1 = db.rawQuery("SELECT 1 FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1", null)
                    val hasTrigger = c1.moveToFirst()
                    c1.close()

                    // config switch
                    var configEnabled = false
                    val c2 = db.rawQuery("SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1", null)
                    if (c2.moveToFirst()) {
                        val v = c2.getString(0)?.trim()?.lowercase()
                        configEnabled = (v == "1" || v == "true")
                    }
                    c2.close()

                    shouldNotify = hasTrigger || configEnabled
                    try { DbRepo.log(context, null, "[UnlockReceiver] hasTrigger=" + hasTrigger + ", configEnabled=" + configEnabled) } catch (_: Throwable) {}
                } finally {
                    db.close()
                }
            } else {
                // 没有 dbPath，兜底：不崩溃，仅按开关未知处理，不主动发解锁提醒
                try { DbRepo.log(context, null, "[UnlockReceiver] dbPath is null, skip unlock-notify rule") } catch (_: Throwable) {}
            }

            if (shouldNotify) {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                try { DbRepo.log(context, null, "[UnlockReceiver] wrote last_unlock_time=" + System.currentTimeMillis()) } catch (_: Throwable) {}
                sendReminder(context)
            }
        } catch (_: Throwable) {
            // 任意异常不崩溃：只记录并安全返回
            try { DbRepo.log(context, null, "[UnlockReceiver] exception suppressed in rule check") } catch (_: Throwable) {}
        }
    }

    private fun sendReminder(context: Context) {
        val id = 2000  // 与地点提醒使用不同 ID，避免覆盖
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        try { DbRepo.log(context, null, "[UnlockReceiver] sending reminder notification") } catch (_: Throwable) {}
        com.example.quote_app.NotifyHelper.send(context, id, title, body, null, "vision_focus", null)
        try { DbRepo.log(context, null, "通知发送成功") } catch (_: Throwable) {}
    }
}