
import 'dart:isolate';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import '../platform/perm_helper.dart';
import '../main.dart';

class SchedulerService {
  // Stable ID namespace for per-task alarms to avoid collisions and to survive process restarts.
  static const int _kAlarmIdBase = 1200000; // keep far from plugin internal ids and our safety ticker (999001)
  static const int _kAlarmIdMax  = 2200000;
  static const String _kAlarmSeqKey = 'alarm_id_seq';

  static Future<int> _getOrCreateAlarmId(String taskUid) async {
    final db = await AppDatabase.instance();
    final key = 'alarm_id_' + taskUid;
    final rows = await db.query('meta', where: 'key=?', whereArgs: [key], limit: 1);
    if (rows.isNotEmpty) {
      final v = int.tryParse(rows.first['value']?.toString() ?? '');
      if (v != null) return v;
    }
    // allocate next sequence
    int seq = _kAlarmIdBase;
    final seqRows = await db.query('meta', where: 'key=?', whereArgs: [_kAlarmSeqKey], limit: 1);
    if (seqRows.isNotEmpty) {
      final v = int.tryParse(seqRows.first['value']?.toString() ?? '');
      if (v != null) seq = v;
    }
    seq += 1;
    if (seq > _kAlarmIdMax) seq = _kAlarmIdBase + 1; // wrap around in our namespace
    // upsert id for this task
    await db.insert('meta', {'key': key, 'value': seq.toString()}, conflictAlgorithm: ConflictAlgorithm.replace);
    // upsert seq
    if (seqRows.isEmpty) {
      await db.insert('meta', {'key': _kAlarmSeqKey, 'value': seq.toString()});
    } else {
      await db.update('meta', {'value': seq.toString()}, where: 'key=?', whereArgs: [_kAlarmSeqKey]);
    }
    return seq;
  }

  // Periodic safety ticker: scans and recovers missed tasks.
  static const int _kSafetyTickerId = 999001;

  static Future<void> init() async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
    } catch (_) {}
    try {
      await AndroidAlarmManager.initialize();
    } catch (_) {}
    try {
      await ensureTickerRunning();
    } catch (_) {}
  }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final canExact = await PermHelper.hasExactAlarmPermission();
    final tasks = await db.query('tasks', where: 'status=?', whereArgs: ['on']);
    final now = DateTime.now();

    for (final t in tasks) {
      try {
        final next = _computeNext(t, from: now);
        // Persist next into tasks.start_time —— 1.1需求
        await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [t['task_uid']]);
        final id = await _getOrCreateAlarmId(t['task_uid'] as String);
        await AndroidAlarmManager.oneShotAt(
          next,
          id,
          _alarmEntryPoint,
          exact: canExact,
          wakeup: true,
          allowWhileIdle: true,
          rescheduleOnReboot: true,
        );
      } catch (_) {
        // ignore individual task failure, but continue
      }
    }
  }

  @pragma('vm:entry-point')
  static Future<void> callback() async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      if (IsolateTokens.token != null) {
        BackgroundIsolateBinaryMessenger.ensureInitialized(IsolateTokens.token!);
      }
    } catch (_) {}
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final nowStr = _fmt(now);

    final rows = await db.query('tasks', where: 'status=?', whereArgs: ['on']);
    for (final t in rows) {
      try {
        final taskUid = (t['task_uid'] ?? '') as String;
        final name = (t['name'] ?? '') as String;
        final avatar = (t['avatar_path'] ?? '') as String?;
        final start = (t['start_time'] ?? '') as String;
        if (!_isDue(start, now)) {
          continue;
        }

        Map<String, dynamic>? q;
        final type = (t['type'] ?? 'manual') as String;

        if (type == 'manual') {
          q = await QuoteDao().latestForTask(taskUid);
          if (q == null) {
            await LogDao().add(taskUid: taskUid, detail: '错误! 手动任务没有可用名言');
          }
        } else if (type == 'carousel') {
          q = await QuoteDao().carouselNextSequential(taskUid);
          if (q == null) {
            // fallback: create placeholders if empty
            await LogDao().add(taskUid: taskUid, detail: '错误! 轮播无可用名言（空表）');
          }
        } else if (type == 'auto') {
          final cfg = await ConfigDao().getOne();
          try {
            final openai = OpenAIService(
              endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
              apiKey: (cfg['api_key'] ?? '') as String,
              model: (cfg['model'] ?? 'gpt-5') as String,
            );
            final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;
            String? uid;
            for (int i=0; i<10; i++) {
              final quote = (await openai.generateQuote(prompt)).trim();
              if (quote.isEmpty) break;
              final exists = await QuoteDao().existsSimilar(quote, threshold: 0.9);
              if (exists) {
                if (i==9) {
                  await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
                }
                continue;
              }
              uid = await QuoteDao().insertIfUnique(
                taskUid: taskUid,
                type: 'auto',
                taskName: name,
                avatarPath: avatar ?? '',
                content: quote,
              );
              break;
            }
            if (uid != null) {
              q = await QuoteDao().latestForTask(taskUid);
            }
          } catch (e) {
            await LogDao().add(taskUid: taskUid, detail: '错误! 自动生成失败: $e');
          }
        }

        // carousel fallback if still empty
        if (q == null && type == 'carousel') {
          // 兜底: 如果当前没有任何 quote，尝试插入一条默认的
          const def = '“人生如逆旅，我亦是行人。” —— 苏轼';
          await QuoteDao().insertIfUnique(
            taskUid: taskUid,
            type: 'carousel',
            taskName: name,
            avatarPath: avatar ?? '',
            content: def,
          );
          q = await QuoteDao().carouselNextSequential(taskUid);
          if (q == null) {
            // 仍为空，写日志并返回
            await LogDao().add(taskUid: taskUid, detail: '错误! 轮播无可用名言（兜底失败）');
          }
        }

        if (q != null) {
          final content = (q['content'] ?? '') as String;
          await NotificationService.show(
            id: (await _getOrCreateAlarmId(taskUid)),
            title: name.isEmpty ? '名言' : name,
            body: content,
            largeIconPath: avatar,
          );
          await LogDao().add(taskUid: taskUid, detail: '已发送通知');
        }

        // compute and persist next run + schedule next alarm
        final next = _computeNext(t, from: now.add(const Duration(seconds: 1)));
        await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
        final id = await _getOrCreateAlarmId(taskUid);
        final canExact2 = await PermHelper.hasExactAlarmPermission();
        await AndroidAlarmManager.oneShotAt(
          next,
          id,
          _alarmEntryPoint,
          exact: canExact2,
          wakeup: true,
          allowWhileIdle: true,
          rescheduleOnReboot: true,
        );
      } catch (_) {}
    }
  }

  static String _fmt(DateTime dt) {
    String two(int n)=> n.toString().padLeft(2,'0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}';
  }

  static bool _isDue(String start, DateTime now) {
    // start format: YYYY-MM-DD HH:mm
    try {
      final dt = DateFormat('yyyy-MM-dd HH:mm').parse(start);
      return !dt.isAfter(now);
    } catch (_) {
      return true; // if parsing fails, treat as due
    }
  }

  static DateTime _computeNext(Map<String, Object?> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    // derive base hh:mm from start_time
    int hh = now.hour;
    int mm = now.minute;
    try {
      final start = (t['start_time'] ?? '') as String;
      if (start.isNotEmpty) {
        final dt = DateFormat('yyyy-MM-dd HH:mm').parse(start);
        hh = dt.hour; mm = dt.minute;
      }
    } catch (_) {}
    final String freqType = (t['freq_type'] ?? 'daily') as String;
    if (freqType == 'weekly') {
      final int wd = (t['freq_weekday'] as int?) ?? 1; // 1=Mon..7=Sun
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freqType == 'monthly') {
      final int d = (t['freq_day_of_month'] as int?) ?? 1;
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1;
        if (m > 12) { m = 1; y += 1; }
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      // daily
      var cand = DateTime(now.year, now.month, now.day, hh, mm);
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 1));
      return cand;
    }
  }

  static Future<void> startSafetyTicker() async {
    final canExact = await PermHelper.hasExactAlarmPermission();
    // schedule next tick 15 minutes later
    final when = DateTime.now().add(const Duration(minutes: 15));
    await AndroidAlarmManager.oneShotAt(
      when,
      _kSafetyTickerId,
      _tickerEntryPoint,
      exact: canExact,
      wakeup: true,
      allowWhileIdle: true,
      rescheduleOnReboot: true,
    );
  }

  static Future<void> ensureTickerRunning() async {
    await startSafetyTicker();
  }

  static Future<void> _processDueTasks() async {
    try {
      await SchedulerService.callback();
    } catch (_) {}
  }

  @pragma('vm:entry-point')
  static Future<void> _alarmEntryPoint(int id) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      if (IsolateTokens.token != null) {
        BackgroundIsolateBinaryMessenger.ensureInitialized(IsolateTokens.token!);
      }
    } catch (_) {}
    await _processDueTasks();
    try { await startSafetyTicker(); } catch (_) {}
  }

  @pragma('vm:entry-point')
  static Future<void> _tickerEntryPoint(int id) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      if (IsolateTokens.token != null) {
        BackgroundIsolateBinaryMessenger.ensureInitialized(IsolateTokens.token!);
      }
    } catch (_) {}
    await _processDueTasks();
    try { await startSafetyTicker(); } catch (_) {}
  }
}
