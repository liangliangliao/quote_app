import '../platform/perm_helper.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';


class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  // ===== 通知类别（与图示对应：ALARM / REMINDER / INFO） =====
  static const String chAlarmId = 'quote_alarm';
  static const String chAlarmName = '闹钟/重要提醒';
  static const String chAlarmDesc = '高优先级，闹钟/关键任务类通知';

  static const String chReminderId = 'quote_reminder';
  static const String chReminderName = '日常提醒';
  static const String chReminderDesc = '中高优先级，常规任务提醒';

  static const String chInfoId = 'quote_info';
  static const String chInfoName = '资讯/静默';
  static const String chInfoDesc = '低优先级，资讯播报、静默类';

  static const AndroidNotificationChannel _channelAlarm = AndroidNotificationChannel(
    chAlarmId, chAlarmName,
    description: chAlarmDesc,
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );

  static const AndroidNotificationChannel _channelReminder = AndroidNotificationChannel(
    chReminderId, chReminderName,
    description: chReminderDesc,
    importance: Importance.high,
    playSound: true,
    enableVibration: true,
    showBadge: true,
  );

  static const AndroidNotificationChannel _channelInfo = AndroidNotificationChannel(
    chInfoId, chInfoName,
    description: chInfoDesc,
    importance: Importance.defaultImportance,
    playSound: false,
    enableVibration: false,
    showBadge: false,
  );

  // iOS/macOS 通知类别（用于动作按钮/前台展示策略）
  static const String catAlarm = 'ALARM';
  static const String catReminder = 'REMINDER';
  static const String catInfo = 'INFO';

  static Future<void> init() async {
    if (_inited) return;

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    final darwinInit = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
      notificationCategories: <DarwinNotificationCategory>[
        DarwinNotificationCategory(
          catAlarm,
          actions: <DarwinNotificationAction>[
            DarwinNotificationAction.text('DONE', '完成'),
            DarwinNotificationAction.plain('SNOOZE', '稍后提醒'),
          ],
        ),
        DarwinNotificationCategory(
          catReminder,
          actions: <DarwinNotificationAction>[
            DarwinNotificationAction.text('DONE', '完成'),
          ],
        ),
        DarwinNotificationCategory(catInfo),
      ],
    );
    final settings = InitializationSettings(android: androidInit, iOS: darwinInit);
    await _plugin.initialize(settings);

    // --- 运行时权限 & 通道创建 ---
    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      try { await android?.requestPermission(); } catch (_) {}
      try {
        await android?.createNotificationChannel(_channelAlarm);
        await android?.createNotificationChannel(_channelReminder);
        await android?.createNotificationChannel(_channelInfo);
      } catch (_) {}
      // 确保悬浮窗权限（若产品需要悬浮提示）
      try { await PermHelper.ensureOverlayPermission(); } catch (_) {}
    } else if (Platform.isIOS || Platform.isMacOS) {
      final darwin = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      try { await darwin?.requestPermissions(alert: true, badge: true, sound: true); } catch (_) {}
    }

    _inited = true;
  }

  // 类别枚举
  static const int alarm = 1;
  static const int reminder = 2;
  static const int info = 3;

  // 统一展示入口：可前台/后台调用
  static Future<void> show({
    required int id,
    Object? largeIcon,
    required String title,
    required String body,
    int category = info,
    String? payload,
    BigPictureStyleInformation? style,
  }) async {
    await init();

    // Android 选择通道
    String channelId = chInfoId;
    String channelName = chInfoName;
    String channelDesc = chInfoDesc;
    String? darwinCategory;

    switch (category) {
      case alarm:
        channelId = chAlarmId; channelName = chAlarmName; channelDesc = chAlarmDesc;
        darwinCategory = catAlarm;
        break;
      case reminder:
        channelId = chReminderId; channelName = chReminderName; channelDesc = chReminderDesc;
        darwinCategory = catReminder;
        break;
      default:
        channelId = chInfoId; channelName = chInfoName; channelDesc = chInfoDesc;
        darwinCategory = catInfo;
    }

    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDesc,
      importance: (category == alarm) ? Importance.max : (category == reminder ? Importance.high : Importance.defaultImportance),
      priority: (category == alarm) ? Priority.max : (category == reminder ? Priority.high : Priority.defaultPriority),
      styleInformation: style,
      icon: '@mipmap/ic_launcher',
      largeIcon: (largeIcon == null)
          ? const DrawableResourceAndroidBitmap('@mipmap/ic_launcher')
          : largeIcon as dynamic,
      enableVibration: (category != info),
      playSound: (category != info),
      ticker: 'quote_ticker',
      // category field may not exist on older plugin versions; we avoid it for safety.
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(
        categoryIdentifier: darwinCategory,
        presentAlert: true,
        presentBadge: true,
        presentSound: category != info,
      ),
      macOS: DarwinNotificationDetails(
        categoryIdentifier: darwinCategory,
        presentAlert: true,
        presentBadge: true,
        presentSound: category != info,
      ),
    );

    await _plugin.show(id, title, body, details, payload: payload);
  }

  // 便捷方法（不破坏兼容性）
  static Future<void> showAlarm({required int id, required String title, required String body, String? payload}) =>
      show(id: id, title: title, body: body, category: alarm, payload: payload);
  static Future<void> showReminder({required int id, required String title, required String body, String? payload}) =>
      show(id: id, title: title, body: body, category: reminder, payload: payload);
  static Future<void> showInfo({required int id, required String title, required String body, String? payload}) =>
      show(id: id, title: title, body: body, category: info, payload: payload);
}
