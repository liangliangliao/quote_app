import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  static Future<bool> isEnabled() async {
    final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl == null) return true;
    return await androidImpl.areNotificationsEnabled() ?? true;
  }

  static Future<void> request() async {
    final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl != null) {
      await androidImpl.requestNotificationsPermission();
    }
  }


  static Future<void> init() async {
final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
if (androidImpl != null) {
  final enabled = await androidImpl.areNotificationsEnabled() ?? true;
  if (!enabled) {
    await androidImpl.requestNotificationsPermission();
  }
}

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
  }

  static Future<void> showSimple(String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails('default', '默认通知',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority),
    );
    await _plugin.show(DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body, details);
  }

  /// 兼容旧代码：支持命名参数 id/title/body；若缺省则使用默认
/// 兼容旧代码：支持命名参数 id/title/body/largeIconPath；若缺省则使用默认
static Future<void> show({int? id, String? title, String? body, String? largeIconPath}) async {
  final androidDetails = AndroidNotificationDetails(
    'default',
    '默认通知',
    importance: Importance.defaultImportance,
    priority: Priority.defaultPriority,
    largeIcon: (largeIconPath != null && largeIconPath.isNotEmpty)
        ? FilePathAndroidBitmap(largeIconPath)
        : null,
  );
  final details = NotificationDetails(android: androidDetails);
  final nid = id ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000);
  final t = title ?? '提醒';
  final b = body ?? '';
  await _plugin.show(nid, t, b, details);
}
}
