class PermGate { static bool shownHome = false; }
