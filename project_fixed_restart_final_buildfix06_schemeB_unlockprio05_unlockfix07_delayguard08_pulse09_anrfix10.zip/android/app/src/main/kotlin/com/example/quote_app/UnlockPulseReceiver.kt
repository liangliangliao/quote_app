package com.example.quote_app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import kotlin.concurrent.thread

/**
 * UnlockPulse 的回调接收器：
 * - 每次触发后自循环调度下一次（非 WorkManager）；
 * - 只在检测到“从锁屏->已解锁”的状态跃迁时触发业务；
 * - 其余时间只更新 lastLocked 状态。
 */
class UnlockPulseReceiver : BroadcastReceiver() {

  override fun onReceive(context: Context, intent: Intent?) {
    val app = context.applicationContext
    thread(name = "unlock-pulse") {
      try {
        // 如果功能已关闭，则取消后续脉冲。
        if (!UnlockPulse.shouldEnable(app)) {
          UnlockPulse.logWithTime(app, "【解锁脉冲】功能已关闭，取消脉冲（回包：DISABLED）")
          UnlockPulse.cancel(app)
          return@thread
        }

        val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val km = app.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager

        val interactive = try { pm?.isInteractive ?: false } catch (_: Throwable) { false }
        val locked = try { km?.isKeyguardLocked ?: true } catch (_: Throwable) { true }

        // 将“屏幕不亮/不可交互”也视为 locked，便于后续识别 unlock 跃迁。
        val nowLocked = (!interactive) || locked
        val lastLocked = UnlockPulse.getLastLocked(app)

        // 更新 lastLocked（先更新，避免并发）
        UnlockPulse.setLastLocked(app, nowLocked)

        // 自循环调度下一次：
        // - 若当前处于锁屏/上锁：更频繁一点（30s）提高解锁后命中率
        // - 若已解锁：降低频率（90s）降低后台唤醒
        val nextDelay = if (nowLocked) 30_000L else 90_000L
        UnlockPulse.scheduleNext(app, delayMs = nextDelay)

        // 只在“从 locked -> unlocked”跃迁时触发业务
        if (lastLocked && !nowLocked) {
          val now = System.currentTimeMillis()
          val sp = app.getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
          val lastTrigger = sp.getLong("last_unlock_trigger_ts", 0L)
          if (lastTrigger > 0 && (now - lastTrigger) < 3000L) {
            UnlockPulse.logWithTime(app, "【解锁脉冲】3 秒内已触发过解锁链路，跳过（回包：SKIP_DUP）")
            return@thread
          }

          sp.edit().putLong("last_unlock_trigger_ts", now).apply()

          // 已确认解锁并即将执行业务：取消 5 分钟窗口兜底（避免重复）
          try { UnlockWatchdog.cancel(app) } catch (_: Throwable) {}

          UnlockPulse.logWithTime(app, "【解锁脉冲】检测到解锁跃迁，执行高优先级解锁链路（回包：OK）")

          UnlockEventHandler.withHighPriority(app, "pulse") {
            try { UnlockEventHandler.handleUnlockLightReminder(app, source = "pulse") } catch (_: Throwable) {}
            try { GeoUnlockOrchestrator.run(app, "pulse") } catch (_: Throwable) {}
          }
        }
      } catch (t: Throwable) {
        try { UnlockPulse.logWithTime(app, "【解锁脉冲】异常：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
        // 异常时仍尽量保持脉冲链路不断：下一次 90s 再试
        try { UnlockPulse.scheduleNext(app, delayMs = 90_000L) } catch (_: Throwable) {}
      }
    }
  }
}
