import 'dart:async';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';

/// Global background music service for sport running.
/// It is intentionally decoupled from page lifecycle so music can continue
/// when user leaves SportRunningPage and returns later.
class SportMusicService {
  SportMusicService._();
  static final SportMusicService instance = SportMusicService._();

  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<void>? _completeSub;

  List<String> _playlist = <String>[];
  String _mode = 'order'; // order / random
  int _index = 0;
  bool _started = false;
  final Random _rand = Random();

  Future<void> configure({required List<String> playlist, required String mode}) async {
    _playlist = List<String>.from(playlist);
    _mode = (mode == 'random') ? 'random' : 'order';
    // Setup completion callback once.
    _completeSub ??= _player.onPlayerComplete.listen((_) {
      // ignore: discarded_futures
      playNext();
    });
    try {
      await _player.setReleaseMode(ReleaseMode.stop);
    } catch (_) {}
  }

  bool get isStarted => _started;

  Future<void> startIfNeeded() async {
    if (_playlist.isEmpty) return;
    if (_started) {
      try {
        await _player.resume();
      } catch (_) {}
      return;
    }
    _started = true;
    if (_mode == 'random') {
      _index = _rand.nextInt(_playlist.length);
    } else {
      _index = 0;
    }
    await _playAt(_index);
  }

  Future<void> playAt(int idx) async {
    if (_playlist.isEmpty) return;
    _started = true;
    _index = idx.clamp(0, _playlist.length - 1);
    await _playAt(_index);
  }

  Future<void> playNext() async {
    if (!_started) return;
    if (_playlist.isEmpty) return;
    if (_playlist.length == 1) {
      await _playAt(0);
      return;
    }
    int next = _index;
    if (_mode == 'random') {
      next = _rand.nextInt(_playlist.length);
      if (next == _index) next = (next + 1) % _playlist.length;
    } else {
      next = (_index + 1) % _playlist.length;
    }
    _index = next;
    await _playAt(_index);
  }

  Future<void> pause() async {
    try {
      await _player.pause();
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
    _started = false;
  }

  Future<void> _playAt(int idx) async {
    if (_playlist.isEmpty) return;
    final p = _playlist[idx];
    if (p.trim().isEmpty) return;
    try {
      await _player.stop();
    } catch (_) {}
    try {
      await _player.play(DeviceFileSource(p));
    } catch (_) {}
  }
}
