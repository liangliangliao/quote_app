// GENERATED FIX: robust data injection + avatar base64 scaling
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/services.dart' show rootBundle;
import 'package:webview_flutter/webview_flutter.dart';
import 'package:image/image.dart' as img;
import '../utils/debug_logger.dart';

class HomeHtmlView extends StatefulWidget {
  final String assetPath;
  final Map<String, dynamic>? data; // null => keep static HTML
  const HomeHtmlView({super.key, required this.assetPath, required this.data});
  @override
  State<HomeHtmlView> createState() => _HomeHtmlViewState();
}

class _HomeHtmlViewState extends State<HomeHtmlView> {
  bool _pendingReveal = false;
  String? _pendingRevealKind;

  late final WebViewController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) async { _ready = true; await _injectIfNeeded(); }))
      ;
    _loadFirstFrame();
}

  @override
  void didUpdateWidget(covariant HomeHtmlView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data) { _injectIfNeeded(); }
  }

  // -- Helpers -----------------------------------------------------------------
String _coalesce(Map d, List keys) {
  for (final k in keys) {
    if (d.containsKey(k) && d[k] != null) {
      final v = d[k];
      if (v is String && v.trim().isNotEmpty) return v.trim();
      return v.toString();
    }
  }
  return '';
}


  static bool _looksLikeUrl(String s) => s.startsWith('http://') || s.startsWith('https://');
  static bool _looksLikeData(String s) => s.startsWith('data:image/');

  static String _extToMime(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    if (p.endsWith('.gif')) return 'image/gif';
    return 'image/jpeg';
  }

  /// Read an avatar source and return a **small** data URL (<= ~60KB) to avoid
  /// evaluateJavascript length limits on Android WebView.
  Future<String> _normalizeAvatar(dynamic raw) async {
    if (raw == null) return '';
    final s = raw.toString();
    if (s.isEmpty) return '';
    if (_looksLikeUrl(s) || _looksLikeData(s)) return s;

    // Try file path (absolute or file://)
    var path = s;
    if (path.startsWith('file://')) path = path.substring(7);
    final f = File(path);
    if (!(await f.exists())) return '';

    // Decode -> downscale -> JPEG(85)
    try {
      final bytes = await f.readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return '';
      final maxSide = 256;
      final resized = img.copyResize(decoded, width: decoded.width > decoded.height ? maxSide : null, height: decoded.height >= decoded.width ? maxSide : null, interpolation: img.Interpolation.average);
      final out = img.encodeJpg(resized, quality: 85);
      final b64 = base64Encode(out);
      return 'data:image/jpeg;base64,' + b64;
    } catch (e) {
      try { await DLog.e('HTML','avatar normalize failed: ' + e.toString()); } catch(_){}
      return '';
    }
  }

  
  Future<void> _loadFirstFrame() async {
    // Blank-first strategy
    final isBlank = (widget.data is Map && (widget.data as Map).containsKey('__blank__'));
    // If we already have data, compose final HTML and load once to avoid flicker.
    try {
      final d = widget.data;
if (d != null) {
        final payloadMap = <String, dynamic>{
          'topic': _coalesce(d, ['topic','title','headline','subject','theme','主题','标题']),
          'quote': _coalesce(d, ['quote','content','body','正文']),
          'author': _coalesce(d, ['author','author_name','speaker','signature','署名','签名','credit']),
          'source': _coalesce(d, ['source','origin','source_from','出处','来源','from']),
          'note': _coalesce(d, ['explain','explanation','note','comment','memo','备注']),
        };
        final rawAvatar = d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url'];
        payloadMap['avatarUrl'] = await _normalizeAvatar(rawAvatar);
        if (d.containsKey('focalX')) payloadMap['focalX'] = d['focalX'];
        if (d.containsKey('focalY')) payloadMap['focalY'] = d['focalY'];

        final tpl = await rootBundle.loadString(widget.assetPath);
        final payloadJson = jsonEncode(payloadMap);
        // Hide body until data applied, then reveal, to avoid static->dynamic flash.
        final injector = '''
<script>
document.addEventListener('DOMContentLoaded', function() {
  try {
    var payload = PAYLOAD;
    if (window.setDynamicData) { window.setDynamicData(payload); }
    document.body.style.visibility = 'visible';
  } catch(e) { console && console.error && console.error('inject-on-first-frame failed', e); document.body.style.visibility = 'visible'; }
});
</script>'''.replaceAll("PAYLOAD", payloadJson);
        String html = tpl;
        if (!html.contains('<body')) {
          // fallback: just load template
          await _controller.loadFlutterAsset(widget.assetPath);
          return;
        }
        // ensure hidden before injecting
        if (!RegExp(r'visibility\s*:\s*hidden').hasMatch(html)) {
          html = html.replaceFirst('<body', '<body style="visibility:hidden"');
        }
        html = html.replaceFirst('</body>', injector + '\n</body>');
        await _controller.loadHtmlString(html);
        _ready = true; // avoid double-injection in onPageFinished
        return;
      }
    } catch (_) {
      // fallback to asset
    }
    await _controller.loadFlutterAsset(widget.assetPath);
  }

Future<void> _injectIfNeeded() async {
    if (!_ready) return;
    final d = widget.data;
if (d == null) return;
    final payloadMap = <String, dynamic>{
  'topic': _coalesce(d, ['topic','title','headline','subject','theme','主题','标题']),
  'quote': _coalesce(d, ['quote','content','body','正文']),
  'author': _coalesce(d, ['author','author_name','speaker','signature','署名','签名','credit']),
  'source': _coalesce(d, ['source','origin','source_from','出处','来源','from']),
  'note': _coalesce(d, ['explain','explanation','note','comment','memo','备注']),
  'avatarUrl': await _normalizeAvatar(
    d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url']
  ),
  if (d.containsKey('focalX')) 'focalX': d['focalX'],
  if (d.containsKey('focalY')) 'focalY': d['focalY'],
};
    // avatar
    final rawAvatar = d['avatarUrl'] ?? d['avatar_url'] ?? d['avatar'] ?? d['avatarImg'] ?? d['avatar_path'] ?? d['portrait_url'];
    payloadMap['avatarUrl'] = await _normalizeAvatar(rawAvatar);
    if (d.containsKey('focalX')) payloadMap['focalX'] = d['focalX'];
    if (d.containsKey('focalY')) payloadMap['focalY'] = d['focalY'];

    final payloadJson = jsonEncode(payloadMap);

    try { await DLog.i('HTML', '注入数据: ' + (payloadJson.length > 256 ? (payloadJson.substring(0,256)+'...('+payloadJson.length.toString()+' bytes)') : payloadJson)); } catch(_){}

    // Some WebViews have trouble with very long evaluateJavascript strings.
    // Keep it small by compressing avatar above. Additionally, guard with try..catch in JS.
    final script = "try { window.setDynamicData(PAYLOAD); } catch(e) { console && console.error && console.error('inject failed', e); }".replaceFirst("PAYLOAD", payloadJson);
    await _controller.runJavaScript(script);
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}

  Future<void> _revealInWebView() async {
    const js = '''(function(){try{
      var sels = ['#topic-text','#quote-text','#author-text','#note-text','#avatar-img',
                  '[id*="avatar"]','[class*="avatar"]','img[alt*="avatar"]'];
      for (var i=0;i<sels.length;i++){
        var nodes = document.querySelectorAll(sels[i]);
        for (var j=0;j<nodes.length;j++){ nodes[j].style.visibility = 'visible'; }
      }
      if (document && document.body) document.body.style.visibility = 'visible';
      return true;
    }catch(e){ return false; }})();''';
    try {
      await _controller.runJavaScriptReturningResult(js);
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 60));
      try { await _controller.runJavaScriptReturningResult(js); } catch(__) {}
    }
  }

