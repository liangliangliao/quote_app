
import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import '../utils/text_utils.dart';

String _uid(String prefix){
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  return '$prefix-$ts-${r.nextInt(1<<32)}';
}

class ConfigDao {
  Future<Map<String, dynamic>> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    return rows.isEmpty ? {} : rows.first;
  }

  Future<void> save({required String apiKey, required String model, required String endpoint, String backgroundImage = ''}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('configs', limit: 1);
    if (rows.isEmpty) {
      await db.insert('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint, 'background_image': backgroundImage});
    } else {
      await db.update('configs', {'api_key': apiKey, 'model': model, 'endpoint': endpoint, 'background_image': backgroundImage},
          where: 'id=?', whereArgs: [rows.first['id']]);
    }
  }
}


class TaskDao {
  Future<String> create({required String name, required String type, required DateTime startTime, String prompt='', String avatarPath='', String status='open', String freqType='daily', int? freqWeekday, int? freqDayOfMonth, String freqCustom=''}) async {
    return await insert(name: name, type: type, startTime: startTime, prompt: prompt, avatarPath: avatarPath, status: status, freqType: freqType, freqWeekday: freqWeekday, freqDayOfMonth: freqDayOfMonth, freqCustom: freqCustom);
  }

  Future<List<Map<String, dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return db.query('tasks', orderBy: 'id DESC');
  }

  Future<Map<String, dynamic>?> byUid(String uid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<String> insert({required String name, required String type, required DateTime startTime, String prompt = '', String avatarPath = '', String status = 'open', String freqType='daily', int? freqWeekday, int? freqDayOfMonth, String freqCustom=''} ) async {
    final db = await AppDatabase.instance();
    final uid = _uid('task');
    await db.insert('tasks', {
      'task_uid': uid,
      'name': name,
      'type': type,
      'start_ts': startTime.millisecondsSinceEpoch,
      'next_run_ts': startTime.millisecondsSinceEpoch,
      'prompt': prompt,
      'avatar_path': avatarPath,
      'status': status,
      'freq_type': freqType,
      'freq_weekday': freqWeekday,
      'freq_day_of_month': freqDayOfMonth,
      'freq_custom': freqCustom,
    });
    return uid;
  }

  Future<void> update(String taskUid, Map<String, dynamic> patch) async {
    final db = await AppDatabase.instance();
    await db.update('tasks', patch, where: 'task_uid=?', whereArgs: [taskUid]);
  }

  Future<void> delete(String taskUid) async {
    final db = await AppDatabase.instance();
    await db.delete('tasks', where: 'task_uid=?', whereArgs: [taskUid]);
  }
}

class QuoteDao {
  Future<int> count() async {
    final db = await AppDatabase.instance();
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM quotes')) ?? 0;
  }

  Future<List<Map<String,dynamic>>> latest({int limit=100, int offset=0, String? q}) async {
    final db = await AppDatabase.instance();
    if (q!=null && q.trim().isNotEmpty) {
      return db.query('quotes', where: 'content LIKE ?', whereArgs: ['%$q%'], orderBy: 'id DESC', limit: limit, offset: offset);
    }
    return db.query('quotes', orderBy: 'id DESC', limit: limit, offset: offset);
  }

  Future<Map<String,dynamic>?> latestOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', orderBy: 'id DESC', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String,dynamic>>> unnotified() async {
    final db = await AppDatabase.instance();
    return db.query('quotes', where: 'notified=0', orderBy: 'created_at ASC');
  }

  Future<void> markNotifiedByUid(String quoteUid) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
  }

  Future<bool> existsSimilar(String content, {double threshold=0.9}) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', columns: ['content']);
    final sNorm = normalizeText(content);
    for (final r in rows) {
      final c = normalizeText((r['content'] ?? '') as String);
      if (c == sNorm) return true;
      final sim = jaroWinkler(sNorm, c);
      if (sim >= threshold) return true;
    }
    return false;
  }

  Future<String?> insertIfUnique({required String taskUid, required String type, required String taskName, required String avatarPath, required String content}) async {
    if (await existsSimilar(content)) return null;
    final db = await AppDatabase.instance();
    final uid = _uid('quote');
    await db.insert('quotes', {
      'quote_uid': uid,
      'task_uid': taskUid,
      'content': content,
      'type': type,
      'notified': 0,
      'task_name': taskName,
      'avatar_path': avatarPath,
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
    return uid;
  }
}

class LogDao {
  Future<void> add({required String taskUid, required String detail}) async {
    final db = await AppDatabase.instance();
    await db.insert('logs', {
      'log_uid': _uid('log'),
      'task_uid': taskUid,
      'detail': detail,
      'created_at': DateTime.now().millisecondsSinceEpoch
    });
  }

  Future<List<Map<String,dynamic>>> latest({int limit=50, int offset=0}) async {
    final db = await AppDatabase.instance();
    // join with tasks for name and start_time
    return await db.rawQuery('''
      SELECT l.*, t.name as task_name, t.start_time as task_start_time
      FROM logs l LEFT JOIN tasks t ON l.task_uid = t.task_uid
      ORDER BY l.id DESC LIMIT ? OFFSET ?
    ''', [limit, offset]);
  }
}


extension QuoteDaoExtras on QuoteDao {
  Future<String?> latestForTask(String taskUid) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return (rows.first['content'] ?? '') as String;
  }

  Future<bool> updateLatestForTask(String taskUid, String content) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return false;
    final id = rows.first['id'] as int;
    await db.update('quotes', {'content': content, 'notified': 0, 'created_at': DateTime.now().millisecondsSinceEpoch}, where: 'id=?', whereArgs: [id]);
    return true;
  }
}


DateTime computeNextRunFrom(DateTime now, {required String freqType, required DateTime baseTime, int? freqWeekday, int? freqDayOfMonth}) {
  final hh = baseTime.hour;
  final mm = baseTime.minute;
  if (freqType == 'daily') {
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    return today.isAfter(now) ? today : today.add(const Duration(days: 1));
  } else if (freqType == 'weekly') {
    final target = (freqWeekday ?? 1).clamp(1,7);
    int delta = (target - now.weekday) % 7;
    var candidate = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
    if (!candidate.isAfter(now)) candidate = candidate.add(const Duration(days: 7));
    return candidate;
  } else if (freqType == 'monthly') {
    final day = (freqDayOfMonth ?? 1).clamp(1,31);
    int year = now.year, month = now.month;
    int end = DateTime(year, month+1, 0).day;
    var candidate = DateTime(year, month, day.clamp(1,end), hh, mm);
    if (!candidate.isAfter(now)) {
      month += 1;
      end = DateTime(year, month+1, 0).day;
      candidate = DateTime(year, month, day.clamp(1,end), hh, mm);
    }
    return candidate;
  } else {
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    return today.isAfter(now) ? today : today.add(const Duration(days: 1));
  }
}
