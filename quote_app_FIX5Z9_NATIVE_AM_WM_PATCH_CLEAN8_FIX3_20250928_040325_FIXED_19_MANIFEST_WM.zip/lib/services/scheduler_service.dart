import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import '../platform/native_scheduler.dart';
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import 'package:sqflite/sqflite.dart';

import '../utils/debug_logger.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import 'dart:async';
import '../platform/perm_helper.dart';

import '../utils/run_context.dart';
import 'run_guard.dart';
// === Scheduler constants ===
const Duration kExactGrace = Duration(minutes: 2); // 精准闹钟允许的过期容忍窗口
const Duration kFallbackDelay = Duration(minutes: 2); // WM兜底延迟


// ====== 日志辅助：统一中文上下文 ======
// ====== 日志辅助：统一中文上下文 ======
String _fmt(DateTime dt) => dt.toLocal().toString().split('.').first;
Future<void> _logEnter(String stage, {String? uid, String? title, DateTime? when, String extra = ''}) async {
  final ts = when != null ? _fmt(when) : '';
  final name = (title ?? '');
  final idPart = uid != null ? '(id='+uid+')' : '';
  final whenPart = ts.isNotEmpty ? (' @'+ts) : '';
  final base = '【进入】' + stage + (name.isNotEmpty?(' '+name):'') + idPart + whenPart + (extra.isNotEmpty?(' '+extra):'');
  await DLog.i('SCH', base);
  await LogDao().add(taskUid: uid ?? '', detail: base);
}
class SchedulerService
{
  // === Fallback attempts guard ===
  static const int _kMaxFallbackAttempts = 2; // 最大兜底重试次数
  static const int _kFallbackBackoffMin = 3;  // 每次递增的退避分钟 （1x, 2x, ...）

  // === 动态参数：从 configs 或 meta 读取（有默认值） ===
  static Future<int> _getTtlMinutes() async {
    try { return await ConfigDao().getInt('ttl_minutes', 10); } catch (_) { return 10; }
  }
  static Future<int> _getFbMaxAttempts() async {
    try { return await ConfigDao().getInt('fb_max_attempts', _kMaxFallbackAttempts); } catch (_) { return _kMaxFallbackAttempts; }
  }
  static Future<int> _getFbBackoffMin() async {
    try { return await ConfigDao().getInt('fb_backoff_min', _kFallbackBackoffMin); } catch (_) { return _kFallbackBackoffMin; }
  }

  static Future<List<String>> _metaCols() async {
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery("PRAGMA table_info(meta)");
    final cols = rows.map((e)=> (e['name'] ?? e['cid']).toString()).toList();
    // meta 可能是 (k,v) 或 (key,value)
    final k = cols.contains('k') ? 'k' : 'key';
    final v = cols.contains('v') ? 'v' : 'value';
    return [k, v];
  }

  static Future<int> _fbAttemptGet(String uid, String runKey) async {
    final db = await AppDatabase.instance();
    final cols = await _metaCols();
    final kcol = cols[0], vcol = cols[1];
    final key = 'fb_attempt_'+uid+'_'+runKey;
    final rows = await db.query('meta', where: kcol+'=?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return 0;
    final s = rows.first[vcol]?.toString() ?? '0';
    final n = int.tryParse(s) ?? 0;
    return n;
  }

  static Future<void> _fbAttemptSet(String uid, String runKey, int n) async {
    final db = await AppDatabase.instance();
    final cols = await _metaCols();
    final kcol = cols[0], vcol = cols[1];
    final key = 'fb_attempt_'+uid+'_'+runKey;
    final existing = await db.query('meta', where: kcol+'=?', whereArgs: [key], limit: 1);
    final row = {kcol: key, vcol: n.toString()};
    if (existing.isEmpty) {
      await db.insert('meta', row, conflictAlgorithm: ConflictAlgorithm.replace);
    } else {
      await db.update('meta', row, where: kcol+'=?', whereArgs: [key]);
    }
  }

  static Future<void> _fbAttemptClear(String uid, String runKey) async {
    final db = await AppDatabase.instance();
    final cols = await _metaCols();
    final kcol = cols[0];
    final key = 'fb_attempt_'+uid+'_'+runKey;
    await db.delete('meta', where: kcol+'=?', whereArgs: [key]);
  }

  static final Set<String> _schedulingInFlight = <String>{};
  // —— 单任务“仅保留下一次触发”的固定 ID ——
  static int _nextAlarmId(String uid, String runKey) => (uid.hashCode ^ (runKey.hashCode<<1)) & 0x7fffffff;

  static Future<void> cancelNextForTask(String uid, {String? runKey, bool includeFallback = true}) async {
    await _logEnter('取消环节', uid: uid);
    await DLog.i('SCH','开始取消先前计划：uid='+uid+(runKey!=null?(' run='+runKey!):''));
    // 若未传 runKey，推断当前下一次，并以其 runKey 精确取消
    if (runKey == null) {
      final db = await AppDatabase.instance();
      final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
      if (rows.isNotEmpty) {
        final next = _computeNext(rows.first);
        if (next != null) { runKey = _runKeyForPlanned(next); }
      }
    }
    try {
      await NativeScheduler.cancel(_nextAlarmId(uid, runKey ?? ''));
      await DLog.i('SCH','已取消AM精确闹钟 id='+_nextAlarmId(uid, (runKey ?? '')).toString());
    } catch (e) { await DLog.w('SCH','取消AM精确闹钟异常 uid='+uid+' err='+e.toString()); }
    try {
      await Workmanager().cancelByUniqueName('wm_run_'+uid+'_'+(runKey ?? ''));
      await DLog.i('SCH','WM一次性取消提交完成 name='+'wm_run_'+uid+'_'+(runKey ?? ''));
    } catch (e) { await DLog.w('SCH','取消WM一次性异常 uid='+uid+' err='+e.toString()); }
    if (includeFallback) {
      try {
        await Workmanager().cancelByUniqueName('fb_next_'+uid+'_'+(runKey ?? ''));
        await DLog.i('SCH','WM兜底取消提交完成 name='+'fb_next_'+uid+'_'+(runKey ?? ''));
      } catch (e) { await DLog.w('SCH','取消WM兜底异常 uid='+uid+' err='+e.toString()); }
    }
    // 兼容旧命名（老版本可能还残留）
    try { await Workmanager().cancelByUniqueName('next_'+uid); } catch (_) {}
    try { await Workmanager().cancelByUniqueName('fb_next_'+uid); } catch (_) {}
    await DLog.i('SCH','已尝试取消完成 uid='+uid);
  }
/// 初始化调度：初始化 WorkManager，并在无精确闹钟权限时注册 15 分钟兜底任务。
  static Future<void> init() async {
    await DLog.i('SCH', 'init start');
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'hasExact(now)=$hasExact');
    if (!hasExact) { // no exact alarm permission: keep periodic fallback alive
      // (policy) do not open system settings here per product requirement
      await Workmanager().registerPeriodicTask(
          'due_check_periodic',
          'due_check_periodic',
          frequency: const Duration(minutes: 15),
          initialDelay: const Duration(minutes: 15),
          existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
        );
        await DLog.i('SCH', 'registered fallback periodic task');
        
    }
  }

  /// 扫描任务并为每个任务安排下一次触发（有精确闹钟权限时使用原生 AlarmManager）。
  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'hasExact(now)=$hasExact');
    final tasks = await TaskDao().all();
    final Map<String, DateTime> _nextChosen = {};

    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;
      final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) continue;

      final next = _computeNext(t);
      if (next == null) continue;
      // 去重：同一 uid 只保留最早 future 触发 
      if (_nextChosen.containsKey(uid)) {
        if (next.isBefore(_nextChosen[uid]!)) {
          _nextChosen[uid] = next;
        }
        continue;
      }
      else {
        _nextChosen[uid] = next;
      }

      final diffSecs = next.difference(DateTime.now()).inSeconds;
      if (diffSecs.abs() <= 5) {
        await DLog.i('SCH', 'instant fire $uid');
        await SchedulerService.sendForTask(t, runKey: _runKeyForPlanned(next), source: 'INSTANT');
        await LogDao().add(taskUid: uid, detail: '即时触发：${_fmt(DateTime.now())}');
        continue;
      }

      // 把“下一次”写回任务（保持你原有约定）
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [uid]);
        

      // 精确权限：优先走 AM，否则 WM
      if (await PermHelper.hasExactAlarmPermission()) {
        final runKey = _runKeyForPlanned(next);
        // 若已略过但在 2 分钟容忍窗口内，直接用 WM 立即执行；否则注册 AM
        if (next.isBefore(DateTime.now()) && DateTime.now().difference(next) <= kExactGrace) {
          await _scheduleWmOneOff(
            'wm_run_'+uid+'_'+runKey,
            {'job':'wm_run','task_uid': uid, 'run_key': runKey},
            Duration.zero,
          );
          await DLog.w('SCH','已过期≤2分钟，用WM立即执行 uid='+uid+' runKey='+runKey);
        } else {
          // Build AM payload depending on task type
          // Build AM payload depending on task type
          final type = (t['type'] ?? 'manual').toString();
          final runKey = _runKeyForPlanned(next);
          Map<String, dynamic> amPayload = {'job':'am','task_uid': uid, 'run_key': runKey};
          bool notifyByAm = false;
          if (type == 'manual') {
            final row = await QuoteDao().latestByTaskUid(uid);
            final content = (row?['content'] ?? '').toString();
            if (content.isNotEmpty) {
              amPayload['title'] = (t['name'] ?? '提醒').toString();
              amPayload['body'] = content;
              amPayload['notify'] = true;
              notifyByAm = true;
            }
          } else if (type == 'carousel') {
            final row = await QuoteDao().peekCarouselNext(uid);
            final content = (row?['content'] ?? '').toString();
            final title = (row?['task_name'] ?? (t['name'] ?? '提醒')).toString();
            if (content.isNotEmpty) {
              amPayload['title'] = title;
              amPayload['body'] = content;
              amPayload['notify'] = true;
              notifyByAm = true;
            }
          } else {
            // auto: no AM notification, WM will do heavy lifting
          }

          final okNative = await NativeScheduler.scheduleExactAt(
            id: _nextAlarmId(uid, runKey),
            epochMs: next.millisecondsSinceEpoch,
            payload: amPayload,
          );

          // 同步安排一个 WM 任务用于“对账/续排”：
          // - manual/carousel：'wm_after_am'（仅记账与游标，不再通知）
          // - auto：'wm_run'（完整联网去重与通知）
          final wmDelay = next.difference(DateTime.now()) + const Duration(seconds: 5);
          if (type == 'auto') {
            final uniq = 'wm_run_'+uid+'_'+runKey;
            await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, wmDelay);
          } else {
            final uniq = 'wm_after_'+uid+'_'+runKey;
            await _scheduleWmOneOff(uniq, {'job':'wm_after_am','task_uid':uid,'run_key':runKey}, wmDelay);
          }
          await DLog.i('SCH', 'AM(Native)注册提交完成 uid='+uid+' ok='+okNative.toString());
          }
      } else {
        // 无精确权限：直接 WM one-off
        final runKey = _runKeyForPlanned(next);
        final uniq = 'wm_run_'+uid+'_'+runKey;
        await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, next.difference(DateTime.now()));
        await DLog.i('SCH', '已注册WM oneOff uid='+uid+' run='+runKey);
        // fallback via NativeScheduler handled natively; no extra WM fallback  // WM 基准 + 2 分钟兜底
      }
      }
    }

  /// 只为指定任务安排下一次触发；不影响其他任务。
  static Future<void> scheduleNextForTask(String uid) async {
    if (_schedulingInFlight.contains(uid)) { await DLog.w('SCH','忽略重复注册(进行中) uid='+uid); return; }
    _schedulingInFlight.add(uid);
    try {
    final db = await AppDatabase.instance();
    final trows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
    if (trows.isEmpty) return;
    final t = trows.first;

    
    // Insurance: cancel any leftover fallback by tag for this uid
    try { await Workmanager().cancelByTag('fb:'+uid); } catch (_) {}
final status = (t['status'] ?? 'on').toString();
    if (status != 'on' && status != 'active') {
      await cancelNextForTask(uid);
      return;
    }

    final next = _computeNext(t);
    if (next == null) {
      await cancelNextForTask(uid);
      return;
    }

    // 即时窗口（±5 秒）直接发送
    final diffSecs = next.difference(DateTime.now()).inSeconds;
    if (diffSecs.abs() <= 5) {
      await SchedulerService.sendForTask(t, runKey: _runKeyForPlanned(next), source: 'INSTANT');
      await LogDao().add(taskUid: uid, detail: '即时触发：${_fmt(DateTime.now())}');
      return;
    }

    // 把“下一次”写回任务
    await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [uid]);

    // 精确权限优先走 AM，否则走 WM one‑off
      // 精确权限：优先走 AM，否则 WM
      // 精确权限：优先走 AM，否则 WM
      if (await PermHelper.hasExactAlarmPermission()) {
        final runKey = _runKeyForPlanned(next);
        // 若已略过但在 2 分钟容忍窗口内，直接用 WM 立即执行；否则注册 AM
        if (next.isBefore(DateTime.now()) && DateTime.now().difference(next) <= kExactGrace) {
          await _scheduleWmOneOff(
            'wm_run_'+uid+'_'+runKey,
            {'job':'wm_run','task_uid': uid, 'run_key': runKey},
            Duration.zero,
          );
          await DLog.w('SCH','已过期≤2分钟，用WM立即执行 uid='+uid+' runKey='+runKey);
        } else {
          final amPayload = {
            'job': 'am',
            'task_uid': uid,
            'run_key': runKey,
            'notify': notifyByAm, // auto 默认不让 AM 直接弹通知，由 WM 路径完成去重 + 生成 + 通知
          };
          final okNative = await NativeScheduler.scheduleExactAt(
            id: _nextAlarmId(uid, runKey),
            epochMs: next.millisecondsSinceEpoch,
            payload: amPayload,
          );
          // 同步安排一个 WM 任务用于“对账/续排”
          final wmDelay = next.difference(DateTime.now()) + const Duration(seconds: 5);
          if (type == 'auto') {
            final uniq = 'wm_run_'+uid+'_'+runKey;
            await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, wmDelay);
          } else {
            final uniq = 'wm_after_'+uid+'_'+runKey;
            await _scheduleWmOneOff(uniq, {'job':'wm_after_am','task_uid':uid,'run_key':runKey}, wmDelay);
          }
        }
      } else {
        // 无精确权限：直接用 WM one-off
        final runKey = _runKeyForPlanned(next);
        await _scheduleWmOneOff(
          'wm_run_'+uid+'_'+runKey,
          {'job':'wm_run','task_uid': uid, 'run_key': runKey},
          const Duration(seconds: 0),
        );
      }
      if (status != 'on' && status != 'active') continue;

      final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) continue;

      final st = (t['start_time'] ?? '').toString();
      await DLog.i('CP', '当天补发检查 task $uid st=$st');
      if (st.isEmpty) continue;

      final planned = _parseTimeOrToday(st);
      if (planned == null) continue;

      // 只在“计划时间已到或已过”的时候触发一次
      final delta = now.difference(planned).inSeconds;
      await DLog.i('CB', 'check task $uid st=$st delta=$delta');
        // 触发窗口：提前 10 秒 ~ 延迟 5 分钟
        if (delta >= -10 && delta <= 300) {
          // recent duplicate guard (5 min)
          final fiveMinAgo = now.subtract(const Duration(minutes: 5)).millisecondsSinceEpoch;
          final recent = await db.query('logs',
            where: 'task_uid=? AND detail LIKE ? AND created_at > ?',
            whereArgs: [uid, '触发:%', fiveMinAgo], limit: 1);
          if (recent.isNotEmpty) { await DLog.i('CB', 'skip recent uid=$uid'); continue; }
          try {
            final _rk = _runKeyForPlanned(planned);
            await _handleCallback(uid, _rk, source: (RunContext.isFromWM ? 'WM' : 'AM'));
          } catch (e) {
            await DLog.w('SCH', '异常（AM/WM回调内部），仅记录 uid='+uid+' err='+e.toString());
          }
          await LogDao().add(taskUid: uid, detail: '触发：${_fmt(now)}');
        } else {
          await DLog.i('CB', '跳过：超出容忍窗口，uid=$uid delta=$delta');
        }

        // === 唯一运行键，分到分钟 ===
  }
  }

  // === 发送通知（内部）===
  
  // === 发送通知（内部）===
  // === 发送通知（对外）===
  static Future<void> sendForTask(Map<String, dynamic> t, {String? runKey, DateTime? planned, String? source}) async {
    return _sendForTask(t, runKey: runKey, planned: planned, source: source);
  }

  static Future<void> _sendForTask(Map<String, dynamic> t, {String? runKey, DateTime? planned, String? source}) async {
    final uid = (t['task_uid'] ?? '').toString();
    final rk  = runKey ?? (planned != null ? DateFormat('yyyyMMdd_HHmm').format(planned.toLocal()) : '');
    final src = (source ?? 'AM');

    // 初始化通知环境
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();

    // 任务状态检查（open/on/active 视为开启；为空也允许）
    final status = (t['status'] ?? '').toString().toLowerCase();
    if (!(status == 'open' || status == 'on' || status == 'active' || status.isEmpty)) {
      await DLog.i('TASK','跳过：任务未开启 uid='+uid+' status='+status);
      return;
    }

    // 通知内容生成
    final type = (t['type'] ?? 'manual').toString();
    String title = (t['name'] ?? '').toString();
    String? iconPath = (t['avatar'] ?? t['icon'])?.toString();
    String? body;

    try {
      if (type == 'manual') {
        // 手动：直接用最近一条名言或任务自带内容
        final row = await QuoteDao().latestByTaskUid(uid);
        body = (row?['content'] ?? t['content'])?.toString();
      } else if (type == 'auto') {
        // 自动：此处先走最小可用通知（生成部分在上层 WM 路径完成）
        final row = await QuoteDao().latestByTaskUid(uid);
        body = (row?['content'] ?? ''); // 无内容时发标题即可
      } else {
        // 轮播：按任务的名言表顺序取下一条（只读不推进）
        final row = await QuoteDao().peekCarouselNext(uid);
        body = row?['content']?.toString();
        // 标题/头像可取名言表字段以覆盖
        title = ((row?['task_name'] ?? title)?.toString() ?? title);
        iconPath = (row?['avatar'] ?? iconPath)?.toString();
      }

      // 发送通知（空文案时只发标题）
      await NotificationService.show(
        title: title.isNotEmpty ? title : '提醒',
        body: (body != null && body.trim().isNotEmpty) ? body : null,
        largeIconPath: (iconPath != null && iconPath.trim().isNotEmpty) ? iconPath : null,
      );
      await DLog.i('NOTI','已发 uid='+uid+' run='+rk+' src='+src);

      // 标记通知已发送（若有名言行）
      try { await QuoteDao().markNotifiedByUid(uid, rk); } catch (_) {}

      // 记日志
      await LogDao().add(taskUid: uid, detail: '成功!');
    } catch (e) {
      await DLog.w('NOTI','异常 uid='+uid+' run='+rk+' err='+e.toString());
      await LogDao().add(taskUid: uid, detail: '错误! '+e.toString());
      rethrow;
    }
  }


  static Future<void> _handleCallback(String uid, String runKey, {required String source}) async {
    // TTL guard: skip stale runs (>10 minutes) without retry
    try {
      if (runKey.isNotEmpty) {
        final y = int.parse(runKey.substring(0,4));
        final M = int.parse(runKey.substring(4,6));
        final d = int.parse(runKey.substring(6,8));
        final hh = int.parse(runKey.substring(9,11));
        final mm = int.parse(runKey.substring(11,13));
        final planned = DateTime(y, M, d, hh, mm);
        final age = DateTime.now().difference(planned).inMinutes;
        final ttl = await _getTtlMinutes();
        if (age > ttl) {
          await DLog.w('SCH', 'TTL skip: stale run_key='+runKey+' age='+age.toString()+'m src='+source);
          return;
        }
      }
    } catch (_) {}

    await DLog.i('SCH', '正常，已经进入回调环节啦！ src='+source+' uid='+uid+' run='+runKey);
    bool proceed = true;
    try {
      if (await RunGuard.begin(uid, runKey, source: source) == false) {
        await DLog.w('SCH', "[RunGuard] dup run suppressed uid="+uid+" run="+runKey+" src="+source);
        proceed = false;
      }
    } catch (_) {}
    if (!proceed) return;

    try {
      final db = await AppDatabase.instance();
      final rows = await db.query('tasks', where: 'task_uid=?', whereArgs: [uid], limit: 1);
      if (rows.isEmpty) return;
      final t = rows.first;
      await SchedulerService.sendForTask(t, runKey: runKey, source: source);

      // 成功后：取消本次兜底 + 注册下一次
      try { await SchedulerService.cancelWmFallbackForRun(uid, runKey);
      try { await _fbAttemptClear(uid, runKey); } catch (_) {}
 } catch (_) {}
      await SchedulerService.scheduleNextForTask(uid);
      await DLog.i('SCH', '回调完成，已续排下一次 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.w('SCH', '异常，进入回调兜底环节！ uid='+uid+' run='+runKey+' err='+e.toString());
      try { await _triggerWmFallbackNow(uid, runKey); } catch (_) {}
    } finally {
      try { await RunGuard.end(uid, runKey, source: source); } catch (_) {}
    }
  }

  // === WM 回调入口 ===
  static Future<void> wmRunTask(String taskUid, String runKey) async {
    await _handleCallback(taskUid, runKey, source: 'WM');
  }


  // === WM after AM 回执入口（仅对账/续排，避免重复通知） ===
  static Future<void> wmAfterAmTask(String taskUid, String runKey) async {
    await _handleCallback(taskUid, runKey, source: 'WM_AFTER_AM');
  }

  // === 当天漏发补发（对外入口）===
  static Future<void> catchupIfMissed() async { await _catchupIfMissed(); }
static String _runKeyForPlanned(DateTime planned) {
  return DateFormat('yyyyMMdd_HHmm').format(planned.toLocal());
}


static DateTime? _computeNext(Map<String, dynamic> t) {
    final now = DateTime.now();
    final start = (t['start_time'] ?? '').toString().trim();
    if (start.isEmpty) return null;

    // 解析“时:分”
    int hh = 9, mm = 0;
    final reHm = RegExp(r'^\d{2}:\d{2}$');
    final reAbs = RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$');
    DateTime? absDt;
    if (reHm.hasMatch(start)) {
      hh = int.parse(start.substring(0,2));
      mm = int.parse(start.substring(3,5));
    } else if (reAbs.hasMatch(start)) {
      final yyyy = int.parse(start.substring(0,4));
        final MMm  = int.parse(start.substring(5,7));
        final dd   = int.parse(start.substring(8,10));
        hh = int.parse(start.substring(11,13));
        mm = int.parse(start.substring(14,16));
        absDt = DateTime(yyyy, MMm, dd, hh, mm);
        
    } else {
      // 尝试从任意字符串中提取 “HH:mm”
      final m2 = RegExp(r'(\d{2}):(\d{2})').firstMatch(start);
      if (m2 != null) {
        hh = int.parse(m2.group(1)!);
          mm = int.parse(m2.group(2)!);
          
      }
    }

    // 读取频率（新字段优先，兼容旧字段）
    final String freqType = (t['freq_type'] ?? t['freq'] ?? 'daily').toString();
    final int? weekDay = (t['freq_weekday'] ?? t['weekday']) as int?;
    final int? dayOfMonth = (t['freq_day_of_month'] ?? t['dayOfMonth']) as int?;

    // 如果 start 为绝对时间且在未来：直接使用它（作为“下一次”）
    if (absDt != null && absDt.isAfter(now)) {
      return absDt;
    }

    if (freqType == 'weekly' && weekDay != null) {
      final wd = weekDay;
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (cand.isBefore(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    }

    if (freqType == 'monthly' && dayOfMonth != null) {
      final d = dayOfMonth.clamp(1,31);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (cand.isBefore(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    }

    // 默认：每天
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    if (!today.isBefore(now)) return today;
    return today.add(const Duration(days: 1));
  }

  
  static DateTime? _parseTimeOrToday(String st) {
    final now = DateTime.now();
    // "HH:mm"
    if (RegExp(r'^\d{2}:\d{2}$').hasMatch(st)) {
      final hh = int.tryParse(st.substring(0, 2)) ?? 0;
      final mm = int.tryParse(st.substring(3, 5)) ?? 0;
      return DateTime(now.year, now.month, now.day, hh, mm);
    }
    // "yyyy-MM-dd HH:mm"
    if (RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$').hasMatch(st)) {
      final yyyy = int.tryParse(st.substring(0, 4)) ?? now.year;
      final MM = int.tryParse(st.substring(5, 7)) ?? now.month;
      final dd = int.tryParse(st.substring(8, 10)) ?? now.day;
      final HH = int.tryParse(st.substring(11, 13)) ?? 0;
      final mm = int.tryParse(st.substring(14, 16)) ?? 0;
      return DateTime(yyyy, MM, dd, HH, mm);
    }
    return null;
  }


static Future<void> _catchupIfMissed() async {
  final db = await AppDatabase.instance();
    final now = DateTime.now();
    final dayStart = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final dayEnd = DateTime(now.year, now.month, now.day, 23, 59, 59, 999).millisecondsSinceEpoch;
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;
      final uid = (t['task_uid'] ?? '').toString();
            if (uid.isEmpty) continue;
      final st = (t['start_time'] ?? '').toString();
      await DLog.i('CP', '当天补发检查 task $uid st=$st');
      if (st.isEmpty) continue;
      final planned = _parseTimeOrToday(st);
      if (planned == null) continue;
      if (planned.isAfter(now)) continue;

      final sent = await db.query('logs',
          where: 'task_uid=? AND created_at BETWEEN ? AND ?',
          whereArgs: [uid, dayStart, dayEnd],
          limit: 1);
      if (sent.isNotEmpty) continue;

      await SchedulerService.sendForTask(t, runKey: _runKeyForPlanned(planned));
      await LogDao().add(taskUid: uid, detail: '补发：${_fmt(now)}');
    }
    

  // 取消某任务的兜底 WM（通过 tag=fb:<uid>）
  static Future<void> cancelWmFallbackForRun(String uid, String runKey) async {
    try {
      await Workmanager().cancelByTag('fb:'+uid);
      await DLog.i('WM','cancel fallback fb:'+uid+' run='+runKey);
    } catch (e) {
      await DLog.w('WM','cancel fallback err: '+e.toString());
    }
  }

  // 立刻触发一个兜底 WM（用于AM未能触达时）
  static Future<void> _triggerWmFallbackNow(String uid, String runKey) async {
    try {
      final uniq = 'wm_fb_'+uid+'_'+runKey;
      await _scheduleWmOneOff(uniq, {'job':'wm_fallback','task_uid':uid,'run_key':runKey}, Duration.zero);
      await DLog.i('WM','trigger fallback now uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.w('WM','trigger fallback err: '+e.toString());
    }
  }
  static Future<void> _scheduleWmOneOff(String uniqueName, Map<String, dynamic> input, Duration delay) async {
    try {
      await Workmanager().registerOneOffTask(
        uniqueName,
        'wm_task',
        initialDelay: delay,
        inputData: input,
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: ((input['job']?.toString() == 'wm_fallback')
              ? ('fb:' + (input['task_uid']?.toString() ?? ''))
              : ('run:' + (input['task_uid']?.toString() ?? ''))),
      );
      await DLog.i('WM','registerOneOffTask unique='+uniqueName+' delay='+delay.inSeconds.toString()+'s');
    } catch (e) {
      await DLog.e('WM','registerOneOffTask error: '+e.toString());
      rethrow;
    }
  }
}
