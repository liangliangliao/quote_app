
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../platform/native_scheduler.dart';
import 'task_runner.dart';

// 精准闹钟允许的过期容忍窗口
const Duration kExactGrace = Duration(minutes: 2);

class SchedulerService {
  /// 初始化：注册 Workmanager callback（由外部 main 调用）
  static Future<void> init() async {
    try {
      await Workmanager().initialize((dispatcher, inputData) async { return true; });
    } catch (_) {}
  }

  /// 计算下一次时间（简单版本：每天 start_time）
  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final start = (t['start_time'] ?? '09:00').toString();
    final now = DateTime.now();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length>1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (!next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }

  static int _alarmId(String uid, String runKey) {
    // stable small int from uid+runKey
    return (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;
  }

  static String _runKeyFromTime(DateTime t) {
    return DateFormat('yyyyMMdd_HHmm').format(t);
  }

  /// 为单个任务安排下一次（AM + WM 兜底）
  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);

    // AlarmManager (native)
    try {
      await NativeScheduler.scheduleExactAt(
        id: _alarmId(uid, runKey),
        epochMs: next.millisecondsSinceEpoch,
        payload: {'uid': uid, 'runKey': runKey, 'title': '提醒', 'body': '到点了'},
      );
      await DLog.i('SCH', 'AM 注册完成 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.w('SCH','AM 注册失败，忽略: '+e.toString());
    }

    // 兜底：WM one-off
    try {
      final delay = next.difference(DateTime.now());
      await Workmanager().registerOneOffTask(
        'wm_run_'+uid+'_'+runKey,
        'wm_task',
        initialDelay: delay.isNegative ? Duration.zero : delay,
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.e('SCH','WM 注册失败: '+e.toString());
    }
  }

  /// 批量为所有任务安排下一次
  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      await scheduleNextForTask((t['task_uid'] ?? '').toString());
    }
  }

  /// 取消单个任务的下一次（AM + WM）
  static Future<void> cancelNextForTask(String uid) async {
    // best-effort: cancel latest two planned keys by time vicinity
    final now = DateTime.now();
    for (int d=0; d<=1; d++) {
      final t = now.add(Duration(days: d));
      final runKey = _runKeyFromTime(DateTime(t.year,t.month,t.day, (t.hour)));
      try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
      try { await Workmanager().cancelByUniqueName('wm_run_'+uid+'_'+runKey); } catch (_) {}
    }
    await DLog.i('SCH','已尝试取消 uid='+uid);
  }

  /// WM 回调入口（由 wm_dispatcher 调用）
  static Future<void> wmRunTask(String uid, String? runKey) async {
    await TaskRunner.run(uid);
  }

  /// AM 回调入口（如果 Native 收到闹钟后通过 MethodChannel 回调 Dart，可调用此方法）
  static Future<void> callback(String uid, String? runKey) async {
    await TaskRunner.run(uid);
  }

  /// 补偿执行（可用于WM启动时做兜底；这里直接无操作）
  static Future<void> catchupIfMissed() async {}
}
