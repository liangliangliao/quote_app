
import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:quote_app/widgets/home_html_view.dart';
import '../data/dao.dart';
import '../utils/debug_logger.dart';
import 'package:quote_app/services/native_guard.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  Map<String, dynamic>? _todayData;
  Map<String, dynamic>? _latestRow;
  bool _firstLoaded = false;
  bool _fav = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SimpleBus.homeTick.addListener(_onBus);
    _load();
  }

  void _onBus() { _load(); }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SimpleBus.homeTick.removeListener(_onBus);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _load();
    }
  }

  Future<String> _avatarToDataUrl(String raw) async {
    final s = (raw).toString().trim();
    if (s.isEmpty) return '';
    if (s.startsWith('data:') || s.startsWith('http://') || s.startsWith('https://')) return s;
    try {
      final f = File(s);
      if (await f.exists()) {
        final bytes = await f.readAsBytes();
        String mime = 'image/png';
        final lower = s.toLowerCase();
        if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) mime = 'image/jpeg';
        else if (lower.endsWith('.webp')) mime = 'image/webp';
        else if (lower.endsWith('.gif')) mime = 'image/gif';
        final b64 = base64Encode(bytes);
        return 'data:$mime;base64,$b64';
      }
    } catch (_) {}
    return '';
  }

  Future<void> _load() async {
    // 仅在首次加载时将数据设为空以显示兜底，后续刷新保持原有数据避免闪屏
    if (!_firstLoaded) {
      setState(() { _todayData = null; _firstLoaded = true; });
    }
    try {
      final dao = QuoteDao();
      final latest = await dao.latestNotifiedToday();
      if (!mounted) return;
      _latestRow = latest;
      if (latest == null) {
        await DLog.i('HOME', '今日未检索到已通知记录：显示兜底 HTML');
        // 若查询不到今日数据，清空数据（此时会显示兜底）
        if (mounted) setState(() { _todayData = null; });
      } else {
        final avatarUrl = await _avatarToDataUrl((latest['avatar'] ?? '').toString());
        // 根据署名和出处组装 author 字段。若存在署名或出处则前缀“——”，否则为空
        final String authorName = (latest['author_name'] ?? latest['author'] ?? '').toString().trim();
        final String source = (latest['source_from'] ?? latest['source'] ?? '').toString().trim();
        String authorLine = '';
        if (authorName.isNotEmpty || source.isNotEmpty) {
          // 如果署名不为空，使用“——署名 出处”，否则仅加前缀
          authorLine = '——';
          if (authorName.isNotEmpty) {
            authorLine += authorName;
            if (source.isNotEmpty) authorLine += ' $source';
          } else {
            authorLine += source;
          }
        }
        final payload = <String, dynamic>{
          'topic': (latest['theme'] ?? latest['topic'] ?? '').toString(),
          'quote': (latest['content'] ?? latest['quote'] ?? '').toString(),
          // 将 author 字段设置为包含署名和出处的组合文本
          'author': authorLine,
          'source': source,
          'note': (latest['explanation'] ?? latest['note'] ?? '').toString(),
          'avatarUrl': avatarUrl,
          // 将背景图片路径作为相对路径传入，供 HTML 页通过 setBackground 使用
          'bgUrl': '../bg-wood-upload.jpg',
        };
        await DLog.i('HOME', '已检索到今日最新已通知记录：准备注入');
        if (mounted) setState(() { _todayData = payload; });
      }
    } catch (e) {
      await DLog.e('HOME', '查询异常：将显示兜底；err=$e');
      if (mounted) setState(() { _todayData = null; });
    }
  }

  Future<void> _copyLatest() async {
    final text = (_latestRow?['content'] ?? '').toString();
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制'), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final assetPath = 'assets/html/poster-wall-only-frame-v23-1.html';
    final content = (!_firstLoaded) ? const {'__blank__': true} : _todayData;
    final topPad = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // 内容区
          Positioned.fill(
            child: Padding(
              padding: EdgeInsets.only(top: topPad + kToolbarHeight),
              child: Center(child: HomeHtmlView(assetPath: assetPath, data: content)),
            ),
          ),
          // 顶栏区域（悬浮白底按钮）
          Positioned(
            top: topPad,
            left: 0,
            right: 0,
            height: kToolbarHeight,
            child: IgnorePointer(
              ignoring: false,
              child: Row(
                children: [
                  const SizedBox(width: 8),
                  const Expanded(child: SizedBox()),
                  // share
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '分享',
                        icon: const Icon(Icons.share, color: Colors.black87),
                        onPressed: () async {
                          // 简化版分享：复制到剪贴板并提示
                          await _copyLatest();
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // copy
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: '复制',
                        icon: const Icon(Icons.copy, color: Colors.black87),
                        onPressed: _copyLatest,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // favorite
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Material(
                      color: Colors.white,
                      elevation: 6,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: _fav ? '取消收藏' : '收藏',
                        icon: Icon(_fav ? Icons.favorite : Icons.favorite_border, color: Colors.black87),
                        onPressed: () => setState(() => _fav = !_fav),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
