import 'package:flutter/material.dart';

/// A TextEditingController that visually hides attachment marker lines like:
///   [图片] /path/to/file
///   [语音] /path/to/file
///
/// This keeps the raw text compatible with existing storage/logic, while
/// preventing file paths from being shown in the editor/reader TextField.
class DiaryContentController extends TextEditingController {
  DiaryContentController({String? text}) : super(text: text);

  static bool _isMarkerLine(String line) {
    final l = line.trimLeft();
    return l.startsWith('[图片]') || l.startsWith('[语音]');
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final baseStyle = style ?? DefaultTextStyle.of(context).style;
    final hiddenStyle = baseStyle.copyWith(
      color: Colors.transparent,
      fontSize: 0.01,
      height: 0.0,
    );

    final full = value.text;
    final composing = value.composing;
    final composingValid = withComposing && composing.isValid && !composing.isCollapsed;

    // Build spans line-by-line so marker lines can be rendered nearly invisible
    // (no visible file path) while keeping the raw content unchanged.
    final lines = full.split('\n');
    final spans = <InlineSpan>[];
    int offset = 0;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i];
      final lineHasNewline = i != lines.length - 1;
      final lineText = lineHasNewline ? '$line\n' : line;
      final segStart = offset;
      final segEnd = offset + lineText.length;

      final segStyle = _isMarkerLine(line) ? hiddenStyle : baseStyle;

      void addSpan(String text, TextStyle s) {
        if (text.isEmpty) return;
        spans.add(TextSpan(text: text, style: s));
      }

      if (composingValid && composing.start < segEnd && composing.end > segStart) {
        final a = (composing.start - segStart).clamp(0, lineText.length);
        final b = (composing.end - segStart).clamp(0, lineText.length);
        addSpan(lineText.substring(0, a), segStyle);
        addSpan(
          lineText.substring(a, b),
          segStyle.copyWith(decoration: TextDecoration.underline),
        );
        addSpan(lineText.substring(b), segStyle);
      } else {
        addSpan(lineText, segStyle);
      }

      offset = segEnd;
    }

    return TextSpan(style: baseStyle, children: spans);
  }
}
