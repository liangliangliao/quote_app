import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import 'utils/debug_logger.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';

class BackgroundTasks {
  /// Register a lightweight periodic self-check using Workmanager.
  /// It re-schedules next runs for all tasks and catches up missed runs.
  static Future<void> registerSelfCheck() async {
    const uniq = 'bg_selfcheck_next';
    try { await Workmanager().cancelByUniqueName(uniq); } catch (_){}

    // Ensure plugin initialized (main.dart also does this; double-initialize is safe-guarded)
    try {
      // No-op if already initialized by main.dart
      // Workmanager().initialize(workmanagerCallbackDispatcher) -- keep single point in main.dart
    } catch (_) {}

    try {
      await Workmanager().registerPeriodicTask(
        uniq,
        'wm_selfcheck',
        inputData: {'job':'wm_selfcheck'},
        frequency: const Duration(minutes: 15),
        initialDelay: const Duration(minutes: 1),
        backoffPolicy: BackoffPolicy.linear,
        backoffPolicyDelay: const Duration(minutes: 5),
        constraints: Constraints(
          
          requiresBatteryNotLow: false,
          requiresCharging: false,
        ),
      );
      await DLog.i('BG', '自检任务已注册（15min 轮询，含1min初始延迟）');
    } catch (e) {
      await DLog.i('BG', '自检注册失败：${e.toString()}');
    }
  }
}
