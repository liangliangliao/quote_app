import './scheduler_service.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'notification_service.dart';
import '../data/db.dart';
import 'scheduler_service.dart';
import '../utils/run_context.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
Workmanager().executeTask((task, inputData) async {
    return await runZonedGuarded(() async {
      try {
        RunContext.isBackground = true;
        WidgetsFlutterBinding.ensureInitialized();
        ui.DartPluginRegistrant.ensureInitialized();
        await DLog.i('WM', 'callbackDispatcher start: ' + task);
        if (task == 'due_once' || task == 'due_check_periodic') {
          await SchedulerService.callback();
          await DLog.i('WM', 'callback executed: ' + task);
        }
        return true;
      } catch (e, s) {
        await DLog.e('WM', 'init/callback failed: ' + e.toString() + '\n' + s.toString());
        return false;
      }
    }, (e, s) async {
      try { await DLog.e('WM', 'Uncaught in WM task: ' + e.toString() + '\n' + s.toString()); } catch (_) {}
      return Future.value(false);
    });
  });
}
