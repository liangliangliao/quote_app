import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/debug_logger.dart';
import 'notification_service.dart';
import 'scheduler_service.dart';
import '../background_tasks.dart';
import '../utils/run_context.dart';

@pragma('vm:entry-point')
void workmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      ui.DartPluginRegistrant.ensureInitialized();
      await NotificationService.init();
      RunContext.markFromWM(); // ensure context is WM

      final job = inputData?['job']?.toString() ?? '';
      final uid = inputData?['task_uid']?.toString() ?? '';
      final runKey = inputData?['run_key']?.toString() ?? '';

      // 只处理我们关心的三类 WM 任务
      if (job == 'wm_after_am') {
        await SchedulerService.wmAfterAmTask(uid, runKey);
        return Future.value(true);
      }
      if (job == 'wm_run') {
        await SchedulerService.wmRunTask(uid, runKey);
        return Future.value(true);
      }
      if (job == 'wm_fallback') {
        await SchedulerService.wmRunTask(uid, runKey); // 兜底也走统一的 run 入口
        return Future.value(true);
      }

      await DLog.i('WM', "调度任务=? "+task.toString());
      return Future.value(true);
    } catch (e) {
      await DLog.e('WM', 'callback error: '+e.toString());
      return Future.value(true);
    }
  });
}
