
import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'db.dart';

class QuoteDao {
  Future<List<Map<String,dynamic>>> fetchUnnotified() async {
    final db = await AppDatabase.instance();
    return db.query('quotes', where: 'notified=0', orderBy: 'created_at ASC');
  }

  Future<void> markNotified(int id) async {
    final db = await AppDatabase.instance();
    await db.update('quotes', {'notified': 1, 'notify_count': 1}, where: 'id=?', whereArgs: [id]);
  }

  Future<void> seedDefaultQuote() async {
    final db = await AppDatabase.instance();
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM quotes')) ?? 0;
    if (count == 0) {
      await db.insert('quotes', {
        'text': '凡是不能杀死我的，必使我更坚强。',
        'author': '弗里德里希·尼采',
        'source': '《偶像的黄昏》',
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'notified': 0,
        'notify_count': 0,
      });
    }
  }

  Future<int> insertQuoteReturnId(String text, {String author = '', String source = ''}) async {
    final db = await AppDatabase.instance();
    return await db.insert('quotes', {
      'text': text,
      'author': author,
      'source': source,
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'notified': 0,
      'notify_count': 0,
    });
  }

  Future<Map<String,dynamic>?> latest() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', orderBy: 'created_at DESC', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String,dynamic>>> list({int limit=100, int offset=0, String? query}) async {
    final db = await AppDatabase.instance();
    if (query!=null && query.trim().isNotEmpty) {
      return db.query('quotes',
          where: 'text LIKE ? OR author LIKE ? OR source LIKE ?',
          whereArgs: ['%$query%','%$query%','%$query%'],
          orderBy: 'created_at DESC', limit: limit, offset: offset);
    }
    return db.query('quotes', orderBy: 'created_at DESC', limit: limit, offset: offset);
  }
}

class ScheduleDao {
  Future<List<Map<String,dynamic>>> all() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('schedules', orderBy: 'id DESC');
    // decode payload to Map for UI
    return rows.map((r){
      final raw = r['payload'];
      Map<String,dynamic> payload;
      if (raw is String) {
        try { payload = jsonDecode(raw); } catch (_) { payload = {}; }
      } else if (raw is Map<String,dynamic>) {
        payload = raw;
      } else {
        payload = {};
      }
      return {
        ...r,
        'payload': payload,
      };
    }).toList();
  }

  Future<int> insert(String type, Map<String,dynamic> payload) async {
    final db = await AppDatabase.instance();
    return await db.insert('schedules', {
      'type': type,
      'payload': jsonEncode(payload),
      'enabled': 1,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<void> updateSchedule(int id, {required String type, required Map<String,dynamic> payload}) async {
    final db = await AppDatabase.instance();
    await db.update('schedules', {
      'type': type,
      'payload': jsonEncode(payload),
    }, where: 'id=?', whereArgs: [id]);
  }

  Future<void> setEnabled(int id, bool enabled) async {
    final db = await AppDatabase.instance();
    await db.update('schedules', {'enabled': enabled ? 1 : 0}, where: 'id=?', whereArgs: [id]);
  }

  Future<void> deleteById(int id) async {
    final db = await AppDatabase.instance();
    await db.delete('schedules', where: 'id=?', whereArgs: [id]);
  }
}

class SettingsDao {
  Future<Map<String,dynamic>> getSettings() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('settings', where: 'id=1', limit: 1);
    return rows.isEmpty ? {'api_key':'', 'prompt':''} : rows.first;
  }

  Future<void> save({required String apiKey, required String prompt}) async {
    final db = await AppDatabase.instance();
    await db.update('settings', {'api_key': apiKey, 'prompt': prompt}, where: 'id=1');
  }
}
