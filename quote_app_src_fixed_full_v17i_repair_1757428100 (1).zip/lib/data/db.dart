
import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(
      path,
      version: 2,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE quotes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            author TEXT DEFAULT '',
            source TEXT DEFAULT '',
            created_at INTEGER NOT NULL,
            notified INTEGER DEFAULT 0,
            notify_count INTEGER DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE schedules(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            payload TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE settings(
            id INTEGER PRIMARY KEY CHECK (id=1),
            api_key TEXT DEFAULT '',
            prompt TEXT DEFAULT ''
          )
        ''');
        await db.insert('settings', {'id': 1, 'api_key': '', 'prompt': ''});
      },
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 2) {
          // ensure settings table exists
          await db.execute('''
            CREATE TABLE IF NOT EXISTS settings(
              id INTEGER PRIMARY KEY CHECK (id=1),
              api_key TEXT DEFAULT '',
              prompt TEXT DEFAULT ''
            )
          ''');
          final existing = await db.query('settings', limit: 1);
          if (existing.isEmpty) {
            await db.insert('settings', {'id': 1, 'api_key': '', 'prompt': ''});
          }
        }
      },
    );
    return _db!;
  }
}
