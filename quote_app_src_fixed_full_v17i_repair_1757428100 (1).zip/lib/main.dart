
import 'package:flutter/material.dart';
import 'data/dao.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/settings_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await QuoteDao().seedDefaultQuote();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _index = 0;
  final _pages = const [HomePage(), HistoryPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quote App',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: Scaffold(
        appBar: AppBar(title: const Text('Quote App')),
        body: _pages[_index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home), label: '首页'),
            NavigationDestination(icon: Icon(Icons.history), label: '历史'),
            NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
          ],
          onDestinationSelected: (i){ setState(()=> _index = i); },
        ),
        floatingActionButton: (_index==0) ? FloatingActionButton(
          onPressed: () async {
            await SchedulerService().tickOnce();
          },
          child: const Icon(Icons.refresh),
        ) : null,
      ),
    );
  }
}
