
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:convert';
import '../data/dao.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@android:drawable/sym_def_app_icon');
    const init = InitializationSettings(android: android);
    await _plugin.initialize(init);
    const channel = AndroidNotificationChannel(
      'quote_channel', 'Quote Updates',
      description: 'Notifications for new quotes',
      importance: Importance.max,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  static Future<void> showQuote(String text) async {
    final androidDetails = AndroidNotificationDetails(
      'quote_channel',
      'Quote Updates',
      channelDescription: 'Notifications for new quotes',
      importance: Importance.max,
      priority: Priority.high,
      styleInformation: BigTextStyleInformation(text, htmlFormatBigText: false),
      icon: '@android:drawable/sym_def_app_icon',
      category: AndroidNotificationCategory.message,
      showWhen: true,
    );
    final details = NotificationDetails(android: androidDetails);
    await _plugin.show(1, '新的名人名言', text, details);
  }
}

class NotificationOrchestrator {
  static Future<void> checkAndNotifyNewQuotes() async {
    final dao = QuoteDao();
    final quotes = await dao.fetchUnnotified();
    for (final q in quotes) {
      final text = (q['text'] ?? '') as String;
      if (text.isNotEmpty) {
        await NotificationService.showQuote(text);
      }
      await dao.markNotified(q['id'] as int);
    }
  }
}
