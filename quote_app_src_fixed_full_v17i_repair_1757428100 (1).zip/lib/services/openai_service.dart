
class OpenAIService {
  Future<String> fetchQuote(String prompt, {required String apiKey}) async {
    // Stub: return prompt to simulate
    return prompt.isEmpty ? 'To be, or not to be, that is the question.' : prompt;
  }
}
