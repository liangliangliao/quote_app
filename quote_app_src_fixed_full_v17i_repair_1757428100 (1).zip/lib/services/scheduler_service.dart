
import '../data/dao.dart';
import 'openai_service.dart';
import 'notification_service.dart';

class SchedulerService {
  final QuoteDao quoteDao = QuoteDao();

  Future<void> tickOnce() async {
    // Placeholder: in real app you'd evaluate schedules and call OpenAI.
    // Here we just seed default if needed.
    await quoteDao.seedDefaultQuote();
    await NotificationOrchestrator.checkAndNotifyNewQuotes();
  }
}
