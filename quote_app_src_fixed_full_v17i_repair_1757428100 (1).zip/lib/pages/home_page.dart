
import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../widgets/quote_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final QuoteDao _dao = QuoteDao();
  Map<String,dynamic>? _latest;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 15), (_)=> _refresh());
  }

  Future<void> _refresh() async {
    await _dao.seedDefaultQuote();
    final q = await _dao.latest();
    setState(()=> _latest = q);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_latest == null) {
      return const Center(child: Text('暂无数据！'));
    }
    return SingleChildScrollView(
      child: QuoteCard(
        text: (_latest!['text'] ?? '') as String,
        author: (_latest!['author'] ?? '') as String,
        source: (_latest!['source'] ?? '') as String,
      ),
    );
  }
}
