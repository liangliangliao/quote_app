
import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final QuoteDao _dao = QuoteDao();
  final _searchCtrl = TextEditingController();
  List<Map<String,dynamic>> _items = [];
  bool _loading = false;
  int _offset = 0;
  static const int _pageSize = 100;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load(true);
  }

  Future<void> _load(bool reset) async {
    if (_loading) return;
    setState(()=> _loading = true);
    if (reset) { _offset = 0; _items.clear(); }
    final rows = await _dao.list(limit: _pageSize, offset: _offset, query: _q);
    _items.addAll(rows);
    _offset += rows.length;
    setState(()=> _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: _searchCtrl,
            decoration: InputDecoration(
              labelText: '搜索',
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: (){ _q = _searchCtrl.text.trim(); _load(true); },
              ),
            ),
            onSubmitted: (_){ _q = _searchCtrl.text.trim(); _load(true); },
          ),
        ),
        Expanded(
          child: NotificationListener<ScrollNotification>(
            onNotification: (n) {
              if (n.metrics.pixels >= n.metrics.maxScrollExtent - 100 && !_loading) {
                _load(false);
              }
              return false;
            },
            child: ListView.builder(
              itemCount: _items.length,
              itemBuilder: (_, i){
                final it = _items[i];
                return ListTile(
                  title: Text((it['text'] ?? '') as String),
                  subtitle: Text('—— ${(it['author'] ?? '')}   ${(it['source'] ?? '')}'),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
