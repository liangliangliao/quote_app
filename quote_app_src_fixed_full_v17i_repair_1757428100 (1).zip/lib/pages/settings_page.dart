
import 'dart:convert';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/notification_service.dart' show NotificationOrchestrator;

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _settingsDao = SettingsDao();
  final _scheduleDao = ScheduleDao();

  final _apiKeyCtrl = TextEditingController();
  final _promptCtrl = TextEditingController();

  List<Map<String,dynamic>> _schedules = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await _settingsDao.getSettings();
    _apiKeyCtrl.text = (s['api_key'] ?? '') as String;
    _promptCtrl.text = (s['prompt'] ?? '') as String;
    _schedules = await _scheduleDao.all();
    if (mounted) setState((){});
    try { await NotificationOrchestrator.checkAndNotifyNewQuotes(); } catch (_) {}
  }

  Future<void> _saveAll() async {
    await _settingsDao.save(apiKey: _apiKeyCtrl.text.trim(), prompt: _promptCtrl.text.trim());
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

  // ---- schedule subtitle helpers ----
  String _weekdayName(int w) {
    const names = ['周一','周二','周三','周四','周五','周六','周日'];
    final idx = (w - 1).clamp(0, 6);
    return names[idx];
  }

  String _readableTime(Map<String, dynamic> s) {
    try {
      final type = (s['type'] as String?) ?? '';
      final raw = s['payload'];
      final Map<String, dynamic> payload =
          (raw is String) ? (jsonDecode(raw) as Map<String, dynamic>) :
          (raw is Map<String, dynamic>) ? raw :
          <String, dynamic>{};

      if (type == 'daily') {
        return '每天 ' + (payload['time'] ?? '');
      } else if (type == 'weekly') {
        final w = (payload['weekday'] ?? 1) as int;
        return '每周' + _weekdayName(w) + ' ' + (payload['time'] ?? '');
      } else if (type == 'monthly') {
        final d = (payload['day'] ?? '').toString();
        return '每月' + d + '日 ' + (payload['time'] ?? '');
      } else if (type == 'custom') {
        final d = (payload['date'] ?? '').toString();
        final t = (payload['time'] ?? '').toString();
        return (d + ' ' + t).trim();
      }
    } catch (_) {}
    return '';
  }

  Future<void> _openCreateTaskDialog() async { await _openTaskDialog(); }
  Future<void> _openEditTaskDialog(Map<String, dynamic> s) async { await _openTaskDialog(existing: s); }

  Future<void> _openTaskDialog({Map<String,dynamic>? existing}) async {
    String name = existing==null ? '' : ((existing['payload'] is Map) ? existing['payload']['name'] ?? '' : '');
    String prompt = existing==null ? '' : ((existing['payload'] is Map) ? existing['payload']['prompt'] ?? '' : '');
    String type = existing==null ? 'daily' : (existing['type'] as String? ?? 'daily');
    int weekday = (existing==null) ? 1 : (((existing['payload'] is Map) ? (existing['payload']['weekday'] ?? 1) : 1) as int);
    int monthday = (existing==null) ? 1 : (((existing['payload'] is Map) ? (existing['payload']['day'] ?? 1) : 1) as int);
    TimeOfDay time = TimeOfDay.now();

    final timeCtrl = TextEditingController();
    void syncTimeToCtrl(TimeOfDay t){ timeCtrl.text = t.format(context); }

    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setStateD) {
          return AlertDialog(
            title: Text(existing==null ? '新增任务' : '编辑任务'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    decoration: const InputDecoration(labelText: '名称'),
                    onChanged: (v)=> name=v,
                    controller: TextEditingController(text: name),
                  ),
                  TextField(
                    decoration: const InputDecoration(labelText: '提示词（最多100字）'),
                    maxLength: 100,
                    maxLines: 3,
                    onChanged: (v)=> prompt=v,
                    controller: TextEditingController(text: prompt),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: type,
                    items: const [
                      DropdownMenuItem(value: 'daily', child: Text('每天')),
                      DropdownMenuItem(value: 'weekly', child: Text('每周')),
                      DropdownMenuItem(value: 'monthly', child: Text('每月')),
                    ],
                    onChanged: (v){ setStateD(()=> type = v ?? 'daily'); },
                    decoration: const InputDecoration(labelText: '何时'),
                  ),
                  if (type=='weekly')
                    DropdownButtonFormField<int>(
                      value: weekday,
                      items: const [
                        DropdownMenuItem(value: 1, child: Text('周一')),
                        DropdownMenuItem(value: 2, child: Text('周二')),
                        DropdownMenuItem(value: 3, child: Text('周三')),
                        DropdownMenuItem(value: 4, child: Text('周四')),
                        DropdownMenuItem(value: 5, child: Text('周五')),
                        DropdownMenuItem(value: 6, child: Text('周六')),
                        DropdownMenuItem(value: 7, child: Text('周日')),
                      ],
                      onChanged: (v){ setStateD(()=> weekday = v ?? 1); },
                      decoration: const InputDecoration(labelText: '星期'),
                    ),
                  if (type=='monthly')
                    DropdownButtonFormField<int>(
                      value: monthday,
                      items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}日'))),
                      onChanged: (v){ setStateD(()=> monthday = v ?? 1); },
                      decoration: const InputDecoration(labelText: '日期'),
                    ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: timeCtrl,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: '时间',
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.access_time),
                        onPressed: () async {
                          final picked = await showTimePicker(context: ctx, initialTime: time);
                          if (picked != null) {
                            time = picked;
                            setStateD(()=> syncTimeToCtrl(time));
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              if (existing != null)
                TextButton(
                  onPressed: () async {
                    await _scheduleDao.setEnabled(existing['id'] as int, false);
                    Navigator.of(ctx).pop();
                    _schedules = await _scheduleDao.all();
                    if (mounted) setState((){});
                  },
                  child: const Text('暂停'),
                ),
              if (existing != null)
                TextButton(
                  onPressed: () async {
                    await _scheduleDao.deleteById(existing['id'] as int);
                    Navigator.of(ctx).pop();
                    _schedules = await _scheduleDao.all();
                    if (mounted) setState((){});
                  },
                  child: const Text('删除', style: TextStyle(color: Colors.red)),
                ),
              TextButton(onPressed: ()=> Navigator.of(ctx).pop(), child: const Text('取消')),
              FilledButton(
                onPressed: () async {
                  final payload = <String,dynamic>{'name': name, 'prompt': prompt};
                  final hh = time.hour.toString().padLeft(2,'0');
                  final mm = time.minute.toString().padLeft(2,'0');
                  final ss = '00';
                  if (type=='daily') {
                    payload['time'] = '$hh:$mm:$ss';
                  } else if (type=='weekly') {
                    payload['weekday'] = weekday;
                    payload['time'] = '$hh:$mm:$ss';
                  } else if (type=='monthly') {
                    payload['day'] = monthday;
                    payload['time'] = '$hh:$mm:$ss';
                  }
                  if (existing == null) {
                    await _scheduleDao.insert(type, payload);
                  } else {
                    await _scheduleDao.updateSchedule(existing['id'] as int, type: type, payload: payload);
                  }
                  Navigator.of(ctx).pop();
                  _schedules = await _scheduleDao.all();
                  if (mounted) setState((){});
                },
                child: const Text('保存'),
              ),
            ],
          );
        }
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        actions: [
          IconButton(onPressed: _saveAll, icon: const Icon(Icons.save)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _apiKeyCtrl,
            decoration: const InputDecoration(labelText: 'API Key'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _promptCtrl,
            decoration: const InputDecoration(labelText: '提示词（保存后用于自动获取）'),
            maxLines: 3,
            maxLength: 200,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Expanded(child: Text('已添加的任务', style: TextStyle(fontWeight: FontWeight.bold))),
              TextButton.icon(
                onPressed: () => _openCreateTaskDialog(),
                icon: const Icon(Icons.add_task),
                label: const Text('新增任务'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ..._schedules.map((s) {
            final id = s['id'] as int;
            final payload = (s['payload'] is Map) ? s['payload'] as Map<String,dynamic> : {};
            final name = (payload['name'] ?? '未命名').toString();
            return ListTile(
              dense: true,
              title: Text(name),
              subtitle: Text(_readableTime(s)),
              onTap: () => _openEditTaskDialog(s),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.pause_circle_outline),
                    onPressed: () async {
                      await _scheduleDao.setEnabled(id, false);
                      _schedules = await _scheduleDao.all();
                      if (mounted) setState((){});
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    onPressed: () async {
                      await _scheduleDao.deleteById(id);
                      _schedules = await _scheduleDao.all();
                      if (mounted) setState((){});
                    },
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}
