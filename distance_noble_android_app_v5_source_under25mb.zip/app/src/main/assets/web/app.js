
const KEY='distance_noble_game_save_v4';
const img = {
  city1:'images/city_skin_1.jpg', city2:'images/city_skin_2.jpg',
  characters1:'images/characters_1.jpg', characters2:'images/characters_2.jpg', characters3:'images/characters_3.jpg',
  buildings:'images/buildings_1.jpg', maps:'images/maps_1.jpg', ui:'images/ui_1.jpg', cover:'images/cover_1.jpg'
};
const portraits = {
  arion:'images/portrait_sheet1_4.jpg',
  mira:'images/portrait_sheet1_1.jpg',
  safer:'images/portrait_sheet1_3.jpg',
  edna:'images/portrait_sheet1_5.jpg',
  hollen:'images/portrait_sheet2_3.jpg',
  vian:'images/portrait_sheet2_4.jpg',
  rosa:'images/portrait_sheet2_2.jpg',
  beck:'images/portrait_sheet3_1.jpg',
  dorn:'images/portrait_sheet2_1.jpg',
  isabel:'images/portrait_sheet2_5.jpg'
};
const baseState = {
  day:3, cityName:'灰崖', cityLevel:1, chapter:1,
  resources:{gold:5760, wood:920, stone:692, iron:472, mirror:160, honor:80, publicWill:110},
  civilization:{distance:40,honor:53,resentment:26,vanity:34,equality:38,creativity:36,obedience:42,reverence:29},
  laws:[
    {id:'law1',name:'誓约公开制',family:'荣誉',status:'已启用',cost:0,effect:'荣誉 +3，距离 +1，群众支持更稳定'},
    {id:'law2',name:'节庆豁免令',family:'镜厅',status:'可启用',cost:40,effect:'镜币收益提高，但虚荣 +4'},
    {id:'law3',name:'静室优先权',family:'敬意',status:'可启用',cost:36,effect:'敬意 +4，虚荣 -2'},
    {id:'law4',name:'公共学舍扩建',family:'平等',status:'可启用',cost:32,effect:'平等 +4，服从度 +1'}],
  buildings:[
    {id:'council',name:'议政厅',level:1,max:3,type:'政务',effects:['主线推进','城市等级上限'],civ:{distance:1,honor:1},income:{gold:80}},
    {id:'market',name:'市场',level:1,max:3,type:'经济',effects:['金币产出','贸易活性'],civ:{vanity:1,equality:1},income:{gold:240}},
    {id:'barracks',name:'兵营',level:1,max:3,type:'军事',effects:['训练战斗单位','提升战斗准备度'],civ:{obedience:2,honor:1},income:{}},
    {id:'academy',name:'贵族学院',level:0,max:3,type:'教育',effects:['培养高贵系角色','距离与荣誉提升'],civ:{distance:3,honor:2,resentment:1},income:{}},
    {id:'civicSchool',name:'市民学校',level:1,max:3,type:'教育',effects:['平等与稳定提升','公共教育'],civ:{equality:3,obedience:1,creativity:-1},income:{}},
    {id:'mirrorHall',name:'镜厅',level:0,max:3,type:'社交',effects:['节庆与声望核心','提高虚荣'],civ:{vanity:3},income:{mirror:12}},
    {id:'quietRoom',name:'静室',level:1,max:3,type:'敬意',effects:['降低虚荣','提高敬意'],civ:{reverence:3,vanity:-1},income:{}},
    {id:'archive',name:'档案塔',level:1,max:3,type:'研究',effects:['记录事件','帮助理解文明'],civ:{creativity:1,reverence:1},income:{}}
  ],
  quiet:{
    level:1, reverenceValue:29, seats:[
      {id:'seat1', charId:'edna', remaining:2, effect:'虚荣下降 / 敬意提升'},
      {id:'seat2', charId:null, remaining:0, effect:'空坐席'}
    ],
    trials:[
      {id:'trial1', name:'后退一步', desc:'不立刻命名眼前的稀有之物。', rewards:'敬意 +5 / 荣誉印 +8'},
      {id:'trial2', name:'不消费', desc:'忍住把一切立刻变成工具的冲动。', rewards:'敬意 +6 / 镜币 +10'}
    ]
  },
  shop:[
    {id:'pack1',name:'边境补给包',price:'¥6',items:'金币 1000 / 木材 200 / 石材 150'},
    {id:'pack2',name:'荣誉月卡',price:'¥30',items:'每日金币 / 荣誉印 / 镜币'},
    {id:'pack3',name:'静室礼盒',price:'¥18',items:'敬意材料 / 荣誉印 / 试炼券'}
  ],
  characters:[
    {id:'arion',name:'阿列翁·维尔卡',rarity:'卓越',role:'统帅',faction:'高贵',level:12,power:640,hp:125,atk:34,status:'适配当前文明',route:'誓约统帅',equipment:['steel','banner'],personality:{self:80,vanity:10,reverence:58,honor:82,resentment:8,attachment:14}},
    {id:'mira',name:'米拉·镜厅',rarity:'稀有',role:'演说家',faction:'镜厅',level:10,power:510,hp:98,atk:28,status:'正在向虚荣偏移',route:'舞台女王（倾向）',equipment:['gem'],personality:{self:34,vanity:82,reverence:12,honor:26,resentment:22,attachment:72}},
    {id:'safer',name:'赛弗·灰衣',rarity:'卓越',role:'传教者',faction:'怨恨',level:11,power:560,hp:110,atk:31,status:'对高距离文明非常敏感',route:'怨恨先知（倾向）',equipment:['book'],personality:{self:45,vanity:20,reverence:8,honor:12,resentment:84,attachment:36}},
    {id:'edna',name:'埃德娜·静室',rarity:'命运',role:'守护者',faction:'敬意',level:9,power:485,hp:105,atk:22,status:'适配静室与高敬意环境',route:'守护稀有者',equipment:['quietseal'],personality:{self:72,vanity:6,reverence:90,honor:55,resentment:4,attachment:18}},
    {id:'hollen',name:'霍伦·档案师',rarity:'优异',role:'学者',faction:'学者',level:8,power:430,hp:92,atk:20,status:'研究效率高',route:'冷档案师',equipment:['book'],personality:{self:42,vanity:14,reverence:44,honor:28,resentment:10,attachment:20}},
    {id:'vian',name:'维安·无名天才',rarity:'命运',role:'未定型',faction:'命运',level:7,power:400,hp:88,atk:30,status:'正在形成分支',route:'未定',equipment:['gem'],personality:{self:48,vanity:28,reverence:20,honor:22,resentment:30,attachment:24}},
    {id:'rosa',name:'罗莎·公社书记',rarity:'优异',role:'治理者',faction:'平等',level:8,power:420,hp:102,atk:19,status:'更适合稳定环境',route:'群体守护人',equipment:['seal'],personality:{self:38,vanity:12,reverence:24,honor:30,resentment:18,attachment:56}}
  ],
  equipmentDefs:{steel:{name:'钢剑',power:18,desc:'提高直接战斗输出。'},banner:{name:'誓约军旗',power:24,desc:'提高领袖与荣誉加成。'},gem:{name:'镜厅宝石',power:14,desc:'提高镜币与演说加成。'},book:{name:'灰档案册',power:12,desc:'提高研究与洞察。'},quietseal:{name:'静室印记',power:16,desc:'提高敬意与静修收益。'},seal:{name:'公社封印章',power:10,desc:'提高平等与稳定加成。'}},
  team:['arion','mira','edna','vian','rosa'],
  storyEvents:[
    {id:'e1',chapter:1,title:'边境议事',text:'灰崖的第一场争论不是粮食够不够，而是谁有资格发号施令。',done:false,options:[{text:'强调誓约与责任',civ:{honor:4,distance:2},history:'你把“资格”重新和责任绑定。'},{text:'强调人人发声',civ:{equality:4,obedience:1},history:'你让“发声权”变成公共秩序的起点。'}]},
    {id:'e2',chapter:2,title:'掌声与沉默',text:'米拉在掌声中开始发亮，但你也意识到掌声会反过来塑造她。',done:false,options:[{text:'安排公开节庆',civ:{vanity:5,publicWill:0},history:'灰崖比以前更会享受被看见。'},{text:'让她进入静室短修',civ:{reverence:4,vanity:-2},history:'你第一次主动阻止了一种空心化。'}]},
    {id:'e3',chapter:3,title:'危险的人',text:'维安做出了超出常规的举动，城里开始争论：他究竟是危险，还是稀有。',done:false,options:[{text:'将其定义为危险',civ:{resentment:5,obedience:2},history:'城市学会了更快地命名异常。'},{text:'暂缓命名，进入观察',civ:{reverence:5,distance:2},history:'你为“先不消费”保留了一点空间。'}]}
  ],
  recruitPool:[
    {id:'beck',name:'贝伦·安睡官',rarity:'命运',faction:'中等人',cost:120,desc:'中等人时代的制度设计者。'},
    {id:'dorn',name:'多恩·誓庭',rarity:'稀有',faction:'高贵',cost:60,desc:'高贵阵营前排守护者。'},
    {id:'isabel',name:'伊莎贝·冷玺',rarity:'卓越',faction:'高贵',cost:90,desc:'用冷礼法压制喧闹与失序。'}
  ],
  missions:[
    {id:'m1',chapter:1,name:'立足之地',desc:'将议政厅升到2级，并完成一次边境战斗。',progress:0,target:2,status:'进行中',reward:{gold:800,honor:12}},
    {id:'m2',chapter:2,name:'掌声与沉默',desc:'将镜厅或静室提升到1级，并做出关于掌声的选择。',progress:0,target:1,status:'未开启',reward:{mirror:30,publicWill:20}},
    {id:'m3',chapter:3,name:'谁是危险的人（事件链）',desc:'完成一次维安异常事件。',progress:0,target:1,status:'未开启',reward:{gold:1200,honor:15}},
    {id:'m4',chapter:4,name:'中等人的时代',desc:'当前版本预留章节。',progress:0,target:1,status:'未开启',reward:{gold:1500,publicWill:30}},
    {id:'m5',chapter:5,name:'血与回声',desc:'当前版本预留章节。',progress:0,target:1,status:'未开启',reward:{gold:1800,honor:20}},
    {id:'m6',chapter:6,name:'门后的高者',desc:'当前版本预留章节。',progress:0,target:1,status:'未开启',reward:{gold:2200,honor:30}}
  ],
  history:[
    {day:1,title:'继任灰崖',text:'你在众人彼此不完全信任的情况下接管了灰崖。'},
    {day:2,title:'第一次城市选择',text:'你发现这座城市真正争夺的不是粮食，而是谁应该被推到高处。'}
  ],
  battle:{enemyName:'边境袭扰者',enemyHP:320,enemyMaxHP:320,playerHP:380,playerMaxHP:380,round:1,support:50,chaos:20,logs:['战斗尚未开始。'],active:false,stars:0}
};
function clone(o){ return JSON.parse(JSON.stringify(o)); }
function load(){ try{ const raw=localStorage.getItem(KEY); return raw?Object.assign(clone(baseState), JSON.parse(raw)):clone(baseState);}catch(e){return clone(baseState);} }
let state = load();
function save(){ localStorage.setItem(KEY, JSON.stringify(state)); }
const cn = k => ({distance:'距离',honor:'荣誉',resentment:'怨恨',vanity:'虚荣',equality:'平等',creativity:'创造力',obedience:'服从度',reverence:'敬意'})[k];
const desc = k => ({distance:'高时更易诞生稀有者，也更易积累怨恨。',honor:'高时同等者之间的责任、誓约与威信更强。',resentment:'高时弱者更倾向把强者命名为危险。',vanity:'高时掌声与被看见会塑造人格与资源。',equality:'高时秩序更稳，但高峰更难长出。',creativity:'高时天才与怪胎都会更多。',obedience:'高时城市更高效，但个体更难偏离。',reverence:'高时更懂得后退一步，不立刻消费稀有之物。'})[k];
function mood(){ const c=state.civilization, t=[]; if(c.honor>=50)t.push('以荣誉维系的城邦'); if(c.distance>=50)t.push('偏高贵'); if(c.vanity>=50)t.push('掌声繁荣'); if(c.reverence>=50)t.push('敬意上升'); if(c.equality>=50)t.push('趋向平均'); if(!t.length)t.push('正在形成方向'); return t; }
function resourceBar(){ const names={gold:'金币',wood:'木材',stone:'石材',iron:'铁矿',mirror:'镜币',honor:'荣誉印',publicWill:'民意票'}; return Object.entries(names).map(([k,v]) => `<div class="res"><div class="k">${v}</div><div class="v">${(state.resources[k]||0).toLocaleString('zh-CN')}</div></div>`).join(''); }
function getChar(id){ return state.characters.find(c=>c.id===id); }
function teamPower(){ return state.team.reduce((sum,id)=>sum + (getChar(id)?.power || 0), 0); }
function addHistory(title,text){ state.history.unshift({day:state.day,title,text}); state.history = state.history.slice(0,80); }
function civChange(ch){ Object.entries(ch).forEach(([k,v])=>{ if(k in state.resources){ state.resources[k]+=v; return; } if(state.civilization[k]!=null) state.civilization[k]=Math.max(0,Math.min(100,state.civilization[k]+v)); }); }
function openModal(inner){ document.getElementById('modalRoot').innerHTML = `<div class="modal-wrap" onclick="closeModal(event)"><div class="modal" onclick="event.stopPropagation()">${inner}</div></div>`; }
function closeModal(e){ if(e && e.target && !e.target.classList.contains('modal-wrap')) return; document.getElementById('modalRoot').innerHTML=''; }
window.closeModal = closeModal;
function toast(msg){ openModal(`<button class="close" onclick="closeModal()">×</button><h3>提示</h3><p>${msg}</p>`); }
function nextDay(){ state.day += 1; let goldGain = 0, mirrorGain = 0; state.buildings.forEach(b=>{ goldGain += (b.income.gold||0) * Math.max(1,b.level); mirrorGain += (b.income.mirror||0) * Math.max(1,b.level); }); state.resources.gold += goldGain; state.resources.wood += 60; state.resources.stone += 46; state.resources.iron += 32; state.resources.mirror += mirrorGain; state.quiet.seats.forEach(s=>{ if(s.charId && s.remaining>0) s.remaining -= 1; }); addHistory('进入新的一日', `城市运转了一天，获得 ${goldGain} 金币与 ${mirrorGain} 镜币。`); updateMissionProgress(); save(); rerender(); }
function upgradeBuilding(id){ const b = state.buildings.find(x=>x.id===id); if(!b || b.level >= b.max) return; const cost = 260 + b.level * 240; if(state.resources.gold < cost){ toast('金币不足。'); return; } state.resources.gold -= cost; b.level += 1; civChange(b.civ || {}); if(id === 'council' && b.level >= 2){ state.cityLevel = 2; state.missions[0].progress = Math.min(2, state.missions[0].progress + 1); } if(['mirrorHall','quietRoom'].includes(id)){ state.missions[1].status = '进行中'; } addHistory('建筑升级', `${b.name} 升至 ${b.level} 级。`); save(); rerender(); }
function trainChar(id){ const c=getChar(id); const cost = 220 + c.level * 25; if(state.resources.gold < cost){ toast('金币不足。'); return; } state.resources.gold -= cost; c.level += 1; c.power += 35; c.hp += 8; c.atk += 3; if(c.id==='mira') c.personality.vanity = Math.min(100, c.personality.vanity + 1); if(c.id==='edna') c.personality.reverence = Math.min(100, c.personality.reverence + 2); if(c.id==='vian') c.status = '正在形成更强烈的分支'; addHistory('角色成长', `${c.name} 升至 ${c.level} 级。`); save(); rerender(); }
function addToTeam(id){ if(state.team.includes(id)){ toast('该角色已经在队伍中。'); return; } if(state.team.length < 5) state.team.push(id); else state.team[4] = id; save(); rerender(); }
function replaceTeam(index, id){ state.team[index] = id; save(); rerender(); }
function cityChoice(type){ closeModal(); if(type==='festival'){ state.resources.mirror += 40; state.resources.publicWill += 20; civChange({vanity:5,equality:1}); addHistory('节庆之夜', '灰崖被灯火与掌声照亮，但也更依赖被看见。'); } else if(type==='reverence'){ civChange({reverence:6, vanity:-2}); addHistory('静室修整', '你让这座城市在安静中恢复力量。'); } else { civChange({distance:5,honor:4,resentment:2}); addHistory('贵族训练', '你把资源投入到少数人的严格训练中。'); } state.missions[1].progress = 1; updateMissionProgress(); save(); rerender(); }
window.cityChoice = cityChoice;
function buildingDetail(id){ const b = state.buildings.find(x=>x.id===id); openModal(`<button class="close" onclick="closeModal()">×</button><h2 class="title">${b.name}</h2><p class="sub">${b.type} ｜ 等级 ${b.level}/${b.max}</p><img class="hero-banner" src="${img.buildings}" alt=""><div class="grid g2"><div class="card"><h3>建筑效果</h3><ul>${b.effects.map(x=>`<li>${x}</li>`).join('')}</ul></div><div class="card"><h3>文明影响</h3><ul>${Object.entries(b.civ||{}).map(([k,v])=>`<li>${cn(k)} ${v>0?'+':''}${v}</li>`).join('')}</ul><button class="primary" onclick="closeModal(); upgradeBuilding('${b.id}')" ${b.level>=b.max?'disabled':''}>升级建筑</button></div></div>`); }
function characterDetail(id){ const c = getChar(id), p=c.personality, equips=(c.equipment||[]).map(e=>state.equipmentDefs[e]?.name || e).join('、') || '无'; openModal(`<button class="close" onclick="closeModal()">×</button><h2 class="title">${c.name}</h2><p class="sub">${c.rarity} ｜ ${c.role} ｜ ${c.faction} ｜ 等级 ${c.level} ｜ 战力 ${c.power}</p><img class="hero-banner" src="${portraits[c.id] || img.characters1}" alt=""><div class="grid g2"><div class="card"><h3>基础属性</h3><ul><li>生命：${c.hp}</li><li>攻击：${c.atk}</li><li>路线：${c.route}</li><li>状态：${c.status}</li><li>装备：${equips}</li></ul></div><div class="card"><h3>人格状态</h3>${[['自我定值',p.self],['虚荣',p.vanity],['敬意',p.reverence],['荣誉感',p.honor],['怨恨',p.resentment],['依附性',p.attachment]].map(([k,v])=>`<div style="margin-bottom:10px"><div class="row" style="justify-content:space-between"><span>${k}</span><span>${v}</span></div><div class="meter"><span style="width:${v}%"></span></div></div>`).join('')}</div></div><div class="row"><button class="primary" onclick="closeModal(); trainChar('${c.id}')">培养角色</button><button class="secondary" onclick="closeModal(); addToTeam('${c.id}')">加入队伍</button></div>`); }
function applyLaw(id){ const law = state.laws.find(x=>x.id===id); if(!law || law.status==='已启用') return; if(state.resources.honor < law.cost){ toast('荣誉印不足。'); return; } state.resources.honor -= law.cost; state.laws.forEach(x => { if(x.family === law.family && x.status === '已启用') x.status = '可启用'; }); law.status = '已启用'; if(id==='law1') civChange({honor:3,distance:1}); if(id==='law2') civChange({vanity:4}); if(id==='law3') civChange({reverence:4,vanity:-2}); if(id==='law4') civChange({equality:4,obedience:1}); addHistory('法令启用', `${law.name} 开始生效。`); save(); rerender(); }
function assignQuietSeat(seatId, charId){ const seat = state.quiet.seats.find(s=>s.id===seatId); if(!seat) return; seat.charId = charId; seat.remaining = 2; addHistory('静室安排', `${getChar(charId).name} 被安排进入静室。`); save(); rerender(); }
function quietAction(action){ if(action==='collect'){ state.resources.honor += 8; civChange({reverence:3, vanity:-1}); addHistory('静室收获', '静室带来的平静开始改变城市。'); } else { state.resources.honor += 10; civChange({reverence:5, honor:1}); addHistory('敬意试炼', '你完成了一次关于“后退一步”的试炼。'); } save(); rerender(); }
function buyItem(id){ const item = state.shop.find(x=>x.id===id); openModal(`<button class="close" onclick="closeModal()">×</button><h3>商品说明</h3><p>当前工程仍是单机离线版本，未接入真实支付，也不应伪装成真实内购。</p><p><strong>${item.name}</strong></p><p>${item.items}</p>`); }
function recruit(id, cost){ if(state.resources.mirror < cost){ toast('镜币不足。'); return; } state.resources.mirror -= cost; const pool = { beck:{name:'贝伦·安睡官',rarity:'命运',role:'治理者',faction:'中等人',level:7,power:420,hp:96,atk:20,status:'更适合中等人时代',route:'安稳治理者',equipment:['seal'],personality:{self:55,vanity:9,reverence:18,honor:32,resentment:12,attachment:42}}, dorn:{name:'多恩·誓庭',rarity:'稀有',role:'护卫',faction:'高贵',level:8,power:445,hp:118,atk:24,status:'适合高荣誉阵容',route:'誓庭卫者',equipment:['steel'],personality:{self:60,vanity:8,reverence:35,honor:68,resentment:9,attachment:26}}, isabel:{name:'伊莎贝·冷玺',rarity:'卓越',role:'礼法压制',faction:'高贵',level:9,power:480,hp:102,atk:29,status:'擅长压制喧闹与失礼',route:'冷礼法官',equipment:['steel'],personality:{self:76,vanity:6,reverence:44,honor:72,resentment:10,attachment:12}} }; if(state.characters.some(c=>c.id===id)){ state.resources.honor += 8; toast('重复角色已转化为荣誉印。'); } else { state.characters.push({id, ...pool[id]}); addHistory('招募新角色', `${pool[id].name} 加入了灰崖。`); } save(); rerender(); }
function updateMissionProgress(){ const council = state.buildings.find(b=>b.id==='council'); if(council.level >= 2 && state.battle.enemyHP <= 0){ state.missions[0].progress = 2; state.missions[0].status = '可领取'; if(state.missions[1].status === '未开启') state.missions[1].status = '进行中'; } const mirror = state.buildings.find(b=>b.id==='mirrorHall').level; const quiet = state.buildings.find(b=>b.id==='quietRoom').level; if((mirror >= 1 || quiet >= 1) && state.missions[1].status !== '未开启'){ state.missions[1].progress = 1; state.missions[1].status = '可领取'; if(state.missions[2].status === '未开启') state.missions[2].status = '进行中'; } }
function claimMission(id){ const m = state.missions.find(x=>x.id===id); if(!m || m.status !== '可领取') return; Object.entries(m.reward).forEach(([k,v])=>{ if(state.resources[k]!=null) state.resources[k]+=v; }); m.status = '已完成'; if(id==='m1') { state.chapter = 2; addHistory('主线推进', '灰崖在第一次边境冲突后开始真正长出方向。'); } if(id==='m2') { state.chapter = 3; addHistory('主线推进', '你第一次切身感到：掌声会改变一个人。'); } save(); rerender(); }
function chooseStory(id, idx){ const event = state.storyEvents.find(e=>e.id===id); if(!event || event.done) return; const opt = event.options[idx]; civChange(opt.civ || {}); event.done = true; addHistory(event.title, opt.history); if(id==='e2'){ state.missions[1].progress = 1; updateMissionProgress(); } if(id==='e3'){ state.missions[2].progress = 1; state.missions[2].status = '可领取'; } save(); rerender(); }
function startBattle(){ const baseEnemy = 320 + (state.chapter - 1) * 90; const basePlayer = 360 + Math.floor(teamPower()/12); state.battle = {enemyName:'边境袭扰者',enemyHP:baseEnemy,enemyMaxHP:baseEnemy,playerHP:basePlayer,playerMaxHP:basePlayer,round:1,support:50 + Math.floor(state.civilization.honor / 4),chaos:20 + Math.floor(state.civilization.resentment / 5),logs:['战斗开始。敌人正试图撕开灰崖边境。'],active:true,stars:0}; save(); renderBattle(); }
function battleAction(type){ if(!state.battle.active) return; const b = state.battle; const roster = state.team.map(id=>getChar(id)).filter(Boolean); const eqBonus = roster.reduce((sum,c)=>sum + (c.equipment||[]).reduce((s,e)=>s+(state.equipmentDefs[e]?.power||0),0), 0); const teamAtk = roster.reduce((sum,c)=>sum + c.atk + Math.floor(c.level/2), 0); let dmg = 0; if(type==='attack'){ dmg = teamAtk + Math.floor(eqBonus/8); b.logs.unshift('你下达了正面攻击命令。'); b.support += 1; } else if(type==='command'){ dmg = Math.floor(teamAtk*0.75) + Math.floor(state.civilization.honor/3); b.support += 6; b.chaos = Math.max(0, b.chaos - 2); b.logs.unshift('你下达了整队指挥，队伍更有秩序。'); } else if(type==='reverence'){ dmg = Math.floor(teamAtk*0.55) + Math.floor(state.civilization.reverence/3); b.support += 3; b.chaos = Math.max(0, b.chaos - 6); b.logs.unshift('你选择克制推进，以敬意稳定局面。'); } b.enemyHP -= dmg; b.logs.unshift(`本回合对敌方造成 ${dmg} 点伤害。`); if(b.enemyHP <= 0){ b.enemyHP = 0; b.active = false; b.stars = (b.playerHP > b.playerMaxHP * 0.8 ? 3 : (b.playerHP > b.playerMaxHP * 0.45 ? 2 : 1)); b.logs.unshift(`战斗胜利，获得 ${b.stars} 星评价。`); state.resources.gold += 700 + b.stars * 120; state.resources.honor += 18 + b.stars * 4; state.resources.publicWill += 8 + b.stars * 2; civChange({honor:2, distance:1}); state.missions[0].progress = Math.min(2, state.missions[0].progress + 1); updateMissionProgress(); addHistory('边境胜利', '你在边境稳住了灰崖的局势。'); save(); renderBattle(); return; } const enemyHit = 22 + b.round * 5 + Math.floor(b.chaos/10); b.playerHP -= enemyHit; b.logs.unshift(`敌军反击，灰崖承受 ${enemyHit} 点压力。`); b.support = Math.max(0, b.support - 3); b.chaos = Math.min(100, b.chaos + 4); b.round += 1; if(b.playerHP <= 0){ b.playerHP = 0; b.active = false; b.stars = 0; b.logs.unshift('灰崖在这场战斗中失利。'); } save(); renderBattle(); }
function exportSave(){ document.getElementById('saveExport').value = JSON.stringify(state); }
function importSave(){ try{ const txt = document.getElementById('saveImport').value.trim(); if(!txt){ toast('请先粘贴存档文本。'); return; } state = Object.assign(clone(baseState), JSON.parse(txt)); save(); rerender(); toast('存档导入成功。'); }catch(e){ toast('存档格式错误。'); } }
function renderCity(){ document.getElementById('screen-city').innerHTML = `<div class="grid g2"><div class="card"><div class="section-head"><div><h2 class="title">${state.cityName} · 主城总览</h2><p class="sub">第 ${state.day} 日 ｜ 主城等级 ${state.cityLevel} ｜ 当前章节 ${state.chapter}</p></div><div class="hero-tags">${mood().map(x=>`<span class="pill">${x}</span>`).join('')}</div></div><img class="hero-banner" src="${img.city1}" alt=""><div class="row" style="margin-bottom:12px"><button class="primary" id="nextDayBtn">进入下一日</button><button class="secondary" id="choiceBtn">做一次城市选择</button><button class="secondary" id="gotoStory">打开剧情事件</button><button class="danger" id="resetBtn">重置存档</button></div><div class="grid g4">${state.buildings.map(b=>`<div class="tile"><h3>${b.name}</h3><div class="small">类型：${b.type} ｜ 等级 ${b.level}/${b.max}</div><p class="small">${b.effects.join('；')}</p><div class="row"><button class="primary" data-up="${b.id}" ${b.level>=b.max?'disabled':''}>升级</button><button class="secondary" data-view="${b.id}">详情</button></div></div>`).join('')}</div></div><div class="grid"><div class="card"><h2 class="title">文明状态</h2><div class="list">${Object.entries(state.civilization).map(([k,v])=>`<div class="metric"><div class="row" style="justify-content:space-between"><strong>${cn(k)}</strong><span>${v}</span></div><div class="meter" style="margin-top:8px"><span style="width:${v}%"></span></div><div class="small" style="margin-top:8px">${desc(k)}</div></div>`).join('')}</div></div><div class="card"><h2 class="title">当前主线</h2><p class="sub">${(state.missions.find(x=>x.status==='进行中')||state.missions[0]).name}</p><p>${(state.missions.find(x=>x.status==='进行中')||state.missions[0]).desc}</p></div></div></div>`; document.getElementById('nextDayBtn').onclick = nextDay; document.getElementById('choiceBtn').onclick = ()=>openModal(`<button class="close" onclick="closeModal()">×</button><h2 class="title">城市选择</h2><div class="grid"><div class="card"><h3>公开节庆</h3><p class="small">获得镜币与群众支持，但虚荣上升。</p><button class="primary" onclick="cityChoice('festival')">选择</button></div><div class="card"><h3>静室修整</h3><p class="small">提升敬意，压低虚荣。</p><button class="primary" onclick="cityChoice('reverence')">选择</button></div><div class="card"><h3>贵族训练</h3><p class="small">提升距离与荣誉，但怨恨累积。</p><button class="primary" onclick="cityChoice('noble')">选择</button></div></div>`); document.getElementById('gotoStory').onclick = ()=>switchScreen('story'); document.getElementById('resetBtn').onclick = ()=>{ localStorage.removeItem(KEY); state = clone(baseState); rerender(); }; document.querySelectorAll('[data-up]').forEach(b=>b.onclick=()=>upgradeBuilding(b.dataset.up)); document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>buildingDetail(b.dataset.view)); }
function renderCharacters(){
  document.getElementById('screen-characters').innerHTML = `
    <div class="card">
      <div class="section-head"><div><h2 class="title">角色总览</h2><p class="sub">现在每个核心角色都接入了独立单角画像。</p></div></div>
      <div class="grid g3">${state.characters.map(c=>`
        <div class="char">
          <div class="char-head">
            <img class="char-portrait" src="${portraits[c.id] || img.characters2}" alt="">
            <div>
              <h3 style="margin:0 0 6px">${c.name}</h3>
              <div class="small">${c.rarity} ｜ ${c.role} ｜ ${c.faction}</div>
              <div class="small" style="margin-top:6px">等级 ${c.level} ｜ 战力 ${c.power}</div>
              <div class="small" style="margin-top:6px">${c.status}</div>
              <div class="row" style="margin-top:10px">
                <button class="primary" data-char="${c.id}">详情</button>
                <button class="secondary" data-train="${c.id}">培养</button>
              </div>
            </div>
          </div>
        </div>`).join('')}
      </div>
    </div>`;
  document.querySelectorAll('[data-char]').forEach(b=>b.onclick=()=>characterDetail(b.dataset.char));
  document.querySelectorAll('[data-train]').forEach(b=>b.onclick=()=>trainChar(b.dataset.train));
}
function renderSquad(){ document.getElementById('screen-squad').innerHTML = `<div class="grid g2"><div class="card"><h2 class="title">当前编队</h2><p class="sub">总战力 ${teamPower()}</p>${state.team.map((id, idx)=>{ const c=getChar(id); return `<div class="tile"><div class="row" style="justify-content:space-between"><div><strong>位置 ${idx+1}：${c.name}</strong><div class="small">${c.role} ｜ ${c.faction} ｜ 战力 ${c.power}</div></div><button class="secondary" data-slot="${idx}">更换</button></div></div>`; }).join('')}</div><div class="card"><h2 class="title">装备加成</h2><div class="grid">${state.team.map(id=>{ const c=getChar(id); return `<div class="equip"><strong>${c.name}</strong><div class="small">${(c.equipment||[]).map(e=>state.equipmentDefs[e]?.name || e).join('、') || '无装备'}</div><div class="small">装备加成：${(c.equipment||[]).reduce((s,e)=>s+(state.equipmentDefs[e]?.power||0),0)}</div></div>`; }).join('')}</div></div></div>`; document.querySelectorAll('[data-slot]').forEach(b=>b.onclick=()=>{ const idx = Number(b.dataset.slot); openModal(`<button class="close" onclick="closeModal()">×</button><h2 class="title">更换队伍位置 ${idx+1}</h2><div class="grid">${state.characters.map(c=>`<div class="char"><strong>${c.name}</strong><div class="small">${c.role} ｜ 战力 ${c.power}</div><button class="primary" onclick="closeModal(); replaceTeam(${idx}, '${c.id}')">替换为此角色</button></div>`).join('')}</div>`); }); }
function renderCivilization(){ document.getElementById('screen-civilization').innerHTML = `<div class="grid g2"><div class="card"><h2 class="title">文明指标</h2><p class="sub">${mood().join(' / ')}</p>${Object.entries(state.civilization).map(([k,v])=>`<div class="metric" style="margin-bottom:10px"><div class="row" style="justify-content:space-between"><strong>${cn(k)}</strong><span>${v}</span></div><div class="meter" style="margin-top:8px"><span style="width:${v}%"></span></div><div class="small" style="margin-top:6px">${desc(k)}</div></div>`).join('')}</div><div class="grid"><div class="card"><img class="hero-banner" src="${img.city2}" alt=""><h2 class="title">文明总评</h2><ul><li>继续提升 <strong>镜厅</strong>，虚荣会更明显上升。</li><li>继续强化 <strong>静室</strong>，高端角色更不容易空心化。</li><li>提高 <strong>平等</strong> 会带来稳定，但压低高峰。</li></ul></div></div></div>`; }
function renderLaws(){ document.getElementById('screen-laws').innerHTML = `<div class="card"><div class="section-head"><div><h2 class="title">文明法令</h2><p class="sub">同一座城市，不同法令会让它奖励不同的人。</p></div><span class="pill">当前荣誉印：${state.resources.honor}</span></div><div class="grid g2">${state.laws.map(l=>`<div class="law"><h3>${l.name}</h3><div class="small">法令系：${l.family} ｜ 状态：${l.status}</div><p class="small">${l.effect}</p><button class="primary" data-law="${l.id}" ${l.status==='已启用'?'disabled':''}>${l.status==='已启用'?'已启用':`消耗 ${l.cost} 荣誉印启用`}</button></div>`).join('')}</div></div>`; document.querySelectorAll('[data-law]').forEach(b=>b.onclick=()=>applyLaw(b.dataset.law)); }
function renderQuiet(){ document.getElementById('screen-quiet').innerHTML = `<div class="grid g2"><div class="card"><h2 class="title">静室</h2><p class="sub">在这里，玩家学会后退一步，不急着命名和消费稀有之物。</p><img class="hero-banner" src="${img.cover}" alt=""><div class="grid">${state.quiet.seats.map(s=>`<div class="quiet-slot"><h3>${s.id === 'seat1' ? '静修位一' : '静修位二'}</h3><div class="small">当前角色：${s.charId ? getChar(s.charId).name : '空'}</div><div class="small">效果：${s.effect}</div><div class="small">剩余天数：${s.remaining}</div><button class="secondary" data-seat="${s.id}">${s.charId?'更换角色':'安排角色'}</button></div>`).join('')}</div></div><div class="grid"><div class="card"><h2 class="title">静修收益</h2><ul><li>敬意：${state.quiet.reverenceValue}</li><li>当前效果：降低虚荣，提高自我定值</li></ul><div class="row"><button class="primary" id="quietCollect">收取静修收益</button><button class="secondary" id="quietTrial">开始试炼</button></div></div><div class="card"><h2 class="title">试炼</h2>${state.quiet.trials.map(t=>`<div class="quiet-slot"><h3>${t.name}</h3><div class="small">${t.desc}</div><div class="small">${t.rewards}</div></div>`).join('')}</div></div></div>`; document.getElementById('quietCollect').onclick = ()=>quietAction('collect'); document.getElementById('quietTrial').onclick = ()=>quietAction('trial'); document.querySelectorAll('[data-seat]').forEach(b=>b.onclick=()=>{ const seatId = b.dataset.seat; openModal(`<button class="close" onclick="closeModal()">×</button><h2 class="title">安排静修角色</h2><div class="grid">${state.characters.map(c=>`<div class="char"><strong>${c.name}</strong><div class="small">${c.role} ｜ ${c.faction}</div><button class="primary" onclick="closeModal(); assignQuietSeat('${seatId}', '${c.id}')">安排入静室</button></div>`).join('')}</div>`); }); }
function renderStory(){ document.getElementById('screen-story').innerHTML = `<div class="card"><h2 class="title">剧情事件</h2><p class="sub">这里把前面设计的价值冲突，用可执行事件的方式落到单机版里。</p><img class="hero-banner" src="${img.maps}" alt=""><div class="grid">${state.storyEvents.map(ev=>`<div class="story-card"><h3>第 ${ev.chapter} 章 · ${ev.title}</h3><div class="small">${ev.text}</div><div class="row" style="margin-top:10px">${ev.done ? `<span class="pill">已完成</span>` : ev.options.map((op,idx)=>`<button class="primary" data-story="${ev.id}" data-idx="${idx}">${op.text}</button>`).join('')}</div></div>`).join('')}</div></div>`; document.querySelectorAll('[data-story]').forEach(b=>b.onclick=()=>chooseStory(b.dataset.story, Number(b.dataset.idx))); }
function renderMissions(){ document.getElementById('screen-missions').innerHTML = `<div class="card"><h2 class="title">主线章节</h2><p class="sub">当前版本已强化前三章任务链与事件衔接，并继续预留第四到第六章的章节位。</p><img class="hero-banner" src="${img.maps}" alt=""><div class="grid">${state.missions.map(m=>`<div class="mission"><h3>第 ${m.chapter} 章 · ${m.name}</h3><div class="small">${m.desc}</div><div class="meter" style="margin:10px 0"><span style="width:${(m.progress/m.target)*100}%"></span></div><div class="row"><span class="pill">${m.status}</span><span class="pill">进度 ${m.progress}/${m.target}</span></div><button class="primary" data-mission="${m.id}" ${m.status!=='可领取'?'disabled':''}>领取奖励</button></div>`).join('')}</div></div>`; document.querySelectorAll('[data-mission]').forEach(b=>b.onclick=()=>claimMission(b.dataset.mission)); }
function renderRecruit(){ document.getElementById('screen-recruit').innerHTML = `<div class="card"><div class="section-head"><div><h2 class="title">招募</h2><p class="sub">消耗镜币进行角色招募。</p></div><span class="pill">镜币：${state.resources.mirror}</span></div><img class="hero-banner" src="${img.characters3}" alt=""><div class="grid g3">${state.recruitPool.map(r=>`<div class="recruit"><h3>${r.name}</h3><div class="small">${r.rarity} ｜ ${r.faction}</div><p class="small">${r.desc}</p><button class="primary" data-recruit="${r.id}" data-cost="${r.cost}">消耗 ${r.cost} 镜币招募</button></div>`).join('')}</div></div>`; document.querySelectorAll('[data-recruit]').forEach(b=>b.onclick=()=>recruit(b.dataset.recruit, Number(b.dataset.cost))); }
function renderShop(){ document.getElementById('screen-shop').innerHTML = `<div class="card"><h2 class="title">商店</h2><p class="sub">当前工程保留商业化页面结构，但不伪造真实支付。</p><div class="grid g3">${state.shop.map(s=>`<div class="shop-item"><h3>${s.name}</h3><div class="small">${s.price}</div><p class="small">${s.items}</p><button class="primary" data-buy="${s.id}">查看</button></div>`).join('')}</div></div>`; document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buyItem(b.dataset.buy)); }
function renderBattle(){
  const b = state.battle;
  const roster = state.team.map(id=>getChar(id)).filter(Boolean);
  document.getElementById('screen-battle').innerHTML = `
    <div class="card">
      <div class="section-head">
        <div><h2 class="title">战斗</h2><p class="sub">V5 已改成更明确的可视化对战场景：我方角色带单独头像，对面出现敌方单位画面，同时保留三种操作指令。</p></div>
        <div class="row"><button class="primary" id="battleStart">${b.active ? '战斗进行中' : '开始战斗'}</button><span class="pill">星级 ${b.stars}</span></div>
      </div>

      <div class="battle-scene">
        <div class="battle-lineup">
          <div>
            <div class="battle-grid">
              ${roster.map(c=>{
                const eq=(c.equipment||[]).reduce((s,e)=>s+(state.equipmentDefs[e]?.power||0),0);
                return `<div class="battle-unit">
                  <img class="battle-avatar" src="${portraits[c.id] || img.characters2}" alt="">
                  <div class="name">${c.name}</div>
                  <div class="meta">Lv.${c.level} ｜ 攻击 ${c.atk}</div>
                  <div class="meta">装备加成 ${eq}</div>
                </div>`;
              }).join('')}
            </div>

            <div class="card" style="margin-top:14px">
              <h3>我方状态</h3>
              <div class="small">我方生命 ${b.playerHP}/${b.playerMaxHP}</div>
              <div class="meter" style="margin-top:8px"><span style="width:${b.playerMaxHP ? (b.playerHP/b.playerMaxHP)*100 : 0}%"></span></div>
              <div class="row" style="margin-top:10px">
                <span class="pill">群众支持 ${b.support}</span>
                <span class="pill">失控值 ${b.chaos}</span>
                <span class="pill">回合 ${b.round}</span>
              </div>
              <div class="action-bar">
                <button class="primary" id="actAttack" ${!b.active?'disabled':''}>普通攻击</button>
                <button class="secondary" id="actCommand" ${!b.active?'disabled':''}>整队指挥</button>
                <button class="secondary" id="actReverence" ${!b.active?'disabled':''}>敬意克制</button>
              </div>
            </div>
          </div>

          <div class="enemy-box">
            <img class="enemy-portrait" src="images/enemy_raider.jpg" alt="">
            <h3 style="margin:10px 0 6px">敌方：${b.enemyName}</h3>
            <div class="small">敌方生命 ${b.enemyHP}/${b.enemyMaxHP}</div>
            <div class="meter" style="margin-top:8px"><span style="width:${b.enemyMaxHP ? (b.enemyHP/b.enemyMaxHP)*100 : 0}%"></span></div>
          </div>
        </div>
      </div>

      <div class="card" style="margin-top:14px">
        <h3>战斗记录</h3>
        <div class="log">${b.logs.map(x=>`<p>${x}</p>`).join('')}</div>
      </div>
    </div>`;
  document.getElementById('battleStart').onclick = startBattle;
  document.getElementById('actAttack').onclick = ()=>battleAction('attack');
  document.getElementById('actCommand').onclick = ()=>battleAction('command');
  document.getElementById('actReverence').onclick = ()=>battleAction('reverence');
}
function renderGallery(){ const items = [{title:'主城皮肤一', src:img.city1, desc:'前面准备好的主城主题图已纳入离线工程。'},{title:'主城皮肤二', src:img.city2, desc:'继续扩展不同文明倾向下的城池风格。'},{title:'角色宣传图', src:img.characters1, desc:'角色组图已作为正式单机版素材参考一并打包。'},{title:'建筑概念图', src:img.buildings, desc:'核心建筑与升级方向用于后续正式资产细化。'},{title:'前六章地图', src:img.maps, desc:'前面产出的地图方向图已接入本地资源库。'},{title:'UI方向图', src:img.ui, desc:'页面风格与交互方向也一并保留在图鉴中。'}]; document.getElementById('screen-gallery').innerHTML = `<div class="card"><h2 class="title">资源图鉴</h2><p class="sub">前面生成的图片资源已一并打包进单机工程，当前更多用于展示与参考，正式商业版仍需替换为统一规格的可实装资产。</p><div class="grid g2">${items.map(i=>`<div class="gallery-item"><img class="gallery-thumb" src="${i.src}" alt=""><h3>${i.title}</h3><div class="small">${i.desc}</div></div>`).join('')}</div></div>`; }
function renderSave(){ document.getElementById('screen-save').innerHTML = `<div class="grid g2"><div class="save-box"><h2 class="title">导出存档</h2><p class="sub">导出的文本可以手动备份，或在另一台设备上导入。</p><button class="primary" id="exportBtn">生成导出文本</button><textarea id="saveExport" readonly></textarea></div><div class="save-box"><h2 class="title">导入存档</h2><p class="sub">将之前导出的 JSON 文本粘贴到这里。</p><textarea id="saveImport"></textarea><div class="row" style="margin-top:8px"><button class="primary" id="importBtn">导入存档</button></div></div></div>`; document.getElementById('exportBtn').onclick = exportSave; document.getElementById('importBtn').onclick = importSave; }
function switchScreen(name){ document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active')); document.querySelector(`.tab[data-screen="${name}"]`)?.classList.add('active'); document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active')); document.getElementById('screen-' + name).classList.add('active'); }
window.switchScreen = switchScreen;
function rerender(){ document.getElementById('resourceBar').innerHTML = resourceBar(); document.getElementById('heroTags').innerHTML = mood().map(x=>`<span class="pill">${x}</span>`).join(''); renderCity(); renderCharacters(); renderSquad(); renderCivilization(); renderLaws(); renderQuiet(); renderStory(); renderMissions(); renderRecruit(); renderShop(); renderBattle(); renderGallery(); renderSave(); save(); }
document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click', ()=>switchScreen(btn.dataset.screen)));
updateMissionProgress(); rerender();
