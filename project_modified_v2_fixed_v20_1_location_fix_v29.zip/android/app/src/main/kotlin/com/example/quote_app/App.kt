package com.example.quote_app

import android.app.Application
import android.app.Activity
import android.app.ActivityManager
import android.os.Bundle
import com.example.quote_app.GeoWorker
import com.example.quote_app.NotifyHelper
import com.example.quote_app.data.DbInspector
import android.database.sqlite.SQLiteDatabase
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import android.content.pm.PackageManager
import java.security.MessageDigest

/**
 * Application (Flutter V2 embedding).
 * No custom plugin registrant callbacks are used.
 * Workmanager/plugin registration is handled by the framework and plugins themselves.
 */
class App : Application(), Application.ActivityLifecycleCallbacks {
  private var unlockReceiver: UnlockReceiver? = null

  override fun onCreate() {
    super.onCreate()
    registerActivityLifecycleCallbacks(this)

    // NOTE: Application.onCreate() runs in every process of this app (including ":remote").
    // Heavy init + broadcast registrations should only run in the main process, otherwise:
    // - Baidu Location remote process crashes/restarts can spam logs ("动态解锁接收器注册成功...")
    // - unnecessary receivers are registered in the :remote process.
    val isMain = isMainProcess()

    // ---- Baidu SDK common init (runs in all processes, including ":remote") ----
    // Location SDK privacy + AK must be set before any LocationClient usage.
    try {
      try { com.baidu.location.LocationClient.setAgreePrivacy(true) } catch (_: Throwable) {}
      val ak = try { readBaiduAkForMapSdk(applicationContext) } catch (_: Throwable) { "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" }

      // 仅在主进程打印一次：帮助排查百度 AK 与签名(SHA1)/包名不匹配（locType=505）
      if (isMain) {
        try {
          val sha1 = getSigningSha1(applicationContext) ?: "na"
          Log.i("App", "Baidu AK=${maskAk(ak)}, package=${applicationContext.packageName}, sha1=$sha1, process=${getProcessNameSafe()}")
        } catch (_: Throwable) {}
      }

      // Location SDK requires explicit AK; use reflection to avoid version-coupling.
      invokeBaiduSdkStatic("com.baidu.location.LocationClient", "setKey", ak)

      // ---- Baidu Map/Search init (main process only) ----
      if (isMain) {
        try { com.baidu.mapapi.SDKInitializer.setAgreePrivacy(applicationContext, true) } catch (_: Throwable) {}
        invokeBaiduSdkStatic("com.baidu.mapapi.SDKInitializer", "setApiKey", ak)
        try { com.baidu.mapapi.SDKInitializer.initialize(applicationContext) } catch (_: Throwable) {}
        try { com.baidu.mapapi.SDKInitializer.setCoordType(com.baidu.mapapi.CoordType.BD09LL) } catch (_: Throwable) {}
        invokeBaiduSdkStatic("com.baidu.mapapi.SDKInitializer", "setHttpsEnable", true)
      }
    } catch (_: Throwable) {}

    if (isMain) {
      // Schedule the periodic GeoWorker so geo triggers run even if the device isn't rebooted.
      try {
        GeoWorker.schedule(this)
      } catch (_: Throwable) {
        // Ignore any failures silently
      }

      // 关键：只要进程还活着，解锁广播就会进 UnlockReceiver
      registerUnlockReceiver()

      // 注册 SCREEN_ON 探测接收器（仅用于确认是否已解锁，不直接触发业务）
      try {
        val f2 = android.content.IntentFilter().apply { addAction(android.content.Intent.ACTION_SCREEN_ON) }
        val r2 = ScreenOnProbeReceiver()
        if (android.os.Build.VERSION.SDK_INT >= 33) {
          registerReceiver(r2, f2, RECEIVER_NOT_EXPORTED)
        } else {
          @Suppress("DEPRECATION")
          registerReceiver(r2, f2)
        }
        com.example.quote_app.data.DbRepo.log(this, null, "【App】runtime SCREEN_ON 探测接收器已注册（仅用于确认已解锁，不直接触发业务）")
      } catch (_: Throwable) {}

      // 兜底：某些机型广播被电池策略吞掉，在 App 启动时补一次提醒（带冷却）
      maybeSendUnlockReminderOnAppStart()
    }
  }

  private fun isMainProcess(): Boolean {
    // API 28+ provides Application.getProcessName(); older devices use ActivityManager.
    val pn = packageName
    val current = try {
      if (Build.VERSION.SDK_INT >= 28) {
        Application.getProcessName()
      } else {
        getProcessNameCompat()
      }
    } catch (_: Throwable) {
      null
    }
    return current == null || current == pn
  }

  private fun getProcessNameCompat(): String? {
    return try {
      val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      val myPid = android.os.Process.myPid()
      val procs = am?.runningAppProcesses ?: return null
      for (p in procs) {
        if (p.pid == myPid) return p.processName
      }
      null
    } catch (_: Throwable) {
      null
    }
  }


  private fun registerUnlockReceiver() {
    try {
      if (unlockReceiver == null) {
        val r = UnlockReceiver()
        val filter = IntentFilter().apply {
          // 仅监听解锁事件（USER_PRESENT / USER_UNLOCKED），避免多余广播干扰
          addAction(Intent.ACTION_USER_PRESENT)
          addAction(Intent.ACTION_USER_UNLOCKED)
        }

        if (Build.VERSION.SDK_INT >= 33) {
          registerReceiver(r, filter, RECEIVER_NOT_EXPORTED)
        } else {
          @Suppress("DEPRECATION")
          registerReceiver(r, filter)
        }

        unlockReceiver = r
        try {
          com.example.quote_app.data.DbRepo.log(this, null, "【App】动态解锁接收器注册成功，只监听解锁事件 ACTION_USER_PRESENT/ACTION_USER_UNLOCKED（回包：OK）")
        } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {
      try {
        com.example.quote_app.data.DbRepo.log(this, null, "【App】动态解锁接收器注册失败（回包：FAIL）")
      } catch (_: Throwable) {}
    }
  }

  /**
   * 作为解锁提醒的兜底逻辑：
   * - 理想情况：UnlockReceiver 能正常收到 USER_PRESENT 并直接发通知；
   * - 某些机型/电池策略过于激进时，广播可能收不到，这里在 App 启动时
   *   按一定规则补发一条提醒，避免完全收不到通知；同时加入限流，杜绝
   *   每次打开 App 都弹一条的情况。
   */
  private fun maybeSendUnlockReminderOnAppStart() {
    try {
      val prefs = getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
      val now = System.currentTimeMillis()

      // 仅当“最近一次解锁”发生在 5 秒内，才认为是解锁相关的启动；否则不发送兜底提醒
      try {
        val sp = getSharedPreferences("quote_prefs", Context.MODE_PRIVATE)
        val lastUp = sp.getLong("last_user_present_ts", 0L)
        if (lastUp <= 0L || (now - lastUp) > 5000L) {
          try { com.example.quote_app.data.DbRepo.log(this, null, "【App】启动兜底检查：最近未发生解锁（>5s），本次不发送愿景提醒（回包：SKIP）") } catch (_: Throwable) {}
          return
        }
      } catch (_: Throwable) {}

      // 1）如果刚刚是 UnlockReceiver 通过解锁事件发过一条（10 秒内），
      //    则此处不再重复发送。
      val lastUnlockReminder = prefs.getLong("last_unlock_reminder_time", 0L)
      if (lastUnlockReminder > 0L && (now - lastUnlockReminder) <= 10_000L) {
        return
      }

      // 2）兜底渠道增加冷却时间，防止频繁打开 App 被通知轰炸。
      // 默认值 30 分钟，如果 notify_config 中配置了 unlock_cooldown_minutes 或 unlock_cooldown_days，则覆盖默认值。
      var cooldownMs = 30L * 60L * 1000L
      try {
        val cc = com.example.quote_app.data.DbInspector.loadOrLightScan(this)
        if (cc != null && cc.dbPath != null) {
          val dbConf = SQLiteDatabase.openDatabase(cc.dbPath, null, SQLiteDatabase.OPEN_READONLY)
          // 优先读取天数配置
          try {
            val cDay = dbConf.rawQuery("SELECT value FROM notify_config WHERE key='unlock_cooldown_days' LIMIT 1", null)
            if (cDay.moveToFirst()) {
              val v = cDay.getString(0)
              try {
                val d = v?.toDouble()
                if (d != null && d > 0.0) {
                  cooldownMs = (d * 24.0 * 60.0 * 60.0 * 1000.0).toLong()
                }
              } catch (_: Throwable) {
                // ignore parse
              }
            }
            cDay.close()
          } catch (_: Throwable) {
            // ignore
          }
          // 如果未由天数配置覆盖，则读取分钟配置
          if (cooldownMs == 30L * 60L * 1000L) {
            try {
              val cMin = dbConf.rawQuery("SELECT value FROM notify_config WHERE key='unlock_cooldown_minutes' LIMIT 1", null)
              if (cMin.moveToFirst()) {
                val v2 = cMin.getString(0)
                try {
                  val m = v2?.toInt()
                  if (m != null && m > 0) {
                    cooldownMs = m.toLong() * 60L * 1000L
                  }
                } catch (_: Throwable) {
                  // ignore parse
                }
              }
              cMin.close()
            } catch (_: Throwable) {
              // ignore
            }
          }
          dbConf.close()
        }
      } catch (_: Throwable) {
        // ignore
      }
      val lastAppReminder = prefs.getLong("last_app_start_reminder_time", 0L)
      if (lastAppReminder > 0L && (now - lastAppReminder) <= cooldownMs) {
        return
      }

      // 3）判断是否需要兜底：
      //    - 如果从未记录过 unlock 时间（last_unlock_time == 0），说明很多
      //      机型根本收不到 USER_PRESENT，这种情况直接认为需要兜底；
      //    - 否则仅在“解锁后 10 秒内启动 App”时认为需要兜底。
      val lastUnlock = prefs.getLong("last_unlock_time", 0L)
      val needFallback = if (lastUnlock == 0L) {
        true
      } else {
        (now - lastUnlock) <= 10_000L
      }
      if (!needFallback) {
        return
      }

      // 4）确认数据库中确实存在已启用的 screen_unlock 触发规则
      val contract = DbInspector.loadOrLightScan(this)
      if (contract == null || contract.dbPath == null) return
      val path = contract.dbPath!!
      val db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY)
      val c = db.rawQuery(
        "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
        null
      )
      val has = c.moveToFirst()
      c.close()
      db.close()
      if (has) {
        NotifyHelper.send(this, 2000, "愿景提醒", "别忘了你的一件事！", null, "vision_focus", null)
        // 记录为一次 App 启动兜底提醒，30 分钟内不再触发
        prefs.edit().putLong("last_app_start_reminder_time", now).apply()
      }
    } catch (_: Throwable) {
      // swallow errors，避免影响 App 启动
    }
  }

    
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        if (activity is io.flutter.embedding.android.FlutterActivity) {
            try {
                // 通过反射获取 flutterEngine，避免直接访问受保护的属性。
                val field = io.flutter.embedding.android.FlutterActivity::class.java.getDeclaredField("flutterEngine")
                field.isAccessible = true
                val engine = field.get(activity) as? io.flutter.embedding.engine.FlutterEngine
	                if (engine != null) {
	                    // 注意：SysChannel 与 Channels 使用相同 MethodChannel 名称（com.example.quote_app/sys）。
	                    // 为避免 handler 被覆盖导致系统/权限相关方法丢失，这里仅注册 Channels。
	                    try { Channels.register(engine, applicationContext) } catch (_: Throwable) {}
	                }
            } catch (_: Throwable) {
                // 忽略，保持兼容
            }
        }
    }
    override fun onActivityStarted(activity: Activity) {}
    override fun onActivityResumed(activity: Activity) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}


  private fun isGeoRulesEnabled(ctx: Context): Boolean {
    return try {
      val cc = DbInspector.loadOrLightScan(ctx) ?: return false
      val db = SQLiteDatabase.openDatabase(
        cc.dbPath,
        null,
        SQLiteDatabase.OPEN_READONLY
      )
      try {
        var enabled = false
        try {
          db.rawQuery(
            "SELECT location_rules_enabled FROM configs ORDER BY id DESC LIMIT 1",
            null
          ).use { c ->
            if (c.moveToFirst()) {
              enabled = (c.getInt(0) == 1)
            }
          }
        } catch (_: Throwable) {
        }
        enabled
      } finally {
        try {
          db.close()
        } catch (_: Throwable) {
        }
      }
    } catch (_: Throwable) {
      false
    }
  }

private fun readBaiduAkForMapSdk(ctx: Context): String {
  return try {
    val cc = DbInspector.loadOrLightScan(ctx)
    val path = cc?.dbPath
    if (path.isNullOrEmpty()) return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
    // 某些机型/场景下 prefs 里可能残留一个已不存在的 dbPath（例如重装/清理数据/迁移失败）。
    // 此处必须先判定文件存在，否则 openDatabase 会直接抛错并污染日志，甚至影响 SDK 初始化时序。
    try {
      val f = java.io.File(path)
      if (!f.exists() || !f.isFile) return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
    } catch (_: Throwable) {
      return "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
    }
    val db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY)
    try {
      var v: String? = null
      try {
        db.rawQuery("SELECT baidu_ak FROM configs LIMIT 1", null).use { c ->
          if (c.moveToFirst()) v = c.getString(0)
        }
      } catch (_: Throwable) {
        // ignore when table/column missing
      }
      if (v == null || v!!.trim().isEmpty()) "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2" else v!!.trim()
    } finally {
      try { db.close() } catch (_: Throwable) {}
    }
  } catch (_: Throwable) {
    "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
  }
}


  private fun maskAk(ak: String): String {
    return try {
      if (ak.length <= 8) "***"
      else ak.substring(0, 4) + "****" + ak.substring(ak.length - 4)
    } catch (_: Throwable) { "***" }
  }

  /** 获取当前安装包签名证书 SHA1（用于百度控制台 Android SDK 安全码校验）。失败返回 null。 */
  private fun getSigningSha1(ctx: Context): String? {
    return try {
      val pm = ctx.packageManager
      val pi = if (Build.VERSION.SDK_INT >= 28) {
        pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
      } else {
        @Suppress("DEPRECATION")
        pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
      }

      val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= 28) {
        val si = pi.signingInfo ?: return null
        val sigs = if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
        if (sigs.isNotEmpty()) sigs[0].toByteArray() else null
      } else {
        @Suppress("DEPRECATION")
        if (pi.signatures != null && pi.signatures.isNotEmpty()) pi.signatures[0].toByteArray() else null
      }

      if (sigBytes == null) return null
      val md = MessageDigest.getInstance("SHA1")
      val digest = md.digest(sigBytes)
      digest.joinToString(":") { b -> "%02X".format(b) }
    } catch (_: Throwable) {
      null
    }
  }

  private fun invokeBaiduSdkStatic(className: String, methodName: String, vararg args: Any?) {
    try {
      val clazz = Class.forName(className)
      val methods = clazz.methods
      for (m in methods) {
        if (m.name == methodName && m.parameterTypes.size == args.size) {
          try { m.invoke(null, *args) } catch (_: Throwable) {}
          return
        }
      }
    } catch (_: Throwable) {}
  }

}