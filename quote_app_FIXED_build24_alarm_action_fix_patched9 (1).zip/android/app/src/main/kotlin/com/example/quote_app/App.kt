package com.example.quote_app

import android.app.Application

/**
 * Application (Flutter V2 embedding).
 * No custom plugin registrant callbacks are used.
 * Workmanager/plugin registration is handled by the framework and plugins themselves.
 */
class App : Application() {
  override fun onCreate() {
    super.onCreate()
    // Keep empty: no v1 embedding APIs, no reflection.
  }
}
