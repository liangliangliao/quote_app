class RunContext {
  static bool isFromWM = false; // 是否来自WorkManager回调
  static bool isBackground = false;
}


class RunIdCard {
  // 格式: src=<am|main-wm|fallback-wm|selfck-wm>_runkey=<yyyy-MM-dd HH:mm:ss>_uid=<uid>
  static String build({required String src, required String runKey, required String uid}) {
    return 'src='+src+'_runkey='+runKey+'_uid='+uid;
  }
  static String srcOf(String id) => _part(id, 'src');
  static String runKeyOf(String id) => _part(id, 'runkey');
  static String uidOf(String id) => _part(id, 'uid');
  static String _part(String s, String k) {
    final re = RegExp(k+r'=([^_]+)');
    final m = re.firstMatch(s);
    return m == null ? '' : (m.group(1) ?? '');
  }
}
