package com.example.quote_app.wm;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;
import com.example.quote_app.data.DbRepository;

public final class WmScheduler {
    private WmScheduler() {}

    public static void schedulePair(Context ctx, long triggerAt, String uid, String runKey) {
        long now = System.currentTimeMillis();
        long delay = Math.max(0L, triggerAt - now);
        long fbDelay = delay + 2 * 60 * 1000L; // +2min fallback

        WorkManager wm = WorkManager.getInstance(ctx.getApplicationContext());

        Data normal = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("chan", "normal")
                .putInt("attempt", 1)
                .build();

        Data fallback = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("chan", "wm_fallback")
                .putInt("attempt", 1)
                .build();

        OneTimeWorkRequest normalReq = new OneTimeWorkRequest.Builder(NormalWorker.class)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .addTag("wm_normal").addTag(uid)
                .setInputData(normal)
                .build();

        OneTimeWorkRequest fbReq = new OneTimeWorkRequest.Builder(FallbackWorker.class)
                .setInitialDelay(fbDelay, TimeUnit.MILLISECONDS)
                .addTag("wm_fallback")
                .setInputData(fallback)
                .build();

        DbRepository.log(ctx, uid, "【原生】WM 正常通道注册 uid="+uid+" run="+runKey+" ts="+triggerAt);
        wm.enqueueUniqueWork(WmNames.normUnique(uid, runKey), ExistingWorkPolicy.REPLACE, normalReq);
        DbRepository.log(ctx, uid, "【原生】WM 兜底通道注册 uid="+uid+" run="+runKey+" ts="+(triggerAt+120000));
        wm.enqueueUniqueWork(WmNames.fbUnique(uid, runKey), ExistingWorkPolicy.REPLACE, fbReq);
    }

    
    public static void cancelNormal(Context ctx, String uid, String runKey) {
        DbRepository.log(ctx, uid, "【原生】WM 取消正常 uid="+uid+" run="+runKey);
        WorkManager.getInstance(ctx.getApplicationContext())
                .cancelUniqueWork(WmNames.normUnique(uid, runKey));
    }
public static void cancelFallback(Context ctx, String uid, String runKey) {
        DbRepository.log(ctx, uid, "【原生】WM 取消兜底 uid="+uid+" run="+runKey);
        WorkManager.getInstance(ctx.getApplicationContext())
                .cancelUniqueWork(WmNames.fbUnique(uid, runKey));
    }


    public static void cancelByUid(Context ctx, String uid) {
        try {
            DbRepository.log(ctx, uid, "【原生】WM 取消(按uid) uid="+uid);
            WorkManager.getInstance(ctx.getApplicationContext()).cancelAllWorkByTag(uid);
        } catch (Throwable ignore) {}
    }

    public static void cancelByIdCard(Context ctx, String idCard) {
        try {
            String src = part(idCard, "src");
            String runKey = part(idCard, "runkey");
            String uid = part(idCard, "uid");
            if (uid.isEmpty() || runKey.isEmpty()) return;
            if ("main-wm".equals(src)) {
                cancelNormal(ctx, uid, runKey);
            } else if ("fallback-wm".equals(src)) {
                cancelFallback(ctx, uid, runKey);
            } else if ("selfck-wm".equals(src)) {
                cancelSelfCheck(ctx);
            } else {
                cancelNormal(ctx, uid, runKey);
            }
        } catch (Throwable ignore) {}
    }

    public static void cancelSelfCheck(Context ctx) {
        try {
            DbRepository.log(ctx, null, "【原生】WM 取消自检");
            WorkManager.getInstance(ctx.getApplicationContext())
                .cancelUniqueWork("wm_once_selfck");
            WorkManager.getInstance(ctx.getApplicationContext())
                .cancelAllWorkByTag("selfck-wm");
        } catch (Throwable ignore) {}
    }


    private static void cancelNormal(Context ctx, String uid, String runKey) {
        try {
            androidx.work.WorkManager.getInstance(ctx)
                .cancelUniqueWork(WmNames.normUnique(uid, runKey));
        } catch (Throwable ignore) {}
    }
    private static void cancelFallback(Context ctx, String uid, String runKey) {
        try {
            androidx.work.WorkManager.getInstance(ctx)
                .cancelUniqueWork(WmNames.fbUnique(uid, runKey));
        } catch (Throwable ignore) {}
    }
    public static void cancelSelfCheck(Context ctx) {
        try {
            androidx.work.WorkManager wm = androidx.work.WorkManager.getInstance(ctx);
            wm.cancelUniqueWork("wm_once_selfck");
            wm.cancelAllWorkByTag("selfck-wm");
        } catch (Throwable ignore) {}
    }
    public static void schedulePair(Context ctx, long triggerAt, String uid, String runKey) {
        try {
            Data normal = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("chan", "main-wm")
                .putInt("attempt", 1)
                .build();
            androidx.work.OneTimeWorkRequest reqN =
                new androidx.work.OneTimeWorkRequest.Builder(NormalWorker.class)
                .setInitialDelay(Math.max(0, triggerAt - System.currentTimeMillis()), java.util.concurrent.TimeUnit.MILLISECONDS)
                .setInputData(normal).build();
            androidx.work.WorkManager.getInstance(ctx).enqueueUniqueWork(
                WmNames.normUnique(uid, runKey), androidx.work.ExistingWorkPolicy.REPLACE, reqN);
            Data fb = new Data.Builder()
                .putString("uid", uid)
                .putString("runKey", runKey)
                .putString("chan", "fallback-wm")
                .putInt("attempt", 1)
                .build();
            androidx.work.OneTimeWorkRequest reqF =
                new androidx.work.OneTimeWorkRequest.Builder(FallbackWorker.class)
                .setInitialDelay(Math.max(0, triggerAt - System.currentTimeMillis() + 120000L), java.util.concurrent.TimeUnit.MILLISECONDS)
                .setInputData(fb).build();
            androidx.work.WorkManager.getInstance(ctx).enqueueUniqueWork(
                WmNames.fbUnique(uid, runKey), androidx.work.ExistingWorkPolicy.REPLACE, reqF);
        } catch (Throwable ignore) {}
    }
    
    private static String part(String id, String key) {
        if (id == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(key + "=([^_]+)").matcher(id);
        if (m.find()) return m.group(1);
        if ("uid".equals(key)) {
            m = java.util.regex.Pattern.compile("uid=(.+)$").matcher(id);
            if (m.find()) return m.group(1);
        }
        return "";
    }

}
