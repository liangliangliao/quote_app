package com.example.quote_app.wm;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ListenableWorker;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

import java.util.concurrent.TimeUnit;

public final class FallbackWorker extends Worker {

    public FallbackWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override public ListenableWorker.Result doWork() {
        Context ctx = getApplicationContext();
        Data in = getInputData();
        String uid = in.getString("uid");
        String runKey = in.getString("runKey");
        int attempt = in.getInt("attempt", 1);

        try {
            DbRepository.log(ctx, uid, "【原生】WM 兜底通道触发 uid="+uid+" run="+runKey+" attempt="+attempt);
            boolean ok = Biz.run(ctx, uid);
            if (ok) {
                DbRepository.markLatestSuccess(ctx, uid);
                // 成功：自身结束并安排下一次（不需要额外操作，UniqueWork会自然完成）
                long next = NextTriggerCalculator.compute(ctx, uid);
                if (next > 0) {
                    WmScheduler.schedulePair(ctx, next, uid, "ts_" + next);
                }
                return ListenableWorker.Result.success();
            } else {
                // 失败：重试一次立刻执行的兜底；超过 2 次则放弃
                DbRepository.log(ctx, uid, "【原生】WM 兜底通道发送失败 uid="+uid+" run="+runKey+" attempt="+attempt);
                if (attempt < 2) {
                    Data in2 = new Data.Builder()
                            .putString("uid", uid)
                            .putString("runKey", runKey)
                            .putString("chan", "wm_fallback")
                            .putInt("attempt", attempt + 1)
                            .build();
                    OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(FallbackWorker.class)
                            .setInitialDelay(0, TimeUnit.MILLISECONDS)
                            .addTag("wm_fallback_retry")
                            .setInputData(in2)
                            .build();
                    WorkManager.getInstance(ctx).enqueueUniqueWork(WmNames.fbUnique(uid, runKey), 
                            androidx.work.ExistingWorkPolicy.REPLACE, req);
                    return ListenableWorker.Result.success(); // 当前这次算完成，交给新的重试
                } else {
                    DbRepository.log(ctx, uid, "兜底失败达到2次，停止兜底");
                    return ListenableWorker.Result.failure();
                }
            }
        } catch (Throwable t) {
            DbRepository.log(ctx, uid, "WM兜底异常: " + t.getMessage());
            return ListenableWorker.Result.retry();
        }
    }
}
