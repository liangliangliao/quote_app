import 'dart:async';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../data/self_help_dao.dart';
import '../data/kv_dao.dart';
import '../integrations/fitbit/fitbit_client.dart';
import '../utils/ppg_processor.dart';
import '../utils/fitbit_metrics.dart';
import '../utils/arousal_model.dart';
import 'change_self_help_report_page.dart';
import 'change_intervention_page.dart';
import 'fitbit_settings_page.dart';



enum _PpgSignalMode { auto, redUV, redVU, luma, bgraRed }

/// "改变 · 心理自助"（Change module）
///
/// - 主观：STAI-6（状态焦虑短表） + Affective Slider（唤醒/愉悦）
/// - 客观：手机后置摄像头 PPG（心率 + HRV RMSSD 估算）
/// - 可选：Fitbit 数据同步（心率、睡眠、HRV 等）
class ChangeSelfHelpPage extends StatefulWidget {
  const ChangeSelfHelpPage({super.key});

  @override
  State<ChangeSelfHelpPage> createState() => _ChangeSelfHelpPageState();
}

class _ChangeSelfHelpPageState extends State<ChangeSelfHelpPage> {
  final _dao = SelfHelpDao();
  final _kv = KeyValueDao();
  final _ppg = PpgProcessor();

  // --- subjective ---
  // STAI-6 items (1..4)
  final List<int> _stai6 = List<int>.filled(6, 2);
  // Affective Slider (0..100)
  double _arousal = 50;
  double _valence = 50;

  // Zone appraisal (0..100)
  double _demand = 50; // perceived challenge/demand
  double _resources = 60; // perceived coping resources/control
  double _distress = 35; // subjective distress (SUDS)

  // --- objective (camera PPG) ---
  CameraController? _cam;
  bool _measuring = false;
  double? _bpm;
  double? _rmssd;
  double? _sqi;
  String? _ppgError;
  int _secondsLeft = 0;
  Timer? _ticker;
  bool _torchEnabled = false;

  // green channel samples & timestamps (ms)
  final List<double> _samples = [];
  final List<int> _tsMs = [];

  // PPG signal extraction mode auto-selection (to improve robustness across devices).
  _PpgSignalMode _ppgSignalMode = _PpgSignalMode.auto;
  final List<double> _probeRedUv = [];
  final List<double> _probeRedVu = [];
  final List<double> _probeLuma = [];
  int _probeTarget = 45; // ~3s at 15fps

  // PPG warmup to allow torch exposure + finger settling
  int _ppgStartMs = 0;
  static const int _ppgWarmupMs = 1500;

  // --- fitbit ---
  bool _fitbitSyncing = false;
  String? _fitbitStatus;

  final _fitbitDao = FitbitDao();
  int _fitbitCacheCount = 0;
  List<String> _fitbitCachedEndpoints = const [];

  FitbitMetrics? _fitbitMetrics;
  double? _baselineRestingHr;
  double? _baselineRmssdMs;

  ArousalResult? _lastComputed;

  @override
  void initState() {
    super.initState();
    _reloadBaselinesAndFitbit();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _stopCamera();
    super.dispose();
  }

  // =======================
  // Subjective scoring
  // =======================

  /// STAI-6 scoring (Marteau & Bekker 1992): reverse score positive items,
  /// sum 6 items (range 6..24), and optionally prorate to 20-item STAI
  /// by multiplying by (20/6) producing 20..80.
  ///
  /// Reverse-scored items: calm, relaxed, content.
  int _stai6Raw() {
    // indices: 0 calm (R), 1 tense, 2 upset, 3 relaxed (R), 4 content (R), 5 worried
    int rev(int v) => 5 - v; // 1<->4
    final v0 = rev(_stai6[0]);
    final v1 = _stai6[1];
    final v2 = _stai6[2];
    final v3 = rev(_stai6[3]);
    final v4 = rev(_stai6[4]);
    final v5 = _stai6[5];
    return v0 + v1 + v2 + v3 + v4 + v5;
  }

  double _stai6Prorated() {
    return _stai6Raw() * (20.0 / 6.0);
  }

  // =======================
  // Baselines & Fitbit metrics
  // =======================

  String _todayDateStr() {
    final now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  double? _median(List<double> xs) {
    if (xs.isEmpty) return null;
    final a = [...xs]..sort();
    final m = a.length ~/ 2;
    if (a.length.isOdd) return a[m];
    return (a[m - 1] + a[m]) / 2.0;
  }

  double? _baselineFromRecentHr(List<double> bpm) {
    if (bpm.isEmpty) return null;
    final a = [...bpm]..sort();
    // Use the lower 30% to approximate resting baseline.
    final take = math.max(1, (a.length * 0.30).ceil());
    return _median(a.take(take).toList(growable: false));
  }

  double? _baselineFromRecentRmssd(List<double> rmssd) {
    if (rmssd.isEmpty) return null;
    final a = [...rmssd]..sort();
    // Use the upper 30% (higher HRV) to approximate calm baseline.
    final take = math.max(1, (a.length * 0.30).ceil());
    return _median(a.skip(math.max(0, a.length - take)).toList(growable: false));
  }

  Future<void> _reloadBaselinesAndFitbit() async {
    // Baseline from recent local records.
    try {
      final recents = await _dao.recentRecords(limit: 30);
      final bpm = <double>[];
      final rmssd = <double>[];
      for (final r in recents) {
        final b = (r['bpm'] as num?)?.toDouble();
        final h = (r['rmssd_ms'] as num?)?.toDouble();
        final sqi = (r['signal_quality'] as num?)?.toDouble() ?? 0.0;
        if (b != null && b >= 35 && b <= 200 && sqi >= 0.45) bpm.add(b);
        if (h != null && h >= 5 && h <= 200 && sqi >= 0.45) rmssd.add(h);
      }
      final baseHr = _baselineFromRecentHr(bpm);
      final baseRmssd = _baselineFromRecentRmssd(rmssd);
      if (mounted) {
        setState(() {
          _baselineRestingHr = baseHr;
          _baselineRmssdMs = baseRmssd;
        });
      }
    } catch (_) {
      // ignore
    }

    // Fitbit caches and parsed metrics for today.
    try {
      final date = _todayDateStr();
      final caches = await _fitbitDao.listCachesForDate(date);
      final endpoints = <String>[];
      for (final c in caches) {
        final ep = (c['endpoint'] ?? '')?.toString() ?? '';
        if (ep.isNotEmpty) endpoints.add(ep);
      }
      endpoints.sort();
      final metrics = await FitbitMetrics.load(dao: _fitbitDao, date: date);
      if (mounted) {
        setState(() {
          _fitbitCacheCount = caches.length;
          _fitbitCachedEndpoints = endpoints.toSet().toList(growable: false);
          // Only keep metrics if it has at least one signal.
          final hasAny = metrics.restingHeartRate != null ||
              metrics.currentHeartRate != null ||
              metrics.hrvRmssdMs != null ||
              metrics.sleepMinutes != null ||
              metrics.breathingRate != null;
          _fitbitMetrics = hasAny ? metrics : null;
        });
      }
    } catch (_) {
      // ignore
    }
  }

  // =======================
  // Zone classification
  // =======================

  
  String _zoneFromMetrics({double? bpm, double? rmssd, double? arousal0To100, double? staiProrated, double? demand0To100, double? resources0To100, double? distress0To100}) {
    // -----------------------
    // 科学化三区自评思路（主观）：
    // - 需求/挑战（Demand）
    // - 资源/掌控感（Resources / Control）
    // - 困扰强度（SUDS / Distress）
    //
    // 结合：唤醒（Arousal） + 状态焦虑（STAI-6） + 生理激活（HR/HRV）
    // 三区判定核心：需求与资源的“差距” + 困扰强度
    // -----------------------

    // Subjective
    final a = ((arousal0To100 ?? _arousal) / 100.0).clamp(0.0, 1.0);
    final s = (((staiProrated ?? _stai6Prorated()) - 20.0) / 60.0).clamp(0.0, 1.0); // 20..80 -> 0..1
    final d = ((demand0To100 ?? _demand) / 100.0).clamp(0.0, 1.0);
    final r = ((resources0To100 ?? _resources) / 100.0).clamp(0.0, 1.0);
    final u = ((distress0To100 ?? _distress) / 100.0).clamp(0.0, 1.0);

    // Objective contribution: high HR + low HRV suggests higher arousal.
    double o = 0.0;
    if (bpm != null) {
      o += ((bpm - 60.0) / 60.0).clamp(0.0, 1.0);
    }
    if (rmssd != null) {
      // typical RMSSD often ~20-80ms; lower => more stress.
      o += (1.0 - ((rmssd - 20.0) / 60.0).clamp(0.0, 1.0));
    }
    o = (o / 2.0).clamp(0.0, 1.0);

    // Appraisal gap: demand > resources implies overload risk.
    final gap = (d - r).clamp(-1.0, 1.0);

    // Composite activation: distress & arousal matter most for immediate self-help.
    final activation = (0.30 * a + 0.25 * s + 0.20 * o + 0.25 * u).clamp(0.0, 1.0);

    // Comfort zone: low demand + low distress + low activation.
    if (activation < 0.42 && d < 0.45 && u < 0.45) return '舒适区';

    // Panic zone: very high distress OR demand significantly exceeds resources (especially with high activation).
    if (u >= 0.85) return '恐慌区';
    if (gap >= 0.25 && (u >= 0.65 || activation >= 0.72)) return '恐慌区';
    if (activation >= 0.80 && u >= 0.60) return '恐慌区';

    // Learning zone: moderate challenge + manageable distress, even if activation is moderate.
    return '学习区';
  }

  String _zoneAdvice(String zone) {
    switch (zone) {
      case '舒适区':
        return '你当前较稳定。可以尝试一个“小挑战”：把目标分解到 10 分钟能完成的下一步。';
      case '学习区':
        return '你处在可成长的张力区间。建议：设定 25 分钟专注 + 5 分钟恢复；结束后做一次身体扫描/伸展。';
      case '恐慌区':
      default:
        return '唤醒水平偏高。先做“降唤醒”：4-6 呼吸（吸 4 秒、呼 6 秒）× 3 轮；把任务缩小到“最小下一步”。必要时暂停并寻求支持。';
    }
  }

  // =======================
  // Camera PPG
  // =======================

  Future<bool> _ensureCameraPermission() async {
    final st = await Permission.camera.request();
    return st.isGranted;
  }



  /// Extract a scalar PPG signal from [CameraImage].
  ///
  /// We prefer an approximate "red" intensity because finger PPG has strong
  /// contrast in the red channel under torch. However, across Android devices
  /// the U/V plane ordering and pixel strides can vary. We therefore probe a few
  /// variants and auto-select the most informative one for this session.
  ///
  /// Output is normalized to 0..1.
  double _extractPpgSignal(CameraImage img) {
    // ROI in the center to reduce edge leakage when finger doesn't fully cover lens.
    final w = img.width;
    final h = img.height;
    final x0 = (w * 0.35).round().clamp(0, w - 1);
    final x1 = (w * 0.65).round().clamp(1, w);
    final y0 = (h * 0.35).round().clamp(0, h - 1);
    final y1 = (h * 0.65).round().clamp(1, h);
    const step = 4; // downsample for speed

    // BGRA (some iOS devices) – use red byte (BGRA ordering).
    if (img.format.group == ImageFormatGroup.bgra8888 && img.planes.isNotEmpty) {
      final p = img.planes[0];
      final bytes = p.bytes;
      final rowStride = p.bytesPerRow;
      double sum = 0.0;
      int n = 0;
      for (int y = y0; y < y1; y += step) {
        final row = y * rowStride;
        for (int x = x0; x < x1; x += step) {
          final i = row + x * 4;
          if (i + 2 >= bytes.length) continue;
          final r = bytes[i + 2].toDouble();
          sum += r;
          n++;
        }
      }
      if (n <= 0) return 0.0;
      return (sum / n) / 255.0;
    }

    // YUV420 (Android) – use Y + 1.402*(V-128) as an approximation of red.
    if (img.planes.length < 3) return 0.0;
    final yPlane = img.planes[0];
    final uPlane = img.planes[1];
    final vPlane = img.planes[2];

    final yBytes = yPlane.bytes;
    final uBytes = uPlane.bytes;
    final vBytes = vPlane.bytes;

    final yRowStride = yPlane.bytesPerRow;
    final uvRowStride = uPlane.bytesPerRow;
    final uvPixelStride = uPlane.bytesPerPixel ?? 2;

    double sumL = 0.0;
    double sumRedUv = 0.0;
    double sumRedVu = 0.0;
    int n = 0;

    for (int y = y0; y < y1; y += step) {
      final yRow = y * yRowStride;
      final uvRow = (y >> 1) * uvRowStride;
      for (int x = x0; x < x1; x += step) {
        final yi = yRow + x;
        final uvi = uvRow + (x >> 1) * uvPixelStride;
        if (yi < 0 || yi >= yBytes.length) continue;
        if (uvi < 0 || uvi >= uBytes.length || uvi >= vBytes.length) continue;

        final yy = yBytes[yi].toDouble();
        final uu = uBytes[uvi].toDouble() - 128.0;
        final vv = vBytes[uvi].toDouble() - 128.0;

        sumL += yy;
        // Standard ordering: planes[1]=U, planes[2]=V
        sumRedUv += (yy + 1.402 * vv);
        // Swapped ordering fallback (treat U as V)
        sumRedVu += (yy + 1.402 * uu);
        n++;
      }
    }

    if (n <= 0) return 0.0;

    double norm01(double v) => (v.clamp(0.0, 255.0)) / 255.0;

    final luma = norm01(sumL / n);
    final redUv = norm01(sumRedUv / n);
    final redVu = norm01(sumRedVu / n);

    // Auto-probe first few seconds to choose the channel with the most variability.
    if (_ppgSignalMode == _PpgSignalMode.auto) {
      _probeRedUv.add(redUv);
      _probeRedVu.add(redVu);
      _probeLuma.add(luma);

      if (_probeRedUv.length >= _probeTarget) {
        double std(List<double> a) {
          if (a.length < 2) return 0.0;
          final m = a.reduce((p, c) => p + c) / a.length;
          double s = 0.0;
          for (final v in a) {
            final d = v - m;
            s += d * d;
          }
          return math.sqrt(s / math.max(1, a.length - 1));
        }

        final sUv = std(_probeRedUv);
        final sVu = std(_probeRedVu);
        final sL = std(_probeLuma);

        // Choose the most informative signal for this device/session.
        if (sUv >= sVu && sUv >= sL) {
          _ppgSignalMode = _PpgSignalMode.redUV;
        } else if (sVu >= sUv && sVu >= sL) {
          _ppgSignalMode = _PpgSignalMode.redVU;
        } else {
          _ppgSignalMode = _PpgSignalMode.luma;
        }

        _probeRedUv.clear();
        _probeRedVu.clear();
        _probeLuma.clear();
      }

      // While probing, use redUv as a reasonable default.
      return redUv;
    }

    switch (_ppgSignalMode) {
      case _PpgSignalMode.redUV:
        return redUv;
      case _PpgSignalMode.redVU:
        return redVu;
      case _PpgSignalMode.luma:
        return luma;
      case _PpgSignalMode.bgraRed:
        // Not expected here because BGRA branch returns early, but keep for completeness.
        return redUv;
      case _PpgSignalMode.auto:
        return redUv;
    }
  }

  Future<void> _startMeasurement() async {
    setState(() {
      _ppgError = null;
      _bpm = null;
      _rmssd = null;
      _sqi = null;
      _torchEnabled = false;
    });

    if (!await _ensureCameraPermission()) {
      setState(() => _ppgError = '未获得相机权限');
      return;
    }

    try {
      final cameras = await availableCameras();
      final back = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.isNotEmpty ? cameras.first : throw Exception('No camera'),
      );
      final ctrl = CameraController(
        back,
        ResolutionPreset.low,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );
      await ctrl.initialize();
      // turn torch on (finger over camera)
      try {
        await ctrl.setFlashMode(FlashMode.torch);
      } catch (_) {
        // not all devices support torch
      }
      // Best-effort: record whether torch is enabled (helps better error hints later).
      _torchEnabled = ctrl.value.flashMode == FlashMode.torch;

      // Try to reduce auto-adjust jitter (helps stabilize camera PPG).
      try {
        await ctrl.setExposureMode(ExposureMode.locked);
      } catch (_) {}
      try {
        await ctrl.setFocusMode(FocusMode.locked);
      } catch (_) {}

      _ppgStartMs = DateTime.now().millisecondsSinceEpoch;

      setState(() {
        _cam = ctrl;
        _measuring = true;
        _secondsLeft = 25;
        _samples.clear();
        _tsMs.clear();
        _ppgSignalMode = _PpgSignalMode.auto;
        _probeRedUv.clear();
        _probeRedVu.clear();
        _probeLuma.clear();
      });

      // collect frames
      await ctrl.startImageStream((img) {
        if (!_measuring) return;
        final now = DateTime.now().millisecondsSinceEpoch;
        if (now - _ppgStartMs < _ppgWarmupMs) return; // warmup discard
        final mean = _extractPpgSignal(img);
        _samples.add(mean);
        _tsMs.add(now);
      });

      _ticker?.cancel();
      _ticker = Timer.periodic(const Duration(seconds: 1), (t) async {
        if (!mounted) return;
        if (_secondsLeft <= 1) {
          t.cancel();
          await _finishMeasurement();
        } else {
          setState(() => _secondsLeft -= 1);
        }
      });
    } catch (e) {
      setState(() {
        _ppgError = '启动测量失败：$e';
        _measuring = false;
      });
      await _stopCamera();
    }
  }

  Future<void> _finishMeasurement() async {
    setState(() => _measuring = false);

    // stop stream & torch
    await _stopCamera();

    if (_samples.length < 100 || _tsMs.length != _samples.length) {
      setState(() => _ppgError = '采样不足，请保持手指稳定并重试');
      return;
    }

    // Estimate sample rate from timestamps
    final dtTotal = (_tsMs.last - _tsMs.first).clamp(1, 1 << 31);
    final fs = (_samples.length - 1) * 1000.0 / dtTotal;
    if (fs < 10 || fs > 90) {
      setState(() => _ppgError = '采样帧率异常（$fs Hz），请重试');
      return;
    }

    // Detrend + normalize
    final mean = _samples.reduce((a, b) => a + b) / _samples.length;
    final x0 = _samples.map((v) => v - mean).toList(growable: false);
    final filt = _ppg.bandpass(x0, fs);
    final sm = _ppg.movingAverage(filt, (fs * 0.15).round());
    // Peak detection can fail on some devices if the criteria are too strict.
    // Use a small adaptive fallback so we can still obtain a usable HR estimate
    // (and then gate reliability via SQI).
    List<int> peaks = _ppg.findPeaks(sm, fs: fs, k: 0.60);
    if (peaks.length < 3) {
      final p2 = _ppg.findPeaks(sm, fs: fs, k: 0.45);
      if (p2.length > peaks.length) peaks = p2;
    }
    if (peaks.length < 3) {
      final p3 = _ppg.findPeaks(sm, fs: fs, k: 0.35);
      if (p3.length > peaks.length) peaks = p3;
    }

var hrHrv = _ppg.computeHrAndHrv(peaks: peaks, fs: fs);
var sqi = _ppg.signalQuality(filtered: sm, peaks: peaks, fs: fs);

double? bpm = hrHrv['bpm'];
double? rmssd = hrHrv['rmssd'];

// Some devices produce an inverted waveform (pulse as trough).
// If HR is implausible, retry on inverted signal.
if (bpm == null || bpm < 35 || bpm > 200) {
  final smInv = sm.map((v) => -v).toList(growable: false);
  List<int> peaksInv = _ppg.findPeaks(smInv, fs: fs, k: 0.60);
  if (peaksInv.length < 3) {
    final p2 = _ppg.findPeaks(smInv, fs: fs, k: 0.45);
    if (p2.length > peaksInv.length) peaksInv = p2;
  }
  if (peaksInv.length < 3) {
    final p3 = _ppg.findPeaks(smInv, fs: fs, k: 0.35);
    if (p3.length > peaksInv.length) peaksInv = p3;
  }

  final hrHrvInv = _ppg.computeHrAndHrv(peaks: peaksInv, fs: fs);
  final bpmInv = hrHrvInv['bpm'];
  if (bpmInv != null && bpmInv >= 35 && bpmInv <= 200) {
    peaks = peaksInv;
    hrHrv = hrHrvInv;
    sqi = _ppg.signalQuality(filtered: smInv, peaks: peaksInv, fs: fs);
    bpm = bpmInv;
    rmssd = hrHrvInv['rmssd'];
  }
}


    // Hard failure: no plausible HR.
if (bpm == null || bpm < 35 || bpm > 200) {
  // Heuristic to provide more actionable hints:
  // - If raw signal is almost flat, it's usually due to not covering lens/torch,
  //   too much ambient light, or torch not available.
  double range0(List<double> xs) {
    if (xs.isEmpty) return 0.0;
    final maxV = xs.reduce(math.max);
    final minV = xs.reduce(math.min);
    return (maxV - minV).abs();
  }

  final rawRange = range0(_samples);
  String hint;
  if (!_torchEnabled && rawRange < 0.8) {
    hint = '当前设备可能未开启/不支持持续闪光灯，且信号几乎无变化；请在更暗环境下轻压覆盖镜头并重试。';
  } else if (rawRange < 0.8) {
    hint = '信号几乎无变化：请确保手指同时覆盖镜头和闪光灯、环境光较暗、不要用力挤压。';
  } else {
    hint = '未能识别到稳定心率：请保持手指不动、轻压覆盖镜头和闪光灯、避免漏光后重试。';
  }

  setState(() {
    _ppgError = hint;
    _bpm = null;
    _rmssd = null;
    _sqi = sqi;
  });
  return;
}

    // Soft failure / warning by SQI: show HR but gate HRV & show warning.
    final double sqiClamped = sqi.clamp(0.0, 1.0);
    final bool okForHr = sqiClamped >= 0.25;
    final bool okForHrv = sqiClamped >= 0.35;

    // Clamp HRV to a plausible range to avoid misleading extremes.
    final rmssdClamped = (!okForHrv || rmssd == null) ? null : rmssd.clamp(5.0, 200.0).toDouble();

    setState(() {
      _bpm = okForHr ? bpm : null;
      _rmssd = rmssdClamped;
      _sqi = sqiClamped;
      _ppgError = okForHr
          ? (okForHrv ? null : '信号质量偏低（SQI=${sqiClamped.toStringAsFixed(2)}），心率仅供参考；建议保持更稳定后再测')
          : '信号质量不足（SQI=${sqiClamped.toStringAsFixed(2)}），请保持手指稳定、轻压覆盖镜头和闪光灯后重试';
    });
  }

  Future<void> _stopCamera() async {
    final ctrl = _cam;
    _cam = null;
    if (ctrl == null) return;
    try {
      // Some devices keep the torch on if we only dispose the controller.
      // We therefore try to turn it off both before and after stopping the stream.
      try {
        await ctrl.setFlashMode(FlashMode.off);
      } catch (_) {}

      try {
        if (ctrl.value.isStreamingImages) {
          await ctrl.stopImageStream();
        }
      } catch (_) {}

      try {
        await ctrl.setFlashMode(FlashMode.off);
      } catch (_) {}

      await ctrl.dispose();
    } catch (_) {
      // ignore
    }
  }

  double _meanLumaFromYuv420(CameraImage img) {
    // Finger-on-camera PPG is very sensitive to motion and non-uniform lighting.
    // Sampling a small center ROI (rather than the whole frame) usually reduces
    // noise from edges and improves stability.
    final plane = img.planes[0]; // Y plane (luma)
    final bytes = plane.bytes;
    if (bytes.isEmpty) return 0.0;

    final int w = img.width;
    final int h = img.height;
    final int rowStride = plane.bytesPerRow;

    final int x0 = (w * 0.35).floor();
    final int x1 = (w * 0.65).floor();
    final int y0 = (h * 0.35).floor();
    final int y1 = (h * 0.65).floor();

    final int xStep = math.max(1, ((x1 - x0) / 50).floor());
    final int yStep = math.max(1, ((y1 - y0) / 50).floor());

    int sum = 0;
    int cnt = 0;
    final int len = bytes.length;
    for (int y = y0; y < y1; y += yStep) {
      final int row = y * rowStride;
      for (int x = x0; x < x1; x += xStep) {
        final int idx = row + x;
        if (idx >= 0 && idx < len) {
          sum += bytes[idx];
          cnt++;
        }
      }
    }
    if (cnt == 0) return 0.0;
    return sum / cnt;
  }


  // =======================
  // Fitbit
  // =======================

  Future<FitbitClient?> _fitbitClient() async {
    final id = (await _kv.getString('fitbit_client_id'))?.trim() ?? '';
    final sec = (await _kv.getString('fitbit_client_secret'))?.trim() ?? '';
    if (id.isEmpty || sec.isEmpty) return null;
    return FitbitClient(clientId: id, clientSecret: sec);
  }

  Future<void> _connectFitbit() async {
    final client = await _fitbitClient();
    if (client == null) {
      if (!mounted) return;
      Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const FitbitSettingsPage()));
      return;
    }
    setState(() {
      _fitbitSyncing = true;
      _fitbitStatus = '正在连接 Fitbit…';
    });
    try {
      await client.connect();
      setState(() => _fitbitStatus = '已连接');
    } catch (e) {
      setState(() => _fitbitStatus = '连接失败：$e');
    } finally {
      if (mounted) setState(() => _fitbitSyncing = false);
    }
  }

  Future<void> _syncFitbitToday() async {
    final client = await _fitbitClient();
    if (client == null) {
      if (!mounted) return;
      Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const FitbitSettingsPage()));
      return;
    }
    setState(() {
      _fitbitSyncing = true;
      _fitbitStatus = '同步今日数据…';
    });
    try {
      await client.syncToday();
      final now = DateTime.now();
      final date = '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      final caches = await _fitbitDao.listCachesForDate(date);
      final endpoints = <String>[];
      for (final c in caches) {
        final ep = (c['endpoint'] ?? '')?.toString() ?? '';
        if (ep.isNotEmpty) endpoints.add(ep);
      }
      endpoints.sort();
      final metrics = await FitbitMetrics.load(dao: _fitbitDao, date: date);
      setState(() {
        _fitbitCacheCount = caches.length;
        _fitbitCachedEndpoints = endpoints.toSet().toList(growable: false);
        final hasAny = metrics.restingHeartRate != null ||
            metrics.currentHeartRate != null ||
            metrics.hrvRmssdMs != null ||
            metrics.sleepMinutes != null ||
            metrics.breathingRate != null;
        _fitbitMetrics = hasAny ? metrics : null;
        _fitbitStatus = '同步完成（${caches.length} 项）';
      });
    } catch (e) {
      setState(() => _fitbitStatus = '同步失败：$e');
    } finally {
      if (mounted) setState(() => _fitbitSyncing = false);
    }
  }

  // =======================
  // Save record
  // =======================

  Future<void> _save() async {
    final raw = _stai6Raw();
    final prorated = _stai6Prorated();
    final inputs = ArousalInputs(
      stai6Prorated: prorated,
      arousal0To100: _arousal,
      valence0To100: _valence,
      demand0To100: _demand,
      resources0To100: _resources,
      distress0To100: _distress,
      ppgBpm: _bpm,
      ppgRmssdMs: _rmssd,
      ppgSignalQuality: _sqi,
      fitbit: _fitbitMetrics,
      baselineRestingHr: _baselineRestingHr,
      baselineRmssdMs: _baselineRmssdMs,
    );
    final res = ArousalModel.compute(inputs);
    _lastComputed = res;
    await _dao.insertRecord(
      timestampMs: DateTime.now().millisecondsSinceEpoch,
      stai6Score: raw,
      stai6Prorated: prorated,
      arousal0To100: _arousal,
      valence0To100: _valence,
      demand0To100: _demand,
      resources0To100: _resources,
      distress0To100: _distress,
      bpm: _bpm,
      rmssdMs: _rmssd,
      signalQuality: _sqi,
      arousal0To10: res.arousal0To10,
      confidence0To1: res.confidence0To1,
      subjectiveIndex0To1: res.subjectiveIndex0To1,
      physiologicalIndex0To1: res.physiologicalIndex0To1,
      modelVersion: kArousalModelVersion,
      modelExplain: res.explanation,
      warningsJson: res.warningsJson(),
      fitbitRestingBpm: _fitbitMetrics?.restingHeartRate,
      fitbitCurrentBpm: _fitbitMetrics?.currentHeartRate,
      fitbitHrvRmssdMs: _fitbitMetrics?.hrvRmssdMs,
      fitbitBreathingRate: _fitbitMetrics?.breathingRate,
      fitbitSleepMinutes: _fitbitMetrics?.sleepMinutes,
      fitbitSleepEfficiency: _fitbitMetrics?.sleepEfficiency,
      fitbitSteps: _fitbitMetrics?.steps,
      fitbitSpo2Avg: _fitbitMetrics?.spo2Avg,
      fitbitSkinTempDev: _fitbitMetrics?.skinTempDeviation,
      fitbitActiveZoneMinutes: _fitbitMetrics?.activeZoneMinutes,
      fitbitCardioScore: _fitbitMetrics?.cardioScore,
      zone: res.zoneLabel,
      note: null,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存测评记录')));
    await _reloadBaselinesAndFitbit();
    if (mounted) setState(() {});
  }

  // =======================
  // UI
  // =======================

  @override
  Widget build(BuildContext context) {
    final inputs = ArousalInputs(
      stai6Prorated: _stai6Prorated(),
      arousal0To100: _arousal,
      valence0To100: _valence,
      demand0To100: _demand,
      resources0To100: _resources,
      distress0To100: _distress,
      ppgBpm: _bpm,
      ppgRmssdMs: _rmssd,
      ppgSignalQuality: _sqi,
      fitbit: _fitbitMetrics,
      baselineRestingHr: _baselineRestingHr,
      baselineRmssdMs: _baselineRmssdMs,
    );
    final res = ArousalModel.compute(inputs);
    _lastComputed = res;
    final advice = _zoneAdvice(res.zoneLabel);
    return Scaffold(
      appBar: AppBar(
        title: const Text('改变 · 心理自助'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {
              Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const FitbitSettingsPage()));
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionTitle('主观评估（更科学）'),
          const SizedBox(height: 8),
          _buildStai6(),
          const SizedBox(height: 12),
          _buildAffectiveSlider(),
          const SizedBox(height: 12),
          _buildZoneSelfCheck(),
          const SizedBox(height: 20),
          _sectionTitle('客观测量（摄像头 PPG）'),
          const SizedBox(height: 8),
          _buildPpgCard(),
          const SizedBox(height: 16),
          _sectionTitle('可穿戴设备（Fitbit，可选）'),
          const SizedBox(height: 8),
          _buildFitbitCard(),
          const SizedBox(height: 16),
          _sectionTitle('结果'),
          const SizedBox(height: 8),
          _buildResult(res, advice),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_outlined),
            label: const Text('保存本次测评'),
          ),
          const SizedBox(height: 8),
          const Text(
            '免责声明：本功能仅用于情绪/压力自助与习惯养成参考，不用于医学诊断。\n若出现持续强烈不适或自伤想法，请及时求助专业机构/紧急电话。',
            style: TextStyle(color: Colors.black54, height: 1.4, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700));
  }

  Widget _buildStai6() {
    final items = const [
      '我感到平静',
      '我感到紧张',
      '我感到心烦/不安',
      '我感到放松',
      '我感到满足',
      '我感到担忧',
    ];
    final opts = const ['一点也不', '有一点', '相当', '非常'];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('STAI-6（状态焦虑短表，最近“此刻”）', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            const Text('每题 1-4 分。系统会对正向题做反向计分，并换算到 20-80 的 STAI 区间。', style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
            const SizedBox(height: 8),
            for (int i = 0; i < items.length; i++) ...[
              Text(items[i], style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 8,
                children: [
                  for (int k = 0; k < 4; k++)
                    ChoiceChip(
                      label: Text(opts[k]),
                      selected: _stai6[i] == (k + 1),
                      onSelected: (_) => setState(() => _stai6[i] = (k + 1)),
                    ),
                ],
              ),
              const Divider(height: 18),
            ],
            Text('STAI-6 原始分：${_stai6Raw()}（6-24）  ·  换算：${_stai6Prorated().toStringAsFixed(1)}（20-80）',
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildAffectiveSlider() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Affective Slider（移动端情绪自评）', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            const Text('用两条滑杆快速评估：唤醒程度（强度）与愉悦程度（正/负）。', style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [Text('😴 低唤醒'), Text('唤醒'), Text('😳 高唤醒')],
            ),
            Slider(
              value: _arousal,
              min: 0,
              max: 100,
              divisions: 100,
              label: _arousal.round().toString(),
              onChanged: (v) => setState(() => _arousal = v),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [Text('🙁 负性'), Text('愉悦'), Text('🙂 正性')],
            ),
            Slider(
              value: _valence,
              min: 0,
              max: 100,
              divisions: 100,
              label: _valence.round().toString(),
              onChanged: (v) => setState(() => _valence = v),
            ),
          ],
        ),
      ),
    );
  }


  Widget _buildZoneSelfCheck() {
    final gap = ((_demand - _resources) / 100.0).clamp(-1.0, 1.0);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('三区自评（舒适区 / 学习区 / 恐慌区）', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            const Text(
              '''用“需求-资源”与“困扰强度”来刻画：
• 需求/挑战：事情对你的压力/难度
• 资源/掌控：你感觉自己能否应对
• 困扰强度：此刻的不适/紧张有多强（SUDS）
系统会把它们与 STAI-6、唤醒以及心率/HRV 结合，给出区间判断。''',
              style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4),
            ),
            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [Text('轻松'), Text('需求/挑战'), Text('很难')],
            ),
            Slider(
              value: _demand,
              min: 0,
              max: 100,
              divisions: 100,
              label: _demand.round().toString(),
              onChanged: (v) => setState(() => _demand = v),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [Text('无把握'), Text('资源/掌控'), Text('很有把握')],
            ),
            Slider(
              value: _resources,
              min: 0,
              max: 100,
              divisions: 100,
              label: _resources.round().toString(),
              onChanged: (v) => setState(() => _resources = v),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [Text('几乎没有'), Text('困扰强度'), Text('非常强')],
            ),
            Slider(
              value: _distress,
              min: 0,
              max: 100,
              divisions: 100,
              label: _distress.round().toString(),
              onChanged: (v) => setState(() => _distress = v),
            ),

            const SizedBox(height: 6),
            Text(
              '挑战-资源差距：${(gap * 10).toStringAsFixed(1)}/10（越大越可能“超载”）',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }


  Widget _buildPpgCard() {
    final ctrl = _cam;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('用指腹轻盖住后置摄像头与闪光灯，保持稳定约 20 秒。', style: TextStyle(height: 1.4)),
            const SizedBox(height: 10),
            if (ctrl != null && ctrl.value.isInitialized)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AspectRatio(
                  aspectRatio: ctrl.value.aspectRatio,
                  child: CameraPreview(ctrl),
                ),
              )
            else
              Container(
                height: 160,
                decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(12)),
                alignment: Alignment.center,
                child: const Text('相机预览'),
              ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _measuring ? null : _startMeasurement,
                    icon: const Icon(Icons.favorite_border),
                    label: Text(_measuring ? '测量中… $_secondsLeft s' : '开始测量'),
                  ),
                ),
                const SizedBox(width: 12),
                OutlinedButton(
                  onPressed: _measuring
                      ? () async {
                          _ticker?.cancel();
                          await _finishMeasurement();
                        }
                      : null,
                  child: const Text('提前结束'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_ppgError != null)
              Text(_ppgError!, style: const TextStyle(color: Colors.redAccent, height: 1.3)),
            Wrap(
              spacing: 10,
              runSpacing: 8,
              children: [
                _metricChip('心率', _bpm == null ? '--' : '${_bpm!.toStringAsFixed(1)} bpm'),
                _metricChip('HRV(RMSSD)', _rmssd == null ? '--' : '${_rmssd!.toStringAsFixed(1)} ms'),
                _metricChip('信号质量', _sqi == null ? '--' : 'SQI ${_sqi!.toStringAsFixed(2)}'),
              ],
            ),
            const SizedBox(height: 8),
            const Text('提示：若结果波动大，多数是因为按压不稳/漏光/手指移动；请“轻压覆盖”，不要用力挤压。',
                style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
          ],
        ),
      ),
    );
  }

  Widget _metricChip(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(color: const Color(0xFFF7F7F7), borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _buildFitbitCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _fitbitSyncing ? null : _connectFitbit,
                    icon: const Icon(Icons.link),
                    label: const Text('连接 Fitbit'),
                  ),
                ),
                const SizedBox(width: 12),
                OutlinedButton(
                  onPressed: _fitbitSyncing ? null : _syncFitbitToday,
                  child: const Text('同步今日'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_fitbitStatus != null)
              Text(_fitbitStatus!, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),
            if (_fitbitCacheCount > 0)
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                childrenPadding: const EdgeInsets.only(bottom: 6),
                title: Text('已同步数据源（$_fitbitCacheCount 项）', style: const TextStyle(fontSize: 14)),
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _fitbitCachedEndpoints.take(16).map((e) => Chip(label: Text(e, style: const TextStyle(fontSize: 12)))).toList(growable: false),
                  ),
                  if (_fitbitCachedEndpoints.length > 16)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text('…以及其他 ${_fitbitCachedEndpoints.length - 16} 项', style: const TextStyle(color: Colors.black54, fontSize: 12)),
                    ),
                ],
              ),

            const Text(
              '同步后会把 Fitbit 的原始 JSON 缓存到本地数据库，用于后续综合评估（睡眠 HRV、心率趋势、活动量等）。',
              style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResult(ArousalResult res, String advice) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '综合唤醒 ${res.arousal0To10.toStringAsFixed(1)}/10',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                Text(
                  '置信度 ${(res.confidence0To1 * 100).toStringAsFixed(0)}%',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 6),
            LinearProgressIndicator(
              value: (res.arousal0To10 / 10.0).clamp(0.0, 1.0),
              minHeight: 8,
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 8,
              children: [
                _metricChip('区间', res.zoneLabel),
                _metricChip('主观', '${(res.subjectiveIndex0To1 * 10).toStringAsFixed(1)}/10'),
                _metricChip('客观', '${(res.physiologicalIndex0To1 * 10).toStringAsFixed(1)}/10'),
                _metricChip('需求', '${(_demand / 10).toStringAsFixed(1)}/10'),
                _metricChip('资源', '${(_resources / 10).toStringAsFixed(1)}/10'),
                _metricChip('困扰', '${(_distress / 10).toStringAsFixed(1)}/10'),
              ],
            ),
            const SizedBox(height: 10),
            Text(advice, style: const TextStyle(height: 1.4)),
            const SizedBox(height: 10),
            Text(res.explanation, style: const TextStyle(color: Colors.black87, fontSize: 12, height: 1.4)),
            if (res.warnings.isNotEmpty) ...[
              const SizedBox(height: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: res.warnings
                    .map((w) => Padding(
                          padding: const EdgeInsets.only(top: 2),
                          child: Text('• $w', style: const TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
                        ))
                    .toList(growable: false),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              children: [
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const ChangeSelfHelpReportPage()));
                  },
                  icon: const Icon(Icons.show_chart_outlined),
                  label: const Text('趋势报告'),
                ),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(CupertinoPageRoute(builder: (_) => ChangeInterventionPage(zone: res.zoneLabel, arousal0To10: res.arousal0To10)));
                  },
                  icon: const Icon(Icons.self_improvement_outlined),
                  label: const Text('干预建议'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
