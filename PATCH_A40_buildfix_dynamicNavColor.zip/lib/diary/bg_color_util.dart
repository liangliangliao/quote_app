import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Utilities to derive a solid color from a background image.
///
/// Why:
/// On Android 3-button navigation, the system navigation bar area cannot reliably
/// show the app's background image. Even with transparent nav bars, the system may
/// apply a contrast scrim. A robust approach is to compute a representative solid
/// color from the user's background image and use that for the navigation bar.
class BgColorUtil {
  const BgColorUtil._();

  /// Compute a representative solid color from an image at [imagePath].
  ///
  /// It decodes the image and samples pixels with a step to keep it fast.
  /// Returns [fallback] on any error.
  static Future<Color> computeRepresentativeColor(
    String imagePath, {
    Color fallback = const Color(0xFFDDEFE6), // mint-like fallback
    int sampleStep = 12,
  }) async {
    try {
      final file = File(imagePath);
      if (!await file.exists()) return fallback;

      final Uint8List bytes = await file.readAsBytes();
      final ui.Codec codec = await ui.instantiateImageCodec(bytes);
      final ui.FrameInfo frame = await codec.getNextFrame();
      final ui.Image image = frame.image;

      final ByteData? data =
          await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      if (data == null) return fallback;

      final Uint8List rgba = data.buffer.asUint8List();
      final int width = image.width;
      final int height = image.height;

      // Sample the lower part a bit more to better match what user sees near nav bar.
      final int yStart = (height * 2 / 3).floor();
      final int yEnd = height;

      int r = 0, g = 0, b = 0, count = 0;

      for (int y = yStart; y < yEnd; y += sampleStep) {
        final int rowBase = y * width * 4;
        for (int x = 0; x < width; x += sampleStep) {
          final int i = rowBase + x * 4;
          // rawRgba: R,G,B,A
          final int rr = rgba[i];
          final int gg = rgba[i + 1];
          final int bb = rgba[i + 2];
          final int aa = rgba[i + 3];

          // Ignore fully transparent pixels if present.
          if (aa == 0) continue;

          r += rr;
          g += gg;
          b += bb;
          count++;
        }
      }

      if (count == 0) return fallback;

      final int ar = (r / count).round().clamp(0, 255);
      final int ag = (g / count).round().clamp(0, 255);
      final int ab = (b / count).round().clamp(0, 255);

      return Color.fromARGB(255, ar, ag, ab);
    } catch (_) {
      return fallback;
    }
  }

  static Brightness iconBrightnessFor(Color bg) {
    return ThemeData.estimateBrightnessForColor(bg) == Brightness.dark
        ? Brightness.light
        : Brightness.dark;
  }
}
