
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';

import 'utils/debug_logger.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';

class BackgroundTasks {
  static Future<void> registerSelfCheck() async {
    final uniq = 'bg_selfcheck_next';
    try { await Workmanager().cancelByUniqueName(uniq); } catch (_) {}
    await Workmanager().registerOneOffTask(
      uniq, 'bg_selfcheck',
      initialDelay: const Duration(minutes: 2),
      existingWorkPolicy: ExistingWorkPolicy.replace,
    );
    await DLog.i('BG','已注册自检 (~2m)');
  }

  @pragma('vm:entry-point')
  static Future<void> selfCheckAlarmCallback() async {
    await _runSelfCheck();
  }
}

@pragma('vm:entry-point')
Future<void> selfCheckAlarmCallback() async {
  await _runSelfCheck();
}

Future<void> _runSelfCheck() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();

    await DLog.i('BG', '自检开始');
    await SchedulerService.callback();
    await SchedulerService.scheduleNextForAll();

    // 继续安排下一次后台自检（用 WM，避免平台差异）
    final uniq = 'bg_selfcheck_next';
    try { await Workmanager().cancelByUniqueName(uniq); } catch (_) {}
    await Workmanager().registerOneOffTask(
      uniq, 'bg_selfcheck',
      initialDelay: const Duration(minutes: 2),
      existingWorkPolicy: ExistingWorkPolicy.replace,
    );
    await DLog.i('BG', '自检完成并已安排下次 (~2m)');
  } catch (e) {
    await DLog.e('BG', '自检异常: ' + e.toString());
  }
}
