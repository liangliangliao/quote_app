import 'package:flutter/material.dart';
import '../services/nasa_api_service.dart';

/// A simple detail page for displaying a single Astronomy Picture of the
/// Day. Shows the image (or a placeholder if the media type is not an
/// image) and its descriptive text. Users can scroll to read longer
/// explanations.
class ApodDetailPage extends StatelessWidget {
  const ApodDetailPage({
    super.key,
    required this.apod,
    this.translatedTitle,
    this.translatedExplanation,
  });

  final Apod apod;
  final String? translatedTitle;
  final String? translatedExplanation;

  @override
  Widget build(BuildContext context) {
    final imageUrl = apod.hdUrl ?? apod.url;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          (translatedTitle?.trim().isNotEmpty ?? false) ? translatedTitle! : apod.title,
          style: const TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Show the image if the media type is an image; otherwise
            // display a placeholder container with a message.
            if (apod.mediaType == 'image')
              Image.network(
                imageUrl,
                fit: BoxFit.cover,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return SizedBox(
                    height: 200,
                    child: Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                                (loadingProgress.expectedTotalBytes ?? 1)
                            : null,
                      ),
                    ),
                  );
                },
                errorBuilder: (context, error, stackTrace) {
                  return const SizedBox(
                    height: 200,
                    child: Center(child: Icon(Icons.broken_image)),
                  );
                },
              )
            else
              const SizedBox(
                height: 200,
                child: Center(
                  child: Icon(Icons.videocam_outlined, size: 48),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    (translatedTitle?.trim().isNotEmpty ?? false) ? translatedTitle! : apod.title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    apod.date,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    (translatedExplanation?.trim().isNotEmpty ?? false)
                        ? translatedExplanation!
                        : apod.explanation,
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}