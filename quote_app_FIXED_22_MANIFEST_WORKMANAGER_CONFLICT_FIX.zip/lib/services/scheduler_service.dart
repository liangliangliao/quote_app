
import 'dart:async';
import 'dart:math';
import 'package:workmanager/workmanager.dart';
import 'package:quote_app/data/dao.dart';
import 'package:quote_app/services/notification_service.dart';
import 'package:quote_app/services/openai_service.dart';
import 'package:quote_app/platform/native_scheduler.dart';
import 'package:quote_app/utils/run_context.dart';
import 'package:quote_app/data/dao.dart';

/// Backward-compat shim: some older branches may miss QuoteDao.peekCarouselNext.
/// Provide it via an extension that maps to carouselNextSequential.
extension QuoteDaoCompat on QuoteDao {
  Future<Map<String,dynamic>?> peekCarouselNext(String taskUid) {
    return carouselNextSequential(taskUid);
  }
}

class SchedulerService {
  static const int _kMaxFallbackAttempts = 3;
  static const int _kFallbackBackoffMin = 3;

  static Future<int> _cfgTtlMinutes() async {
    try { return await ConfigDao().getInt('ttl_minutes', 10); } catch (_) { return 10; }
  }
  static Future<int> _cfgFbMaxAttempts() async {
    try { return await ConfigDao().getInt('fb_max_attempts', _kMaxFallbackAttempts); } catch (_) { return _kMaxFallbackAttempts; }
  }
  static Future<int> _cfgFbBackoffMin() async {
    try { return await ConfigDao().getInt('fb_backoff_min', _kFallbackBackoffMin); } catch (_) { return _kFallbackBackoffMin; }
  }

  static Future<void> init() async {
    await NotificationService().initialize();
    // Register Workmanager one-off callback name by ensuring plugin initialized on app startup.
    try {
      // Workmanager is initialized in main.dart
    } catch (_) {
      // Ignore if already initialized.
    }
  }

  static Future<void> cancelNextForTask(String uid, {String? runKey, bool includeFallback = true}) async {
    // Cancel Native exact alarm and WM jobs with unique names containing uid/runKey
    final rk = runKey ?? '';
    try {
      await NativeScheduler.cancelByTag('am_$uid${rk.isNotEmpty ? "_$rk" : ""}');
    } catch (_) {}
    if (includeFallback) {
      try { await Workmanager().cancelByUniqueName('fb_next_${uid}_$rk'); } catch (_){}
      try { await Workmanager().cancelByUniqueName('wm_run_${uid}_$rk'); } catch (_){}
      try { await Workmanager().cancelByUniqueName('wm_after_am_${uid}_$rk'); } catch (_){}
    }
  }

  static Future<void> sendForTask(Map<String, dynamic> t, {String? runKey, DateTime? planned, String? source}) async {
    final uid = (t['uid'] ?? '').toString();
    final type = (t['type'] ?? 'manual').toString(); // 'manual' | 'auto' | 'carousel'
    final name = (t['name'] ?? '任务').toString();
    final avatar = (t['avatar'] ?? '').toString();

    Future<void> _notify({required String title, required String? body, required String? iconPath}) async {
      await NotificationService().show(title, body ?? '', androidSmallIcon: (iconPath?.isEmpty ?? true) ? null : iconPath);
    }

    if (type == 'manual') {
      final row = await QuoteDao().latestForTask(uid);
      final content = (row?['content'] ?? '').toString();
      if (content.isEmpty) return;
      await _notify(title: name, body: content, iconPath: avatar);
      if (row?['uid'] != null) await QuoteDao().markNotifiedByUid(row!['uid'].toString());
      return;
    }

    if (type == 'carousel') {
      final row = await QuoteDao().peekCarouselNext(uid);
      if (row == null) return;
      await _notify(title: name, body: (row['content'] ?? '').toString(), iconPath: (row['avatar'] ?? avatar).toString());
      if (row['uid'] != null) await QuoteDao().markNotifiedByUid(row['uid'].toString());
      return;
    }

    // auto
    final prompt = (t['prompt'] ?? '').toString();
    final model = await ConfigDao().getString('model', 'gpt-5');
    final apiKey = await ConfigDao().getString('api_key', '');
    final baseUrl = await ConfigDao().getString('api_base', '');

    final int MAX_TRIES = await ConfigDao().getInt('max_auto_tries', 10);
    for (int i = 0; i < MAX_TRIES; i++) {
      String text;
      try {
        text = await OpenAIService.generateQuote(prompt: prompt, model: model, apiKey: apiKey, baseUrl: baseUrl);
      } catch (e) {
        await LogDao().add(taskUid: uid, detail: '错误! ${e.toString()}');
        return;
      }
      final dup = await QuoteDao().existsSimilar(text, threshold: 0.90);
      if (dup) continue;
      final qUid = await QuoteDao().insertQuote(taskUid: uid, content: text, avatar: avatar, taskType: type);
      await LogDao().add(taskUid: uid, detail: '成功!');
      await _notify(title: name, body: text, iconPath: avatar);
      await QuoteDao().markNotifiedByUid(qUid);
      return;
    }
    await LogDao().add(taskUid: uid, detail: '错误! 连续调用api10次去重检验未通过！');
  }

  static Future<void> _triggerWmFallbackNow(String uid, String runKey) async {
    await _scheduleWmOneOff('fb_next_${uid}_$runKey', {'job':'wm_run','task_uid':uid,'run_key':runKey}, Duration.zero);
  }

  static Future<void> cancelWmFallbackForRun(String uid, String runKey) async {
    try { await Workmanager().cancelByUniqueName('fb_next_${uid}_$runKey'); } catch (_){}
  }

  static Future<void> cancelForTask(String uid) async {
    await cancelNextForTask(uid, includeFallback: true);
  }

  static Future<void> _handleCallback(String uid, String runKey, {required String source}) async {
    final t = await TaskDao().findByUid(uid);
    if (t == null) return;
    await sendForTask(t, runKey: runKey, source: source);
    try { await cancelWmFallbackForRun(uid, runKey); } catch (_){}
  }

  static Future<void> wmRunTask(String taskUid, String runKey) async {
    await _handleCallback(taskUid, runKey, source: 'WM');
  }
  static Future<void> wmAfterAmTask(String taskUid, String runKey) async {
    await _handleCallback(taskUid, runKey, source: 'AM');
  }
  static Future<void> catchupIfMissed() async {
    // no-op minimal implementation
  }

  static String _runKeyForPlanned(DateTime planned) {
    return planned.toIso8601String().replaceAll(':', '').replaceAll('-', '').replaceAll('.', '');
  }

  static DateTime? _computeNext(Map<String, dynamic> t) {
    // simplistic: use 'start_time' HH:mm if exists, otherwise now + 1 minute
    final st = (t['start_time'] ?? '').toString();
    final next = _parseTimeOrToday(st);
    return next ?? DateTime.now().add(const Duration(minutes: 1));
  }

  static DateTime? _parseTimeOrToday(String st) {
    if (st.isEmpty) return null;
    final now = DateTime.now();
    final parts = st.split(':');
    if (parts.length < 2) return null;
    final h = int.tryParse(parts[0]) ?? 0;
    final m = int.tryParse(parts[1]) ?? 0;
    var dt = DateTime(now.year, now.month, now.day, h, m);
    if (dt.isBefore(now)) dt = dt.add(const Duration(days: 1));
    return dt;
  }

  static Future<void> _scheduleWmOneOff(String uniqueName, Map<String, dynamic> input, Duration delay) async {
    await Workmanager().registerOneOffTask(uniqueName, uniqueName, inputData: input, initialDelay: delay);
  }
  /// Schedule the next WM run for a single task by uid.
  static Future<void> scheduleNextForTask(String uid) async {
    try {
      final t = await TaskDao().getByUid(uid);
      if (t == null) return;
      final st = (t['start_time'] ?? t['time'] ?? '').toString();
      final planned = _parseTimeOrToday(st);
      if (planned == null) return;
      final runKey = _runKeyForPlanned(planned);
      final uniq = 'wm_run_${uid}_$runKey';
      await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, planned.difference(DateTime.now()));
    } catch (e) {
      await LogDao().add(taskUid: uid, detail: 'scheduleNextForTask error: ${e.toString()}');
    }
  }

  /// Schedule WM runs for all tasks (e.g., on app start).
  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      final uid = (t['uid'] ?? '').toString();
      if (uid.isEmpty) continue;
      await scheduleNextForTask(uid);
    }
  }

}