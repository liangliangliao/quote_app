
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../platform/native_scheduler.dart';
import '../platform/perm_helper.dart';
import 'task_runner.dart';

class SchedulerService {
  static String _wmUniqueBase(String uid, String runKey) => 'wm_run_'+uid+'_'+runKey;
  static String _wmUniqueNormal(String uid, String runKey) => _wmUniqueBase(uid, runKey) + '_N';
  static String _wmUniqueFallback(String uid, String runKey, int attempt) => _wmUniqueBase(uid, runKey) + '_FB_' + attempt.toString();
  static int _alarmId(String uid, String runKey) {
    return (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;
  }
  static String _runKeyFromTime(DateTime t) {
    return DateFormat('yyyyMMdd_HHmm').format(t);
  }

  static Future<void> init() async { /* no-op: Workmanager.initialize is handled in main.dart */ }

  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final start = (t['start_time'] ?? '09:00').toString();
    final now = DateTime.now();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length>1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (!next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }


  
  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);
    final now = DateTime.now();
    final diff = next.difference(now);
    final normalDelay = diff.isNegative ? Duration.zero : diff;

    // --- AM: guarded by exact-alarm permission ---
    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (ok) {
        await NativeScheduler.scheduleExactAt(
          id: _alarmId(uid, runKey),
          epochMs: next.millisecondsSinceEpoch,
          payload: {'uid': uid, 'runKey': runKey, 'chan':'am', 'attempt': 1},
        );
        await DLog.i('SCH', 'AM 注册完成 uid='+uid+' am_id='+_alarmId(uid, runKey).toString()+' run='+runKey);
      } else {
        await DLog.w('SCH', 'AM 权限未授予，跳过AM注册（走WM兜底）');
      }
    } catch (e) {
      await DLog.w('SCH','AM 注册失败，忽略: '+e.toString());
    }

    // --- WM normal: at 'next' (or immediate if equal/past) ---
    try {
      final _uniqueN = _wmUniqueNormal(uid, runKey);
      await Workmanager().registerOneOffTask(
        _uniqueN,
        'wm_task',
        initialDelay: normalDelay,
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'normal', 'attempt': 1},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 正常注册完成 uid='+uid+' wm_unique='+_uniqueN+' run='+runKey+' delay='+normalDelay.inSeconds.toString()+'s');
    } catch (e) {
      await DLog.e('SCH','WM 正常注册失败: '+e.toString());
    }

    // --- WM fallback: +2min ---
    try {
      final _uniqueFB1 = _wmUniqueFallback(uid, runKey, 1);
      await Workmanager().registerOneOffTask(
        _uniqueFB1,
        'wm_task',
        initialDelay: normalDelay + const Duration(minutes: 2),
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'fallback', 'attempt': 1},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+_uniqueFB1+' run='+runKey);
    } catch (e) {
      await DLog.e('SCH','WM 兜底注册失败: '+e.toString());
    }
  }

  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      await scheduleNextForTask((t['task_uid'] ?? '').toString());
    }
  }

  static Future<void> cancelNextForTask(String uid) async {
    try { await Workmanager().cancelAll(); } catch (_) {}
    try { await NativeScheduler.cancel(0); } catch (_) {}
  }

  
  static Future<void> wmRunTask(String uid, String? runKey, {String? chan, int attempt = 1}) async {
    final rk = (runKey ?? _runKeyFromTime(DateTime.now()));
    bool ok = false;
    try {
      ok = await TaskRunner.run(uid);
    } catch (e) {
      ok = false;
    }

    // 成功：取消兜底 & 取消当前任务，并安排下一次时间
    if (ok) {
      await cancelWmFallback(uid, rk, 1); // 兜底1
      await cancelWmFallback(uid, rk, 2); // 兜底2（若存在）
      // 根据通道取消当前
      if ((chan ?? 'normal') == 'fallback') {
        await cancelWmFallback(uid, rk, attempt);
      } else {
        await cancelWmNormal(uid, rk);
      }
      // 更新并安排下一次
      await _updateNextAndReschedule(uid);
      return;
    }

    // 失败：仅取消当前，保留/重试兜底
    if ((chan ?? 'normal') == 'fallback') {
      if (attempt >= 2) {
        // 第二次兜底仍失败：取消自己，终止兜底
        await cancelWmFallback(uid, rk, attempt);
      } else {
        // 第一次兜底失败：取消自己并立即注册一次兜底2（立即）
        await cancelWmFallback(uid, rk, attempt);
        final _uniqueFB2 = _wmUniqueFallback(uid, rk, 2);
        try {
          await Workmanager().registerOneOffTask(
            _uniqueFB2, 'wm_task',
            initialDelay: Duration.zero,
            inputData: {'job':'wm_run','task_uid': uid, 'run_key': rk, 'chan':'fallback', 'attempt': 2},
            existingWorkPolicy: ExistingWorkPolicy.replace,
            tag: uid,
          );
          await DLog.w('SCH','WM 兜底1失败，已注册兜底2(立即) uid='+uid+' wm_unique='+_uniqueFB2+' run='+rk);
        } catch (e) {
          await DLog.e('SCH','注册兜底2失败: '+e.toString());
        }
      }
    } else {
      // 正常 WM 失败：取消自己并安排下一次（保留兜底1）
      await cancelWmNormal(uid, rk);
      await _updateNextAndReschedule(uid);
    }
  }

  static Future<void> callback([String? uid, String? runKey]) async {
    if (uid == null || uid.isEmpty) { return; }

    await TaskRunner.run(uid);
  }

  
  static Future<void> cancelAm(String uid, String runKey) async {
    try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
  }
  static Future<void> cancelWmByUnique(String uniqueName) async {
    try { await Workmanager().cancelByUniqueName(uniqueName); } catch (_) {}
  }
  static Future<void> cancelWmNormal(String uid, String runKey) async {
    await cancelWmByUnique(_wmUniqueNormal(uid, runKey));
  }
  static Future<void> cancelWmFallback(String uid, String runKey, int attempt) async {
    await cancelWmByUnique(_wmUniqueFallback(uid, runKey, attempt));
  }
static Future<void> catchupIfMissed() async {}
}
