class RunContext {
  // 标记当前是否来源于 WorkManager 回调
  static bool isFromWM = false;
  static void markFromWM() { isFromWM = true; }

  // 可扩展的运行态标记
  static bool isBackground = false;
}
