import 'dart:io';
import 'dart:ui' as ui;
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'tag_picker_page.dart';
import 'diary_dao.dart';
import 'weather.dart';
import '../data/db.dart';
import 'diary_text_controller.dart';

class EntryReaderPage extends StatefulWidget {
  final int notebookId;
  final int initialEntryId;
  const EntryReaderPage({super.key, required this.notebookId, required this.initialEntryId});

  @override
  State<EntryReaderPage> createState() => _EntryReaderPageState();
}

class _EntryReaderPageState extends State<EntryReaderPage> {

  Future<Size> _readImageSize(File f) async {
    final bytes = await f.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final img = frame.image;
    return Size(img.width.toDouble(), img.height.toDouble());
  }

  final GlobalKey _readerTextBoxKey = GlobalKey();
  final FocusNode _readerFocusNode = FocusNode();

  
void _handleDoubleTapDownReader(TapDownDetails d, TextEditingController ctrl) {
  final RenderBox? box = _readerTextBoxKey.currentContext?.findRenderObject() as RenderBox?;
  if (box == null) return;

  final Offset local = box.globalToLocal(d.globalPosition);
  final Size size = box.size;
  final String text = ctrl.text;
  final TextStyle baseStyle = Theme.of(context).textTheme.bodyLarge ?? const TextStyle(fontSize: 16);

  // 行高测量：仅用来估算点击位置是第几行。
  final TextPainter measurePainter = TextPainter(
    text: TextSpan(text: '示', style: baseStyle),
    textDirection: TextDirection.ltr,
    maxLines: 1,
  )..layout(maxWidth: size.width);
  final double lineHeight = measurePainter.preferredLineHeight;

  // 文本为空时，双击任意位置：自动补足若干空行，让光标出现在该行最左侧。
  if (text.isEmpty) {
    double dy = local.dy.clamp(0.0, size.height);
    int extraLines = (dy / lineHeight).floor();
    if (extraLines < 0) extraLines = 0;
    final String newText = extraLines > 0 ? '\n' * extraLines : '';
    final int caretOffset = newText.length;
    ctrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: caretOffset),
    );
    _readerFocusNode.requestFocus();
    return;
  }

  // 使用与编辑页相同的逻辑：如果 controller 支持自定义 buildTextSpan，
  // 则复用它，从而正确计算包含图片在内的整体高度。
  final InlineSpan span;
  if (ctrl is DiaryContentController) {
    span = ctrl.buildTextSpan(
      context: context,
      style: baseStyle,
      withComposing: false,
    );
  } else {
    span = TextSpan(text: text, style: baseStyle);
  }

  final TextPainter tp = TextPainter(
    text: span,
    textDirection: TextDirection.ltr,
    maxLines: null,
  )..layout(maxWidth: size.width);

  // 计算末尾光标的位置，用于判断是否点击在现有内容下方。
  final Offset endCaret = tp.getOffsetForCaret(
    TextPosition(offset: text.length),
    Rect.zero,
  );

  double dy = local.dy;
  if (dy < 0) dy = 0;

  // 点击在现有内容下方：根据距离自动补足若干空行，让光标落在新行行首。
  if (dy > endCaret.dy + lineHeight / 2) {
    final double extraDy = dy - endCaret.dy;
    int extraLines = (extraDy / lineHeight).ceil();
    if (extraLines < 1) extraLines = 1;
    final String newText = text + ('\n' * extraLines);
    ctrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
    _readerFocusNode.requestFocus();
    return;
  }

  final double maxDy = endCaret.dy;
  if (dy > maxDy) dy = maxDy;

  // 根据点击位置计算所在行，再把光标移动到该行的最左侧。
  final TextPosition pos = tp.getPositionForOffset(Offset(0, dy));
  final TextRange boundary = tp.getLineBoundary(pos);
  final int start = boundary.start.clamp(0, text.length);
  ctrl.selection = TextSelection.collapsed(offset: start);
  _readerFocusNode.requestFocus();
}
  int _totalCount = 0; int _globalIndex = 0;
  final _dao = DiaryDao();
  final _fmt = DateFormat('yyyy年MM月dd日 HH:mm');
  final _controller = PageController(initialPage: 1);
  final List<DiaryEntry> _pages = [];
  final Map<int, DateTime> _timeById = {};
  final Map<int, int?> _weatherById = {};
  final Map<int, List<int>> _tagIdsById = {};

  final Map<int, DiaryContentController> _contentCtrls = {};
  final Map<String, AudioPlayer> _players = {};
  final Map<String, ValueNotifier<bool>> _playing = {};
  int _index = 1; // keep in sync with PageController(initialPage: 1)

  String? _bgPath;
  double _bgOpacity = 0.25;

  
  
  Future<void> _saveIfChanged(DiaryEntry e, TextEditingController c) async {
    // 内容或元数据有变化才保存
    final t = _timeById[e.id] ?? DateTime.fromMillisecondsSinceEpoch(e.entryTime);
    final wc = _weatherById[e.id] ?? e.weatherCode;
    final changed = c.text != e.content || t.millisecondsSinceEpoch != e.entryTime || wc != e.weatherCode;
    if (!changed) return;

    final preview = _preview(c.text);
    final w = weatherByCode(wc);
    final updated = DiaryEntry(
      id: e.id,
      notebookId: e.notebookId,
      entryTime: t.millisecondsSinceEpoch,
      weatherCode: wc,
      weatherName: wc == null ? null : w.name,
      moodName: e.moodName,
      moodIcon: e.moodIcon,
      content: c.text,
      preview: preview,
      starred: e.starred,
    );
    final id = await _dao.upsertEntry(updated);
    final tags = _tagIdsById[e.id] ?? <int>[];
    await _dao.setTagsForEntry(id, tags);
    await _dao.touchNotebook(e.notebookId);
  }


  Future<void> _saveCurrentIfChanged() async {
    if (_pages.isEmpty) return;
    final i = _index;
    if (i <= 0 || i > _pages.length) return;
    final real = (i - 1).clamp(0, _pages.length - 1);
    final e = _pages[real];
          // 初始化页内可编辑元数据（时间/天气/标签）
          _timeById.putIfAbsent(e.id, () => DateTime.fromMillisecondsSinceEpoch(e.entryTime));
          _weatherById.putIfAbsent(e.id, () => e.weatherCode);
          if (!_tagIdsById.containsKey(e.id)) {
            _dao.tagsForEntry(e.id).then((list) {
              if (!mounted) return;
              setState(() { _tagIdsById[e.id] = list.map((t) => t.id).toList(); });
            });
          }

    final c = _contentCtrls[e.id];
    if (c != null) {
      await _saveIfChanged(e, c);
    }
  }

  String _preview(String content) {
    final lines = content.split(RegExp(r'\r?\n'));
    for (final raw in lines) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      if (line.startsWith('[图片]') || line.startsWith('[语音]')) continue;
      return line.length > 50 ? line.substring(0, 50) : line;
    }
    return '（空白日记）';
  }
@override
  void dispose() {
    for (final p in _players.values) {
      try { p.dispose(); } catch (_) {}
    }
    for (final n in _playing.values) {
      try { n.dispose(); } catch (_) {}
    }
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final db = await AppDatabase.instance();
    try {
      final rows = await db.rawQuery(
        "SELECT * FROM configs "
        "WHERE (diary_bg_image IS NOT NULL AND diary_bg_image != '') "
        "   OR diary_bg_opacity IS NOT NULL "
        "   OR (diary_pin IS NOT NULL AND diary_pin != '') "
        "ORDER BY id DESC LIMIT 1"
      );
      if (rows.isNotEmpty) {
        _bgPath = (rows.first['diary_bg_image'] ?? '') as String?;
        final op = rows.first['diary_bg_opacity'];
        if (op != null) _bgOpacity = double.tryParse(op.toString()) ?? _bgOpacity;
      }
    } catch (_) {}
    final e = await _dao.getEntry(widget.initialEntryId);
    final total = await _dao.countEntries(widget.notebookId);
    final pos = await _dao.positionOfEntry(widget.notebookId, widget.initialEntryId) ?? 0;
    if (e != null) setState(() { _pages.add(e); _totalCount = total; _globalIndex = pos; });
  }

  Widget _bgWrap(Widget child) {
    final bg = _bgPath;
    if (bg == null || bg.isEmpty) return child;
    final f = File(bg);
    if (!f.existsSync()) return child;
    return Stack(fit: StackFit.expand, children: [
      const ColoredBox(color: Colors.white),
      Opacity(opacity: (1.0 - _bgOpacity).clamp(0.0, 1.0), child: Image.file(f, fit: BoxFit.cover)),
      child,
    ]);
  }

  
  Future<bool?> _ensureNewer() async {
    if (_pages.isEmpty) return false;
    final first = _pages.first;
    final next = await _dao.neighbor(notebookId: widget.notebookId, cur: first, newer: true);
    if (next == null) {
      return false;
    }
    setState(() { _pages.insert(0, next); });
    return true;
  }
Future<bool?> _ensureOlder(int targetIndex) async {
    if (targetIndex < _pages.length) return true;
    final last = _pages.last;
    final next = await _dao.neighbor(notebookId: widget.notebookId, cur: last, newer: false);
    if (next == null) {
      
      
      if (mounted) _controller.jumpToPage(_index);
      return false;
    }
    setState(() => _pages.add(next));
    return true;
  }

  
Widget _buildContent(BuildContext context, String content) {
  final lines = content.split(RegExp(r'\r?\n'));
  final widgets = <Widget>[];
  final imgReg = RegExp(r'^\[图片\]\s*(.+)$');
  final audioReg = RegExp(r'^\[语音\]\s*(.+)$');

  for (final raw in lines) {
    final line = raw.trimRight();
    if (line.isEmpty) { continue; }

    final m1 = imgReg.firstMatch(line);
    final m2 = audioReg.firstMatch(line);

    if (m1 != null) {
      final path = m1.group(1)!;
      final f = File(path);
      if (f.existsSync()) {
        widgets.add(Padding(
          padding: EdgeInsets.zero,
          child: LayoutBuilder(
            builder: (context, constraints) {
              if (!f.existsSync()) return const SizedBox.shrink();
              final w = constraints.maxWidth;
              return ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: FutureBuilder<Size>(
                  future: _readImageSize(f),
                  builder: (context, snap) {
                    if (snap.hasData) {
                      final ar = snap.data!.width / snap.data!.height;
                      final h = w / (ar > 0 ? ar : 1);
                      return SizedBox(
                        width: w,
                        height: h,
                        child: Image.file(f, fit: BoxFit.cover),
                      );
                    }
                    return SizedBox(
                      width: w,
                      height: 180,
                      child: const ColoredBox(color: Color(0xFFF5F5F5)),
                    );
                  },
                ),
              );
            },
          ),
        ));
      } else {
        widgets.add(const SizedBox.shrink());
}
    } else if (m2 != null) {
      final path = m2.group(1)!;
      final p = _players.putIfAbsent(path, () => AudioPlayer());
      final playing = _playing.putIfAbsent(path, () => ValueNotifier<bool>(false));
      widgets.add(_InlineAudioTile(path: path, player: p, playing: playing));
    } else {
      widgets.add(Text(line, style: Theme.of(context).textTheme.bodyLarge));
    }
  }

  
  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets);
}

  // === Helpers to insert attachments into the inline marker model ===
  void _insertMarkerAtTopLines(TextEditingController ctrl, String marker, String path) {
    final base = ctrl.text;
    final lines = base.split(RegExp(r'\r?\n'));
    if (lines.isEmpty) { lines.add(''); }
    // Insert as early as possible: line 1 if empty, otherwise line 2; then 4, 6, ...
    int target = lines.isNotEmpty && lines[0].trim().isNotEmpty ? 1 : 0;
    while (true) {
      if (target >= lines.length) {
        while (lines.length <= target) { lines.add(''); }
      }
      if (lines[target].trim().isEmpty) break;
      target += 2;
    }
    lines.insert(target, '[$marker] ' + path);
    // Trim trailing empty lines to reduce extra vertical space in TextField
    while (lines.isNotEmpty && lines.last.trim().isEmpty && lines.length > target + 1) {
      lines.removeLast();
    }
    final newText = lines.join('\n');
    ctrl.text = newText;
    // Put cursor to the start to avoid showing the path as typed content.
    ctrl.selection = const TextSelection.collapsed(offset: 0);
    if (mounted) setState(() {});
  }

  Future<void> _insertImageFor(TextEditingController ctrl) async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;
    _insertMarkerAtTopLines(ctrl, '图片', path);
  }

  Future<void> _insertAudioFor(TextEditingController ctrl) async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res == null || res.files.isEmpty) return;
    final path = res.files.first.path;
    if (path == null) return;
    _insertMarkerAtTopLines(ctrl, '语音', path);
  }

  Future<void> _pickTagsFor(int entryId) async {
    final initial = _tagIdsById[entryId] ?? <int>[];
    final picked = await Navigator.push<List<int>>(context, MaterialPageRoute(
      builder: (_) => TagPickerPage(dao: _dao, initialSelected: initial),
    ));
    if (picked != null) {
      setState(() { _tagIdsById[entryId] = picked; });
    }
  }

Widget _attachmentsPreviewFor(String text) {
    final lines = text.split(RegExp(r'\r?\n'));
    final widgets = <Widget>[];
    final imgReg = RegExp(r'^\[图片\]\s*(.+)$');
    final audioReg = RegExp(r'^\[语音\]\s*(.+)$');
    for (final raw in lines) {
      final line = raw.trimRight();
      if (line.isEmpty) continue;
      final m1 = imgReg.firstMatch(line);
      final m2 = audioReg.firstMatch(line);
            if (m1 != null) {
        // 图片在正文中以内联方式展示，这里不再重复渲染。
        continue;
      } else if (m2 != null) {
        final path = m2.group(1)!;
        final p = _players.putIfAbsent(path, () => AudioPlayer());
        final playing = _playing.putIfAbsent(path, () => ValueNotifier<bool>(false));
        widgets.add(_InlineAudioTile(path: path, player: p, playing: playing));
      }
    }
    if (widgets.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets);
  }
@override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        await _saveCurrentIfChanged();
        try { Navigator.pop(context, true); } catch (_) {}
        return false;
      },
      child: _bgWrap(Scaffold(
        backgroundColor: (_bgPath == null || _bgPath!.isEmpty) ? Colors.white : Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: AppBar(title: const Text('日记'), backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0),
        body: SafeArea(
          child: PageView.builder(
            physics: EdgeLockPagePhysics(
              lockToStart: _totalCount > 0 && _globalIndex <= 0,
              lockToEnd: _totalCount > 0 && _globalIndex >= _totalCount - 1,
            ),
        controller: _controller,
        itemCount: _pages.length + 2,
        onPageChanged: (i) async {
          // left swipe -> older
          if (i == _pages.length + 1) {
            final ok = await _ensureOlder(i);
            if (ok == true) {
              setState(() { _index = _pages.length; _globalIndex = (_globalIndex + 1).clamp(0, _totalCount-1); });
            } else {
              
              
              if (mounted) _controller.jumpToPage(_pages.length);
            }
            return;
          }
          // right swipe -> newer
          if (i == 0) {
            final ok = await _ensureNewer();
            if (ok == true) {
              setState(() { _index = 1; _globalIndex = (_globalIndex - 1).clamp(0, _totalCount-1); });
              if (mounted) _controller.jumpToPage(1);
            } else {
              
              
              if (mounted) _controller.jumpToPage(1);
            }
            return;
          }
          final prev = _index; if (_pages.isNotEmpty && prev>0 && prev<=_pages.length) { final prevReal = (prev - 1).clamp(0, _pages.length-1); final ePrev = _pages[prevReal]; final cPrev = _contentCtrls[ePrev.id]; if (cPrev != null) { await _saveIfChanged(ePrev, cPrev); } }
          setState(() { _index = i; _globalIndex = (_globalIndex + (i - prev)).clamp(0, _totalCount-1); });
        },
        itemBuilder: (context, i) {
          // Map PageView index (with 2 sentinels) to _pages index
          if (_pages.isEmpty) return const SizedBox.shrink();
          if (i == 0 || i == _pages.length + 1) return const SizedBox.shrink();
          final real = (i - 1).clamp(0, _pages.length - 1);
          final e = _pages[real];
          final w = weatherByCode(e.weatherCode);
          final ctrl = _contentCtrls.putIfAbsent(e.id, () => DiaryContentController(text: e.content));
          return Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
            child: Stack(
              children: [
                Card(
                  color: Colors.transparent,
                  elevation: 0,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                DateTime base = _timeById[e.id] ?? DateTime.fromMillisecondsSinceEpoch(e.entryTime);
                                final date = await showDatePicker(context: context, initialDate: base, firstDate: DateTime(2000), lastDate: DateTime(2100));
                                if (date != null) {
                                  final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(base));
                                  final picked = DateTime(date.year, date.month, date.day, (time?.hour ?? base.hour), (time?.minute ?? base.minute));
                                  setState(() { _timeById[e.id] = picked; });
                                }
                              },
                              child: Row(
                                children: [
                                  const Icon(Icons.schedule, size: 18),
                                  const SizedBox(width: 6),
                                  Text(_fmt.format((_timeById[e.id] ?? DateTime.fromMillisecondsSinceEpoch(e.entryTime)))),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          DropdownButton<int>(
                            value: _weatherById[e.id] ?? e.weatherCode,
                            hint: const Text('天气'),
                            items: weatherOptions.map((w)=>DropdownMenuItem<int>(
                              value: w.code,
                              child: Row(children: [Icon(w.icon, size: 18), const SizedBox(width: 6), Text(w.name)]),
                            )).toList(),
                            onChanged: (v) => setState(() { _weatherById[e.id] = v; }),
                          ),
                          const SizedBox(width: 8),
                          if (e.moodIcon != null) Text(e.moodIcon!, style: const TextStyle(fontSize: 18)),
                          if (e.moodName != null) ...[ const SizedBox(width: 4), Text(e.moodName!), ],
                        ],
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
GestureDetector(
                                behavior: HitTestBehavior.translucent,
                                onTapDown: (d) => _handleDoubleTapDownReader(d, ctrl),
                                onDoubleTapDown: (d) => _handleDoubleTapDownReader(d, ctrl),
                                child: Container(
                                  key: _readerTextBoxKey,
                                  alignment: Alignment.topLeft,
                                  width: double.infinity,
                                  constraints: BoxConstraints(
                                    minHeight: MediaQuery.of(context).size.height,
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      TextField(
                                        controller: ctrl,
                                        focusNode: _readerFocusNode,
                                        maxLines: null,
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          isCollapsed: true,
                                          contentPadding: EdgeInsets.zero,
                                        ),
                                        onChanged: (_) {
                                          // Refresh inline previews (图片/语音) immediately.
                                          if (mounted) setState(() {});
                                        },
                                      ),
                                      const SizedBox(height: 8),
                                      _attachmentsPreviewFor(ctrl.text),
                                    ],
                                  ),
                                ),
                              ),
                            ],
),
                          ),
                        ),
                    ],
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: SafeArea(
                    top: false,
                    minimum: EdgeInsets.zero,
                    child: Row(
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Wrap(
                              spacing: 8,
                              children: (_tagIdsById[e.id] ?? const <int>[]).map((id) => Chip(
                                label: Text('标签#' + id.toString()),
                              )).toList(),
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: '插入语音',
                          onPressed: () => _insertAudioFor(ctrl),
                          icon: const Icon(Icons.mic_none),
                        ),
                        IconButton(
                          tooltip: '插入图片',
                          onPressed: () => _insertImageFor(ctrl),
                          icon: const Icon(Icons.image_outlined),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => _pickTagsFor(e.id),
                          icon: const Icon(Icons.label_outline),
                          label: const Text('标签'),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: SafeArea(
                    top: false,
                    minimum: EdgeInsets.zero,
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        color: Colors.black54,
                      ),
                      child: Text(
                        '${_globalIndex + 1}/$_totalCount',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );

        },
      )),
    )),
    );
  }
}

class _InlineAudioTile extends StatelessWidget {
  final String path;
  final AudioPlayer player;
  final ValueNotifier<bool> playing;
  const _InlineAudioTile({required this.path, required this.player, required this.playing});

  Future<void> _toggle(BuildContext context, bool isPlaying) async {
    try {
      if (isPlaying) {
        await player.pause();
        playing.value = false;
      } else {
        await player.play(DeviceFileSource(path));
        playing.value = true;
      }
    } catch (_) {
      playing.value = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: playing,
      builder: (context, isPlaying, _) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: IconButton(
          icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
          onPressed: () => _toggle(context, isPlaying),
        ),
        title: const Text('语音'),
        subtitle: const Text('点击播放'),
      ),
    );
  }
}


class EdgeLockPagePhysics extends ScrollPhysics {
  final bool lockToStart; // 锁定上一页（首条时）
  final bool lockToEnd;   // 锁定下一页（末条时）
  const EdgeLockPagePhysics({this.lockToStart=false, this.lockToEnd=false, ScrollPhysics? parent}) : super(parent: parent);

  @override
  EdgeLockPagePhysics applyTo(ScrollPhysics? ancestor) {
    return EdgeLockPagePhysics(lockToStart: lockToStart, lockToEnd: lockToEnd, parent: buildParent(ancestor));
  }

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) {
    // PageView：右滑通常 offset < 0，左滑 offset > 0
    if (lockToStart && offset < 0) return 0.0; // 首页禁止右滑
    if (lockToEnd && offset > 0) return 0.0;   // 末页禁止左滑
    return super.applyPhysicsToUserOffset(position, offset);
  }

  @override
  double applyBoundaryConditions(ScrollMetrics position, double value) {
    // value 是尝试滚动后的像素；position.pixels 是当前像素
    final delta = value - position.pixels;
    if (lockToStart && delta < 0) return delta; // 试图到上一页（像素减小）
    if (lockToEnd && delta > 0) return delta;   // 试图到下一页（像素增大）
    return super.applyBoundaryConditions(position, value);
  }
}

