package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.quote_app.data.DbRepository
import com.example.quote_app.schedule.NextTriggerCalculator
import com.example.quote_app.biz.Biz
import org.json.JSONObject

class NotifyWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val id = inputData.getInt("id", 0)
    val payload = inputData.getString("payload") ?: "{}"
    val o = JSONObject(payload)
    val uid = o.optString("uid", "")
    val runKey = o.optString("runKey", "")
    val title = o.optString("title", "提醒")
    val body = o.optString("body", "到点了")

    // 如果 payload 含 uid，则走完整 Java 业务；否则仅兜底通知
    if (uid.isNotEmpty()) {
      val entered = DbRepository.runGuardBegin(applicationContext, uid, runKey, "wm")
      if (!entered) return Result.success()
      try {
        val handled = Biz.run(applicationContext, uid)
        if (handled) {
          DbRepository.markLatestSuccess(applicationContext, uid)
          // 续排下一次
          val next = NextTriggerCalculator.compute(applicationContext, uid)
          if (next > 0) {
            NativeSchedulerK.scheduleExactWmCompat(applicationContext, id, next, payload)
          }
          // 主通道/WM 成功后，取消兜底 WM
          WorkManager.getInstance(applicationContext).cancelUniqueWork("wm_once_" + id)
          return Result.success()
        } else {
          // 业务未处理，允许 retry（按 WM 策略）
          return Result.retry()
        }
      } catch (t: Throwable) {
        DbRepository.log(applicationContext, uid, "WM任务异常: " + (t.message ?: "未知错误"))
        return Result.retry()
      } finally {
        DbRepository.runGuardEnd(applicationContext, uid, runKey, "wm")
      }
    } else {
      // 无 uid，仅兜底通知
      NotifyHelper.send(applicationContext, id, title, body, null)
      return Result.success()
    }
  }
}
