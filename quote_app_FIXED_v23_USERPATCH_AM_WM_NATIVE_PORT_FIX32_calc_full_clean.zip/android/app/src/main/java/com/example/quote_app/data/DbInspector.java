package com.example.quote_app.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class DbInspector {
    private static final String PREF_KEY = "alarm_contract_v2";

    public static final class Contract {
        public String dbPath;
        public String tasksSource;
        public String quotesSource;
        public Map<String,String> taskColMap = new HashMap<>();
        public Map<String,String> quoteColMap = new HashMap<>();
        public int version = 1;
    }

    public static Contract loadOrLightScan(Context ctx) {
        Contract c = loadFromPref(ctx);
        if (c != null) return c;
        c = new Contract();
        File dir = new File(ctx.getApplicationInfo().dataDir, "databases");
        if (dir.exists()) {
            File[] list = dir.listFiles();
            if (list != null) for (File f : list) {
                if (f.isFile() && f.getName().endsWith(".db")) { c.dbPath = f.getAbsolutePath(); break; }
            }
        }
        if (TextUtils.isEmpty(c.dbPath)) c.dbPath = ctx.getDatabasePath("app.db").getAbsolutePath();
        c.tasksSource = "tasks";
        c.quotesSource = "quotes";
        c.taskColMap.put("uid", "uid");
        c.taskColMap.put("title","title");
        c.taskColMap.put("content","content");
        c.taskColMap.put("trigger_at","trigger_at");
        c.quoteColMap.put("uid","task_uid");
        c.quoteColMap.put("content","content");
        saveToPref(ctx, c);
        return c;
    }

    private static Contract loadFromPref(Context ctx) {
        try {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
            String js = sp.getString(PREF_KEY, null);
            if (TextUtils.isEmpty(js)) return null;
            JSONObject o = new JSONObject(js);
            Contract c = new Contract();
            c.dbPath = o.optString("dbPath", null);
            c.tasksSource = o.optString("tasksSource", null);
            c.quotesSource = o.optString("quotesSource", null);
            JSONObject tm = o.optJSONObject("taskColMap");
            if (tm != null) for (String k : tm.keySet()) c.taskColMap.put(k, tm.optString(k, null));
            JSONObject qm = o.optJSONObject("quoteColMap");
            if (qm != null) for (String k : qm.keySet()) c.quoteColMap.put(k, qm.optString(k, null));
            c.version = o.optInt("version", 1);
            return c;
        } catch (Throwable ignored) { return null; }
    }

    private static void saveToPref(Context ctx, Contract c) {
        try {
            JSONObject o = new JSONObject();
            o.put("dbPath", c.dbPath);
            o.put("tasksSource", c.tasksSource);
            o.put("quotesSource", c.quotesSource);
            JSONObject tm = new JSONObject();
            for (Map.Entry<String,String> e : c.taskColMap.entrySet()) tm.put(e.getKey(), e.getValue());
            JSONObject qm = new JSONObject();
            for (Map.Entry<String,String> e : c.quoteColMap.entrySet()) qm.put(e.getKey(), e.getValue());
            o.put("taskColMap", tm);
            o.put("quoteColMap", qm);
            o.put("version", c.version);
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
            sp.edit().putString(PREF_KEY, o.toString()).apply();
        } catch (Throwable ignored) {}
    }

    public static Set<String> listColumns(SQLiteDatabase db, String table) {
        Set<String> s = new HashSet<>();
        if (db == null || TextUtils.isEmpty(table)) return s;
        try (Cursor c = db.rawQuery("PRAGMA table_info(" + table + ")", null)) {
            while (c.moveToNext()) s.add(c.getString(1));
        } catch (Throwable ignored) {}
        return s;
    }
}
