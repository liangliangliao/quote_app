import '../util/kv_store.dart';

import 'dart:isolate';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart' show BackgroundIsolateBinaryMessenger;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';

import 'package:quote_app/app_globals.dart';
import 'package:quote_app/platform/perm_helper.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';

class SchedulerService {

static Future<bool> _shouldSimulateDartFail() async {
  try {
    final kv = await KVStore.instance();
    return (kv.getInt('simulate_dart_fail') ?? 0) == 1;
  } catch (_) { return false; }
}

static Future<void> _nativeFallbackNow({
  required String title,
  required String body,
  required int nid,
  String? avatarPath,
  String? taskUid,
  int? quoteId,
  
}) async {
  final whenMs = DateTime.now().add(const Duration(seconds: 2)).millisecondsSinceEpoch;
  await PermHelper.scheduleNativeNotification(
    whenMs: whenMs,
    title: title,
    body: body,
    nid: nid,
    avatarPath: avatarPath,
    taskUid: taskUid,
    quoteId: quoteId,
    handshakeKey: AppGlobals.handshakeKey,
      );
}

  static Future<void> init() async { try { await AndroidAlarmManager.initialize(); } catch (_) {} }

  static Future<void> scheduleNextForAll() async {
  final db = await AppDatabase.instance();
  final tasks = await db.query('tasks');
  final canExact = await PermHelper.hasExactAlarmPermission();

  for (final t in tasks) {
    if ((t['status'] ?? 'on') != 'on') continue;

    final DateTime next = _computeNext(t);
    final String taskUid = (t['task_uid'] ?? '') as String;
    final int id = _alarmIdForTask(taskUid);

    // 记录下一次触发时间
    await TaskDao().updateNextRun(taskUid, next);

    // 安排闹钟回调
    await AndroidAlarmManager.oneShotAt(
      next,
      id,
      callback,
      exact: canExact,
      wakeup: true,
      rescheduleOnReboot: true,
      allowWhileIdle: true,
    );

    // 原生兜底：仅为手动任务预取内容；自动/轮播不预取，避免副作用
    try {
      final String title = (t['name'] ?? '') as String;
      final String type = (t['type'] ?? 'auto') as String;
      final String avatar = (t['avatar_path'] ?? '') as String;
      String? contentForFallback;
      int? quoteIdForFallback;

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        final c = (q?['content'] ?? '') as String;
        if (c.isNotEmpty) {
          contentForFallback = c;
          quoteIdForFallback = (q?['id'] as int?);
        }
      } else {
        contentForFallback = null; // 让 Dart 到点决定；兜底给默认提示
      }

      final whenMs = next.add(const Duration(seconds: 45)).millisecondsSinceEpoch;
      await PermHelper.scheduleNativeNotification(
        whenMs: whenMs,
        title: title,
        body: (contentForFallback ?? '到点啦，打开App查看内容'),
        nid: id,
        avatarPath: avatar.isEmpty ? null : avatar,
        taskUid: taskUid,
        quoteId: quoteIdForFallback,
        handshakeKey: AppGlobals.handshakeKey,
              );
    } catch (_) {}
  }
}

  
@pragma('vm:entry-point')
  static Future<void> callback() async {
    final token = AppGlobals.rootIsolateToken;
    if (token != null) {
      BackgroundIsolateBinaryMessenger.ensureInitialized(token);
    }
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final tasks = await db.query('tasks');

    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final start = (t['start_time'] ?? '') as String;
      if (start.isEmpty) continue;
      if (!_isDue(now, start)) continue;

      final String taskUid = (t['task_uid'] ?? '') as String;
      final String name = (t['name'] ?? '') as String;
      final String avatar = (t['avatar_path'] ?? '') as String;
      final String type = (t['type'] ?? 'manual') as String;
      final int nid = _alarmIdForTask(taskUid);

      final next2 = _computeNext(t, from: now.add(const Duration(seconds: 1)));
      try {
        if (type == 'manual') {
          final q = await QuoteDao().latestForTask(taskUid);
          final content = (q?['content'] ?? '') as String;
          if (content.isNotEmpty) {
            final __simulate = await _shouldSimulateDartFail();
            try {
              await NotificationService.show(
                id: nid,
                title: name,
                body: content,
                largeIconPath: avatar.isEmpty ? null : avatar,
              );
              await LogDao().add(taskUid: taskUid, detail: '通知已成功发送');
              if (q?['id'] != null) {
                await QuoteDao().markNotified(q!['id'] as int);
              }
            } catch (e) {
              await LogDao().add(taskUid: taskUid, detail: '通知Dart路径失败，改走原生兜底: ' + e.toString());
              await _nativeFallbackNow(
                title: name, body: content, nid: nid,
                avatarPath: avatar.isEmpty ? null : avatar,
                taskUid: taskUid, quoteId: (q?['id'] as int?));
            }
            if (__simulate) {
              await LogDao().add(taskUid: taskUid, detail: '模拟开关生效：触发原生兜底通知');
              await _nativeFallbackNow(
                title: name, body: content, nid: nid,
                avatarPath: avatar.isEmpty ? null : avatar,
                taskUid: taskUid, quoteId: (q?['id'] as int?));
            }
          }
        } else if (type == 'carousel') {
          final q = await QuoteDao().carouselNextSequential(taskUid);
          if (q != null) {
            final content = (q['content'] ?? '') as String;
            final __simulate = await _shouldSimulateDartFail();
            try {
              await NotificationService.show(
                id: nid,
                title: name,
                body: content,
                largeIconPath: avatar.isEmpty ? null : avatar,
              );
              await LogDao().add(taskUid: taskUid, detail: '通知已成功发送');
              await QuoteDao().markNotified(q['id'] as int);
            } catch (e) {
              await LogDao().add(taskUid: taskUid, detail: '通知Dart路径失败，改走原生兜底: ' + e.toString());
              await _nativeFallbackNow(
                title: name, body: content, nid: nid,
                avatarPath: avatar.isEmpty ? null : avatar,
                taskUid: taskUid, quoteId: (q['id'] as int?));
            }
            if (__simulate) {
              await LogDao().add(taskUid: taskUid, detail: '模拟开关生效：触发原生兜底通知');
              await _nativeFallbackNow(
                title: name, body: content, nid: nid,
                avatarPath: avatar.isEmpty ? null : avatar,
                taskUid: taskUid, quoteId: (q['id'] as int?));
            }
          }
        } else {
          final cfg = await ConfigDao().getOne();
          final endpoint = (cfg?['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;
          final apiKey = (cfg?['api_key'] ?? '') as String;
          final model = (cfg?['model'] ?? 'gpt-5') as String;
          final prompt = (t['prompt'] ?? '') as String;
          final openai = OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model);

          int tries = 0;
          bool brokeOnException = false;
          while (tries < 10) {
            tries++;
            try {
              final generated = (await openai.generateQuote(prompt)).trim();
              if (generated.isEmpty) {
                await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败! 返回为空');
                brokeOnException = true;
                break;
              }

              final dup = await QuoteDao().existsSimilar(generated, threshold: 0.9);
              if (!dup) {
                final uid = await QuoteDao().insertIfUnique(
                  taskUid: taskUid,
                  type: 'auto',
                  taskName: name,
                  avatarPath: avatar,
                  content: generated,
                );
                if (uid.isNotEmpty) {
                  await LogDao().add(taskUid: taskUid, detail: 'api插入成功!');

                  final __simulate = await _shouldSimulateDartFail();
                  try {
                    await NotificationService.show(
                      id: nid,
                      title: name,
                      body: generated,
                      largeIconPath: avatar.isEmpty ? null : avatar,
                    );
                    await LogDao().add(taskUid: taskUid, detail: '通知已成功发送');
                    final last = await QuoteDao().latestForTask(taskUid);
                    if (last?['id'] != null) {
                      await QuoteDao().markNotified(last!['id'] as int);
                    }
                  } catch (e) {
                    await LogDao().add(taskUid: taskUid, detail: '通知Dart路径失败，改走原生兜底: ' + e.toString());
                    await _nativeFallbackNow(
                      title: name, body: generated, nid: nid,
                      avatarPath: avatar.isEmpty ? null : avatar,
                      taskUid: taskUid, quoteId: null);
                  }
                  if (__simulate) {
                    await LogDao().add(taskUid: taskUid, detail: '模拟开关生效：触发原生兜底通知');
                    await _nativeFallbackNow(
                      title: name, body: generated, nid: nid,
                      avatarPath: avatar.isEmpty ? null : avatar,
                      taskUid: taskUid, quoteId: null);
                  }

                  break;
                }
              } else {
                await LogDao().add(taskUid: taskUid, detail: '去重未通过，重试第' + tries.toString() + '次');
              }
            } catch (e) {
              await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败! ' + e.toString());
              brokeOnException = true;
              break;
            }
          }
          if (!brokeOnException && tries >= 10) {
            await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
          }
        }
      } finally {
        await TaskDao().updateNextRun(taskUid, next2);
      }
    }
  }




  static bool _isDue(DateTime now, String start) {
    try {
      final dt = DateTime.parse(start.replaceAll('/', '-'));
      final diff = now.difference(dt).inSeconds;
      return diff >= 0 && diff <= 59;
    } catch (_) {
      return false;
    }
  }

  static int _alarmIdForTask(String taskUid) {
    int h = 0;
    for (int i = 0; i < taskUid.length; i++) {
      h = (h * 131 + taskUid.codeUnitAt(i)) & 0x7fffffff;
    }
    return h;
  }

  static DateTime _computeNext(Map<String, dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    final start = (t['start_time'] ?? '') as String;
    final parsedTime = _parseTimeAsToday(start, now);
    final String freq = (t['freq_type'] ?? 'daily') as String;
    final int? weekday = t['freq_weekday'] as int?; // 1=Mon..7=Sun
    final int? dayOfMonth = t['freq_day_of_month'] as int?; // 1..31

    DateTime candidate = parsedTime.isAfter(now) ? parsedTime : parsedTime.add(const Duration(days: 1));

    if (freq == 'weekly') {
      int target = (weekday ?? 1).clamp(1, 7);
      int cur = parsedTime.weekday; // 1..7
      int add = (target - cur) % 7;
      if (add == 0 && !parsedTime.isAfter(now)) add = 7;
      candidate = DateTime(now.year, now.month, now.day, parsedTime.hour, parsedTime.minute).add(Duration(days: add));
    } else if (freq == 'monthly') {
      int dom = (dayOfMonth ?? 1).clamp(1, 31);
      DateTime base = DateTime(now.year, now.month, dom, parsedTime.hour, parsedTime.minute);
      if (!base.isAfter(now)) {
        final nextMonth = DateTime(now.year, now.month + 1, 1);
        final m = nextMonth.month;
        final y = nextMonth.year;
        final days = DateTime(y, m + 1, 0).day;
        dom = dom.clamp(1, days);
        base = DateTime(y, m, dom, parsedTime.hour, parsedTime.minute);
      }
      candidate = base;
    } else {
      // daily
      if (!parsedTime.isAfter(now)) {
        candidate = parsedTime.add(const Duration(days: 1));
      } else {
        candidate = parsedTime;
      }
    }

    return candidate;
  }

  static DateTime _parseTimeAsToday(String start, DateTime now) {
    try {
      // supports "yyyy-MM-dd HH:mm"
      final parts = start.split(' ');
      final hm = (parts.isNotEmpty ? parts.last : start).split(':');
      final h = int.parse(hm[0]);
      final m = int.parse(hm[1]);
      return DateTime(now.year, now.month, now.day, h, m);
    } catch (_) {
      return DateTime(now.year, now.month, now.day, 9, 0);
    }
  }

  static String _fmt(DateTime dt) => DateFormat('yyyy-MM-dd HH:mm').format(dt);
}
