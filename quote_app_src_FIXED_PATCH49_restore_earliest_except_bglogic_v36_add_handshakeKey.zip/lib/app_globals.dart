import 'dart:ui';

class AppGlobals {
  static RootIsolateToken? rootIsolateToken;

  /// 用于 Dart↔原生 兜底通知的握手校验；
  /// 保持非空常量即可（如需加强安全，可在 main() 中动态覆盖）。
  static String handshakeKey = 'quote_app_handshake_v1';
}