package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import com.example.quote_app.data.DbRepository
import com.example.quote_app.schedule.NextTriggerCalculator
import com.example.quote_app.biz.Biz
import org.json.JSONObject

class NotifyWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
  override suspend fun doWork(): Result {
    val id = inputData.getInt("id", 0)
    val payload = inputData.getString("payload") ?: "{}"
    val obj = try { JSONObject(payload) } catch (_: Throwable) { JSONObject() }
    val uid = obj.optString("uid", "")
    val runKey = obj.optString("runKey", "")
    val chan = "wm_fallback"

    if (uid.isEmpty()) return Result.success()

    var entered = false
    try {
      entered = DbRepository.runGuardBegin(applicationContext, uid, runKey, chan)
      if (!entered) return Result.success()

      val handled = Biz.run(applicationContext, uid)
      if (handled) {
        DbRepository.markLatestSuccess(applicationContext, uid)
        val next = NextTriggerCalculator.compute(applicationContext, uid)
        if (next > 0) {
          // 续排使用 AM+WM 兼容
          com.example.quote_app.NativeSchedulerK.scheduleExactWmCompat(applicationContext, id, next, payload)
        }
        // 取消兜底
        try { WorkManager.getInstance(applicationContext).cancelUniqueWork("wm_once_" + id) } catch (_: Throwable) {}
        return Result.success()
      } else {
        DbRepository.log(applicationContext, uid, "WM兜底：业务未处理")
        return Result.retry()
      }
    } catch (t: Throwable) {
      DbRepository.log(applicationContext, uid, "WM兜底异常: " + (t.message ?: "未知错误"))
      return Result.retry()
    } finally {
      try { DbRepository.runGuardEnd(applicationContext, uid, runKey, chan) } catch (_: Throwable) {}
    }
  }
}