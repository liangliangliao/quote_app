import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';
import '../utils/debug_logger.dart';

/// A helper service to obtain the current device location in a robust manner.
///
/// This service first attempts to use the Geolocator plugin to obtain the
/// current position with high accuracy. If that fails (for example on
/// devices without Google Play services in Mainland China), it falls back
/// to Baidu's IP‑based geolocation API. The Baidu API key is read from
/// the notify_config table (key = 'baidu_ak'). If no key is configured,
/// the fallback will be skipped and null is returned.
class LocationService {
  /// Attempts to obtain the current position. Returns a [Position] if
  /// successful, otherwise returns null.
  static Future<Position?> getCurrentPositionSmart() async {
    // Try using Geolocator first
    try {
      // Attempt to obtain a fresh location fix with a time limit.  In some indoor
      // environments or on devices without Google Play services, this call may
      // throw or time out.  We wrap it in a try/catch to gracefully handle
      // failures.
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 4),
      );
      // Record a log entry indicating that the standard Geolocator API was used
      // to obtain the location. This helps differentiate overseas provider
      // usage from the Baidu fallback in the logs table.
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator 获取位置：'
            'lat=${pos.latitude}, lon=${pos.longitude}');
      } catch (_) {}
      return pos;
    } catch (_) {
      // ignore and try last known position or Baidu fallback
    }
    // If a current position could not be obtained, attempt to retrieve the last
    // known position from the system.  This is useful when GPS is disabled or
    // no recent fix is available.  If null, fall through to Baidu.
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        try {
          DLog.i('LocationService', '【定位】使用 Geolocator 最近一次已知位置：'
              'lat=${last.latitude}, lon=${last.longitude}');
        } catch (_) {}
        return last;
      }
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // If there is no last known position, attempt to obtain a low-accuracy
    // location via the network/GPS provider. This provides a coarse location
    // quickly before falling back to Baidu IP. This call may still throw
    // exceptions which are caught and ignored.
    try {
      final low = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 4),
      );
      try {
        DLog.i('LocationService', '【定位】使用 Geolocator (低精度) 获取位置：'
            'lat=${low.latitude}, lon=${low.longitude}');
      } catch (_) {}
      return low;
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // Fallback to Baidu IP location if configured
    try {
      final ak = await NotifyConfigDao().getBaiduAk();
      if (ak.trim().isEmpty) {
        return null;
      }
      final url = Uri.parse(
        'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(ak.trim())}&coor=wgs84',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && data['status'] == 0) {
          final content = data['content'];
          if (content is Map) {
            final point = content['point'];
            if (point is Map) {
              final latStr = point['y']?.toString() ?? '';
              final lngStr = point['x']?.toString() ?? '';
              final lat = double.tryParse(latStr);
              final lng = double.tryParse(lngStr);
              if (lat != null && lng != null) {
                // Construct a Position with minimal fields; other fields left at zero
                // Log that Baidu IP location fallback is being used so the logs can
                // differentiate between location providers. Include the coordinates.
                try {
                  DLog.i('LocationService', '【定位】使用 Baidu IP 定位获取位置：'
                      'lat=$lat, lon=$lng');
                } catch (_) {}
                return Position(
                  latitude: lat,
                  longitude: lng,
                  timestamp: DateTime.now(),
                  accuracy: 0,
                  altitude: 0,
                  heading: 0,
                  speed: 0,
                  speedAccuracy: 0,
                  altitudeAccuracy: 0,
                  headingAccuracy: 0,
                );
              }
            }
          }
        }
      }
    } catch (_) {
      // ignore network or JSON errors
    }
    return null;
  }

  /// Attempts to obtain the current position with a bias toward using the
  /// Baidu IP geolocation service when it is configured. This helper first
  /// checks whether a Baidu API key exists in the notify_config table. If a
  /// non‑empty key is found, it will immediately attempt to query Baidu's
  /// `location/ip` endpoint to obtain a coordinate. Should this request
  /// succeed, the resulting position is returned and no further calls are
  /// attempted. If the Baidu lookup fails or no key is configured, this
  /// method falls back to [getCurrentPositionSmart] which uses Geolocator
  /// and then Baidu as a final option. All key steps are logged via DLog so
  /// that the logs table clearly shows which provider was used.
  static Future<Position?> getCurrentPositionPreferBaidu() async {
    // Attempt Baidu IP geolocation first.  Use the configured AK when present;
    // otherwise fall back to a default AK specific to this app.  This ensures
    // that users in China can always obtain a coarse location via Baidu even
    // if they haven't configured an API key.  If the lookup fails or a
    // network error occurs, we fall through to the standard smart fallback.
    try {
      String ak = '';
      try {
        ak = await NotifyConfigDao().getBaiduAk();
      } catch (_) {
        ak = '';
      }
      // If no API key is configured, use the built‑in fallback key.  This
      // fallback allows Baidu geolocation to operate out‑of‑box for users in
      // China.  Developers may override this via settings.  When using the
      // fallback key the user may still provide their own key in settings.
      final effectiveAk = ak.trim().isNotEmpty
          ? ak.trim()
          : 'oMtxRk6dE7Q8w8SXZ3frrwzAak3gqOTh';
      if (effectiveAk.isNotEmpty) {
        final url = Uri.parse(
          'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(effectiveAk)}&coor=wgs84',
        );
        final res = await http.get(url).timeout(const Duration(seconds: 5));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data is Map && data['status'] == 0) {
            final content = data['content'];
            if (content is Map) {
              final point = content['point'];
              if (point is Map) {
                final latStr = point['y']?.toString() ?? '';
                final lngStr = point['x']?.toString() ?? '';
                final lat = double.tryParse(latStr);
                final lng = double.tryParse(lngStr);
                if (lat != null && lng != null) {
                  try {
                    DLog.i('LocationService', '【定位】优先使用 Baidu IP 定位获取位置：'
                        'lat=$lat, lon=$lng');
                  } catch (_) {}
                  return Position(
                    latitude: lat,
                    longitude: lng,
                    timestamp: DateTime.now(),
                    accuracy: 0,
                    altitude: 0,
                    heading: 0,
                    speed: 0,
                    speedAccuracy: 0,
                    altitudeAccuracy: 0,
                    headingAccuracy: 0,
                  );
                }
              }
            }
          }
        }
      }
    } catch (_) {
      // ignore network or JSON errors and fall through to the smart fallback
    }
    // Fall back to the standard smart location retrieval logic if Baidu lookup
    // fails or returns no result.  This will attempt Geolocator (high,
    // low, last known) and finally fallback to Baidu again.  Logging will
    // occur within that call.
    return await getCurrentPositionSmart();
  }
}