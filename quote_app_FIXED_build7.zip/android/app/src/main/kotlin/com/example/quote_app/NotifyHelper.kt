package com.example.quote_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import com.example.quote_app.data.DbRepository

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default"

  @JvmStatic
  fun send(ctx: Context, id: Int, title: String, body: String, avatarPath: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    // 诊断：系统总的通知开关被关会静默丢弃所有通知
    if (!nm.areNotificationsEnabled()) {
      com.example.quote_app.data.DbRepository.log(ctx, null, "【原生】通知被系统总开关关闭：请到系统通知中开启本应用的通知权限")
      return
    }
    val ch0 = nm.getNotificationChannel(DEFAULT_CHANNEL_ID)
    if (ch0 == null) {
      val ch = NotificationChannel(DEFAULT_CHANNEL_ID, "提醒", NotificationManager.IMPORTANCE_DEFAULT)
      nm.createNotificationChannel(ch)
    } else if (ch0.importance == NotificationManager.IMPORTANCE_NONE) {
      com.example.quote_app.data.DbRepository.log(ctx, null, "【原生】通知渠道被关闭：channel=quote_default，请到系统通知设置中开启该渠道")
      return
    }
    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)

    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }
    nm.notify(id, builder.build())
        try { com.example.quote_app.data.DbRepository.log(ctx, null, "【原生】已提交系统通知 id="+id+" chan="+DEFAULT_CHANNEL_ID); } catch (_: Throwable) {}
  }
}