
package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationManager
import android.app.NotificationChannel
import android.os.Build
import androidx.core.app.NotificationCompat
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.database.sqlite.SQLiteDatabase
import android.content.ContentValues

class NativeNotifyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val sp = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)

        // 如果 Dart 在近 90s 内已发同一 nid，则放弃兜底（避免双响）
        try {
            val nid = intent.getIntExtra("nid", 0)
            val lastTs = sp.getLong("flutter.lastDartSentAt_$" + nid, 0L)
            val now = System.currentTimeMillis()
            if (lastTs > 0 && now - lastTs <= 90_000L) {
                return
            }
        } catch (_: Throwable) {}

        // 如果握手标记为 true，也放弃
        try {
            val hkey = intent.getStringExtra("handshakeKey")
            if (hkey != null) {
                val ok = sp.getBoolean("flutter.${'$'}hkey", false)
                if (ok) return
            }
        } catch (_: Throwable) {}

        val channelId = "quote_channel"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "Quotes", NotificationManager.IMPORTANCE_DEFAULT)
            nm.createNotificationChannel(ch)
        }

        val title = intent.getStringExtra("title") ?: "提醒"
        val body = intent.getStringExtra("body") ?: "到点啦"
        val nid = intent.getIntExtra("nid", 1002)
        val avatarPath = intent.getStringExtra("avatarPath") ?: ""
        val taskUid = intent.getStringExtra("taskUid") ?: ""
        val quoteId = intent.getIntExtra("quoteId", -1)

        var largeIcon: Bitmap? = null
        try {
            if (avatarPath.isNotEmpty()) {
                val f = java.io.File(avatarPath)
                if (f.exists()) {
                    largeIcon = BitmapFactory.decodeFile(avatarPath)
                }
            }
        } catch (_: Throwable) {}

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)

        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon)
        }

        nm.notify(nid, builder.build())

        // 成功后把 quotes.notified=1，并写 logs
        try {
            if (quoteId > 0) {
                val dbPath = java.io.File(context.filesDir, "quotes.db").absolutePath
                val db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READWRITE)
                val cv = ContentValues()
                cv.put("notified", 1)
                db.update("quotes", cv, "id=?", arrayOf(quoteId.toString()))

                // 写日志
                val cv2 = ContentValues()
                cv2.put("log_uid", "log_" + System.currentTimeMillis().toString())
                cv2.put("task_uid", taskUid)
                cv2.put("detail", "成功! (native)")
                cv2.put("created_at", System.currentTimeMillis())
                db.insert("logs", null, cv2)

                db.close()
            }
        } catch (_: Throwable) {}
    }
}
