package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.os.PowerManager
import android.provider.Settings
import android.net.Uri
import android.os.Build
import android.content.Intent
import android.app.AlarmManager
import android.app.ActivityManager
import android.content.Context

import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat
import android.Manifest
import android.content.pm.PackageManager
class MainActivity: FlutterActivity() {

override fun onCreate(savedInstanceState: android.os.Bundle?) {
    if (Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {

        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            1001
        )
        return
    }
    super.onCreate(savedInstanceState)
}

    private val CHANNEL = "com.example.quote_app/sys"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "native.scheduler").setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleExactAt" -> {
                    val id = call.argument<Int>("id")!!
                    val epochMs = call.argument<Long>("epochMs")!!
                    val payloadJson = call.argument<String>("payload") ?: "{}"
                    val ok = NativeSchedulerK.scheduleExactAt(this, id, epochMs, payloadJson)
                    result.success(ok)
                }
                "cancel" -> {
                    val id = call.argument<Int>("id")!!
                    NativeSchedulerK.cancel(this, id)
                    result.success(null)
                }
                "hasExactAlarmPermission" -> {
                    result.success(NativeSchedulerK.canScheduleExact(this))
                }
                "requestExactAlarmPermission" -> {
                    NativeSchedulerK.requestExact(this)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }


        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                
                
                "hasExactAlarmPermission" -> {
                    var ok = true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        ok = try {
                            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                            am.canScheduleExactAlarms()
                        } catch (e: Exception) { false }
                    }
                    result.success(ok)
                }
    
    
                
                
                "requestExactAlarmPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        // 1) App-specific page
                        try {
                            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                data = Uri.parse("package:" + packageName)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                        } catch (e1: Exception) {
                            // 2) Generic page
                            try {
                                val intent2 = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intent2)
                            } catch (e2: Exception) {
                                // 3) App details as fallback
                                try {
                                    val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                        data = Uri.parse("package:" + packageName)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    startActivity(fallback)
                                } catch (_: Exception) {}
                            }
                        }
                    }
                    result.success(null)
                }
    
    
                "hasOverlayPermission" -> {
                    var ok = true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        ok = Settings.canDrawOverlays(this)
                    }
                    result.success(ok)
                }
                "requestOverlayPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    }
                    result.success(null)
                }
                
                "isIgnoringBatteryOptimizations" -> {
                    var ok = true
                    try {
                        val pm = getSystemService(POWER_SERVICE) as PowerManager
                        ok = pm.isIgnoringBatteryOptimizations(packageName)
                    } catch (e: Exception) { ok = false }
                    result.success(ok)
                }
                "requestIgnoreBatteryOptimizations" -> {
                    try {
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:" + packageName)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                    } catch (e: Exception) {
                        val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(fallback)
                    }
                    result.success(null)
                }
                
                "isBackgroundRestricted" -> {
                    var restricted = false
                    try {
                        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                        restricted = am.isBackgroundRestricted
                    } catch (e: Exception) { restricted = false }
                    result.success(restricted)
                }
                "openAppBatterySettings" -> {
                    try {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:" + packageName)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                    } catch (_: Exception) {}
                    result.success(null)
                }
                else -> result.notImplemented()
            
        
            }
        }
    }
override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    if (requestCode == 1001) {
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            finish()
        }
    }
}
}
