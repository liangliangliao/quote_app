
import 'dart:isolate';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart' show BackgroundIsolateBinaryMessenger;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:quote_app/app_globals.dart';
import 'package:quote_app/platform/perm_helper.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';

class SchedulerService {
  static Future<void> init() async { try { await AndroidAlarmManager.initialize(); } catch (_) {} }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    final canExact = await PermHelper.hasExactAlarmPermission();
    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;

      final DateTime next = _computeNext(t);
      final String taskUid = (t['task_uid'] ?? '') as String;
      final int id = _alarmIdForTask(taskUid);

      // 挂 AlarmManager 到点回调
      await AndroidAlarmManager.oneShotAt(
        next,
        id,
        callback,
        exact: canExact,
        wakeup: true,
        rescheduleOnReboot: true,
        allowWhileIdle: true,
      );

      // 与 Dart 一致的原生兜底（预取内容并下发完整负载）
      try {
        final String title = (t['name'] ?? '') as String;
        final String type = (t['type'] ?? 'auto') as String;
        final String avatar = (t['avatar_path'] ?? '') as String;
        String? contentForFallback;
        int? quoteIdForFallback;

        if (type == 'manual') {
          final q = await QuoteDao().latestForTask(taskUid);
          final c = (q?['content'] ?? '') as String;
          if (c.isNotEmpty) {
            contentForFallback = c;
            quoteIdForFallback = (q?['id'] as int?);
          }
        } else if (type == 'carousel') {
          final q = await QuoteDao().carouselNextSequential(taskUid);
          if (q != null) {
            contentForFallback = (q['content'] ?? '') as String;
            quoteIdForFallback = (q['id'] as int?);
          }
        } else {
  // auto：不在调度阶段调用 OpenAI，避免重复；到点由 Dart 回调生成
  contentForFallback = null;
}

        if (contentForFallback != null && contentForFallback!.isNotEmpty) {
          final whenMs = next.add(const Duration(seconds: 45)).millisecondsSinceEpoch;
          final handshakeKey = 'notif_${id}_${next.millisecondsSinceEpoch}';
          try { await PermHelper.saveHandshakeKey(id, handshakeKey); } catch (_) {}
          await PermHelper.scheduleNativeNotification(
            whenMs: whenMs,
            title: title,
            body: (contentForFallback ?? '到点啦，打开App查看内容'),
            nid: id,
            handshakeKey: handshakeKey,
            avatarPath: avatar,
            taskUid: taskUid,
            quoteId: quoteIdForFallback ?? -1,
          );
        }
      } catch (_) {}
    }
  }

  @pragma('vm:entry-point')
  static Future<void> callback() async {
    // 确保后台 isolate 能发通知
    final token = AppGlobals.rootIsolateToken;
    if (token != null) {
      BackgroundIsolateBinaryMessenger.ensureInitialized(token);
    }
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final tasks = await db.query('tasks');

    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final start = (t['start_time'] ?? '') as String;
      if (start.isEmpty) continue;
      if (!_isDue(now, start)) continue;

      final String taskUid = (t['task_uid'] ?? '') as String;
      final String name = (t['name'] ?? '') as String;
      final String avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;
      final nid = _alarmIdForTask(taskUid);

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        final content = (q?['content'] ?? '') as String;
        if (content.isNotEmpty) {
          await NotificationService.show(
            id: nid,
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          
          // 写入“通知已成功发送”的日志
          try { await LogDao().add(taskUid: taskUid, detail: '通知已成功发送'); } catch (_) {}
          // 计算并回写下一次时间
          try {
            final DateTime _next = _computeNext(t, from: DateTime.now().add(const Duration(seconds: 1)));
            await db.update('tasks', {'start_time': _fmt(_next)}, where: 'task_uid = ?', whereArgs: [taskUid]);
          } catch (_) {}
try {
            final sp = await SharedPreferences.getInstance();
            await sp.setInt('lastDartSentAt_$nid', DateTime.now().millisecondsSinceEpoch);
          } catch (_) {}
          if (q?['id'] != null) {
            await QuoteDao().markNotified(q!['id'] as int);
          }
          await LogDao().add(taskUid: taskUid, detail: '成功!');
        }
      } else if (type == 'carousel') {
        final q = await QuoteDao().carouselNextSequential(taskUid);
        if (q != null) {
          final content = (q['content'] ?? '') as String;
          await NotificationService.show(
            id: nid,
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          
          // 写入“通知已成功发送”的日志
          try { await LogDao().add(taskUid: taskUid, detail: '通知已成功发送'); } catch (_) {}
          // 计算并回写下一次时间
          try {
            final DateTime _next = _computeNext(t, from: DateTime.now().add(const Duration(seconds: 1)));
            await db.update('tasks', {'start_time': _fmt(_next)}, where: 'task_uid = ?', whereArgs: [taskUid]);
          } catch (_) {}
try {
            final sp = await SharedPreferences.getInstance();
            await sp.setInt('lastDartSentAt_$nid', DateTime.now().millisecondsSinceEpoch);
          } catch (_) {}
          await QuoteDao().markNotified(q['id'] as int);
          await LogDao().add(taskUid: taskUid, detail: '成功!');
        }
      } else {
        // auto：和兜底一致的业务逻辑（到点若 Dart 拉起成功也会发）
        final cfg = await ConfigDao().getOne();
        final endpoint = (cfg?['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;
        final apiKey = (cfg?['api_key'] ?? '') as String;
        final model = (cfg?['model'] ?? 'gpt-5') as String;
        final prompt = (t['prompt'] ?? '') as String;
        final openai = OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model);

        int tries = 0;
bool _brokeOnException = false;
while (tries < 10) {
  tries++;
  try {
            final generated = (await openai.generateQuote(prompt)).trim();
            if (generated.isEmpty) continue;
            final dup = await QuoteDao().existsSimilar(generated, threshold: 0.9);
            if (!dup) {
              final uid = await QuoteDao().insertIfUnique(
                taskUid: taskUid,
                type: 'auto',
                taskName: name,
                avatarPath: avatar,
                content: generated,
              );
              if (uid.isNotEmpty) {
                await NotificationService.show(
                  id: nid,
                  title: name,
                  body: generated,
                  largeIconPath: avatar.isEmpty ? null : avatar,
                );
                
          // 写入“通知已成功发送”的日志
          try { await LogDao().add(taskUid: taskUid, detail: '通知已成功发送'); } catch (_) {}
          // 计算并回写下一次时间
          try {
            final DateTime _next = _computeNext(t, from: DateTime.now().add(const Duration(seconds: 1)));
            await db.update('tasks', {'start_time': _fmt(_next)}, where: 'task_uid = ?', whereArgs: [taskUid]);
          } catch (_) {}
try {
                  final sp = await SharedPreferences.getInstance();
                  await sp.setInt('lastDartSentAt_$nid', DateTime.now().millisecondsSinceEpoch);
                } catch (_) {}
                final last = await QuoteDao().latestForTask(taskUid);
                if (last?['id'] != null) {
                  await QuoteDao().markNotified(last!['id'] as int);
                }
                await LogDao().add(taskUid: taskUid, detail: '成功!');
                break;
              }
            } else {
              await LogDao().add(taskUid: taskUid, detail: '自动任务命中去重，重试第$tries次');
            }
          } catch (e) {
            await LogDao().add(taskUid: taskUid, detail: '调用openai api发生错误或失败: ' + e.toString());
            break;
          }
        }
if (!_brokeOnException && tries >= 10) {
  await LogDao().add(taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
}

      }
    }
  }

  static bool _isDue(DateTime now, String start) {
    try {
      final dt = DateTime.parse(start.replaceAll('/', '-'));
      final diff = now.difference(dt).inSeconds;
      return diff >= 0 && diff <= 59;
    } catch (_) {
      return false;
    }
  }

  static int _alarmIdForTask(String taskUid) {
    int h = 0;
    for (int i = 0; i < taskUid.length; i++) {
      h = (h * 131 + taskUid.codeUnitAt(i)) & 0x7fffffff;
    }
    return h;
  }

  static DateTime _computeNext(Map<String, dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    final start = (t['start_time'] ?? '') as String;
    final parsedTime = _parseTimeAsToday(start, now);
    final String freq = (t['freq_type'] ?? 'daily') as String;
    final int? weekday = t['freq_weekday'] as int?; // 1=Mon..7=Sun
    final int? dayOfMonth = t['freq_day_of_month'] as int?; // 1..31

    DateTime candidate = parsedTime.isAfter(now) ? parsedTime : parsedTime.add(const Duration(days: 1));

    if (freq == 'weekly') {
      int target = (weekday ?? 1).clamp(1, 7);
      int cur = parsedTime.weekday; // 1..7
      int add = (target - cur) % 7;
      if (add == 0 && !parsedTime.isAfter(now)) add = 7;
      candidate = DateTime(now.year, now.month, now.day, parsedTime.hour, parsedTime.minute).add(Duration(days: add));
    } else if (freq == 'monthly') {
      int dom = (dayOfMonth ?? 1).clamp(1, 31);
      DateTime base = DateTime(now.year, now.month, dom, parsedTime.hour, parsedTime.minute);
      if (!base.isAfter(now)) {
        final nextMonth = DateTime(now.year, now.month + 1, 1);
        final m = nextMonth.month;
        final y = nextMonth.year;
        final days = DateTime(y, m + 1, 0).day;
        dom = dom.clamp(1, days);
        base = DateTime(y, m, dom, parsedTime.hour, parsedTime.minute);
      }
      candidate = base;
    } else {
      // daily
      if (!parsedTime.isAfter(now)) {
        candidate = parsedTime.add(const Duration(days: 1));
      } else {
        candidate = parsedTime;
      }
    }

    return candidate;
  }

  static DateTime _parseTimeAsToday(String start, DateTime now) {
    try {
      // supports "yyyy-MM-dd HH:mm"
      final parts = start.split(' ');
      final hm = (parts.isNotEmpty ? parts.last : start).split(':');
      final h = int.parse(hm[0]);
      final m = int.parse(hm[1]);
      return DateTime(now.year, now.month, now.day, h, m);
    } catch (_) {
      return DateTime(now.year, now.month, now.day, 9, 0);
    }
  }

  static String _fmt(DateTime dt) => DateFormat('yyyy-MM-dd HH:mm').format(dt);
}
