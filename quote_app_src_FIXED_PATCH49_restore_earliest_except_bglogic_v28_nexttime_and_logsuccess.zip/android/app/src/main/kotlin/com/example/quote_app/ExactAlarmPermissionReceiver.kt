package com.example.quote_app

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Receives alarm permission state changes on Android 12+.
 * When granted, app可以在此处触发重排期逻辑（当前仅日志提示；Dart侧拿到源码后可接MethodChannel做真正重排期）。
 */
class ExactAlarmPermissionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED) {
            val can = (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
            Log.i("ExactAlarmPermRcvr", "ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED, canSchedule=$can")
            // TODO: 若需要，可在此发一个本地广播/启动轻量Service/MethodChannel，通知Dart侧重建最近一次的排期
        }
    }
}
