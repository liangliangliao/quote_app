package com.example.quote_app

import io.flutter.app.FlutterApplication

class MyApp : FlutterApplication()
