import 'package:flutter/material.dart';
import '../services/nasa_api_service.dart';

/// Displays a single item from the NASA Image and Video Library. Shows
/// the full image along with title, creation date and description. If
/// the image URL is empty a placeholder icon is displayed instead.
class NasaMediaDetailPage extends StatelessWidget {
  const NasaMediaDetailPage({
    super.key,
    required this.item,
    this.translatedTitle,
    this.translatedDescription,
  });

  final NasaMediaItem item;
  final String? translatedTitle;
  final String? translatedDescription;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          (translatedTitle?.trim().isNotEmpty ?? false) ? translatedTitle! : item.title,
          style: const TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (item.mediaUrl.isNotEmpty)
              Image.network(
                item.mediaUrl,
                fit: BoxFit.cover,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return SizedBox(
                    height: 200,
                    child: Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                                (loadingProgress.expectedTotalBytes ?? 1)
                            : null,
                      ),
                    ),
                  );
                },
                errorBuilder: (context, error, stackTrace) {
                  return const SizedBox(
                    height: 200,
                    child: Center(child: Icon(Icons.broken_image)),
                  );
                },
              )
            else
              const SizedBox(
                height: 200,
                child: Center(
                  child: Icon(Icons.broken_image, size: 48),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    (translatedTitle?.trim().isNotEmpty ?? false) ? translatedTitle! : item.title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item.date,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    (translatedDescription?.trim().isNotEmpty ?? false)
                        ? translatedDescription!
                        : (item.description.isNotEmpty ? item.description : '无描述'),
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}