import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final _dao = QuoteDao();
  final _scroll = ScrollController();
  String _q = '';
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _load(reset: true);
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 200 && !_loading && !_done) {
        _load();
      }
    });
  }

  Future<void> _load({bool reset=false}) async {
    if (reset) {
      _items.clear();
      _offset = 0;
      _done = false;
      if (mounted) setState((){});
    }
    _loading = true;
    final rows = await _dao.latest(q: _q.isEmpty ? null : _q, limit: 50, offset: _offset);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 50) _done = true;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            decoration: InputDecoration(
              hintText: '搜索内容...',
              suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: ()=> _load(reset:true)),
            ),
            onChanged: (v)=> _q = v,
          ),
        ),
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            itemCount: _items.length,
            itemBuilder: (_, i){
              final it = _items[i];
              return ListTile(
                leading: const Icon(Icons.format_quote),
                title: Text((it['content'] ?? '') as String, maxLines: 2, overflow: TextOverflow.ellipsis),
                subtitle: Text((it['created_at'] ?? '') as String),
              );
            },
          ),
        ),
      ],
    );
  }
}
