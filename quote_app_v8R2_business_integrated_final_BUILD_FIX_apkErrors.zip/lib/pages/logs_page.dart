import 'package:flutter/material.dart';
import '../data/dao.dart';
import 'package:intl/intl.dart';

class LogsPage extends StatefulWidget {
  const LogsPage({super.key});
  @override
  State<LogsPage> createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> {
  final _dao = LogDao();
  final _scroll = ScrollController();
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _load();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 200 && !_loading && !_done) {
        _load();
      }
    });
  }

  Future<void> _load() async {
    _loading = true;
    final rows = await _dao.latest(limit: 50, offset: _offset);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 50) _done = true;
  }

  String _fmt(String? s){
    if (s == null || s.isEmpty) return '';
    try {
      final match = RegExp(r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?)').firstMatch(s);
      return match?.group(1) ?? s;
    } catch (_) {
      return s;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      controller: _scroll,
      itemCount: _items.length,
      itemBuilder: (_, i){
        final it = _items[i];
        return ListTile(
          leading: const Icon(Icons.article),
          title: Text((it['detail'] ?? '') as String, maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('task: ${(it['task_uid'] ?? '') as String}  at: ${_fmt((it['created_at'] ?? '') as String)}'),
        );
      },
    );
  }
}
