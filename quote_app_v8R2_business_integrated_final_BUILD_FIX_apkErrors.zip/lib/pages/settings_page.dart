import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';
import '../utils/debug_logger.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _editingConfig = false;
  String _apiKey = '';
  String _model = 'gpt-5';
  String _endpoint = 'https://api.openai.com/v1/responses';
  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await ConfigDao().getOne();
    _apiKey = (cfg['api_key'] ?? '').toString();
    _model = (cfg['model'] ?? 'gpt-5').toString();
    _endpoint = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses').toString();
    _tasks = await TaskDao().all();
    if (mounted) setState((){});
  }

  Future<void> _saveConfig() async {
    await ConfigDao().save(apiKey: _apiKey, model: _model, endpoint: _endpoint);
    await DLog.i('CFG','saved');
    setState(()=> _editingConfig = false);
  }

  Future<String?> _pickAvatar() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery);
    if (x == null) return null;
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png');
    await f.writeAsBytes(await x.readAsBytes());
    return f.path;
  }

  Future<void> _openTaskDialog({Map<String,dynamic>? task}) async {
    final isEdit = task != null;
    String name = isEdit ? (task!['name'] ?? '') as String : '';
    String type = isEdit ? (task!['type'] ?? 'manual') as String : 'manual'; // manual / auto / carousel
    String status = isEdit ? (task!['status'] ?? 'on') as String : 'on';     // on / off
    String startTime = isEdit ? (task!['start_time'] ?? '08:30') as String : '08:30'; // HH:mm 或 yyyy-MM-dd HH:mm
    String prompt = isEdit ? (task!['prompt'] ?? '') as String : '';
    String avatarPath = isEdit ? (task!['avatar_path'] ?? '') as String : '';

    final formKey = GlobalKey<FormState>();

    await showDialog(context: context, builder: (ctx){
      return AlertDialog(
        title: Text(isEdit ? '编辑任务' : '新增任务'),
        content: SizedBox(
          width: 400,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    decoration: const InputDecoration(labelText: '任务名称'),
                    initialValue: name,
                    onChanged: (v)=> name = v,
                    validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入任务名称' : null,
                  ),
                  const SizedBox(height: 8),
                  const Text('任务类型'),
                  DropdownButton<String>(
                    value: type,
                    onChanged: (v){ setState(()=> type = v ?? 'manual'); },
                    items: const [
                      DropdownMenuItem(value: 'manual', child: Text('手动')),
                      DropdownMenuItem(value: 'auto', child: Text('自动')),
                      DropdownMenuItem(value: 'carousel', child: Text('轮播')),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(labelText: '开始时间（HH:mm 或 yyyy-MM-dd HH:mm）'),
                    initialValue: startTime,
                    onChanged: (v)=> startTime = v,
                    validator: (v)=> (v==null || v.trim().isEmpty) ? '请输入时间' : null,
                  ),
                  if (type == 'auto') ...[
                    const SizedBox(height: 8),
                    TextFormField(
                      decoration: const InputDecoration(labelText: '提示词（自动任务专用）'),
                      initialValue: prompt,
                      onChanged: (v)=> prompt = v,
                      minLines: 3,
                      maxLines: null,
                      keyboardType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                    ),
                  ],
                  const SizedBox(height: 8),
                  const Text('头像（用于通知图标）'),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundImage: (avatarPath.isNotEmpty && File(avatarPath).existsSync()) ? FileImage(File(avatarPath)) : null,
                        child: (avatarPath.isEmpty || !File(avatarPath).existsSync()) ? const Icon(Icons.person) : null,
                      ),
                      const SizedBox(width: 8),
                      TextButton.icon(
                        onPressed: () async {
                          final p = await _pickAvatar();
                          if (p != null) setState(()=> avatarPath = p);
                        },
                        icon: const Icon(Icons.image),
                        label: const Text('选择图片'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: ()=> Navigator.pop(ctx), child: const Text('取消')),
          ElevatedButton(
            onPressed: () async {
              if (!(formKey.currentState?.validate() ?? false)) return;
              if (isEdit) {
                // 简化处理：删除旧任务重建（避免编写更新 SQL），不影响 uid 长度约束
                await TaskDao().delete((task!['task_uid'] ?? '') as String);
              }
              await TaskDao().create(
                name: name,
                type: type,
                startTime: DateTime.tryParse(startTime) ?? _parseHHmm(startTime),
                prompt: prompt,
                avatarPath: avatarPath,
                status: status,
              );
              await SchedulerService.scheduleNextForAll();
              if (mounted) Navigator.pop(ctx);
              await _reloadTasksAfterSave();
            },
            child: const Text('保存'),
          )
        ],
      );
    });
  }

  DateTime _parseHHmm(String s){
    final now = DateTime.now();
    final m = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(s.trim());
    if (m == null) return DateTime(now.year, now.month, now.day, 8, 30);
    final h = int.parse(m.group(1)!);
    final mm = int.parse(m.group(2)!);
    var dt = DateTime(now.year, now.month, now.day, h, mm);
    if (!dt.isAfter(now)) dt = dt.add(const Duration(days: 1));
    return dt;
  }

  Future<void> _reloadTasksAfterSave() async {
    _tasks = await TaskDao().all();
    if (mounted) setState((){});
  }

  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          decoration: const InputDecoration(labelText: 'API Key'),
          initialValue: _apiKey,
          onChanged: (v)=> _apiKey = v,
          enabled: _editingConfig,
        ),
        const SizedBox(height: 8),
        TextFormField(
          decoration: const InputDecoration(labelText: '模型（默认 gpt-5）'),
          initialValue: _model,
          onChanged: (v)=> _model = v,
          enabled: _editingConfig,
        ),
        const SizedBox(height: 8),
        TextFormField(
          decoration: const InputDecoration(labelText: 'Endpoint（默认 /v1/responses）'),
          initialValue: _endpoint,
          onChanged: (v)=> _endpoint = v,
          enabled: _editingConfig,
        ),
      ],
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        actions: [
          IconButton(onPressed: (){ setState(()=> _editingConfig = true); }, icon: const Icon(Icons.edit)),
          IconButton(onPressed: _saveConfig, icon: const Icon(Icons.save)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            cfgFields,
            const SizedBox(height: 16),
            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final t in _tasks)
              ListTile(
                leading: const Icon(Icons.alarm),
                title: Text((t['name'] ?? '') as String),
                subtitle: Text('时间: ${(t['start_time'] ?? '') as String}  类型: ${(t['type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(onPressed: ()=> _openTaskDialog(task: t), icon: const Icon(Icons.edit)),
                    IconButton(onPressed: () async {
                      await TaskDao().delete((t['task_uid'] ?? '') as String);
                      await SchedulerService.scheduleNextForAll();
                      await _reloadTasksAfterSave();
                    }, icon: const Icon(Icons.delete)),
                  ],
                ),
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}
