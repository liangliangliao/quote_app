import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String,dynamic>? _latest;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 5), (_)=> _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final dao = QuoteDao();
    final rows = await dao.all(limit: 1, offset: 0);
    setState(()=> _latest = rows.isNotEmpty ? rows.first : null);
  }

  @override
  Widget build(BuildContext context) {
    // Prepare the body content based on whether we have a latest quote.  A
    // nullable widget variable makes it easier to compose the final layout
    // without nesting conditional returns.  When there is no data, show a
    // simple message; otherwise show the quote text.  The content itself is
    // wrapped in padding and a scroll view.
    Widget content;
    if (_latest == null) {
      content = const Center(child: Text('暂无数据！'));
    } else {
      content = Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Text(
            (_latest!['content'] ?? '') as String,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      );
    }
    // Compose the page using a top bar and a middle area.  The top bar is a
    // fixed‑height white container to replace the default dark bar.  The
    // middle area expands to fill the remainder of the screen.  No bottom
    // navigation bar is included here because RootShell provides it.
    return Column(
      children: [
        Container(
          height: kToolbarHeight,
          color: Colors.white,
        ),
        Expanded(child: content),
      ],
    );
  }
}
