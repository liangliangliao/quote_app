import 'package:flutter/material.dart';

class TopBar extends StatelessWidget {
  const TopBar({super.key, this.actions = const []});
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(top: top),
      child: SizedBox(
        height: kToolbarHeight,
        child: Row(
          children: [
            const SizedBox(width: 16),
            const Spacer(),
            ...actions.map((w) => Padding(
              padding: const EdgeInsets.only(right: 4),
              child: w,
            )),
            const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}
