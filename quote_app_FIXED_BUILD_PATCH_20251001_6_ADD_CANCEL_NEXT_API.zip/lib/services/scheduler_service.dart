
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import '../platform/native_scheduler.dart';
import '../platform/perm_helper.dart';
import 'task_runner.dart';

class SchedulerService {
  static Future<void> init() async { /* Workmanager.initialize is handled in main.dart */ }

  // ---------- helpers ----------
  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final start = (t['start_time'] ?? '09:00').toString();
    final now = DateTime.now();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length>1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (!next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }

  static String _wmUniqueBase(String uid, String runKey) => 'wm_run_'+uid+'_'+runKey;
  static String _wmUniqueNormal(String uid, String runKey) => _wmUniqueBase(uid, runKey) + '_N';
  static String _wmUniqueFallback(String uid, String runKey, int attempt) => _wmUniqueBase(uid, runKey) + '_FB_' + attempt.toString();

  static int _alarmId(String uid, String runKey) {
    return (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;
  }

  static String _runKeyFromTime(DateTime t) {
    return DateFormat('yyyyMMdd_HHmm').format(t);
  }

  // ---------- schedule ----------
  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);
    final now = DateTime.now();
    final diff = next.difference(now);
    final normalDelay = diff.isNegative ? Duration.zero : diff;

    // AM: guarded by exact-alarm permission
    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (ok) {
        await NativeScheduler.scheduleExactAt(
          id: _alarmId(uid, runKey),
          epochMs: next.millisecondsSinceEpoch,
          payload: {'uid': uid, 'runKey': runKey, 'chan':'am', 'attempt': 1},
        );
        await DLog.i('SCH', 'AM 注册完成 uid='+uid+' am_id='+_alarmId(uid, runKey).toString()+' run='+runKey);
      } else {
        await DLog.w('SCH','AM 权限未授予，跳过AM注册（走WM兜底）');
      }
    } catch (e) {
      await DLog.w('SCH','AM 注册失败，忽略: '+e.toString());
    }

    // WM normal
    try {
      final _uniqueN = _wmUniqueNormal(uid, runKey);
      await Workmanager().registerOneOffTask(
        _uniqueN,
        'wm_task',
        initialDelay: normalDelay,
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'normal', 'attempt': 1},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 正常注册完成 uid='+uid+' wm_unique='+_uniqueN+' run='+runKey+' delay='+normalDelay.inSeconds.toString()+'s');
    } catch (e) {
      await DLog.e('SCH','WM 正常注册失败: '+e.toString());
    }

    // WM fallback +2m
    try {
      final _uniqueFB1 = _wmUniqueFallback(uid, runKey, 1);
      await Workmanager().registerOneOffTask(
        _uniqueFB1,
        'wm_task',
        initialDelay: normalDelay + const Duration(minutes: 2),
        inputData: {'job':'wm_run','task_uid': uid, 'run_key': runKey, 'chan':'fallback', 'attempt': 1},
        existingWorkPolicy: ExistingWorkPolicy.replace,
        tag: uid,
      );
      await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+_uniqueFB1+' run='+runKey);
    } catch (e) {
      await DLog.e('SCH','WM 兜底注册失败: '+e.toString());
    }
  }

  static Future<void> scheduleNextForAll() async {
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      await scheduleNextForTask((t['task_uid'] ?? '').toString());
    }
  }

  // precise cancel helpers
  static Future<void> cancelAm(String uid, String runKey) async {
    try { await NativeScheduler.cancel(_alarmId(uid, runKey)); } catch (_) {}
  }
  static Future<void> cancelWmByUnique(String uniqueName) async {
    try { await Workmanager().cancelByUniqueName(uniqueName); } catch (_) {}
  }
  static Future<void> cancelWmNormal(String uid, String runKey) async {
    await cancelWmByUnique(_wmUniqueNormal(uid, runKey));
  }
  static Future<void> cancelWmFallback(String uid, String runKey, int attempt) async {
    await cancelWmByUnique(_wmUniqueFallback(uid, runKey, attempt));
  }

  /// 取消“下一次”计划（AM + WM 正常 + WM 兜底），用于设置页手动取消。
  static Future<void> cancelNextForTask(String uid) async {
    try {
      final t = await TaskDao().getByUid(uid);
      if (t == null) return;
      final next = _nextTimeForTask(t);
      final runKey = _runKeyFromTime(next);
      await cancelAm(uid, runKey);
      await cancelWmNormal(uid, runKey);
      await cancelWmFallback(uid, runKey, 1);
      await cancelWmFallback(uid, runKey, 2);
      await DLog.i('SCH','已取消下一次计划 uid='+uid+' run='+runKey);
    } catch (e) {
      await DLog.e('SCH','取消下一次计划失败: '+e.toString());
    }
  }

  static Future<void> wmRunTask(String uid, String? runKey, {String? chan, int attempt = 1}) async {
    final rk = (runKey ?? _runKeyFromTime(DateTime.now()));
    bool ok = false;
    try {
      ok = await TaskRunner.run(uid);
    } catch (_) {
      ok = false;
    }

    if (ok) {
      await cancelWmFallback(uid, rk, 1);
      await cancelWmFallback(uid, rk, 2);
      if ((chan ?? 'normal') == 'fallback') {
        await cancelWmFallback(uid, rk, attempt);
      } else {
        await cancelWmNormal(uid, rk);
      }
      await _updateNextAndReschedule(uid);
      return;
    }

    if ((chan ?? 'normal') == 'fallback') {
      if (attempt >= 2) {
        await cancelWmFallback(uid, rk, attempt);
      } else {
        await cancelWmFallback(uid, rk, attempt);
        final _uniqueFB2 = _wmUniqueFallback(uid, rk, 2);
        try {
          await Workmanager().registerOneOffTask(
            _uniqueFB2, 'wm_task',
            initialDelay: Duration.zero,
            inputData: {'job':'wm_run','task_uid': uid, 'run_key': rk, 'chan':'fallback', 'attempt': 2},
            existingWorkPolicy: ExistingWorkPolicy.replace,
            tag: uid,
          );
          await DLog.w('SCH','WM 兜底1失败，已注册兜底2(立即) uid='+uid+' wm_unique='+_uniqueFB2+' run='+rk);
        } catch (e) {
          await DLog.e('SCH','注册兜底2失败: '+e.toString());
        }
      }
    } else {
      await cancelWmNormal(uid, rk);
      await _updateNextAndReschedule(uid);
    }
  }

  static Future<void> callback([String? uid, String? runKey]) async {
    if (uid == null || uid.isEmpty) { return; }
    await TaskRunner.run(uid);
  }

  static Future<void> _updateNextAndReschedule(String uid) async {
    try {
      final t = await TaskDao().getByUid(uid);
      if (t != null) {
        final next = _nextTimeForTask(t);
        try { await TaskDao().updateNextTime(uid, next.toIso8601String()); } catch (_) {}
        await scheduleNextForTask(uid);
      }
    } catch (e) {
      await DLog.e('SCH','更新下一次时间失败: '+e.toString());
    }
  }

  static Future<void> catchupIfMissed() async {}
}
