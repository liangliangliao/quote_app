import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart' show BackgroundIsolateBinaryMessenger;
import 'package:quote_app/app_globals.dart';
import '../data/db.dart';
import 'notification_service.dart';
import 'scheduler_service.dart';

class BackgroundBootstrap {
  static bool _inited = false;

  /// 在后台回调（Alarm/WorkManager）里调用，确保必须组件已初始化。
  static Future<void> initForBackground() async {
    if (_inited) return;
    // 1) 基本 Flutter 初始化
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    try {
      if (AppGlobals.rootIsolateToken != null) {
        BackgroundIsolateBinaryMessenger.ensureInitialized(AppGlobals.rootIsolateToken!);
      }
    } catch (_) {}

    // 2) 业务所需初始化（尽量轻量 + 幂等）
    try { await AppDatabase.instance(); } catch (_) {}
    try { await NotificationService.init(); } catch (_) {}
    try { await SchedulerService.init(); } catch (_) {}

    _inited = true;
  }
}