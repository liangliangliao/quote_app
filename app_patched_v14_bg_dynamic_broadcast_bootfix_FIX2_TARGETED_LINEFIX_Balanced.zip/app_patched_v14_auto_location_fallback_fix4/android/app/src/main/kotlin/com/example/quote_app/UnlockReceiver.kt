package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.quote_app.bg.GatekeeperService
import android.database.sqlite.SQLiteDatabase
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.Data
import androidx.work.WorkManager
import com.example.quote_app.data.DbRepo
import com.example.quote_app.NotifyHelper

class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // 1) 解锁/亮屏日志 + 尝试拉起守护服务（best-effort，Android 12+ 可能被限制，但不影响主流程）
        val act = intent?.action
        if (act == Intent.ACTION_SCREEN_ON || act == Intent.ACTION_USER_PRESENT || act == Intent.ACTION_USER_UNLOCKED) {
            try { DbRepo.log(context, null, "正在解锁屏幕将触发通知发送") } catch (_: Throwable) {}
            try { ContextCompat.startForegroundService(context, Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
        }

        // 2) 无条件下发一次 GeoWorker，强制 force_unlock_geo=true（地点触发与开关无关）
        try {
            val request = OneTimeWorkRequestBuilder<com.example.quote_app.GeoWorker>()
                .setInputData(Data.Builder().putBoolean("force_unlock_geo", true).build())
                .build()
            WorkManager.getInstance(context).enqueue(request)
        } catch (_: Throwable) {}

        // 3) 数据库规则：存在解锁触发或者开关开启 => 发送解锁提醒
        try {
            val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(context)
            if (contract == null || contract.dbPath == null) {
                try { DbRepo.log(context, null, "[UnlockReceiver] contract or dbPath unavailable, fallback to send reminder") } catch (_: Throwable) {}
                sendReminder(context)
                return
            }

            val db: SQLiteDatabase = SQLiteDatabase.openDatabase(contract.dbPath, null, SQLiteDatabase.OPEN_READONLY)
            val cursor = db.rawQuery(
                "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                null
            )
            val hasTrigger = cursor.moveToFirst()
            cursor.close()

            var configEnabled = false
            try {
                val c = db.rawQuery(
                    "SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1",
                    null
                )
                if (c.moveToFirst()) {
                    val v = c.getString(0)
                    if (v != null) {
                        val s = v.trim().lowercase()
                        configEnabled = (s == "1" || s == "true")
                    }
                }
                c.close()
            } catch (_: Throwable) { /* ignore DB errors */ }

            try { DbRepo.log(context, null, "[UnlockReceiver] hasTrigger=" + hasTrigger + ", configEnabled=" + configEnabled) } catch (_: Throwable) {}
            db.close()

            if (hasTrigger || configEnabled) {
                // 记录解锁时间，避免 App 刚启动时马上重复提醒
                try {
                    val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                    try { DbRepo.log(context, null, "[UnlockReceiver] wrote last_unlock_time (logs table) at ts=" + System.currentTimeMillis()) } catch (_: Throwable) {}
                } catch (_: Throwable) { /* ignore */ }
                sendReminder(context)
            }
        } catch (_: Throwable) {
            // 兜底：任意异常都直接发送提醒，并写入 last_unlock_time，避免静默失败
            try {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                prefs.edit().putLong("last_unlock_time", System.currentTimeMillis()).apply()
                try { DbRepo.log(context, null, "[UnlockReceiver] wrote last_unlock_time (logs table) at ts=" + System.currentTimeMillis()) } catch (_: Throwable) {}
            } catch (_: Throwable) { /* ignore */ }
            sendReminder(context)
        }
    }

private fun sendReminder(context: Context) {
        // 记录最近一次通过解锁事件发送提醒的时间，方便 App 在启动时
        // 避免立刻再补发一条重复通知。
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_unlock_reminder_time", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
            // ignore
        }

        // Use a deterministic ID to avoid flooding the notification drawer
        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"
        // Pass notifType so that tapping the notification opens the vision focus page
        try {
            DbRepo.log(context, null, "[UnlockReceiver] sending reminder notification at ts=" + System.currentTimeMillis())
        } catch (_: Throwable) {}
        NotifyHelper.send(context, id, title, body, null, "vision_focus", null)

        // No need to enqueue GeoWorker here; it will be scheduled in onReceive unconditionally.
    }
}
