package com.example.quote_app.am

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskUid = intent.getStringExtra("task_uid")
        val runKey  = intent.getStringExtra("run_key")
        if (taskUid.isNullOrEmpty() || runKey.isNullOrEmpty()) {
            Log.e("AlarmReceiver","missing task_uid/run_key → fallback")
            Notifier.fallback(context); return
        }

        val pending = goAsync()
        Thread {
            try {
                val dbPath = DbPaths.quotesDbPath(context)
                val exact = SqliteReader.queryExact(dbPath, taskUid, runKey)
                if (exact != null) {
                    Notifier.notify(context, exact)
                } else {
                    val (from, to) = RunKey.windowBefore(runKey, 30)
                    val near = SqliteReader.queryNearest(dbPath, taskUid, from, to)
                    if (near != null) Notifier.notify(context, near) else {
                        Log.e("AlarmReceiver","payload not found for $taskUid/$runKey → fallback")
                        Notifier.fallback(context)
                    }
                }
            } catch (t: Throwable) {
                Log.e("AlarmReceiver","read db failed: {${t.message}}", t)
                Notifier.fallback(context)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
