package com.example.quote_app.am

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notifier {
    private const val CHANNEL_ID = "quote_channel"

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(CHANNEL_ID, "Quote Reminders", NotificationManager.IMPORTANCE_DEFAULT)
                mgr.createNotificationChannel(ch)
            }
        }
    }

    fun notify(ctx: Context, p: SqliteReader.Payload) {
        ensureChannel(ctx)
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(p.title ?: "提醒")
            .setContentText(p.content ?: "该做正事啦")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify((System.currentTimeMillis()%100000).toInt(), n)
    }

    fun fallback(ctx: Context) {
        notify(ctx, SqliteReader.Payload("提醒","该做正事啦", null, null, null))
    }
}
