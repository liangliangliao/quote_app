import 'dart:isolate';
import 'dart:ui';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import '../data/dao.dart';
import '../data/db.dart';
import '../services/notification_service.dart';
import '../services/openai_service.dart';

const String _isolateName = 'task_alarm_isolate';
SendPort? _uiSendPort;

class SchedulerService {
  static Future<void> init() async {
    await AndroidAlarmManager.initialize();
    await scheduleNextForAll();
  }

  static DateTime? _nextTrigger(DateTime now, Map<String, dynamic> task) {
    try {
      final nrt = (task['next_run_ts'] as int?) ?? 0;
      if (nrt > 0) {
        final dt = DateTime.fromMillisecondsSinceEpoch(nrt);
        if (dt.isAfter(now)) return dt;
      }
      final startTs = (task['start_ts'] as int?) ?? 0;
      final base = startTs > 0
          ? DateTime.fromMillisecondsSinceEpoch(startTs)
          : DateTime(now.year, now.month, now.day, 9, 0);
      final freq = (task['freq_type'] ?? 'daily') as String;
      final wd = (task['freq_weekday'] as int?);
      final md = (task['freq_day_of_month'] as int?);
      return computeNextRunFrom(now,
          freqType: freq, baseTime: base, freqWeekday: wd, freqDayOfMonth: md);
    } catch (_) {
      return null;
    }
  }

  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await TaskDao().all();
    final now = DateTime.now();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final next = _nextTrigger(now, t);
      if (next == null) continue;
      await db.update('tasks', {'next_run_ts': next.millisecondsSinceEpoch},
          where: 'task_uid=?', whereArgs: [t['task_uid']]);
      final id = (t['task_uid'] as String).hashCode & 0x7fffffff;
      await AndroidAlarmManager.oneShotAt(next, id, callback,
          exact: true,
          wakeup: true,
          allowWhileIdle: true,
          rescheduleOnReboot: true);
    }
  }

  @pragma('vm:entry-point')
  static Future<void> callback() async {
    final now = DateTime.now();
    final db = await AppDatabase.instance();
    final tasks = await TaskDao().all();
    final cfg = await ConfigDao().getOne();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final nrt = (t['next_run_ts'] as int?) ?? 0;
      if (nrt == 0) continue;
      final due = DateTime.fromMillisecondsSinceEpoch(nrt);
      if (due.isAfter(now.add(const Duration(seconds: 60)))) continue;

      final type = (t['type'] ?? 'auto') as String;
      final taskUid = (t['task_uid'] ?? '') as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        if (q != null && q.isNotEmpty) {
          await NotificationService.show(
              id: taskUid.hashCode & 0x7fffffff,
              title: name,
              body: q,
              largeIconPath: avatar);
        }
      } else if (type == 'carousel') {
        final current = await QuoteDao().nextCarouselForTask(taskUid);
        if (current != null) {
          await NotificationService.show(
              id: taskUid.hashCode & 0x7fffffff,
              title: name,
              body: (current['content'] as String?) ?? '',
              largeIconPath: avatar);
          await QuoteDao().markNotifiedById(current['id'] as int);
        }
      } else {
        final endpoint = (cfg['endpoint'] as String?)?.trim();
        final apiKey = (cfg['api_key'] as String?)?.trim();
        final model = ((cfg['model'] as String?)?.trim().isNotEmpty ?? false)
            ? (cfg['model'] as String)
            : 'gpt-5';
        final prompt = (t['prompt'] as String?) ?? '';
        if (apiKey != null && apiKey.isNotEmpty) {
          try {
            final svc = OpenAIService(
                endpoint:
                    (endpoint?.isNotEmpty ?? false) ? endpoint! : 'https://api.openai.com/v1/responses',
                apiKey: apiKey,
                model: model);
            String content = '';
            int tries = 0;
            while (tries < 10) {
              tries++;
              final respTxt = await svc.generateQuote(prompt);
              if (respTxt.trim().isEmpty) {
                await LogDao()
                    .add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
                break;
              }
              final dup = await QuoteDao().existsSimilar(respTxt);
              if (dup) {
                if (tries >= 10) {
                  await LogDao().add(
                      taskUid: taskUid, detail: '错误!连续调用api10次去重检验未通过！');
                  break;
                }
                continue;
              } else {
                content = respTxt.trim();
                break;
              }
            }
            if (content.isNotEmpty) {
              final uid = await QuoteDao().insertIfUnique(
                  taskUid: taskUid,
                  type: 'auto',
                  taskName: name,
                  avatarPath: avatar,
                  content: content);
              await LogDao().add(
                  taskUid: taskUid,
                  detail: uid == null ? '错误! 插入名言失败（可能重复）' : '成功!');
              if (uid != null) {
                await NotificationService.show(
                    id: taskUid.hashCode & 0x7fffffff,
                    title: name,
                    body: content,
                    largeIconPath: avatar);
                await QuoteDao().markNotifiedByUid(uid);
              }
            }
          } catch (e) {
            await LogDao()
                .add(taskUid: taskUid, detail: '调用openai api发生错误或失败!');
          }
        } else {
          await LogDao().add(
              taskUid: taskUid, detail: '调用openai api发生错误或失败!(API KEY 为空)');
        }
      }

      final baseTs = (t['start_ts'] as int?) ?? 0;
      final base = baseTs > 0
          ? DateTime.fromMillisecondsSinceEpoch(baseTs)
          : now;
      final freq = (t['freq_type'] ?? 'daily') as String;
      final wd = (t['freq_weekday'] as int?);
      final md = (t['freq_day_of_month'] as int?);
      final next = computeNextRunFrom(now,
          freqType: freq, baseTime: base, freqWeekday: wd, freqDayOfMonth: md);
      await db.update('tasks', {'next_run_ts': next.millisecondsSinceEpoch},
          where: 'task_uid=?', whereArgs: [taskUid]);
    }

    await scheduleNextForAll();
  }
}