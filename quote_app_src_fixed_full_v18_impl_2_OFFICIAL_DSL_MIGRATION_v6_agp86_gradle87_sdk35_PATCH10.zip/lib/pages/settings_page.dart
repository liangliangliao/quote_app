
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _configDao = ConfigDao();
  final _taskDao = TaskDao();

  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');

  bool _configEditing = false;
  List<Map<String,dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await _configDao.getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = ((cfg['endpoint'] ?? '') as String).isNotEmpty ? cfg['endpoint'] as String : 'https://api.openai.com/v1/responses';
    _tasks = await _taskDao.all();
    if (mounted) setState((){});
  }

  Future<void> _saveConfig() async {
    await _configDao.save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim().isEmpty?'gpt-5':_modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
    _configEditing = false;
    if (mounted) setState((){});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('配置已保存')));
  }

  Future<void> _openTaskDialog({Map<String,dynamic>? task}) async {
    final isEdit = task != null;
    final nameCtrl = TextEditingController(text: isEdit ? (task['name'] ?? '') as String : '');
    String type = isEdit ? (task['type'] ?? 'auto') as String : 'auto';
    String freqType = isEdit ? ((task['freq_type'] ?? 'daily') as String) : 'daily';
    int? selectedWeekday = isEdit ? (task['freq_weekday'] as int?) : 1;
    int? selectedMonthDay = isEdit ? (task['freq_day_of_month'] as int?) : 1;
    String freqCustomJson = isEdit ? ((task['freq_custom'] ?? '') as String) : '';
    final promptCtrl = TextEditingController(text: isEdit ? (task['prompt'] ?? '') as String : '');
    DateTime start = DateTime.now().add(const Duration(minutes: 1));
    if (isEdit) {
      try { final ts = (task['start_ts'] as int?); if (ts != null && ts>0) start = DateTime.fromMillisecondsSinceEpoch(ts); } catch (_){}
    }
    String avatarPath = isEdit ? (task['avatar_path'] ?? '') as String : '';
    String status = isEdit ? (task['status'] ?? 'open') as String : 'open';
    final manualQuoteCtrl = TextEditingController();
    if (isEdit && type=='manual') {
      final latest = await QuoteDao().latestForTask(task['task_uid'] as String);
      manualQuoteCtrl.text = latest ?? '';
    }
    if (isEdit && type=='manual') {
      final latest = await QuoteDao().latestForTask(task['task_uid'] as String);
      manualQuoteCtrl.text = latest ?? '';
    }

    final formKey = GlobalKey<FormState>();

    await showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: Text(isEdit ? '编辑任务' : '新增任务'),
        content: StatefulBuilder(builder: (ctx, setStateDialog) {
          Future<void> pickAvatar() async {
            final picker = ImagePicker();
            final x = await picker.pickImage(source: ImageSource.gallery);
            if (x == null) return;
            final bytes = await x.readAsBytes();
            final decoded = img.decodeImage(bytes);
            if (decoded != null) {
              final resized = img.copyResize(decoded, width: 72, height: 72);
              final dir = await getApplicationDocumentsDirectory();
              final file = File('${dir.path}/avatar_${DateTime.now().millisecondsSinceEpoch}.png');
              await file.writeAsBytes(img.encodePng(resized));
              avatarPath = file.path;
              setStateDialog((){});
            }
          }

          Widget timePickerField(){
            return Row(
              children: [
                Expanded(
                  child: Text(
                    '\${start.year.toString().padLeft(4,'0')}-\${start.month.toString().padLeft(2,'0')}-\${start.day.toString().padLeft(2,'0')} '
                    '\${start.hour.toString().padLeft(2,'0')}:\${start.minute.toString().padLeft(2,'0')}'
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.access_time),
                  onPressed: () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(hour: start.hour, minute: start.minute),
                    );
                    if (t != null) {
                      setStateDialog(() {
                        start = DateTime(start.year, start.month, start.day, t.hour, t.minute);
                      });
                    }
                  },
                ),
              ],
            );
          }
          final now = DateTime.now();
          final base = DateTime(now.year, now.month, now.day, start.hour, start.minute);
          final next = computeNextRunFrom(
            now,
            freqType: freqType,
            baseTime: base,
            freqWeekday: selectedWeekday,
            freqDayOfMonth: selectedMonthDay,
          );
          patch['start_ts'] = base.millisecondsSinceEpoch;
          patch['next_run_ts'] = next.millisecondsSinceEpoch;
          await _taskDao.update(task!['task_uid'] as String, patch);
      // Manual task edit: update existing quote instead of inserting new row
      if (type == 'manual') {
        final content = manualQuoteCtrl.text.trim();
        if (content.isNotEmpty) {
          final ok = await QuoteDao().updateLatestForTask(task['task_uid'] as String, content);
          if (!ok) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('未找到该任务的现有名言，未插入新数据（按需求不插入）。')));
          }
        }
      }
    } else {
      // create
      final newUid = await _taskDao.create(
        name: nameCtrl.text.trim(),
        type: type,
        startTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, start.hour, start.minute),
        prompt: type=='auto' ? promptCtrl.text.trim() : '',
        avatarPath: avatarPath,
        status: status,
        freqType: freqType,
        freqWeekday: selectedWeekday,
        freqDayOfMonth: selectedMonthDay,
        freqCustom: freqCustomJson,
      );
      if (type == 'manual') {
        final content = manualQuoteCtrl.text.trim();
        if (content.isNotEmpty) {
          final dup = await QuoteDao().existsSimilar(content);
          if (dup) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('数据重复!请重新输入名人名言')));
            closeNow = false;
          } else {
            await QuoteDao().insertIfUnique(
              taskUid: newUid,
              type: 'manual',
              taskName: nameCtrl.text.trim(),
              avatarPath: avatarPath,
              content: content,
            );
          }
        }
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
    }
    await SchedulerService.scheduleNextForAll();
    await _load();
  } finally {
    if (context.mounted && closeNow) Navigator.pop(context);
  }
}, child: const Text('保存')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final cfgFields = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('API key', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: _apiKeyCtrl, enabled: _configEditing),
        const SizedBox(height: 8),
        const Text('模型名称', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: _modelCtrl, enabled: _configEditing),
        const SizedBox(height: 8),
        const Text('接口地址', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: _endpointCtrl, enabled: _configEditing),
      ],
    );

    final actions = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(onPressed: (){
          setState(()=> _configEditing = true);
        }, icon: const Icon(Icons.edit)),
        IconButton(onPressed: _saveConfig, icon: const Icon(Icons.save)),
      ],
    );

    return Scaffold(
      appBar: AppBar(title: const Text('设置'), actions: [
        IconButton(icon: const Icon(Icons.save), tooltip: '保存配置', onPressed: _saveConfig),
        IconButton(icon: const Icon(Icons.edit), tooltip: '编辑配置', onPressed: (){ setState((){ _configEditing = true;}); }),
      ]),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            cfgFields,
            const SizedBox(height: 16),
            const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ..._tasks.map((t) {
              final startTs = (t['start_ts'] as int?) ?? 0;
              final dt = startTs > 0 ? DateTime.fromMillisecondsSinceEpoch(startTs) : null;
              final y = dt?.year.toString().padLeft(4,'0');
              final m = dt?.month.toString().padLeft(2,'0');
              final d = dt?.day.toString().padLeft(2,'0');
              final hh = dt?.hour.toString().padLeft(2,'0');
              final mm = dt?.minute.toString().padLeft(2,'0');
              final timeStr = dt != null ? '\${y}-\${m}-\${d} \${hh}:\${mm}' : '未设置';
              final typeStr = (t['type'] ?? '') as String;
              final statusStr = (t['status'] ?? '') as String;
              return ListTile(
                title: InkWell(
                  onTap: () => _openTaskDialog(task: t),
                  child: Text((t['name'] ?? '') as String, style: const TextStyle(decoration: TextDecoration.underline)),
                ),
                subtitle: Text('时间: ' + timeStr + '  类型: ' + typeStr + '  状态: ' + statusStr),
              );
            }).toList(),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}