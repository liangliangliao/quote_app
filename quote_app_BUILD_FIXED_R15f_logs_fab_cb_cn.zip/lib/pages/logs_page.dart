import 'package:flutter/material.dart';
import '../data/db.dart';
import 'package:intl/intl.dart';
import '../utils/debug_logger.dart';

class LogsPage extends StatefulWidget {
  const LogsPage({super.key});
  @override
  State<LogsPage> createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> {
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _items = [];
  int _page = 0;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _load(reset: true);
  }

  Future<void> _load({bool reset = false}) async {
    if (_loading) return;
    _loading = true;
    if (reset) {
      _items = [];
      _page = 0;
    }
    final db = await AppDatabase.instance();
    final rows = await db.rawQuery(
        'SELECT logs.*, COALESCE(logs.task_name_snapshot, tasks.name, "") AS task_name, '
        'COALESCE(logs.task_start_time_snapshot, tasks.start_time, "") AS task_start_time '
        'FROM logs LEFT JOIN tasks ON tasks.task_uid = logs.task_uid '
        'ORDER BY logs.id DESC LIMIT ? OFFSET ?',
        [100, _page * 100]);
    setState(() {
      _items.addAll(rows);
      _page++;
      _loading = false;
    });
  }

  String _fmt(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    try {
      final dt = DateTime.parse(iso);
      return DateFormat('yyyy-MM-dd HH:mm:ss').format(dt);
    } catch (_) {
      return iso;
    }
  }

  Future<void> _clearLogs() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('清空日志'),
        content: const Text('确定要删除所有日志吗？此操作不可恢复。'),
        actions: [
          TextButton(onPressed: ()=> Navigator.pop(ctx, false), child: const Text('取消')),
          ElevatedButton(onPressed: ()=> Navigator.pop(ctx, true), child: const Text('确认删除')),
        ],
      ),
    );
    if (ok != true) return;
    final db = await AppDatabase.instance();
    await db.delete('logs');
    await DLog.i('LOGS', '已清空所有日志');
    if (!mounted) return;
    setState(() { _items.clear(); _page = 0; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('日志')),
      floatingActionButton: FloatingActionButton(
        onPressed: _clearLogs,
        child: const Icon(Icons.delete_sweep),
      ),
      body: NotificationListener<ScrollNotification>(
        onNotification: (n) {
          if (n.metrics.pixels >= n.metrics.maxScrollExtent - 100) {
            _load();
          }
          return false;
        },
        child: ListView.builder(
          controller: _scroll,
          itemCount: _items.length,
          itemBuilder: (ctx, i) {
            final e = _items[i];
            final detail = e['detail'] as String? ?? '';
            final title = (e['task_name'] as String? ?? '').isEmpty
                ? '系统'
                : (e['task_name'] as String);
            final subt = _fmt(e['created_at_iso'] as String? ?? e['created_at_text'] as String? ?? '');
            final isErr = detail.contains('【错误】');
            return ListTile(
              leading: Icon(isErr ? Icons.error_outline : Icons.info_outline),
              title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(detail),
              trailing: Text(subt),
            );
          },
        ),
      ),
    );
  }
}
