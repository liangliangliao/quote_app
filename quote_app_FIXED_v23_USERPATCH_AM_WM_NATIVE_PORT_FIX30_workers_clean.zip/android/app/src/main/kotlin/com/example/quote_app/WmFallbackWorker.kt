package com.example.quote_app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.quote_app.data.DbRepository
import com.example.quote_app.schedule.NextTriggerCalculator
import com.example.quote_app.biz.Biz
import org.json.JSONObject

class WmFallbackWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val id = inputData.getInt("id", 0)
    val payload = inputData.getString("payload") ?: "{}"
    val o = JSONObject(payload)
    val uid = o.optString("uid", "")
    val runKey = o.optString("runKey", "")

    if (uid.isNotEmpty()) {
      val entered = DbRepository.runGuardBegin(applicationContext, uid, runKey, "wm_fallback")
      if (!entered) return Result.success()
      try {
        val handled = Biz.run(applicationContext, uid)
        if (handled) {
          DbRepository.markLatestSuccess(applicationContext, uid)
          val next = NextTriggerCalculator.compute(applicationContext, uid)
          if (next > 0) NativeSchedulerK.scheduleExactWmCompat(applicationContext, id, next, payload)
          WorkManager.getInstance(applicationContext).cancelUniqueWork("wm_once_" + id)
          return Result.success()
        } else {
          return Result.retry()
        }
      } catch (t: Throwable) {
        DbRepository.log(applicationContext, uid, "WM兜底异常: " + (t.message ?: "未知错误"))
        return Result.retry()
      } finally {
        DbRepository.runGuardEnd(applicationContext, uid, runKey, "wm_fallback")
      }
    } else {
      // 无 uid 不做 DB 处理，只作为占位成功返回
      return Result.success()
    }
  }
}
