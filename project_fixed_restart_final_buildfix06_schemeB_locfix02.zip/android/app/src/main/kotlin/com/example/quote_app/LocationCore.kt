package com.example.quote_app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.HandlerThread
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * 统一定位能力：
 * - 系统高精度流（Fused -> GPS/Network）
 * - Baidu SDK（由调用方决定是否需要；这里不强依赖）
 * - 最近已知位置（lastKnown）
 */
object LocationCore {

  private fun hasAnyLocationPermission(ctx: Context): Boolean {
    return try {
      val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
      val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
      fine || coarse
    } catch (_: Throwable) {
      false
    }
  }

  // （debugEnv / getSystemHighAccLikeManual 定义在下方，避免重复实现）

  /**
   * 系统高精度流：优先 Fused（更稳），失败再用 LocationManager（GPS/Network）。
   * 返回 best effort：
   * - 若在 timeout 内达到 targetAccMeters 会尽快返回
   * - 否则返回 timeout 内的最优精度位置
   */
  @JvmStatic
  fun getSystemHighAcc(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    if (!hasAnyLocationPermission(ctx)) return null
    // 1) Fused
    val fused = runCatching { obtainFusedHighAccOnWorkerLooper(ctx, targetAccMeters, timeoutMs, minUpdates = 1) }.getOrNull()
    if (fused != null) return fused

    // 2) GPS/Network stream
    return runCatching { obtainGpsHighAccOnWorkerLooper(ctx, targetAccMeters, timeoutMs, minUpdates = 1) }.getOrNull()
  }

  /**
   * 对齐“新增地点规则-手动定位”（SysChannel.getSystemLocationOnce）的系统定位实现：
   * - Fused 高精度流（更长收敛）-> LocationManager(GPS/Network)
   * - best-effort：即使未达到 targetAcc 也返回 timeout 内的最优位置
   * - 使用独立 HandlerThread 的 looper 接收回调，避免在解锁瞬间主线程繁忙导致收不到回调。
   */
  @JvmStatic
  fun getSystemHighAccLikeManual(
    ctx: Context,
    targetAccMeters: Double,
    fusedTimeoutMs: Long,
    gpsTimeoutMs: Long,
  ): Location? {
    if (!hasAnyLocationPermission(ctx)) return null

    // 1) Fused（若设备无 GMS/不可用则会快速失败，直接进入 2)
    val fused = runCatching { obtainFusedHighAccOnWorkerLooper(ctx, targetAccMeters, fusedTimeoutMs, minUpdates = 2) }.getOrNull()
    if (fused != null) return fused

    // 2) GPS/Network stream
    return runCatching { obtainGpsHighAccOnWorkerLooper(ctx, targetAccMeters, gpsTimeoutMs, minUpdates = 2) }.getOrNull()
  }

  /** 输出定位环境信息，便于排查“为什么取不到位置”。 */
  @JvmStatic
  fun debugEnv(ctx: Context): String {
    return try {
      val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
      val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val gpsOn = runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)
      val netOn = runCatching { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)
      val locOn = if (android.os.Build.VERSION.SDK_INT >= 28) {
        runCatching { lm.isLocationEnabled }.getOrDefault(gpsOn || netOn)
      } else {
        gpsOn || netOn
      }
      "perm(fine=$fine, coarse=$coarse), locationEnabled=$locOn, gps=$gpsOn, network=$netOn"
    } catch (_: Throwable) {
      "env_unknown"
    }
  }

  @JvmStatic
  fun getLastKnown(ctx: Context): Location? {
    if (!hasAnyLocationPermission(ctx)) return null
    return try {
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val list = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
      list.mapNotNull { p ->
        try { lm.getLastKnownLocation(p) } catch (_: Throwable) { null }
      }.maxByOrNull { it.time }
    } catch (_: Throwable) {
      null
    }
  }

  private fun obtainFusedHighAccOnWorkerLooper(
    ctx: Context,
    targetAccMeters: Double,
    timeoutMs: Long,
    minUpdates: Int,
  ): Location? {
    val ht = HandlerThread("geo-fused-loc").apply { start() }
    return try {
      val client = LocationServices.getFusedLocationProviderClient(ctx)
      val latch = CountDownLatch(1)
      var best: Location? = null
      var seen = 0

      val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
        .setWaitForAccurateLocation(true)
        .setMaxUpdates(6)
        .build()

      val cb = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
          for (l in result.locations) {
            seen++
            if (best == null || l.accuracy < best!!.accuracy) best = l
          }
          if (best != null && best!!.accuracy <= targetAccMeters && seen >= minUpdates) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
        }
      }

      try { client.requestLocationUpdates(req, cb, ht.looper) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { client.removeLocationUpdates(cb) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) {
      null
    } finally {
      try { ht.quitSafely() } catch (_: Throwable) { try { ht.quit() } catch (_: Throwable) {} }
    }
  }

  private fun obtainGpsHighAccOnWorkerLooper(
    ctx: Context,
    targetAccMeters: Double,
    timeoutMs: Long,
    minUpdates: Int,
  ): Location? {
    val ht = HandlerThread("geo-gps-loc").apply { start() }
    return try {
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val latch = CountDownLatch(1)
      var best: Location? = null
      var seen = 0

      val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
          seen++
          if (best == null || loc.accuracy < best!!.accuracy) best = loc
          if (best != null && best!!.accuracy <= targetAccMeters && seen >= minUpdates) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
        }

        @Deprecated("deprecated")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
      }

      try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, ht.looper) } catch (_: Throwable) {}
      try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 0f, listener, ht.looper) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) {
      null
    } finally {
      try { ht.quitSafely() } catch (_: Throwable) { try { ht.quit() } catch (_: Throwable) {} }
    }
  }

}
