import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../data/dao.dart';

/// A helper service to obtain the current device location in a robust manner.
///
/// This service first attempts to use the Geolocator plugin to obtain the
/// current position with high accuracy. If that fails (for example on
/// devices without Google Play services in Mainland China), it falls back
/// to Baidu's IP‑based geolocation API. The Baidu API key is read from
/// the notify_config table (key = 'baidu_ak'). If no key is configured,
/// the fallback will be skipped and null is returned.
class LocationService {
  /// Attempts to obtain the current position. Returns a [Position] if
  /// successful, otherwise returns null.
  static Future<Position?> getCurrentPositionSmart() async {
    // Try using Geolocator first
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 4),
      );
      return pos;
    } catch (_) {
      // ignore and fall through to Baidu
    }
    // Fallback to Baidu IP location if configured
    try {
      final ak = await NotifyConfigDao().getBaiduAk();
      if (ak.trim().isEmpty) {
        return null;
      }
      final url = Uri.parse(
        'https://api.map.baidu.com/location/ip?ak=${Uri.encodeComponent(ak.trim())}&coor=wgs84',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && data['status'] == 0) {
          final content = data['content'];
          if (content is Map) {
            final point = content['point'];
            if (point is Map) {
              final latStr = point['y']?.toString() ?? '';
              final lngStr = point['x']?.toString() ?? '';
              final lat = double.tryParse(latStr);
              final lng = double.tryParse(lngStr);
              if (lat != null && lng != null) {
                // Construct a Position with minimal fields; other fields left at zero
                return Position(
                  latitude: lat,
                  longitude: lng,
                  timestamp: DateTime.now(),
                  accuracy: 0,
                  altitude: 0,
                  heading: 0,
                  speed: 0,
                  speedAccuracy: 0,
                );
              }
            }
          }
        }
      }
    } catch (_) {
      // ignore network or JSON errors
    }
    return null;
  }
}