package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver 作为解锁链路的「入口点」：
 *
 * - 由 Manifest 静态注册，系统在解锁/亮屏时即使应用在后台也会回调此 Receiver；
 * - 这里只做非常轻量的工作：记录中文日志 + 弹出 Toast 提示用户「已检测到解锁」；
 * - 然后将真正的业务逻辑（数据库检查 / 冷却 / 通知发送 / Geo 调度）
 *   交给 WorkManager 中的 UnlockWorker 在后台线程执行。
 *
 * 注意：整个链路不再依赖前台守护服务（ScreenGatekeeperService），
 * 以避免 Android 12+ 对后台启动前台服务的限制，同时减少电量消耗。
 */
class UnlockReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "null"

        // 记录收到的广播 action，方便排查「是否确实收到了系统解锁广播」
        try {
            DbRepo.log(
                context,
                null,
                "【解锁提醒】UnlockReceiver.onReceive：收到系统广播 action=" + action
            )
        } catch (_: Throwable) {
        }

        // 仅对解锁/亮屏相关广播进行后续处理
        val isUnlockAction =
            (Intent.ACTION_USER_PRESENT == action) ||
                (Intent.ACTION_USER_UNLOCKED == action) ||
                (Intent.ACTION_SCREEN_ON == action)

        if (!isUnlockAction) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver.onReceive：收到的并非解锁相关广播，本次不调度 UnlockWorker，直接返回"
                )
            } catch (_: Throwable) {
            }
            return
        }

        // 在后台也弹出一个简单的 Toast，提示用户链路已被触发（仅作为调试/体验提示）
        try {
            Toast.makeText(
                context.applicationContext,
                "检测到解锁，正在检查愿景提醒…",
                Toast.LENGTH_SHORT
            ).show()
        } catch (_: Throwable) {
            // 某些 ROM 可能限制后台 Toast，这里只做 best-effort
        }

        // 将真正的解锁业务逻辑交给 WorkManager 处理
        try {
            val request = OneTimeWorkRequestBuilder<UnlockWorker>()
                .addTag("unlock_event")
                .build()
            WorkManager.getInstance(context.applicationContext).enqueue(request)

            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver.onReceive：已成功向 WorkManager 提交 UnlockWorker 任务，tag=unlock_event"
                )
            } catch (_: Throwable) {
            }
        } catch (e: Throwable) {
            // 这里捕获所有异常，避免因为 WorkManager 异常导致广播处理崩溃
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver.onReceive：调度 UnlockWorker 失败，异常类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {
            }
        }
    }
}
