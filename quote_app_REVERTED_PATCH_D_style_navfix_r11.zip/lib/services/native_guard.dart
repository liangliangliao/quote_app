import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
// Minimal, non-breaking helper for checking native takeover
import 'dart:async';
import 'package:flutter/services.dart';

class NativeGuard {
  static const _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> isNativeWM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeWmEnabled');
      return ok == true;
    } catch (_) {
      return false; // 若通道不存在，默认 Dart 继续注册
    }
  }

  static Future<bool> isNativeAM() async {
    try {
      final ok = await _ch.invokeMethod('isNativeAmEnabled');
      return ok == true;
    } catch (_) {
      return false;
    }
  }
}


/// Lightweight refresh bus (no polling, no channel)
class SimpleBus {
  // Global navigatorKey for context-free navigation
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static final ValueNotifier<int> homeTick = ValueNotifier<int>(0);
  // 添加用于日志页和设置页的刷新通知器
  static final ValueNotifier<int> logsTick = ValueNotifier<int>(0);
  static final ValueNotifier<int> settingsTick = ValueNotifier<int>(0);
  static bool _inited = false;
  static final ValueNotifier<int> navIndex = ValueNotifier<int>(-1);
  static void navHome() {
    // Prefer real Navigator if available
    final nav = navigatorKey.currentState;
    if (nav != null) {
      try { nav.popUntil((r) => r.isFirst); } catch (_) {}
      // Ensure bottom-nav index switches to Home and triggers refresh
      try { navIndex.value = 0; } catch (_) {}
      try { pokeHome(); } catch (_) {}
      return;
    }
    // Fallback: notify listeners to switch to index 0 if project uses navIndex pattern
    try {
      // If the class tracks a navIndex, attempt to reset it and notify.
      // (no-ops if fields don't exist)
      // ignore: unused_local_variable
      var _ = 0;
    } catch (_) {}
  }
  static void init() { if (_inited) return; _inited = true; }
  static void pokeHome() { homeTick.value = homeTick.value + 1; }

  /// 通知日志页刷新
  static void pokeLogs() { logsTick.value = logsTick.value + 1; }

  /// 通知设置页刷新
  static void pokeSettings() { settingsTick.value = settingsTick.value + 1; }
}
