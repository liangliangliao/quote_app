package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.os.Environment
import java.io.File

object Channels {
  private lateinit var appContext: Context
    fun areNotificationsEnabled(): Boolean {
        return try {
            val nm = androidx.core.app.NotificationManagerCompat.from(appContext)
            nm.areNotificationsEnabled()
        } catch (_: Throwable) { true }
    }

  private const val CH = "native.scheduler"

  fun register(engine: FlutterEngine, appCtx: Context) {
    appContext = appCtx.applicationContext
        appContext = appCtx.applicationContext
  MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      try {
        when (call.method) {
            "shouldAskExactAlarm" -> {
                val firstLaunch = (call.argument<Boolean>("firstLaunch") ?: false)
                result.success(shouldAskExactAlarm(firstLaunch))
        return@setMethodCallHandler@setMethodCallHandler
            }
                "isNativeWM" -> result.success(true)
                "isNativeAM" -> result.success(true)
          "canScheduleExact" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))
          "scheduleExactAt" -> {
            val id = call.argument<Int>("id") ?: 0
            val epochMs = call.argument<Long>("epochMs") ?: 0L
            val payload = call.argument<String>("payload")
            val ok = NativeSchedulerK.scheduleExactAt(appCtx, id, epochMs, payload)
            result.success(ok)
          }
          "cancel" -> {
            val id = call.argument<Int>("id") ?: 0
            NativeSchedulerK.cancel(appCtx, id)
            result.success(null)
          }
          "cancelAll" -> { NativeSchedulerK.cancelAll(appCtx); result.success(null) }
                    "scheduleWmPair" -> {
            val uid = call.argument<String>("uid")
            val runKey = call.argument<String>("runKey")
            val triggerAt = call.argument<Long>("triggerAtMillis")
            if (uid == null || runKey == null || triggerAt == null) {
              result.error("ARG","uid/runKey/triggerAtMillis missing", null)
            } else {
              com.example.quote_app.wm.WmScheduler.schedulePair(appCtx, triggerAt, uid, runKey)
              result.success(true)
            }
          }
          "scheduleKickAt" -> {
            val arg = call.arguments as? Map<*, *>
            val uid = arg?.get("uid") as? String
            val runKey = arg?.get("runKey") as? String
            val at = (arg?.get("triggerAtMillis") as? Number)?.toLong()
            if (uid == null || runKey == null || at == null) {
              result.error("ARG", "uid/runKey/triggerAtMillis missing", null)
            } else {
              com.example.quote_app.wm.WmScheduler.scheduleKick(appCtx, at, uid, runKey)
              result.success(true)
            }
          }
          "cancelKick" -> {
            val arg = call.arguments as? Map<*, *>
            val uid = arg?.get("uid") as? String
            val runKey = arg?.get("runKey") as? String
            if (uid == null || runKey == null) {
              result.error("ARG", "uid/runKey missing", null)
            } else {
              com.example.quote_app.wm.WmScheduler.cancelKick(appCtx, uid, runKey)
              result.success(true)
            }
          }
          "cancelWmByUnique" -> {
            val unique = call.argument<String>("unique")
            if (unique == null) {
              result.error("ARG","unique missing", null)
            } else {
              com.example.quote_app.wm.WmScheduler.cancelByUnique(appCtx, unique)
              result.success(true)
            }
          }
          
          
          
          "cancelExactById" -> {
            val arg = call.arguments as? Map<*, *>
            val uid = arg?.get("uid") as? String
            val rk  = arg?.get("runKey") as? String
            if (uid.isNullOrEmpty() || rk.isNullOrEmpty()) {
              result.error("ARG","uid/runKey missing", null)
            } else {
              val id = com.example.quote_app.compat.DartParity.alarmId(uid, rk)
              NativeSchedulerK.cancel(appCtx, id)
              result.success(true)
            }
          }
"cancelExactByNext" -> {
            val arg = call.arguments as? Map<*, *>
            val uid = arg?.get("uid") as? String
            val at = (arg?.get("triggerAtMillis") as? Number)?.toLong()
            if (uid == null || at == null) {
              result.error("ARG","uid/triggerAtMillis missing", null)
            } else {
              val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
            val runKey = fmt.format(java.util.Date(at))
            val id = com.example.quote_app.compat.DartParity.alarmId(uid, runKey)
              NativeSchedulerK.cancel(appCtx, id)
              result.success(true)
            }
          }
          "cancelWmByUidBoth" -> {
            val uid = call.argument<String>("uid")
            if (uid == null) {
              result.error("ARG","uid missing", null)
            } else {
              com.example.quote_app.compat.WmCancelCompat.cancelBoth(appCtx, uid)
              result.success(true)
            }
          }
          "dbInfo" -> {
            try {
              val arg = call.arguments as? Map<*, *>
              val path = arg?.get("dbPath") as? String
              val ver = (arg?.get("version") as? Int) ?: 1
              if (!path.isNullOrEmpty()) {
                android.util.Log.i("Channels", "dbInfo received path=" + path + " ver=" + ver + " schema=" + ( (arg?.get("schema") as? Map<*,*>)?.size ?: 0))
                // save minimal contract into prefs so DbInspector can pick it up
                val o = org.json.JSONObject()
                o.put("dbPath", path)
                o.put("version", ver)
                o.put("logsSource", "logs");
                o.put("tasksSource", "tasks");
                o.put("quotesSource", "quotes");
                val logMap = org.json.JSONObject();
                logMap.put("uid", "task_uid");
                logMap.put("detail", "detail");
                o.put("logColMap", logMap);
                val taskMap = org.json.JSONObject();
                taskMap.put("uid", "task_uid");
                taskMap.put("title", "name");
                taskMap.put("content", "prompt");
                taskMap.put("avatar", "avatar_path");
                taskMap.put("enabled", "status");
                taskMap.put("trigger_at", "start_time");
                taskMap.put("next_time", "next_time");
                o.put("taskColMap", taskMap);
                val quoteMap = org.json.JSONObject();
                quoteMap.put("uid", "task_uid");
                quoteMap.put("content", "content");
                o.put("quoteColMap", quoteMap)
                // optional: persist full schema if provided by Dart
                val schemaArg = arg?.get("schema")
                if (schemaArg is Map<*, *>) {
                    val schemaJson = org.json.JSONObject(schemaArg)
                    o.put("schema", schemaJson)
                }
                val sp = android.preference.PreferenceManager.getDefaultSharedPreferences(appCtx)
                sp.edit().putString("db.contract", o.toString()).apply()
                result.success(true)
              } else result.error("bad_args","missing path", null)
            } catch (t: Throwable) { result.error("ERR", t.message, null) }
          }
    
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
        // System/perm support channel used by Dart (PermHelper & NativeGuard)
    MethodChannel(engine.dartExecutor.binaryMessenger, "com.example.quote_app/sys").setMethodCallHandler { call, result ->
      try {
        when (call.method) {
          "createNoMediaGuards" -> {
            try {
              // Create .nomedia in app-specific external files (Pictures & root)
              val dirs = arrayOf(
                appCtx.getExternalFilesDir(null),
                appCtx.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                appCtx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
              )
              for (d in dirs) {
                if (d != null) {
                  if (!d.exists()) d.mkdirs()
                  try {
                    val nm = File(d, ".nomedia")
                    if (!nm.exists()) nm.createNewFile()
                  } catch (_: Throwable) {}
                }
              }
              result.success(true)
            } catch (t: Throwable) { result.error("ERR", t.message, null) }
          }

          "isNativeWmEnabled" -> result.success(true)
          "isNativeAmEnabled" -> result.success(true)
          "hasExactAlarmPermission" -> result.success(ExactAlarmHelper.hasExactAlarmPermission(appCtx))
          "requestExactAlarmPermission" -> result.success(ExactAlarmHelper.requestExactAlarmPermission(appCtx))
          
          
          "cancelExactByNext" -> {
            val arg = call.arguments as? Map<*, *>
            val uid = arg?.get("uid") as? String
            val at = (arg?.get("triggerAtMillis") as? Number)?.toLong()
            if (uid == null || at == null) {
              result.error("ARG","uid/triggerAtMillis missing", null)
            } else {
              val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
            val runKey = fmt.format(java.util.Date(at))
            val id = com.example.quote_app.compat.DartParity.alarmId(uid, runKey)
              NativeSchedulerK.cancel(appCtx, id)
              result.success(true)
            }
          }
          "cancelWmByUidBoth" -> {
            val uid = call.argument<String>("uid")
            if (uid == null) {
              result.error("ARG","uid missing", null)
            } else {
              com.example.quote_app.compat.WmCancelCompat.cancelBoth(appCtx, uid)
              result.success(true)
            }
          }
          "dbInfo" -> {
            try {
              val arg = call.arguments as? Map<*, *>
              val path = arg?.get("dbPath") as? String
              val ver = (arg?.get("version") as? Int) ?: 1
              if (!path.isNullOrEmpty()) {
                android.util.Log.i("Channels", "dbInfo received path=" + path + " ver=" + ver + " schema=" + ( (arg?.get("schema") as? Map<*,*>)?.size ?: 0))
                // save minimal contract into prefs so DbInspector can pick it up
                val o = org.json.JSONObject()
                o.put("dbPath", path)
                o.put("version", ver)
                o.put("logsSource", "logs");
                o.put("tasksSource", "tasks");
                o.put("quotesSource", "quotes");
                val logMap = org.json.JSONObject();
                logMap.put("uid", "task_uid");
                logMap.put("detail", "detail");
                o.put("logColMap", logMap);
                val taskMap = org.json.JSONObject();
                taskMap.put("uid", "task_uid");
                taskMap.put("title", "name");
                taskMap.put("content", "prompt");
                taskMap.put("avatar", "avatar_path");
                taskMap.put("enabled", "status");
                taskMap.put("trigger_at", "start_time");
                taskMap.put("next_time", "next_time");
                o.put("taskColMap", taskMap);
                val quoteMap = org.json.JSONObject();
                quoteMap.put("uid", "task_uid");
                quoteMap.put("content", "content");
                o.put("quoteColMap", quoteMap)
                // optional: persist full schema if provided by Dart
                val schemaArg = arg?.get("schema")
                if (schemaArg is Map<*, *>) {
                    val schemaJson = org.json.JSONObject(schemaArg)
                    o.put("schema", schemaJson)
                }
                val sp = android.preference.PreferenceManager.getDefaultSharedPreferences(appCtx)
                sp.edit().putString("db.contract", o.toString()).apply()
                result.success(true)
              } else result.error("bad_args","missing path", null)
            } catch (t: Throwable) { result.error("ERR", t.message, null) }
          }
    
          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.error("ERR", t.message, null)
      }
    }
    
  }

  fun shouldAskExactAlarm(firstLaunch: Boolean): Boolean {
    return if (!firstLaunch) true else areNotificationsEnabled()
  }

}
}
