
import 'package:flutter/material.dart';
import '../data/dao.dart';
import 'package:intl/intl.dart';
import '../utils/debug_logger.dart';

class LogsPage extends StatefulWidget {
  const LogsPage({super.key});
  @override
  State<LogsPage> createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> {
  final _dao = LogDao();
  final _scroll = ScrollController();
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && !_done) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 50, offset: _offset);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 50) _done = true;
  }

  @override
  Widget build(BuildContext context) {
    String fmt(String? s){
  if (s == null || s.isEmpty) return '';
  try {
    // 多格式严格解析
    final patterns = ['yyyy-MM-dd HH:mm:ss.SSS','yyyy-MM-dd HH:mm:ss','yyyy-MM-dd HH:mm','yyyy/MM/dd HH:mm'];
    for (final p in patterns) {
      try {
        final dt = DateFormat(p).parseStrict(s);
        return DateFormat('yyyy-MM-dd HH:mm').format(dt);
      } catch (_){}
    }
    // 从字符串中提取 yyyy-MM-dd HH:mm
    final m = RegExp(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2})').firstMatch(s);
    if (m != null) {
      final dt = DateFormat('yyyy-MM-dd HH:mm').parseStrict(m.group(1)!);
      return DateFormat('yyyy-MM-dd HH:mm').format(dt);
    }
    // 10/13 位时间戳
    if (RegExp(r'^\d{10,13}\$').hasMatch(s)) {
      final ms = s.length == 13 ? int.parse(s) : int.parse(s) * 1000;
      final dt = DateTime.fromMillisecondsSinceEpoch(ms);
      return DateFormat('yyyy-MM-dd HH:mm').format(dt);
    }
    // 失败直接原样返回，不再记录错误日志，避免刷屏
    return s;
  } catch (_){
    return s;
  }
}

    return ListView.builder(
      controller: _scroll,
      itemCount: _items.length,
      itemBuilder: (_, i){
        final e = _items[i];
        final detail = (e['detail'] ?? '') as String;
        final isErr = detail.contains('错误');
        final isOk = detail.contains('成功');
        final style = TextStyle(
          color: isErr ? Colors.red : isOk ? Colors.green : null,
          fontWeight: (isErr || isOk) ? FontWeight.bold : null
        );
        return ListTile(
          leading: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text((e['task_name'] ?? '') as String, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(fmt(e['task_start_time'] as String?)),
            ],
          ),
          title: Text(detail, style: style),
        );
      },
    );
  }
}