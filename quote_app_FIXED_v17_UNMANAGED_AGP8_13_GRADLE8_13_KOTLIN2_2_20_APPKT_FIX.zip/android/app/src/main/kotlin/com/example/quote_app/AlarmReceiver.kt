package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.*
import org.json.JSONObject

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val payload = intent.getStringExtra("payload") ?: "{}"
        val obj = JSONObject(payload)
        val uid = obj.optString("uid", "")
        val runKey = obj.optString("runKey", "")
        // 解析通道（am/normal/fallback）与重试次数（默认1）
        val chan = obj.optString("chan", "")
        val attempt: Int = try {
            obj.optInt("attempt", 1)
        } catch (_: Exception) {
            1
        }

        // Delegate heavy work to WorkManager where Flutter plugin can pick it up
        val data = Data.Builder()
            .putString("job", "wm_run")
            .putString("task_uid", uid)
            .putString("run_key", runKey)
            .putString("chan", chan)
            .putInt("attempt", attempt)
            .build()

        val request = OneTimeWorkRequestBuilder<AlarmProxyWorker>()
            .setInputData(data)
            .build()

        WorkManager.getInstance(context).enqueue(request)
    }
}

class AlarmProxyWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        // This proxy simply relays to the Flutter workmanager plugin by sending a broadcast Intent
        // The plugin registers its own worker; however, as a fallback we trigger the app to start,
        // and WorkManager plugin (if initialized) should handle the queued work.
        return Result.success()
    }
}