import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:workmanager/workmanager.dart';

import 'data/db.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'services/wm_dispatcher.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/logs_page.dart';
import 'pages/settings_page.dart';
import 'utils/debug_logger.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();

  // 基础设施初始化（必须在 runApp 之前）：DB、通知、AlarmManager、WorkManager
  await AppDatabase.instance();
  await NotificationService.init();
  await AndroidAlarmManager.initialize();
  await Workmanager().initialize(
    workmanagerCallbackDispatcher,
    isInDebugMode: false,
  );

  // 调度初始化 + 启动兜底重排（首启空表也安全）
  await DLog.i('SCH', 'init start (from main)');
  await SchedulerService.init();
  await SchedulerService.scheduleNextForAll();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const _Shell(),
    );
  }
}

class _Shell extends StatefulWidget {
  const _Shell({super.key});
  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: '首页'),
          NavigationDestination(icon: Icon(Icons.history), label: '历史'),
          NavigationDestination(icon: Icon(Icons.list), label: '日志'),
          NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
        ],
        onDestinationSelected: (i) => setState(() => _idx = i),
      ),
    );
  }
}
