import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import '../services/sport_music_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import '../data/dao.dart';
import '../data/sport_dao.dart';
import '../services/native_sport_fg.dart';
import '../services/sport_bg_tracker.dart';

/// 运动进行中页
///
/// 关键特性（对齐需求）：
/// - 支持计划/非计划记录恢复：从 sport_records 读取并恢复步数/距离/用时/状态
/// - 进程被杀后：record(in_progress) 在启动时被置为 paused（由 SportDao.markInProgressAsPaused）；
///   进入本页会直接恢复暂停态并允许继续
/// - 步数：优先使用 Android StepCounter 传感器（EventChannel），避免 GPS 估算造成延迟/不准
/// - 运动过程中周期性持久化（每 3 秒一次 + 状态变更时）防止数据丢失
class SportRunningPage extends StatefulWidget {
  final int recordId;
  final Map<String, dynamic>? plan;
  final String mode; // plan / instant

  const SportRunningPage({
    super.key,
    required this.recordId,
    this.plan,
    required this.mode,
  });

  @override
  State<SportRunningPage> createState() => _SportRunningPageState();
}

class _SportRunningPageState extends State<SportRunningPage> {
  final SportDao _dao = SportDao();
  final ConfigDao _configDao = ConfigDao();

  static const MethodChannel _sys = MethodChannel('com.example.quote_app/sys');
  static const EventChannel _stepsCh = EventChannel('com.example.quote_app/steps');

  final AudioPlayer _audioPlayer = AudioPlayer();
  // Background music playlist (loop)
  List<String> _musicPlaylist = <String>[];
  String _musicMode = 'order'; // order / random
  int _musicIndex = 0;
  bool _musicStarted = false;
  final Random _musicRandom = Random();

  // UI settings
  String? _bgImagePath;
  String? _startSoundPath;

  // Quote
  String _quoteContent = '生命在于运动';
  String _quoteAuthor = '';
  String _quoteExplanation = '';

  // State
  String _status = 'loading'; // not_started / in_progress / paused / stopped / completed
  int _countdown = 5;
  bool _ready = false;

  // Actual start timestamp (written when countdown ends or when restart begins).
  String? _startedAtIso;


  // Progress
  double _distance = 0.0; // meters
  int _steps = 0;
  int _stepsOffset = 0; // for sensor reset on resume
  int _elapsedOffsetSec = 0; // persisted elapsed seconds
  final Stopwatch _segmentWatch = Stopwatch();

  // Location
  Position? _lastPosition;
  Position? _startPosition;
  StreamSubscription<Position>? _posSub;
  DateTime? _lastPosTs;

  // For distance/speed: track accepted points to suppress GPS drift while stationary.
  Position? _lastAcceptedPosition;
  DateTime? _lastAcceptedTs;
  int _stationaryStreak = 0;

  // Pending movement confirmation window (to suppress GPS drift spikes while stationary).
  Position? _pendingPosition;
  DateTime? _pendingPositionTs;
  DateTime? _pendingStartTs;
  double _pendingDistance = 0.0;
  int _pendingCount = 0;
  int _pendingStartSteps = 0;
  DateTime? _inProgressStartedAt;

  double _currentSpeedMps = 0.0;


  // Steps
  StreamSubscription<dynamic>? _stepsSub;
  bool _sensorStepsActive = false;

  // Timers
  Timer? _countdownTimer;
  Timer? _uiTimer;
  Timer? _persistTimer;
  // Background/restore support:
  // - Android: keep collecting via native foreground service even if page is left or app task removed.
  // - iOS/others: keep collecting within the same process via a Dart singleton tracker when leaving this page.
  bool _nativeFgMode = false; // Android-only native foreground mode
  Timer? _dbPollTimer;
  double _currentSpeedKmh = 0.0;


  // Plan
  int? _planId;
  Map<String, dynamic>? _loadedPlan;

  Map<String, dynamic>? get _plan => widget.plan ?? _loadedPlan;
  String get _targetType => (_plan?['target_type'] ?? 'steps').toString();
  double? get _targetValue => _plan?['target_value'] is num ? (_plan?['target_value'] as num).toDouble() : null;
  String get _targetUnit => (_plan?['target_unit'] ?? '步').toString();

  Duration get _totalElapsed {
    if (_nativeFgMode) return Duration(seconds: _elapsedOffsetSec);
    return Duration(seconds: _elapsedOffsetSec + _segmentWatch.elapsed.inSeconds);
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _initLocationPerm();
    await _loadUiSettings();
    await _loadQuote();
    await _restoreFromRecord();
    // Ensure we don't double-count if a background tracker was running while this page was not visible.
    // ignore: discarded_futures
    SportBgTracker.instance.stopIfRunning(widget.recordId);

    if (!mounted) return;
    setState(() {
      _ready = true;
    });
    // New record: start 5s countdown. Resumed record: keep state.
    if (_status == 'not_started' && _elapsedOffsetSec == 0 && _steps == 0 && _distance == 0.0) {
      _startCountdown();
    } else {
      _startUiTimer();
      if (_status == 'in_progress') {
        // If user re-enters the running page while the session is still in progress:
        // - Android: keep using native foreground tracking + DB polling
        // - Others: resume in-page sensors
        if (Platform.isAndroid || Platform.isIOS) {
          _nativeFgMode = true;
          // ignore: discarded_futures
          
NativeSportFg.ensureStarted(
  recordId: widget.recordId,
  title: (_plan?['title'] ?? widget.plan?['title'] ?? '运动进行中').toString(),
  targetType: (_plan?['target_type'] ?? widget.plan?['target_type'])?.toString(),
  targetValue: (() {
    final v = _plan?['target_value'] ?? widget.plan?['target_value'];
    if (v is num) return v.toDouble();
    return double.tryParse(v?.toString() ?? '');
  })(),
  targetUnit: (_plan?['target_unit'] ?? widget.plan?['target_unit'])?.toString(),
);
          _startDbPollTimer();
          // Pull immediately once to render without 1s delay.
          // ignore: discarded_futures
          _refreshFromDb();
        } else {
          _resumeRunning(startTimers: true);
        }
      }
    }
  }

  Future<void> _initLocationPerm() async {
    try {
      // Request permission proactively; some devices won't start streams otherwise.
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        // Can't force-enable here; just return and let stream fail gracefully.
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      // If deniedForever, don't spam dialogs.
    } catch (_) {}
  }

  Future<void> _loadUiSettings() async {
    try {
      final bg = await _configDao.getSportRunningBg();
      final sound = await _configDao.getSportStartSound();
      final list = await _configDao.getSportMusicPlaylist();
      final mode = await _configDao.getSportMusicMode();
      if (!mounted) return;
      setState(() {
        _bgImagePath = (bg?.trim().isEmpty ?? true) ? null : bg;
        _startSoundPath = (sound?.trim().isEmpty ?? true) ? null : sound;
        _musicPlaylist = list;
        _musicMode = (mode == 'random') ? 'random' : 'order';
      });

      // Setup playlist (global service) so music can continue across pages.
      await SportMusicService.instance.configure(playlist: list, mode: _musicMode);
    } catch (_) {}
  }

  Future<void> _loadQuote() async {
    try {
      final q = await _dao.getRandomSportQuote();
      if (q == null) return;
      if (!mounted) return;
      setState(() {
        _quoteContent = (q['content'] ?? _quoteContent).toString();
        _quoteAuthor = (q['author'] ?? '').toString();
        _quoteExplanation = (q['explanation'] ?? '').toString();
      });
    } catch (_) {}
  }

  Future<void> _restoreFromRecord() async {
    final r = await _dao.getRecord(widget.recordId);
    if (r == null) return;

    _planId = r['plan_id'] as int?;
    if (widget.plan == null && _planId != null) {
      try {
        _loadedPlan = await _dao.getPlan(_planId!);
      } catch (_) {}
    }

    final st = (r['status'] ?? 'not_started').toString();
    final startIso = (r['start_time'] ?? '').toString();
    final dur = (r['total_duration'] is num) ? (r['total_duration'] as num).toInt() : 0;
    final steps = (r['total_steps'] is num) ? (r['total_steps'] as num).toInt() : 0;
    final dist = (r['total_distance'] is num) ? (r['total_distance'] as num).toDouble() : 0.0;

    // Start location
    try {
      final sl = (r['start_location'] ?? '').toString();
      if (sl.isNotEmpty) {
        final m = jsonDecode(sl);
        if (m is Map && m['lat'] != null && m['lon'] != null) {
          _startPosition = Position(
            latitude: (m['lat'] as num).toDouble(),
            longitude: (m['lon'] as num).toDouble(),
            timestamp: DateTime.now(),
            accuracy: 0,
            altitude: 0,
            heading: 0,
            speed: 0,
            speedAccuracy: 0,
            floor: null,
            isMocked: false,
            headingAccuracy: 0,
            altitudeAccuracy: 0,
          );
        }
      }
    } catch (_) {}

    setState(() {
      _status = st;
      _startedAtIso = startIso.isEmpty ? null : startIso;
      _elapsedOffsetSec = dur;
      _steps = steps;
      _distance = dist;
      _stepsOffset = steps;
    });


  }

  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdown = 5;
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        _countdown -= 1;
      });
      if (_countdown <= 0) {
        t.cancel();
        _startRunningFromCountdown();
      }
    });
  }

  Future<void> _startRunningFromCountdown() async {
    if (!mounted) return;
    setState(() {
      _status = 'in_progress';
    });
    _startedAtIso = DateTime.now().toIso8601String();
    await _playStartBell();
    _segmentWatch
      ..reset()
      ..start();
    _elapsedOffsetSec = 0;
    _distance = 0.0;
    _steps = 0;
    _stepsOffset = 0;
    _startPosition = null;
    _lastPosition = null;
    _lastAcceptedPosition = null;
    _lastAcceptedTs = null;
    _stationaryStreak = 0;
    _pendingPosition = null;
    _pendingPositionTs = null;
    _pendingStartTs = null;
    _pendingDistance = 0.0;
    _pendingCount = 0;
    _pendingStartSteps = 0;
    _inProgressStartedAt = DateTime.now();

    if (Platform.isAndroid || Platform.isIOS) {
      _nativeFgMode = true;
      // Persist start fields before starting native service so it can restore correctly.
      _startUiTimer();
      await _startMusicLoopIfNeeded();
      await _persistProgress(reason: 'start');
      await _syncPlanStatus('in_progress');
      // Start Android native foreground tracking (survives leaving page / removing recent task).
      // ignore: discarded_futures
      NativeSportFg.ensureStarted(recordId: widget.recordId, title: (_plan?['title'] ?? '运动进行中').toString());
      _startDbPollTimer();
      // Pull immediately.
      // ignore: discarded_futures
      _refreshFromDb();
      return;
    }
    await _startMusicLoopIfNeeded();
    _startUiTimer();
    _startPersistTimer();
    await _persistProgress(reason: 'start');
    await _syncPlanStatus('in_progress');
  }

  void _startUiTimer() {
    _uiTimer?.cancel();
    _uiTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {});
      _checkTargetReached();
    });
  }

  Future<void> _startSensors() async {
    await _startStepStream();
    await _startLocationStream();
  }

  void _stopSensors() {
    _posSub?.cancel();
    _posSub = null;
    _stopStepStream();
  }

  Future<void> _startStepStream() async {
    // Ask runtime permission on Android 10+.
    try {
      final st = await Permission.activityRecognition.request();
      if (!st.isGranted) {
        _sensorStepsActive = false;
        return;
      }
    } catch (_) {
      // If permission_handler doesn't support the platform, ignore.
    }

    try {
      await _sys.invokeMethod('resetStepCounter');
    } catch (_) {}

    _stepsSub?.cancel();
    _sensorStepsActive = true;
    _stepsSub = _stepsCh.receiveBroadcastStream().listen((v) {
      if (!_sensorStepsActive) return;
      final x = (v is num) ? v.toInt() : int.tryParse(v.toString());
      if (x == null) return;
      if (!mounted) return;
      setState(() {
        _steps = _stepsOffset + x;
      });
    }, onError: (_) {
      _sensorStepsActive = false;
    });
  }

  void _stopStepStream() {
    _sensorStepsActive = false;
    _stepsSub?.cancel();
    _stepsSub = null;
  }

  Future<void> _startLocationStream() async {
    _posSub?.cancel();
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      final perm = await Geolocator.checkPermission();
      if (!enabled || perm == LocationPermission.deniedForever || perm == LocationPermission.denied) {
        // If location isn't available, keep distance at 0 but don't crash.
        return;
      }
    } catch (_) {
      // If geolocator throws, still try to subscribe; onError will handle.
    }

    _posSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        // Use a slightly larger distance filter to suppress jitter/drift.
        distanceFilter: 5,
      ),
    ).listen(
      _onPositionUpdate,
      onError: (_) {
        // If stream errors (permission revoked, GPS off...), decay speed to 0.
        _currentSpeedMps = 0.0;
      },
    );
  }

  void _onPositionUpdate(Position pos) {
    if (_status != 'in_progress') return;

    // First location as start location
    _startPosition ??= pos;

    final nowTs = pos.timestamp ?? DateTime.now();

    // Always track the raw last fix (even if we reject it for distance) to keep timestamps moving.
    final accCur = (pos.accuracy.isFinite) ? pos.accuracy : 0.0;
    _lastPosition = pos;
    _lastPosTs = nowTs;

    // Drop extremely inaccurate points early.
    // NOTE: Some devices often report 60~90m indoors; don't block all movement.
    if (accCur > 120) {
      _stationaryStreak++;
      if (_stationaryStreak >= 3) {
        _currentSpeedMps = 0.0;
      } else {
        _currentSpeedMps *= 0.85;
      }
      return;
    }

    // Initialize accepted anchor.
    _lastAcceptedPosition ??= pos;
    _lastAcceptedTs ??= nowTs;

    final lastAcc = _lastAcceptedPosition!;
    final lastAccTs = _lastAcceptedTs!;
    final accLast = (lastAcc.accuracy.isFinite) ? lastAcc.accuracy : 0.0;

    final dist = Geolocator.distanceBetween(
      lastAcc.latitude,
      lastAcc.longitude,
      pos.latitude,
      pos.longitude,
    );

    // Time delta (seconds) based on accepted anchor.
    final dtMs = nowTs.difference(lastAccTs).inMilliseconds;
    final dtSec = dtMs <= 0 ? 0.001 : dtMs / 1000.0;

    // Compute speed from distance/time; use sensor speed only if it's reasonable (often 0 on many devices).
    final computedSpeed = (dist.isFinite && dist > 0) ? (dist / dtSec) : 0.0;
    final sensorSpeed = (pos.speed.isFinite && pos.speed > 0.3) ? pos.speed : 0.0;
    final speedMps = max(computedSpeed, sensorSpeed);

    final warmupActive = _inProgressStartedAt != null &&
        nowTs.difference(_inProgressStartedAt!).inSeconds < 8;

    // Jitter / drift gate:
    // - Require displacement larger than the accuracy radius (scaled).
    // - Require a plausible speed.
    // This reduces "原地漂移" (distance grows while staying still).
    final baseAcc = max(accCur, accLast);
    final threshold = max(4.0, min(25.0, baseAcc * 1.2));

    var candidateOk = true;
    var rejectedByJitter = false;
    if (!dist.isFinite || dist <= 0) {
      candidateOk = false;
      rejectedByJitter = true;
    } else if (dist < threshold) {
      candidateOk = false;
      rejectedByJitter = true;
    } else if (dist > 120 && speedMps > 10) {
      // Huge jump with very high speed -> likely a bad fix.
      candidateOk = false;
    } else {
      // Speed gate: accept when either sensor speed is reliable,
      // or computed speed is plausible with decent accuracy.
      final okBySensor = sensorSpeed > 0.6;
      final okByComputedStrict = (computedSpeed > 0.8 && baseAcc <= 20);
      final okByComputedLoose = (computedSpeed > 1.2 && baseAcc <= 35);
      if (!(okBySensor || okByComputedStrict || okByComputedLoose)) {
        candidateOk = false;
        rejectedByJitter = true;
      }
    }

    if (candidateOk) {
      // Build a short "confirmation" window before committing distance.
      // This prevents single GPS drift spikes from immediately inflating distance.
      if (_pendingCount == 0) {
        _pendingStartTs = nowTs;
        _pendingStartSteps = _steps;
        _pendingDistance = dist;
        _pendingCount = 1;
        _pendingPosition = pos;
        _pendingPositionTs = nowTs;
      } else {
        final prev = _pendingPosition;
        if (prev != null) {
          final seg = Geolocator.distanceBetween(
            prev.latitude,
            prev.longitude,
            pos.latitude,
            pos.longitude,
          );
          if (seg.isFinite && seg > 0) {
            _pendingDistance += seg;
          }
        }
        _pendingCount += 1;
        _pendingPosition = pos;
        _pendingPositionTs = nowTs;
      }

      final pendingAgeSec = _pendingStartTs == null ? 0 : nowTs.difference(_pendingStartTs!).inSeconds;
      final stepsDelta = _steps - _pendingStartSteps;
      final hasStepEvidence = !_sensorStepsActive || stepsDelta >= 1;

      // Confirm movement: need consecutive points and enough cumulative displacement.
      final requiredCount = _sensorStepsActive ? 2 : 3;
      final requiredDistBase = _sensorStepsActive ? 10.0 : 15.0;
      final accSum = accCur + accLast;
      final requiredDist = max(requiredDistBase, min(30.0, accSum * 1.2));

      var confirmed = _pendingCount >= requiredCount &&
          _pendingDistance >= requiredDist &&
          hasStepEvidence &&
          (!warmupActive || stepsDelta >= 1);

      // If step sensor is active but there are still no steps after a while,
      // treat it as drift: move the anchor without adding distance.
      if (_sensorStepsActive && stepsDelta < 1 && pendingAgeSec >= 10) {
        confirmed = false;
        _lastAcceptedPosition = pos;
        _lastAcceptedTs = nowTs;
        _pendingPosition = null;
        _pendingPositionTs = null;
        _pendingStartTs = null;
        _pendingDistance = 0.0;
        _pendingCount = 0;
        _pendingStartSteps = _steps;
        _stationaryStreak = max(_stationaryStreak, 2);
        _currentSpeedMps = 0.0;
        return;
      }

      if (confirmed) {
        _distance += _pendingDistance;
        // Fallback step estimation when sensor unavailable
        if (!_sensorStepsActive) {
          _steps = (_distance / 0.7).floor();
        }
        _lastAcceptedPosition = _pendingPosition;
        _lastAcceptedTs = _pendingPositionTs;
        _stationaryStreak = 0;
        // Low-pass filter for display speed.
        _currentSpeedMps = _currentSpeedMps * 0.6 + speedMps * 0.4;

        // Clear pending window.
        _pendingPosition = null;
        _pendingPositionTs = null;
        _pendingStartTs = null;
        _pendingDistance = 0.0;
        _pendingCount = 0;
        _pendingStartSteps = _steps;
      } else {
        // Not confirmed yet: if no steps, keep speed 0 to avoid fake km/h while stationary.
        if (_sensorStepsActive && stepsDelta < 1) {
          _currentSpeedMps = 0.0;
        } else {
          _currentSpeedMps *= 0.85;
        }
      }
    } else {
      // Clear pending window on rejection.
      if (_pendingCount > 0) {
        _pendingPosition = null;
        _pendingPositionTs = null;
        _pendingStartTs = null;
        _pendingDistance = 0.0;
        _pendingCount = 0;
        _pendingStartSteps = _steps;
      }

      // Stationary detection:
      // - if rejected by jitter gate, treat as stationary
      // - otherwise use small speed to detect stationary
      if (rejectedByJitter) {
        _stationaryStreak++;
      } else if (speedMps < 0.3) {
        _stationaryStreak++;
      } else {
        _stationaryStreak = 0;
      }

      if ((_stationaryStreak >= 2 && rejectedByJitter) || _stationaryStreak >= 3) {
        _currentSpeedMps = 0.0;
      } else {
        _currentSpeedMps *= 0.85;
      }
    }
  }

  Future<void> _playStartBell() async {
    try {
      final p = _startSoundPath;
      if (p != null && p.isNotEmpty) {
        await _audioPlayer.stop();
        await _audioPlayer.play(DeviceFileSource(p));
        return;
      }
    } catch (_) {}
    try {
      await _sys.invokeMethod('playSystemNotificationSound');
    } catch (_) {}
  }

  Future<void> _startMusicLoopIfNeeded() async {
  try {
    if (_musicPlaylist.isEmpty) return;
    if (_status != 'in_progress') return;
    await SportMusicService.instance.configure(playlist: _musicPlaylist, mode: _musicMode);
    await SportMusicService.instance.startIfNeeded();
    _musicStarted = SportMusicService.instance.isStarted;
    if (_musicStarted) {
      // Keep local index in range (service tracks its own index internally).
      if (_musicIndex < 0 || _musicIndex >= _musicPlaylist.length) {
        _musicIndex = 0;
      }
    }
  } catch (_) {}
}

Future<void> _playMusicAt(int idx) async {
  try {
    if (_musicPlaylist.isEmpty) return;
    await SportMusicService.instance.configure(playlist: _musicPlaylist, mode: _musicMode);
    final safeIdx = idx.clamp(0, _musicPlaylist.length - 1);
    _musicIndex = safeIdx;
    await SportMusicService.instance.playAt(safeIdx);
    _musicStarted = true;
  } catch (_) {}
}

void _playNextMusic() {
  if (!_musicStarted) return;
  if (_musicPlaylist.isEmpty) return;
  if (_status != 'in_progress') return;

  int next = _musicIndex;
  if (_musicPlaylist.length == 1) {
    next = 0;
  } else if (_musicMode == 'random') {
    next = _musicRandom.nextInt(_musicPlaylist.length);
    // Avoid repeating the same track when possible.
    if (next == _musicIndex) {
      next = (next + 1) % _musicPlaylist.length;
    }
  } else {
    next = (_musicIndex + 1) % _musicPlaylist.length;
  }
  _musicIndex = next;
  // ignore: discarded_futures
  _playMusicAt(_musicIndex);
}

Future<void> _pauseMusic() async {
  try {
    await SportMusicService.instance.pause();
  } catch (_) {}
}

Future<void> _stopMusic() async {
  try {
    await SportMusicService.instance.stop();
  } catch (_) {}
  _musicStarted = false;
}



  String _formatDuration(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    // Do NOT escape '$' here, otherwise UI will literally show "$h:$m:$s".
    return '$h:$m:$s';
  }

  String _formatDistance(double meters) {
    if (!meters.isFinite || meters <= 0) return '0 m';
    if (meters < 1000) {
      return '${meters.toStringAsFixed(1)} m';
    }
    return '${(meters / 1000.0).toStringAsFixed(2)} km';
  }

  String _formatSpeedKmH(double mps) {
    if (!mps.isFinite || mps <= 0) return '0.00 km/h';
    final kmh = (mps * 3.6).clamp(0, 99.0);
    return '${kmh.toStringAsFixed(2)} km/h';
  }

  double _calcAvgSpeedKmH() {
    final sec = _totalElapsed.inSeconds;
    if (sec <= 0) return 0;
    final hours = sec / 3600.0;
    return (_distance / 1000.0) / hours;
  }

  void _togglePause() async {
    if (_nativeFgMode) {
      if (_status == 'in_progress') {
        // Pause: keep metrics in DB, just mark status and stop native foreground tracking.
        await _refreshFromDb();
        await _pauseMusic();
        setState(() {
          _status = 'paused';
          _stepsOffset = _steps;
        });
        try {
          await _dao.updateRecord(widget.recordId, {'status': 'paused'});
        } catch (_) {}
        await _syncPlanStatus('paused');
        await NativeSportFg.stop();
        _stopDbPollTimer();
        return;
      }
      if (_status == 'paused') {
        // Resume
        setState(() {
          _status = 'in_progress';
        });
        try {
          await _dao.updateRecord(widget.recordId, {'status': 'in_progress'});
        } catch (_) {}
        await _syncPlanStatus('in_progress');
        // ignore: discarded_futures
        NativeSportFg.ensureStarted(recordId: widget.recordId, title: (_plan?['title'] ?? '运动进行中').toString());
        _startDbPollTimer();
        // ignore: discarded_futures
        _startMusicLoopIfNeeded();
        return;
      }
    }
    if (_status == 'in_progress') {
      // pause
      _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
      _segmentWatch
        ..stop()
        ..reset();
      _stopSensors();
      await _pauseMusic();
      setState(() {
        _status = 'paused';
        _stepsOffset = _steps;
      });
      await _persistProgress(reason: 'pause');
      await _syncPlanStatus('paused');
      return;
    }
    if (_status == 'paused') {
      // resume
      setState(() {
        _status = 'in_progress';
      });

      // Reset motion filters so the first GPS fix after resume does not create a large jump.
      _lastAcceptedPosition = null;
      _lastAcceptedTs = null;
      _stationaryStreak = 0;
      _pendingPosition = null;
      _pendingPositionTs = null;
      _pendingStartTs = null;
      _pendingDistance = 0.0;
      _pendingCount = 0;
      _pendingStartSteps = _steps;
      _inProgressStartedAt = DateTime.now();

      _segmentWatch
        ..reset()
        ..start();
      _stepsOffset = _steps;
      await _startSensors();
      await _startMusicLoopIfNeeded();
      _startPersistTimer();
      await _persistProgress(reason: 'resume');
      await _syncPlanStatus('in_progress');
    }
  }

  void _stop() async {
    if (_nativeFgMode) {
      await _refreshFromDb();
      await NativeSportFg.stop();
      _stopDbPollTimer();
      await _stopMusic();
      setState(() {
        _status = 'stopped';
        _stepsOffset = _steps;
      });
      await _persistProgress(reason: 'stop', forceEndTime: true);
      await _syncPlanStatus('stopped');
      if (mounted) Navigator.of(context).pop();
      return;
    }

    if (_status == 'completed') return;
    if (_status == 'in_progress') {
      _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
    }
    _segmentWatch
      ..stop()
      ..reset();
    _stopSensors();
    await _stopMusic();
    setState(() {
      _status = 'stopped';
      _stepsOffset = _steps;
    });
    await _persistProgress(reason: 'stop');
    await _syncPlanStatus('stopped');
    // stopped is not completed; keep record for resume.
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  void _restart() async {
    if (_nativeFgMode) {
      await _refreshFromDb();
      await NativeSportFg.stop();
      _stopDbPollTimer();
      final now = DateTime.now().toIso8601String();
      setState(() {
        _status = 'in_progress';
        _elapsedOffsetSec = 0;
        _steps = 0;
        _stepsOffset = 0;
        _distance = 0.0;
        _currentSpeedKmh = 0.0;
        _currentSpeedMps = 0.0;
      });
      await _dao.updateRecord(widget.recordId, <String, dynamic>{
        'start_time': now,
        'end_time': null,
        'total_duration': 0,
        'paused_total_sec': 0,
        'total_steps': 0,
        'total_distance': 0.0,
        'avg_speed': 0.0,
        'current_speed': 0.0,
        'status': 'in_progress',
        'updated_at': now,
      });
      await _syncPlanStatus('in_progress');
      _startUiTimer();
      await _startMusicLoopIfNeeded();
      // ignore: discarded_futures
      NativeSportFg.ensureStarted(recordId: widget.recordId, title: (_plan?['title'] ?? '运动进行中').toString());
      _startDbPollTimer();
      // ignore: discarded_futures
      _refreshFromDb();
      return;
    }

    // Reset and start immediately (no countdown) – aligns with “重新开始”行为
    _elapsedOffsetSec = 0;
    _distance = 0;
    _steps = 0;
    _stepsOffset = 0;
    _startPosition = null;
    _lastPosition = null;
    _lastAcceptedPosition = null;
    _lastAcceptedTs = null;
    _stationaryStreak = 0;
    _pendingPosition = null;
    _pendingPositionTs = null;
    _pendingStartTs = null;
    _pendingDistance = 0.0;
    _pendingCount = 0;
    _pendingStartSteps = _steps;
    _inProgressStartedAt = DateTime.now();
    _segmentWatch
      ..reset()
      ..start();
    _startedAtIso = DateTime.now().toIso8601String();
    setState(() {
      _status = 'in_progress';
    });
    await _startSensors();
    await _startMusicLoopIfNeeded();
    _startUiTimer();
    _startPersistTimer();
    await _persistProgress(reason: 'restart');
    await _syncPlanStatus('in_progress');
  }

  void _resumeRunning({required bool startTimers}) {
    _segmentWatch
      ..reset()
      ..start();
    _lastAcceptedPosition = null;
    _lastAcceptedTs = null;
    _stationaryStreak = 0;
    _pendingPosition = null;
    _pendingPositionTs = null;
    _pendingStartTs = null;
    _pendingDistance = 0.0;
    _pendingCount = 0;
    _pendingStartSteps = _steps;
    _inProgressStartedAt = DateTime.now();
    _startSensors();
    // Best-effort: resume music only when actually running.
    // ignore: discarded_futures
    _startMusicLoopIfNeeded();
    if (startTimers) {
      _startUiTimer();
      _startPersistTimer();
    }
  }

  void _checkTargetReached() {
    if (_status != 'in_progress') return;
    final targetVal = _targetValue;
    if (targetVal == null || targetVal <= 0) return;

    double progress;
    if (_targetType == 'steps') {
      progress = _steps.toDouble();
    } else if (_targetType == 'duration') {
      // target_value uses hours in plan dialog
      progress = _totalElapsed.inSeconds / 3600.0;
    } else {
      progress = _distance / 1000.0;
    }
    if (progress >= targetVal) {
      _complete();
    }
  }

  Future<void> _complete({String? dialogTitle, String? dialogContent}) async {
    if (_status == 'completed') return;
    if (_nativeFgMode) {
      await _refreshFromDb();
      await NativeSportFg.stop();
      _stopDbPollTimer();
      await _stopMusic();
      setState(() {
        _status = 'completed';
        _stepsOffset = _steps;
      });
    } else {
    _elapsedOffsetSec += _segmentWatch.elapsed.inSeconds;
    _segmentWatch
      ..stop()
      ..reset();
    _stopSensors();
    await _stopMusic();
    setState(() {
      _status = 'completed';
      _stepsOffset = _steps;
    });

    }
    // Try to fetch a fresh end location once (best-effort).
    Position? endPos = _lastPosition;
    try {
      endPos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    } catch (_) {
      // retry once
      try {
        endPos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
      } catch (_) {}
    }
    if (endPos != null) _lastPosition = endPos;

    await _persistProgress(reason: 'complete', forceEndTime: true);
    await _syncPlanStatus('completed');

    if (!mounted) return;
    final title = dialogTitle ?? (widget.mode == 'instant' ? '已结束' : '已完成');
    final content = dialogContent ?? (widget.mode == 'instant' ? '本次运动已结束！' : '运动已达标！');

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('确定'),
          ),
        ],
      ),
    );
    if (mounted) Navigator.of(context).pop();
  }

  void _startPersistTimer() {
    _persistTimer?.cancel();
    _persistTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (_status == 'in_progress') {
        _persistProgress(reason: 'tick');
      }
    });
  }

  void _startDbPollTimer() {
    _dbPollTimer?.cancel();
    _dbPollTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      // Keep UI variables fresh from DB, so returning to this page restores correctly.
      _refreshFromDb();
    });
  }

  void _stopDbPollTimer() {
    _dbPollTimer?.cancel();
    _dbPollTimer = null;
  }

  Future<void> _refreshFromDb() async {
    // iOS native tracking persists metrics in native side; sync into DB on resume/poll.
    if (Platform.isIOS && _nativeFgMode) {
      final snap = await NativeSportFg.getSnapshot(widget.recordId);
      if (snap != null) {
        final dur = (snap['total_duration'] is num)
            ? (snap['total_duration'] as num).toInt()
            : int.tryParse(snap['total_duration']?.toString() ?? '') ?? 0;
        final steps = (snap['total_steps'] is num)
            ? (snap['total_steps'] as num).toInt()
            : int.tryParse(snap['total_steps']?.toString() ?? '') ?? 0;
        final dist = (snap['total_distance'] is num)
            ? (snap['total_distance'] as num).toDouble()
            : double.tryParse(snap['total_distance']?.toString() ?? '') ?? 0.0;
        final curSp = (snap['current_speed'] is num)
            ? (snap['current_speed'] as num).toDouble()
            : double.tryParse(snap['current_speed']?.toString() ?? '') ?? 0.0;
        final avgSp = (snap['avg_speed'] is num)
            ? (snap['avg_speed'] as num).toDouble()
            : double.tryParse(snap['avg_speed']?.toString() ?? '') ?? 0.0;
        try {
          await _dao.updateRecord(widget.recordId, {
            'status': 'in_progress',
            'total_duration': dur,
            'total_steps': steps,
            'total_distance': dist,
            'current_speed': curSp,
            'avg_speed': avgSp,
          });
        } catch (_) {
          // ignore
        }
      }
    }
    try {
      final rec = await _dao.getRecord(widget.recordId);
      if (rec == null) return;
      final st = (rec['status'] ?? '').toString();
      final dur = (rec['total_duration'] is num) ? (rec['total_duration'] as num).toInt() : int.tryParse(rec['total_duration']?.toString() ?? '') ?? 0;
      final steps = (rec['total_steps'] is num) ? (rec['total_steps'] as num).toInt() : int.tryParse(rec['total_steps']?.toString() ?? '') ?? 0;
      final dist = (rec['total_distance'] is num) ? (rec['total_distance'] as num).toDouble() : double.tryParse(rec['total_distance']?.toString() ?? '') ?? 0.0;
      final sp = (rec['current_speed'] is num) ? (rec['current_speed'] as num).toDouble() : double.tryParse(rec['current_speed']?.toString() ?? '') ?? 0.0;
      if (!mounted) return;
      setState(() {
        _status = st.isEmpty ? _status : st;
        _elapsedOffsetSec = dur;
        _steps = steps;
        _distance = dist;
        _currentSpeedKmh = sp;
        _currentSpeedMps = sp / 3.6;
      });
    } catch (_) {
      // ignore
    }
  }


  Future<void> _persistProgress({required String reason, bool forceEndTime = false}) async {
    // Persist minimal progress frequently to avoid loss on crash/kill.
    final now = DateTime.now().toIso8601String();
    final totalSec = _totalElapsed.inSeconds;
    final m = <String, dynamic>{
      'updated_at': now,
      'status': _status,
      'total_duration': totalSec,
      'total_steps': _steps,
      'total_distance': _distance,
      'avg_speed': _calcAvgSpeedKmH(),
    };

    // Only set start_time when the session actually begins.
    // For resumed records, keep the original start_time.
    if ((reason == 'start' || reason == 'restart') && (_startedAtIso != null && _startedAtIso!.isNotEmpty)) {
      m['start_time'] = _startedAtIso;
    }
    if (_startPosition != null) {
      m['start_location'] = jsonEncode({'lat': _startPosition!.latitude, 'lon': _startPosition!.longitude});
    }
    if (forceEndTime || _status == 'completed') {
      m['end_time'] = now;
      if (_lastPosition != null) {
        m['end_location'] = jsonEncode({'lat': _lastPosition!.latitude, 'lon': _lastPosition!.longitude});
      }
    }

    try {
      await _dao.updateRecord(widget.recordId, m);
    } catch (_) {
      // ignore: local DB failure is rare; periodic writes reduce loss anyway.
    }
  }

  Future<void> _syncPlanStatus(String status) async {
    final pid = _planId;
    if (pid == null) return;
    try {
      await _dao.updatePlanStatus(pid, status);
    } catch (_) {}
  }

  @override
  void dispose() {
    _uiTimer?.cancel();
    _persistTimer?.cancel();
    _countdownTimer?.cancel();
    _stopDbPollTimer();
    // Stop in-page sensors (UI is leaving), but DO NOT pause/stop the workout state.
    // Data collection continues via:
    // - Android: native foreground service
    // - iOS/others: Dart background tracker (within same process)
    if (_status == 'in_progress') {
      // Keep background music playing when leaving this page (per product requirement).
      // Do NOT pause/stop here.
      if (!_nativeFgMode) {
        // Start Dart tracker so leaving this page doesn't stop collection.
        // ignore: discarded_futures
        SportBgTracker.instance.startIfNeeded(recordId: widget.recordId);
      }
    }
    _stopSensors();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return Scaffold(
        appBar: AppBar(title: const Text('运动进行中')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final elapsed = _totalElapsed;

    final targetVal = _targetValue;
    final remainingText = () {
      if (targetVal == null || targetVal <= 0) return '';
      double progress;
      double remain;
      String unit;
      if (_targetType == 'steps') {
        progress = _steps.toDouble();
        remain = targetVal - progress;
        unit = '步';
      } else if (_targetType == 'duration') {
        progress = elapsed.inSeconds / 3600.0;
        remain = targetVal - progress;
        unit = '小时';
      } else {
        progress = _distance / 1000.0;
        remain = targetVal - progress;
        unit = 'km';
      }
      if (remain < 0) remain = 0;
      return '剩余: ${remain.toStringAsFixed(1)} $unit';
    }();

    final statusText = _status == 'in_progress'
        ? '进行中'
        : _status == 'paused'
            ? '已暂停'
            : _status == 'stopped'
                ? '已停止'
                : _status == 'completed'
                    ? '已完成'
                    : '未开始';

    final hasBottomBar = !(_status == 'not_started' || _status == 'completed');
    // When extendBody=true, body will render behind bottomNavigationBar.
    // Add extra bottom padding so content isn't covered by the action buttons.
    final bottomPad = 16.0 + MediaQuery.of(context).padding.bottom + (hasBottomBar ? (kBottomNavigationBarHeight + 12) : 0);

    return Scaffold(
      appBar: AppBar(title: const Text('运动进行中')),
      // Let the background extend behind the transparent BottomAppBar.
      extendBody: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Full-screen background
          Positioned.fill(
            child: (_bgImagePath != null && _bgImagePath!.isNotEmpty && File(_bgImagePath!).existsSync())
                ? Image.file(
                    File(_bgImagePath!),
                    fit: BoxFit.cover,
                    alignment: Alignment.center,
                    width: double.infinity,
                    height: double.infinity,
                  )
                : Container(color: Colors.white),
          ),
          // Overlay to keep text readable while keeping background visible
          Positioned.fill(
            child: (_bgImagePath != null && _bgImagePath!.isNotEmpty)
                ? Container(color: Colors.white.withOpacity(0.55))
                : const SizedBox.shrink(),
          ),
          // Main content; use Positioned.fill so Stack always expands to full screen.
          Positioned.fill(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, bottomPad),
              child: Column(
                children: [
                Card(
                  color: const Color(0xFFF0F8FF).withOpacity(0.92),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Text(
                          _quoteContent,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        if (_quoteAuthor.trim().isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text('—— $_quoteAuthor', textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic)),
                        ],
                        if (_quoteExplanation.trim().isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(_quoteExplanation, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                if (_status == 'not_started')
                  Column(
                    children: [
                      Text('准备开始', style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 12),
                      Text(
                        '$_countdown',
                        style: const TextStyle(fontSize: 64, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                    ],
                  )
                else
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('状态: $statusText', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('已用时: ${_formatDuration(elapsed)}', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('步数: $_steps 步${_sensorStepsActive ? '' : '（估算）'}', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('距离: ${_formatDistance(_distance)}', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('实时速度: ${_formatSpeedKmH(_currentSpeedMps)}', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text('平均速度: ${_calcAvgSpeedKmH().toStringAsFixed(2)} km/h', style: const TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        if (targetVal != null && targetVal > 0) Text(remainingText, style: const TextStyle(fontSize: 16)),
                      ],
                    ),
                  ),
              ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: !hasBottomBar
          ? null
          : BottomAppBar(
              color: Colors.transparent,
              elevation: 0,
              shadowColor: Colors.transparent,
              surfaceTintColor: Colors.transparent,
              child: SafeArea(
                top: false,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    if (_status == 'in_progress' || _status == 'paused')
                      IconButton(
                        icon: Icon(_status == 'paused' ? Icons.play_arrow : Icons.pause),
                        onPressed: _togglePause,
                      ),
                    if (_status == 'in_progress' || _status == 'paused')
                      IconButton(
                        icon: Icon(widget.mode == 'instant' ? Icons.flag : Icons.stop),
                        onPressed: widget.mode == 'instant' ? () => _complete() : _stop,
                      ),
                    if (_status == 'stopped')
                      IconButton(
                        icon: const Icon(Icons.refresh),
                        onPressed: _restart,
                      ),
                  ],
                ),
              ),
            ),
    );
  }
}