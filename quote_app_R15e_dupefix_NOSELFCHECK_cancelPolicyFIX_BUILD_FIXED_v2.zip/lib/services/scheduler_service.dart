import 'dart:isolate';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import 'package:sqflite/sqflite.dart';

import '../utils/debug_logger.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import 'dart:async';
import '../platform/perm_helper.dart';

import '../utils/run_context.dart';
import 'run_guard.dart';
// === Scheduler constants ===
const Duration kExactGrace = Duration(minutes: 2); // 精准闹钟允许的过期容忍窗口
const Duration kFallbackDelay = Duration(minutes: 3); // WM兜底延迟


// ====== 日志辅助：统一中文上下文 ======
// ====== 日志辅助：统一中文上下文 ======
String _fmt(DateTime dt) => dt.toLocal().toString().split('.').first;
Future<void> _logEnter(String stage, {String? uid, String? title, DateTime? when, String extra = ''}) async {
  final ts = when != null ? _fmt(when) : '';
  final name = (title ?? '');
  final idPart = uid != null ? '(id='+uid+')' : '';
  final whenPart = ts.isNotEmpty ? (' @'+ts) : '';
  final base = '【进入】' + stage + (name.isNotEmpty?(' '+name):'') + idPart + whenPart + (extra.isNotEmpty?(' '+extra):'');
  await DLog.i('SCH', base);
  await LogDao().add(taskUid: uid ?? '', detail: base);
}
class SchedulerService
{
  // —— 单任务“仅保留下一次触发”的固定 ID ——
  static int _nextAlarmId(String uid) => (uid.hashCode) & 0x7fffffff;


  static int _fallbackAlarmId(String uid) => (uid.hashCode ^ 0x5F3759DF) & 0x7fffffff;

  static Future<void> cancelNextForTask(String uid) async {
    await _logEnter('取消环节', uid: uid);
  await DLog.i('SCH','开始取消先前计划：uid='+uid);
  try { await AndroidAlarmManager.cancel(_nextAlarmId(uid)); await DLog.i('SCH','已取消AM精确闹钟 id='+_nextAlarmId(uid).toString()); } catch (_) {}
  try { await AndroidAlarmManager.cancel(_fallbackAlarmId(uid)); await DLog.i('SCH','已取消AM兜底闹钟 id='+_fallbackAlarmId(uid).toString()); } catch (_) {}
  try { await Workmanager().cancelByUniqueName('next_'+uid); await DLog.i('SCH','已取消WM一次性任务 name='+'next_'+uid); } catch (_) {}
  try { await Workmanager().cancelByUniqueName('fb_next_'+uid); await DLog.i('SCH','已取消WM兜底任务 name='+'fb_next_'+uid); } catch (_) {}
  await DLog.i('SCH','已尝试取消完成 uid='+uid);
  }

  
  static Future<void> _ensurePendingTable(Database db) async {
    await db.execute(
      "CREATE TABLE IF NOT EXISTS pending_run("
      "uid TEXT PRIMARY KEY,"
      "run_key TEXT,"
      "wm_unique TEXT,"
      "alarm_id INTEGER"
      ")"
    );
  }
static Future<void> _savePending(String uid, String runKey, String wmUnique, int alarmId) async {
    try {
      final db = await AppDatabase.instance();
    await _ensurePendingTable(db);
    await db.insert('pending_run', {
        'uid': uid, 'run_key': runKey, 'wm_unique': wmUnique, 'alarm_id': alarmId
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    } catch (_) {}
  }

  static int _idFor(String uid, String runKey) => (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;

  // ---- runKey helpers / WM fallback ----
  static String _runKeyForPlanned(DateTime planned) {
    String two(int n)=> n.toString().padLeft(2,'0');
    return '${planned.year}${two(planned.month)}${two(planned.day)}${two(planned.hour)}${two(planned.minute)}';
  }
  
  static Future<bool> _hasRunSuccess(String taskUid, String runKey) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('logs', where: 'task_uid=? AND detail LIKE ?', whereArgs: [taskUid, '%run='+runKey+'%'], limit: 1);
    return rows.isNotEmpty;
  }
  
  static Future<void> _scheduleWmOneOff(String uniqueName, Map<String, dynamic> data, Duration delay) async {
    await Workmanager().registerOneOffTask(
      uniqueName,
      data['job']?.toString() ?? 'wm_fallback',
      initialDelay: delay.isNegative ? Duration.zero : delay,
      existingWorkPolicy: ExistingWorkPolicy.replace,

      constraints: Constraints(networkType: NetworkType.notRequired),
      inputData: data.map((k, v) => MapEntry(k, v is num || v is String || v is bool ? v : v.toString())),
    );
  }
  
  static Future<void> wmRunTask(String taskUid, String runKey) async {
    final db = await AppDatabase.instance();
    final trows = await db.query('tasks', where: 'task_uid=?', whereArgs: [taskUid], limit: 1);
    if (trows.isEmpty) return;
    final t = trows.first;
     // 跨通道幂等：谁先执行谁赢
    if (!await RunGuard.begin(taskUid, runKey, source: 'WM')) return;
    await _sendForTask(t, runKey: runKey, source: 'WM');
  }
/// 初始化调度：初始化 WorkManager，并在无精确闹钟权限时注册 15 分钟兜底任务。
  static Future<void> init() async {
    await DLog.i('SCH', 'init start');
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'hasExact(now)=$hasExact');
    if (true) { // always keep periodic fallback alive; internal checks avoid duplicate work
      // (policy) do not open system settings here per product requirement
      await Workmanager().registerPeriodicTask(
          'due_check_periodic',
          'due_check_periodic',
          frequency: const Duration(minutes: 15),
          initialDelay: const Duration(minutes: 15),
          existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
          constraints: Constraints(networkType: NetworkType.notRequired),
        );
        await DLog.i('SCH', 'registered fallback periodic task');
        
    }
    else {
      // 有精确闹钟权限：取消兜底任务
      await Workmanager().cancelByUniqueName('due_check_periodic');
        await DLog.i('SCH', 'cancelled fallback periodic task');
        
    }
  }

  /// 扫描任务并为每个任务安排下一次触发（有精确闹钟权限时使用 AndroidAlarmManager）。
  static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final hasExact = await PermHelper.hasExactAlarmPermission();
    await DLog.i('SCH', 'hasExact(now)=$hasExact');
    final tasks = await TaskDao().all();
    final Map<String, DateTime> _nextChosen = {};

    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;
      final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) continue;

      final next = _computeNext(t);
      if (next == null) continue;
      // 去重：同一 uid 只保留最早 future 触发 
      if (_nextChosen.containsKey(uid)) {
        if (next.isBefore(_nextChosen[uid]!)) {
          _nextChosen[uid] = next;
        }
        continue;
      } else {
        _nextChosen[uid] = next;
      }

      final diffSecs = next.difference(DateTime.now()).inSeconds;
      if (diffSecs.abs() <= 5) {
        await DLog.i('SCH', 'instant fire $uid');
        await _sendForTask(t, runKey: _runKeyForPlanned(next), source: 'INSTANT');
        await LogDao().add(taskUid: uid, detail: '即时触发：${_fmt(DateTime.now())}');
        continue;
      }

      // 把“下一次”写回任务（保持你原有约定）
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [uid]);
        

      // 精确权限：优先走 AM，否则 WM
      if (await PermHelper.hasExactAlarmPermission()) {
        final runKey = _runKeyForPlanned(next);
        // 若已略过但在 2 分钟容忍窗口内，直接用 WM 立即执行；否则注册 AM
        if (next.isBefore(DateTime.now()) && DateTime.now().difference(next) <= kExactGrace) {
          await SchedulerService.cancelNextForTask(uid);
          await _scheduleWmOneOff('next_'+uid, {'job':'wm_run','task_uid': uid, 'run_key': runKey}, Duration.zero);
          await DLog.w('SCH','已过期≤2分钟，用WM立即执行 uid='+uid+' runKey='+runKey);
        } else {
          await AndroidAlarmManager.oneShotAt(
            next, _nextAlarmId(uid), alarmCallback,
            exact: true, allowWhileIdle: true, wakeup: true, rescheduleOnReboot: true);
          await DLog.i('SCH', '已注册AM uid='+uid+' @'+_fmt(next));
        }
      } else {
        // 无精确权限：直接 WM one-off
        final runKey = _runKeyForPlanned(next);
        final uniq = 'wm_run_'+uid+'_'+runKey;
        await _scheduleWmOneOff(uniq, {'job':'wm_run','task_uid':uid,'run_key':runKey}, next.difference(DateTime.now()));
        await DLog.i('SCH', '已注册WM oneOff uid='+uid+' run='+runKey);
      }
      }
    }

  /// 被闹钟或兜底调用：检查到期任务并发送通知。
  static Future<void> callback() async {
    await _logEnter('回调环节');
    final db = await AppDatabase.instance();
    final now = DateTime.now();
    final tasks = await TaskDao().all();

    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;

      final uid = (t['task_uid'] ?? '').toString();
    if (uid.isEmpty) continue;

      final st = (t['start_time'] ?? '').toString();
      await DLog.i('CP', '当天补发检查 task $uid st=$st');
      if (st.isEmpty) continue;

      final planned = _parseTimeOrToday(st);
      if (planned == null) continue;

      // 只在“计划时间已到或已过”的时候触发一次
      final delta = now.difference(planned).inSeconds;
      await DLog.i('CB', 'check task $uid st=$st delta=$delta');
      // 触发窗口：提前 10 秒 ~ 延迟 5 分钟
      if (delta >= -10 && delta <= 300) {
        // recent duplicate guard (5 min)
        final fiveMinAgo = now.subtract(const Duration(minutes: 5)).millisecondsSinceEpoch;
        final recent = await db.query('logs', where: 'task_uid=? AND detail LIKE ? AND created_at > ?', whereArgs: [uid, '触发:%', fiveMinAgo], limit: 1);
        if (recent.isNotEmpty) { await DLog.i('CB', 'skip recent uid=$uid'); continue; }
        await _sendForTask(t, runKey: _runKeyForPlanned(planned), source: (RunContext.isFromWM ? 'WM' : 'AM'));
        await LogDao().add(taskUid: uid, detail: '触发：${_fmt(now)}');
      }
      else {
        await DLog.i('CB', '跳过：超出容忍窗口，uid=$uid delta=$delta');
      }
    }
  }

  /// 计算下一次时间：支持 'HH:mm' 每日、'yyyy-MM-dd HH:mm' 精确时间、以及包含 freq/weekday/dayOfMonth 的扩展。
  
  /// 计算下一次时间：兼容旧/新字段。
  
  /// 计算下一次时间：兼容旧/新字段。
  static DateTime? _computeNext(Map<String, dynamic> t) {
    final now = DateTime.now();
    final start = (t['start_time'] ?? '').toString().trim();
    if (start.isEmpty) return null;

    // 解析“时:分”
    int hh = 9, mm = 0;
    final reHm = RegExp(r'^\d{2}:\d{2}$');
    final reAbs = RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$');
    DateTime? absDt;
    if (reHm.hasMatch(start)) {
      hh = int.parse(start.substring(0,2));
      mm = int.parse(start.substring(3,5));
    } else if (reAbs.hasMatch(start)) {
      final yyyy = int.parse(start.substring(0,4));
        final MMm  = int.parse(start.substring(5,7));
        final dd   = int.parse(start.substring(8,10));
        hh = int.parse(start.substring(11,13));
        mm = int.parse(start.substring(14,16));
        absDt = DateTime(yyyy, MMm, dd, hh, mm);
        
    } else {
      // 尝试从任意字符串中提取 “HH:mm”
      final m2 = RegExp(r'(\d{2}):(\d{2})').firstMatch(start);
      if (m2 != null) {
        hh = int.parse(m2.group(1)!);
          mm = int.parse(m2.group(2)!);
          
      }
    }

    // 读取频率（新字段优先，兼容旧字段）
    final String freqType = (t['freq_type'] ?? t['freq'] ?? 'daily').toString();
    final int? weekDay = (t['freq_weekday'] ?? t['weekday']) as int?;
    final int? dayOfMonth = (t['freq_day_of_month'] ?? t['dayOfMonth']) as int?;

    // 如果 start 为绝对时间且在未来：直接使用它（作为“下一次”）
    if (absDt != null && absDt.isAfter(now)) {
      return absDt;
    }

    if (freqType == 'weekly' && weekDay != null) {
      final wd = weekDay;
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (cand.isBefore(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    }

    if (freqType == 'monthly' && dayOfMonth != null) {
      final d = dayOfMonth.clamp(1,31);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (cand.isBefore(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    }

    // 默认：每天
    final today = DateTime(now.year, now.month, now.day, hh, mm);
    if (!today.isBefore(now)) return today;
    return today.add(const Duration(days: 1));
  }
static DateTime? _parseTimeOrToday(String st) {
    final now = DateTime.now();
    if (RegExp(r'^\d{2}:\d{2}$').hasMatch(st)) {
        final hh = int.parse(st.substring(0,2));
        final mm = int.parse(st.substring(3,5));
        return DateTime(now.year, now.month, now.day, hh, mm);
      } else if (RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$').hasMatch(st)) {
        final yyyy = int.parse(st.substring(0,4));
        final mm = int.parse(st.substring(5,7));
        final dd = int.parse(st.substring(8,10));
        final HH = int.parse(st.substring(11,13));
        final MM = int.parse(st.substring(14,16));
        return DateTime(yyyy, mm, dd, HH, MM);
      }
      
    return null;
  }

  static Future<void> _sendForTask(Map<String, dynamic> t, {String? runKey, DateTime? planned, String? source}) async {
    final type = (t['type'] ?? '').toString();
    final uid = (t['task_uid'] ?? '').toString();
    String title = (t['name'] ?? '提醒').toString();
    String body = '到了预设时间';

    // ensure background init (idempotent)
    WidgetsFlutterBinding.ensureInitialized();
    ui.DartPluginRegistrant.ensureInitialized();
    await NotificationService.init();
    // —— 幂等屏障 ——
    if (runKey != null && (source ?? '') != 'WM') {
      final uid = (t['task_uid'] ?? '').toString();
      final ok = await RunGuard.begin(uid, runKey, source: (source ?? ''));
      if (!ok) { await DLog.i('SCH','幂等拦截：重复触发 uid='+uid+' run='+runKey); return; }
    }


    // --- double‑check精确权限失效时兜底重新注册 ---
    if (runKey != null) {

      final hasExactNow = await PermHelper.hasExactAlarmPermission();
      if (!hasExactNow && !(await _hasRunSuccess(uid, runKey))) {
        // 系统精确权限被关，重注册WM one‑off 5s 后触发
        await _scheduleWmOneOff('wm_fb_'+uid+'_'+runKey, {'job':'wm_fallback','task_uid':uid,'run_key':runKey}, const Duration(seconds:5));
      }
    }

    // --- 基础字段 ---
    

    // --- 1) 手动任务：取任务最新名言 ---
    if (type == 'manual') {
      final q = await QuoteDao().latestForTask(uid);
      if (q != null) {
        body = (q['content'] ?? '').toString();
        final id = q['id'] is int ? q['id'] as int : int.tryParse((q['id'] ?? '').toString());
        if (id != null) {
          await QuoteDao().markNotified(id);
        }
      }
    }
    // --- 2) 轮播任务：顺序取下一条 ---
    else if (type == 'carousel') {
      final q = await QuoteDao().carouselNextSequential(uid);
      if (q != null) {
        final content = (q['content'] ?? '').toString();
        final author = (q['author'] ?? '').toString();
        body = author.isEmpty ? content : '$content —— $author';

        final id = q['id'] is int ? q['id'] as int : int.tryParse((q['id'] ?? '').toString());
        if (id != null) {
          await QuoteDao().markNotified(id);
        }
      }
    }
    // --- 3) 自动任务：实时拉取 OpenAI ---
    else if (type == 'auto') {
      final cfg = await ConfigDao().getOne();
      final key = (cfg['api_key'] ?? '').toString();
      final model = (cfg['model'] ?? 'gpt-5').toString();
      final endpoint = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses').toString();
      final prompt = (t['prompt'] ?? '给一句著名人物的名言，中文，短句').toString();

      if (key.isEmpty) {
        await LogDao().add(taskUid: uid, detail: '调用 openai api 失败(未配置 API Key)');
        return;
      }

      final api = OpenAIService(endpoint: endpoint, apiKey: key, model: model);

      String? acceptedContent;
      int retry = 0;
      while (retry < 10) {
        try {
          final resp = await api.generateQuote(prompt);
          final content = resp.trim();
          if (content.isEmpty) {
            retry++;
            continue;
          }
          final dup = await QuoteDao().existsSimilar(content, threshold: 0.9);
          if (dup) {
            retry++;
            continue;
          }
          acceptedContent = content;
          break;
        } catch (e) {
          await LogDao().add(taskUid: uid, detail: '调用 openai api 失败! run=' + (runKey ?? ''));
          return;
        }
      }

      if (acceptedContent == null) {
        await LogDao().add(taskUid: uid, detail: '错误! 连续调用 api10 次去重检验未通过! run=' + (runKey ?? ''));
        return;
      }

      // 入库（再次保护性去重）
      final quoteUid = await QuoteDao().insertIfUnique(
        taskUid: uid,
        type: type,
        taskName: title,
        avatarPath: (t['avatar_path'] ?? '').toString(),
        content: acceptedContent,
      );

      if (quoteUid.isEmpty) {
        await LogDao().add(taskUid: uid, detail: '错误! 内容重复未插入。 run=' + (runKey ?? ''));
        return;
      }

      body = acceptedContent;

      // 标记 quotes.notified = 1
      final db = await AppDatabase.instance();
      await db.update('quotes', {'notified': 1}, where: 'quote_uid=?', whereArgs: [quoteUid]);
    }

    // --- 通知展示 ---
    final largeIconPath = (t['avatar_path'] ?? '').toString();
    final _permNow = await PermHelper.hasExactAlarmPermission();
    final sourceTag = (source ?? (RunContext.isBackground ? (RunContext.isFromWM ? 'WM兜底' : 'AM精准') : '前台即时'));
    await DLog.i('SCH', '发送路径='+sourceTag+'，permExact='+_permNow.toString()+' run='+(runKey ?? ''));
    try {
      await NotificationService.show(
        id: uid.hashCode & 0x7fffffff,
        title: title,
        body: body,
        largeIconPath: largeIconPath,
      );
      await LogDao().add(taskUid: uid, detail: '通知已发送（来源='+sourceTag+'） run=' + (runKey ?? ''));
      // 成功后统一进行取消
      await SchedulerService.cancelNextForTask(uid);
      // 成功后再做清理，避免未到点或失败被提前取消
      await SchedulerService.cancelNextForTask(uid);
    } catch (e) {
      await LogDao().add(taskUid: uid, detail: '通知发送失败 run=' + (runKey ?? '') + ' err=' + e.toString());
      try {
        final hasExact = await PermHelper.hasExactAlarmPermission();
        if (hasExact) {
          final key = (runKey ?? _runKeyForPlanned(DateTime.now()));
          await _scheduleWmOneOff('wm_fb_'+uid+'_'+key, {'job':'wm_fallback','task_uid':uid,'run_key':key}, const Duration(minutes: 15));
          await DLog.i('SCH', '精确闹钟失败，已安排15分钟WorkManager补发 uid='+uid+' run='+key);
        }
      } catch (_){/* ignore */}
    }
  }

      


  static int _alarmIdForTask(String uid) => uid.hashCode & 0x7fffffff;
  static String _fmt(DateTime dt) => DateFormat('yyyy-MM-dd HH:mm').format(dt);

  static Future<void> catchupIfMissed() async => _catchupIfMissed();
  static Future<void> _scheduleWmFallbackAt(String uid, String runKey, DateTime due) async {
    final now = DateTime.now();
    final delay = (due.isAfter(now) ? due.difference(now) : Duration.zero) + kFallbackDelay;
    await _scheduleWmOneOff('fb_next_'+uid, {'task_uid': uid, 'run_key': runKey, 'is_fallback': true}, delay);
    await DLog.i('SCH','已注册兜底WM：fb_next_'+uid+'，延迟='+delay.inSeconds.toString()+'秒');
  }

  static Future<void> _triggerWmFallbackNow(String uid, String runKey) async {
    await _scheduleWmOneOff('fb_next_'+uid, {'task_uid': uid, 'run_key': runKey, 'is_fallback': true}, Duration.zero);
    await DLog.w('SCH','闹钟回调失败，立即触发兜底WM：fb_next_'+uid);
  }


  static Future<void> cancelForTask(String uid) async {
      try {
        final db = await AppDatabase.instance();
        await _ensurePendingTable(db);
        final rows = await db.query('pending_run', where: 'uid=?', whereArgs: [uid]);
        if (rows.isNotEmpty) {
          final alarmId = rows.first['alarm_id'] as int?;
          final wmUnique = rows.first['wm_unique'] as String?;
          if (alarmId != null) {
            try { await AndroidAlarmManager.cancel(alarmId); } catch (_) {}
          }
          if (wmUnique != null && wmUnique.isNotEmpty) {
            try { await Workmanager().cancelByUniqueName(wmUnique); } catch (_) {}
          }
          await db.delete('pending_run', where: 'uid=?', whereArgs: [uid]);
        }
      } catch (_) {}
      await DLog.i('SCH','已取消任务相关闹钟和WorkManager uid='+uid);
    }
  
}

/// AndroidAlarmManager 回调入口（顶层，避免 tree-shaking）
@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  // 标记后台环境（供日志前缀使用）
  RunContext.isBackground = true; 
  RunContext.isFromWM = false; 

  await DLog.i('ALARM', 'alarm hit');
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();
  await NotificationService.init();
  await AppDatabase.instance();
  await SchedulerService.callback();
  await SchedulerService.catchupIfMissed();
  
  await SchedulerService.scheduleNextForAll();
}

/// 当天漏发补发（所有任务类型，仅补一次）
Future<void> _catchupIfMissed() async {
  final db = await AppDatabase.instance();
    final now = DateTime.now();
    final dayStart = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final dayEnd = DateTime(now.year, now.month, now.day, 23, 59, 59, 999).millisecondsSinceEpoch;
    final tasks = await TaskDao().all();
    for (final t in tasks) {
      final status = (t['status'] ?? 'on').toString();
      if (status != 'on' && status != 'active') continue;
      final uid = (t['task_uid'] ?? '').toString();
      await SchedulerService.cancelNextForTask(uid);
      if (uid.isEmpty) continue;
      final st = (t['start_time'] ?? '').toString();
      await DLog.i('CP', '当天补发检查 task $uid st=$st');
      if (st.isEmpty) continue;
      final planned = SchedulerService._parseTimeOrToday(st);
      if (planned == null) continue;
      if (planned.isAfter(now)) continue;

      final sent = await db.query('logs',
          where: 'task_uid=? AND created_at BETWEEN ? AND ?',
          whereArgs: [uid, dayStart, dayEnd],
          limit: 1);
      if (sent.isNotEmpty) continue;

      await SchedulerService._sendForTask(t, runKey: SchedulerService._runKeyForPlanned(planned));
      await LogDao().add(taskUid: uid, detail: '补发：${SchedulerService._fmt(now)}');
    }
    
}
  
  // —— 准点闹钟兜底：在预定触发后10分钟补发一次（若闹钟回调未执行或失败） ——

  // —— 立即触发兜底（用于闹钟回调执行了但发送失败的情况） ——