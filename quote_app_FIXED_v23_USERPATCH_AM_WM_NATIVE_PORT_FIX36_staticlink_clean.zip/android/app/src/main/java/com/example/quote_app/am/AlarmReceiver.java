package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import androidx.work.WorkManager;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.schedule.NextTriggerCalculator;

import org.json.JSONObject;

/**
 * 精准闹钟触发入口（AM 主通道）。
 * 1) 解析 id / payload（含 uid/runKey 等）；
 * 2) 幂等门禁（runGuard）；
 * 3) 执行业务 Biz.run(ctx, uid)（内部会处理自动/手动/轮播、OpenAI、去重、日志、发送通知等）；
 * 4) 成功后：标记成功 + 计算下一次并续排 + 取消 WM 兜底；
 * 5) 失败/异常：写日志，必要时允许兜底逻辑继续。
 */
public final class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        final int id = intent.getIntExtra("id", 0);
        final String payload = intent.getStringExtra("payload");

        String uid = "";
        String runKey = "";
        String chan = "am";
        int attempt = 1;

        try {
            if (!TextUtils.isEmpty(payload)) {
                JSONObject o = new JSONObject(payload);
                uid = o.optString("uid", "");
                runKey = o.optString("runKey", "");
                chan = o.optString("chan", "am");
                attempt = o.optInt("attempt", 1);
            }
        } catch (Throwable ignored) {}

        // 无 uid：作为兜底通知（兼容历史）
        if (TextUtils.isEmpty(uid)) {
            String title = "提醒";
            String body = "到点了";
            try {
                NotifyHelper.send(context.getApplicationContext(), id, title, body, null);
            } catch (Throwable ignored) {}
            return;
        }

        final Context app = context.getApplicationContext();
        boolean entered = false;
        try {
            // 幂等门禁（防止重复触发）
            entered = DbRepository.runGuardBegin(app, uid, runKey, chan);
            if (!entered) return;

            // 执行业务
            boolean handled = Biz.run(app, uid);

            if (handled) {
                // 标记成功
                DbRepository.markLatestSuccess(app, uid);

                // 计算下一次并续排
                long next = NextTriggerCalculator.compute(app, uid);
                if (next > 0) {
                    NativeSchedulerK.scheduleExactWmCompat(app, id, next, payload != null ? payload : "{}");
                }

                // 主通道成功则取消 WM 兜底
                try {
                    WorkManager.getInstance(app).cancelUniqueWork("wm_once_" + id);
                } catch (Throwable ignored) {}
            } else {
                // 业务未处理，保持静默，由 WM 重试策略兜底
                DbRepository.log(app, uid, "AM触发：业务未处理，等待兜底");
            }
        } catch (Throwable t) {
            try {
                DbRepository.log(app, uid, "AM触发异常: " + (t.getMessage() == null ? "未知错误" : t.getMessage()));
            } catch (Throwable ignored) {}
        } finally {
            try {
                if (entered) DbRepository.runGuardEnd(app, uid, runKey, chan);
            } catch (Throwable ignored) {}
        }
    }
}