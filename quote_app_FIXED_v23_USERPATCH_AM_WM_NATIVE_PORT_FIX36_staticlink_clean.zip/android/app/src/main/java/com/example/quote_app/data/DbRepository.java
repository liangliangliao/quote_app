package com.example.quote_app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.example.quote_app.data.DbInspector.Contract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class DbRepository {

    public static java.util.List<String> failsOfToday(Context ctx) { return new java.util.ArrayList<>(); }


    public static final class Task {
        public String uid;
        public String title;
        public String content;
        public long triggerAtMillis;
        public boolean enabled = true;
        public String type;
        public String avatarPath;
    }

    private static SQLiteDatabase openByPath(String path) {
        try { return SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE); }
        catch (Throwable e) { return null; }
    }

    private static String or(String v, String d) { return TextUtils.isEmpty(v) ? d : v; }

    // -------- 日志 --------
    public static void log(Context ctx, String uid, String detail) {
        Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.logsSource)) return;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return;
        try {
            Map<String,String> m = cc.logColMap;
            ContentValues cv = new ContentValues();
            cv.put(or(m.get("uid"), "uid"), uid);
            cv.put(or(m.get("detail"), "detail"), detail);
            db.insert(cc.logsSource, null, cv);
        } catch (Throwable ignored) {
        } finally { try { db.close(); } catch (Throwable ignored) {} }
    }

    // -------- 幂等门禁 --------
    private static void ensureRunGuard(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS run_guard(uid TEXT, run_key TEXT, ts INTEGER, src TEXT, PRIMARY KEY(uid,run_key))");
    }

    public static boolean runGuardBegin(Context ctx, String uid, String runKey, String source) {
        Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return true;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return true;
        try {
            ensureRunGuard(db);
            Cursor c = db.rawQuery("SELECT 1 FROM run_guard WHERE uid=? AND run_key=?", new String[]{uid, runKey});
            boolean exists = c.moveToFirst();
            c.close();
            if (exists) return false;
            ContentValues cv = new ContentValues();
            cv.put("uid", uid);
            cv.put("run_key", runKey);
            cv.put("ts", System.currentTimeMillis());
            cv.put("src", source);
            db.insertWithOnConflict("run_guard", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            log(ctx, uid, "begin uid="+uid+" runKey="+runKey+" src="+(source==null?"":source));
            return true;
        } catch (Throwable e) {
            log(ctx, uid, "begin error uid="+uid+" runKey="+runKey+" err="+e.getMessage());
            return true;
        } finally { try { db.close(); } catch (Throwable ignored) {} }
    }

    public static void runGuardEnd(Context ctx, String uid, String runKey, String source) {
        Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null) return;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return;
        try {
            ensureRunGuard(db);
            db.delete("run_guard", "uid=? AND run_key=?", new String[]{uid, runKey});
            log(ctx, uid, "end uid="+uid+" runKey="+runKey+" src="+(source==null?"":source));
        } catch (Throwable e) {
            log(ctx, uid, "end error uid="+uid+" runKey="+runKey+" err="+e.getMessage());
        } finally { try { db.close(); } catch (Throwable ignored) {} }
    }

    public static void markLatestSuccess(Context ctx, String uid) {
        log(ctx, uid, "成功!");
    }

    // -------- 名人名言 --------
    public static long insertQuote(Context ctx, String taskUid, String text, String avatarPath) {
        Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.quotesSource)) return -1L;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return -1L;
        try {
            Map<String,String> m = cc.quoteColMap;
            ContentValues cv = new ContentValues();
            cv.put(or(m.get("uid"), "uid"), taskUid);
            cv.put(or(m.get("content"), "content"), text);
            cv.put(or(m.get("avatar"), "avatar"), avatarPath);
            cv.put(or(m.get("notified"), "notified"), 0);
            long id = db.insert(cc.quotesSource, null, cv);
            return id;
        } catch (Throwable e) {
            log(ctx, taskUid, "insert quote error: "+e.getMessage());
            return -1L;
        } finally { try { db.close(); } catch (Throwable ignored) {} }
    }

    public static void markQuoteNotified(Context ctx, long quoteId) {
        Contract cc = DbInspector.loadOrLightScan(ctx);
        if (cc == null || TextUtils.isEmpty(cc.quotesSource)) return;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return;
        try {
            Map<String,String> m = cc.quoteColMap;
            ContentValues cv = new ContentValues();
            cv.put(or(m.get("notified"), "notified"), 1);
            db.update(cc.quotesSource, cv, "rowid=?", new String[]{String.valueOf(quoteId)});
        } catch (Throwable ignored) {
        } finally { try { db.close(); } catch (Throwable ignored) {} }
    }

    public static List<String> listQuoteTextsForTask(Context ctx, String taskUid, int limit) {
        Contract cc = DbInspector.loadOrLightScan(ctx);
        List<String> out = new ArrayList<>();
        if (cc == null || TextUtils.isEmpty(cc.quotesSource)) return out;
        SQLiteDatabase db = openByPath(cc.dbPath);
        if (db == null) return out;
        String table = cc.quotesSource;
        try {
            String textCol = or(cc.quoteColMap.get("text"), "content");
            String taskCol = or(cc.quoteColMap.get("task_uid"), "task_uid");
            String sql;
            String[] args;
            if (TextUtils.isEmpty(taskUid)) {
                sql = "SELECT " + textCol + " FROM " + table + " ORDER BY rowid DESC LIMIT ?";
                args = new String[]{String.valueOf(limit)};
            } else {
                sql = "SELECT " + textCol + " FROM " + table + " WHERE " + taskCol + "=? ORDER BY rowid DESC LIMIT ?";
                args = new String[]{taskUid, String.valueOf(limit)};
            }
            Cursor c = db.rawQuery(sql, args);
            while (c.moveToNext()) out.add(c.getString(0));
            c.close();
        } catch (Throwable ignored) {
        } finally { try { db.close(); } catch (Throwable ignored) {} }
        return out;
    }
}