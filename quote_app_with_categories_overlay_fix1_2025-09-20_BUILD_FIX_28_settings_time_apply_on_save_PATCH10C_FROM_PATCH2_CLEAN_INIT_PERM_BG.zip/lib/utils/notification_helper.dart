import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';

class AppNotifications {
  static final FlutterLocalNotificationsPlugin fln = FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    final DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    final InitializationSettings settings = InitializationSettings(android: androidSettings, iOS: iosSettings);
    
    // Android 13+ (API 33+) requires runtime POST_NOTIFICATIONS permission
    if (Platform.isAndroid) {
      try {
        final androidImpl = fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
        await androidImpl?.requestPermission();
      } catch (_) {}
    }
if (Platform.isAndroid) {
      final AndroidNotificationChannel channel = AndroidNotificationChannel(
        'high_importance_channel',
        'High Importance Notifications',
        description: 'Used for important notifications.',
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
        showBadge: true,
      );
      final android = fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await android?.createNotificationChannel(channel);
    }
  }

  static Future<void> ensurePermissions() async {
    // On Android 13+, POST_NOTIFICATIONS runtime permission is required. Plugin exposes it via Android-specific api when available.
    final androidImpl = fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.requestNotificationsPermission();

    // iOS foreground presentation options
    final iosImpl = fln.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    await iosImpl?.requestPermissions(alert: true, badge: true, sound: true);
  }

  static Future<void> showNow({required int id, required String title, required String body}) async {
    const AndroidNotificationDetails android = AndroidNotificationDetails(
      'high_importance_channel',
      'High Importance Notifications',
      channelDescription: 'Used for important notifications.',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
    );
    const DarwinNotificationDetails ios = DarwinNotificationDetails(
      presentAlert: true, presentBadge: true, presentSound: true,
    );
    const NotificationDetails details = NotificationDetails(android: android, iOS: ios);
    await fln.show(id, title, body, details);
  }
}
