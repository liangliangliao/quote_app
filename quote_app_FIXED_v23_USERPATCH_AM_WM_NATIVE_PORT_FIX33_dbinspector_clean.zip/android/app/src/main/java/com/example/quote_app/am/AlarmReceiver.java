package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.example.quote_app.NotifyHelper;
import com.example.quote_app.data.DbRepository;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.schedule.NextTriggerCalculator;

import org.json.JSONObject;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String payload = intent != null && intent.hasExtra("payload") ? intent.getStringExtra("payload") : null;
        String uid = null, runKey = null, chan = "am";
        int attempt = 1;
        try {
            if (!TextUtils.isEmpty(payload)) {
                JSONObject o = new JSONObject(payload);
                uid = o.optString("uid", null);
                runKey = o.optString("runKey", null);
                chan = o.optString("chan", "am");
                attempt = o.optInt("attempt", 1);
            }
        } catch (Throwable ignored) {}

        String title = "提醒";
        String body = "到点了";
        try {
            DbRepository.Task t = !TextUtils.isEmpty(uid) ? DbRepository.findTaskByUid(context.getApplicationContext(), uid) : null;
            if (t != null && !TextUtils.isEmpty(t.title)) title = t.title;
            if (t != null && !TextUtils.isEmpty(t.content)) body = t.content;
        } catch (Throwable ignored) {}

        // 如果存在 uid/runKey，先做幂等校验，防止重复发送
        if (!TextUtils.isEmpty(uid) && !TextUtils.isEmpty(runKey)) {
            try {
                if (DbRepository.alreadySent(context.getApplicationContext(), uid, runKey, chan, attempt)) {
                    // 幂等拦截：取消任何同 id 的兜底 WM（避免重复）
                    int id = ((uid.hashCode() ^ runKey.hashCode()) & 0x7fffffff);
                    try { NativeSchedulerK.INSTANCE.cancel(context.getApplicationContext(), id); } catch (Throwable ignored) {}
                    DbRepository.log(context.getApplicationContext(), uid, "幂等拦截：已发送过 uid="+uid+" run="+runKey);
                    return;
                }
            } catch (Throwable e) { throw new RuntimeException(e); }
        }

        // 执行完整业务链
        if (!TextUtils.isEmpty(uid)) {
            try {
                boolean handled = Biz.run(context.getApplicationContext(), uid);
                int id = !TextUtils.isEmpty(runKey) ? ((uid.hashCode() ^ runKey.hashCode()) & 0x7fffffff) : (uid.hashCode());
                if (handled) {
                    try { DbRepository.markLatestSuccess(context.getApplicationContext(), uid); } catch (Throwable ignored) {}
                    // 记录幂等标记 + 取消兜底 WM + 精准取消同 id
                    try { if (!TextUtils.isEmpty(runKey)) DbRepository.markSent(context.getApplicationContext(), uid, runKey, chan, attempt); } catch (Throwable ignored) {}
                    try { NativeSchedulerK.INSTANCE.cancel(context.getApplicationContext(), id); } catch (Throwable ignored) {}
                    // 自动续排
                    long next = NextTriggerCalculator.compute(context.getApplicationContext(), uid);
                    if (next > System.currentTimeMillis()) {
                        String nextPayload = new JSONObject().put("uid", uid).put("runKey", String.valueOf(next)).put("chan","am").put("attempt",1).toString();
                        try { NativeSchedulerK.INSTANCE.scheduleExactWmCompat(context.getApplicationContext(), ((uid.hashCode() ^ String.valueOf(next).hashCode()) & 0x7fffffff), next, nextPayload); } catch (Throwable _t) {}
                    }
                    return;
                } else {
                    // 发送失败：取消精准（避免重复），并保留 WM 兜底
                    try { NativeSchedulerK.INSTANCE.cancel(context.getApplicationContext(), id); } catch (Throwable ignored) {}
                    DbRepository.log(context.getApplicationContext(), uid, "发送失败：业务未处理 uid="+uid);
                    try { DbRepository.insertFail(context.getApplicationContext(), uid, chan, String.valueOf(id), new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date())); } catch (Throwable ignored) {}
                }
            } catch (Throwable t) {
                // 失败：若为 AM 主通道，由注册阶段已安排 WM 兜底；这里仅记录
                if (!TextUtils.isEmpty(uid)) {
                    DbRepository.log(context.getApplicationContext(), uid, "发送失败：异常 "+t.getMessage());
                try { DbRepository.insertFail(context.getApplicationContext(), uid, chan, String.valueOf(id), new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date())); } catch (Throwable ignored) {}
                }
                throw new RuntimeException(t);
            }
        }

        // 兜底：无 uid 或业务未处理，发默认通知
        try {
            int id = (uid != null ? uid.hashCode() : 10001);
            NotifyHelper.INSTANCE.send(context.getApplicationContext(), id, title, body, null);
        } catch (Throwable ignored) {}
    }
}
