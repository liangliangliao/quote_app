
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'notification_helper.dart';

class ReliableNotifier {
  static const MethodChannel _sys = MethodChannel('com.example.quote_app/sys');

  static Future<void> deliver({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    await AppNotifications.initialize();

    if (Platform.isAndroid) {
      final android = AppNotifications.fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      bool? enabled = await android?.areNotificationsEnabled();
      if (enabled == false) {
        try { await android?.requestNotificationsPermission(); } catch (_) {}
        enabled = await android?.areNotificationsEnabled();
      }
      if (enabled == false) {
        try { await _sys.invokeMethod('openAppNotificationSettings'); } catch (_) {}
      }
    }

    try {
      await AppNotifications.showNow(id: id, title: title, body: body);
      return;
    } catch (_) {}

    try {
      await AppNotifications.initialize();
      await AppNotifications.showNow(id: id, title: title, body: body);
    } catch (_) {}
  }
}
