import 'dart:async';
import 'package:workmanager/workmanager.dart';
import '../utils/notification_helper.dart';
import '../utils/reliable_notifier.dart';

const String periodicTask = 'periodic_notification_task';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      await AppNotifications.initialize();
      await ReliableNotifier.deliver(id: 1001, title: inputData?['title'] ?? '定时提醒', body: inputData?['body'] ?? '后台任务触发的通知');
    } catch (e) {
      // swallow to avoid task failure loops
    }
    return Future.value(true);
  });
}
