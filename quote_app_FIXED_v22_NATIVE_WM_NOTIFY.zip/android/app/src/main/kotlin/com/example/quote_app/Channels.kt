package com.example.quote_app

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry

object Channels {
  private const val CH_NOTIFY = "com.example.quote_app/notify"

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH_NOTIFY)
      .setMethodCallHandler { call, result ->
        when (call.method) {
          "notify" -> {
            val title = call.argument<String>("title") ?: ""
            val body = call.argument<String>("body") ?: ""
            val id = call.argument<Int>("id") ?: 1
            val largeIcon = call.argument<String>("largeIconPath")
            val ok = NotifyHelper.send(appCtx, id, title, body, largeIcon)
            result.success(ok)
          }
          else -> result.notImplemented()
        }
      }
  }

  // Register for legacy v1 background (WorkManager) using Registrar messenger
  fun registerWith(registrar: PluginRegistry.Registrar, appCtx: Context) {
    MethodChannel(registrar.messenger(), CH_NOTIFY)
      .setMethodCallHandler { call, result ->
        when (call.method) {
          "notify" -> {
            val title = call.argument<String>("title") ?: ""
            val body = call.argument<String>("body") ?: ""
            val id = call.argument<Int>("id") ?: 1
            val largeIcon = call.argument<String>("largeIconPath")
            val ok = NotifyHelper.send(appCtx, id, title, body, largeIcon)
            result.success(ok)
          }
          else -> result.notImplemented()
        }
      }
  }
}
