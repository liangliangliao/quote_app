package com.example.quote_app

import android.app.Application
import io.flutter.plugin.common.PluginRegistry
import io.flutter.plugins.GeneratedPluginRegistrant

/**
 * Application entry without direct plugin references.
 * Flutter v2 embedding handles plugin registration automatically.
 * Workmanager is initialised from Dart (Workmanager().initialize(...)).
 */
class App : Application(), PluginRegistry.PluginRegistrantCallback {

  override fun onCreate() {
    super.onCreate()
    // Ensure Workmanager background engine registers our channels & plugins
    try {
      val cls = Class.forName("be.tramckrijte.workmanager.WorkmanagerPlugin")
      val m = cls.getMethod("setPluginRegistrantCallback", io.flutter.plugin.common.PluginRegistry.PluginRegistrantCallback::class.java)
      m.invoke(null, this)
    } catch (_: Throwable) {
      try {
        val cls2 = Class.forName("dev.fluttercommunity.plus.workmanager.WorkmanagerPlugin")
        val m2 = cls2.getMethod("setPluginRegistrantCallback", io.flutter.plugin.common.PluginRegistry.PluginRegistrantCallback::class.java)
        m2.invoke(null, this)
      } catch (_: Throwable) {
        // No workmanager plugin detected; background registration won't be set.
      }
    }
  }

  override fun registerWith(registry: PluginRegistry) {
    // Register default plugins
    GeneratedPluginRegistrant.registerWith(registry)
    // Register our custom channel for background (v1 registrar messenger)
    val registrar = registry.registrarFor("com.example.quote_app.NOTIFY_BG")
    Channels.registerWith(registrar, applicationContext)
  }

}
