
import 'package:flutter/material.dart';
import '../data/dao.dart';
import 'package:intl/intl.dart';
import '../utils/debug_logger.dart';

class LogsPage extends StatefulWidget {
  const LogsPage({super.key});
  @override
  State<LogsPage> createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> {
  final _dao = LogDao();
  final _scroll = ScrollController();
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && !_done) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 50, offset: _offset);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 50) _done = true;
  }

  @override
  Widget build(BuildContext context) {
    String fmt(String? s){
      if (s == null || s.isEmpty) return '';
      try {
        final base = (s.length >= 16 ? s.substring(0,16).replaceFirst(' ', 'T') : s);
        final dt = DateTime.tryParse(base);
        if (dt != null) {
          return DateFormat('yyyy-MM-dd HH:mm').format(dt);
        }
      } catch (_) {
        // 不再写回日志，避免循环刷屏
      }
      return s ?? '';
      }
    return ListView.builder(
      controller: _scroll,
      itemCount: _items.length,
      itemBuilder: (_, i){
        final e = _items[i];
        final detail = (e['detail'] ?? '') as String;
        final isErr = detail.contains('错误');
        final isOk = detail.contains('成功');
        final style = TextStyle(
          color: isErr ? Colors.red : isOk ? Colors.green : null,
          fontWeight: (isErr || isOk) ? FontWeight.bold : null
        );
        return ListTile(
          leading: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text((e['task_name'] ?? '') as String, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(fmt(e['task_start_time'] as String?)),
            ],
          ),
          title: Text(detail, style: style),
        );
      },
    );
  }
}