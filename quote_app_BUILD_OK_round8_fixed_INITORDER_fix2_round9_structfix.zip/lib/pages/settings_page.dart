import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../data/dao.dart';
import '../utils/debug_logger.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TaskDao _taskDao = TaskDao();
  List<Map<String, dynamic>> _tasks = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await _taskDao.all();
      setState(() {
        _tasks = rows;
        _loading = false;
      });
    } catch (e) {
      await DLog.e('settings_page.dart', 'load failed: ' + e.toString());
      if (mounted) setState(() => _loading = false);
    }
  }

  void _openTaskDialog() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('这里可实现新增/编辑任务对话框（占位）')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (context, index) {
                  final t = _tasks[index];
                  final name = (t['name'] ?? '') as String;
                  final start = (t['start_time'] ?? '') as String;
                  final type = (t['type'] ?? '') as String;
                  final status = (t['status'] ?? '') as String;
                  return ListTile(
                    title: Text(name.isEmpty ? '(未命名任务)' : name),
                    subtitle: Text('时间: $start  类型: $type  状态: $status'),
                  );
                },
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openTaskDialog,
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}
