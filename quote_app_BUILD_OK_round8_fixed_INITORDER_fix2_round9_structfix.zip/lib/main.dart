import 'dart:ui';
import 'dart:async';
import './utils/run_context.dart';
import 'platform/perm_helper.dart';

import 'package:flutter/material.dart';
import 'utils/debug_logger.dart';
import 'pages/home_page.dart';
import 'pages/history_page.dart';
import 'pages/settings_page.dart';
import 'pages/logs_page.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'data/db.dart';
import 'package:workmanager/workmanager.dart';
import 'services/wm_dispatcher.dart';

Future<void> main() async {
  RunContext.isBackground = false;  // 前台运行标记
  RunContext.isBackground = false;  // 前台运行标记
  RunContext.isBackground = false;  // 前台运行标记
  WidgetsFlutterBinding.ensureInitialized();
  // 全局异常捕获：把所有未处理异常写入日志表
  FlutterError.onError = (FlutterErrorDetails details) async {
    try {
      await DLog.e('FLUTTER', 'Uncaught FlutterError: ' + details.exceptionAsString() + '\n' + (details.stack?.toString() ?? ''));
    } catch (_) {}
  };
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    try { DLog.e('DART', 'Uncaught Zone error: ' + error.toString() + '\n' + stack.toString()); } catch (_) {}
    return true;
  };
  try {
    await AndroidAlarmManager.initialize();
    await DLog.i('APP', 'AAM initialized(before runApp)');
  } catch (e, s) {
    await DLog.e('main.dart', 'AAM init failed: ' + e.toString());
  }

  // ===== App critical init moved before runApp to guarantee scheduling/registration =====
  try { await AppDatabase.instance(); await DLog.i('APP', 'DB init ok'); } catch (e) { await DLog.e('APP', 'DB init failed: ' + e.toString()); }
  try { await PermHelper.ensureBatteryOptExemption(); } catch (e) { await DLog.e('APP', 'battery opt request failed: ' + e.toString()); }
  try { await NotificationService.init(allowRequestPermission: true); await DLog.i('APP', 'Notification init ok'); } catch (e) { await DLog.e('APP', 'Notification init failed: ' + e.toString()); }
  try { await SchedulerService.init(); await DLog.i('APP', 'Scheduler init ok'); } catch (e) { await DLog.e('APP', 'Scheduler init failed: ' + e.toString()); }
  try { await SchedulerService.scheduleNextForAll(); await DLog.i('APP', 'scheduleNextForAll ok'); } catch (e) { await DLog.e('APP', 'scheduleNextForAll failed: ' + e.toString()); }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  int _idx = 0;
  final _pages = const [HomePage(), HistoryPage(), LogsPage(), SettingsPage()];
  // Titles removed per UI requirement
  @override
  
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    if (state == AppLifecycleState.paused) {
      await DLog.i('LIFE', 'paused -> callback & reschedule');
      await SchedulerService.callback();
      await SchedulerService.scheduleNextForAll();
    }
  }

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quote App',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        body: _pages[_idx],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _idx,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home), label: '首页'),
            NavigationDestination(icon: Icon(Icons.history), label: '历史'),
            NavigationDestination(icon: Icon(Icons.list), label: '日志'),
            NavigationDestination(icon: Icon(Icons.settings), label: '设置'),
          ],
          onDestinationSelected: (i)=> setState(()=> _idx = i),
        ),
      ),
    );
  }
}