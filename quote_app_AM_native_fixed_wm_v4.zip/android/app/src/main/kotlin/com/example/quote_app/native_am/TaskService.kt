package com.example.quote_app.native_am

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TaskService : LifecycleService() {

    private val api by lazy { OpenAiRepository(this) }
    private val repo by lazy { LocalRepository(this) }

    override fun onCreate() {
        super.onCreate()
        startForeground(NotificationMaker.NOTI_ID_RUNNER, NotificationMaker.stub(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val uid = intent?.getStringExtra("uid") ?: return Service.START_NOT_STICKY
        val runKey = intent.getStringExtra("runKey") ?: ""
        val payload = intent.getSerializableExtra("payload") as? java.util.HashMap<*, *> ?: hashMapOf<String,Any?>()

        lifecycleScope.launch(Dispatchers.IO) {
            handleTask(uid, runKey, payload)
            stopSelf()
        }
        return Service.START_REDELIVER_INTENT
    }

    private suspend fun handleTask(uid: String, runKey: String, payload: Map<*, *>) {
        val task = repo.findTask(uid) ?: return
        if (!task.enabled) return

        when (task.type) {
            TaskType.AUTO -> handleAutoTask(task)
            TaskType.MANUAL -> handleManualTask(task)
            TaskType.CAROUSEL -> handleCarouselTask(task)
        }
    }

    private suspend fun handleAutoTask(task: TaskEntity) {
        var attempts = 0
        while (attempts < 10) {
            attempts += 1
            val quote = api.fetchQuote(task)
            if (quote == null) {
                repo.log(task.id, "调用openai api发生错误或失败!")
                return
            }
            if (repo.isUniqueQuote(quote)) {
                val quoteId = repo.insertQuote(task, quote)
                repo.log(task.id, "成功!")
                NotificationMaker.show(this, task, quote)
                repo.updateQuoteNotified(quoteId)
                return
            }
            if (attempts >= 10) {
                repo.log(task.id, "错误!连续调用api10次去重检验未通过！")
            }
        }
    }

    private suspend fun handleManualTask(task: TaskEntity) {
        val quote = repo.latestQuoteOfTask(task.id) ?: return
        NotificationMaker.show(this, task, quote)
        repo.updateQuoteNotified(quote.id)
    }

    private suspend fun handleCarouselTask(task: TaskEntity) {
        val quote = repo.nextCarouselQuote(task.id) ?: return
        NotificationMaker.show(this, task, quote)
        repo.updateQuoteNotified(quote.id)
    }

    override fun onBind(intent: Intent): IBinder? = null
}

enum class TaskType { AUTO, MANUAL, CAROUSEL }

data class TaskEntity(
    val id: String,
    val name: String,
    val avatar: String?,
    val enabled: Boolean,
    val type: TaskType,
    val prompt: String,
    val model: String?,
    val apiKey: String?,
    val apiBase: String?
)

data class QuoteEntity(val id: String, val content: String)

class LocalRepository(private val ctx: Service) {
    suspend fun findTask(id: String): TaskEntity? = TODO("query task")
    suspend fun insertQuote(task: TaskEntity, content: String): String = TODO()
    suspend fun latestQuoteOfTask(taskId: String): QuoteEntity? = TODO()
    suspend fun nextCarouselQuote(taskId: String): QuoteEntity? = TODO()
    suspend fun updateQuoteNotified(quoteId: String): Unit = TODO()
    suspend fun isUniqueQuote(content: String): Boolean = TODO()
    suspend fun log(taskId: String, detail: String): Unit = TODO()
}

class OpenAiRepository(private val ctx: Service) {
    suspend fun fetchQuote(task: TaskEntity): String? = try {
        ""
    } catch (e: Exception) { null }
}

object NotificationMaker {
    const val NOTI_ID_RUNNER = 0x99
    fun stub(ctx: Service): Notification = androidx.core.app.NotificationCompat.Builder(ctx, "runner")
        .setContentTitle("Running").setSmallIcon(android.R.drawable.ic_popup_sync).build()
    fun show(ctx: Service, task: TaskEntity, quote: QuoteEntity) {
        val nb = androidx.core.app.NotificationCompat.Builder(ctx, "task_${'$'}{task.id}")
            .setContentTitle(task.name)
            .setContentText(quote.content)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
        ctx.startForeground(NOTI_ID_RUNNER, nb.build())
    }
}
