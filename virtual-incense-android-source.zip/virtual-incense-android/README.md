# 电子上香 Android 源码

这是一个可导入 Android Studio 的 Kotlin + Jetpack Compose 示例项目。

## 功能
- 模拟上香动画
- 平安 / 转运 / 清净 / 安睡预设
- 自定义祈愿文
- 60 / 90 / 180 秒燃香时长
- 完成次数统计
- 安定提醒

## 环境建议
- Android Studio Jellyfish 或更新版本
- Android SDK 35
- JDK 17
- minSdk 24

## 如何运行
1. 用 Android Studio 打开本项目根目录 `virtual-incense-android`
2. 等待 Gradle Sync 完成
3. 连接安卓手机或启动模拟器
4. 点击 Run

## 说明
- 当前“声音陪伴”只有 UI 开关，还没有真正接入音频播放。
- 这是情绪安定类小工具，不承诺任何超自然效果。
- `gradlew` 脚本是简化版；如果你希望完全标准的 Gradle Wrapper，可在 Android Studio 中重新生成。
