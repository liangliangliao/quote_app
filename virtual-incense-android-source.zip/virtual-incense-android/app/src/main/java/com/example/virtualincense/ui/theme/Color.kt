package com.example.virtualincense.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundTop = Color(0xFF120E0B)
val BackgroundBottom = Color(0xFF332014)
val CardSurface = Color(0x14FFFFFF)
val CardStroke = Color(0x1AFFFFFF)
val Amber = Color(0xFFF2B46D)
val AmberStrong = Color(0xFFE09139)
val WarmText = Color(0xFFF6EDE3)
val SoftText = Color(0xFFD3C4B4)
val Stone = Color(0xFF2B211A)
