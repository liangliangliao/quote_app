package com.example.virtualincense.ui.theme

import androidx.compose.material3.Typography

val AppTypography = Typography()
