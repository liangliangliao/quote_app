@echo off
where gradle >nul 2>&1
if %ERRORLEVEL% EQU 0 (
  gradle -p "%~dp0" %*
) else (
  echo Gradle 未安装。请直接用 Android Studio 打开本项目，或先安装 Gradle。
  exit /b 1
)
