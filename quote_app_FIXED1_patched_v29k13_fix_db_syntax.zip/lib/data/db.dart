import 'dart:io';
import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

const _DB_NAME = 'quotes.db';





class AppDatabase {
  static Future<void> _copyDbFile(String from, String to) async {
    try {
      await Directory(p.dirname(to)).create(recursive: true);
      final src = File(from);
      if (await src.exists()) {
        await src.copy(to);
      }
    } catch (e, st) { rethrow; }
  }


  static Future<void> _mergeFromExternalDb(Database targetDb, String externalPath) async {
    Database? extDb;
    try {
      if (!await databaseExists(externalPath)) return;
      extDb = await openDatabase(externalPath, readOnly: true);
      // Copy rows from each known table using INSERT OR IGNORE to avoid duplicates.
      Future<void> copyTable(String table) async {
        final rows = await extDb!.query(table);
        for (final row in rows) {
          try {
            await targetDb.insert(table, row, conflictAlgorithm: ConflictAlgorithm.ignore);
          } catch (_) {
            // Best-effort merge; ignore rows that don't match current schema.
           rethrow;}
        }
      }
      // Merge known tables. If a table doesn't exist in the external DB, just skip.
      for (final t in const ['tasks','quotes','logs','config','payloads']) {
        try { await copyTable(t); } catch (e, st) { rethrow; }
      }
    } catch (_) {
      // Swallow errors: merging is opportunistic, not fatal.
     rethrow;} finally {
      try { await extDb?.close(); } catch (e, st) { rethrow; }
    }
  }

  static Database? _db;

  static Future<Database> instance() async {
  if (_db != null) 
    // --- schema compatibility: add missing columns if needed ---
    try {
      final info = await _db!.rawQuery("PRAGMA table_info(tasks)");
      bool has(String name) => info.any((row) => row["name"]?.toString() == name);
      if (!has("task_uid")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
        await _db!.execute("UPDATE tasks SET task_uid = uid WHERE task_uid IS NULL OR task_uid=''");
      }
      if (!has("trigger_at")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN trigger_at INTEGER");
        await _db!.execute("UPDATE tasks SET trigger_at = COALESCE(next_time, strftime('%s','now')*1000)");
      }
      if (!has("freq_type"))            await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT");
      if (!has("freq_weekday"))         await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
      if (!has("freq_day_of_month"))    await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
      if (!has("freq_custom"))          await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT");
    } catch (e, st) { rethrow; }

    return _db!;

  final dbDir = await getDatabasesPath();
  final legacyPath = p.join(dbDir, _DB_NAME); // 旧库路径
  final docDir = await getApplicationDocumentsDirectory();
  final newPath = p.join(docDir.path, _DB_NAME); // 可能存在的新库

  if (await databaseExists(legacyPath)) {
    _db = await openDatabase(
      legacyPath, version: 6,
      onCreate: (db, v) async => _migrate(db),
      onUpgrade: (db, ov, nv) async => _migrate(db),
    );
    if (await databaseExists(newPath)) {
      try { await _mergeFromExternalDb(_db!, newPath); } catch (e, st) { rethrow; }
    }
    
    // --- schema compatibility: add missing columns if needed ---
    try {
      final info = await _db!.rawQuery("PRAGMA table_info(tasks)");
      bool has(String name) => info.any((row) => row["name"]?.toString() == name);
      if (!has("task_uid")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
        await _db!.execute("UPDATE tasks SET task_uid = uid WHERE task_uid IS NULL OR task_uid=''");
      }
      if (!has("trigger_at")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN trigger_at INTEGER");
        await _db!.execute("UPDATE tasks SET trigger_at = COALESCE(next_time, strftime('%s','now')*1000)");
      }
      if (!has("freq_type"))            await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT");
      if (!has("freq_weekday"))         await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
      if (!has("freq_day_of_month"))    await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
      if (!has("freq_custom"))          await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT");
    } catch (e, st) { rethrow; }

    return _db!;
  }

  if (await databaseExists(newPath)) {
    try { await _copyDbFile(newPath, legacyPath); } catch (e, st) { rethrow; }
  }

  _db = await openDatabase(
    legacyPath, version: 6,
    onCreate: (db, v) async => _migrate(db),
    onUpgrade: (db, ov, nv) async => _migrate(db),
  );
  
    // --- schema compatibility: add missing columns if needed ---
    try {
      final info = await _db!.rawQuery("PRAGMA table_info(tasks)");
      bool has(String name) => info.any((row) => row["name"]?.toString() == name);
      if (!has("task_uid")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN task_uid TEXT");
        await _db!.execute("UPDATE tasks SET task_uid = uid WHERE task_uid IS NULL OR task_uid=''");
      }
      if (!has("trigger_at")) {
        await _db!.execute("ALTER TABLE tasks ADD COLUMN trigger_at INTEGER");
        await _db!.execute("UPDATE tasks SET trigger_at = COALESCE(next_time, strftime('%s','now')*1000)");
      }
      if (!has("freq_type"))            await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_type TEXT");
      if (!has("freq_weekday"))         await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_weekday INTEGER");
      if (!has("freq_day_of_month"))    await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_day_of_month INTEGER");
      if (!has("freq_custom"))          await _db!.execute("ALTER TABLE tasks ADD COLUMN freq_custom TEXT");
    } catch (e, st) { rethrow; }

    return _db!;
}
static Future<void> _migrate(Database db) async {
    // Core tables
    await db.execute('''
      CREATE TABLE IF NOT EXISTS tasks(
        uid TEXT PRIMARY KEY,
        task_uid TEXT,
        title TEXT,
        type TEXT,
        prompt TEXT,
        avatar_path TEXT,
        status TEXT,
        start_time TEXT,
        next_time INTEGER,
        trigger_at INTEGER,
        scheduled_run_key TEXT,
        freq_type TEXT,
        freq_weekday INTEGER,
        freq_day_of_month INTEGER,
        freq_custom TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS quotes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT,
        title TEXT,
        content TEXT,
        created_at INTEGER DEFAULT (strftime('%s','now'))
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_uid TEXT,
        message TEXT,
        created_at INTEGER DEFAULT (strftime('%s','now'))
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS config(
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS payloads(
        task_uid TEXT,
        run_key TEXT,
        title TEXT,
        content TEXT,
        big_picture TEXT,
        actions_json TEXT,
        payload_json TEXT,
        PRIMARY KEY(task_uid, run_key)
      )
    ''');

    // Make sure newly added columns exist (idempotent)
    Future<void> ensureColumn(String table, String column, String ddl) async {
      final info = await db.rawQuery("PRAGMA table_info(" + table + ")");
      final cols = info.map((e) => (e['name'] as String).toLowerCase()).toSet();
      if (!cols.contains(column.toLowerCase())) {
        await db.execute(ddl);
      }
    }

    await ensureColumn('tasks','start_time',"ALTER TABLE tasks ADD COLUMN start_time TEXT");
    await ensureColumn('tasks','next_time',"ALTER TABLE tasks ADD COLUMN next_time INTEGER");
    await ensureColumn('tasks','scheduled_run_key',"ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
    await ensureColumn('tasks','prompt',"ALTER TABLE tasks ADD COLUMN prompt TEXT");
    await ensureColumn('tasks','avatar_path',"ALTER TABLE tasks ADD COLUMN avatar_path TEXT");
    await ensureColumn('tasks','type',"ALTER TABLE tasks ADD COLUMN type TEXT");
    await ensureColumn('tasks','status',"ALTER TABLE tasks ADD COLUMN status TEXT");

    // === App custom migrations for normalized schema ===
    // logs.log_uid unique identifier (keep id as AUTOINCREMENT)
    await ensureColumn('logs','log_uid',"ALTER TABLE logs ADD COLUMN log_uid TEXT");
    await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_logs_log_uid ON logs(log_uid) WHERE log_uid IS NOT NULL");
    // quotes extra columns
    await ensureColumn('quotes','quote_uid',"ALTER TABLE quotes ADD COLUMN quote_uid TEXT");
    await ensureColumn('quotes','task_type',"ALTER TABLE quotes ADD COLUMN task_type TEXT");
    await ensureColumn('quotes','task_name',"ALTER TABLE quotes ADD COLUMN task_name TEXT");
    await ensureColumn('quotes','avatar_path',"ALTER TABLE quotes ADD COLUMN avatar_path TEXT");
    await ensureColumn('quotes','notified',"ALTER TABLE quotes ADD COLUMN notified INTEGER DEFAULT 0");
    // quotes.content unique (allow NULL duplicates)
    await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_quotes_content_unique ON quotes(content) WHERE content IS NOT NULL");
    // tasks.task_uid logical unique (do not change primary key)
    await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_task_uid ON tasks(task_uid)");
    // ON DELETE SET NULL behavior via triggers (since altering foreign keys on existing tables is limited in SQLite)
    await db.execute("""
      CREATE TRIGGER IF NOT EXISTS fk_logs_task_delete
      AFTER DELETE ON tasks
      BEGIN
        UPDATE logs SET task_uid = NULL WHERE task_uid = OLD.task_uid;
      END;
    """);
    await db.execute("""
      CREATE TRIGGER IF NOT EXISTS fk_quotes_task_delete
      AFTER DELETE ON tasks
      BEGIN
        UPDATE quotes SET task_uid = NULL WHERE task_uid = OLD.task_uid;
      END;
    """);
    // Config column-style view mapped onto key-value 'config' table
    await db.execute("""
      CREATE VIEW IF NOT EXISTS app_config_view AS
      SELECT
        NULL AS notify_id,
        (SELECT value FROM config WHERE key='api_key')      AS api_key,
        (SELECT value FROM config WHERE key='bg_image_url') AS bg_image_url,
        (SELECT value FROM config WHERE key='model')        AS model,
        (SELECT value FROM config WHERE key='endpoint')     AS endpoint;
    """);
    await db.execute("""
      CREATE TRIGGER IF NOT EXISTS app_config_view_upd
      INSTEAD OF UPDATE ON app_config_view
      BEGIN
        INSERT INTO config(key,value) VALUES('api_key', NEW.api_key)
          ON CONFLICT(key) DO UPDATE SET value=excluded.value;
        INSERT INTO config(key,value) VALUES('bg_image_url', NEW.bg_image_url)
          ON CONFLICT(key) DO UPDATE SET value=excluded.value;
        INSERT INTO config(key,value) VALUES('model', NEW.model)
          ON CONFLICT(key) DO UPDATE SET value=excluded.value;
        INSERT INTO config(key,value) VALUES('endpoint', NEW.endpoint)
          ON CONFLICT(key) DO UPDATE SET value=excluded.value;
      END;
    """);
,"ALTER TABLE tasks ADD COLUMN status TEXT");
    // ensure quotes.notified exists
    await ensureColumn('quotes','notified',"ALTER TABLE quotes ADD COLUMN notified INTEGER DEFAULT 0");
    // ensure notify_config table exists
    await db.execute("CREATE TABLE IF NOT EXISTS notify_config(self_check_minutes INTEGER)");

        await ensureColumn('tasks','task_uid',"ALTER TABLE tasks ADD COLUMN task_uid TEXT");
        await ensureColumn('tasks','name',"ALTER TABLE tasks ADD COLUMN name TEXT");
  }
}

/// Ensure extra task columns exist when app boots.
Future<void> ensureExtraTaskColumns() async {
  final db = await AppDatabase.instance();
  Future<void> ensure(String column, String ddl) async {
    final info = await db.rawQuery("PRAGMA table_info(tasks)");
    final cols = info.map((e) => (e['name'] as String).toLowerCase()).toSet();
    if (!cols.contains(column.toLowerCase())) {
      await db.execute(ddl);
    }
  }
  await ensure('start_time',"ALTER TABLE tasks ADD COLUMN start_time TEXT");
  await ensure('next_time',"ALTER TABLE tasks ADD COLUMN next_time INTEGER");
  await ensure('scheduled_run_key',"ALTER TABLE tasks ADD COLUMN scheduled_run_key TEXT");
  await ensure('prompt',"ALTER TABLE tasks ADD COLUMN prompt TEXT");
  await ensure('avatar_path',"ALTER TABLE tasks ADD COLUMN avatar_path TEXT");
  await ensure('type',"ALTER TABLE tasks ADD COLUMN type TEXT");
  await ensure('status',"ALTER TABLE tasks ADD COLUMN status TEXT");
}
