package com.example.quote_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import androidx.core.app.NotificationCompat
import com.example.quote_app.data.DbInspector
import kotlin.math.max

/**
 * Foreground service for Sport tracking:
 * - Keep collecting and computing sport metrics even if user leaves SportRunningPage
 *   or removes app from recents.
 *
 * Persist:
 * - sport_records.total_duration (sec)
 * - sport_records.total_steps
 * - sport_records.total_distance (m)
 * - sport_records.avg_speed (km/h)
 * - sport_records.current_speed (km/h)
 *
 * NOTE:
 * - This is Android-only. iOS cannot keep executing after user force-quits.
 */
class SportForegroundService : Service(), LocationListener, SensorEventListener {

  companion object {
    const val ACTION_START = "com.example.quote_app.action.SPORT_FG_START"
    const val ACTION_STOP = "com.example.quote_app.action.SPORT_FG_STOP"
    const val EXTRA_RECORD_ID = "record_id"
    const val EXTRA_TITLE = "title"

    private const val CHANNEL_ID = "sport_fg_channel"
    private const val NOTIF_ID = 7772001

    @Volatile private var running: Boolean = false
    @Volatile private var runningRecordId: Int? = null

    @JvmStatic fun isRunning(): Boolean = running
    @JvmStatic fun getRunningRecordId(): Int? = runningRecordId
  }

  private var recordId: Int = -1
  private var title: String = "运动进行中"

  private var handlerThread: HandlerThread? = null
  private var handler: Handler? = null

  private var locationManager: LocationManager? = null
  private var lastLoc: Location? = null
  private var lastLocTs: Long = 0L
  private var sessionDistanceM: Double = 0.0
  private var currentSpeedKmh: Double = 0.0

  private var baseDurationSec: Int = 0
  private var baseSteps: Int = 0
  private var baseDistanceM: Double = 0.0
  private var sessionStartElapsed: Long = 0L

  private var sensorManager: SensorManager? = null
  private var stepSensor: Sensor? = null
  private var stepBaseline: Long? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    handlerThread = HandlerThread("sport_fg")
    handlerThread?.start()
    handler = Handler(handlerThread?.looper ?: Looper.getMainLooper())
    locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
    ensureNotifChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    try {
      val act = intent?.action
      if (act == ACTION_STOP) {
        stopSelfSafely()
        return START_NOT_STICKY
      }

      // Start / sticky restart
      val rid = intent?.getIntExtra(EXTRA_RECORD_ID, -1) ?: -1
      if (rid <= 0) {
        stopSelfSafely()
        return START_NOT_STICKY
      }
      recordId = rid
      title = intent?.getStringExtra(EXTRA_TITLE) ?: title

      // Start foreground ASAP
      startForeground(NOTIF_ID, buildNotif(title))

      running = true
      runningRecordId = recordId

      // Load base from DB
      loadBaseFromDb()

      // Restore last location from prefs (best-effort)
      restoreLastLocationFromPrefs()

      // Start timers / streams
      startSensors()
      startLocation()

      sessionStartElapsed = SystemClock.elapsedRealtime()

      // Periodic DB persist
      scheduleTick()

      return START_STICKY
    } catch (_: Throwable) {
      stopSelfSafely()
      return START_NOT_STICKY
    }
  }

  override fun onTaskRemoved(rootIntent: Intent?) {
    // Do not stop; keep tracking.
    // START_STICKY will also allow system to recreate.
    super.onTaskRemoved(rootIntent)
  }

  override fun onDestroy() {
    super.onDestroy()
    try { handler?.removeCallbacksAndMessages(null) } catch (_: Throwable) {}
    stopLocation()
    stopSensors()
    try { handlerThread?.quitSafely() } catch (_: Throwable) {}
    handlerThread = null
    handler = null
    running = false
    runningRecordId = null
  }

  private fun stopSelfSafely() {
    try { stopForeground(true) } catch (_: Throwable) {}
    try { stopSelf() } catch (_: Throwable) {}
  }

  private fun ensureNotifChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val ch = NotificationChannel(CHANNEL_ID, "运动进行中", NotificationManager.IMPORTANCE_LOW)
      ch.setShowBadge(false)
      nm.createNotificationChannel(ch)
    }
  }

  private fun buildNotif(content: String) =
    NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("运动进行中")
      .setContentText(content)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setOngoing(true)
      .build()

  private fun startLocation() {
    try {
      val lm = locationManager ?: return
      val looper = handlerThread?.looper ?: Looper.getMainLooper()
      // Prefer GPS; fallback to network when available.
      try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, looper) } catch (_: Throwable) {}
      try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, this, looper) } catch (_: Throwable) {}
    } catch (_: Throwable) {}
  }

  private fun stopLocation() {
    try { locationManager?.removeUpdates(this) } catch (_: Throwable) {}
  }

  private fun startSensors() {
    try {
      val sm = sensorManager ?: return
      val s = stepSensor ?: return
      stepBaseline = null
      val h = handler ?: Handler(Looper.getMainLooper())
      sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL, h)
    } catch (_: Throwable) {}
  }

  private fun stopSensors() {
    try { sensorManager?.unregisterListener(this) } catch (_: Throwable) {}
  }

  override fun onLocationChanged(location: Location) {
    try {
      // Filter out very poor fixes.
      val acc = location.accuracy
      if (!acc.isNaN() && !acc.isInfinite() && acc > 80f) {
        return
      }
      val now = SystemClock.elapsedRealtime()
      val last = lastLoc
      if (last != null) {
        val dtMs = max(1L, now - lastLocTs)
        val d = last.distanceTo(location).toDouble()
        // Ignore tiny jitter and huge jumps.
        if (d >= 0.8 && d < 200) {
          sessionDistanceM += d
          currentSpeedKmh = (d / (dtMs / 1000.0)) * 3.6
        } else if (location.hasSpeed()) {
          currentSpeedKmh = (location.speed.toDouble()) * 3.6
        }
      } else if (location.hasSpeed()) {
        currentSpeedKmh = (location.speed.toDouble()) * 3.6
      }

      lastLoc = location
      lastLocTs = now
      saveLastLocationToPrefs(location)
    } catch (_: Throwable) {}
  }

  override fun onProviderEnabled(provider: String) {}
  override fun onProviderDisabled(provider: String) {}
  override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}


  override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

  private fun scheduleTick() {
    val h = handler ?: return
    h.removeCallbacks(tickRunnable)
    h.post(tickRunnable)
  }

  private val tickRunnable: Runnable = object : Runnable {
    override fun run() {
      try {
        if (recordId <= 0) return

        // If record status changed (paused/stopped/completed), stop service.
        val status = queryStatus()
        if (status != null && status != "in_progress") {
          stopSelfSafely()
          return
        }

        val durSec = baseDurationSec + ((SystemClock.elapsedRealtime() - sessionStartElapsed) / 1000L).toInt()
        val distM = baseDistanceM + sessionDistanceM

        // Steps
        val totalSteps = computeTotalSteps()

        val avgKmh = if (durSec <= 0) 0.0 else (distM / 1000.0) / (durSec / 3600.0)

        persistToDb(
          totalDurationSec = durSec,
          totalSteps = totalSteps,
          totalDistanceM = distM,
          avgSpeedKmh = if (avgKmh.isFinite()) avgKmh else 0.0,
          currentSpeedKmh = if (currentSpeedKmh.isFinite()) currentSpeedKmh else 0.0
        )
      } catch (_: Throwable) {
        // ignore
      } finally {
        // schedule next tick
        try { handler?.postDelayed(this, 2000L) } catch (_: Throwable) {}
      }
    }
  }

  private fun computeTotalSteps(): Int {
    val baseline = stepBaseline
    if (baseline == null) return baseSteps
    // We don't have current counter in tick; but SensorEvent updates baseline only.
    // Keep steps based on latest observed sensor value.
    // To reduce complexity, store latest in stepBaseline? We'll store latest separately.
    return baseSteps + max(0, (latestStepCounter - baseline).toInt())
  }

  private var latestStepCounter: Long = 0L

  override fun onSensorChanged(event: SensorEvent) {
    try {
      if (event.sensor.type != Sensor.TYPE_STEP_COUNTER) return
      val v = event.values.firstOrNull()?.toLong() ?: return
      latestStepCounter = v
      if (stepBaseline == null || v < (stepBaseline ?: 0L)) {
        stepBaseline = v
      }
    } catch (_: Throwable) {}
  }

  private fun queryStatus(): String? {
    var db: SQLiteDatabase? = null
    var c: Cursor? = null
    try {
      db = openDb() ?: return null
      c = db.rawQuery("SELECT status FROM sport_records WHERE id=? LIMIT 1", arrayOf(recordId.toString()))
      if (c.moveToFirst()) return c.getString(0)
    } catch (_: Throwable) {
    } finally {
      try { c?.close() } catch (_: Throwable) {}
      try { db?.close() } catch (_: Throwable) {}
    }
    return null
  }

  private fun loadBaseFromDb() {
    var db: SQLiteDatabase? = null
    var c: Cursor? = null
    try {
      db = openDb() ?: return
      c = db.rawQuery(
        "SELECT total_duration, total_steps, total_distance FROM sport_records WHERE id=? LIMIT 1",
        arrayOf(recordId.toString())
      )
      if (c.moveToFirst()) {
        baseDurationSec = try { c.getInt(0) } catch (_: Throwable) { 0 }
        baseSteps = try { c.getInt(1) } catch (_: Throwable) { 0 }
        baseDistanceM = try { c.getDouble(2) } catch (_: Throwable) { 0.0 }
      }
    } catch (_: Throwable) {
    } finally {
      try { c?.close() } catch (_: Throwable) {}
      try { db?.close() } catch (_: Throwable) {}
    }
  }

  private fun persistToDb(
    totalDurationSec: Int,
    totalSteps: Int,
    totalDistanceM: Double,
    avgSpeedKmh: Double,
    currentSpeedKmh: Double
  ) {
    var db: SQLiteDatabase? = null
    try {
      db = openDb() ?: return
      val now = nowIso()
      db.execSQL(
        "UPDATE sport_records SET total_duration=?, total_steps=?, total_distance=?, avg_speed=?, current_speed=?, updated_at=? WHERE id=?",
        arrayOf(
          totalDurationSec,
          totalSteps,
          totalDistanceM,
          avgSpeedKmh,
          currentSpeedKmh,
          now,
          recordId
        )
      )
    } catch (_: Throwable) {
    } finally {
      try { db?.close() } catch (_: Throwable) {}
    }
  }

  private fun openDb(): SQLiteDatabase? {
    try {
      val cc = DbInspector.loadOrLightScan(this)
      val p = if (cc != null && !TextUtils.isEmpty(cc.dbPath)) cc.dbPath else null
      return if (!p.isNullOrEmpty()) {
        SQLiteDatabase.openDatabase(p, null, SQLiteDatabase.OPEN_READWRITE)
      } else {
        val fallback = getDatabasePath("app.db").absolutePath
        SQLiteDatabase.openOrCreateDatabase(fallback, null)
      }
    } catch (_: Throwable) {
      return null
    }
  }

  private fun nowIso(): String {
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        java.time.OffsetDateTime.now().toString()
      } else {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", java.util.Locale.US)
        fmt.format(java.util.Date())
      }
    } catch (_: Throwable) {
      System.currentTimeMillis().toString()
    }
  }

  private fun saveLastLocationToPrefs(loc: Location) {
    try {
      val sp = getSharedPreferences("sport_fg", Context.MODE_PRIVATE)
      sp.edit()
        .putFloat("last_lat_$recordId", loc.latitude.toFloat())
        .putFloat("last_lng_$recordId", loc.longitude.toFloat())
        .apply()
    } catch (_: Throwable) {}
  }

  private fun restoreLastLocationFromPrefs() {
    try {
      val sp = getSharedPreferences("sport_fg", Context.MODE_PRIVATE)
      val has = sp.contains("last_lat_$recordId") && sp.contains("last_lng_$recordId")
      if (!has) return
      val lat = sp.getFloat("last_lat_$recordId", 0f).toDouble()
      val lng = sp.getFloat("last_lng_$recordId", 0f).toDouble()
      val l = Location("stored")
      l.latitude = lat
      l.longitude = lng
      lastLoc = l
      lastLocTs = SystemClock.elapsedRealtime()
    } catch (_: Throwable) {}
  }
}