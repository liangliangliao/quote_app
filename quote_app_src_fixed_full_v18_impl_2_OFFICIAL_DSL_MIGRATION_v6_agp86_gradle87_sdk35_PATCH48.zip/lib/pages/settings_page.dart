
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _apiKeyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController(text: 'gpt-5');
  final _endpointCtrl = TextEditingController(text: 'https://api.openai.com/v1/responses');

  List<Map<String, dynamic>> _tasks = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final cfg = await ConfigDao().getOne();
    _apiKeyCtrl.text = (cfg['api_key'] ?? '') as String;
    _modelCtrl.text = (cfg['model'] ?? 'gpt-5') as String;
    _endpointCtrl.text = (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String;

    _tasks = await TaskDao().all();
    setState(() { _loading = false; });
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    _modelCtrl.dispose();
    _endpointCtrl.dispose();
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  Future<void> _saveConfig() async {
    try {
      await ConfigDao().save(apiKey: _apiKeyCtrl.text.trim(), model: _modelCtrl.text.trim(), endpoint: _endpointCtrl.text.trim());
      _toast('配置已保存');
    } catch (e) {
      _toast('配置保存失败');
    }
  }

  DateTime _combineToday(TimeOfDay tod) {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
  }

  DateTime _computeNext(Map<String, dynamic> task, {DateTime? from}) {
    final now = from ?? DateTime.now();
    int hh = now.hour, mm = now.minute;
    try {
      final st = (task['start_time'] ?? '') as String;
      if (st.isNotEmpty) {
        final dt = DateFormat('yyyy-MM-dd HH:mm').parse(st);
        hh = dt.hour; mm = dt.minute;
      }
    } catch (_) {}
    final String freqType = (task['freq_type'] ?? 'daily') as String;
    if (freqType == 'weekly') {
      final int wd = (task['freq_weekday'] as int?) ?? 1; // Mon=1..Sun=7
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freqType == 'monthly') {
      final int d = (task['freq_day_of_month'] as int?) ?? 1;
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1; if (m > 12) { m = 1; y += 1; }
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      var cand = DateTime(now.year, now.month, now.day, hh, mm);
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 1));
      return cand;
    }
  }

  Future<void> _openTaskDialog({Map<String, dynamic>? task}) async {
    final isEdit = task != null;
    String name = isEdit ? (task['name'] ?? '') as String : '';
    String type = isEdit ? (task['type'] ?? 'manual') as String : 'manual'; // manual/auto/carousel
    String prompt = isEdit ? (task['prompt'] ?? '') as String : '';
    String status = isEdit ? (task['status'] ?? 'on') as String : 'on'; // on/off
    String freqType = isEdit ? (task['freq_type'] ?? 'daily') as String : 'daily';
    int? freqWeekday = isEdit ? (task['freq_weekday'] as int?) : 1;
    int? freqDayOfMonth = isEdit ? (task['freq_day_of_month'] as int?) : 1;
    TimeOfDay tod;
    try {
      final st = isEdit ? (task['start_time'] ?? '') as String : '';
      if (st.isNotEmpty) {
        final dt = DateFormat('yyyy-MM-dd HH:mm').parse(st);
        tod = TimeOfDay(hour: dt.hour, minute: dt.minute);
      } else {
        tod = const TimeOfDay(hour: 8, minute: 0);
      }
    } catch (_) {
      tod = const TimeOfDay(hour: 8, minute: 0);
    }

    await showDialog(context: context, builder: (ctx){
      return StatefulBuilder(builder: (ctx, setStateDialog){
        return AlertDialog(
          title: Text(isEdit ? '编辑任务' : '新增任务'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: const InputDecoration(labelText: '任务名称'),
                  controller: TextEditingController(text: name),
                  onChanged: (v)=> name = v,
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: type,
                  decoration: const InputDecoration(labelText: '类型'),
                  onChanged: (v)=> setStateDialog(()=> type = v ?? 'manual'),
                  items: const [
                    DropdownMenuItem(value: 'manual', child: Text('手动')),
                    DropdownMenuItem(value: 'auto', child: Text('自动生成')),
                    DropdownMenuItem(value: 'carousel', child: Text('轮播')),
                  ],
                ),
                if (type == 'auto') ...[
                  const SizedBox(height: 8),
                  TextField(
                    decoration: const InputDecoration(labelText: '提示词（仅自动生成需要）'),
                    controller: TextEditingController(text: prompt),
                    onChanged: (v)=> prompt = v,
                  ),
                ],
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: status,
                  decoration: const InputDecoration(labelText: '状态'),
                  onChanged: (v)=> setStateDialog(()=> status = v ?? 'on'),
                  items: const [
                    DropdownMenuItem(value: 'on', child: Text('开启')),
                    DropdownMenuItem(value: 'off', child: Text('关闭')),
                  ],
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: freqType,
                  decoration: const InputDecoration(labelText: '频率'),
                  onChanged: (v)=> setStateDialog(()=> freqType = v ?? 'daily'),
                  items: const [
                    DropdownMenuItem(value: 'daily', child: Text('每天')),
                    DropdownMenuItem(value: 'weekly', child: Text('每周')),
                    DropdownMenuItem(value: 'monthly', child: Text('每月')),
                  ],
                ),
                if (freqType == 'weekly') ...[
                  const SizedBox(height: 8),
                  DropdownButtonFormField<int>(
                    value: freqWeekday ?? 1,
                    decoration: const InputDecoration(labelText: '周几（1=周一…7=周日）'),
                    onChanged: (v)=> setStateDialog(()=> freqWeekday = v),
                    items: const [
                      DropdownMenuItem(value: 1, child: Text('周一')),
                      DropdownMenuItem(value: 2, child: Text('周二')),
                      DropdownMenuItem(value: 3, child: Text('周三')),
                      DropdownMenuItem(value: 4, child: Text('周四')),
                      DropdownMenuItem(value: 5, child: Text('周五')),
                      DropdownMenuItem(value: 6, child: Text('周六')),
                      DropdownMenuItem(value: 7, child: Text('周日')),
                    ],
                  ),
                ],
                if (freqType == 'monthly') ...[
                  const SizedBox(height: 8),
                  DropdownButtonFormField<int>(
                    value: freqDayOfMonth ?? 1,
                    decoration: const InputDecoration(labelText: '每月几号（1-28/30/31自动修正）'),
                    onChanged: (v)=> setStateDialog(()=> freqDayOfMonth = v),
                    items: List.generate(31, (i)=> DropdownMenuItem(value: i+1, child: Text('${i+1}'))),
                  ),
                ],
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Text('时间：'),
                    const SizedBox(width: 12),
                    OutlinedButton(
                      onPressed: () async {
                        final picked = await showTimePicker(context: ctx, initialTime: tod);
                        if (picked != null) setStateDialog(()=> tod = picked);
                      },
                      child: Text('${tod.hour.toString().padLeft(2,'0')}:${tod.minute.toString().padLeft(2,'0')}'),
                    )
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: ()=> Navigator.pop(ctx), child: const Text('取消')),
            ElevatedButton(
              onPressed: () async {
                if (name.trim().isEmpty) { _toast('请输入任务名称'); return; }
                final DateTime start = _combineToday(tod);
                try {
                  if (isEdit) {
                    await TaskDao().update(task!['task_uid'] as String, {
                      'name': name.trim(),
                      'type': type,
                      'prompt': type=='auto' ? prompt.trim() : '',
                      'status': status,
                      'freq_type': freqType,
                      'freq_weekday': freqType=='weekly' ? freqWeekday : null,
                      'freq_day_of_month': freqType=='monthly' ? freqDayOfMonth : null,
                      'start_time': DateFormat('yyyy-MM-dd HH:mm').format(_computeNext({
                        'start_time': DateFormat('yyyy-MM-dd HH:mm').format(start),
                        'freq_type': freqType,
                        'freq_weekday': freqWeekday,
                        'freq_day_of_month': freqDayOfMonth,
                      })),
                    });
                  } else {
                    final uid = await TaskDao().create(
                      name: name.trim(),
                      type: type,
                      startTime: _computeNext({
                        'start_time': DateFormat('yyyy-MM-dd HH:mm').format(start),
                        'freq_type': freqType,
                        'freq_weekday': freqWeekday,
                        'freq_day_of_month': freqDayOfMonth,
                      }),
                      prompt: type=='auto' ? prompt.trim() : '',
                      avatarPath: '',
                      status: status,
                      freqType: freqType,
                      freqWeekday: freqType=='weekly' ? freqWeekday : null,
                      freqDayOfMonth: freqType=='monthly' ? freqDayOfMonth : null,
                      freqCustom: '',
                    );
                  }
                  await SchedulerService.scheduleNextForAll();
                  Navigator.pop(ctx);
                  await _loadAll();
                  _toast('已保存任务');
                } catch (e) {
                  _toast('保存失败：$e');
                }
              },
              child: const Text('保存'),
            ),
          ],
        );
      });
    });
  }

  Future<void> _deleteTask(String uid) async {
    try {
      await TaskDao().delete(uid);
      await SchedulerService.scheduleNextForAll();
      await _loadAll();
      _toast('已删除');
    } catch (e) {
      _toast('删除失败：$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('OpenAI 配置', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height:8),
          TextField(controller: _apiKeyCtrl, decoration: const InputDecoration(labelText: 'API Key')),
          const SizedBox(height:8),
          TextField(controller: _modelCtrl, decoration: const InputDecoration(labelText: '模型')),
          const SizedBox(height:8),
          TextField(controller: _endpointCtrl, decoration: const InputDecoration(labelText: 'Endpoint')),
          const SizedBox(height:8),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton(onPressed: _saveConfig, child: const Text('保存配置')),
          ),
          const Divider(height: 32),
          const Text('任务列表', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          for (final t in _tasks)
            ListTile(
              title: Text((t['name'] ?? '') as String),
              subtitle: Text('时间: ${(t['start_time'] ?? '') as String}  类型: ${(t['type'] ?? '') as String}  状态: ${(t['status'] ?? '') as String}'),
              trailing: Wrap(
                spacing: 8,
                children: [
                  IconButton(icon: const Icon(Icons.edit), onPressed: ()=> _openTaskDialog(task: t)),
                  IconButton(icon: const Icon(Icons.delete_outline), onPressed: ()=> _deleteTask((t['task_uid'] ?? '') as String)),
                ],
              ),
            ),
          const SizedBox(height: 90),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: ()=> _openTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('新增任务'),
      ),
    );
  }
}
