package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.app.AlarmManager

/**
 * 监听 SCHEDULE_EXACT_ALARM 权限变化，授权后拉起应用以便 Flutter 侧重新排程精确闹钟。
 */
class ExactAlarmPermissionChangedReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val action = intent?.action ?: return
        if (action != "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED") return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (am.canScheduleExactAlarms()) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName) ?: return
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            launchIntent.putExtra("reschedule_on_launch", true)
            context.startActivity(launchIntent)
        }
    }
}
