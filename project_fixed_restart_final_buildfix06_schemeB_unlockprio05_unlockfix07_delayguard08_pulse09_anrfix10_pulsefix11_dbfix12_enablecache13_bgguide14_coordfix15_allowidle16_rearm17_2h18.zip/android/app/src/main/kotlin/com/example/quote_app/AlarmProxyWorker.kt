package com.example.quote_app

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.quote_app.data.DbRepo

/**
 * WorkManager 兜底任务：用于在系统长时间待机/ROM 冻结/清理后台后，
 * 尽量恢复 UnlockPulse 的 Alarm 调度。
 *
 * 重要：
 * - 该 Worker 不做定位、不做通知，只做“轻量恢复调度”；
 * - 即使被系统延迟也无妨，目标是防止“脉冲链路彻底断掉”。
 */

class AlarmProxyWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
  override fun doWork(): Result {
    val ctx = applicationContext
    val job = try { inputData.getString("job") ?: "wm_unknown" } catch (_: Throwable) { "wm_unknown" }
    try {
      // 历史版本可能遗留周期 GeoWorker；按需求此处保持清理，避免误触发。
      try { GeoWorker.cancel(ctx) } catch (_: Throwable) {}

      // 关键：确保 UnlockPulse 仍被调度（若开关开启）。
      try { UnlockPulse.ensureScheduledIfNeeded(ctx) } catch (_: Throwable) {}

      // 记录一次轻量日志，便于排查“被清理后是否有恢复尝试”。
      logWithTime(ctx, "【WM兜底】doWork job=$job -> ensureScheduledIfNeeded done")
    } catch (t: Throwable) {
      try { logWithTime(ctx, "【WM兜底】doWork 异常 job=$job：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
    }
    return Result.success()
  }

  private fun logWithTime(ctx: Context, msg: String) {
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      DbRepo.log(ctx, null, "[$now] $msg")
    } catch (_: Throwable) {
      try { DbRepo.log(ctx, null, msg) } catch (_: Throwable) {}
    }
  }
}