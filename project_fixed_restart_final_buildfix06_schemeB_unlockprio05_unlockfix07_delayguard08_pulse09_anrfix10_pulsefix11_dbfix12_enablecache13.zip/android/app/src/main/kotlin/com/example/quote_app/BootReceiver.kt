package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/**
 * BootReceiver listens for device boot completed or app package replacement
 * events and reinitializes all scheduled tasks.  It enqueues a one‑off
 * workmanager job with job name `wm_boot` which is handled in the Dart
 * dispatcher to restore all alarms and scheduled WorkManager tasks.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Build data payload
        val data = Data.Builder()
            .putString("job", "wm_boot")
            .build()
        val request = OneTimeWorkRequestBuilder<AlarmProxyWorker>()
            .setInputData(data)
            .build()
        WorkManager.getInstance(context).enqueue(request)

        // 按需求：地点规则提醒不再采用 WorkManager 周期任务；仅在“解锁广播”触发。
        // 这里仅做一次清理：取消历史版本可能遗留的周期 GeoWorker，避免误触发。
        try { GeoWorker.cancel(context) } catch (_: Throwable) { /* ignore */ }

        // 无常驻通知的命中率增强：开机/更新后恢复 UnlockPulse（若开关开启）。
        // 这是“状态探测”兜底，不做周期性定位。
        try { UnlockPulse.ensureScheduledIfNeeded(context) } catch (_: Throwable) { /* ignore */ }

        // Sport: ensure midnight renewal alarm exists after reboot and best-effort reschedule all sport plan alarms.
        try { com.example.quote_app.sport.SportPlanRenewal.scheduleMidnightAlarm(context) } catch (_: Throwable) {}
        try { com.example.quote_app.sport.SportPlanRenewal.rescheduleAllPlanAlarms(context) } catch (_: Throwable) {}
    }
}
