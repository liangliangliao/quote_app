package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    companion object { @JvmStatic var finishOnResume: Boolean = false }

    private fun invokeFinishAndRemoveTask() {
        try {
            val m = this::class.java.superclass?.getMethod("finishAndRemoveTask")
            m?.invoke(this)
        } catch (_: Throwable) {
            try { finishAffinity() } catch (_: Throwable) { try { finish() } catch (_: Throwable) {} }
        }
    }

    override fun onResume() {
        super.onResume()
        if (BackCloser.finishOnResume) {
            BackCloser.finishOnResume = false
            try { invokeFinishAndRemoveTask() } catch (_: Throwable) {}
            try { android.os.Process.killProcess(android.os.Process.myPid()) } catch (_: Throwable) {}
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 仅注册通道；不引入业务逻辑，避免后续维护成本
        Channels.register(flutterEngine, applicationContext) // Context 在前，Engine 在后
    }
}
