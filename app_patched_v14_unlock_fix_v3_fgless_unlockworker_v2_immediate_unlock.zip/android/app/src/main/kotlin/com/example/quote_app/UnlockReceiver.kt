package com.example.quote_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.widget.Toast
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.quote_app.data.DbInspector
import com.example.quote_app.data.DbRepo

/**
 * UnlockReceiver 作为解锁链路的统一入口：
 *
 * - 由 Manifest 静态注册 + Application 动态注册共同接收解锁/亮屏相关广播；
 * - 在收到 USER_PRESENT / USER_UNLOCKED / SCREEN_ON 时：
 *   1）记录详细中文日志；
 *   2）尽力弹出一条 Toast（用于调试和简单提示，允许后台环境下被系统延迟）；
 *   3）立即在当前 onReceive 回调中完成数据库检查、冷却判断并发送解锁提醒通知；
 *   4）同时调度一次 GeoWorker 作为地理情景提醒的补充。
 *
 * 注意：
 * - 本实现不再依赖前台守护服务（ScreenGatekeeperService），也不依赖 WorkManager
 *   来触发解锁提醒通知，避免在部分 ROM 上出现「Worker 直到打开 App 才执行」的问题；
 * - 所有关键步骤都带有中文日志，方便线上排查。
 */
class UnlockReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "null"

        // 1）记录收到广播的 action
        try {
            DbRepo.log(
                context,
                null,
                "【解锁提醒】UnlockReceiver.onReceive：收到系统广播 action=" + action
            )
        } catch (_: Throwable) {
        }

        // 只处理解锁/亮屏相关广播
        val isUnlockAction =
            (Intent.ACTION_USER_PRESENT == action) ||
                (Intent.ACTION_USER_UNLOCKED == action) ||
                (Intent.ACTION_SCREEN_ON == action)

        if (!isUnlockAction) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver.onReceive：收到的并非解锁相关广播，本次不做解锁提醒处理，直接返回"
                )
            } catch (_: Throwable) {
            }
            return
        }

        // Best-effort Toast：用于调试提示「解锁广播已到达」，允许被系统延迟或屏蔽
        try {
            Toast.makeText(
                context.applicationContext,
                "检测到解锁，正在检查愿景提醒…",
                Toast.LENGTH_SHORT
            ).show()
        } catch (_: Throwable) {
            // 某些 ROM 限制后台 Toast，这里只做尝试，不影响主逻辑
        }

        // 2）无论最终是否会发送解锁提醒，都先调度一次 GeoWorker，保持与历史行为一致
        try {
            val request = OneTimeWorkRequestBuilder<GeoWorker>().build()
            WorkManager.getInstance(context.applicationContext).enqueue(request)
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：已为本次解锁调度一次 GeoWorker，用于解锁后更新地理位置并触发情景提醒"
                )
            } catch (_: Throwable) {
            }
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：调度 GeoWorker 失败（仅影响地理位置相关提醒，不影响本次解锁基本提醒），异常类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {
            }
        }

        // 3）在当前 onReceive 中直接执行数据库检查与冷却逻辑，避免依赖 WorkManager 调度
        handleUnlockBusiness(context)
    }

    /**
     * 在当前进程中直接完成一次完整的“解锁提醒”业务逻辑：
     * - 读取解锁开关与触发器配置；
     * - 计算冷却时间并结合 SharedPreferences 做频控；
     * - 满足条件时记录解锁时间戳并发送通知。
     */
    private fun handleUnlockBusiness(context: Context) {
        // 将 UnlockWorker.doWork 中的核心业务逻辑内联到此处

        try {
            DbRepo.log(
                context,
                null,
                "【解锁提醒】UnlockReceiver.handleUnlockBusiness：开始处理一次解锁事件（同步逻辑，不再依赖 WorkManager）"
            )
        } catch (_: Throwable) {
        }

        // 3.1）获取数据库路径
        val contract = try {
            DbInspector.loadOrLightScan(context)
        } catch (_: Throwable) {
            null
        }

        if (contract == null || contract.dbPath == null) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：DbInspector 加载失败或 dbPath 为空，无法读取配置，本次解锁提醒将被跳过"
                )
            } catch (_: Throwable) {
            }
            return
        }

        val dbPath = contract.dbPath!!

        // 3.2）打开数据库并检查 screen_unlock 触发器及解锁开关
        val db: SQLiteDatabase = try {
            SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY)
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：打开数据库失败，异常类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {
            }
            return
        }

        var hasTrigger = false
        var configEnabled = false

        try {
            val cursor = db.rawQuery(
                "SELECT config FROM vision_triggers WHERE type='screen_unlock' AND enabled=1 LIMIT 1",
                null
            )
            hasTrigger = cursor.moveToFirst()
            cursor.close()

            // 读取 notify_config.unlock_switch_enabled 开关
            try {
                val c = db.rawQuery(
                    "SELECT value FROM notify_config WHERE key='unlock_switch_enabled' LIMIT 1",
                    null
                )
                if (c.moveToFirst()) {
                    val v = c.getString(0)
                    if (v != null) {
                        val s = v.trim().lowercase()
                        configEnabled = (s == "1" || s == "true")
                    }
                }
                c.close()
            } catch (_: Throwable) {
                // ignore db errors
            }

            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：数据库检查完成，hasTrigger=" + hasTrigger +
                        "，configEnabled=" + configEnabled +
                        "（是否存在解锁触发器 / 解锁提醒开关是否开启）"
                )
            } catch (_: Throwable) {
            }
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：查询解锁触发器 / 配置时发生异常，本次解锁提醒将被跳过，异常类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {
            }
            try {
                db.close()
            } catch (_: Throwable) {
            }
            return
        }

        // 若开关关闭，直接结束
        if (!configEnabled) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：解锁轻提醒开关已关闭，本次解锁不发送任何通知"
                )
            } catch (_: Throwable) {
            }
            try {
                db.close()
            } catch (_: Throwable) {
            }
            return
        }

        // 3.3）计算冷却时间（默认 30 分钟，可被 unlock_cooldown_days / unlock_cooldown_minutes 覆盖）
        var cooldownMs = 30L * 60L * 1000L
        try {
            // 优先读取按天配置
            try {
                val cDay = db.rawQuery(
                    "SELECT value FROM notify_config WHERE key='unlock_cooldown_days' LIMIT 1",
                    null
                )
                if (cDay.moveToFirst()) {
                    val v = cDay.getString(0)
                    try {
                        val d = v?.toDouble()
                        if (d != null && d > 0.0) {
                            cooldownMs = (d * 24.0 * 60.0 * 60.0 * 1000.0).toLong()
                        }
                    } catch (_: Throwable) {
                    }
                }
                cDay.close()
            } catch (_: Throwable) {
            }
            // 如果天数配置未覆盖，则尝试读取按分钟配置
            if (cooldownMs == 30L * 60L * 1000L) {
                try {
                    val cMin = db.rawQuery(
                        "SELECT value FROM notify_config WHERE key='unlock_cooldown_minutes' LIMIT 1",
                        null
                    )
                    if (cMin.moveToFirst()) {
                        val v2 = cMin.getString(0)
                        try {
                            val m = v2?.toInt()
                            if (m != null && m > 0) {
                                cooldownMs = m.toLong() * 60L * 1000L
                            }
                        } catch (_: Throwable) {
                        }
                    }
                    cMin.close()
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        } finally {
            try {
                db.close()
            } catch (_: Throwable) {
            }
        }

        // 3.4）根据冷却时间结合 SharedPreferences 判断本次是否需要发送解锁提醒
        var inCooldown = false
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val last = prefs.getLong("last_unlock_reminder_time", 0L)
            if (last > 0L && (now - last) < cooldownMs) {
                inCooldown = true
            }
        } catch (_: Throwable) {
        }

        if (inCooldown) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：仍处于解锁提醒冷却期，跳过本次解锁通知，cooldownMs=" + cooldownMs
                )
            } catch (_: Throwable) {
            }
            return
        }

        if (hasTrigger || configEnabled) {
            // 记录本次解锁事件时间戳，供 App 启动兜底逻辑参考
            try {
                val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
                val ts = System.currentTimeMillis()
                prefs.edit().putLong("last_unlock_time", ts).apply()
                try {
                    DbRepo.log(
                        context,
                        null,
                        "【解锁提醒】UnlockReceiver：记录本次解锁事件时间戳 last_unlock_time=" + ts
                    )
                } catch (_: Throwable) {
                }

            } catch (_: Throwable) {
                // ignore
            }

            // 真正发送解锁提醒通知
            sendReminder(context)
        } else {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：当前不存在启用的解锁触发器，且配置开关未强制开启，本次不发送解锁提醒"
                )
            } catch (_: Throwable) {
            }
        }
    }

    /**
     * 发送解锁轻提醒通知，同时更新 last_unlock_reminder_time。
     * 注意：这里直接在 BroadcastReceiver 的上下文中调用，以确保通知不会
     * 受到 WorkManager 调度延迟的影响。
     */
    private fun sendReminder(context: Context) {
        // 记录最近一次通过解锁事件发送提醒的时间
        try {
            val prefs = context.getSharedPreferences("vision_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_unlock_reminder_time", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
            // 忽略异常，避免因为偏好写入失败影响解锁提醒主流程
        }

        val id = 2000
        val title = "愿景提醒"
        val body = "别忘了你的一件事！"

        val ts = System.currentTimeMillis()
        try {
            DbRepo.log(
                context,
                null,
                "【解锁提醒】UnlockReceiver：即将通过专用解锁提醒渠道发送通知，将立即调用 NotifyHelper.sendUnlockReminder，ts=" +
                    ts + "，通知ID=" + id
            )
        } catch (_: Throwable) {
        }

        try {
            NotifyHelper.sendUnlockReminder(context, id, title, body)
        } catch (e: Throwable) {
            try {
                DbRepo.log(
                    context,
                    null,
                    "【解锁提醒】UnlockReceiver：调用 NotifyHelper.sendUnlockReminder 发生异常，类型=" +
                        e.javaClass.simpleName + "，message=" + (e.message ?: "null")
                )
            } catch (_: Throwable) {
            }
        }
    }
}
