
package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.example.quote_app.IdCard;
import com.example.quote_app.ExactAlarmHelper;
import com.example.quote_app.NativeSchedulerK;
import com.example.quote_app.NotifyHelper;
import com.example.quote_app.schedule.NextTriggerCalculator;
import com.example.quote_app.biz.Biz;
import com.example.quote_app.data.DbRepository;

public class AlarmReceiver extends BroadcastReceiver {

  @Override public void onReceive(Context context, Intent intent) {
    String idCard = "";
    try { idCard = intent.getStringExtra("id_card"); } catch (Throwable ignore) {}
    String uid = IdCard.uidOf(idCard);
    String runKey = IdCard.runKeyOf(idCard);
    if (TextUtils.isEmpty(uid)) {
      try { NotifyHelper.send(context.getApplicationContext(), 0, "提醒", "到点了", null); } catch (Throwable ignore) {}
      return;
    }
    boolean ok = false;
    try { ok = Biz.run(context.getApplicationContext(), uid, runKey); } catch (Throwable t) {
      try { DbRepository.log(context.getApplicationContext(), uid, "AM业务异常:" + (t.getMessage()==null?"":t.getMessage())); } catch (Throwable ignore) {}
      ok = false;
    }
    if (ok) {
      try {
        // 成功：先取消兜底，再取消当前，最后续排
        String fbId = IdCard.build("fallback-wm", runKey, uid);
        NativeSchedulerK.cancelByIdCard(context.getApplicationContext(), fbId);
      } catch (Throwable ignore) {}
      try { NativeSchedulerK.cancelByIdCard(context.getApplicationContext(), idCard); } catch (Throwable ignore) {}
      try {
        long nextAt = NextTriggerCalculator.compute(context.getApplicationContext(), uid);
        boolean hasExact = ExactAlarmHelper.hasExactAlarmPermission(context.getApplicationContext());
        if (hasExact) {
          String nextId = IdCard.build("am", runKey, uid);
          NativeSchedulerK.scheduleExactAtByIdCard(context.getApplicationContext(), nextId, nextAt, "{}");
          String fbNext = IdCard.build("fallback-wm", runKey, uid);
          NativeSchedulerK.scheduleWmFallbackByIdCard(context.getApplicationContext(), fbNext, nextAt + 2*60*1000L, "{}");
        } else {
          String wmNext = IdCard.build("main-wm", runKey, uid);
          NativeSchedulerK.scheduleWmMainByIdCard(context.getApplicationContext(), wmNext, nextAt, "{}");
          String fbNext = IdCard.build("fallback-wm", runKey, uid);
          NativeSchedulerK.scheduleWmFallbackByIdCard(context.getApplicationContext(), fbNext, nextAt + 2*60*1000L, "{}");
        }
      } catch (Throwable ignore) {}
      return;
    } else {
      // 失败：取消当前并续排
      try { NativeSchedulerK.cancelByIdCard(context.getApplicationContext(), idCard); } catch (Throwable ignore) {}
      try {
        long nextAt = NextTriggerCalculator.compute(context.getApplicationContext(), uid);
        boolean hasExact = ExactAlarmHelper.hasExactAlarmPermission(context.getApplicationContext());
        if (hasExact) {
          String nextId = IdCard.build("am", runKey, uid);
          NativeSchedulerK.scheduleExactAtByIdCard(context.getApplicationContext(), nextId, nextAt, "{}");
          String fbNext = IdCard.build("fallback-wm", runKey, uid);
          NativeSchedulerK.scheduleWmFallbackByIdCard(context.getApplicationContext(), fbNext, nextAt + 2*60*1000L, "{}");
        } else {
          String wmNext = IdCard.build("main-wm", runKey, uid);
          NativeSchedulerK.scheduleWmMainByIdCard(context.getApplicationContext(), wmNext, nextAt, "{}");
          String fbNext = IdCard.build("fallback-wm", runKey, uid);
          NativeSchedulerK.scheduleWmFallbackByIdCard(context.getApplicationContext(), fbNext, nextAt + 2*60*1000L, "{}");
        }
      } catch (Throwable ignore) {}
    }
  }
}
