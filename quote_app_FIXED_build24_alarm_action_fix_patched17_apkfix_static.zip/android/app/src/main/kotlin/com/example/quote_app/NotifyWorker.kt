class NotifyWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
  override suspend fun doWork(): Result {
    val payload = inputData.getString("payload") ?: "{}"
    val idCard = inputData.getString("id_card") ?: ""
    val uid = IdCard.uidOf(idCard)
    val runKey = IdCard.runKeyOf(idCard)
    val src = IdCard.srcOf(idCard)
    var ok = false
    try {
      ok = com.example.quote_app.biz.Biz.run(applicationContext, uid, runKey)
    } catch (t: Throwable) {
      com.example.quote_app.data.DbRepository.log(applicationContext, uid, "WM业务异常: "+(t.message ?: ""))
      ok = false
    }

    if (ok) {
      // a.* 成功
      if (src == "am" || src == "main-wm") {
        // 取消备兜底
        val fbId = IdCard.build("fallback-wm", runKey, uid)
        try { NativeSchedulerK.cancelByIdCard(applicationContext, fbId) } catch (_: Throwable) {}
        // 取消当前
        try { NativeSchedulerK.cancelByIdCard(applicationContext, idCard) } catch (_: Throwable) {}
        // 续排下一次
        try {
          val nextAt = com.example.quote_app.schedule.NextTriggerCalculator.compute(applicationContext, uid)
          val hasExact = ExactAlarmHelper.hasExactAlarmPermission(applicationContext)
          if (hasExact) {
            val nextId = IdCard.build("am", runKey, uid)
            NativeSchedulerK.scheduleExactAtByIdCard(applicationContext, nextId, nextAt, payload)
            val fbNext = IdCard.build("fallback-wm", runKey, uid)
            NativeSchedulerK.scheduleWmFallbackByIdCard(applicationContext, fbNext, nextAt + 2*60*1000L, payload)
          } else {
            val mainNext = IdCard.build("main-wm", runKey, uid)
            NativeSchedulerK.scheduleWmMainByIdCard(applicationContext, mainNext, nextAt, payload)
            val fbNext = IdCard.build("fallback-wm", runKey, uid)
            NativeSchedulerK.scheduleWmFallbackByIdCard(applicationContext, fbNext, nextAt + 2*60*1000L, payload)
          }
        } catch (_: Throwable) {}
        return Result.success()
      } else if (src == "fallback-wm") {
        // a.2 取消当前兜底
        try { NativeSchedulerK.cancelByIdCard(applicationContext, idCard) } catch (_: Throwable) {}
        return Result.success()
      } else if (src == "selfck-wm") {
        try { NativeSchedulerK.cancelByIdCard(applicationContext, idCard) } catch (_: Throwable) {}
        return Result.success()
      }
      return Result.success()
    } else {
      // b.* 失败
      if (src == "am" || src == "main-wm") {
        try { NativeSchedulerK.cancelByIdCard(applicationContext, idCard) } catch (_: Throwable) {}
        try {
          val nextAt = com.example.quote_app.schedule.NextTriggerCalculator.compute(applicationContext, uid)
          val hasExact = ExactAlarmHelper.hasExactAlarmPermission(applicationContext)
          if (hasExact) {
            val nextId = IdCard.build("am", runKey, uid)
            NativeSchedulerK.scheduleExactAtByIdCard(applicationContext, nextId, nextAt, payload)
            val fbNext = IdCard.build("fallback-wm", runKey, uid)
            NativeSchedulerK.scheduleWmFallbackByIdCard(applicationContext, fbNext, nextAt + 2*60*1000L, payload)
          } else {
            val mainNext = IdCard.build("main-wm", runKey, uid)
            NativeSchedulerK.scheduleWmMainByIdCard(applicationContext, mainNext, nextAt, payload)
            val fbNext = IdCard.build("fallback-wm", runKey, uid)
            NativeSchedulerK.scheduleWmFallbackByIdCard(applicationContext, fbNext, nextAt + 2*60*1000L, payload)
          }
        } catch (_: Throwable) {}
        return Result.success()
      } else if (src == "fallback-wm") {
        // 统计重试次数
        val attempts = runAttemptCount
        try { NativeSchedulerK.cancelByIdCard(applicationContext, idCard) } catch (_: Throwable) {}
        return if (attempts > 2) {
          Result.failure()
        } else {
          // 重新以零延迟立即兜底
          val now = System.currentTimeMillis()
          try { NativeSchedulerK.scheduleWmFallbackByIdCard(applicationContext, idCard, now, payload) } catch (_: Throwable) {}
          Result.retry()
        }
      } else if (src == "selfck-wm") {
        try { NativeSchedulerK.cancelByIdCard(applicationContext, idCard) } catch (_: Throwable) {}
        return Result.success()
      }
      return Result.retry()
    }
  }
}