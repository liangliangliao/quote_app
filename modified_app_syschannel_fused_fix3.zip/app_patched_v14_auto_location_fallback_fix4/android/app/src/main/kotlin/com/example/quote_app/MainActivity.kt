package com.example.quote_app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import android.os.Bundle
import android.content.Intent

class MainActivity : FlutterActivity() {


    private fun maybeHandleNotificationIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra("from_notification", false)) {
            // Extract additional extras for navigation
            val notifType = intent.getStringExtra("notif_type")
            val payload = intent.getStringExtra("payload")
            // Record and emit the event with type/payload
            Channels.markNotificationTapped()
            Channels.emitNotificationTap(notifType, payload)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        maybeHandleNotificationIntent(intent)
        try {
            if (intent?.getBooleanExtra("from_notification", false) == true) {
                com.example.quote_app.data.DbRepo.log(
                    applicationContext,
                    null,
                    "[NotifTap] onCreate from_notification=true"
                )
            }
        } catch (_: Throwable) {}
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        maybeHandleNotificationIntent(intent)
        try {
            if (intent.getBooleanExtra("from_notification", false)) {
                com.example.quote_app.data.DbRepo.log(
                    applicationContext,
                    null,
                    "[NotifTap] onNewIntent from_notification=true"
                )
            }
        } catch (_: Throwable) {}
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 仅注册通道；不引入业务逻辑，避免后续维护成本
        Channels.register(flutterEngine, applicationContext)
        SysChannel.register(flutterEngine, applicationContext)
    }
}
