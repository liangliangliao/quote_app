
package com.example.quote_app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.google.android.gms.location.*
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.example.quote_app.data.DbRepo
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date
import java.util.concurrent.CountDownLatch

object SysChannel {
  private const val CH = "com.example.quote_app/sys"

  private fun now(): String {
    return try { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS", Locale.getDefault()).format(Date()) } catch (_:Throwable) { "" }
  }

  fun register(engine: FlutterEngine, appCtx: Context) {
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      when (call.method) {
        "getBaiduLocationOnce" -> {
          try { DbRepo.log(appCtx, null, "[${now()}]\n[LocationService]【定位】Baidu SDK 调用开始") } catch (_: Throwable) { }
          try {
            val ak = try { com.example.quote_app.data.ConfigReader.getBaiduAk(appCtx) } catch (_:Throwable){ null } ?: "kmHcLsW5heS5miYWLpbRUsrQapGIJ5m2"
            val loc = obtainBaiduLocation(appCtx, ak, 30.0, 10000L)
            if (loc != null) {
              val map = mapOf("lat" to loc.latitude, "lng" to loc.longitude, "acc" to loc.accuracy, "provider" to loc.provider)
              result.success(map)
              try { DbRepo.log(appCtx, null, "[${now()}]\n[LocationService]【定位】Baidu SDK 成功 lat=${'$'}{loc.latitude}, lon=${'$'}{loc.longitude}, acc=${'$'}{loc.accuracy}") } catch (_: Throwable) {}
            } else {
              result.error("NOLOC", "baidu fail", null)
              try { DbRepo.log(appCtx, null, "[${now()}]\n[LocationService]【定位】Baidu SDK 失败（返回空）") } catch (_: Throwable) {}
            }
          } catch (t: Throwable) {
            result.error("ERR", t.message, null)
            try { DbRepo.log(appCtx, null, "[${now()}]\n[LocationService]【定位】Baidu SDK 调用异常：${'$'}{t.message}") } catch (_: Throwable) {}
          }
        }
        "getSystemLocationOnce" -> {
          try {
            val loc = obtainFusedHighAcc(appCtx, 30.0, 12000L) ?: obtainHighAccuracyLocation(appCtx, 30.0, 10000L)
            if (loc != null) {
              val map = mapOf("lat" to loc.latitude, "lng" to loc.longitude, "acc" to loc.accuracy, "provider" to loc.provider)
              result.success(map)
              try { DbRepo.log(appCtx, null, "[${now()}]\n[LocationService]【定位】System 成功 lat=${'$'}{loc.latitude}, lon=${'$'}{loc.longitude}, acc=${'$'}{loc.accuracy}, provider=${'$'}{loc.provider}") } catch (_: Throwable) {}
            } else {
              result.error("NOLOC", "system fail", null)
            }
          } catch (t: Throwable) {
            result.error("ERR", t.message, null)
          }
        }
        else -> result.notImplemented()
      }
    }
  }

  private fun obtainFusedHighAcc(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(ctx)
      val latch = CountDownLatch(1)
      var best: Location? = null
      val req = com.google.android.gms.location.LocationRequest.Builder(com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, 1000L)
        .setWaitForAccurateLocation(true)
        .setMaxUpdates(6)
        .build()
      val cb = object: com.google.android.gms.location.LocationCallback() {
        override fun onLocationResult(result: com.google.android.gms.location.LocationResult) {
          for (l in result.locations) {
            if (best == null || l.accuracy < best!!.accuracy) best = l
          }
          if (best != null && best!!.accuracy <= targetAccMeters) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
        }
      }
      try { client.requestLocationUpdates(req, cb, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { client.removeLocationUpdates(cb) } catch (_: Throwable) {}
      best
    } catch (_: Throwable) { null }
  }

  private fun obtainHighAccuracyLocation(ctx: Context, targetAccMeters: Double, timeoutMs: Long): Location? {
    try {
      val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
      val latch = CountDownLatch(1)
      var best: Location? = null
      val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
          if (best == null || loc.accuracy < best!!.accuracy) best = loc
          if (best != null && best!!.accuracy <= targetAccMeters) {
            try { latch.countDown() } catch (_: Throwable) {}
          }
        }
        @Deprecated("deprecated") override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
      }
      try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0f, listener, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500, 0f, listener, Looper.getMainLooper()) } catch (_: Throwable) {}
      try { latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}
      try { lm.removeUpdates(listener) } catch (_: Throwable) {}
      return best
    } catch (_: Throwable) { return null }
  }

  private fun obtainBaiduLocation(ctx: Context, ak: String, targetAccMeters: Double, timeoutMs: Long): Location? {
    return try {
      val clientClazz = Class.forName("com.baidu.location.LocationClient")
      val optionsClazz = Class.forName("com.baidu.location.LocationClientOption")
      val listenerIfc = Class.forName("com.baidu.location.BDAbstractLocationListener")
      val bdLocClazz = Class.forName("com.baidu.location.BDLocation")

      val client = clientClazz.getConstructor(Context::class.java).newInstance(ctx)
      val opts = optionsClazz.getDeclaredConstructor().newInstance()

      optionsClazz.getMethod("setOpenGps", Boolean::class.java).invoke(opts, true)
      try { optionsClazz.getMethod("setScanSpan", Int::class.java).invoke(opts, 0) } catch (_: Throwable) {}
      try { optionsClazz.getMethod("setIsNeedAddress", Boolean::class.java).invoke(opts, false) } catch (_: Throwable) {}
      clientClazz.getMethod("setLocOption", optionsClazz).invoke(client, opts)

      val holder = arrayOfNulls<Any>(1)
      val handler = java.lang.reflect.Proxy.newProxyInstance(
        listenerIfc.classLoader, arrayOf(listenerIfc)
      ) { _, method, args ->
        if (method.name == "onReceiveLocation" && args != null && args.isNotEmpty()) {
          holder[0] = args[0]
        }
        null
      }
      clientClazz.getMethod("registerLocationListener", listenerIfc).invoke(client, handler)
      clientClazz.getMethod("start").invoke(client)

      val start = System.currentTimeMillis()
      while (System.currentTimeMillis() - start < timeoutMs) {
        val cur = holder[0]
        if (cur != null) {
          val acc = (Class.forName("com.baidu.location.BDLocation").getMethod("getRadius").invoke(cur) as? Float) ?: 9999f
          val lat = Class.forName("com.baidu.location.BDLocation").getMethod("getLatitude").invoke(cur) as? Double
          val lng = Class.forName("com.baidu.location.BDLocation").getMethod("getLongitude").invoke(cur) as? Double
          if (lat != null && lng != null && acc <= targetAccMeters) {
            val l = Location("baidu"); l.latitude = lat; l.longitude = lng; l.accuracy = acc
            try { clientClazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
            return l
          }
        }
        Thread.sleep(300)
      }
      try { clientClazz.getMethod("stop").invoke(client) } catch (_: Throwable) {}
      null
    } catch (_: Throwable) { null }
  }
}
