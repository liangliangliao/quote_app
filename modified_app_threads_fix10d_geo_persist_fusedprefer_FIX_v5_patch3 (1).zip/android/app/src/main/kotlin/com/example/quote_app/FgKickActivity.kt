package com.example.quote_app

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle

class FgKickActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    try {
      val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
      val now = sdf.format(java.util.Date())
      try { com.example.quote_app.data.DbRepo.log(this, null, "[$now] 【前台服务-地点规则】透明Activity拉起，尝试启动前台服务") } catch (_: Throwable) {}
      val intent = Intent(this, GeoForegroundService::class.java)
      try {
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        try { com.example.quote_app.data.DbRepo.log(this, null, "[$now] 【前台服务-地点规则】透明Activity已发起 startForegroundService") } catch (_: Throwable) {}
      } catch (t: Throwable) {
        try { com.example.quote_app.data.DbRepo.log(this, null, "[$now] 【前台服务-地点规则】透明Activity启动服务失败：" + (t.message ?: "unknown")) } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {}
    finish()
  }
}
