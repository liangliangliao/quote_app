package com.example.quote_app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*

object NativeSchedulerK {
  private const val CHANNEL_ID = "quote_notify"
  private const val UNIQUE_WORK_PREFIX = "wm_once_"

  private fun ensureChannel(ctx: Context) {
    val mgr = NotificationManagerCompat.from(ctx)
    val ch = NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManager.IMPORTANCE_HIGH)
      .setName("Quote Reminders")
      .setDescription("Scheduled reminders")
      .build()
    mgr.createNotificationChannel(ch)
  }

  fun canScheduleExact(ctx: Context): Boolean {
    val am = ctx.getSystemService(AlarmManager::class.java)
    return if (Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true
  }

  fun requestExact(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 31) {
      val it = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      ctx.startActivity(it)
    }
  }

  fun scheduleExactAt(ctx: Context, id: Int, epochMs: Long, payloadJson: String): Boolean {
    ensureChannel(ctx)
    val am = ctx.getSystemService(AlarmManager::class.java)
    val intent = Intent(ctx, AlarmReceiver::class.java).apply {
      action = "ALARM_FIRE"
      putExtra("id", id)
      putExtra("payload", payloadJson)
    }
    val pi = PendingIntent.getBroadcast(
      ctx, id, intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    return try {
      if (Build.VERSION.SDK_INT >= 21 && canScheduleExact(ctx)) {
        val showIntent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        val aci = AlarmManager.AlarmClockInfo(epochMs, PendingIntent.getActivity(
          ctx, id, showIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ))
        am.setAlarmClock(aci, pi)
      } else if (Build.VERSION.SDK_INT >= 23) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, pi)
      } else if (Build.VERSION.SDK_INT >= 19) {
        am.setExact(AlarmManager.RTC_WAKEUP, epochMs, pi)
      } else {
        am.set(AlarmManager.RTC_WAKEUP, epochMs, pi)
      }
      true
    } catch (e: SecurityException) {
      enqueueOnceWithWM(ctx, id, epochMs, payloadJson)
      false
    }
  }

  private fun enqueueOnceWithWM(ctx: Context, id: Int, epochMs: Long, payloadJson: String) {
    val delay = kotlin.math.max(0L, epochMs - System.currentTimeMillis())
    val req = OneTimeWorkRequestBuilder<NotifyWorker>()
      .setInitialDelay(java.time.Duration.ofMillis(delay))
      .setInputData(workDataOf("id" to id, "payload" to payloadJson))
      .addTag("$UNIQUE_WORK_PREFIX$id")
      .build()
    WorkManager.getInstance(ctx).enqueueUniqueWork(
      "$UNIQUE_WORK_PREFIX$id", ExistingWorkPolicy.REPLACE, req
    )
  }

  fun cancel(ctx: Context, id: Int) {
    val am = ctx.getSystemService(AlarmManager::class.java)
    val intent = Intent(ctx, AlarmReceiver::class.java).apply { action = "ALARM_FIRE" }
    val pi = PendingIntent.getBroadcast(
      ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
    )
    if (pi != null) am.cancel(pi)
    WorkManager.getInstance(ctx).cancelUniqueWork("$UNIQUE_WORK_PREFIX$id")
  }
}
