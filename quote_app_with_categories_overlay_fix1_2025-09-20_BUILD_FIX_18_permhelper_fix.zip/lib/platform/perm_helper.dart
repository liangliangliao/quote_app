import 'dart:io';
import 'package:flutter/services.dart';

class PermHelper {
  static const MethodChannel _ch = MethodChannel('com.example.quote_app/sys');

  static Future<bool> hasExactAlarmPermission() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('hasExactAlarmPermission');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestExactAlarmPermission() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestExactAlarmPermission');
    } catch (_) {}
  }

  // 电池优化白名单：检测
  static Future<bool> hasBatteryOptExemption() async {
    if (!Platform.isAndroid) return true;
    try {
      final ok = await _ch.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  // 电池优化白名单：请求
  static Future<void> requestBatteryOptExemption() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {}
  }

  // 电池优化白名单：确保
  static Future<void> ensureBatteryOptExemption() async {
    final ok = await hasBatteryOptExemption();
    if (!ok) {
      await requestBatteryOptExemption();
    }
  }

  // 精确闹钟：确保（未授权时请求）
  static Future<void> ensureExactAlarmPermission() async {
    final ok = await hasExactAlarmPermission();
    if (!ok) {
      await requestExactAlarmPermission();
    }
  }
}
