import 'will_models.dart';

WillDeepLessonContent getWillDeepLessonContent(WillUnitIndex unit) {
  final zone = _zone(unit.moduleCode);
  final key = '${unit.moduleCode}:${unit.id}';
  final explicit = _explicit[key];
  if (explicit != null) return explicit;
  if (unit.moduleCode == 'D') return _introCluster(unit, zone);
  if (unit.moduleCode == 'I') return _ideoMotorCluster(unit, zone);
  if (unit.moduleCode == 'E') return _effortCluster(unit, zone);
  if (unit.moduleCode == 'P') return _pleasureCluster(unit, zone);
  if (unit.moduleCode == 'O') return _obstructedCluster(unit, zone);
  if (unit.moduleCode == 'X') return _explosiveCluster(unit, zone);
  return WillDeepLessonContent(
    originalKeyPoint: '这一单元的原始要点是：${unit.oneLiner}',
    coreMeaning: '它帮助你把抽象意志机制落到现实中，判断当前是冲动过快、阻滞过强、注意失守，还是需要 effort 去维持正确观念。',
    extension: '它适用于学习、工作、关系、自我管理、目标推进等需要把“知道”转成“做到”的情境。',
    realCase: '把它放回你最近最真实的一个困扰里：拖延、冲动、犹豫、回避、明知不做，都可以用这个单元来解释其中一环。',
    practiceAction: '今天用这个单元做一个 2 分钟最小动作：先识别机制，再做一次很小的现实介入。',
    ifThen: '如果这个问题再次出现，那么我先让正确观念在心里多停留 10 秒，再做一个最小动作。',
    mirrorZone: zone,
    reviewPrompt: '今天「${unit.title}」最像出现在什么情境？下次我最早能在哪个点介入？',
  );
}


WillDeepLessonContent _introCluster(WillUnitIndex unit, String zone) {
  final n = _unitNo(unit.id);
  if (n <= 7) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组导论单元处理“动作观念从哪里来”。它反复说明：自愿动作不是凭空从意志里长出来的，而是先有动作经验、再有动作表象。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '对你来说，这一组最重要的不是记名词，而是看见一个事实：身体先学会，意志才能调用。很多“我知道该怎么做却还是做不出来”的问题，本质上是经验痕迹不够，动作线索还不清楚。',
      extension: '它适用于新习惯、技能学习、康复训练、运动动作、说话发音、晨起流程、任何第一步总显得笨拙的情境。',
      realCase: '比如你想开始一个晨间习惯、想练一个训练动作、想稳定地进入写作。真正缺的常不是道理，而是那个能让身体立刻接上的感觉脚本。',
      practiceAction: '今天把「${unit.title}」应用到一个新动作上：先做 2 次慢速预演，每次都刻意感受身体里最明显的本地感觉，再做第 3 次真实动作。',
      ifThen: '如果我又把“理解了”当成“已经会做”，那么我先补一次低要求、可感觉的身体预演。',
      mirrorZone: zone,
      reviewPrompt: '今天哪一个动作暴露出：我脑中已经知道，但身体里还没有形成可调用的线索？',
    );
  }
  if (n <= 19) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组导论单元处理“动作为什么需要引导性感觉”。病例、催眠和视觉补偿都在说明：动作链条若没有在线反馈，就会迷失。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '对你来说，这一组说明了“行动不是靠决心硬顶”，而是靠每一步都知道自己现在处在哪一环。没有这个在线定位，再强的意愿也会变成乱撞。',
      extension: '它适用于复杂流程、精细动作、写作流程、说话表达、康复、训练动作和任何中间容易迷路的任务。',
      realCase: '你开始一个任务时也许能起步，但做着做着就散了。原因往往不是不想做，而是没有中间反馈，脑中没有“我现在在第几步”的线索。',
      practiceAction: '今天选一个 3 步以上的动作流程，每做一步都口头标记一次“我现在在哪一步”，并记录哪一步最容易失去感觉引导。',
      ifThen: '如果我在中途开始发散或失去动作感，那么我先停下来，重新确认“我现在处在流程的哪一步”。',
      mirrorZone: zone,
      reviewPrompt: '今天哪个任务不是输在开始，而是输在中间失去了引导性感觉？',
    );
  }
  if (n <= 40) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组导论单元集中批判“神经支配感”，并把动作真正可意识到的前态，压回到“结果图像 + 必要时的 fiat”。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '对你来说，这一组最重要的价值，是把意志从“神秘劲头”改写成“结果图像是否清楚、同意是否出现”。这会显著降低无力感，因为问题从抽象人格缺陷，变成了可分析的动作结构。',
      extension: '它适用于总觉得自己“差一股劲”、总想靠狠劲启动、觉得行动应该来自某个神秘内在电门的场景。',
      realCase: '很多人想写作、健身、沟通或开始困难任务时，会说“我就是提不起那股劲”。这一组会逼你追问：你到底缺的是清楚的结果图像，还是在把问题神秘化？',
      practiceAction: '今天当你再次说“我没那股劲”时，立刻改写成三项：我要让什么结果现实化、眼下的阻滞是什么、这一步是否需要明确的 fiat。',
      ifThen: '如果我又把问题说成“缺一股神秘的动力”，那么我先回到动作结果图像、阻滞观念和最小第一步。',
      mirrorZone: zone,
      reviewPrompt: '今天哪一刻我把一个本可分析的行动困难，重新神秘化成了“就是没劲”？',
    );
  }
  if (n <= 51) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组导论单元检验“努力感是否证明支配感存在”。作者借瘫痪与呼吸肌实验说明：努力感仍然可以由真实收缩和传入感觉解释。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '对你来说，这一组提醒：你感到“我在用力”并不自动说明你抓住了意志的核心。有时你抓住的只是身体紧绷，而真正该训练的是让正确对象留在心里。',
      extension: '它适用于高 effort 任务、临门一脚、情绪压制、强撑与硬顶、以及把努力误解成纯肌肉紧张的时候。',
      realCase: '你在一项困难任务前会本能咬牙、憋气、耸肩，主观上觉得自己在“很努力”。但这未必等于正确的意志工作；有时只是全身先绷上了。',
      practiceAction: '今天在一次困难动作前，观察自己有没有先出现憋气、顶胸、绷脸。把它和真正的目标观念分开记录。',
      ifThen: '如果我又把全身紧张误当成有效努力，那么我先放松身体，再确认自己真正要维持的对象是什么。',
      mirrorZone: zone,
      reviewPrompt: '今天哪一次“很用力”的感觉，其实更多是身体紧绷，而不是清楚地维持了正确对象？',
    );
  }
  if (n <= 77) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组导论单元继续用眼动、视觉眩晕与麻痹错觉来清理伪证据，说明我们并不需要假定一种“外发支配感”。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '它对现实训练的价值在于：再次把“行动控制”从想象中的神秘控制杆，拉回到可观察的感觉、注意和误判结构。很多失误来自信息盘点不全，而不是缺一股意志流。',
      extension: '它适用于空间判断、复杂任务出错、过度自信、把错觉当事实、以及总以为“我明明已经做对了”的情形。',
      realCase: '现实里很多行动失败并不是没做，而是做错了、以为自己做到了、或误把某个替代信号当成真正进展。你以为问题在动力，实际问题在误判。',
      practiceAction: '今天对一个你“以为已经推进”的任务做一次事实核对：我真正完成了什么？我只是感觉自己推进了，还是确实有外部结果？',
      ifThen: '如果我又陷入“我好像已经做了”的错觉，那么我先核对外部证据，而不是继续依赖主观感觉。',
      mirrorZone: zone,
      reviewPrompt: '今天哪一次我误把“像是在前进”当成了真正前进？',
    );
  }
  return WillDeepLessonContent(
    originalKeyPoint: '导论最后一组单元的任务，是把前面所有铺垫收束成一句话：自愿动作之前，真正能作为线索的，是动作可感觉结果的预期，而不是神经支配感。当前单元的核心句是：${unit.oneLiner}',
    coreMeaning: '对你来说，这一组就是整章的地基。以后无论你做计划、任务、复盘还是镜像城训练，都可以回到这个结构：结果图像、阻滞观念、必要时的 fiat。',
    extension: '它适用于整个模块，是所有训练动作的解释底座。',
    realCase: '当你终于不再说“我没意志力”，而开始说“我没有抓住结果图像”“我被某个对抗观念卡住”“我还没真正说出同意”，你就进入了可训练的世界。',
    practiceAction: '把今天一个最难开始的任务写成三栏：结果图像、阻滞观念、是否需要 fiat。',
    ifThen: '如果我又把行动困难看成人格失败，那么我先按“线索—阻滞—同意”重写一次。',
    mirrorZone: zone,
    reviewPrompt: '今天哪个困难最能用“线索—阻滞—同意”这三项重新解释？',
  );
}

WillDeepLessonContent _ideoMotorCluster(WillUnitIndex unit, String zone) {
  final n = _unitNo(unit.id);
  if (n <= 5) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组“观念—运动作用”单元在定义最简单的意志形式：想到一个动作，在没有额外阻滞时，它就自然发生。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '对你来说，这组内容能解除一个常见误解：很多事情不是因为你“太不自律”才没做，而是因为你把动作复杂化了，忘了行动最初常常只是一个低阻力转换。',
      extension: '它适用于顺手动作、微任务、任务起步、习惯建立、极小启动法。',
      realCase: '你看到杯子空了就去接水、看到消息就顺手回一句，这些都不是大决战，而是观念几乎直接转成动作。',
      practiceAction: '今天刻意记录 3 次“想到就做”的瞬间，写下它们为什么没形成阻滞。',
      ifThen: '如果我又把一个小动作想得很重，那么我先把它还原成一个无需隆重命令的低阻力动作。',
      mirrorZone: zone,
      reviewPrompt: '今天哪一个动作本来可以直接发生，却被我额外抬高了门槛？',
    );
  }
  if (n <= 10) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组单元处理“没有冲突观念时，动作为何几乎必然发生”，并用催眠、模仿与赖床解释阻滞如何解除。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '这组内容把重点从“我要多努力”转到“谁在阻碍我”。很多行动困难并不是缺目标，而是目标一出现，马上就被反向观念夺走了放电权。',
      extension: '它特别适用于起床困难、拖延启动、消息迟迟不发、开工前徘徊、明知要做却迟迟不做。',
      realCase: '赖床就是最典型例子：你并不是一直没有起床观念，而是“暖和、太冷、再躺会儿”不断把它压回去。',
      practiceAction: '今天选一个容易拖延的动作，写出动作观念一出现时立刻冒出来的 1 句反向台词，然后把任务缩到只剩第一个物理动作。',
      ifThen: '如果我又在起步前被一堆反向台词拖住，那么我先让第一个最小动作发生，再允许自己继续评估。',
      mirrorZone: zone,
      reviewPrompt: '今天真正挡住行动的，不是缺目标，而是哪一句冲突观念？',
    );
  }
  if (n <= 15) {
    return WillDeepLessonContent(
      originalKeyPoint: '这一组单元说明：动作即便被抑制，也常以萌芽形式先发生；而 fiat 往往只在需要穿过阻滞时才突出。当前单元的核心句是：${unit.oneLiner}',
      coreMeaning: '对你来说，这意味着“我明明没做”并不代表系统里什么都没发生。很多时候身体已先绷紧、喉咙已先发力、手已先想动，只是被别的观念拦住了。',
      extension: '它适用于临门退缩、想说不敢说、想做又压住、需要识别 fiat 真正出现时刻的场景。',
      realCase: '你想发一条消息却没发，表面看像完全没行动；但仔细看，手已经点进对话框、心跳已经变快、脑中已经把内容预演了一遍。',
      practiceAction: '今天复盘一件没做成的动作，别只写“没做”，而是写出它以什么萌芽形式已经发生了。',
      ifThen: '如果我又停在临门一脚，那么我先说出“现在阻挡我的是什么”，再给出一句简短 fiat。',
      mirrorZone: zone,
      reviewPrompt: '今天我需要明确 fiat 的时刻是哪一刻？在那之前动作已经如何萌芽？',
    );
  }
  return WillDeepLessonContent(
    originalKeyPoint: '这一组单元把“观念—运动作用”从个别例子提升到总图景：行为是多股微细力量的合成，抑制也可以只是相反观念的在场。当前单元的核心句是：${unit.oneLiner}',
    coreMeaning: '对你来说，这让行动从“有没有意志力”这种二元问题，变成“哪些观念在推动，哪些观念在拦截”。真正要练的，是让正确观念站住，而不是凭空制造力量。',
    extension: '它适用于自控、拖延、冲动压制、决策卡住、注意保持。',
    realCase: '你以为自己今天“什么都没做”，但从神经和心理角度看，可能只是力量彼此抵消，最后只留下一个轻微表情、一声叹气、一次呼气或一次摸手机。',
    practiceAction: '今天把一个卡住的时刻拆成两列：推动动作的观念、拦截动作的观念。最后写一句：哪一边只要再多停留 10 秒，结果就会变。',
    ifThen: '如果我又把行动问题看成一团混乱，那么我先把推动与拦截的两组观念分开写出来。',
    mirrorZone: zone,
    reviewPrompt: '今天哪一次看似“什么都没发生”，其实只是推动与拦截力量在彼此抵消？',
  );
}

WillDeepLessonContent _effortCluster(WillUnitIndex unit, String zone) => WillDeepLessonContent(
  originalKeyPoint: '这一单元属于努力感部分。它的原始目标，是说明努力为什么主要落在“让较弱但较高的动机取胜”上。当前单元的核心句是：${unit.oneLiner}',
  coreMeaning: '对你来说，努力不是简单用力，而是让远、抽象、不习惯、却更值得的对象，在本能与习惯面前站住。',
  extension: '它适用于长期目标、自律训练、抗拖延、对抗眼前舒服、以及需要沿“最大阻力线”行动的时候。',
  realCase: '你明知道应该开始工作、运动、道歉或停止刷手机，真正难的不是体力，而是让那个较高对象不要被即时舒服赶走。',
  practiceAction: '今天做一次 30 秒注意锁定：把最该做的对象写在纸上，看着它 30 秒，不切屏，不改任务。',
  ifThen: '如果我又被眼前舒服带走，那么我先让正确对象多留在心里 10 秒，再决定。',
  mirrorZone: zone,
  reviewPrompt: '今天哪一个对象本来更值得，却因为太远、太抽象或太不舒服而失去了推动力？',
);

WillDeepLessonContent _pleasureCluster(WillUnitIndex unit, String zone) => WillDeepLessonContent(
  originalKeyPoint: '这一单元属于“快乐与痛苦作为行动的动力”。作者要说明的是：快痛很重要，但远不是唯一动力；更关键的是，很多时候我们追求的是解除阻断后的舒服。当前单元的核心句是：${unit.oneLiner}',
  coreMeaning: '对你来说，这一组能直接解释“为什么我知道没意义还会去做”。问题往往不在于对象本身，而在于它能迅速解除紧张、无聊、焦虑和拖延的不适。',
  extension: '它适用于刷手机、熬夜、暴食、冲动消费、临时逃避、拖着不开始又不停找替代刺激的场景。',
  realCase: '你以为自己想看第 18 条短视频，但很多时候你真正想要的是：别让我此刻面对那个难任务。',
  practiceAction: '下次想分心时，先写一句：我现在想得到的是这个对象，还是想解除别的难受？',
  ifThen: '如果我又被即时舒服吸走，那么我先把“对象本身”和“解除不适”分开写出来。',
  mirrorZone: zone,
  reviewPrompt: '今天哪一次行动看似是在追求快乐，其实更多是在逃离不适？',
);

WillDeepLessonContent _obstructedCluster(WillUnitIndex unit, String zone) => WillDeepLessonContent(
  originalKeyPoint: '这一单元属于阻塞型意志。这里的问题不是不知道，而是知道也起不来、理想也进不了主调。当前单元的核心句是：${unit.oneLiner}',
  coreMeaning: '对你来说，阻塞型意志最重要的识别点是：目标并未消失，但对象缺乏现实感，动作启动不了。',
  extension: '它适用于长期拖延、任务过大、明白却不做、觉得一切都远、不真实、碰不到自己的情形。',
  realCase: '你知道应该回邮件、开始论文、做训练、处理关系，但这些对象像在远处悬着，完全碰不到今天的身体。',
  practiceAction: '今天把一个拖住你的任务缩成 2 分钟动作，并给它加一个可感结果：完成后你会看到什么变化？',
  ifThen: '如果我又觉得“明明知道，却就是动不了”，那么我先缩小动作，再给它一个更近的结果图像。',
  mirrorZone: zone,
  reviewPrompt: '今天哪一个对象之所以无效，不是因为它不重要，而是因为它离我太远、太不真实？',
);

WillDeepLessonContent _explosiveCluster(WillUnitIndex unit, String zone) => WillDeepLessonContent(
  originalKeyPoint: '这一单元属于爆发型意志。它说明失控并不总是欲望巨大，也可能是阈值过低、通路过通、或某个观念异常强迫。当前单元的核心句是：${unit.oneLiner}',
  coreMeaning: '对你来说，爆发型问题的关键不是羞辱自己，而是识别：到底是抑制太弱，还是某个念头太强，还是你太早进入了自动泄洪。',
  extension: '它适用于情绪爆发、成瘾、冲动消费、性冲动、强迫行为、想法一来就控制不住的场景。',
  realCase: '你不是每次都真心想要那个对象，而是只要它一出现，通路就过于通畅，身体已经向那边滑过去。',
  practiceAction: '今天对一个高风险诱惑做“延迟 90 秒 + 命名冲动”的练习，并记录冲动最高点持续了多久。',
  ifThen: '如果某个冲动又突然变得不可抗，那么我先命名它是“爆发，不是决定”，再延迟 90 秒。',
  mirrorZone: zone,
  reviewPrompt: '今天哪一次行为更像“泄洪”，而不是清楚选择？那个瞬间最早出现的线索是什么？',
);

int _unitNo(String id) {
  final match = RegExp(r'-(\d+)$').firstMatch(id);
  return int.tryParse(match?.group(1) ?? '') ?? 0;
}

String _zone(String code) {
  switch (code) {
    case 'D': return '感动港';
    case 'I': return '起意场';
    case 'A': return '审议庭';
    case 'T': return '裁决塔';
    case 'E': return '努力坡';
    case 'X': return '爆燃区';
    case 'O': return '阻塞谷';
    case 'P': return '诱惑市集';
    case 'R': return '观念神殿';
    case 'F': return '自由岔路';
    case 'W': return '锻造工坊';
    default: return '镜像城';
  }
}

const Map<String, WillDeepLessonContent> _explicit = {
  'D:D-003': WillDeepLessonContent(
    originalKeyPoint: '作者在这里明确提出：自愿运动是“次级功能”，不是“初级功能”。任何真正自愿的动作，都建立在先前非自愿、反射、本能或偶然动作经验之上。',
    coreMeaning: '这意味着人不是一开始就会“靠意志做事”。你之所以能主动做一个动作，是因为这个动作早已在经验中发生过，并在心里留下了可被再次唤起的表象。',
    extension: '它适用于技能学习、行为训练、习惯养成、康复训练，以及一切“我知道但还不会自然做”的场景。它特别能纠正“只要想清楚就会做到”的误解。',
    realCase: '比如第一次做深蹲、第一次练发音、第一次开始晨间流程时，你常常会发现：道理都懂，但身体不会。因为身体还没有形成足够清晰的动作观念。',
    practiceAction: '今天找一个你总想养成却还不自然的动作，只练“第一步的身体版本”3 次，不求完整，只求把动作观念做出来。',
    ifThen: '如果我又把“知道”当成“会做”，那么我先补一次身体层面的预演，而不是继续给自己讲道理。',
    mirrorZone: '感动港',
    reviewPrompt: '今天哪件事暴露了“我脑子里会，但身体里还不会”？我有没有给它一次非完美但真实的预演？',
  ),
  'D:D-020': WillDeepLessonContent(
    originalKeyPoint: '作者在这里收束导论前半：自愿动作至少需要一个能界定“此刻要做哪个动作”的感觉性观念。',
    coreMeaning: '意志不是空的“我要做”，而是一个被感觉图像具体化的“我要做这个”。如果没有这层具体化，意志会变成一团空泛命令。',
    extension: '它适用于起步不清楚、动作模糊、计划过大、总说“我要努力一点”却无从下手的情况。',
    realCase: '比如你说“我要开始工作”，但并不知道第一步是打开哪个页面、看到什么、手要放在哪里、第一句写什么，于是行动根本不会真正开始。',
    practiceAction: '把一个今天要做的动作写成可感觉的版本：开始时会看到什么、手会碰到什么、第一下会做出什么细小动作。',
    ifThen: '如果我又用抽象口号命令自己行动，那么我先把动作改写成可看见、可听见或可感觉的第一步。',
    mirrorZone: '感动港',
    reviewPrompt: '今天哪一个“我要做”其实太空了？我有没有把它改成具体可感觉的动作线索？',
  ),
  'D:D-022': WillDeepLessonContent(
    originalKeyPoint: '传统心理学常主张：除了动作结果图像，还需要一种“神经支配感”来告诉心灵自己正在向哪块肌肉发出能量。',
    coreMeaning: '这一单元的重要性在于：它代表了作者接下来要拆掉的一整个误解——把意志误认成一种神秘的内在发令能量。',
    extension: '它适用于所有“我是不是只差一股劲”“我是不是缺一种内在发令感”的自我叙述。',
    realCase: '很多人说自己“不是不会，就是提不起劲”，仿佛身体里应该存在某个神秘启动电门。作者的工作，就是说明这个想法为什么看似合理，却站不住。',
    practiceAction: '今天当你说“我就是提不起劲”时，暂停 10 秒，改问自己：我现在缺的到底是动作结果图像，还是只是把问题神秘化了？',
    ifThen: '如果我又把问题说成“差一股神秘劲”，那么我先回到动作线索、阻滞观念和最小第一步。',
    mirrorZone: '感动港',
    reviewPrompt: '今天我有没有把一个可分析的问题，误说成“就是没那股劲”？',
  ),
  'D:D-083': WillDeepLessonContent(
    originalKeyPoint: '导论最后的总收束是：使动作成为自愿的，不是“支配思想”，而是动作可感觉效果的预期；而 fiat 的复杂性将进入下一节。',
    coreMeaning: '这是整章地基：你真正能抓住的，不是神秘能量，而是结果图像、动作线索与必要时的同意。',
    extension: '它适用于整个产品里的所有训练：知识卡、任务、if-then、镜像城、复盘，其实都在围绕这一条主线服务。',
    realCase: '当你终于把“我没意志力”翻译成“我没有抓住动作线索、我被冲突观念挡住了、我还没做出 fiat”，你就开始真正拥有可训练的抓手。',
    practiceAction: '写下今天一个最难开始的动作，并把它拆成：结果图像、阻滞观念、是否需要 fiat 三项。',
    ifThen: '如果我又把行动困难看成“人格缺陷”，那么我先问：动作线索是什么？阻滞是什么？我是否需要一个明确同意？',
    mirrorZone: '感动港',
    reviewPrompt: '今天最能代表整章地基的一次行动困难是什么？我有没有把它翻译成“线索—阻滞—同意”的结构？',
  ),
  'I:I-006': WillDeepLessonContent(
    originalKeyPoint: '作者在这里强调：没有冲突观念时，动作观念几乎必然会转成动作。',
    coreMeaning: '这直接改写了“自律失败”的常见解释。很多时候不是你不想做，而是你一想到去做，立刻又被别的观念冲掉了。',
    extension: '它适用于起床、打开文档、发第一条消息、开始运动、收拾桌面、停止刷手机等所有第一步卡住的情境。',
    realCase: '你想站起来去拿水，本来动作几乎会自动发生；但若同时冒出“先等一下”“懒得动”“手头还没看完”，动作就被拦住了。',
    practiceAction: '今天选一个特别小的行动，把环境和内心里的反向观念尽量减到最少，然后观察它是不是更容易自然发生。',
    ifThen: '如果我又卡在第一步，那么我先找出当前最强的那句反向观念，并把环境里的干扰降到最低。',
    mirrorZone: '起意场',
    reviewPrompt: '今天哪个动作本来会自然发生，却被哪一句反向观念拦住了？',
  ),
  'I:I-009': WillDeepLessonContent(
    originalKeyPoint: '赖床案例说明：真正起床往往不是靠一场宏大战斗，而是靠某个念头在没有反向建议时滑入动作。',
    coreMeaning: '这说明很多行动困难并不是靠“更用力想”解决的，而是靠暂时摆脱那些把你锁在原地的对抗性意识。',
    extension: '它适用于赖床、拖延、害怕开始、开工前无限徘徊、总想等状态好了再做的场景。',
    realCase: '你在床上想了一小时“必须起来”，但没起来；后来只是某个瞬间忘了暖和与寒冷，突然坐起，事情就推进了。',
    practiceAction: '明天把起床任务缩成“先坐起来 10 秒”，不要在床上做价值评判，只观察反向观念何时变弱。',
    ifThen: '如果我又在床上展开一场巨大的心理大战，那么我先只要求自己坐起来，不继续讨论人生。',
    mirrorZone: '起意场',
    reviewPrompt: '今天有没有哪个任务像赖床一样，被我用过度清醒的对抗意识拖住了？',
  ),
  'I:I-015': WillDeepLessonContent(
    originalKeyPoint: 'fiat 往往出现在需要解除阻滞时，而不是每一个动作都自带的一股“额外力”。',
    coreMeaning: '真正的“我决定了”常常发生在你必须穿过一个卡点的时候。若没有阻滞，很多动作根本不需要隆重决心。',
    extension: '它适用于任务开头、临门退缩、想做但被顾虑拦住的时刻，也适用于理解为什么有些决定体验特别重。',
    realCase: '你平常走路、拿杯子、打开电脑并不需要大喊一声“我命令自己”；但在你要发一封难发的邮件、去面对一个困难任务时，明确同意才会突出地出现。',
    practiceAction: '今天找一个你明确感到“要跨过去”的瞬间，把它记录为一次 fiat：当时你在穿过什么阻滞？',
    ifThen: '如果我又停在临门一脚，那么我先把阻滞说出来，再给自己一句明确同意。',
    mirrorZone: '起意场',
    reviewPrompt: '今天我真正需要 fiat 的时刻是哪一刻？它解除的是哪一种阻滞？',
  ),
};
