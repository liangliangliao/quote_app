import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import 'db.dart';

/// DAO for the "Change · Self-help" module.
///
/// The table is: self_help_records
///
/// We store both subjective (STAI-6, affective sliders) and objective (camera PPG)
/// metrics, plus a derived zone classification.
class SelfHelpDao {
  Future<int> insertRecord({
    required int timestampMs,
    int? stai6Score,
    double? stai6Prorated,
    double? arousal0To100,
    double? valence0To100,
    double? bpm,
    double? rmssdMs,
    double? signalQuality,
    String? zone,
    String? note,
  }) async {
    final db = await AppDatabase.instance();
    return await db.insert('self_help_records', {
      'timestamp_ms': timestampMs,
      'stai6_score': stai6Score,
      'stai6_prorated': stai6Prorated,
      'arousal_0_100': arousal0To100,
      'valence_0_100': valence0To100,
      'bpm': bpm,
      'rmssd_ms': rmssdMs,
      'signal_quality': signalQuality,
      'zone': zone,
      'note': note,
    });
  }

  Future<Map<String, dynamic>?> latestRecord() async {
    final db = await AppDatabase.instance();
    final rows = await db.query(
      'self_help_records',
      orderBy: 'timestamp_ms DESC, id DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<List<Map<String, dynamic>>> recentRecords({int limit = 14}) async {
    final db = await AppDatabase.instance();
    return await db.query(
      'self_help_records',
      orderBy: 'timestamp_ms DESC, id DESC',
      limit: limit,
    );
  }
}

/// DAO for Fitbit auth tokens and cached endpoint JSON.
class FitbitDao {
  Future<void> upsertAuth({
    required String userId,
    required String accessToken,
    required String refreshToken,
    required String scope,
    required int expiresAtMs,
  }) async {
    final db = await AppDatabase.instance();
    // Keep a single row per user.
    final existing = await db.query('fitbit_auth', where: 'user_id = ?', whereArgs: [userId], limit: 1);
    if (existing.isEmpty) {
      await db.insert('fitbit_auth', {
        'user_id': userId,
        'access_token': accessToken,
        'refresh_token': refreshToken,
        'scope': scope,
        'expires_at_ms': expiresAtMs,
      });
    } else {
      await db.update(
        'fitbit_auth',
        {
          'access_token': accessToken,
          'refresh_token': refreshToken,
          'scope': scope,
          'expires_at_ms': expiresAtMs,
        },
        where: 'user_id = ?',
        whereArgs: [userId],
      );
    }
  }

  Future<Map<String, dynamic>?> getAuth() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('fitbit_auth', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<void> upsertCache({
    required String cacheKey,
    required String endpoint,
    required String date,
    required Map<String, dynamic> json,
  }) async {
    final db = await AppDatabase.instance();
    await db.insert(
      'fitbit_cache',
      {
        'cache_key': cacheKey,
        'endpoint': endpoint,
        'date': date,
        'json': jsonEncode(json),
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, dynamic>?> getCache(String cacheKey) async {
    final db = await AppDatabase.instance();
    final rows = await db.query('fitbit_cache', where: 'cache_key = ?', whereArgs: [cacheKey], limit: 1);
    if (rows.isEmpty) return null;
    final row = rows.first;
    final raw = (row['json'] ?? '') as String;
    if (raw.isEmpty) return null;
    return jsonDecode(raw) as Map<String, dynamic>;
  }
}
