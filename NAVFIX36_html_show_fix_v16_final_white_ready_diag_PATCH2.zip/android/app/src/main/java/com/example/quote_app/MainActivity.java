package com.example.quote_app;

import android.os.Bundle;
import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

import android.content.pm.PackageInfo;
import androidx.webkit.WebViewCompat;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends FlutterActivity {
  private static final String CH = "com.example.quote_app/sys";

  @Override
  public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
    super.configureFlutterEngine(flutterEngine);
    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CH)
      .setMethodCallHandler((call, result) -> {
        switch (call.method) {
          case "isNativeWmEnabled":
            // Always false in this build – keep Dart scheduler active
            result.success(false);
            break;
          case "webViewInfo":
            Map<String, Object> map = new HashMap<>();
            try {
              PackageInfo p = WebViewCompat.getCurrentWebViewPackage(this);
              if (p == null) {
                map.put("ok", "false");
              } else {
                map.put("ok", "true");
                map.put("pkg", p.packageName);
                map.put("ver", p.versionName);
              }
            } catch (Throwable t) {
              map.put("ok", "false");
            }
            result.success(map);
            break;
          default:
            result.notImplemented();
        }
      });
  }
}