package com.example.quote_app.am;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final String taskUid = intent.getStringExtra("task_uid");
        final String runKey  = intent.getStringExtra("run_key");
        try {
            if (taskUid == null || taskUid.isEmpty() || runKey == null || runKey.isEmpty()) {
                // Try JSON payload shortcut
                String payload = intent.getStringExtra("payload");
                if (payload != null && !payload.isEmpty()) {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] notify with payload-json");
                    Notifier.notify(context, new com.example.quote_app.am.SqliteReader.Payload(null, null, null, null, payload));
                } else {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native fallback");
                    Notifier.fallback(context);
                }
                return;
            }

            // Normal path: fetch payload from DB and send notification asynchronously
            new Thread(() -> {
                try {
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] native notify");
                    SqliteReader.Payload p = SqliteReader.payloadByTaskUidRunKey(context, taskUid, runKey);
                    Notifier.notify(context, p);
                } catch (Throwable e) {
                    Log.e("quote_app/native", "AlarmReceiver onReceive(inner): " + e.getMessage(), e);
                    com.example.quote_app.data.DbRepository.log(context, taskUid, "[AM] exception: " + e.getMessage());
                    Notifier.fallback(context);
                }
            }).start();
        } catch (Throwable e) {
            Log.e("quote_app/native", "AlarmReceiver onReceive(outer): " + e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }
}
