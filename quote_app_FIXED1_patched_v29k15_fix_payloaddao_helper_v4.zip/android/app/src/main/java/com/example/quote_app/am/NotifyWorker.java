package com.example.quote_app.am;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class NotifyWorker extends Worker {
    public NotifyWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            Data d = getInputData();
            String taskUid = d.getString("task_uid");
            String runKey  = d.getString("run_key");
            String payload = d.getString("payload");
            if (payload != null && !payload.isEmpty()) {
                Notifier.notify(getApplicationContext(),
                    new SqliteReader.Payload(null, null, null, null, payload));
                return Result.success();
            }
            if (taskUid != null && runKey != null) {
                SqliteReader.Payload p = SqliteReader.payloadByTaskUidRunKey(getApplicationContext(), taskUid, runKey);
                Notifier.notify(getApplicationContext(), p);
                return Result.success();
            }
            // nothing to do
            return Result.success();
        } catch (Throwable e) {
            // keep visible exceptions; WorkManager will retry if needed
            return Result.failure();
        }
    }
}
