import 'dart:isolate';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/widgets.dart';
import 'package:quote_app/app_globals.dart';
import 'package:quote_app/platform/perm_helper.dart';
import 'package:flutter/services.dart' show BackgroundIsolateBinaryMessenger;
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';

import '../data/db.dart';
import '../data/dao.dart';
import 'notification_service.dart';
import 'openai_service.dart';
import 'bg_init.dart';
import 'workmanager_bridge.dart';
import '../platform/perm_helper.dart';
// ignore: implementation_imports

class SchedulerService {
  static Future<void> init() async {
    // Already initialized in main(); safe to call again (idempotent)
    await AndroidAlarmManager.initialize(); // idempotent
    // 记录精确闹钟权限状态（不弹任何引导）
    try {
      final ok = await PermHelper.hasExactAlarmPermission();
      if (!ok) { await LogDao().add(taskUid: 'system', detail: '警告! 系统未授予精确闹钟权限(Alarms & reminders)。Android 14+ 默认关闭。'); }
    } catch (_) {}

    await scheduleNextForAll();
  }

  static int _alarmIdForTask(String taskUid) {
    // stable 31-bit hash
    int h = 0;
    for (int i=0;i<taskUid.length;i++) {
      h = (h * 131 + taskUid.codeUnitAt(i)) & 0x7fffffff;
    }
    return h;
  }

  static DateTime _computeNext(Map<String,dynamic> t, {DateTime? from}) {
    final now = from ?? DateTime.now();
    String freq = (t['freq_type'] ?? 'daily') as String;
    int? weekday = t['freq_weekday'] as int?;
    int? dayOfMonth = t['freq_day_of_month'] as int?;
    final startStr = (t['start_time'] ?? '') as String;
    int hh = 9, mm = 0;
    if (startStr.contains(' ')) {
      final hm = startStr.split(' ')[1].split(':');
      if (hm.length==2) {
        hh = int.tryParse(hm[0]) ?? 9;
        mm = int.tryParse(hm[1]) ?? 0;
      }
    }
    if (freq == 'weekly') {
      final wd = (weekday ?? 1);
      int delta = (wd - now.weekday) % 7;
      var cand = DateTime(now.year, now.month, now.day, hh, mm).add(Duration(days: delta));
      if (!cand.isAfter(now)) cand = cand.add(const Duration(days: 7));
      return cand;
    } else if (freq == 'monthly') {
      final d = (dayOfMonth ?? 1);
      int y = now.year, m = now.month;
      int end = DateTime(y, m + 1, 0).day;
      var cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      if (!cand.isAfter(now)) {
        m += 1;
        end = DateTime(y, m + 1, 0).day;
        cand = DateTime(y, m, d.clamp(1, end), hh, mm);
      }
      return cand;
    } else {
      final today = DateTime(now.year, now.month, now.day, hh, mm);
      if (today.isAfter(now)) return today;
      return today.add(const Duration(days: 1));
    }
  }
static Future<void> scheduleNextForAll() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    final canExact = await PermHelper.hasExactAlarmPermission();

    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;

      final taskUid = (t['task_uid'] as String);
      final name = (t['name'] ?? '') as String;
      final next = _computeNext(t);

      // 持久化下一次触发时间
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);

      // 制定稳定唯一的 id
      final id = _alarmIdForTask(taskUid);

      // 安排 AlarmManager（能 exact 就 exact）
      await AndroidAlarmManager.oneShotAt(
        next,
        id,
        alarmCallback,
        exact: canExact,
        wakeup: true,
        allowWhileIdle: true,
        rescheduleOnReboot: true,
      );

      // 无 exact 权限：WorkManager 兜底
      if (!canExact) {
        await WorkManagerBridge.scheduleOneOff(next, nid: id, fallback: '到点啦～');
      }

      // 同步安排一个原生通知兜底
      try {
        await PermHelper.scheduleNativeNotification(
          whenMs: next.millisecondsSinceEpoch,
          title: name.isEmpty ? '名人名言' : name,
          body: '到点啦～',
          nid: id,
        );
      } catch (_) {}
    }
  }

  static Future<void> callback() async {
    final db = await AppDatabase.instance();
    final tasks = await db.query('tasks');
    final now = DateTime.now();

    for (final t in tasks) {
      if ((t['status'] ?? 'on') != 'on') continue;
      final taskUid = (t['task_uid'] as String);
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final type = (t['type'] ?? 'manual') as String;
      final startStr = (t['start_time'] ?? '') as String;

      // 仅触发到点的任务
      try {
        final dt = DateFormat('yyyy-MM-dd HH:mm').parse(startStr);
        if (dt.isAfter(now)) continue;
      } catch (_) {}

      if (type == 'manual') {
        final q = await QuoteDao().latestForTask(taskUid);
        final content = (q?['content'] ?? '') as String;

        if (content.isNotEmpty) {
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: content,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
          if (q != null && q['id'] is int) {
            await QuoteDao().markNotified(q['id'] as int);
          }
          await LogDao().add(taskUid: taskUid, detail: '手动任务通知已发送');
        } else {
          await LogDao().add(taskUid: taskUid, detail: '手动任务无可用文案');
        }
      } else {
        // auto
        final cfg = await ConfigDao().getOne();
        try {
          final openai = OpenAIService(
            endpoint: (cfg['endpoint'] ?? 'https://api.openai.com/v1/responses') as String,
            apiKey: (cfg['api_key'] ?? '') as String,
            model: (cfg['model'] ?? 'gpt-5') as String,
          );
          final prompt = (t['prompt'] ?? '给我一句简洁的中文名人名言，并附作者或来源。') as String;

          String? generated;
          for (int i=0; i<3; i++) {
            final quote = (await openai.generateQuote(prompt)).trim();
            if (quote.isEmpty) break;
            generated = quote;
            break;
          }

          final body = (generated ?? '').isEmpty ? '到点啦～' : generated!;
          await NotificationService.show(
            id: _alarmIdForTask(taskUid),
            title: name,
            body: body,
            largeIconPath: avatar.isEmpty ? null : avatar,
          );
          try { await PermHelper.cancelNativeNotification(_alarmIdForTask(taskUid)); } catch (_) {}
          await LogDao().add(taskUid: taskUid, detail: '自动任务通知已发送');
        } catch (e) {
          await LogDao().add(taskUid: taskUid, detail: '自动任务生成失败: ' + e.toString());
        }
      }

      // 安排下一次
      final next = _computeNext(t, from: now.add(const Duration(minutes: 1)));
      await db.update('tasks', {'start_time': _fmt(next)}, where: 'task_uid=?', whereArgs: [taskUid]);
    }
  }


@pragma('vm:entry-point')
Future<void> alarmCallback() async {
  await BackgroundBootstrap.initForBackground();
  try {
    await SchedulerService.callback();
  } catch (e) {
    try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: 'callback异常: ' + e.toString()); } catch (_) {}
    await _scheduleRetryIn(minutes: 1);
  }
}

Future<void> _scheduleRetryIn({int minutes = 1}) async {
  try {
    final when = DateTime.now().add(Duration(minutes: minutes));
    const int _retryId = 19997;
    final canExact = await PermHelper.hasExactAlarmPermission();
    await AndroidAlarmManager.oneShotAt(
      when,
      _retryId,
      alarmCallback,
      exact: canExact,
      wakeup: true,
      allowWhileIdle: true,
      rescheduleOnReboot: true,
    );
    if (!canExact) {
      await WorkManagerBridge.scheduleOneOff(when, nid: _retryId, fallback: '重试提醒');
    }
  } catch (e) {
    try { await AppDatabase.instance(); await LogDao().add(taskUid: 'system', detail: 'retry安排失败: ' + e.toString()); } catch (_) {}
  }
}
