
import 'package:intl/intl.dart';
import 'package:workmanager/workmanager.dart';
import '../utils/debug_logger.dart';
import '../data/dao.dart';
import 'package:intl/intl.dart';
import '../platform/native_scheduler.dart';
import 'task_runner.dart';

class SchedulerService {
  static Future<void> init() async { /* no-op: Workmanager.initialize is handled in main.dart */ }

  
  static DateTime _nextTimeForTask(Map<String, dynamic> t) {
    final now = DateTime.now();
    const grace = Duration(seconds: 10); // 允许10秒误差

    // 1) 优先 next_time
    try {
      final raw = (t['next_time'] ?? '').toString();
      if (raw.isNotEmpty) {
        final dt = DateTime.tryParse(raw);
        if (dt != null && dt.isAfter(now.subtract(grace))) return dt;
      }
    } catch (_) {}

    // 2) 回落到每天固定 start_time(HH:mm)
    final start = (t['start_time'] ?? '09:00').toString();
    final parts = start.split(':');
    final hh = int.tryParse(parts.isNotEmpty ? parts[0] : '9') ?? 9;
    final mm = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
    var next = DateTime(now.year, now.month, now.day, hh, mm);
    if (next.isBefore(now.subtract(grace))) next = next.add(const Duration(days: 1));
    return next;
  }

    return next;
  }

  static int _alarmId(String uid, String runKey) {
    return (uid.hashCode ^ runKey.hashCode) & 0x7fffffff;
  }

  static String _runKeyFromTime(DateTime t) {
    return DateFormat('yyyyMMdd_HHmm').format(t);
  }

  
  static Future<void> scheduleNextForTask(String uid) async {
    final t = await TaskDao().getByUid(uid);
    if (t == null) return;
    if ((t['status'] ?? 'on').toString() != 'on') return;

    final next = _nextTimeForTask(t);
    final runKey = _runKeyFromTime(next);
    final now = DateTime.now();
    final diff = next.difference(now);
    final normalDelay = diff.isNegative ? Duration.zero : diff;

    // 记录“本次真正注册”的 runKey，供精准取消使用
    try { await TaskDao().setScheduledRunKey(uid, runKey); } catch (_) {}

    bool hasExact = false;
    try { hasExact = await PermHelper.hasExactAlarmPermission(); } catch (_) {}

    if (hasExact) {
      // ✅ 仅 AM + WM 兜底(+2 分钟)
      try {
        await NativeScheduler.scheduleExactAt(
          id: _alarmId(uid, runKey),
          epochMs: next.millisecondsSinceEpoch,
          payload: {'uid': uid, 'runKey': runKey, 'chan': 'am', 'attempt': 1},
        );
        await DLog.i('SCH', 'AM 注册完成 uid='+uid+' am_id='+_alarmId(uid, runKey).toString()+' run='+runKey);
      } catch (e) {
        await DLog.w('SCH', 'AM 注册失败，忽略: '+e.toString());
      }
      try {
        final u = _wmUniqueFallback(uid, runKey, 1);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay + const Duration(minutes: 2),
          inputData: {'job':'wm_run', 'task_uid': uid, 'run_key': runKey, 'chan': 'fallback', 'attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+u+' run='+runKey);
      } catch (e) {
        await DLog.e('SCH', 'WM 兜底注册失败: '+e.toString());
      }
    } else {
      // ✅ 仅 WM 正常 + WM 兜底(+2 分钟)
      try {
        final u = _wmUniqueNormal(uid, runKey);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay,
          inputData: {'job':'wm_run', 'task_uid': uid, 'run_key': runKey, 'chan': 'normal', 'attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH', 'WM 正常注册完成 uid='+uid+' wm_unique='+u+' run='+runKey+' delay='+normalDelay.inSeconds.toString()+'s');
      } catch (e) {
        await DLog.e('SCH', 'WM 正常注册失败: '+e.toString());
      }
      try {
        final u = _wmUniqueFallback(uid, runKey, 1);
        await Workmanager().registerOneOffTask(
          u, 'wm_task',
          initialDelay: normalDelay + const Duration(minutes: 2),
          inputData: {'job':'wm_run', 'task_uid': uid, 'run_key': runKey, 'chan': 'fallback', 'attempt': 1},
          existingWorkPolicy: ExistingWorkPolicy.replace,
          tag: uid,
        );
        await DLog.i('SCH', 'WM 兜底注册完成 uid='+uid+' wm_unique='+u+' run='+runKey);
      } catch (e) {
        await DLog.e('SCH', 'WM 兜底注册失败: '+e.toString());
      }
    }
  }

